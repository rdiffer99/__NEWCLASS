# DPSrvr.cpp

Chemin original: `C:\Users\rdiff\Desktop\__NEWCLASS\WORLDSERVER\DPSrvr.cpp`
Chemin relatif: `WORLDSERVER\DPSrvr.cpp`
Nom du fichier: `DPSrvr.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "stdafx.h"
#include "defineText.h"
#include "defineItem.h"
#include "defineSkill.h"
#include "dpcoreclient.h"
#include "dpdatabaseclient.h"
#include "dpsrvr.h"
#include "definesound.h"
#include "defineObj.h"
#include "user.h"
#include "worldmng.h"
#include "misc.h"
#include "lang.h"
#include "npchecker.h"
#include "guild.h"
#include "..\_Common\Ship.h"
#include "Party.h"
#include "Chatting.h"
#include "post.h"
#include "..\_Network\ErrorCode.h"
#include "WantedListSnapshot.h"
#include "definequest.h"

#include "HwOption.h"
extern	COption					g_Option;

#if __VER >= 12 // __PET_0519
#include "pet.h"
#endif	// __PET_0519

#if __VER >= 12 // __LORD
#include "slord.h"
#include "lordskillexecutable.h"
#endif	// __LORD

#if __VER >= 11 // __SYS_IDENTIFY
#include "randomoption.h"
#endif	// __SYS_IDENTIFY

#if __VER >= 11 // __SYS_PLAYER_DATA
#include "playerdata.h"
#endif	// __SYS_PLAYER_DATA

#if __VER >= 12 // __ITEMCREATEMON_S0602
	#include "CreateMonster.h"
#endif // __ITEMCREATEMON_S0602

#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
	#include "honor.h"
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ

#if __VER >= 12 // __SECRET_ROOM
#include "SecretRoom.h"
#endif // __SECRET_ROOM

#if __VER >= 12 // __TAX
#include "Tax.h"
#endif // __TAX

#if __VER >= 12 // __EXT_PIERCING
#include "ItemUpgrade.h"
#endif // __EXT_PIERCING

#include "tools.h"

#if __VER >= 13 // __COUPLE_1117
#include "couplehelper.h"
#endif	// __COUPLE_1117

#ifdef __QUIZ
#include "Quiz.h"
#endif // __QUIZ

#if __VER >= 15 // __GUILD_HOUSE
#include "GuildHouse.h"
#endif // __GUILD_HOUSE

#if __VER >= 15 // __CAMPUS
#include "CampusHelper.h"
#endif // __CAMPUS

#ifdef	__COLOSSEUM
#include "Colosseum.h"
#endif // __COLOSSEUM

#ifdef __SHOPPING_CART
#include "ShoppingCart.h"
#endif // __SHOPPING_CART

#ifdef __WHEEL_OF_FORTUNE
#include "WheelOfFortune.h"
#endif

#ifdef __MONSTER_CLASH
#include "MonsterClash.h"
#endif // __MONSTER_CLASH

#if __VER >= 8 //__CSC_VER8_5
struct ItemCountSet{
	OBJID itemid;
	int extracount;
};
#endif //__CSC_VER8_5

#ifdef __RECORD_BOOK
#include "RecordBook.h"
#endif

#define	MAX_RANGE_ASYNC			1024
#define	MAX_RANGE_NPC_MENU		1024

extern	CGuildMng			g_GuildMng;
extern	CPartyMng			g_PartyMng;
extern	CUserMng			g_UserMng;
extern	CDPDatabaseClient	g_dpDBClient;
extern	CDPCoreClient		g_DPCoreClient;
extern	CWorldMng			g_WorldMng;
extern	CChattingMng		g_ChattingMng;
extern	CGuildCombat		g_GuildCombatMng;

#if __VER >= 12 // __ITEMCREATEMON_S0602
#if __VER < 12 // __NEW_ITEMCREATEMON_SERVER
extern	CCreateMonster		g_CreateMonster;
#endif // __NEW_ITEMCREATEMON_SERVER
#endif // __ITEMCREATEMON_S0602

CCommonCtrl* CreateExpBox( CUser* pUser );
CDPSrvr		g_DPSrvr;

// dwGold°ú nPlusÀ» ´õ ÇÒ ¼ö ÀÖ´Â°¡?
BOOL CanAdd( DWORD dwGold, int nPlus )
{
	if( nPlus <= 0 )		// ´õÇÏ·Á´Â °ªÀÌ 0ÀÌÇÏÀÌ¸é ³Í¼¾½º 
		return FALSE;

	int nGold = dwGold;
	ASSERT( nGold >= 0 );
	return ( (nGold + nPlus) > nGold );		// ´õÇÑ °ªÀÌ overflowÀÌ¸é ¸·¾Æ¾ßÇÑ´Ù.
}

CDPSrvr::CDPSrvr()
{
#ifdef __WORLDSERVER_MENU
	m_bExchange = TRUE;
	m_bChat = TRUE;
	m_bPk = TRUE;
	m_bPkCost = TRUE;
#endif // __WORLDSERVER_MENU
	BEGIN_MSG;
#ifdef __JOPS_GLOW
	ON_MSG(PACKETTYPE_GLOW_COL, &CDPSrvr::OnGlowCol);
#endif
#ifdef __JOPS_GLOW
	ON_MSG(PACKETTYPE_GLOW_CHANGE, &CDPSrvr::OnGlowChange);
#endif
	ON_MSG( PACKETTYPE_JOIN, &CDPSrvr::OnAddUser );
	ON_MSG( PACKETTYPE_LEAVE, &CDPSrvr::OnRemoveUser );
	ON_MSG( PACKETTYPE_REPLACE, &CDPSrvr::OnReplace );
	ON_MSG( PACKETTYPE_SUMMONPLAYER, &CDPSrvr::OnSummonPlayer );
	ON_MSG( PACKETTYPE_TELEPORTPLAYER, &CDPSrvr::OnTeleportPlayer );
	ON_MSG( PACKETTYPE_CORR_REQ, &CDPSrvr::OnCorrReq );
	ON_MSG( PACKETTYPE_SCRIPTDLG, &CDPSrvr::OnScriptDialogReq );
	ON_MSG( PACKETTYPE_TRADEPUT, &CDPSrvr::OnTradePut );
	ON_MSG( PACKETTYPE_TRADEPULL, &CDPSrvr::OnTradePull );
	ON_MSG( PACKETTYPE_TRADEPUTGOLD, &CDPSrvr::OnTradePutGold );
//raiders.2006.11.28
//	ON_MSG( PACKETTYPE_TRADECLEARGOLD, &CDPSrvr::OnTradeClearGold );
	ON_MSG( PACKETTYPE_SFX_ID, &CDPSrvr::OnSfxID );
	ON_MSG( PACKETTYPE_SFX_CLEAR, &CDPSrvr::OnSfxClear );
	ON_MSG( PACKETTYPE_CREATE_GUILDCLOAK, &CDPSrvr::OnCreateGuildCloak );
	ON_MSG( PACKETTYPE_CHAT, &CDPSrvr::OnChat );
	ON_MSG( PACKETTYPE_CTRL_COOLTIME_CANCEL, &CDPSrvr::OnCtrlCoolTimeCancel );
	ON_MSG( PACKETTYPE_DOEQUIP, &CDPSrvr::OnDoEquip );
	ON_MSG( PACKETTYPE_MOVEITEM, &CDPSrvr::OnMoveItem );
	ON_MSG( PACKETTYPE_SNAPSHOT, &CDPSrvr::OnSnapshot );
	ON_MSG( PACKETTYPE_INC_STAT_LEVEL, &CDPSrvr::OnIncStatLevel );
	ON_MSG( PACKETTYPE_SEND_TO_SERVER_CHANGEJOB, &CDPSrvr::OnChangeJob );
	ON_MSG( PACKETTYPE_SETLODELIGHT, &CDPSrvr::OnSetLodelight );
	ON_MSG( PACKETTYPE_MODIFYMODE, &CDPSrvr::OnModifyMode );
	ON_MSG( PACKETTYPE_REVIVAL, &CDPSrvr::OnRevival );
	ON_MSG( PACKETTYPE_REVIVAL_TO_LODESTAR, &CDPSrvr::OnRevivalLodestar );
	ON_MSG( PACKETTYPE_REVIVAL_TO_LODELIGHT, &CDPSrvr::OnRevivalLodelight );
	ON_MSG( PACKETTYPE_OPENSHOPWND, &CDPSrvr::OnOpenShopWnd );
	ON_MSG( PACKETTYPE_CLOSESHOPWND, &CDPSrvr::OnCloseShopWnd );
	ON_MSG( PACKETTYPE_SEND_TO_SERVER_EXP, &CDPSrvr::OnExpUp );
	ON_MSG( PACKETTYPE_OPENBANKWND, &CDPSrvr::OnOpenBankWnd );
	ON_MSG( PACKETTYPE_GUILD_BANK_WND, &CDPSrvr::OnOpenGuildBankWnd );
	ON_MSG( PACKETTYPE_PUTITEMGUILDBANK, &CDPSrvr::OnPutItemGuildBank );
	ON_MSG( PACKETTYPE_GETITEMGUILDBANK, &CDPSrvr::OnGetItemGuildBank );
	ON_MSG( PACKETTYPE_GUILD_BANK_WND_CLOSE, &CDPSrvr::OnCloseGuildBankWnd );
	ON_MSG( PACKETTYPE_GUILD_BANK_MOVEITEM, &CDPSrvr::OnGuildBankMoveItem );
	ON_MSG( PACKETTYPE_CLOSEBANKWND, &CDPSrvr::OnCloseBankWnd );
	ON_MSG( PACKETTYPE_PUTITEMBACK, &CDPSrvr::OnPutItemBank );
	ON_MSG( PACKETTYPE_DOUSESKILLPOINT, &CDPSrvr::OnDoUseSkillPoint );
	ON_MSG( PACKETTYPE_PUTBACKTOBANK, &CDPSrvr::OnBankToBank );
	ON_MSG( PACKETTYPE_GETITEMBACK, &CDPSrvr::OnGetItemBank );
	ON_MSG( PACKETTYPE_PUTGOLDBACK, &CDPSrvr::OnPutGoldBank );
	ON_MSG( PACKETTYPE_GETGOLDBACK, &CDPSrvr::OnGetGoldBank );
	ON_MSG( PACKETTYPE_MOVEBANKITEM, &CDPSrvr::OnMoveBankItem );
	ON_MSG( PACKETTYPE_CHANGEBANKPASS, &CDPSrvr::OnChangeBankPass );
	ON_MSG( PACKETTYPE_CONFIRMBANK, &CDPSrvr::OnConfirmBank );	
	ON_MSG( PACKETTYPE_PLAYERMOVED, &CDPSrvr::OnPlayerMoved );
	ON_MSG( PACKETTYPE_PLAYERBEHAVIOR, &CDPSrvr::OnPlayerBehavior );
	ON_MSG( PACKETTYPE_PLAYERMOVED2, &CDPSrvr::OnPlayerMoved2 );
	ON_MSG( PACKETTYPE_PLAYERBEHAVIOR2, &CDPSrvr::OnPlayerBehavior2 );
	ON_MSG( PACKETTYPE_PLAYERANGLE, &CDPSrvr::OnPlayerAngle );
	ON_MSG( PACKETTYPE_PLAYERCORR, &CDPSrvr::OnPlayerCorr );
	ON_MSG( PACKETTYPE_PLAYERCORR2, &CDPSrvr::OnPlayerCorr2 );
	ON_MSG( PACKETTYPE_PLAYERSETDESTOBJ, &CDPSrvr::OnPlayerSetDestObj );
	ON_MSG( PACKETTYPE_TRADE, &CDPSrvr::OnTrade );
	ON_MSG( PACKETTYPE_CONFIRMTRADE, &CDPSrvr::OnConfirmTrade );
	ON_MSG( PACKETTYPE_CONFIRMTRADECANCEL, &CDPSrvr::OnConfirmTradeCancel )
	ON_MSG( PACKETTYPE_TRADECANCEL, &CDPSrvr::OnTradeCancel );
	ON_MSG( PACKETTYPE_DOUSEITEM, &CDPSrvr::OnDoUseItem );
#ifdef __BAG_UPDATE
	ON_MSG(PACKETTYPE_DOUSEITEM_BAG, &CDPSrvr::OnDoUseItemBag);
#endif
#if __VER >= 11 // __SYS_IDENTIFY
	ON_MSG( PACKETTYPE_DO_USE_ITEM_TARGET, &CDPSrvr::OnDoUseItemTarget );
	ON_MSG( PACKETTYPE_REMOVE_ITEM_LEVEL_DOWN, &CDPSrvr::OnRemoveItemLevelDown );
	ON_MSG( PACKETTYPE_AWAKENING, &CDPSrvr::OnAwakening );
	ON_MSG( PACKETTYPE_BLESSEDNESS_CANCEL, &CDPSrvr::OnBlessednessCancel );
#endif	// __SYS_IDENTIFY
#ifdef __AZRIA_1023
	ON_MSG( PACKETTYPE_DO_USE_ITEM_INPUT, &CDPSrvr::OnDoUseItemInput );
#endif	// __AZRIA_1023
#ifdef __PET_1024
	ON_MSG( PACKETTYPE_CLEAR_PET_NAME, &CDPSrvr::OnClearPetName );
#endif	// __PET_1024
#if __VER >= 11 // __SYS_POCKET
	ON_MSG( PACKETTYPE_AVAIL_POCKET, &CDPSrvr::OnAvailPocket );
	ON_MSG( PACKETTYPE_MOVE_ITEM_POCKET, &CDPSrvr::OnMoveItemOnPocket );
#endif	// __SYS_POCKET

#ifdef __JEFF_11
	ON_MSG( PACKETTYPE_QUE_PETRESURRECTION, &CDPSrvr::OnQuePetResurrection );
#endif	// __JEFF_11

#ifdef __JEFF_11_4
	ON_MSG( PACKETTYPE_ARENA_ENTER, &CDPSrvr::OnArenaEnter );
	ON_MSG( PACKETTYPE_ARENA_EXIT, &CDPSrvr::OnArenaExit );
#endif	// __JEFF_11_4

	ON_MSG( PACKETTYPE_TRADECONFIRM, &CDPSrvr::OnTradelastConfrim );
	ON_MSG( PACKETTYPE_MOVERFOCOUS, &CDPSrvr::OnMoverFocus );
	ON_MSG( PACKETTYPE_DROPITEM, &CDPSrvr::OnDropItem );
	ON_MSG( PACKETTYPE_DROPGOLD, &CDPSrvr::OnDropGold );
	ON_MSG( PACKETTYPE_BUYITEM, &CDPSrvr::OnBuyItem );
#if __VER >= 11 // __GUILDCOMBATCHIP
	ON_MSG( PACKETTYPE_BUYCHIPITEM, &CDPSrvr::OnBuyChipItem );
#endif // __GUILDCOMBATCHIP
	ON_MSG( PACKETTYPE_SELLITEM, &CDPSrvr::OnSellItem );
	ON_MSG( PACKETTYPE_TRADEOK, &CDPSrvr::OnTradeOk );
	ON_MSG( PACKETTYPE_MELEE_ATTACK, &CDPSrvr::OnMeleeAttack );
	ON_MSG( PACKETTYPE_MELEE_ATTACK2, &CDPSrvr::OnMeleeAttack2 );
	ON_MSG( PACKETTYPE_MAGIC_ATTACK, &CDPSrvr::OnMagicAttack );
	ON_MSG( PACKETTYPE_RANGE_ATTACK, &CDPSrvr::OnRangeAttack );
	ON_MSG( PACKETTYPE_SFX_HIT, &CDPSrvr::OnSfxHit );
	ON_MSG( PACKETTYPE_USESKILL, &CDPSrvr::OnUseSkill );
	ON_MSG( PACKETTYPE_SETTARGET, &CDPSrvr::OnSetTarget );	// Core¿¡ º¸³»¾ß ÇÏ´ÂÁö È®ÀÎÇØ ÁÙ°Í.
	ON_MSG( PACKETTYPE_TELESKILL, &CDPSrvr::OnTeleSkill );	
	ON_MSG( PACKETTYPE_SKILLTASKBAR, &CDPSrvr::OnSkillTaskBar );
	ON_MSG( PACKETTYPE_ADDAPPLETTASKBAR, &CDPSrvr::OnAddAppletTaskBar );
	ON_MSG( PACKETTYPE_REMOVEAPPLETTASKBAR, &CDPSrvr::OnRemoveAppletTaskBar );
	ON_MSG( PACKETTYPE_ADDITEMTASKBAR, &CDPSrvr::OnAddItemTaskBar );
	ON_MSG( PACKETTYPE_REMOVEITEMTASKBAR, &CDPSrvr::OnRemoveItemTaskBar );
	ON_MSG( PACKETTYPE_QUERYGETPOS, &CDPSrvr::OnQueryGetPos );
	ON_MSG( PACKETTYPE_GETPOS, &CDPSrvr::OnGetPos );
	ON_MSG( PACKETTYPE_QUERYGETDESTOBJ, &CDPSrvr::OnQueryGetDestObj );
	ON_MSG( PACKETTYPE_GETDESTOBJ, &CDPSrvr::OnGetDestObj );
	ON_MSG( PACKETTYPE_MEMBERREQUEST, &CDPSrvr::OnPartyRequest );
	ON_MSG( PACKETTYPE_MEMBERREQUESTCANCLE, &CDPSrvr::OnPartyRequestCancle );
	ON_MSG( PACKETTYPE_PARTYSKILLUSE, &CDPSrvr::OnPartySkillUse );
	ON_MSG( PACKETTYPE_ADDFRIENDREQEST, &CDPSrvr::OnAddFriendReqest );
	ON_MSG( PACKETTYPE_ADDFRIENDNAMEREQEST, &CDPSrvr::OnAddFriendNameReqest );
	ON_MSG( PACKETTYPE_ADDFRIENDCANCEL, &CDPSrvr::OnAddFriendCancel );
	ON_MSG( PACKETTYPE_DUELREQUEST, &CDPSrvr::OnDuelRequest );
	ON_MSG( PACKETTYPE_DUELYES, &CDPSrvr::OnDuelYes );
	ON_MSG( PACKETTYPE_DUELNO, &CDPSrvr::OnDuelNo );
	ON_MSG( PACKETTYPE_DUELPARTYREQUEST, &CDPSrvr::OnDuelPartyRequest );
	ON_MSG( PACKETTYPE_DUELPARTYYES, &CDPSrvr::OnDuelPartyYes );
	ON_MSG( PACKETTYPE_DUELPARTYNO, &CDPSrvr::OnDuelPartyNo );
	ON_MSG(PACKETTYPE_SEND_TO_SERVER_AP, &CDPSrvr::OnActionPoint);
#if __VER >= 11 // __SYS_PLAYER_DATA
	ON_MSG( PACKETTYPE_QUERY_PLAYER_DATA, &CDPSrvr::OnQueryPlayerData );
	ON_MSG( PACKETTYPE_QUERY_PLAYER_DATA2, &CDPSrvr::OnQueryPlayerData2 );
#else	// __SYS_PLAYER_DATA
	ON_MSG( PACKETTYPE_QUERYPLAYERSTRING, &CDPSrvr::OnQueryPlayerString );
	ON_MSG( PACKETTYPE_QUERYPLAYERLISTSTRING, &CDPSrvr::OnQueryPlayerListString );
	ON_MSG( PACKETTYPE_GETFRIENDNAME, &CDPSrvr::OnGetFriendName );
#endif	// __SYS_PLAYER_DATA
	ON_MSG( PACKETTYPE_GUILD_INVITE, &CDPSrvr::OnGuildInvite );
	ON_MSG( PACKETTYPE_IGNORE_GUILD_INVITE, &CDPSrvr::OnIgnoreGuildInvite );
	ON_MSG( PACKETTYPE_NW_GUILDLOGO, &CDPSrvr::OnGuildLogo );			// ·Î°í º¯°æ 
	ON_MSG( PACKETTYPE_NW_GUILDCONTRIBUTION, &CDPSrvr::OnGuildContribution );		// °øÇåµµ 
	ON_MSG( PACKETTYPE_NW_GUILDNOTICE, &CDPSrvr::OnGuildNotice );		// °øÁö»çÇ×  
#ifdef __GUILDRANK
	ON_MSG( PACKETTYPE_REQUEST_GUILD_RANKING, &CDPSrvr::OnRequestGuildRank );
#endif
	ON_MSG( PACKETTYPE_PVENDOR_OPEN, &CDPSrvr::OnPVendorOpen );
	ON_MSG( PACKETTYPE_PVENDOR_CLOSE, &CDPSrvr::OnPVendorClose );
	ON_MSG( PACKETTYPE_REGISTER_PVENDOR_ITEM, &CDPSrvr::OnRegisterPVendorItem );
	ON_MSG( PACKETTYPE_UNREGISTER_PVENDOR_ITEM, &CDPSrvr::OnUnregisterPVendorItem );
	ON_MSG( PACKETTYPE_QUERY_PVENDOR_ITEM, &CDPSrvr::OnQueryPVendorItem );
	ON_MSG( PACKETTYPE_BUY_PVENDOR_ITEM, &CDPSrvr::OnBuyPVendorItem );
	ON_MSG( PACKETTYPE_REPAIRITEM, &CDPSrvr::OnRepairItem );
	ON_MSG( PACKETTYPE_SET_HAIR, &CDPSrvr::OnSetHair );
	ON_MSG( PACKETTYPE_BLOCK, &CDPSrvr::OnBlock );
	ON_MSG( PACKETTYPE_MOTION, &CDPSrvr::OnMotion );
	ON_MSG( PACKETTYPE_SHIP_ACTMSG, &CDPSrvr::OnShipActMsg );
	ON_MSG( PACKETTYPE_LOCALPOSFROMIA, &CDPSrvr::OnLocalPosFromIA );
	ON_MSG( PACKETTYPE_UPGRADEBASE, &CDPSrvr::OnUpgradeBase );
	ON_MSG( PACKETTYPE_ENCHANT, &CDPSrvr::OnEnchant );
#if __VER >= 14 // __SMELT_SAFETY
	ON_MSG( PACKETTYPE_SMELT_SAFETY, &CDPSrvr::OnSmeltSafety );
#ifdef __LDE_SMELTWND
	ON_MSG(PACKETTYPE_PRIME_SMELT, &CDPSrvr::onPrimeSmelt);
#endif
#endif // __SMELT_SAFETY
#if __VER >= 10 // __REMOVE_ATTRIBUTE
	ON_MSG( PACKETTYPE_REMVOE_ATTRIBUTE, &CDPSrvr::OnRemoveAttribute );
#endif // __REMOVE_ATTRIBUTE
#if __VER >= 13 // __EXT_ENCHANT
	ON_MSG( PACKETTYPE_CHANGE_ATTRIBUTE, &CDPSrvr::OnChangeAttribute );
#endif // __EXT_ENCHANT
	ON_MSG( PACKETTYPE_PIERCING_SIZE, &CDPSrvr::OnPiercingSize );
	ON_MSG( PACKETTYPE_EXPBOXINFO, &CDPSrvr::OnExpBoxInfo );
	ON_MSG( PACKETTYPE_RANDOMSCROLL, &CDPSrvr::OnRandomScroll );
	ON_MSG( PACHETTYPE_ITEMTRANSY, &CDPSrvr::OnItemTransy );
	ON_MSG( PACKETTYPE_PIERCING, &CDPSrvr::OnPiercing );
#if __VER >= 11 // __PIERCING_REMOVE
	ON_MSG( PACKETTYPE_PIERCINGREMOVE, &CDPSrvr::OnPiercingRemove );
#endif // __PIERCING_REMOVE
	ON_MSG( PACKETTYPE_BUYING_INFO, &CDPSrvr::OnBuyingInfo );
	ON_MSG( PACKETTYPE_ENTERCHTTING, &CDPSrvr::OnEnterChattingRoom );
	ON_MSG( PACKETTYPE_CHATTING, &CDPSrvr::OnChatting );
	ON_MSG( PACKETTYPE_OPENCHATTINGROOM, &CDPSrvr::OnOpenChattingRoom );
	ON_MSG( PACKETTYPE_CLOSECHATTINGROOM, &CDPSrvr::OnCloseChattingRoom );
	ON_MSG( PACKETTYPE_COMMONPLACE, &CDPSrvr::OnCommonPlace );
	ON_MSG( PACKETTYPE_SETNAVIPOINT, &CDPSrvr::OnSetNaviPoint );
	ON_MSG( PACKETTYPE_DO_ESCAPE, &CDPSrvr::OnDoEscape );
	ON_MSG( PACKETTYPE_LOG_GAMEMASTER_CHAT, &CDPSrvr::OnGameMasterWhisper );
	ON_MSG( PACKETTYPE_RETURNSCROLL, &CDPSrvr::OnReturnScroll );
	ON_MSG( PACKETTYPE_ENDSKILLQUEUE, &CDPSrvr::OnEndSkillQueue );
	ON_MSG( PACKETTYPE_FOCUSOBJ, &CDPSrvr::OnFoucusObj );

	ON_MSG( PACKETTYPE_REMOVEQUEST, &CDPSrvr::OnRemoveQuest );
	ON_MSG( PACKETTYPE_COMMERCIALELEM, &CDPSrvr::OnCommercialElem );
//	ON_MSG( PACKETTYPE_DO_COLLECT, &CDPSrvr::OnDoCollect );

	ON_MSG( PACKETTYPE_NW_WANTED_GOLD, &CDPSrvr::OnNWWantedGold );
	ON_MSG( PACKETTYPE_NW_WANTED_LIST, &CDPSrvr::OnNWWantedList );
	ON_MSG( PACKETTYPE_NW_WANTED_INFO, &CDPSrvr::OnNWWantedInfo );
	ON_MSG( PACKETTYPE_NW_WANTED_NAME, &CDPSrvr::OnNWWantedName );
	ON_MSG( PACKETTYPE_REQ_LEAVE, &CDPSrvr::OnReqLeave );
	ON_MSG( PACKETTYPE_RESURRECTION_OK, &CDPSrvr::OnResurrectionOK );
	ON_MSG( PACKETTYPE_RESURRECTION_CANCEL, &CDPSrvr::OnResurrectionCancel );
	ON_MSG( PACKETTYPE_MODE, &CDPSrvr::OnChangeMode );

	ON_MSG( PACKETTYPE_STATEMODE, &CDPSrvr::OnStateMode );
	ON_MSG( PACKETTYPE_QUERYSETPLAYERNAME, &CDPSrvr::OnQuerySetPlayerName );
	ON_MSG( PACKETTYPE_QUERYSETGUILDNAME, &CDPSrvr::OnQuerySetGuildName );
	ON_MSG( PACKETTYPE_CHEERING, &CDPSrvr::OnCheering );
	ON_MSG( PACKETTYPE_QUERYEQUIP, &CDPSrvr::OnQueryEquip );
	ON_MSG( PACKETTYPE_QUERYEQUIPSETTING, &CDPSrvr::OnQueryEquipSetting );
	ON_MSG( PACKETTYPE_QUERYPOSTMAIL, &CDPSrvr::OnQueryPostMail );
	ON_MSG( PACKETTYPE_QUERYREMOVEMAIL, &CDPSrvr::OnQueryRemoveMail );
	ON_MSG( PACKETTYPE_QUERYGETMAILITEM, &CDPSrvr::OnQueryGetMailItem );
	ON_MSG( PACKETTYPE_QUERYGETMAILGOLD, &CDPSrvr::OnQueryGetMailGold );
	ON_MSG( PACKETTYPE_READMAIL, &CDPSrvr::OnQueryReadMail );
	ON_MSG( PACKETTYPE_QUERYMAILBOX, &CDPSrvr::OnQueryMailBox );
	ON_MSG( PACKETTYPE_CHANGEFACE, &CDPSrvr::OnChangeFace );

#if __VER >= 12 // __ITEMCREATEMON_S0602
	ON_MSG( PACKETTYPE_CREATEMONSTER, &CDPSrvr::OnCreateMonster );
#endif // __ITEMCREATEMON_S0602

	ON_MSG( PACKETTYPE_IN_GUILDCOMBAT, &CDPSrvr::OnGCApp );
	ON_MSG( PACKETTYPE_OUT_GUILDCOMBAT, &CDPSrvr::OnGCCancel );	
	ON_MSG( PACKETTYPE_REQUEST_STATUS, &CDPSrvr::OnGCRequestStatus );
	ON_MSG( PACKETTYPE_SELECTPLAYER_GUILDCOMBAT, &CDPSrvr::OnGCSelectPlayer );
	ON_MSG( PACKETTYPE_SELECTMAP_GUILDCOMBAT, &CDPSrvr::OnGCSelectMap );
	ON_MSG( PACKETTYPE_JOIN_GUILDCOMBAT, &CDPSrvr::OnGCJoin );	
	ON_MSG( PACKETTYPE_GETPENYAGUILD_GUILDCOMBAT, &CDPSrvr::OnGCGetPenyaGuild );
	ON_MSG( PACKETTYPE_GETPENYAPLAYER_GUILDCOMBAT, &CDPSrvr::OnGCGetPenyaPlayer );
#if __VER < 8 // #ifndef __GUILDCOMBAT_85
	ON_MSG( PACKETTYPE_GETITEM_GUILDCOMBAT, &CDPSrvr::OnGCGetItem );
#endif // __VER < 8
	ON_MSG( PACKETTYPE_TELE_GUILDCOMBAT, &CDPSrvr::OnGCTele );
	ON_MSG( PACKETTYPE_PLAYERPOINT_GUILDCOMBAT, &CDPSrvr::OnGCPlayerPoint );
	ON_MSG( PACKETTYPE_SUMMON_FRIEND, &CDPSrvr::OnSummonFriend );
	ON_MSG( PACKETTYPE_SUMMON_FRIEND_CONFIRM, &CDPSrvr::OnSummonFriendConfirm );
	ON_MSG( PACKETTYPE_SUMMON_FRIEND_CANCEL, &CDPSrvr::OnSummonFriendCancel );
	ON_MSG( PACKETTYPE_SUMMON_PARTY, &CDPSrvr::OnSummonParty );
	ON_MSG( PACKETTYPE_SUMMON_PARTY_CONFIRM, &CDPSrvr::OnSummonPartyConfirm );

	ON_MSG( PACKETTYPE_REMOVEINVENITEM, &CDPSrvr::OnRemoveInvenItem );
	////////////////////////////////////////////////////////////////////////
#if __VER >= 8 //__CSC_VER8_5
	ON_MSG( PACKETTYPE_CREATEANGEL, &CDPSrvr::OnCreateAngel );
	ON_MSG( PACKETTYPE_ANGELBUFF, &CDPSrvr::OnAngleBuff );
#endif //__CSC_VER8_5
	
#ifdef __EVE_MINIGAME
	ON_MSG( PACKETTYPE_KAWIBAWIBO_START, &CDPSrvr::OnKawibawiboStart );
	ON_MSG( PACKETTYPE_KAWIBAWIBO_GETITEM, &CDPSrvr::OnKawibawiboGetItem );
	ON_MSG( PACKETTYPE_REASSEMBLE_START, &CDPSrvr::OnReassembleStart );
	ON_MSG( PACKETTYPE_REASSEMBLE_OPENWND, &CDPSrvr::OnReassembleOpenWnd );
	ON_MSG( PACKETTYPE_ALPHABET_OPENWND, &CDPSrvr::OnAlphabetOpenWnd );
	ON_MSG( PACKETTYPE_ALPHABET_START, &CDPSrvr::OnAlphabetStart );
	ON_MSG( PACKETTYPE_FIVESYSTEM_OPENWND, &CDPSrvr::OnFiveSystemOpenWnd );
	ON_MSG( PACKETTYPE_FIVESYSTEM_BET, &CDPSrvr::OnFiveSystemBet );
	ON_MSG( PACKETTYPE_FIVESYSTEM_START, &CDPSrvr::OnFiveSystemStart );
	ON_MSG( PACKETTYPE_FIVESYSTEM_DESTROYWND, &CDPSrvr::OnFiveSystemDestroyWnd );
#endif // __EVE_MINIGAME
	
#if __VER >= 9 // __ULTIMATE
	ON_MSG( PACKETTYPE_ULTIMATE_MAKEITEM, &CDPSrvr::OnUltimateMakeItem );
	ON_MSG( PACKETTYPE_ULTIMATE_MAKEGEM, &CDPSrvr::OnUltimateMakeGem );
	ON_MSG( PACKETTYPE_ULTIMATE_TRANSWEAPON, &CDPSrvr::OnUltimateTransWeapon );
	ON_MSG( PACKETTYPE_ULTIMATE_SETGEM, &CDPSrvr::OnUltimateSetGem );
	ON_MSG( PACKETTYPE_ULTIMATE_REMOVEGEM, &CDPSrvr::OnUltimateRemoveGem );
	ON_MSG( PACKETTYPE_ULTIMATE_ENCHANTWEAPON, &CDPSrvr::OnUltimateEnchantWeapon );
#endif // __ULTIMATE

#ifdef __TRADESYS
	ON_MSG( PACKETTYPE_EXCHANGE, &CDPSrvr::OnExchange );
#endif // __TRADESYS

#if __VER >= 9	// __PET_0410
	ON_MSG( PACKETTYPE_PET_RELEASE, &CDPSrvr::OnPetRelease );
	ON_MSG( PACKETTYPE_USE_PET_FEED, &CDPSrvr::OnUsePetFeed );
	ON_MSG( PACKETTYPE_MAKE_PET_FEED, &CDPSrvr::OnMakePetFeed );
	ON_MSG( PACKETTYPE_PET_TAMER_MISTAKE, &CDPSrvr::OnPetTamerMistake );
	ON_MSG( PACKETTYPE_PET_TAMER_MIRACLE, &CDPSrvr::OnPetTamerMiracle );
	ON_MSG( PACKETTYPE_FEED_POCKET_INACTIVE, &CDPSrvr::OnFeedPocketInactive );
#endif	// __PET_0410

#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	ON_MSG( PACKETTYPE_LEGENDSKILLUP_START, &CDPSrvr::OnLegendSkillStart );
#endif	//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

#if __VER >= 9 // __CSC_VER9_2
	ON_MSG( PACKETTYPE_MODIFY_STATUS, &CDPSrvr::OnModifyStatus );
#endif //__CSC_VER9_2

#if __VER >= 11 // __GUILD_COMBAT_1TO1
	ON_MSG( PACKETTYPE_GC1TO1_TENDEROPENWND, &CDPSrvr::OnGC1to1TenderOpenWnd );
	ON_MSG( PACKETTYPE_GC1TO1_TENDERVIEW, &CDPSrvr::OnGC1to1TenderView );
	ON_MSG( PACKETTYPE_GC1TO1_TENDER, &CDPSrvr::OnGC1to1Tender );
	ON_MSG( PACKETTYPE_GC1TO1_TENDERCANCEL, &CDPSrvr::OnGC1to1CancelTender );
	ON_MSG( PACKETTYPE_GC1TO1_TENDERFAILED, &CDPSrvr::OnGC1to1FailedTender );
	ON_MSG( PACKETTYPE_GC1TO1_MEMBERLINEUPOPENWND, &CDPSrvr::OnGC1to1MemberLineUpOpenWnd );
	ON_MSG( PACKETTYPE_GC1TO1_MEMBERLINEUP, &CDPSrvr::OnGC1to1MemberLineUp );
	ON_MSG( PACKETTYPE_GC1TO1_TELEPORTTONPC, &CDPSrvr::OnGC1to1TeleportToNPC );
	ON_MSG( PACKETTYPE_GC1TO1_TELEPORTTOSTAGE, &CDPSrvr::OnGC1to1TeleportToStage );	
#endif // __GUILD_COMBAT_1TO1

#if __VER >= 11 // __MA_VER11_04	// ±æµå Ã¢°í ·Î±× ±â´É world,database,neuz
	ON_MSG( PACKETTYPE_GUILDLOG_VIEW, &CDPSrvr::OnQueryGuildBankLogList );
#endif //__MA_VER11_04	// ±æµå Ã¢°í ·Î±× ±â´É world,database,neuz
#if __VER >= 11 // __MA_VER11_05	// ÄÉ¸¯ÅÍ ºÀÀÎ °Å·¡ ±â´É world,database,neuz
	ON_MSG( PACKETTYPE_SEALCHAR_REQ, &CDPSrvr::OnSealCharReq );
	ON_MSG( PACKETTYPE_SEALCHARCONM_REQ, &CDPSrvr::OnSealCharConmReq );
	ON_MSG( PACKETTYPE_SEALCHARGET_REQ, &CDPSrvr::OnSealCharGetReq );
#endif // __MA_VER11_05	// ÄÉ¸¯ÅÍ ºÀÀÎ °Å·¡ ±â´É world,database,neuz
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
	ON_MSG( PACKETTYPE_HONOR_LIST_REQ, &CDPSrvr::OnHonorListReq );
	ON_MSG( PACKETTYPE_HONOR_CHANGE_REQ, &CDPSrvr::OnHonorChangeReq );
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ

#if __VER >= 11 // __SYS_COLLECTING
	ON_MSG( PACKETTYPE_QUERY_START_COLLECTING, &CDPSrvr::OnQueryStartCollecting );
	ON_MSG( PACKETTYPE_QUERY_STOP_COLLECTING, &CDPSrvr::OnQueryStopCollecting );
#endif	// __SYS_COLLECTING

#ifdef __NPC_BUFF
	ON_MSG( PACKETTYPE_NPC_BUFF, &CDPSrvr::OnNPCBuff );
#endif // __NPC_BUFF

#if __VER >= 12 // __SECRET_ROOM
	ON_MSG( PACKETTYPE_SECRETROOM_TENDEROPENWND, &CDPSrvr::OnSecretRoomTenderOpenWnd );
	ON_MSG( PACKETTYPE_SECRETROOM_TENDER, &CDPSrvr::OnSecretRoomTender );
	ON_MSG( PACKETTYPE_SECRETROOM_TENDERCANCELRETURN, &CDPSrvr::OnSecretRoomTenderCancelReturn );
	ON_MSG( PACKETTYPE_SECRETROOM_LINEUPOPENWND, &CDPSrvr::OnSecretRoomLineUpOpenWnd );
	ON_MSG( PACKETTYPE_SECRETROOM_LINEUPMEMBER, &CDPSrvr::OnSecretRoomLineUpMember );
	ON_MSG( PACKETTYPE_SECRETROOM_ENTRANCE, &CDPSrvr::OnSecretRoomEntrance );
	ON_MSG( PACKETTYPE_SECRETROOM_TELEPORTTONPC, &CDPSrvr::OnSecretRoomTeleportToNPC );
	ON_MSG( PACKETTYPE_SECRETROOM_TENDERVIEW, &CDPSrvr::OnSecretRoomTenderView );
	ON_MSG( PACKETTYPE_SECRETROOM_TELEPORTTODUNGEON, &CDPSrvr::OnTeleportSecretRoomDungeon );
#endif // __SECRET_ROOM

#if __VER >= 12 // __LORD
	ON_MSG( PACKETTYPE_ELECTION_ADD_DEPOSIT, &CDPSrvr::OnElectionAddDeposit );
	ON_MSG( PACKETTYPE_ELECTION_SET_PLEDGE, &CDPSrvr::OnElectionSetPledge );
	ON_MSG( PACKETTYPE_ELECTION_INC_VOTE, &CDPSrvr::OnElectionIncVote );
	ON_MSG( PACKETTYPE_L_EVENT_CREATE, &CDPSrvr::OnLEventCreate );
	ON_MSG( PACKETTYPE_LORD_SKILL_USE, &CDPSrvr::OnLordSkillUse );
#endif	// __LORD
#if __VER >= 12 // __PET_0519
	// ¾Ëº¯È¯ ÇÚµé·¯
	ON_MSG( PACKETTYPE_TRANSFORM_ITEM, &CDPSrvr::OnTransformItem );
#endif	// __PET_0519

#if __VER >= 12 // __TAX
	ON_MSG( PACKETTYPE_TAX_SET_TAXRATE, &CDPSrvr::OnSetTaxRate );
#endif // __TAX

#if __VER >= 12 // __HEAVEN_TOWER
	ON_MSG( PACKETTYPE_HEAVENTOWER_TELEPORT, &CDPSrvr::OnTeleportToHeavenTower );
#endif // __HEAVEN_TOWER

#if __VER >= 12 // __MOD_TUTORIAL
	ON_MSG( PACKETTYPE_TUTORIAL_STATE, &CDPSrvr::OnTutorialState );
#endif	// __MOD_TUTORIAL

#if __VER >= 12 // __PET_0519
	ON_MSG( PACKETTYPE_PICKUP_PET_AWAKENING_CANCEL, &CDPSrvr::OnPickupPetAwakeningCancel );
#endif	// __PET_0519

#if __VER >= 12 // __UPDATE_OPT
	ON_MSG( PACKETTYPE_OPTION_ENABLE_RENDER_MASK, &CDPSrvr::OnOptionEnableRenderMask );
#endif	// __UPDATE_OPT

#if __VER >= 13 // __RAINBOW_RACE
	ON_MSG( PACKETTYPE_RAINBOWRACE_PREVRANKING_OPENWND, &CDPSrvr::OnRainbowRacePrevRankingOpenWnd );
	ON_MSG( PACKETTYPE_RAINBOWRACE_APPLICATION_OPENWND, &CDPSrvr::OnRainbowRaceApplicationOpenWnd );
	ON_MSG( PACKETTYPE_RAINBOWRACE_APPLICATION, &CDPSrvr::OnRainbowRaceApplication );
	ON_MSG( PACKETTYPE_RAINBOWRACE_MINIGAME_PACKET, &CDPSrvr::OnRainbowRaceMiniGamePacket );
	ON_MSG( PACKETTYPE_RAINBOWRACE_REQ_FINISH, &CDPSrvr::OnRainbowRaceReqFinish );
#endif // __RAINBOW_RACE

#if __VER >= 13 // __HOUSING
	ON_MSG( PACKETTYPE_HOUSING_SETUPFURNITURE, &CDPSrvr::OnHousingSetupFurniture );
	ON_MSG( PACKETTYPE_HOUSING_SETVISITALLOW, &CDPSrvr::OnHousingSetVisitAllow );
	ON_MSG( PACKETTYPE_HOUSING_VISITROOM, &CDPSrvr::OnHousingVisitRoom );
	ON_MSG( PACKETTYPE_HOUSING_REQVISITABLELIST, &CDPSrvr::OnHousingVisitableList );
	ON_MSG( PACKETTYPE_HOUSING_GOOUT, &CDPSrvr::OnHousingGoOut );

#endif // __HOUSING

#if __VER >= 13 // __QUEST_HELPER
	ON_MSG( PACKETTYPE_QUESTHELPER_REQNPCPOS, &CDPSrvr::OnReqQuestNPCPos );
#endif // __QUEST_HELPER

#if __VER >= 13 // __COUPLE_1117
	ON_MSG( PACKETTYPE_PROPOSE, &CDPSrvr::OnPropose );
	ON_MSG( PACKETTYPE_REFUSE, &CDPSrvr::OnRefuse );
	ON_MSG( PACKETTYPE_COUPLE, &CDPSrvr::OnCouple );
	ON_MSG( PACKETTYPE_DECOUPLE, &CDPSrvr::OnDecouple );
#endif	// __COUPLE_1117
#ifdef __MAP_SECURITY
	ON_MSG( PACKETTYPE_MAP_KEY, &CDPSrvr::OnMapKey );
#endif // __MAP_SECURITY
#ifdef __QUIZ
	ON_MSG( PACKETTYPE_QUIZ_ENTRANCE, &CDPSrvr::OnQuizEventEntrance );
	ON_MSG( PACKETTYPE_QUIZ_TELEPORT, &CDPSrvr::OnQuizEventTeleport );
#endif // __QUIZ
#if __VER >= 15 // __PETVIS
	ON_MSG( PACKETTYPE_VISPET_REMOVEVIS, &CDPSrvr::OnRemoveVis );
	ON_MSG( PACKETTYPE_VISPET_SWAPVIS, &CDPSrvr::OnSwapVis );
#endif // __PETVIS
#if __VER >= 15 // __GUILD_HOUSE
	ON_MSG( PACKETTYPE_GUILDHOUSE_BUY, &CDPSrvr::OnBuyGuildHouse );
	ON_MSG( PACKETTYPE_GUILDHOUSE_PACKET, &CDPSrvr::OnGuildHousePacket );
	ON_MSG( PACKETTYPE_GUILDHOUSE_ENTER, &CDPSrvr::OnGuildHouseEnter );
	ON_MSG( PACKETTYPE_GUILDHOUSE_GOOUT, &CDPSrvr::OnGuildHouseGoOut );
#endif // __GUILD_HOUSE
#if __VER >= 15 // __TELEPORTER
	ON_MSG( PACKETTYPE_TELEPORTER, &CDPSrvr::OnTeleporterReq );
#endif // __TELEPORTER
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
	ON_MSG( PACKETTYPE_QUEST_CHECK, &CDPSrvr::OnCheckedQuest );
#endif // __IMPROVE_QUEST_INTERFACE
#if __VER >= 15 // __CAMPUS
	ON_MSG( PACKETTYPE_CAMPUS_INVITE, &CDPSrvr::OnInviteCampusMember );
	ON_MSG( PACKETTYPE_CAMPUS_ACCEPT, &CDPSrvr::OnAcceptCampusMember );
	ON_MSG( PACKETTYPE_CAMPUS_REFUSE, &CDPSrvr::OnRefuseCampusMember );
	ON_MSG( PACKETTYPE_CAMPUS_REMOVE_MEMBER, &CDPSrvr::OnRemoveCampusMember );
#endif // __CAMPUS


	//	mulcom	BEGIN100405	°¢¼º º¸È£ÀÇ µÎ·ç¸¶¸®
	ON_MSG( PACKETTYPE_ITEM_SELECT_AWAKENING_VALUE, &CDPSrvr::OnItemSelectAwakeningValue );
	//	mulcom	END100405	°¢¼º º¸È£ÀÇ µÎ·ç¸¶¸®

#ifdef __GUILD_HOUSE_MIDDLE
	ON_MSG( PACKETTYPE_GUILDHOUSE_TENDER_MAINWND, &CDPSrvr::OnGuildHouseTenderMainWnd );
	ON_MSG( PACKETTYPE_GUILDHOUSE_TENDER_INFOWND, &CDPSrvr::OnGuildHouseTenderInfoWnd );
	ON_MSG( PACKETTYPE_GUILDHOUSE_TENDER_JOIN, &CDPSrvr::OnGuildHouseTenderJoin );
#endif // __GUILD_HOUSE_MIDDLE

#ifdef	__COLOSSEUM
	ON_MSG( PACKETTYPE_COLOSSEUM, &CDPSrvr::OnColosseum );
#endif //__COLOSSEUM

#ifdef __NEW_ITEM_VARUNA
	ON_MSG( PACKETTYPE_BARUNA, &CDPSrvr::OnBaruna );
#endif //__NEW_ITEM_VARUNA

#ifdef __SHOPPING_CART
	ON_MSG(PACKETTYPE_BUYITEMCART, &CDPSrvr::OnBuyItemCart);
#endif // __SHOPPING_CART

#ifdef __HIDE_COAT
	ON_MSG(PACKETTYPE_HIDE_COAT, &CDPSrvr::OnHideCoat);
#endif // __HIDE_COAT

#ifdef __TREASUREBOX
	ON_MSG(PACKETTYPE_OPENBOX, &CDPSrvr::OnTreasureBoxOpen);
#endif
#ifdef __RECYCLE
	ON_MSG(PACKETTYPE_SEND_RECYCLE_PARURE, &CDPSrvr::OnSendRecycleParure);
	ON_MSG(PACKETTYPE_SEND_RECYCLE_FAMILLIER, &CDPSrvr::OnSendRecycleFamillier);
	ON_MSG(PACKETTYPE_SEND_RECYCLE_CAPE, &CDPSrvr::OnSendRecycleCape);
#endif // __RECYCLE
#ifdef __RANDOMOPTION_RETRY
	ON_MSG(PACKETTYPE_RANDOMOPTIONRETRY, &CDPSrvr::OnRandomOptionRetry);
#endif
#ifdef __MARKET_TELEPORT_V19
	ON_MSG(PACKETTYPE_TELEPORT, &CDPSrvr::OnConsignmentTeleport);
#endif // __MARKET_TELEPORT_V19
#ifdef __FASHION_COMBINE
	ON_MSG( PACKETTYPE_COMBINE_FASHION, &CDPSrvr::OnFashionCombine );
#endif //__FASHION_COMBINE
#ifdef __ITEMLINK
	ON_MSG( PACKETTYPE_ITEMLINK, &CDPSrvr::OnItemLink );
#endif
#ifdef __LOOKCHANGE
	ON_MSG( PACKETTYPE_LOOKCHANGE, &CDPSrvr::OnLookChange );
#endif
#ifdef __NEW_TASKBAR_V19
	ON_MSG(PACKETTYPE_SCROLLTASKBAR, &CDPSrvr::OnScrollTaskBar);
#endif // __NEW_TASKBAR_V19
#ifdef __NEW_CHANGE_JOB
	ON_MSG(PACKETTYPE_SEND_JOB_CHANGE, &CDPSrvr::OnSendJobChange);
#endif // __NEW_CHANGE_JOB
#ifdef __REMOVE_SKILL_BUFF
	ON_MSG(PACKETTYPE_REMOVE_SKILL_BUFF, &CDPSrvr::OnSendRemoveSkillBuff);
#endif // __REMOVE_SKILL_BUFF
#ifdef __MODS_MANAGER
	ON_MSG(PACKETTYPE_SEND_MODS_MANAGER, &CDPSrvr::OnSendModsManager);
#endif // __MODS_MANAGER
#ifdef __BAG_LOOT
	ON_MSG(PACKETTYPE_SELECTED_BAG, &CDPSrvr::OnSelectedBag)
#endif
#ifdef MULTIPLE_ITEM_PICKER
	ON_MSG(PACKETTYPE_MULTIPLE_ITEM_PICKER, &CDPSrvr::OnSendMultipleItemPicker);
#endif // MULTIPLE_ITEM_PICKER
#ifdef __WEAPON_RARITY
	ON_MSG(PACKETTYPE_WEAPON_RARITY, &CDPSrvr::OnUpdateWeaponRarity);
#endif // __WEAPON_RARITY
#ifdef __ITEM_CONVERTER
	ON_MSG(PACKETTYPE_GETITEM, &CDPSrvr::OnGetItem);
#endif // __ITEM_CONVERTER
#ifdef __PET_FILTER
	ON_MSG(PACKETTYPE_PETFILTER, &CDPSrvr::OnSetPetfilter);
#endif // __PET_FILTER
#ifdef __APP_TELEPORTER
	ON_MSG(PACKETTYPE_TELE16, &CDPSrvr::OnTeleport);
#endif // __APP_TELEPORTER
#ifdef __GUILD_BUFF
	ON_MSG(PACKETTYPE_BUFF_GUILD, &CDPSrvr::OnBuffGuildByAPP);
#endif// __GUILD_BUFF
#ifdef __AUTO_PERIN_CONVERTER
	ON_MSG(PACKETTYPE_AUTO_PERIN_CONVERTER, &CDPSrvr::OnConvertPerin)
#endif // __AUTO_PERIN_CONVERTER
#ifdef __PARTY_FIND
	ON_MSG(PACKETTYPE_JOIN_PARTY_REQ, &CDPSrvr::OnPartyList);
	ON_MSG(PACKETTYPE_PARTYALLOWJOIN, &CDPSrvr::OnPartyAllowJoin);
#endif // __PARTY_FIND
#ifdef __UPGRADE
	ON_MSG(PACKETTYPE_SEND_UPGRADE, &CDPSrvr::OnUpgrade);
#endif // __UPGRADE
#ifdef __PLAYERS_MENU
	ON_MSG(PACKETTYPE_SEND_PLAYER, &CDPSrvr::OnSendPlayer);
#endif // __PLAYERS_MENU
#ifdef __PLAYER_LIST
	ON_MSG(PACKETTYPE_PLAYER_LIST_SEND_REQUEST, &CDPSrvr::OnPlayerListRequest);
	ON_MSG(PACKETTYPE_PLAYER_LIST_UPDATE_MODS, &CDPSrvr::OnPlayerListUpdateMods);
#endif // __PLAYER_LIST
#ifdef __MOUNT
	ON_MSG(PACKETTYPE_UPDATE_MOUNT, &CDPSrvr::OnMountChange);
#endif // __MOUNT
#ifdef __BATTLEPASS
	ON_MSG(PACKETTYPE_BP_UPDATE, &CDPSrvr::OnDoBP);
#endif // __BATTLEPASS
#ifdef __AWAKE_WINDOW
	ON_MSG(PACKETTYPE_SEND_AWAKE_WINDOW, &CDPSrvr::OnSendAwakeWindow);
#endif // __AWAKE_WINDOW
#ifdef	__REMOVE_CMM
	ON_MSG(PACKETTYPE_REMOVE_CMM, &CDPSrvr::OnRemoveCmm);
#endif	// __REMOVE_CMM
#ifdef	__MALEVOLENT_CP
	ON_MSG(PACKETTYPE_BUFFBYBUTTON, &CDPSrvr::OnBuffbyButton);
#endif
#ifdef __NAME_COLOR
	ON_MSG(PACKETTYPE_NAME_COL, &CDPSrvr::OnNameCol);
#ifdef __NAME_FONT
	ON_MSG(PACKETTYPE_NAME_FONT, &CDPSrvr::OnNameFont);
#endif // __NAME_FONT
#endif // __NAME_COLOR
#ifdef __QUICK_SELL
	ON_MSG(PACKETTYPE_QUICKSELL, &CDPSrvr::OnQuickSell);
#endif // __QUICK_SELL
#ifdef __RESIZE_CHARACTER
	ON_MSG(PACKETTYPE_RESIZE_CHARACTER, &CDPSrvr::OnResizeChar);
#endif // __RESIZE_CHARACTER
#ifdef __USER_OWN_TITLE
	ON_MSG(PACKETTYPE_CREATE_OWN_TITLE, &CDPSrvr::OnCreateOwnTitle);
#endif // __USER_OWN_TITLE
#ifdef __ADVANCED_ANNOUNCEMENT
	ON_MSG(PACKETTYPE_SENDAEGONSYSTEMSHOUT, &CDPSrvr::OnAegonSystemShout);
#endif // __ADVANCED_ANNOUNCEMENT
#ifdef __WIKI_ITEMS_V2
	ON_MSG(PACKETTYPE_WIKI_CREATE, &CDPSrvr::OnWikiCreate);
#endif
#ifdef __SYS_WORLDBOSS
	ON_MSG(PACKETTYPE_REGISTER_HWID, &CDPSrvr::OnRegisterHWID);
#endif //__SYS_WORLDBOSS
#ifdef __AUTO_STATS
	ON_MSG(PACKETTYPE_UPDATE_AUTO_STATS, &CDPSrvr::OnUpdateAutoStats);
#endif
#ifdef __DEATH_MATCH
	ON_MSG(PACKETTYPE_PLAYERWAR_JOIN, &CDPSrvr::OnPlayerSiegeJoin);
	ON_MSG(PACKETTYPE_PLAYERWAR_RANKING, &CDPSrvr::OnGetSiegeRanking);
#endif // __DEATH_MATCH
#ifdef __WRITING_SAY
	ON_MSG(PACKETTYPE_SENDWRITINGCHAT, &CDPSrvr::OnWritingSay);
#endif
#ifdef __MONSTER_CLASH
	ON_MSG(PACKETTYPE_MONSTERCLASH_TENDEROPENWND, &CDPSrvr::OnMonsterClashTenderOpenWnd);
	ON_MSG(PACKETTYPE_MONSTERCLASH_TENDER, &CDPSrvr::OnMonsterClashTender);
	ON_MSG(PACKETTYPE_MONSTERCLASH_TENDERCANCELRETURN, &CDPSrvr::OnMonsterClashTenderCancelReturn);
	ON_MSG(PACKETTYPE_MONSTERCLASH_LINEUPOPENWND, &CDPSrvr::OnMonsterClashLineUpOpenWnd);
	ON_MSG(PACKETTYPE_MONSTERCLASH_LINEUPMEMBER, &CDPSrvr::OnMonsterClashLineUpMember);
	ON_MSG(PACKETTYPE_MONSTERCLASH_ENTRANCE, &CDPSrvr::OnMonsterClashEntrance);
	ON_MSG(PACKETTYPE_MONSTERCLASH_TELEPORTTONPC, &CDPSrvr::OnMonsterClashTeleportToNPC);
	ON_MSG(PACKETTYPE_MONSTERCLASH_TENDERVIEW, &CDPSrvr::OnMonsterClashTenderView);
#endif // __MONSTER_CLASH
#ifdef __BADGE
	ON_MSG(PACKETTYPE_BADGE_CHANGE, &CDPSrvr::OnChangeBadgeIcon);
#endif //__BADGE
#ifdef __RECORD_BOOK
	ON_MSG(PACKETTYPE_RECORD_BOOK, &CDPSrvr::OnRecordBook);
#endif
#ifdef __WHEEL_OF_FORTUNE
	ON_MSG(PACKETTYPE_WOF_INIT, &CDPSrvr::OnWofInit);
	ON_MSG(PACKETTYPE_WOF_FINISH, &CDPSrvr::OnWofFinish);
#endif
}

CDPSrvr::~CDPSrvr()
{
	m_dpidCache = DPID_UNKNOWN;			// Ä³½¬¼­¹ö DPID
}

void CDPSrvr::SysMessageHandler( LPDPMSG_GENERIC lpMsg, DWORD dwMsgSize, DPID idFrom )
{
	switch( lpMsg->dwType )
	{
		case DPSYS_CREATEPLAYERORGROUP:
			{
				LPDPMSG_CREATEPLAYERORGROUP lpCreatePlayer	= (LPDPMSG_CREATEPLAYERORGROUP)lpMsg;
				OnAddConnection( lpCreatePlayer->dpId );
				break;
			}
		case DPSYS_DESTROYPLAYERORGROUP:
			{
				LPDPMSG_DESTROYPLAYERORGROUP lpDestroyPlayer	= (LPDPMSG_DESTROYPLAYERORGROUP)lpMsg;
				OnRemoveConnection( lpDestroyPlayer->dpId );
				break;
			}
	}
}

void CDPSrvr::UserMessageHandler( LPDPMSG_GENERIC lpMsg, DWORD dwMsgSize, DPID idFrom )
{
	LPBYTE lpBuffer		= (LPBYTE)lpMsg + sizeof(DPID);
	u_long uBufSize		= dwMsgSize - sizeof(DPID);

	CAr ar( lpBuffer, uBufSize );
	GETTYPE( ar )

	CUser* pUser = g_UserMng.GetUser(idFrom, *(UNALIGNED LPDPID)lpMsg);
	if (pUser && !pUser->IsValid())
		return;

	void ( theClass::*pfn )( theParameters )	=	GetHandler( dw );

	if( pfn ) 
	{
		( this->*( pfn ) )( ar, idFrom, *(UNALIGNED LPDPID)lpMsg, lpBuffer, uBufSize );
	}

}

void CDPSrvr::OnAddConnection( DPID dpid )
{
}

void CDPSrvr::OnRemoveConnection( DPID dpid )
{
	// ½ÇÁ¦ Ä³½¬ ¼­¹ö°¡ ºÙÀ» °æ¿ìµµ ÀÖ°í, Å×½ºÆ® ¿ëÀ¸·Î telnetÀÌ ºÙÀ» °æ¿ìµµ ÀÖ´Ù.
	// Ä³½¬¼­¹ö¿Í ¿¬°áÀÌ ²÷±â¸é, Ä³½¬ ¼­¹ö¿Í ¿¬°èµÈ À¯ÀúµéÀ» ²÷¾î¾ß ÇÑ´Ù.
	// À§ 2°¡Áö¸¦ °í·ÁÇØ¼­, À¯Àú°¡ µî·ÏµÈ ¿¬°á¸¸À» ½ÇÁ¦ Ä³½¬¼­¹ö·Î °£ÁÖÇÏ°í
	// µî·ÏÇÏ°Ô ÇÑ´Ù.
	if( dpid == m_dpidCache )
	{
		g_UserMng.RemoveAllUsers();		
		m_dpidCache = DPID_UNKNOWN;	
	}
}

void CDPSrvr::OnAddUser( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	m_dpidCache = dpidCache;			// Ä³½¬¼­¹öÀÇ DPID¸¦ º¸°üÇÑ´Ù.

	TCHAR	lpszAccount[MAX_ACCOUNT], lpszpw[MAX_PASSWORD], lpAddr[16];
	DWORD	dwAuthKey;
	u_long	idPlayer;
	BYTE	nSlot;
	DPID	dpidSocket;

	ar >> dwAuthKey >> idPlayer >> nSlot;
	ar >> dpidSocket;
	ar.ReadString( lpszAccount, MAX_ACCOUNT );
	ar.ReadString( lpszpw, MAX_PASSWORD );
	ar.ReadString( lpAddr, 16 );

#ifdef __GAMEGUARD
	if (nSlot > 2 || nSlot < 0)
#else // __GAMEGUARD
	if (nSlot >= 3)
#endif // __GAMEGUARD
	{
		return;
	}

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if( pUser )
	{
		//WriteLog( "CDPSrvr::OnAddUser idPlayer:%d account:%s DPID:%d", idPlayer, lpszAccount, dpidUser );
		// Ä³½¬¼­¹ö¿¡´Â socket¹øÈ£¸¦ º¸³»¾ß ÇÑ´Ù. ( pUser->m_Snapshot.dpidUser´Â ¼ÒÄÏ¹øÈ£ )
		QueryDestroyPlayer( pUser->m_Snapshot.dpidCache, pUser->m_Snapshot.dpidUser, pUser->m_dwSerial, pUser->m_idPlayer ); // pUser->m_Snapshot.dpidUser¿¡´Â ¼ÒÄÏ¹øÈ£°¡ µé¾î°¡ ÀÖ´Ù.
		QueryDestroyPlayer( dpidCache, dpidSocket, dpidUser, idPlayer );	
		return;
	}

	pUser = g_UserMng.AddUser( dpidCache, dpidUser, dpidSocket );
	if( pUser == NULL )
		return;

	pUser->m_dwAuthKey = dwAuthKey;
	memcpy( pUser->m_playAccount.lpAddr, lpAddr, 16 );

	//	TRANS
	BEFORESENDDUAL( arJoin, PACKETTYPE_JOIN, dpidCache, dpidUser );
	arJoin << dwAuthKey;
	arJoin.WriteString( lpszAccount );
	arJoin.WriteString( lpszpw );
	arJoin << nSlot << idPlayer;
	SEND( arJoin, &g_dpDBClient, DPID_SERVERPLAYER );
}


void CDPSrvr::OnRemoveUser( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
#ifdef __CONSOLE
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		CONSOLE(pUser->GetName(), prj.GetText(TID_CONSOLE_02));
	}
#endif // __CONSOLE
	g_UserMng.RemoveUser((DWORD)dpidUser); // dpidUser´Â CACHE¿¡¼­ »ç¿ëµÇ´Â serialÇÑ °ª 
}

void CDPSrvr::OnChat( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	static	TCHAR	sChat[1024];
	if( uBufSize > 1031 )	// 4 + 4 + 1024 - 1		= 1031
		return;

	ar.ReadString( sChat, 1024 );
	CString strChat	= sChat;
	strChat.Replace( "\\n", " " );
	
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
	{
#ifdef __GAMEMASTER
		if (pUser->m_dwAuthorization >= AUTH_HELPER)
#else // __GAMEMASTER
		if (pUser->m_dwAuthorization >= AUTH_LOGCHATTING)		// ÀÏ¹ÝÀ¯Àú°¡ ¾Æ´Ï¸é ·Î±×³²±è ¸ðµç ·Î±×³²±è
#endif // __GAMEMASTER
		{
			g_dpDBClient.SendLogGamemaChat( pUser, strChat );
		}

		if (sChat[0] == '/' && ParsingCommand(strChat, (CMover*)pUser))
		{
#ifdef __GAMEGUARD
			CString str[2];
			str[0].Format("%s", sChat);
			str[1].Format("..\\Program\\Logs\\Player\\%s.txt", pUser->GetName());
			GameGuardLog(str[0], str[1], 0);
#endif // __GAMEGUARD
#ifdef __CONSOLE
			CONSOLE(pUser->GetName(), sChat);
#endif // __CONSOLE
			return;
		}
		if( pUser->IsMode( TALK_MODE ) )
			return;
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bChat == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bChat == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
#ifdef __JEFF_9_20
#if __VER >= 12 // __LORD
		int nText	= pUser->GetMuteText();
		if(  nText )
		{
			pUser->AddDefinedText( nText );
			return;
		}
#else	// __LORD
		if( pUser->IsMute() )
			return;
#endif	// __LORD
#endif	// __JEFF_9_20

		if( !( pUser->HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_FONTEDIT ) ) )
		{
//			strChat		= sChat;
//			strChat.Replace( "\\n", " " );
			ParsingEffect( sChat, strlen(sChat) );
		}
		strChat	= sChat;
		strChat.Replace( "\\n", " " );
#ifdef __GAMEGUARD
		CString str[2];
		str[0].Format("%s", strChat);
		str[1].Format("..\\Program\\Logs\\Player\\%s.txt", pUser->GetName());
		GameGuardLog(str[0], str[1], 0);
#endif // __GAMEGUARD
#ifdef __CONSOLE
		CONSOLE(pUser->GetName(), strChat);
#endif // __CONSOLE
//		RemoveCRLF( sChat );

	
		g_UserMng.AddChat( pUser, strChat );
	}
}

void CDPSrvr::OnCtrlCoolTimeCancel( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser;
	CCommonCtrl* pCtrl;
	pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;
	
	((CMover*)pUser)->m_dwCtrlReadyTime = 0xffffffff;

	pCtrl = (CCommonCtrl*)prj.GetCtrl( ((CMover*)pUser)->m_dwCtrlReadyId );
	if( IsValidObj( pCtrl ) == FALSE )
		return;

	((CMover*)pUser)->m_dwCtrlReadyId = NULL_ID;

	pCtrl->m_dwCtrlReadyTime = 0xffffffff;
	pCtrl->m_bAction         = FALSE;
}

void CDPSrvr::OnDoEquip( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD nId;
	int nPart;

	ar >> nId;
	ar >> nPart;		
	
	if( nPart >= MAX_HUMAN_PARTS )	
		return;

	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) == FALSE )
		return;

#ifdef __GAMEGUARD
	if (pUser->GetHitPoint() > pUser->GetMaxHitPoint())
		pUser->SetHitPoint(pUser->GetMaxHitPoint());

	if (pUser->GetManaPoint() > pUser->GetMaxManaPoint())
		pUser->SetManaPoint(pUser->GetMaxManaPoint());

	if (pUser->GetFatiguePoint() > pUser->GetMaxFatiguePoint())
		pUser->SetFatiguePoint(pUser->GetMaxFatiguePoint());
#endif __GAMEGUARD

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId( nId );
	if( IsUsableItem( pItemElem ) == FALSE )
			return;
	if( nPart > 0 )
	{
		if( pUser->m_Inventory.IsEquip( nId ) )
		{
			if( pItemElem != pUser->m_Inventory.GetEquip( nPart ) )
				return;
		}
	}
	else
	{
		if( pUser->m_Inventory.IsEquip( nId ) )
			return;
	}
#ifdef __HACK_1023
	ItemProp* pItemProp		= pItemElem->GetProp();
	if( pItemProp && pItemProp->dwParts == PARTS_RIDE )
	{
		if( !pUser->m_Inventory.IsEquip( nId ) )
		{
			FLOAT fVal;
			ar >> fVal;
			if( fVal != pItemProp->fFlightSpeed )
			{
				pUser->AddDefinedText( TID_GAME_MODIFY_FLIGHT_SPEED );
				return;
			}
		}
	}
#endif	// __HACK_1023

#ifdef __WEAPON_RARITY
	if (!prj.CheckWeaponRarity(pItemElem->GetWeaponRarity()))
	{
		Error("%s : pItemElem->GetWeaponRarity() returns %d !", pUser->GetName(), pItemElem->GetWeaponRarity());

		int nRarity = pItemElem->GetWeaponRarity() > prj.m_nHighWeaponRarityLevel ? prj.m_nHighWeaponRarityLevel : 0;
		pItemElem->SetWeaponRarity(nRarity);
		pUser->AddWeaponRarity(pItemElem->m_dwObjId, nRarity);
		return;
	}
#endif // __WEAPON_RARITY

	if( pUser->IsDie() == FALSE )
		pUser->DoUseEquipmentItem( pItemElem, nId, nPart );
}

void CDPSrvr::OnMoveItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE nItemType, nSrcIndex, nDstIndex;
	ar >> nItemType >> nSrcIndex >> nDstIndex;

	if( nSrcIndex == nDstIndex )
		return;
	if( nDstIndex >= MAX_INVENTORY || nSrcIndex >= MAX_INVENTORY )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) == FALSE )
		return;

	CItemElem* pItemSrc = pUser->m_Inventory.GetAt( nSrcIndex );
	CItemElem* pItemDst = pUser->m_Inventory.GetAt( nDstIndex );
	if( pItemDst == NULL || IsUsableItem( pItemDst ) ) // ºó °ø°£ or °Å·¡ÁßÀÌÁö ¾Ê´Â ¾ÆÀÌÅÛ ?			
	{	
		if( IsUsableItem( pItemSrc ) )					// °Å·¡ÁßÀÌÁö ¾Ê´Â ¾ÆÀÌÅÛ ?
		{
			pUser->m_Inventory.Swap( nSrcIndex, nDstIndex );
			pUser->AddMoveItem( 0, nSrcIndex, nDstIndex );
		}
	}
}

void CDPSrvr::OnDropItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwItemType;
	DWORD dwItemId;
	short nDropNum;
	D3DXVECTOR3 vPos;

	ar >> dwItemType >> dwItemId >> nDropNum >> vPos;

	if( nDropNum <= 0 )
		return;

	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj(pUser) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		if( g_eLocal.GetState( EVE_DROPITEMREMOVE ) )
		{
			CItemElem* pItemElem	= (CItemElem*)pUser->GetItemId( dwItemId );
			if( IsUsableItem( pItemElem ) && pUser->IsDropable( pItemElem, FALSE ) )
				pUser->RemoveItem( (BYTE)dwItemId, nDropNum );
		}
		else
		{
			pUser->DropItem( (DWORD)dwItemId, nDropNum, vPos );
		}
	}
}

void CDPSrvr::OnDropGold( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{

#if __VER >= 8  	//8Â÷°ÔÀÓ³»µ·µå·Ó±ÝÁö

	return;

#else	//  __VER >= 8  

	DWORD dwGold;
	D3DXVECTOR3 vPos;
	ar >> dwGold >> vPos;

	BOOL bLimit = FALSE;
	if( dwGold > 30000 )	// 3¸¸ Æä³Ä ÀÌ»óÀº ¶¥¿¡ ¶³¾î¶ß¸± ¼ö ¾ø½À´Ï´Ù. 
	{
		dwGold = 30000;
		bLimit = TRUE;
	}

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText(prj.GetText(TID_WORLDSRVR_GAME_02), 0xFFFF0000);
			return;
		}
#endif // __WORLDSERVER_MENU
		if( g_eLocal.GetState( EVE_DROPITEMREMOVE ) )
		{
			if( pUser->GetGold() >= (int)dwGold )	// raiders.2006.11.28
				pUser->AddGold( -dwGold );
		}
		else
		{
			if( pUser->DropGold( dwGold, vPos ) != NULL && bLimit )
				pUser->AddDefinedText( TID_GAME_LIMITMONEY, "" );
		}
	}

#endif	//	  __VER >= 8  

}


void CDPSrvr::OnReplace( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	ASSERT( 0 );
	Error("CDPSrvr::OnReplace called\n");
}

void CDPSrvr::OnScriptDialogReq( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	static TCHAR lpKey[256];
	OBJID objid;
	int nGlobal1, nGlobal2, nGlobal3, nGlobal4;

	ar >> objid;
 	ar.ReadString( lpKey, 256 );

	ar >> nGlobal1 >> nGlobal2 >> nGlobal3 >> nGlobal4;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __QUEST_1208
		DWORD dwTickCount	= GetTickCount();
		if( dwTickCount < pUser->m_tickScript + 400 )
			return;
		pUser->m_tickScript	= dwTickCount;
#endif	// __QUEST_1208
		CMover* pMover	= prj.GetMover( objid );
		if( IsValidObj( pMover ) )
		{
#ifdef __HACK_1130
			char lpOutputString[512]	= { 0,};
			sprintf( lpOutputString, "npc = %s, key = %s, n1 = %d, n2 = %d, n3 = %d, n4 = %d",
				pMover->GetName(), lpKey, nGlobal1, nGlobal2, nGlobal3, nGlobal4 );
			OutputDebugString( lpOutputString );
#endif	// __HACK_1130

			D3DXVECTOR3 vOut	= pUser->GetPos() - pMover->GetPos();
			if( fabs( (double)D3DXVec3LengthSq( &vOut ) ) > MAX_LEN_MOVER_MENU )
			{
				return;
			}
		#if !defined(__REMOVE_SCIRPT_060712)
			CScriptDialog::SetLatestDialog( pMover->GetName(), lpKey );
		#endif
			if( pMover->m_pNpcProperty &&
				pMover->m_pNpcProperty->IsDialogLoaded() )
			{
				if( lstrlen( lpKey ) == 0 )
					lstrcpy( lpKey, _T( "#init" ) );
				if( nGlobal3 == 0 )	
					nGlobal3 = (int)pMover->GetId();
				if( nGlobal4 == 0 )	
					nGlobal4 = (int)pUser->GetId();

				pMover->m_pNpcProperty->RunDialog( lpKey, NULL, nGlobal1, (int)pMover->GetId(), (int)pUser->GetId(), nGlobal2 );

				// Äù½ºÆ® Á¶°Ç ´ëÈ­¿¡ ¸Â´Â Å°ÀÏ °æ¿ì´Â ´ëÈ­ ¼º°ø ÇÃ·ºÀ» ¼¼ÆÃÇÏ°í Äù½ºÆ® Á¤º¸¸¦ Å¬¶óÀÌ¾ðÆ®¿¡ º¸³»ÁØ´Ù.
				for( int i = 0; i < pUser->m_nQuestSize; i++ )
				{
					LPQUEST lpQuest = &pUser->m_aQuest[ i ];
					QuestProp* pQuestProp = pUser->m_aQuest[ i ].GetProp();
					if( pQuestProp )
					{
						if( strcmp( pQuestProp->m_szEndCondDlgCharKey, pMover->m_szCharacterKey ) == 0 )
						{
							if( strcmp( pQuestProp->m_szEndCondDlgAddKey, lpKey ) == 0 )
							{
								lpQuest->m_bDialog = TRUE;
								pUser->AddSetQuest( lpQuest );
								break;
							}
						}
					}
				}
			}
		}
	}
}

void CDPSrvr::OnRevival( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CWorld* pWorld;
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) && ( pWorld = pUser->GetWorld() ) )
	{
		pUser->m_Resurrection_Data.bUseing = FALSE;

		if( pUser->IsDie() == FALSE )
		{
			Error( "OnRevival\t// %s is not dead", pUser->GetName() );
			return;
		}
		
		BOOL bGuildCombat = FALSE;

		CItemElem* pItemElem = pUser->m_Inventory.GetAtItemId( II_SYS_SYS_SCR_RESURRECTION );
		if( IsUsableItem( pItemElem ) )
		{
			pUser->m_nDead = PROCESS_COUNT * 5;		// Á×Àº ÈÄ 5ÃÊ°£Àº ¹«Àû

#if __VER >= 8 // __S8_PK
			if( pUser->IsChaotic() )
			{
				pUser->SubDieDecExp( TRUE, 0, TRUE );		// Á×¾î¼­ ºÎÈ°ÇÏ¸é °âÄ¡ ±ðÀÓ,.
			}
			else
			{
#if __VER < 12 // __ANGEL_NODIE
				if( !pUser->m_bLastPK && !pUser->m_bGuildCombat )
					pUser->RemoveAngel();
#endif // __ANGEL_NODIE
			}
#endif // __VER >= 8 // __S8_PK
			float fRate = 0.1f;

#if __VER >= 9 // __S_9_ADD
			fRate = 0.2f;
#else // __S_9_ADD
			int nLevel	= pUser->GetLevel();
			if( nLevel == 1 )		{ fRate	= 0.8f; }
			else if( nLevel == 2 )	{ fRate	= 0.6f; }
			else if( nLevel <= 5 )	{ fRate	= 0.5f; }
			else if( nLevel <= 10 )	{ fRate	= 0.4f; }
			else if( nLevel <= 15 )	{ fRate	= 0.3f; }
#endif // __S_9_ADD

			pUser->m_pActMover->ClearState();

			if( pWorld->GetID() == WI_WORLD_GUILDWAR )
				fRate = 1.0f;
#ifdef __DEATH_MATCH
			if (pWorld->GetID() == WI_WORLD_DEATH_MATCH)
				fRate = 1.0f;
#endif // __DEATH_MATCH
#if __VER < 9 // __S_9_ADD	// ¾Æ·¡¿¡¼­ Ã¤¿öÁÖ°í ÆÐÅ¶±îÁö º¸³»¹ö¸®´Â °ÍÀ¸·Î ¼öÁ¤
			pUser->SetHitPoint( (int)(pUser->GetMaxHitPoint() * fRate) );	// hp È¸º¹

			int nVal	= (int)(pUser->GetMaxManaPoint() * fRate);			// mp È¸º¹
			if( pUser->GetManaPoint() < nVal )
				pUser->SetManaPoint( nVal );
			
			nVal	= (int)(pUser->GetMaxFatiguePoint() * fRate);			// fp È¸º¹
			if( pUser->GetFatiguePoint() < nVal )
				pUser->SetFatiguePoint( nVal );
#endif // __S_9_ADD

			if( pWorld->GetID() == WI_WORLD_GUILDWAR )
			{
				g_UserMng.AddHdr( pUser, SNAPSHOTTYPE_REVIVAL );
				g_GuildCombatMng.JoinObserver( pUser );
			}
#ifdef __DEATH_MATCH
			else if (pWorld->GetID() == WI_WORLD_DEATH_MATCH)
			{
				g_UserMng.AddHdr(pUser, SNAPSHOTTYPE_REVIVAL);
				g_War.TeleportToWaitArea(pUser);
			}
#endif // __DEATH_MATCH
			else
			{
				g_UserMng.AddHdr( pUser, SNAPSHOTTYPE_REVIVAL );

				ItemProp* pItemProp = pItemElem->GetProp();
				if( pItemProp && pItemProp->dwSfxObj3 != -1 )
					g_UserMng.AddCreateSfxObj((CMover *)pUser, pItemElem->GetProp()->dwSfxObj3 );

				// »ó¿ëÈ­ ¾ÆÀÌÅÛ »ç¿ë ·Î±× »ðÀÔ
				g_dpDBClient.SendLogSMItemUse( "1", pUser, pItemElem, pItemProp );
				pUser->RemoveItem( (BYTE)pItemElem->m_dwObjId, 1 );
			}

#if __VER >= 9 // __S_9_ADD
#ifdef __NO_HP_DMG_LIMIT
			pUser->SetPointParam(DST_HP, (__int64)(pUser->GetMaxHitPoint() * fRate));

#else
			pUser->SetPointParam(DST_HP, (int)(pUser->GetMaxHitPoint() * fRate));
#endif
					
			int nVal	= (int)(pUser->GetMaxManaPoint() * fRate);			// mp È¸º¹
			if( pUser->GetManaPoint() < nVal )
				pUser->SetPointParam( DST_MP, nVal );
			
			nVal	= (int)(pUser->GetMaxFatiguePoint() * fRate);			// fp È¸º¹
			if( pUser->GetFatiguePoint() < nVal )
				pUser->SetPointParam( DST_FP, nVal );			
#endif // __S_9_ADD
		}
		else
		{
			Error( "Error CMover::OnRevival Not Inventory RevivalItem" );
		}
	}
}

void CDPSrvr::OnRevivalLodestar( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CWorld* pWorld;
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) && ( pWorld = pUser->GetWorld() ) )
	{
		pUser->m_Resurrection_Data.bUseing = FALSE;

		if( pUser->IsDie() == FALSE )
		{
			// ÀÌ¸®·Î µé¾î¿À´Â °æ¿ì°¡ »ý±ä´Ù. »ý°¢¿£ ÀÌ¹Ì ÇÑ¹ø ¿©±æ µé¾î¿Ô´Ù°¡ ·º °É¸°µ¿¾È 
			// ·Îµå½ºÅ¸¸¦ ¶Ç ´©¸£¸é µé¾î¿À´Â°Ô ¾Æ´Ñ°¡ ½Í´Ù.
			return;
		}

		CCommonCtrl* pCtrl	= CreateExpBox( pUser );
		if( pCtrl )
		{
			pCtrl->AddItToGlobalId();
			pWorld->ADDOBJ( pCtrl, FALSE, pUser->GetLayer() );
			g_dpDBClient.SendLogExpBox( pUser->m_idPlayer, pCtrl->GetId(), pCtrl->m_nExpBox );
		}
		
		BOOL bGuildCombat = FALSE;
		
		g_dpDBClient.SendLogLevelUp( (CMover*)pUser, 9 );	// ·Îµå½ºÅ¸·Î ºÎÈ° ·Î±×

		pUser->m_nDead = PROCESS_COUNT * 5;		// Á×Àº ÈÄ 5ÃÊ°£Àº ¹«Àû
		float fRate		= pUser->SubDieDecExp();		// Á×¾î¼­ ºÎÈ°ÇÏ¸é °âÄ¡ ±ðÀÓ,.
		pUser->m_pActMover->ClearState();

		if( pWorld->GetID() == WI_WORLD_GUILDWAR )
			fRate = 1.0f;
#ifdef __DEATH_MATCH
		if (pWorld->GetID() == WI_WORLD_DEATH_MATCH)
			fRate = 1.0f;
#endif // __DEATH_MATCH
#if __VER >= 11 // __GUILD_COMBAT_1TO1
		else if( g_GuildCombat1to1Mng.IsPossibleUser( pUser ) )
			fRate = 1.0f;
#endif // __GUILD_COMBAT_1TO1
#if __VER >= 9 // __S_9_ADD
		else
			fRate = 0.2f;
#endif // __S_9_ADD
		
#if __VER < 9 // __S_9_ADD	// ¾Æ·¡¿¡¼­ Ã¤¿öÁÖ°í ÆÐÅ¶±îÁö º¸³»¹ö¸®´Â °ÍÀ¸·Î ¼öÁ¤
#ifdef __NO_HP_DMG_LIMIT
		pUser->SetHitPoint((__int64)(pUser->GetMaxHitPoint() * fRate));

#else
		pUser->SetHitPoint((int)(pUser->GetMaxHitPoint() * fRate));	// hp +ê-+-¦-¦
#endif
		
		int nVal	= (int)(pUser->GetMaxManaPoint() * fRate);			// mp È¸º¹
		if( pUser->GetManaPoint() < nVal )
			pUser->SetManaPoint( nVal );
		
		nVal	= (int)(pUser->GetMaxFatiguePoint() * fRate);			// fp È¸º¹
		if( pUser->GetFatiguePoint() < nVal )
			pUser->SetFatiguePoint( nVal );
#endif // __S_9_ADD

		if( pWorld->GetID() == WI_WORLD_GUILDWAR )
		{
			g_UserMng.AddHdr( pUser, SNAPSHOTTYPE_REVIVAL );
			g_GuildCombatMng.JoinObserver( pUser );
		}
#ifdef __DEATH_MATCH
		else if (pWorld->GetID() == WI_WORLD_DEATH_MATCH)
		{
			g_UserMng.AddHdr(pUser, SNAPSHOTTYPE_REVIVAL);
			g_War.TeleportToWaitArea(pUser);
		}
#endif // __DEATH_MATCH
		else
		{
			g_UserMng.AddHdr( pUser, SNAPSHOTTYPE_REVIVAL_TO_LODESTAR );
		}		

#if __VER >= 9 // __S_9_ADD
#ifdef __NO_HP_DMG_LIMIT
		pUser->SetPointParam(DST_HP, (__int64)(pUser->GetMaxHitPoint() * fRate));

#else
		pUser->SetPointParam(DST_HP, (int)(pUser->GetMaxHitPoint() * fRate));
#endif
		
		int nVal	= (int)(pUser->GetMaxManaPoint() * fRate);			// mp È¸º¹
		//if( pUser->GetManaPoint() < nVal )
			pUser->SetPointParam( DST_MP, nVal );
		
		nVal	= (int)(pUser->GetMaxFatiguePoint() * fRate);			// fp È¸º¹
		//if( pUser->GetFatiguePoint() < nVal )
			pUser->SetPointParam( DST_FP, nVal );
#endif // __S_9_ADD

		if( pWorld->GetID() == WI_WORLD_GUILDWAR )
			return;
#ifdef __DEATH_MATCH
		if (pWorld->GetID() == WI_WORLD_DEATH_MATCH)
			return;
#endif // __DEATH_MATCH
#if __VER >= 12 // __SECRET_ROOM
		if( CSecretRoomMng::GetInstance()->IsInTheSecretRoom( pUser ) )
		{
			pUser->REPLACE( g_uIdofMulti, WI_WORLD_MADRIGAL, CSecretRoomMng::GetInstance()->GetRevivalPos( pUser ), REPLACE_NORMAL, nDefaultLayer );
			return;
		}
#endif // __SECRET_ROOM
		
		// º¸½º¸÷ ¸Ê¿¡¼­ Á×¾ú´Ù...
		// ±×·¯¸é ºÎÈ°Àº ¸¶À»¿¡¼­...
		if( pWorld->GetID() == WI_DUNGEON_MUSCLE || pWorld->GetID() == WI_DUNGEON_KRRR || pWorld->GetID() == WI_DUNGEON_BEAR )
		{			
			pUser->REPLACE( g_uIdofMulti, WI_WORLD_MADRIGAL, D3DXVECTOR3( 6968.0f, 0.0f, 3328.8f ), REPLACE_NORMAL, nDefaultLayer );
			return;
		}

		PRegionElem	pRgnElem	= NULL;
		if( pUser->IsChaotic()
#ifdef __JEFF_11_4
			&& !pWorld->IsArena()
#endif	// __JEFF_11_4
			)
		{
#if __VER >= 8 // __S8_PK
			if( pWorld->GetID() != pWorld->m_dwIdWorldRevival && pWorld->m_dwIdWorldRevival != 0 )
				pRgnElem	= g_WorldMng.GetRevivalPosChao( pWorld->m_dwIdWorldRevival, pWorld->m_szKeyRevival );
			if( NULL == pRgnElem )	// Find near revival pos
				pRgnElem	= g_WorldMng.GetNearRevivalPosChao( pWorld->GetID(), pUser->GetPos() );	
#else // __VER >= 8 // __S8_PK
			pRgnElem	= g_WorldMng.GetNearRevivalPosChao( pWorld->GetID(), pUser->GetPos() );
#endif // __VER >= 8 // __S8_PK
		}
		else
		{
			if( pWorld->GetID() != pWorld->m_dwIdWorldRevival && pWorld->m_dwIdWorldRevival != 0 )
				pRgnElem	= g_WorldMng.GetRevivalPos( pWorld->m_dwIdWorldRevival, pWorld->m_szKeyRevival );
			
			if( NULL == pRgnElem )	// Find near revival pos
				pRgnElem	= g_WorldMng.GetNearRevivalPos( pWorld->GetID(), pUser->GetPos() );	
		}

		if( pRgnElem ) 
			pUser->REPLACE( g_uIdofMulti, pRgnElem->m_dwWorldId, pRgnElem->m_vPos, REPLACE_FORCE, nRevivalLayer );
		else 
			pUser->REPLACE( g_uIdofMulti, pWorld->GetID(), pUser->GetPos(), REPLACE_FORCE, pUser->GetLayer() );
	}
}

void CDPSrvr::OnRevivalLodelight( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
}

void CDPSrvr::OnSetLodelight( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_MARKING, pUser->GetWorld(), pUser->GetPos() ) )
			return;
		pUser->SetMarkingPos();
		pUser->AddDefinedText( TID_GAME_LODELIGHT, "" );
	}
}

void CDPSrvr::OnIncStatLevel( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CHAR chID;
	ar >> chID;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		long nValue;
		
		switch( chID )
		{
			case 100:	
				pUser->IncStrLevel();
				nValue	= pUser->m_nStr;
				break;
			case 101:
				pUser->IncStaLevel();
				nValue	= pUser->m_nSta;
				break;
			case 102:
				pUser->IncDexLevel();
				nValue	= pUser->m_nDex;
				break;
			case 103:
				pUser->IncIntLevel();
				nValue	= pUser->m_nInt;
				break;
			default:
				return;			
		}
//		pUser->AddSetStatLevel( chID, nValue, pUser->m_nRemainGP );
		g_UserMng.AddSetStateLevel( pUser, chID, nValue );
		g_dpDBClient.SendLogLevelUp( pUser, 2 );
	}
}

void CDPSrvr::OnCorrReq( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID idObj;
	ar >> idObj;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );		// ¾î´ÀÀ¯Àú·ÎºÎÅÍ ³¯¾Æ¿Â°Å³Ä.
	if( IsValidObj( pUser ) )
	{
		CMover *pMover = prj.GetMover( idObj );	// ¼±ÅÃµÈ ¿ÀºêÁ§Æ®ÀÇ Æ÷ÀÎÅÍ
		if( IsValidObj( pMover ) )
		{
			pUser->AddCorrReq( pMover );	// ¿äÃ»ÇÑ Å¬¶ó¿¡°Ô ¼±ÅÃµÈ ¿ÀºêÁ§Æ®ÀÇ Á¤º¸¸¦ º¸³¿.
		}
	}
}

void CDPSrvr::OnCreateGuildCloak( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	if( g_eLocal.GetState( ENABLE_GUILD_INVENTORY ) == FALSE )		
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );		// ¾î´ÀÀ¯Àú·ÎºÎÅÍ ³¯¾Æ¿Â°Å³Ä.
	if( IsValidObj( pUser ) )
	{
		CGuild *pGuild = pUser->GetGuild();
		if( pGuild == NULL )
			return;
		if( pGuild->m_dwLogo == 0 ||							//  ·Î°í°¡ ÁöÁ¤µÇ¾î ÀÖÁö ¾Ê°Å³ª
			pGuild->IsMaster( pUser->m_idPlayer ) == FALSE )	// ¸¶½ºÅÍ°¡ ¾Æ´Ï°Å³ª
		{
			if( pGuild->m_dwLogo == 0 )
			{
				// ·Î±×°¡ ÁöÁ¤µÇÁö ¾Ê¾Æ¼­ ¸ø¸¸µë
				pUser->AddDefinedText( TID_GAME_GUILDSETTINGLOGO, "" );
			}
			else
			{
				// ¸¶½ºÅÍ°¡ ¾Æ´Ï¹Ç·Î ¸¸µé¼ö°¡ ¾øÀ½.
				pUser->AddDefinedText( TID_GAME_GUILDONLYMASTERLOGO, "" );
			}
			return;
		}

		// ±æµåÃ¢°í°¡ ¸ÁÅä¸¦ ³ÖÀ» °ø°£ÀÌ ÃæºÐÇÑÁö Ã¼Å©ÇÑ´Ù. ¹°·Ð ±æµå ¸ÁÅä¸¦ ±æµå Ã¢°í¿¡ ³ÖÀ»¶§ÀÌ´Ù. ¾Æ´Ï¶ó¸é ÁÖ¼®Ã³¸® ÇØÁÖ¼¼¿ë
		if ( MAX_BANK <= pGuild->m_GuildBank.GetCount() )
		{
			pUser->AddDefinedText( TID_GAME_GUILDBANKFULL, "" );		// ±æµåÃ¢°í°¡ ²ËÃ¡½ÃÀ¯~
			return;
		}

		if ( pGuild->m_nGoldGuild >= 10000 )	 // ±æµåÃ¢°í¿¡ µ·ÀÌ ÃæºÐÇÏ³Ä?
		{
			pGuild->m_nGoldGuild -= 10000;

			// ±æµåÃ¢°í¿¡¼­ µ· ÁöºÒÇÏ°í, ±æµå ¸ÁÅä¸¦ ±æµåÃ¢°í¿¡ »ý¼º½ÃÅ´.
//			BYTE nId;
			CItemElem itemElem;
			if( pGuild->m_dwLogo == 999 )	// Ä¿½ºÅÒ ·Î°í·Î ¼³Á¤µÇ¾î ÀÖÀ»¶§.
				itemElem.m_dwItemId	= II_ARM_S_CLO_CLO_BLANK;		// Ä¿½ºÅÒ¿ë ¹ÎÂ¥ ¸ÁÅä»ý¼º.
			else
			{
				if(pUser->IsAuthHigher(AUTH_GAMEMASTER) && pGuild->m_dwLogo > CUSTOM_LOGO_MAX - 7) // GM Guild Logo»ç¿ë ½Ã ÀÓÀÇ·Î ¸ÁÅä »ý¼º
					itemElem.m_dwItemId	= II_ARM_S_CLO_CLO_SYSCLOAK01;
				else
					itemElem.m_dwItemId	= II_ARM_S_CLO_CLO_SYSCLOAK01 + (pGuild->m_dwLogo - 1);
			}
			itemElem.m_nItemNum		= 1;
			// ±æµå ¾ÆÀÌµð¸¦ ¸ÁÅä¿¡ ¹ÚÀ½. Å¬¶ó¿¡¼± ¼ýÀÚ¸¦ ±â¹ÝÀ¸·Î Ä¿½ºÅÒ ¸ÁÅä¸¦ ÀÐ´Â´Ù.
			// Ä¿½ºÅÒ ¸ÁÅä°¡ ¾Æ´Ñ°æ¿ì´Â ÀÌ¹øÈ£·Î ±æµåÀÌ¸§À» º¸¿©ÁØ´Ù.
			itemElem.m_idGuild	= pGuild->m_idGuild;			
			

			// a. ¿äÃ»ÇÑ Å¬¶ó¿¡°Ô ±æµåÃ¢°í Æä³Ä°¡ ¼Ò¸ðµÇ¾úÀ½À» ¾Ë¸°´Ù.
			// b. ÇöÀç °°Àº ¼­¹ö¿¡ ÀÖ´Â °°Àº ±æµå¿øÀÎ Å¬¶óÀÌ¾ðÆ®¿¡°Ô Æä³Ä°¡ ¼Ò¸ðµÇ¾úÀ½À» ¾Ë¸°´Ù.
			// c. ´Ù¸¥ ¸ÖÆ¼¼­¹ö¼Â¿¡ ÀÖ´Â °°Àº ±æµå¿øÀÎ Å¬¶óÀÌ¾ðÆ®¿¡°Ô Æä³Ä°¡ ¼Ò¸ðµÇ¾úÀ»À» ¾Ë¸°´Ù.
			itemElem.SetSerialNumber();
			ItemProp* pItemProp		= itemElem.GetProp();
			if( pItemProp )
				itemElem.m_nHitPoint	= pItemProp->dwEndurance;
			else
				itemElem.m_nHitPoint	= 0;

			pUser->AddPutItemGuildBank( &itemElem );
			pGuild->m_GuildBank.Add( &itemElem );
			g_UserMng.AddPutItemElem( pUser, &itemElem );
						
			// ÀÚ½ÅÀÇ ±æµå¿øµéÀÇ ·çÇÁ¸¦ µ¹¸é¼­ ±æµå¸ÁÅä¸¦ »ç¼­ 10000Æä³Ä°¡ ¼Ò¸ðµÇ¾ú´Ù°í ¾Ë·ÁÁØ´Ù.
			// ¹°·Ð ·çÇÁ¿¡¼­ ¿äÃ»ÇÑ Å¬¶óÀÌ¾ðÆ®¿¡°Ôµµ ¸Þ½ÃÁö¸¦ ÇÔ²² º¸³½´Ù.
			CGuildMember*	pMember;
			CUser*			pUsertmp;
			CGuild*			pGuild = pUser->GetGuild();
			for( map<u_long, CGuildMember*>::iterator i = pGuild->m_mapPMember.begin();
			i != pGuild->m_mapPMember.end(); ++i )
			{
				pMember		= i->second;
				pUsertmp	= (CUser*)prj.GetUserByID( pMember->m_idPlayer );
				if( IsValidObj( pUsertmp ) )
				{
					pUsertmp->AddGetGoldGuildBank( 10000, 2, pMember->m_idPlayer, 1 );	// 2´Â ¾÷µ¥ÀÌÆ® ÇØ¾ßÇÒ Å¬¶óÀÌ°Ô
				}
			}
			// Çö ¸ÖÆ¼¼Â ¼­¹ö¿¡´Â À§ ·çÆ¾ÀÌ ¸ðµÎ 10000Æä³Ä°¡ ¼Ò¸ðµÊÀ» ¾Ë·ÈÀ¸¹Ç·Î DPCoreClient·Î Ä³½Ã¼­¹ö¿¡ ¿äÃ»ÇÏ¿© 
			// ¸ðµç ¸ÖÆ¼¼Â¿¡ 10000Æä³Ä°¡ ¼Ò¸ðµÇ¾ú´Ù°í ¾Ë¸°´Ù. ¹°·Ð º¸³»´Â ÀÌ ¸ÖÆ¼¼Â ¼­¹ö´Â ÀÌ ¸Þ½ÃÁö¸¦ ¹«½ÃÇØ¾ß ÇÑ´Ù. ( ¹«½ÃÇÏ°Ô ÇØ³ùÁö¸¸ Àß µÉ·±Áö -_- )
			g_DPCoreClient.SendGuildMsgControl_Bank_Penya( pUser, 10000, 2, 1 ); 	// 2´Â ¾÷µ¥ÀÌÆ® ÇØ¾ßÇÒ ´Ù¸¥ ¿ùµå¼­¹öÀÇ Å¬¶óÀÌ¾ðÆ®
			UpdateGuildBank(pGuild, GUILD_CLOAK, 0, pUser->m_idPlayer, &itemElem, 10000, 1 ); // 0Àº ±æµå Æä³Ä¸¦ ¾÷µ¥ÀÌÆ® ÇÑ´Ù´Â °ÍÀÌ´Ù.(½ÇÀº ¸ðµç°ÍÀ» ¾÷µ¥ÀÌÆ®ÇÏÁö¸¸ -_-)
			pUser->AddDefinedText( TID_GAME_GUILDCREATECLOAK, "" );
		} 
		else
		{
			pUser->AddDefinedText( TID_GAME_GUILDNEEDGOLD, "" );		// ±æµåÃ¢°í¿¡ µ·ÀÌ ¾ö¶º!
		}
	}
}

void CDPSrvr::OnQueryGetDestObj( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objid;
	ar >> objid;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CMover* pMover	= prj.GetMover( objid );
		if( IsValidObj( pMover ) && !pMover->IsEmptyDestObj() )
			pUser->AddGetDestObj( objid, pMover->GetDestId(), pMover->m_fArrivalRange );
	}
}

void CDPSrvr::OnGetDestObj( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objid, objidDest;
	ar >> objid >> objidDest;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
		pUser->SetDestObj( objidDest );
/*
	{
		if( NULL_ID == objid )
		{
			pUser->SetDestObj( objidDest );
		}
		else
		{
			CUser* ptr	= prj.GetUser( objid );
			if( IsValidObj( ptr ) )
				ptr->AddGetDestObj( pUser->GetId(), objidDest, ptr->m_fArrivalRange );
		}
	}
*/
}

void CDPSrvr::OnQueryGetPos( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objid;
	ar >> objid;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CMover* pMover	= prj.GetMover( objid );
		if( IsValidObj( pMover ) )
		{
			if( FALSE == pMover->IsPlayer() )
			{
				pUser->AddGetPos( objid, pMover->GetPos(), pMover->GetAngle() );
			}
			else
			{
				( (CUser*)pMover )->AddQueryGetPos( pUser->GetId() );
			}
		}
	}
}

void CDPSrvr::OnGetPos( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	D3DXVECTOR3 vPos;
	float fAngle;
	OBJID objid;
	ar >> vPos >> fAngle >> objid;
	
	if( _isnan((double)fAngle) )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		D3DXVECTOR3 vDistance	= pUser->GetPos() - vPos;
		if( D3DXVec3LengthSq( &vDistance ) > 1000000.0F )
		{
//			Error( "PACKETTYPE_GETPOS" );
			return;
		}

		if( NULL_ID == objid )
		{
			pUser->SetPos( vPos );
			pUser->SetAngle( fAngle );
			
			pUser->m_fWaitQueryGetPos	= FALSE;
			
			if( FALSE == pUser->IsEmptyDestPos() )
				pUser->SetDestPos( pUser->GetDestPos(), pUser->m_bForward, FALSE );
		}
		else
		{
			CUser* ptr	= prj.GetUser( objid );
			if( IsValidObj( ptr ) )
				ptr->AddGetPos( pUser->GetId(), vPos, fAngle );
		}
	}
}

void CDPSrvr::OnPartyRequest( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long uLeaderid, uMemberid;
	BOOL bTroup;
	ar >> uLeaderid >> uMemberid;
	ar >> bTroup;

	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) && pUser->m_idPlayer == uLeaderid )
		InviteParty( uLeaderid, uMemberid, bTroup );
}

void CDPSrvr::OnPartyRequestCancle( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long uLeaderid, uMemberid;
	int nMode;
	ar >> uLeaderid >> uMemberid >> nMode;

	CUser* pUser = g_UserMng.GetUserByPlayerID( uLeaderid );
	if( IsValidObj( pUser ) )
		pUser->AddPartyRequestCancel( uLeaderid, uMemberid, nMode );
}

void CDPSrvr::OnPartySkillUse( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long uLeaderid;
	int nSkill;
	ar >> uLeaderid >> nSkill;	

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsInvalidObj( pUser ) )		
		return;
	
	CParty* pParty	= g_PartyMng.GetParty( pUser->m_idparty );
	if( pParty )
	{
#ifdef __FL_PARTY_ASSISTANTS_V2
		int nHueta = pParty->FindMember(pUser->m_idPlayer);
		//Error("Before use skill this user is %d", pParty->m_aMember[nHueta].bAssistParty);
		if (pParty->IsLeader(pUser->m_idPlayer) || pParty->m_aMember[nHueta].bAssistParty == TRUE)
		{
			pParty->DoUsePartySkill(pUser->m_idparty, pUser->m_idPlayer, nSkill);
		}
#else //
		if (pParty->IsLeader(pUser->m_idPlayer))
			pParty->DoUsePartySkill(pUser->m_idparty, pUser->m_idPlayer, nSkill);
#endif //
	}
}

void CDPSrvr::OnAddFriendReqest( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long uLeaderid, uMemberid;
	ar >> uLeaderid >> uMemberid;
	
	CUser* pLeader	= g_UserMng.GetUserByPlayerID( uLeaderid );
	CUser* pMember	= g_UserMng.GetUserByPlayerID( uMemberid );
	if( IsValidObj( pMember ) && IsValidObj( pLeader ) )
	{

#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
		if( 0 < pLeader->m_nDuel ||  0 < pMember->m_nDuel )
		{
			return;
		}
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma

		// ±æµå´ëÀüÀå¿¡´Â Ä£±¸Ãß°¡¸¦ ÇÒ¼ö ¾ø½À´Ï´Ù
		CWorld* pWorldLeader = pLeader->GetWorld();
		CWorld* pWorldMember = pMember->GetWorld();
		if( ( pWorldLeader && pWorldLeader->GetID() == WI_WORLD_GUILDWAR ) ||
			( pWorldMember && pWorldMember->GetID() == WI_WORLD_GUILDWAR ) )
		{			
			pLeader->AddText( prj.GetText(TID_GAME_GUILDCOMBAT_CANNOT_FRIENDADD) );
			return;
		}
#if __VER >= 11 // __GUILD_COMBAT_1TO1
		if( g_GuildCombat1to1Mng.IsPossibleUser( pLeader ) || g_GuildCombat1to1Mng.IsPossibleUser( pMember ) )
		{
			pLeader->AddText( prj.GetText(TID_GAME_GUILDCOMBAT_CANNOT_FRIENDADD) );
			return;
		}
#endif // __GUILD_COMBAT_1TO1

#ifdef __RT_1025
		if( !pLeader->m_RTMessenger.GetFriend( uMemberid ) )
#else	// __RT_1025
		if( FALSE == pLeader->m_Messenger.IsFriend( uMemberid ) )
#endif	// __RT_1025
		{
			if( pMember->IsAttackMode() )
				pLeader->AddDefinedText( TID_GAME_BATTLE_NOTFRIEND, "" );
			else
				pMember->AddFriendReqest( uLeaderid, pLeader->m_nJob, (BYTE)pLeader->GetSex(), pLeader->GetName() );	// Ä£±¸ µî·Ï ¿©ºÎ ÁúÀÇ
		}
	}
}

// ´Ù¸¥ ¸ÖÆ¼¼­¹ö¿¡ ÀÖ´Â Ä³¸¯À» Ãß°¡ ½ÃÅ°·Á¸é ÄÚ¾î·Î º¸³»¾ß ÇÑ´Ù.
// ÀÌ¸§À¸·Î ¿À¹Ç·Î ¿ùµå¿¡¼­ idPlayer·Î ¹Ù²ã¼­ º¸³¿
void CDPSrvr::OnAddFriendNameReqest( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
#ifdef __GAMEGUARD
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
#endif // __GAMEGUARD
	{
		u_long uLeaderid, uMember;
		char szMemberName[64] = {0,};

		ar >> uLeaderid;
		ar.ReadString( szMemberName, 64 );

#ifdef __GAMEGUARD
		if (pUser->m_idPlayer != uLeaderid)
		{
			Error("CDPSrvr::OnAddFriendNameReqest : pUser->m_idPlayer == %d - uLeaderid == %d", pUser->GetId(), uLeaderid);
			return;
		}
		if (prj.IsInvalidName(szMemberName) || !prj.IsAllowedLetter(szMemberName) || strlen(szMemberName) > MAX_NAME || strcmp(szMemberName, pUser->GetName()) == 0)
		{
			Error("CDPSrvr::OnAddFriendNameReqest : pUser->m_idPlayer == %d - uLeaderid == %d - szMemberName == %s", pUser->GetId(), uLeaderid, szMemberName);
			return;
		}
#endif // __GAMEGUARD
#if __VER >= 11 // __SYS_PLAYER_DATA
		uMember	= CPlayerDataCenter::GetInstance()->GetPlayerId( szMemberName );
#else	// __SYS_PLAYER_DATA
		uMember = prj.GetPlayerID( szMemberName );
#endif	// __SYS_PLAYER_DATA
		CUser* pLeader	= g_UserMng.GetUserByPlayerID( uLeaderid );	

		if (IsValidObj(pLeader))
		{
			if (uMember > 0)
			{
#ifdef __RT_1025
				if (!pLeader->m_RTMessenger.GetFriend(uMember))
#else	// __RT_1025
				if (pLeader->m_Messenger.IsFriend(uMember) == FALSE)
#endif	// __RT_1025
					g_DPCoreClient.SendAddFriendNameReqest(uLeaderid, pLeader->m_nJob, (BYTE)pLeader->GetSex(), uMember, pLeader->GetName(), szMemberName);
				else
					pLeader->AddFriendError(1, szMemberName);
			}
			else
			{
				// ÀÌ ÀÌ¸§À» °¡Áö°í ÀÕ´Â Ä³¸¯Àº ¾øÀ½.
				pLeader->AddFriendError(2, szMemberName);
			}
		}
	}
}


void CDPSrvr::OnAddFriendCancel( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long uLeaderid, uMemberid;
	ar >> uLeaderid >> uMemberid;

	CUser* pLeader = g_UserMng.GetUserByPlayerID( uLeaderid );
	if( IsValidObj( pLeader ) )
		pLeader->AddFriendCancel();	// uMemberid
}

void CDPSrvr::OnActionPoint(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nAP;
	ar >> nAP;

	if (nAP < 0)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		pUser->m_playTaskBar.m_nActionPoint = nAP;
	}
}

void CDPSrvr::OnRemoveQuest( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwQuestCancelID;
	ar >> dwQuestCancelID;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __QUEST_1208
		DWORD dwTickCount	= GetTickCount();
		if( dwTickCount < pUser->m_tickScript + 400 )
			return;
		pUser->m_tickScript	= dwTickCount;
#endif	// __QUEST_1208
		LPQUEST lpQuest = pUser->GetQuest( dwQuestCancelID );
		if( lpQuest )
		{
			if( lpQuest->m_nState != QS_END )
			{
				QuestProp* pQuestProp	= prj.m_aPropQuest.GetAt( lpQuest->m_wId );
				if( pQuestProp && pQuestProp->m_bNoRemove == FALSE )
				{
					pUser->RemoveQuest( dwQuestCancelID );
					pUser->AddCancelQuest( dwQuestCancelID );
					g_dpDBClient.CalluspLoggingQuest( pUser->m_idPlayer, dwQuestCancelID, 30 );
					// ½ÃÀÛ½Ã º¯½ÅÀ» ÇßÀ¸¸é Äù½ºÆ® »èÁ¦½Ã º¯½Å ÇØÁ¦½ÃÅ²´Ù.
					if( pQuestProp->m_nBeginSetDisguiseMoverIndex )
					{
						pUser->NoDisguise();
						g_UserMng.AddNoDisguise( pUser );
					}
				}
			}
		}
	}
}

#if __VER >= 11 // __SYS_PLAYER_DATA
void CDPSrvr::OnQueryPlayerData( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long idPlayer;
	ar >> idPlayer;
	int nVer;
	ar >> nVer;
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		PlayerData* pPlayerData	= CPlayerDataCenter::GetInstance()->GetPlayerData( idPlayer );
		if( pPlayerData && pPlayerData->data.nVer != nVer )
			pUser->AddQueryPlayerData( idPlayer, pPlayerData );
	}
}

void CDPSrvr::OnQueryPlayerData2( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	int nSize;
//	u_long idPlayer;
	ar >> nSize;

	if( nSize > 1024 )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		for( int i = 0; i < nSize; i++ )
		{
			PDVer	pdv;
			ar.Read( &pdv, sizeof(PDVer) );
			PlayerData* pPlayerData		= CPlayerDataCenter::GetInstance()->GetPlayerData( pdv.idPlayer );
			if( pPlayerData && pPlayerData->data.nVer != pdv.nVer )
				pUser->AddQueryPlayerData( pdv.idPlayer, pPlayerData );
		}
	}
}
#else	// __SYS_PLAYER_DATA
void CDPSrvr::OnQueryPlayerString( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long idPlayer;
	BYTE nQuery;
	ar >> idPlayer >> nQuery;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		LPCSTR lpszPlayer	= prj.GetPlayerString( idPlayer );
		if( lpszPlayer )
			pUser->AddQueryPlayerString( idPlayer, lpszPlayer, nQuery );
	}
}

void CDPSrvr::OnQueryPlayerListString( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	int nSize;
	u_long idPlayer;
	BYTE nQuery;
	ar >> nSize >> nQuery;

	if( nSize > 1024 )
		return;
		
	CUser* pUser;

	pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) )
	{
		for( int i=0; i<nSize; i++ )
		{
			ar >> idPlayer;
			
			LPCSTR lpszPlayer	= prj.GetPlayerString( idPlayer );
			if( lpszPlayer )
			{
				pUser->AddQueryPlayerString( idPlayer, lpszPlayer, nQuery );
			}
			else
			{
				pUser->AddQueryPlayerString( idPlayer, "Unknown", nQuery );
			}
		}

		if( nSize > 0 )
			pUser->AddQueryPlayerListString( nQuery );
	}
}

void CDPSrvr::OnGetFriendName( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	int nCount;
	ar >> nCount;		
	if( nCount <= 0 || nCount > MAX_FRIEND )
		return;

	FRIEND aFriend[MAX_FRIEND];
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		for( int i = 0 ; i < nCount ; i++ )
		{
			ar >> aFriend[i].dwUserId;
#if __VER >= 11 // __SYS_PLAYER_DATA
//			LPCSTR lpszPlayer	= CPlayerDataCenter::GetInstance()->GetPlayerString( aFriend[i].dwUserId );
#else	// __SYS_PLAYER_DATA
			LPCSTR lpszPlayer	= prj.GetPlayerString( aFriend[i].dwUserId );
			strcpy( aFriend[i].szName, lpszPlayer? lpszPlayer: "" );
#endif	// __SYS_PLAYER_DATA
			
		}
		pUser->AddGetFriendName( nCount, aFriend );
	}
}
#endif	// __SYS_PLAYER_DATA

void CDPSrvr::OnGuildInvite( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objid;
	ar >> objid;
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	InviteCompany( pUser, objid );
}

void CDPSrvr::OnIgnoreGuildInvite( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long idPlayer;
	ar >> idPlayer;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CUser* pPlayer	= g_UserMng.GetUserByPlayerID( idPlayer );		// kingpin
		if( IsValidObj( pPlayer ) )
		{
			pPlayer->AddDefinedText( TID_GAME_COMACCEPTDENY, "%s", pUser->GetName( TRUE ) );
		}
	}
}

// ·Î°í º¯°æ 
void CDPSrvr::OnGuildLogo( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwLogo;
	ar >> dwLogo;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) == FALSE )
		return;

	if( dwLogo > CUSTOM_LOGO_MAX )
		return;

	if( dwLogo > 20 && !pUser->IsAuthHigher( AUTH_GAMEMASTER ) )
		return;

	g_DPCoreClient.SendGuildStat( pUser, GUILD_STAT_LOGO, dwLogo );
}

// °øÇåµµ 
void CDPSrvr::OnGuildContribution( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE cbPxpCount, cbItemFlag;
	int nGold;

	cbItemFlag = 0;
	ar >> cbPxpCount >> nGold;
	ar >> cbItemFlag;

	if( g_eLocal.GetState( ENABLE_GUILD_INVENTORY ) == FALSE )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) == FALSE ) 
		return;

	if( nGold > 0 )
	{
		if( pUser->GetGold() >= nGold ) 
		{
			if( g_DPCoreClient.SendGuildStat( pUser, GUILD_STAT_PENYA, nGold ) )
			{
				pUser->AddGold( -nGold );

				LogItemInfo aLogItem;
				aLogItem.Action = "W";
				aLogItem.SendName = pUser->GetName();
				aLogItem.RecvName = "GUILDBANK";
				aLogItem.WorldId = pUser->GetWorld()->GetID();
				aLogItem.Gold = pUser->GetGold() + nGold;
				aLogItem.Gold2 = pUser->GetGold();
				//aLogItem.ItemName = "SEED";
				_stprintf( aLogItem.szItemName, "%d", II_GOLD_SEED1 );
				aLogItem.itemNumber = nGold;
				OnLogItem( aLogItem );
			}
		} 
		else
		{
			pUser->AddDefinedText( TID_GAME_GUILDNOTENGGOLD, "" );	// ÀÎº¥¿¡ µ·ÀÌºÎÁ·
		}
	}
	else if( cbItemFlag )
	{
		for( int i=0; i< pUser->m_Inventory.GetMax(); ++i )
		{
			CItemElem* pItemElem = pUser->m_Inventory.GetAtId( i );
			if( IsUsableItem( pItemElem ) == FALSE )
				continue;

			if( pItemElem->GetProp()->dwItemKind3 != IK3_GEM )
				continue;

			int nValue = 0;

			if( pItemElem->m_nItemNum > 0 )
			{
				// ¾ÆÀÌÅÛ ·¹º§¿¡ µû¶ó¼­ °øÇåµµ¸¦ ´Ù¸£°Ô ÇÑ´Ù.
				nValue = (pItemElem->GetProp()->dwItemLV + 1) / 2;	
				nValue *= pItemElem->m_nItemNum;					
			}

			if( nValue > 0 )
			{
				if( g_DPCoreClient.SendGuildStat( pUser, GUILD_STAT_PXPCOUNT, nValue ) )
				{
					LogItemInfo aLogItem;
					aLogItem.Action = "V";
					aLogItem.SendName = pUser->GetName();
					aLogItem.RecvName = "GUILDBANK";
					aLogItem.WorldId = pUser->GetWorld()->GetID();
					aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
					OnLogItem( aLogItem, pItemElem, pItemElem->m_nItemNum );
					pUser->RemoveItem( (BYTE)i, pItemElem->m_nItemNum );
				}
			}
		}

	}
}

// °øÁö»çÇ×
void CDPSrvr::OnGuildNotice( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	char szNotice[MAX_BYTE_NOTICE];
	ar.ReadString( szNotice, MAX_BYTE_NOTICE );
	szNotice[MAX_BYTE_NOTICE-1] = '\0';

	if( strlen( szNotice ) == 0 )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) == FALSE )
		return;

	g_DPCoreClient.SendGuildStat( pUser, GUILD_STAT_NOTICE, (DWORD)szNotice );
}

void CDPSrvr::OnDuelRequest( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long uidSrc, uidDst;
	ar >> uidSrc >> uidDst;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	CUser* pDstUser = g_UserMng.GetUserByPlayerID( uidDst );
	if( IsValidObj( pUser ) && IsValidObj( pDstUser ) )
	{
		if( 0 < pUser->m_idparty && pUser->m_idparty == pDstUser->m_idparty )
		{
			pUser->AddDefinedText( TID_PK_PARTY_LIMIT, "" );	// °°ÀºÆÄÆ¼¿ø
			return;
		}

#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
		if( 0 < pUser->m_idparty ||  0 < pDstUser->m_idparty )
			return;
		if( pUser->m_vtInfo.GetOther() )	// °Å·¡Áß ÀÌ¸é µà¾ó ºÒ°¡ 
			return;
		if( pDstUser->m_vtInfo.GetOther() )	// °Å·¡Áß ÀÌ¸é µà¾ó ºÒ°¡ 
			return;
	
		int	nState = pUser->GetSummonState();
		if( nState != 0 )
			return;
		nState = pUser->GetSummonState();
		if( nState != 0 )
			return;

#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma

		if( pUser->IsPVPInspection( pDstUser, 1 ) )
		{
			if( pDstUser->IsMode( PVPCONFIRM_MODE ) )
			{
				pUser->AddDefinedText( TID_PK_MODE_REJECT, "" );	// PVP°ÅÀý ¸ðµåÀÔ´Ï´Ù
			}
			else
			{
#ifdef __HACK_1130
				pUser->m_tmDuelRequest	= GetTickCount();
#endif	// __HACK_1130
				pDstUser->AddDuelRequest( uidSrc, uidDst );
			}
		}
	}
}

// µà¾ó½Â¶ôÀ» ¹ÞÀ½.  µÎÄ³¸¯ÅÍ¿¡°Ô ½ÃÀÛÇÏ¶ó°í º¸³»Áà¾ß ÇÔ.
void CDPSrvr::OnDuelYes( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long uidSrc, uidDst;
	ar >> uidSrc >> uidDst;

	CUser* pSrc = g_UserMng.GetUserByPlayerID( uidSrc );
#ifdef __HACK_1130
	CUser* pDst	=	g_UserMng.GetUser( dpidCache, dpidUser );
#else	// __HACK_1130
	CUser* pDst = g_UserMng.GetUserByPlayerID( uidDst );
#endif	// __HACK_1130

	if( IsValidObj(pSrc) && IsValidObj(pDst) )
	{
		if( 0 < pSrc->m_idparty && pSrc->m_idparty == pDst->m_idparty )
		{
			pSrc->AddDefinedText( TID_PK_PARTY_LIMIT, "" );	// °°ÀºÆÄÆ¼¿ø
			pDst->AddDefinedText( TID_PK_PARTY_LIMIT, "" );	// °°ÀºÆÄÆ¼¿ø
			return;
		}

#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
		if( 0 < pSrc->m_idparty ||  0 < pDst->m_idparty )
		{
			return;
		}
		//°³ÀÎ»óÁ¡ Áß¿¡´Â µà¾ó ºÒ°¡ 
		if( pSrc->m_vtInfo.VendorIsVendor() || pSrc->m_vtInfo.IsVendorOpen() ||
            pDst->m_vtInfo.VendorIsVendor() || pDst->m_vtInfo.IsVendorOpen() )
		{
			return;	//
		}
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma


		if( pSrc->IsPVPInspection( pDst, 1 ) )
		{
#ifdef __HACK_1130
			if( pSrc->m_tmDuelRequest + SEC( 10 ) < GetTickCount() )	// µà¾ó ½ÅÃ» ½Ã°£À» 10ÃÊ ÃÊ°úÇÏ¸é
			{
				pSrc->m_tmDuelRequest	= 0;
				return;
			}
#endif	// __HACK_1130
			pSrc->m_nDuel = 1;
			pSrc->m_nDuelState = 104;
			pSrc->m_idDuelOther = pDst->GetId();
			pDst->m_nDuel = 1;
			pDst->m_nDuelState = 104;
			pDst->m_idDuelOther = pSrc->GetId();
			pSrc->AddDuelStart( uidDst );	// ¼­·Î »ó´ë¹æ¿¡ ´ëÇÑ ¾ÆÀÌµð¸¸ º¸³»ÁÖ¸é µÈ´Ù.
			pDst->AddDuelStart( uidSrc );
			pSrc->m_dwTickEndDuel = ::timeGetTime() + NEXT_TICK_ENDDUEL;
			pDst->m_dwTickEndDuel = ::timeGetTime() + NEXT_TICK_ENDDUEL;
			pSrc->SetPosChanged( TRUE );
			pDst->SetPosChanged( TRUE );
		}
	}
}

// pUser°¡ µà¾ó ½ÅÃ»À» °ÅºÎÇß´Ù. pSrc¿¡°Ô ¾Ë·Á¾ß ÇÑ´Ù.
void CDPSrvr::OnDuelNo( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long uidSrc; //, uidDst;
	ar >> uidSrc;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj(pUser) )
	{
		CUser* pSrc = g_UserMng.GetUserByPlayerID( uidSrc );
		if( IsValidObj(pSrc) )
			pSrc->AddDuelNo( pUser->GetId() );	// pSrc¿¡°Ô pUser°¡ °ÅºÎÇß´Ù´Â°É ¾Ë¸².
	}
}

// ÆÄÆ¼µà¾ó ----------------------------------------------------------------
// Src°¡ Dst¿¡°Ô ÇÑÆÇ ºÙÀÚ°í ½ÅÃ»ÇØ¿Ô´Ù.
void CDPSrvr::OnDuelPartyRequest( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long uidSrc, uidDst;
	ar >> uidSrc >> uidDst;
	
	CUser* pSrcUser	= g_UserMng.GetUser( dpidCache, dpidUser );	// ½ÅÃ»ÀÚ À¯Àú.
	CUser* pDstUser	= g_UserMng.GetUserByPlayerID( uidDst );	// »ó´ë À¯Àú
	if( IsValidObj( pDstUser ) && IsValidObj( pSrcUser ) )
	{
		if( pDstUser->IsMode( PVPCONFIRM_MODE ) )
		{
			pSrcUser->AddDefinedText( TID_PK_MODE_REJECT, "" );	// PVP°ÅÀý ¸ðµåÀÔ´Ï´Ù
		}
		else
		{

			if( pSrcUser->IsPVPInspection( pDstUser, 2 ) )
			{
				CParty* pSrcParty = g_PartyMng.GetParty( pSrcUser->m_idparty );		// ½ÅÃ»ÀÚÀÇ ÆÄÆ¼²¨³¿
				if( pSrcParty == NULL || pSrcParty->IsLeader( pSrcUser->m_idPlayer ) == FALSE )
				{
					pSrcUser->AddDefinedText( TID_PK_NO_IPARTYLEADER, "" );	// ÆÄÆ¼ÀåÀÌ ¾Æ´Õ´Ï´Ù
					return;
				}
				CParty *pDstParty = g_PartyMng.GetParty( pDstUser->m_idparty );		// µµÀü¹Þ´ÂÀÚÀÇ ÆÄÆ¼²¨³¿.
				if( pDstParty == NULL || pDstParty->IsLeader( pDstUser->m_idPlayer ) == FALSE )
				{
					pSrcUser->AddDefinedText( TID_PK_NO_UPARTYLEADER, "" );		// »ó´ë¹æÀÌ ÆÄÆ¼ÀåÀÌ ¾Æ´Õ´Ï´Ù
					return;
				}
				pDstUser->AddDuelPartyRequest( uidSrc, uidDst );
			}
		}

	}
}

// ÆÄÆ¼µà¾ó½Â¶ôÀ» ¹ÞÀ½.  ¸ðµç ¾çÃø ÆÄÆ¼¿øµé¿¡°Ô µà¾óÀÌ ½ÃÀÛµÊÀ» ¾Ë¸².
void CDPSrvr::OnDuelPartyYes( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long uidSrc, uidDst;
	ar >> uidSrc >> uidDst;
	
	CUser* pSrc = g_UserMng.GetUserByPlayerID( uidSrc );	
	CUser* pDst = g_UserMng.GetUserByPlayerID( uidDst );
	if( IsValidObj(pSrc) && IsValidObj(pDst) )
	{

		if( pSrc->IsPVPInspection( pDst, 2 ) )
		{
			CParty* pSrcParty = g_PartyMng.GetParty( pSrc->m_idparty );		// ½ÅÃ»ÀÚÀÇ ÆÄÆ¼²¨³¿
			if( pSrcParty == NULL || pSrcParty->IsLeader( pSrc->m_idPlayer ) == FALSE )
			{
				Error( "CDPSrvr::OnDuelPartyYes : PLAYER NO LEADER SOURCE  %d %s", pSrc->m_idparty, pSrc->GetName() );
				return;
			}
			CParty *pDstParty = g_PartyMng.GetParty( pDst->m_idparty );		// µµÀü¹Þ´ÂÀÚÀÇ ÆÄÆ¼²¨³¿.
			//			if( pDstParty == NULL || pDstParty->IsMember( pDst->m_idPlayer ) == FALSE )
			if( pDstParty == NULL || pDstParty->IsLeader( pDst->m_idPlayer ) == FALSE )
			{
				Error( "CDPSrvr::OnDuelPartyYes : PLAYER NO LEADER DESTINATION %d %s", pDst->m_idparty, pDst->GetName() );
				return;
			}

			pSrc->m_dwTickEndDuel = ::timeGetTime() + NEXT_TICK_ENDDUEL;
			pDst->m_dwTickEndDuel = ::timeGetTime() + NEXT_TICK_ENDDUEL;
			pSrc->SetPosChanged( TRUE );	// UpdateRegionAttr
			pDst->SetPosChanged( TRUE );

			g_DPCoreClient.SendSetPartyDuel( pSrcParty->m_uPartyId, pDstParty->m_uPartyId, TRUE );

			pSrcParty->DoDuelPartyStart( pDstParty );		// »ó´ëÆÄÆ¼¿Í °áÅõ°¡ ½ÃÀÛµÆ´Ù´Â°É ¼¼ÆÃ.
			pDstParty->DoDuelPartyStart( pSrcParty );		// »ó´ëÆÄÆ¼¿Í °áÅõ°¡ ½ÃÀÛµÆ´Ù´Â°É ¼¼ÆÃ.
		}
	}
}

// pUser°¡ µà¾ó ½ÅÃ»À» °ÅºÎÇß´Ù. pSrc¿¡°Ô ¾Ë·Á¾ß ÇÑ´Ù.
void CDPSrvr::OnDuelPartyNo( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long uidSrc; //, uidDst;
	ar >> uidSrc;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj(pUser) )
	{
		CUser* pSrc = g_UserMng.GetUserByPlayerID( uidSrc );
		if( IsValidObj(pSrc) )
			pSrc->AddDuelPartyNo( pUser->GetId() );		// pSrc¿¡°Ô pUser°¡ °ÅºÎÇß´Ù´Â°É ¾Ë¸².
	}
}

void CDPSrvr::OnMoverFocus( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long uidPlayer;
	ar >> uidPlayer;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj(pUser) )
	{
		CUser* pFocus = g_UserMng.GetUserByPlayerID( uidPlayer );
		if( IsValidObj(pFocus) )
			pUser->AddMoverFocus( pFocus );
	}
}

void CDPSrvr::OnSkillTaskBar( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	int nCount;
	ar >> nCount;

	if( nCount > MAX_SLOT_QUEUE )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		for( int i = 0 ; i < nCount ; i++)
		{
			BYTE nIndex;
			ar >> nIndex;

			if( nIndex >= MAX_SLOT_QUEUE )
				return;

			ar >> pUser->m_playTaskBar.m_aSlotQueue[nIndex].m_dwShortcut >> pUser->m_playTaskBar.m_aSlotQueue[nIndex].m_dwId >> pUser->m_playTaskBar.m_aSlotQueue[nIndex].m_dwType;
			ar >> pUser->m_playTaskBar.m_aSlotQueue[nIndex].m_dwIndex >> pUser->m_playTaskBar.m_aSlotQueue[nIndex].m_dwUserId >> pUser->m_playTaskBar.m_aSlotQueue[nIndex].m_dwData;
		}
	}
}
void CDPSrvr::OnAddAppletTaskBar( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE nIndex;
	ar >> nIndex;

	if( nIndex >= MAX_SLOT_APPLET )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		ar >> pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwShortcut >> pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwId >> pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwType;
		ar >> pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwIndex >> pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwUserId >> pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwData;
		if( pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwShortcut == SHORTCUT_CHAT )
		{
			ar.ReadString( pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_szString, MAX_SHORTCUT_STRING );
			pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_szString[MAX_SHORTCUT_STRING-1] = '\0';
		}
	}
}
void CDPSrvr::OnRemoveAppletTaskBar( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE nIndex;
	ar >> nIndex;

	if( nIndex >= MAX_SLOT_APPLET )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwShortcut == SHORTCUT_CHAT )
		{
			memset( pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_szString, 0, sizeof( pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_szString ) );
		}
		pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwShortcut = SHORTCUT_NONE;
	}
}
void CDPSrvr::OnAddItemTaskBar( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE nSlotIndex, nIndex;
	ar >> nSlotIndex >> nIndex;

	if( nSlotIndex >= MAX_SLOT_ITEM_COUNT || nIndex >= MAX_SLOT_ITEM )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#if __VER >= 11 // __CSC_VER11_5
		DWORD dwShortCut;
		ar >> dwShortCut;

		// Chat Shortcut 10°³·Î Á¦ÇÑ
		if(dwShortCut == SHORTCUT_CHAT)
		{
			int nchatshortcut = 0;
			for( int i=0; i<MAX_SLOT_ITEM_COUNT; i++ )
			{
				for( int j=0; j<MAX_SLOT_ITEM; j++ )
				{
					if( pUser->m_playTaskBar.m_aSlotItem[i][j].m_dwShortcut == SHORTCUT_CHAT )
						nchatshortcut++;
				}
			}

			if(nchatshortcut > 9)
			{
				pUser->AddDefinedText( TID_GAME_MAX_SHORTCUT_CHAT );
				return;
			}
		}

		pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwShortcut = dwShortCut;
	 	ar >> pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwId >> pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwType;
#else //__CSC_VER11_5
		ar >> pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwShortcut >> pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwId >> pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwType;
#endif //__CSC_VER11_5
		ar >> pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwIndex >> pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwUserId >> pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwData;
		if( pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwShortcut == SHORTCUT_CHAT )
		{
			ar.ReadString( pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_szString, MAX_SHORTCUT_STRING );
			pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_szString[MAX_SHORTCUT_STRING-1] = '\0';
		}
	}
}
void CDPSrvr::OnRemoveItemTaskBar( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE nSlotIndex, nIndex;
	ar >> nSlotIndex >> nIndex;

	if( nSlotIndex >= MAX_SLOT_ITEM_COUNT || nIndex >= MAX_SLOT_ITEM )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwShortcut == SHORTCUT_CHAT )
		{
			memset( pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_szString, 0, sizeof( pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_szString ) );
		}
		pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwShortcut = SHORTCUT_NONE;
	}
}


void CDPSrvr::OnPlayerMoved( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsInvalidObj( pUser ) )
		return;

	if( pUser->GetIndex() == 0 )
	{
		WriteError( "PACKETTYPE_PLAYERMOVED" );
		return;
	}

	if( pUser->m_pActMover->IsDie() )
		return;

	D3DXVECTOR3 v, vd;
	float f;
	DWORD dwState, dwStateFlag, dwMotion	= 0;
	int nMotionEx	= 0, nLoop;
	DWORD dwMotionOption;
	__int64 nTickCount;

	ar >> v >> vd >> f;
	ar >> dwState >> dwStateFlag;
	ar >> dwMotion >> nMotionEx;
	ar >> nLoop >> dwMotionOption;
	ar >> nTickCount;

	if( pUser->m_pActMover->IsFly() )	return;		// ºñÇà»óÅÂÀÎµ¥ ÀÏ·Î µé¾î¿Ô´Ù¸é Ãë¼Ò½ÃÅ°ÀÚ.

	D3DXVECTOR3 vDistance	= pUser->GetPos() - v;
	if( D3DXVec3LengthSq( &vDistance ) > 1000000.0F )
	{
//		Error( "PACKETTYPE_PLAYERMOVED" );
		return;
	}

#ifdef __AFK_REWARD_SYSTEM
	pUser->m_dwLastWalkTick = GetTickCount();
	if (pUser->IsAfk())
	{
		pUser->m_bAfk = FALSE;
		g_UserMng.UpdateAfkState(pUser);
	}
#endif //__AFK_REWARD_SYSTEM

	int delay	= (int)( (float)g_TickCount.GetOffset( nTickCount ) / 66.6667f );

	if( delay >= MAX_CORR_SIZE_45 ) {
		pUser->ActionForceSet( v, vd, f, dwState, dwStateFlag, dwMotion, nMotionEx, nLoop, dwMotionOption );
	}
	else 	
	{
		if( pUser->m_pActMover->IsStateFlag( OBJSTAF_FLY ) || dwStateFlag & OBJSTAF_FLY ) 
		{
			pUser->ActionForceSet( v, vd, f, dwState, dwStateFlag, dwMotion, nMotionEx, nLoop, dwMotionOption );
		}
		else 
		{
			pUser->m_pActMover->DefaultSet();

			int nRemnant	= (int)( MAX_CORR_SIZE_45 - delay );
			D3DXVECTOR3 d	= v - pUser->GetPos();
			float fLength	= D3DXVec3Length( &d );
			float fSpeed	= ( fLength / (float)nRemnant ) / 4 + 0.020f;
			
			pUser->m_fCrrSpd	= pUser->m_pActMover->IsStateFlag( OBJSTAF_WALK )? fSpeed*4.0f: fSpeed;

			pUser->m_CorrAction.v	= v;
			pUser->m_CorrAction.vd		= vd;
			pUser->m_CorrAction.f	= f;
			pUser->m_CorrAction.dwState	= dwState;
			pUser->m_CorrAction.dwStateFlag	= dwStateFlag;
			pUser->m_CorrAction.dwMotion	= dwMotion;
			pUser->m_CorrAction.nMotionEx	= nMotionEx;
			pUser->m_CorrAction.nLoop	= nLoop;
			pUser->m_CorrAction.dwMotionOption	= dwMotionOption;
			pUser->m_CorrAction.fValid	= TRUE;

			pUser->SetDestPos( v, ( dwState & OBJSTA_MOVE_ALL ) != OBJSTA_BMOVE );
		}
	}

	g_UserMng.AddMoverMoved
		( pUser, v, vd, f, dwState, dwStateFlag, dwMotion,  nMotionEx, nLoop, dwMotionOption, nTickCount );
}

void CDPSrvr::OnPlayerBehavior( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
//	TRACE( "OnPlayerBehavior()\n" );
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );

	if( IsInvalidObj( pUser ) )
		return;

	if( pUser->GetIndex() == 0 )
	{
		WriteError( "PACKETTYPE_PLAYERBEHAVIOR" );
		return;
	}

	if( pUser->m_pActMover->IsDie() )
			return;
	
	if( pUser->m_pActMover->IsState( OBJSTA_ATK_CASTING1 | OBJSTA_ATK_CASTING2 | OBJSTA_ATK_MAGIC1 | OBJSTA_ATK_RANGE1 | OBJSTA_ATK_MELEESKILL | OBJSTA_ATK_RANGESKILL ) )
		return;

	D3DXVECTOR3 v, vd;
	float f;
	DWORD dwState, dwStateFlag, dwMotion	= 0;
	int nMotionEx	= 0, nLoop;
	DWORD dwMotionOption;
	__int64 nTickCount;

	ar >> v >> vd >> f;
	ar >> dwState >> dwStateFlag;
	ar >> dwMotion >> nMotionEx;

	ar >> nLoop >> dwMotionOption;
	ar >> nTickCount;

	if( pUser->m_pActMover->IsFly() )
		return;
	
#ifndef __OPTIMIZE
	int delay = (int)((float)g_TickCount.GetOffset(nTickCount) / 66.6667f);
#endif

#ifdef __AFK_REWARD_SYSTEM
	pUser->m_dwLastWalkTick = GetTickCount();
	if (pUser->IsAfk())
	{

		pUser->m_bAfk = FALSE;
		g_UserMng.UpdateAfkState(pUser);
	}
#endif //__AFK_REWARD_SYSTEM


	if( !pUser->IsEmptyDest() && pUser->m_CorrAction.fValid == FALSE ) 
		pUser->ActionForceSet( v, vd, f, dwState, dwStateFlag, dwMotion, nMotionEx, nLoop, dwMotionOption );
	else 
		pUser->ActionForceSet( v, vd, f, dwState, dwStateFlag, dwMotion, nMotionEx, nLoop, dwMotionOption );

	g_UserMng.AddMoverBehavior( pUser, v, vd, f, dwState, dwStateFlag, dwMotion,  nMotionEx, nLoop, dwMotionOption, nTickCount );
}

void CDPSrvr::OnPlayerMoved2( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
	{
		if( pUser->GetIndex() == 0 )
		{
			WriteError( "PACKETTYPE_PLAYERMOVED2" );
			return;
		}

		if( pUser->m_pActMover->IsDie() )
			return;

		D3DXVECTOR3 v, vd;
		float f, fAngleX, fAccPower, fTurnAngle;
		DWORD dwState, dwStateFlag, dwMotion	= 0;
		int nMotionEx	= 0, nLoop;
		DWORD dwMotionOption;
		__int64 nTickCount;
		BYTE nFrame;

		ar >> v >> vd >> f >> fAngleX >> fAccPower >> fTurnAngle;
		ar >> dwState >> dwStateFlag;
		ar >> dwMotion >> nMotionEx;

		ar >> nLoop >> dwMotionOption;
		ar >> nTickCount;
		ar >> nFrame;
		int delay	= (int)( (float)g_TickCount.GetOffset( nTickCount ) / 66.6667f );

#ifdef __AFK_REWARD_SYSTEM
		pUser->m_dwLastWalkTick = GetTickCount();
		if (pUser->IsAfk())
		{

			pUser->m_bAfk = FALSE;
			g_UserMng.UpdateAfkState(pUser);
		}
#endif //__AFK_REWARD_SYSTEM

		if( pUser->m_pActMover->IsFly() )
		{
			// 1
			// 2
			// 3
	//		pUser->ActionForceSet2( v, vd, f, fAngleX, fAccPower, fTurnAngle, dwState, dwStateFlag, dwMotion, nMotionEx, nLoop, dwMotionOption );
//			if( false/*nTickCount < 0*/ ) {
			if( delay >= nFrame ) {
				pUser->ActionForceSet2( v, vd, f, fAngleX, fAccPower, fTurnAngle, dwState, dwStateFlag, dwMotion, nMotionEx, nLoop, dwMotionOption );
			}
			else {
				pUser->m_pActMover->DefaultSet();

				pUser->m_CorrAction.v	= v;
				pUser->m_CorrAction.vd		= vd;
				pUser->m_CorrAction.f	= f;
				pUser->m_CorrAction.dwState	= dwState;
				pUser->m_CorrAction.dwStateFlag	= dwStateFlag;
				pUser->m_CorrAction.dwMotion	= dwMotion;
				pUser->m_CorrAction.nMotionEx	= nMotionEx;
				pUser->m_CorrAction.nLoop	= nLoop;
				pUser->m_CorrAction.dwMotionOption	= dwMotionOption;
				pUser->m_CorrAction.fAngleX	= fAngleX;
				pUser->m_CorrAction.fAccPower	= fAccPower;
				pUser->m_CorrAction.fTurnAngle	= fTurnAngle;
				pUser->m_CorrAction.fValid	= TRUE;

				int nRemnant	= (int)nFrame - delay;
				pUser->m_uRemnantCorrFrm	= nRemnant;
				pUser->SetDestPos( v );
			}

			g_UserMng.AddMoverMoved2
				( pUser, v, vd, f, fAngleX, fAccPower, fTurnAngle, dwState, dwStateFlag, dwMotion,  nMotionEx, nLoop, dwMotionOption, nTickCount, nFrame );
		} 
	}
}

void CDPSrvr::OnPlayerBehavior2( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( pUser->GetIndex() == 0 )
		{
			WriteError( "PACKETTYPE_PLAYERBEHAVIOR2" );
			return;
		}

		if( pUser->m_pActMover->IsDie() )
			return;

		D3DXVECTOR3 v, vd;
		float f, fAngleX, fAccPower, fTurnAngle;
		DWORD dwState, dwStateFlag, dwMotion;
		int nMotionEx, nLoop;
		DWORD dwMotionOption;
		__int64 nTickCount;

		ar >> v >> vd >> f >> fAngleX >> fAccPower >> fTurnAngle;
		ar >> dwState >> dwStateFlag;
		ar >> dwMotion >> nMotionEx;
		ar >> nLoop >> dwMotionOption;
		ar >> nTickCount;
#ifdef _DEBUG
		if( dwStateFlag & OBJSTAF_ACC )	
		{
			int a = 0;
		}
#endif

#ifdef __AFK_REWARD_SYSTEM
		pUser->m_dwLastWalkTick = GetTickCount();
		if (pUser->IsAfk())
		{

			pUser->m_bAfk = FALSE;
			g_UserMng.UpdateAfkState(pUser);
		}
#endif //__AFK_REWARD_SYSTEM

		if( pUser->m_pActMover->IsFly() == FALSE )	return;	// ºñÇà»óÅÂ°¡ ¾Æ´Ñµ¥ ÀÌ¸®·Î µé¾î¿Ô´Ù¸é Ãë¼Ò.

		// 1
		// 2
		// 3
		pUser->ActionForceSet2( v, vd, f, fAngleX, fAccPower, fTurnAngle, dwState, dwStateFlag, dwMotion, nMotionEx, nLoop, dwMotionOption );
		// 4
		g_UserMng.AddMoverBehavior2
			( pUser, v, vd, f, fAngleX, fAccPower, fTurnAngle, dwState, dwStateFlag, dwMotion,  nMotionEx, nLoop, dwMotionOption, nTickCount );
	}
}

// Å¬¶ó·ÎºÎÅÍ ¿Ã¶ó¿Â °¢µµ¸¦ ¼¼ÆÃ.
// º¸Åë ºñÇàÁß »ç¿ë.
void CDPSrvr::OnPlayerAngle( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );

	if( IsValidObj( pUser ) )
	{
		if( pUser->GetIndex() == 0 )
		{
			WriteError( "PACKETTYPE_PLAYERANGLE" );
			return;
		}

		D3DXVECTOR3 v, vd;
		float f, fAngleX, fAccPower, fTurnAngle;
		__int64 nTickCount;

		ar >> v >> vd >> f >> fAngleX >> fAccPower >> fTurnAngle;
		ar >> nTickCount;

		int delay	= (int)( (float)g_TickCount.GetOffset( nTickCount ) / 66.6667f );

#ifdef __AFK_REWARD_SYSTEM
		pUser->m_dwLastWalkTick = GetTickCount();
		if (pUser->IsAfk())
		{

			pUser->m_bAfk = FALSE;
			g_UserMng.UpdateAfkState(pUser);
		}
#endif //__AFK_REWARD_SYSTEM

		if( pUser->m_pActMover->IsFly() )
		{
			if( delay >= MAX_CORR_SIZE_150 )
			{
				if( pUser->m_CorrAction.fValid &&  !pUser->m_CorrAction.fHalf )
				{
						pUser->ActionForceSet2( v, vd, f, fAngleX, fAccPower, fTurnAngle,
						pUser->m_CorrAction.dwState, pUser->m_CorrAction.dwStateFlag, pUser->m_CorrAction.dwMotion, pUser->m_CorrAction.nMotionEx,
						pUser->m_CorrAction.nLoop, pUser->m_CorrAction.dwMotionOption );
				}
				else
				{
					pUser->HalfForceSet( v, vd, f, fAngleX, fAccPower, fTurnAngle );
				}
			}
			else
			{
				pUser->m_pActMover->DefaultSet();

				pUser->m_CorrAction.v	= v;
				pUser->m_CorrAction.vd		= vd;
				pUser->m_CorrAction.f	= f;
				pUser->m_CorrAction.fAngleX	= fAngleX;
				pUser->m_CorrAction.fAccPower	= fAccPower;
				pUser->m_CorrAction.fTurnAngle	= fTurnAngle;
				pUser->m_CorrAction.fHalf	= !pUser->m_CorrAction.fValid;
				pUser->m_CorrAction.fValid	= TRUE;

				int nRemnant	= MAX_CORR_SIZE_150 - delay;
				pUser->m_uRemnantCorrFrm	= nRemnant;
				pUser->SetDestPos( v );
			}
			g_UserMng.AddMoverAngle( pUser, v, vd, f, fAngleX, fAccPower, fTurnAngle, nTickCount );
		}
	}
}

void CDPSrvr::OnPlayerSetDestObj( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		OBJID objid;
		float fRange;
		ar >> objid >> fRange;

		CCtrl* pCtrl;

		pCtrl	= prj.GetCtrl( objid );
		if( IsValidObj( pCtrl ) )
		{
#ifdef __TRAFIC_1222
			if( pUser->GetDestId() == objid )
				return;
#endif	// __TRAFIC_1222
			pUser->m_pActMover->DefaultSet();
			pUser->BehaviorActionForceSet();
			pUser->SetDestObj( objid, fRange );

			g_UserMng.AddMoverSetDestObj( (CMover*)pUser, objid, fRange );
		}

	}
}

#ifdef __BAG_UPDATE
void CDPSrvr::OnDoUseItemBag(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
		DWORD dwData;
	OBJID objid;
	int nBag;

	ar >> dwData >> objid >> nBag;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	if (nBag != 0 && nBag != 1 && nBag != 2)
		return;

	if (dwData < 0)
		return;

#ifdef __QUIZ
	if (pUser->GetWorld() && pUser->GetWorld()->GetID() == WI_WORLD_QUIZ)
		return;
#endif // __QUIZ

	pUser->OnDoUseItemBag(dwData, objid, nBag);
}
#endif
// raider_test ¾ø´Â ¾ÆÀÌÅÛÀ» »ç¿ëÇß´Ù°í ÇÏ¸é?
void CDPSrvr::OnDoUseItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwData;
	OBJID objid;
	int	  nPart;

	ar >> dwData >> objid >> nPart;
#ifdef __GAMEGUARD
	if (nPart >= MAX_HUMAN_PARTS || nPart < -1)
#else // __GAMEGUARD
	if (nPart >= MAX_HUMAN_PARTS)
#endif // __GAMEGUARD	
	{
		return;
	}

	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) == FALSE )
		return;

#ifdef __SECURITY_FIXES
	if ( dwData < 0 )
		return;
#endif // __SECURITY_FIXES	

	WORD nId = HIWORD( dwData );
	if( nPart > 0 )
	{
		CItemElem* pItemElem	= pUser->m_Inventory.GetAtId( nId );
		if( IsUsableItem( pItemElem ) == FALSE )
			return;
		if( pUser->m_Inventory.IsEquip( nId ) )
		{
			if( pItemElem != pUser->m_Inventory.GetEquip( nPart ) )
				return;
		}
	}
#ifdef __HACK_1023
	CItemElem* pItemElem	= pUser->m_Inventory.GetAtId( nId );
	if( IsUsableItem( pItemElem ) )
	{
		ItemProp* pItemProp	= pItemElem->GetProp();
		if( pItemProp && pItemProp->dwParts == PARTS_RIDE )
		{
			if( !pUser->m_Inventory.IsEquip( nId ) )
			{
				FLOAT fVal;
				ar >> fVal;
				if( fVal != pItemProp->fFlightSpeed )
				{
					pUser->AddDefinedText( TID_GAME_MODIFY_FLIGHT_SPEED );
					return;
				}
			}
		}
	}
#endif	// __HACK_1023


	pUser->OnDoUseItem( dwData, objid, nPart );
#ifdef __GAMEGUARD
	if (pUser->GetWorld())
		g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
#endif // __GAMEGUARD
	if (nPart > MAX_HUMAN_PARTS || dwData < 0 || nPart < -1)
	{
		Error("CDPSrvr::OnDoUseItem : Crash Try -> [Player ID: %07d], [Player Name: %s], [Packet used: %d,%d,%d]",
			pUser->m_idPlayer, pUser->GetName(), dwData, objid, nPart);
		return;
	}
}

void CDPSrvr::OnPlayerCorr( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
//	TRACE( "OnPlayerCorr\n" );
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( pUser->GetIndex() == 0 )
		{
			WriteError( "PACKETTYPE_PLAYERCORR" );
			return;
		}

		D3DXVECTOR3 v, vd;
		float f;
		DWORD dwState, dwStateFlag, dwMotion;
		int nMotionEx, nLoop;
		DWORD dwMotionOption;
		__int64 nTickCount;

		ar >> v >> vd >> f;
		ar >> dwState >> dwStateFlag;
		ar >> dwMotion >> nMotionEx;
		ar >> nLoop >> dwMotionOption;
		ar >> nTickCount;

		if( pUser->m_pActMover->IsFly() == FALSE )
		{
			D3DXVECTOR3 vDistance	= pUser->GetPos() - v;
			if( D3DXVec3LengthSq( &vDistance ) > 1000000.0F )
			{
//				Error( "PACKETTYPE_PLAYERCORR" );
				return;
			}
			// 1
			// 2
			// 3
			pUser->ClearDest();
			pUser->ClearDestAngle();
			memset( &pUser->m_CorrAction, 0, sizeof(CORR_ACTION) );

			pUser->ActionForceSet( v, vd, f, dwState, dwStateFlag, dwMotion, nMotionEx, nLoop, dwMotionOption );

			// 4
			g_UserMng.AddMoverCorr
				( pUser, v, vd, f, dwState, dwStateFlag, dwMotion,  nMotionEx, nLoop, dwMotionOption, nTickCount );
		}
	}
}

void CDPSrvr::OnPlayerCorr2( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
//	TRACE( "OnPlayerCorr2()\n" );
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( pUser->GetIndex() == 0 )
		{
			WriteError( "PACKETTYPE_PLAYERCORR2" );
			return;
		}

		D3DXVECTOR3 v, vd;
		float f, fAngleX, fAccPower, fTurnAngle;
		DWORD dwState, dwStateFlag, dwMotion;
		int nMotionEx, nLoop;
		DWORD dwMotionOption;
		__int64 nTickCount;

		ar >> v >> vd >> f >> fAngleX >> fAccPower >> fTurnAngle;
		ar >> dwState >> dwStateFlag;
		ar >> dwMotion >> nMotionEx;

		ar >> nLoop >> dwMotionOption;
		ar >> nTickCount;

		if( pUser->m_pActMover->IsFly() )
		{
			// 1
			// 2
			// 3
			pUser->ClearDest();
			pUser->ClearDestAngle();
			memset( &pUser->m_CorrAction, 0, sizeof(CORR_ACTION) );

			pUser->ActionForceSet2( v, vd, f, fAngleX, fAccPower, fTurnAngle, dwState, dwStateFlag, dwMotion, nMotionEx, nLoop, dwMotionOption );

			// 4
			g_UserMng.AddMoverCorr2
				( pUser, v, vd, f, fAngleX, fAccPower, fTurnAngle, dwState, dwStateFlag, dwMotion,  nMotionEx, nLoop, dwMotionOption, nTickCount );
		}
	}
}

void CDPSrvr::OnOpenShopWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		OBJID objid;
		ar >> objid;
		
		CMover* pVendor	= prj.GetMover( objid );
		if( IsValidObj( pVendor ) && pUser->m_vtInfo.GetOther() == NULL )
		{
			if( pVendor->IsNPC() == FALSE )		// ´ë»óÀÌ NPC°¡ ¾Æ´Ï¸é?
				return;

#if __VER >= 8 // __S8_PK
			if( pUser->IsChaotic() )
			{
				CHAO_PROPENSITY Propensity = prj.GetPropensityPenalty( pUser->GetPKPropensity() );
				if( !Propensity.nShop )
					return;
			}
#endif // __VER >= 8 // __S8_PK

			if( pVendor->IsVendorNPC() == FALSE )
			{
				WriteError( "VENDOR//%s", pVendor->GetName() );
				return;
			}

			if( pUser->m_bBank )
			{
				pUser->AddDefinedText( TID_GAME_TRADELIMITNPC, "" );
				return;
			}

			if( pUser->m_vtInfo.VendorIsVendor() )
				return;

#ifdef __S_SERVER_UNIFY
			if( pUser->m_bAllAction == FALSE )
				return;
#endif // __S_SERVER_UNIFY

			pUser->m_vtInfo.SetOther( pVendor );
			pUser->AddOpenShopWnd( pVendor );
		}
	}
}

void CDPSrvr::OnCloseShopWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
	{
		CMover* pMover = pUser->m_vtInfo.GetOther();
		if( IsValidObj( pMover ) && pMover->IsNPC() )
			pUser->m_vtInfo.SetOther( NULL );
	}
}

void CDPSrvr::OnBuyItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
#ifdef __SECURITY_FIXES
	BYTE cTab;
#else // __SECURITY_FIXES
	CHAR cTab;
#endif // __SECURITY_FIXES
	BYTE nId;
	short nNum;
	DWORD dwItemId;

	ar >> cTab >> nId >> nNum >> dwItemId;
#ifdef __GAMEGUARD
	if (cTab > 3 || cTab < 0 || nId < 0 || nId > MAX_VENDOR_INVENTORY + 1 || nNum < 1 || nNum > 9999 || dwItemId <= 0)
#else // __GAMEGUARD
	if (cTab >= MAX_VENDOR_INVENTORY_TAB || nNum < 1)
#endif // __GAMEGUARD
	{
		return;
	}

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) && pUser->m_vtInfo.GetOther() )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		CMover* pVendor = pUser->m_vtInfo.GetOther();
#if __VER >= 11 // __GUILDCOMBATCHIP
		LPCHARACTER lpChar = prj.GetCharacter( pVendor->m_szCharacterKey );
		if( lpChar && lpChar->m_nVenderType != 0 )	// 0 - Æä³Ä »óÀÎ
			return;
#endif // __GUILDCOMBATCHIP

		if( pVendor->IsNPC() == FALSE )		// ÆÇ¸ÅÇÒ ´ë»óÀÌ NPC°¡ ¾Æ´Ï¸é?
			return;

		if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_TRADE, pUser->GetWorld(), pUser->GetPos() ) )
			return;

		CItemElem* pItemElem = pVendor->m_ShopInventory[cTab]->GetAtId( nId );
		if( NULL == pItemElem )
			return;

		if( dwItemId != pItemElem->m_dwItemId )
			return;

		if( nNum > pItemElem->m_nItemNum )
			nNum = pItemElem->m_nItemNum;

#ifdef __OCCUPATION_SHOPITEM
		if( CTax::GetInstance()->IsOccupationShopItem( dwItemId ) && !CTax::GetInstance()->IsOccupationGuildMember( pUser ) )
		{
			pUser->AddDefinedText( TID_GAME_SECRETROOM_STORE_BUY );
			return;
		}
#endif // __OCCUPATION_SHOPITEM
		
		int nCost = (int)pItemElem->GetCost();
		nCost = (int)( prj.m_fShopCost * nCost );
#ifdef __SHOP_COST_RATE
		nCost = (int)( prj.m_EventLua.GetShopBuyFactor() * nCost );
#endif // __SHOP_COST_RATE
		
#if __VER < 8 // __S8_PK
		// Á÷À§¿¡ µû¸¥ »óÁ¡°¡°Ý º¯µ¿
		KarmaProp* pProp = prj.GetKarmaProp( pUser->m_nSlaughter );
		if( pProp )
		{
			if( pProp->nGrade == -6 )
				return;

			if( pProp->fDiscountRate != 0.0f )
			{
				nCost = (int)( nCost * pProp->fDiscountRate );
			}
		}
#endif // __VER < 8 // __S8_PK

#if __VER >= 11 // __MA_VER11_02
		if( pItemElem->m_dwItemId == II_SYS_SYS_SCR_PERIN )
			nCost = PERIN_VALUE;
#endif //__MA_VER11_02
		if( nCost < 1 )
			nCost = 1;
	
#ifdef __GAMEGUARD
		long long lEntireCost = nNum * nCost;
		if (lEntireCost > INT_MAX)
			return;
#endif // __GAMEGUARD

		int nPracticable = pUser->GetGold() / nCost;
		if( nNum > nPracticable )
			nNum = (short)nPracticable;

		if( nNum <= 0 )
		{
			pUser->AddDefinedText( TID_GAME_LACKMONEY, "" );
			return;
		}

#if __VER >= 12 // __TAX
		int nTax = 0;
		if( CTax::GetInstance()->IsApplyTaxRate( pUser, pItemElem ) )
			nTax = (int)( nCost * CTax::GetInstance()->GetPurchaseTaxRate( pUser ) );
		nCost += nTax;
		nTax *= nNum;
#endif // __TAX
		int nGold = nCost * nNum;
		if( nGold <= 0 )
			return;

		if( pUser->GetGold() >= nGold )
		{
#ifdef __PERIN_BUY_BUG
			if( pUser->m_dwLastBuyItemTick + 500 > GetTickCount() ) // ¾ÆÀÌÅÛ ±¸ÀÔ½Ãµµ ÈÄ 0.5ÃÊÀÌ³»¿¡ ´Ù½Ã ±¸ÀÔ½ÃµµÇÑ °æ¿ì
			{
				Error( "CDPSrvr::OnBuyItem : __PERIN_BUY_BUG -> [PlayerId:%07d(%s)], [LastTick:%d], [CurTick:%d], [LastTryItem:%d], [Packet:%d,%d,%d,%d]",
						pUser->m_idPlayer, pUser->GetName(), pUser->m_dwLastBuyItemTick, GetTickCount(), pUser->m_dwLastTryBuyItem, cTab, nId, nNum, dwItemId );
				//g_DPSrvr.QueryDestroyPlayer( pUser->m_Snapshot.dpidCache, pUser->m_Snapshot.dpidUser, pUser->m_dwSerial, pUser->m_idPlayer );
				return;
			}
			pUser->m_dwLastTryBuyItem = pItemElem->m_dwItemId;
			pUser->m_dwLastBuyItemTick = GetTickCount();
#endif // __PERIN_BUY_BUG
	
			CItemElem itemElem;
			itemElem	= *pItemElem;
			itemElem.m_nItemNum	      = nNum;
			itemElem.SetSerialNumber();

			if( pUser->CreateItem( &itemElem ) )
			{
				LogItemInfo aLogItem;
				aLogItem.Action = "B";
				aLogItem.SendName = pUser->GetName();
				aLogItem.RecvName = pVendor->GetName();
				aLogItem.WorldId = pUser->GetWorld()->GetID();
				aLogItem.Gold = pUser->GetGold();
				aLogItem.Gold2 = pUser->GetGold() - nGold;
				aLogItem.Gold_1 = pVendor->GetGold();

				pItemElem->SetSerialNumber( itemElem.GetSerialNumber() );
				OnLogItem( aLogItem, pItemElem, nNum );		// why do not pass &itemElem as argument?
				pItemElem->SetSerialNumber( 0 );
				pUser->AddGold( -nGold );	
#if __VER >= 12 // __TAX
				if( nTax )
					CTax::GetInstance()->AddTax( CTax::GetInstance()->GetContinent( pUser ), nTax, TAX_PURCHASE );
#endif // __TAX
			}
			else
				pUser->AddDefinedText( TID_GAME_LACKSPACE, "" );
		}
	}
}

#if __VER >= 11 // __GUILDCOMBATCHIP
// Ä¨À¸·Î ¾ÆÀÌÅÛ ±¸¸Å
void CDPSrvr::OnBuyChipItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
#ifdef __GAMEGUARD
	BYTE cTab;
#else // __GAMEGUARD
	CHAR cTab;
#endif // __GAMEGUARD
	BYTE nId;
	short nNum;
	DWORD dwItemId;

	ar >> cTab >> nId >> nNum >> dwItemId;
#ifdef __GAMEGUARD
	if (cTab > 3 || cTab < 0 || nId < 0 || nNum < 1 || nNum > 9999 || dwItemId < 0)
#else // __GAMEGUARD
	if (cTab >= MAX_VENDOR_INVENTORY_TAB || nNum < 1)
#endif // __GAMEGUARD
	{
		return;
	}

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) && pUser->m_vtInfo.GetOther() )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		CMover* pVendor = pUser->m_vtInfo.GetOther();
		LPCHARACTER lpChar = prj.GetCharacter( pVendor->m_szCharacterKey );
#ifdef __VENDOR_UPDATE
		if (lpChar && lpChar->m_nVenderType == 0) //Is gold
#else // __VENDOR_UPDATE
		if (lpChar && lpChar->m_nVenderType != 1)	// 1 - Ä¨ »óÀÎ
#endif // __VENDOR_UPDATE
		{
			return;
		}

		if( pVendor->IsNPC() == FALSE )		// ÆÇ¸ÅÇÒ ´ë»óÀÌ NPC°¡ ¾Æ´Ï¸é?
			return;

		if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_TRADE, pUser->GetWorld(), pUser->GetPos() ) )
			return;

		CItemElem* pItemElem = pVendor->m_ShopInventory[cTab]->GetAtId( nId );
		if( NULL == pItemElem )
			return;

		if( dwItemId != pItemElem->m_dwItemId )
			return;

#ifdef __OCCUPATION_SHOPITEM
		if( CTax::GetInstance()->IsOccupationShopItem( dwItemId ) && !CTax::GetInstance()->IsOccupationGuildMember( pUser ) )
		{
			pUser->AddDefinedText( TID_GAME_SECRETROOM_STORE_BUY );
			return;
		}
#endif // __OCCUPATION_SHOPITEM
		if( nNum > pItemElem->m_nItemNum )
			nNum = pItemElem->m_nItemNum;
		
		// ¼ÒÁöÇÑ Ä¨ÀÇ °³¼ö°¡ ºÎÁ·ÇÒ ¶§
#ifdef __VENDOR_UPDATE
		if (pUser->m_Inventory.GetAtItemNum(lpChar->m_nVenderType) < (int)(pItemElem->GetChipCost() * nNum))
#else // __VENDOR_UPDATE
		if (pUser->m_Inventory.GetAtItemNum(II_CHP_RED) < (int)(pItemElem->GetChipCost() * nNum))
#endif // __VENDOR_UPDATE
		{
			// Ä¨ °³¼ö ºÎÁ· ÅØ½ºÆ® Ãâ·Â
			pUser->AddDefinedText( TID_GAME_LACKCHIP );
			return;
		}

		// ÀÎº¥Åä¸®°¡ ²Ë Ã¡À» ¶§ 
		if( pUser->m_Inventory.IsFull( pItemElem, pItemElem->GetProp(), nNum ) )
		{
			int cost = pItemElem->GetChipCost();
			int nChipNum = cost * nNum;
#ifdef __VENDOR_UPDATE
			ItemProp* pChipItemProp = prj.GetItemProp(lpChar->m_nVenderType);
#else // __VENDOR_UPDATE
			ItemProp* pChipItemProp = prj.GetItemProp(II_CHP_RED);
#endif // __VENDOR_UPDATE
			if( nChipNum < (int)( pChipItemProp->dwPackMax ) )
			{
				CItemElem* pTempElem;
				int bEmpty = FALSE;
				for( int i = 0; i < pUser->m_Inventory.GetSize(); i++ )
				{
					pTempElem = pUser->m_Inventory.GetAtId( i );
					if( IsUsableItem(pTempElem) && pChipItemProp->dwID == pTempElem->m_dwItemId )
					{
						if( pTempElem->m_nItemNum <= nChipNum )
							bEmpty = TRUE;
						break;
					}
				}
				if( !bEmpty )
				{
					// ÀÎº¥ÀÌ ²ËÃ¡´Ù´Â ÅØ½ºÆ® Ãâ·Â
					pUser->AddDefinedText( TID_GAME_LACKSPACE, "" );
					return;
				}
			}
		}
		
		// ±¸¸Å °¡°Ý ¸¸Å­ÀÇ Ä¨ »èÁ¦
		DWORD dwChipCost = pItemElem->GetChipCost() * nNum;
		if( dwChipCost > 0x7fff )
		{
			for( ; dwChipCost > 0x7fff; )
			{
#ifdef __VENDOR_UPDATE
				pUser->RemoveItemA(lpChar->m_nVenderType, 0x7fff);
#else // __VENDOR_UPDATE
				pUser->RemoveItemA(II_CHP_RED, 0x7fff);
#endif // __VENDOR_UPDATE
				dwChipCost -= 0x7fff;
			}
		}
#ifdef __VENDOR_UPDATE
		pUser->RemoveItemA(lpChar->m_nVenderType, (short)dwChipCost);
#else // __VENDOR_UPDATE
		pUser->RemoveItemA(II_CHP_RED, (short)dwChipCost);
#endif // __VENDOR_UPDATE
				
		// ±¸¸Å ¾ÆÀÌÅÛ »ý¼º
		CItemElem itemElem;
		itemElem	= *pItemElem;
		itemElem.m_nItemNum = nNum;
		itemElem.SetSerialNumber();
		if( pUser->CreateItem( &itemElem ) )
		{
			// ·Î±× ³²±è
			LogItemInfo aLogItem;
			aLogItem.Action = "B";
			aLogItem.SendName = pUser->GetName();
			CString strTemp;
			strTemp.Format( "%s_C", pVendor->GetName() );
			aLogItem.RecvName = (LPCTSTR)strTemp;
			aLogItem.WorldId = pUser->GetWorld()->GetID();
#ifdef __VENDOR_UPDATE
			aLogItem.Gold = pUser->GetItemNum(lpChar->m_nVenderType) + itemElem.GetChipCost() * nNum;
			aLogItem.Gold2 = pUser->GetItemNum(lpChar->m_nVenderType);
#else // __VENDOR_UPDATE
			aLogItem.Gold = pUser->GetItemNum(II_CHP_RED) + itemElem.GetChipCost() * nNum;
			aLogItem.Gold2 = pUser->GetItemNum(II_CHP_RED);
#endif // __VENDOR_UPDATE
			aLogItem.Gold_1 = (DWORD)((-1) * (int)((itemElem.GetChipCost() * nNum)));
			OnLogItem( aLogItem, &itemElem, nNum );
		}
		else
		{
			LogItemInfo aLogItem;
			aLogItem.Action = "B";
			aLogItem.SendName = pUser->GetName();
			CString strTemp;
			strTemp.Format( "%s_CF", pVendor->GetName() );
			aLogItem.RecvName = (LPCTSTR)strTemp;
			aLogItem.WorldId = pUser->GetWorld()->GetID();
#ifdef __VENDOR_UPDATE
			aLogItem.Gold = pUser->GetItemNum(lpChar->m_nVenderType) + itemElem.GetChipCost() * nNum;
			aLogItem.Gold2 = pUser->GetItemNum(lpChar->m_nVenderType);
#else // __VENDOR_UPDATE
			aLogItem.Gold = pUser->GetItemNum(II_CHP_RED) + itemElem.GetChipCost() * nNum;
			aLogItem.Gold2 = pUser->GetItemNum(II_CHP_RED);
#endif // __VENDOR_UPDATE
			aLogItem.Gold_1 = (DWORD)((-1) * (int)((itemElem.GetChipCost() * nNum)));
			OnLogItem(aLogItem, &itemElem, nNum);
		}
	}
}
#endif // __GUILDCOMBATCHIP

//NPC¿¡°Ô ÆÄ´Â °æ¿ì
void CDPSrvr::OnSellItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE nId;
	short nNum;

	ar >> nId >> nNum;
	if( nNum < 1 )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) && IsValidObj( pUser->m_vtInfo.GetOther() ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		if( pUser->m_vtInfo.GetOther()->IsNPC() == FALSE )		// ÆÇ¸ÅÇÒ ´ë»óÀÌ NPC°¡ ¾Æ´Ï¸é?
			return;

		if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_TRADE, pUser->GetWorld(), pUser->GetPos() ) )
			return;

		CItemElem* pItemElem = pUser->m_Inventory.GetAtId( nId );		
		if( IsUsableItem( pItemElem ) == FALSE )
			return;

		ItemProp* pProp	= pItemElem->GetProp();
		if( pProp->dwItemKind3 == IK3_EVENTMAIN )
			return;
		
#ifdef __GAMEGUARD
		if (pProp->dwItemKind3 == IK3_EGG)
			return;
#endif // __GAMEGUARD

		if( pItemElem->IsQuest() )
			return;

		if( pUser->m_Inventory.IsEquip( nId ) )
		{
			pUser->AddDefinedText( TID_GAME_EQUIPTRADE, "" );
			return;
		}
#if __VER >= 11 // __MA_VER11_05	// ÄÉ¸¯ÅÍ ºÀÀÎ °Å·¡ ±â´É world,database,neuz
		if( pItemElem->m_dwItemId == II_SYS_SYS_SCR_SEALCHARACTER )
			return;
#endif // __MA_VER11_05	// ÄÉ¸¯ÅÍ ºÀÀÎ °Å·¡ ±â´É world,database,neuz
#if __VER >= 11 // __MA_VER11_02				// ¼öÇ¥ °³³ä È­Æä 'Æä¸°' Ãß°¡
		if( pItemElem->m_dwItemId == II_SYS_SYS_SCR_PERIN )
			return;
#endif // __MA_VER11_02				// ¼öÇ¥ °³³ä È­Æä 'Æä¸°' Ãß°¡

		if( nNum > pItemElem->m_nItemNum )
			nNum = pItemElem->m_nItemNum;
		if( nNum < 1 )
			nNum = 1;

#if __VER >= 12 // __TAX
		int nGold = ( pItemElem->GetCost() / 4 );
#ifdef __SHOP_COST_RATE
		nGold = (int)( prj.m_EventLua.GetShopSellFactor() * nGold );
#endif // __SHOP_COST_RATE
		if( nGold == 0 )
			nGold = 1;
		int nTax = 0;
		if( CTax::GetInstance()->IsApplyTaxRate( pUser, pItemElem ) )
			nTax = (int)( nGold * CTax::GetInstance()->GetSalesTaxRate( pUser ) );
		nGold -= nTax;
		nGold *= nNum;
		nTax  *= nNum;
		float fTmpGold = (float)( pUser->GetGold() + nGold );
#else // __TAX
		float fTmpGold = pUser->GetGold() + ( pItemElem->GetCost() / 4 ) * nNum;
#endif // __TAX
		if( fTmpGold >= 2100000000 )
		{
			return;
		}
//		if( pItemElem->m_dwItemId == II_RID_RID_BOR_EVEINSHOVER || pItemElem->m_dwItemId == II_RID_RID_BOR_LADOLF )
//			return;
		if( pProp->dwParts == PARTS_RIDE && pProp->dwItemJob == JOB_VAGRANT )
			return;

		if( pUser->IsUsing( pItemElem ) )
		{
			pUser->AddDefinedText( TID_GAME_CANNOT_DO_USINGITEM );
			return;
		}

		LogItemInfo aLogItem;
		aLogItem.Action = "S";
		aLogItem.SendName = pUser->GetName();
		aLogItem.RecvName = pUser->m_vtInfo.GetOther()->GetName();
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		aLogItem.Gold = pUser->GetGold();
#if __VER >= 12 // __TAX
		aLogItem.Gold2 = pUser->GetGold() + nGold;
#else // __TAX
		aLogItem.Gold2 = pUser->GetGold() + ( pItemElem->GetCost() / 4 ) * nNum;
#endif // __TAX
		OnLogItem( aLogItem, pItemElem, nNum );
		int nCost	= (int)pItemElem->GetCost() / 4;

#if __VER < 8 // __S8_PK
		KarmaProp* pProp = prj.GetKarmaProp( pUser->m_nSlaughter );
		if( pProp )
		{
			if( pProp->nGrade == -6 )
				return;

			if( pProp->fSellPenaltyRate != 0.0f )
			{
				nCost = (int)( nCost * pProp->fSellPenaltyRate );
			}
		}
#endif // __VER < 8 // __S8_PK

		if( nCost < 1 )	
			nCost = 1;

#if __VER >= 12 // __TAX
		if( nGold < 1 )
			nGold = 1;
		
		pUser->AddGold( nGold );
		if( nTax )
			CTax::GetInstance()->AddTax( CTax::GetInstance()->GetContinent( pUser ), nTax, TAX_SALES );
#else // __TAX
		pUser->AddGold( nCost * nNum );
#endif // __TAX
		pUser->RemoveItem( nId, nNum );
#ifdef __GAMEGUARD
		if (pUser->GetWorld())
			g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
#endif // __GAMEGUARD
	}
}

// ÆÐ½º¿öµå º¯°æÃ¢À» ¶ç¿ï°ÍÀÎÁö ÆÐ½º¿öµå È®ÀÎÃ¢À» ¶çÀ»°ÍÀÎÁö¸¦ ¾Ë·ÁÁØ´Ù
void CDPSrvr::OnOpenBankWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD	dwId, dwItemId;
	ar >> dwId >> dwItemId;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( dwId == NULL_ID && !CNpcChecker::GetInstance()->IsCloseNpc( MMI_BANKING, pUser->GetWorld(), pUser->GetPos() ) )
			return;
#if __VER >= 8 // __S8_PK
		if( pUser->IsChaotic() )
		{
			CHAO_PROPENSITY Propensity = prj.GetPropensityPenalty( pUser->GetPKPropensity() );
			if( !Propensity.nBank )
				return;
		}
#endif // __VER >= 8 // __S8_PK
		if( 0 == strcmp( pUser->m_szBankPass, "0000") )
		{
			// º¯°æÃ¢À» ¶ç¿ì¶ó°í ÇÔ
			pUser->AddBankWindow( 0, dwId, dwItemId );
		}
		else
		{
			// È®ÀÎÃ¢À» ¶ç¿ì¶ó°í ÇÔ
			pUser->AddBankWindow( 1, dwId, dwItemId );
		}
	}
}

void CDPSrvr::OnOpenGuildBankWnd(CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	if( g_eLocal.GetState( ENABLE_GUILD_INVENTORY ) == FALSE )		
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( pUser->m_vtInfo.GetOther() )	// °Å·¡ÁßÀÎ ´ë»óÀÌ ÀÖÀ¸¸é?
			return;
		if( pUser->m_vtInfo.VendorIsVendor() )		// ³»°¡ ÆÈ°í ÀÖÀ¸¸é?
			return;
		if( pUser->m_bBank )				// Ã¢°í¸¦ ¿­°í ÀÖÀ¸¸é?
			return;
#ifdef __S_SERVER_UNIFY
		if( pUser->m_bAllAction == FALSE )
			return;
#endif // __S_SERVER_UNIFY

		pUser->AddGuildBankWindow( 0 );
		pUser->m_bGuildBank = TRUE;
	}
}

void CDPSrvr::OnCloseBankWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );	
	if( IsValidObj( pUser ) )
	{
		pUser->m_bBank = FALSE;
		pUser->m_bInstantBank	= FALSE;
	}
}

void CDPSrvr::OnDoUseSkillPoint( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	SKILL aJobSkill[ MAX_SKILL_JOB ] = {0, };
	
	for( int i = 0; i < MAX_SKILL_JOB; i++ ) 
		ar >> aJobSkill[i].dwSkill >> aJobSkill[i].dwLevel;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );	
	if( IsValidObj( pUser ) )
	{	// ¹Ù²Ü¼ö ÀÖÀ»Áö?  È®ÀÎ
		int nChangePoint = 0;
		for( int i = 0; i < MAX_SKILL_JOB; i++ ) 
		{		
			if( aJobSkill[i].dwSkill == NULL_ID )
				continue;
			ItemProp* pSkillProp    = prj.GetSkillProp( aJobSkill[i].dwSkill );			
			if( pSkillProp == NULL )
				continue;

			if( aJobSkill[i].dwLevel < pUser->m_aJobSkill[i].dwLevel || aJobSkill[i].dwLevel > pSkillProp->dwExpertMax )
			{
				pUser->AddDefinedText(TID_RESKILLPOINT_ERROR);
				return;						
			}
			int nPoint = (aJobSkill[i].dwLevel - pUser->m_aJobSkill[i].dwLevel) * prj.GetSkillPoint( pSkillProp );
			nChangePoint += nPoint;
		}

		if( nChangePoint == 0 ) 
			return;
		if( pUser->m_nSkillPoint < nChangePoint )
		{
			pUser->AddDefinedText(TID_RESKILLPOINT_ERROR);
			return;						
		}
		
		// ½ºÅ³º° ÀçºÐ¹è ÇÏ±â // ½ºÅ³ ·¹º§ ¼ÂÆÃ
		pUser->m_nSkillPoint -= nChangePoint;

		for( int i = 0; i < MAX_SKILL_JOB; i++ ) 
		{				
			LPSKILL lpSkill = &(pUser->m_aJobSkill[i]);
			if( lpSkill )
			{
				if( aJobSkill[i].dwSkill == NULL_ID )
					continue;
				ItemProp* pSkillProp    = prj.GetSkillProp( lpSkill->dwSkill );			
				if( pSkillProp == NULL )
					continue;

				int nPoint = (aJobSkill[i].dwLevel - lpSkill->dwLevel) * prj.GetSkillPoint( pSkillProp );
				if( 0 < nPoint ) // ½ºÅ³ ºÎ¿©ÇÑ°Í¸¸ ·Î±×¿¡ ³²±âÀÚ
					g_dpDBClient.SendLogSkillPoint( LOG_SKILLPOINT_USE, nPoint, (CMover*)pUser, &aJobSkill[i] );

				lpSkill->dwLevel = aJobSkill[i].dwLevel;
			}
		}	
		g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_SYS_EXCHAN01, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
		pUser->AddDoUseSkillPoint( &aJobSkill[0], pUser->m_nSkillPoint );
#ifdef __S_NEW_SKILL_2
		g_dpDBClient.SaveSkill( pUser );
#endif // __S_NEW_SKILL_2
	}
}

void CDPSrvr::OnCloseGuildBankWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	if( g_eLocal.GetState( ENABLE_GUILD_INVENTORY ) == FALSE )		
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) )
	{
		pUser->m_bGuildBank = FALSE;
	}
}

void CDPSrvr::OnBankToBank( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE nFlag, nPutSlot, nSlot, nId;
	short nItemNum;
	DWORD dwGold;
	ar >> nFlag >> nPutSlot >> nSlot;

	if( nPutSlot >= 3 || nSlot >= 3 )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		if( pUser->m_idPlayerBank[nPutSlot] != 0 && pUser->m_idPlayerBank[nSlot] != 0 && pUser->IsCommBank() )
		{
			if( nFlag == 1 )	// Item
			{
				ar >> nId >> nItemNum;
				CItemElem* pItemElem	= pUser->m_Bank[nPutSlot].GetAtId( nId );
				if( pItemElem == NULL )
					return;

				if( nItemNum > pItemElem->m_nItemNum )
					nItemNum	= pItemElem->m_nItemNum;
				if( nItemNum < 1 )
					nItemNum	= 1;

				if( MAX_BANK > pUser->m_Bank[nSlot].GetCount() )
				{
					CItemElem itemElem;
					itemElem	= *pItemElem;
					itemElem.m_nItemNum		= nItemNum;
					pUser->AddPutItemBank( nSlot, &itemElem );
					pUser->m_Bank[nSlot].Add( &itemElem );
					pUser->UpdateItemBank( nPutSlot, nId, UI_NUM, pItemElem->m_nItemNum - nItemNum );		// ÀºÇà¿¡ »©±â¹× Àü¼Û

					LogItemInfo aLogItem;
					aLogItem.Action = "A";
					aLogItem.SendName = pUser->GetName();
					aLogItem.RecvName = "BANK";
					aLogItem.WorldId = pUser->GetWorld()->GetID();
					aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
					aLogItem.Gold_1 = pUser->m_dwGoldBank[pUser->m_nSlot];
					aLogItem.nSlot = nSlot;
					aLogItem.nSlot1 = nPutSlot;
					OnLogItem( aLogItem, &itemElem, itemElem.m_nItemNum );
				}
				else
				{
					// ²ËÂ÷¼­ ³ÖÀ»¼ö °¡ ¾øÀ½. ¸Þ¼¼Áö Ã³¸®
					pUser->AddBankIsFull();
				}
			}
			else		// Gold
			{
				 ar >> dwGold;
				
				 if( dwGold > pUser->m_dwGoldBank[nPutSlot] )
					 dwGold = pUser->m_dwGoldBank[nPutSlot];
				 
				 int nGold = dwGold;
				 if( CanAdd( pUser->m_dwGoldBank[nSlot], nGold ) )
				 {
					 pUser->m_dwGoldBank[nSlot]	+= nGold;
					 pUser->m_dwGoldBank[nPutSlot] -= nGold;
					 
					 pUser->AddPutGoldBank( nSlot, pUser->GetGold(), pUser->m_dwGoldBank[nSlot] );
					 pUser->AddPutGoldBank( nPutSlot, pUser->GetGold(), pUser->m_dwGoldBank[nPutSlot] );

					 LogItemInfo aLogItem;
					 aLogItem.Action = "A";
					 aLogItem.SendName = pUser->GetName();
					 aLogItem.RecvName = "BANK";
					 aLogItem.WorldId = pUser->GetWorld()->GetID();
					 aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
					 //aLogItem.ItemName = "SEED";
					 _stprintf( aLogItem.szItemName, "%d", II_GOLD_SEED1 );
					 aLogItem.itemNumber = nGold;
					 aLogItem.Gold_1 = pUser->m_dwGoldBank[pUser->m_nSlot];
					 aLogItem.nSlot = nSlot;
					 aLogItem.nSlot1 = nPutSlot;
					 OnLogItem( aLogItem );
				 }	
			}
#ifdef __GAMEGUARD
			if (pUser->GetWorld())
				g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
#endif // __GAMEGUARD
		}
	}
}
void CDPSrvr::OnPutItemBank( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE nSlot, nId;
	short nItemNum;

	ar >> nSlot >> nId >> nItemNum;
	if( nSlot >= 3 )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		if( !pUser->m_bInstantBank )
		{
			if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_BANKING, pUser->GetWorld(), pUser->GetPos() ) )
				return;
		}

		if( pUser->m_nSlot == nSlot || ( pUser->m_idPlayerBank[nSlot] != 0 && pUser->IsCommBank() ) )
		{
			CItemElem* pItemElem = pUser->m_Inventory.GetAtId( nId );
			if( IsUsableItem( pItemElem ) == FALSE )
				return;

			if( nSlot != pUser->m_nSlot )
			{
				if( pItemElem->IsQuest() )
					return;
			}
				
#if __VER >= 11 // __SYS_IDENTIFY
			if( pItemElem->IsBinds() )
				return;
#else	// __SYS_IDENTIFY
			if( pItemElem->IsFlag( CItemElem::binds ) )
				return;
#endif	// __SYS_IDENTIFY

			ItemProp* pProp	= pItemElem->GetProp();
			if( !pProp )
				return;

			if( pUser->IsUsing( pItemElem ) )
			{
				pUser->AddDefinedText( TID_GAME_CANNOT_DO_USINGITEM );
				return;
			}
			
			if( pProp->dwItemKind3 == IK3_EVENTMAIN ||
				pProp->dwItemKind3 == IK3_LINK ||
				( pProp->dwItemKind3 == IK3_CLOAK && pItemElem->m_idGuild != 0 ) )
				return;

//			if( pItemElem->m_dwItemId == II_RID_RID_BOR_EVEINSHOVER || pItemElem->m_dwItemId == II_RID_RID_BOR_LADOLF )
//				return;
			if( pProp->dwParts == PARTS_RIDE && pProp->dwItemJob == JOB_VAGRANT )
				return;


			if( pUser->m_Inventory.IsEquip( nId ) )
			{
				pUser->AddDefinedText( TID_GAME_EQUIPTRADE, "" );
				return;
			}
			
			if( nItemNum > pItemElem->m_nItemNum )
				nItemNum	= pItemElem->m_nItemNum;
			if( nItemNum < 1 )
				nItemNum	= 1;

//			if( MAX_BANK > pUser->m_Bank[nSlot].GetCount() )
			if( pUser->m_Bank[nSlot].IsFull( pItemElem, pProp, nItemNum ) == FALSE )
			{
				CItemElem itemElem;
				itemElem	= *pItemElem;
				itemElem.m_nItemNum		= nItemNum;
				pUser->AddPutItemBank( nSlot, &itemElem );
				pUser->m_Bank[nSlot].Add( &itemElem );

				LogItemInfo aLogItem;
				aLogItem.Action = "P";
				aLogItem.SendName = pUser->GetName();
				aLogItem.RecvName = "BANK";
				aLogItem.WorldId = pUser->GetWorld()->GetID();
				aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
				aLogItem.Gold_1 = pUser->m_dwGoldBank[pUser->m_nSlot];
				aLogItem.nSlot1 = nSlot;
				OnLogItem( aLogItem, pItemElem, nItemNum );

				pUser->RemoveItem( nId, nItemNum );
#ifdef __SECURITY_FIXES
				CWorld* pWorld = pUser->GetWorld();				
				g_dpDBClient.SavePlayer( pUser, pWorld->GetID(), pUser->GetPos(), pUser->GetLayer() );
#endif //__SECURITY_FIXES			
			}
			else
			{
				// ²ËÂ÷¼­ ³ÖÀ»¼ö °¡ ¾øÀ½. ¸Þ¼¼Áö Ã³¸®
				pUser->AddBankIsFull();
			}
		}
#ifdef __GAMEGUARD
		if (pUser->GetWorld())
			g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
#endif // __GAMEGUARD
	}
}

void CDPSrvr::OnPutItemGuildBank( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	if( g_eLocal.GetState( ENABLE_GUILD_INVENTORY ) == FALSE )		
		return;

	BYTE nId, mode;
#ifdef __GAMEGUARD
	UINT nItemNum;
#else // __GAMEGUARD
	DWORD nItemNum;
#endif // __GAMEGUARD

	ar >> nId >> nItemNum >> mode;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );	
	if( IsValidObj( pUser ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
#if __VER >= 15 // __GUILD_HOUSE
		if( !pUser->GetWorld() || !GuildHouseMng->IsGuildHouse( pUser->GetWorld()->GetID() ) )
#endif // __GUILD_HOUSE
		{
			if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_GUILDBANKING, pUser->GetWorld(), pUser->GetPos()))
				return;
		}
		if( mode == 0 ) // ±æµåÃ¢°í¿¡´Â Gold¸¦ ³ÖÀ»¼ö ¾ø½À´Ï´Ù.
			return;

#ifdef __GAMEGUARD
		if (nId < 1 || nId > pUser->m_Inventory.GetMax())
			return;
#endif // __GAMEGUARD
		
		CItemElem* pItemElem = pUser->m_Inventory.GetAtId( nId );		
		if( IsUsableItem( pItemElem ) == FALSE )
			return;

		if( pItemElem->IsQuest() )
			return;
		
		if( pItemElem->IsBinds() )
			return;

		if( pUser->IsUsing( pItemElem ) )
		{
			pUser->AddDefinedText( TID_GAME_CANNOT_DO_USINGITEM );
			return;
		}

		ItemProp* pProp	= pItemElem->GetProp();
#ifdef __GAMEGUARD
		if (!pProp)
			return;
#endif // __GAMEGUARD

		if( pProp->dwParts == PARTS_RIDE && pProp->dwItemJob == JOB_VAGRANT )
			return;

		if( pUser->m_Inventory.IsEquip( nId ) )
		{
			pUser->AddDefinedText( TID_GAME_EQUIPTRADE, "" );
			return;
		}

		if( pItemElem->IsCharged() )
			return;

#ifdef __GAMEGUARD
		if ((short)(nItemNum) > pItemElem->m_nItemNum)
#else // __GAMEGUARD
		if ((int)(nItemNum) > pItemElem->m_nItemNum)
#endif // __GAMEGUARD
		{
			nItemNum = pItemElem->m_nItemNum;
		}

#ifdef __GAMEGUARD
		if ((short)(nItemNum) < 1)
#else // __GAMEGUARD
		if (nItemNum < 1)
#endif // __GAMEGUARD
		{
			nItemNum = 1;
		}
		CGuild*	pGuild = pUser->GetGuild();
		if( pGuild )
		{
			CItemElem itemElem;
			itemElem	= *pItemElem;
#ifdef __GAMEGUARD
			itemElem.m_nItemNum = nItemNum;
#else // __GAMEGUARD
			itemElem.m_nItemNum = (short)nItemNum;
#endif // __GAMEGUARD
			if ( pGuild->m_GuildBank.Add( &itemElem ) )
			{
				LogItemInfo aLogItem;
				aLogItem.Action = "W";
				aLogItem.SendName = pUser->GetName();
				aLogItem.RecvName = "GUILDBANK";
				aLogItem.WorldId = pUser->GetWorld()->GetID();
				aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
				OnLogItem( aLogItem, &itemElem, nItemNum );

#ifdef __GAMEGUARD
				pUser->RemoveItem((BYTE)(nId), nItemNum);
				UpdateGuildBank(pGuild, GUILD_PUT_ITEM, 0, pUser->m_idPlayer, &itemElem, 0, (short)(nItemNum));
#else // __GAMEGUARD
				pUser->RemoveItem((BYTE)(nId), (short)(nItemNum));
				UpdateGuildBank(pGuild, GUILD_PUT_ITEM, 0, pUser->m_idPlayer, &itemElem, 0, nItemNum);
#endif // __GAMEGUARD
				pUser->AddPutItemGuildBank( &itemElem );
				g_UserMng.AddPutItemElem( pUser, &itemElem );
			}
			else
			{
				pUser->AddDefinedText( TID_GAME_GUILDBANKFULL, "" );		// ±æµåÃ¢°í°¡ ²ËÃ¡½ÃÀ¯~
			}
		}
#ifdef __GAMEGUARD
		if (pUser->GetWorld())
			g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
#endif // __GAMEGUARD
	}
}

void CDPSrvr::OnGetItemGuildBank( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	if( g_eLocal.GetState( ENABLE_GUILD_INVENTORY ) == FALSE )		
		return;

	BYTE nId, mode;
#ifdef __GAMEGUARD
	int dwItemNum;
#else // __GAMEGUARD
	DWORD dwItemNum;
#endif // __GAMEGUARD

	ar >> nId >> dwItemNum >> mode;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );	
	if( IsValidObj( pUser ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
#if __VER >= 15 // __GUILD_HOUSE
		if( !pUser->GetWorld() || !GuildHouseMng->IsGuildHouse( pUser->GetWorld()->GetID() ) )
#endif // __GUILD_HOUSE
		{
			if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_GUILDBANKING, pUser->GetWorld(), pUser->GetPos()))
				return;
		}

#ifdef __GAMEGUARD
		if (dwItemNum < 1 || dwItemNum > 2100000000)
			return;
#endif // __GAMEGUARD
		
		if (mode == 0) // Gold¸¦ ±æµåÃ¢°í¿¡¼­ »©³¾¶§
		{
#ifdef __GAMEGUARD
			int nGold = (UINT)dwItemNum;
#else // __GAMEGUARD
			int nGold = dwItemNum;
#endif // __GAMEGUARD
			if( nGold <= 0 || CanAdd( pUser->GetGold(), nGold ) == FALSE )
				return;

			CGuild*	pGuild = pUser->GetGuild();
			if (pGuild && pGuild->IsGetPenya(pUser->m_idPlayer))
			{
				if( (DWORD)nGold > pGuild->m_nGoldGuild )
					return;

				pUser->AddGold( nGold, FALSE );
				pGuild->m_nGoldGuild -= nGold;
				pUser->AddGetGoldGuildBank( nGold, 0, pUser->m_idPlayer, 0 );	// 0Àº ¾÷µ¥ÀÌÆ® ½ÃÅ² Å¬¶ó¿¡°Ô 
				pGuild->DecrementMemberContribution( pUser->m_idPlayer, nGold, 0 );
				UpdateGuildBank(pGuild, GUILD_GET_PENYA, 1, pUser->m_idPlayer, NULL, nGold );

				LogItemInfo aLogItem;
				aLogItem.Action = "Y";
				aLogItem.SendName = "GUILDBANK";
				aLogItem.RecvName = pUser->GetName();
				aLogItem.WorldId = pUser->GetWorld()->GetID();
				aLogItem.Gold = pUser->GetGold() - nGold;
				aLogItem.Gold2 = pUser->GetGold();
				//aLogItem.ItemName = "SEED";
				_stprintf( aLogItem.szItemName, "%d", II_GOLD_SEED1 );
				aLogItem.itemNumber = nGold;
				OnLogItem( aLogItem );

				CGuildMember*	pMember;
				CUser*			pUsertmp;
				map<u_long, CGuildMember*>::iterator i = pGuild->m_mapPMember.begin();
				for( ; i != pGuild->m_mapPMember.end(); ++i )
				{
					pMember		= i->second;
					pUsertmp	= (CUser*)prj.GetUserByID( pMember->m_idPlayer );
					if( IsValidObj( pUsertmp ) && pUsertmp != pUser )
					{
						pUsertmp->AddGetGoldGuildBank( nGold, 2, pUser->m_idPlayer, 0 );	// 2´Â ¾÷µ¥ÀÌÆ® ÇØ¾ßÇÒ Å¬¶óÀÌ°Ô
					}
				}

				g_DPCoreClient.SendGuildMsgControl_Bank_Penya( pUser, nGold, 2, 0 ); 	// 2´Â ¾÷µ¥ÀÌÆ® ÇØ¾ßÇÒ ´Ù¸¥ ¿ùµå¼­¹öÀÇ Å¬¶óÀÌ¾ðÆ®
			}
			//	Core ¼­¹ö¿¡ Àü ¼­¹ö¿¡ ¾÷µ¥ÀÌÆ® µÇ¾ßÇÔÀ» ¾Ë¸°´Ù.
		}
		else if (mode == 1) // ¾ÆÀÌÅÛÀ» ±æµåÃ¢°í¿¡¼­ »©³¾¶§
		{
			CGuild*			pGuild = pUser->GetGuild();
			if (pGuild && pGuild->IsGetItem(pUser->m_idPlayer))
			{
				if( nId < 0 || nId > pGuild->m_GuildBank.GetMax() )
					return;
				
				CItemElem* pItemElem	= pGuild->m_GuildBank.GetAtId( nId );
				
				if( NULL == pItemElem )
					return;
				
#ifdef __GAMEGUARD
				if ((short)(dwItemNum) > pItemElem->m_nItemNum)
#else // __GAMEGUARD
				if ((int)(dwItemNum) > pItemElem->m_nItemNum)
#endif // __GAMEGUARD
				{
					dwItemNum = pItemElem->m_nItemNum;
				}

#ifdef __GAMEGUARD
				if ((short)(dwItemNum) < 1)
#else // __GAMEGUARD
				if (dwItemNum < 1)
#endif // __GAMEGUARD
				{
					dwItemNum = 1;
				}
				
				CItemElem itemElem;
				itemElem	= *pItemElem;
				itemElem.m_nItemNum		= (short)( dwItemNum );
				itemElem.m_dwObjId		= pItemElem->m_dwObjId;

				if( pUser->m_Inventory.Add( &itemElem ) )
				{
					if (pItemElem->m_nItemNum > (int)( dwItemNum ) )
						pItemElem->m_nItemNum	= (short)( pItemElem->m_nItemNum - dwItemNum );
					else 
						pGuild->m_GuildBank.RemoveAtId( nId );
					UpdateGuildBank(pGuild, GUILD_GET_ITEM, 0, pUser->m_idPlayer, &itemElem, 0, (short)( dwItemNum ) );
					LogItemInfo aLogItem;
					aLogItem.Action = "Y";
					aLogItem.SendName = "GUILDBANK";
					aLogItem.RecvName = pUser->GetName();
					aLogItem.WorldId = pUser->GetWorld()->GetID();
					aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
					OnLogItem( aLogItem, &itemElem, dwItemNum );
				
					// Å¬¶óÀÌ¾ðÆ®¿¡°Ô ¾ÆÀÌÅÛÀÌ ÀÎº¥Åä¸®¿¡ Ãß°¡µÊÀ» ¾Ë¸°´Ù.
					pUser->AddGetItemGuildBank( &itemElem );
					// ÀÚ½ÅÀ» Á¦¿ÜÇÑ ¸ðµç Å¬¶óÀÌ¾ðÆ®¿¡°Ô ¾Ë·ÁÁØ´Ù.
					g_UserMng.AddGetItemElem( pUser, &itemElem );
				}
				else
				{
					// ²ËÂ÷¼­ ³ÖÀ»¼ö °¡ ¾øÀ½. ¸Þ¼¼Áö Ã³¸®
					pUser->AddBankIsFull();
				}
			}
		}
#ifdef __GAMEGUARD
		if (pUser->GetWorld())
			g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
#endif // __GAMEGUARD
	}
}


void CDPSrvr::OnGuildBankMoveItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	if( g_eLocal.GetState( ENABLE_GUILD_INVENTORY ) == FALSE )		
		return;

	BYTE nSrcIndex, nDestIndex;
	
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		ar >> nSrcIndex >> nDestIndex;
		
		// ±æµå Ã¢°íÀÇ ¾ÆÀÌÅÛÀ» ½º¿ÒÇÑ´Ù.
		CGuild* pGuild = pUser->GetGuild();
		if ( pGuild )
		{
			pGuild->m_GuildBank.Swap( nSrcIndex, nDestIndex );
			// ¸ðµç Å¬¶óÀÌ¾ðÆ®¿¡°Ô ±æµåÃ¢°í¿¡¼­ ¾ÆÀÌÅÛÀÌ ÀÌµ¿ÇßÀ½À» ¾Ë·ÁÁØ´Ù.
			// ±æµåÃ¢°í¸¦ ¾÷µ¥ÀÌÆ®ÇÑ´Ù.
			UpdateGuildBank(pGuild, 4); // 4¹øÀº ¾ÆÀÌÅÛÀÌ ½º¿ÒµÈ°ÍÀÓ
		}
#ifdef __GAMEGUARD
		if (pUser->GetWorld())
			g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
#endif // __GAMEGUARD
	}
}

void CDPSrvr::UpdateGuildBank(CGuild* p_GuildBank, int p_Mode, BYTE cbUpdate, u_long idPlayer, CItemElem* pItemElem, DWORD dwPenya, short nItemCount )
{
	BEFORESENDDUAL( ar, PACKETTYPE_GUILD_BANK_UPDATE, DPID_UNKNOWN, DPID_UNKNOWN );

	if (p_GuildBank)
	{
		ar << p_GuildBank->m_idGuild;
		ar << p_GuildBank->m_nGoldGuild;
		p_GuildBank->m_GuildBank.Serialize(ar);
		ar << cbUpdate;	// ¸â¹öÀÇ °øÇåÆä³Ä¸¦ ¾÷µ«ÇØ¾ßÇÏ´Â°¡? 
		ar << idPlayer;
		ar << p_Mode;
		if( pItemElem == NULL )
		{
			ar << (DWORD)0;
			ar << (int)0;
			ar << (SERIALNUMBER)0;
		}
		else
		{
			ar << pItemElem->m_dwItemId;
			ar << pItemElem->GetAbilityOption();
			ar << pItemElem->GetSerialNumber();
		}		
		ar << nItemCount;
		ar << dwPenya;
		SEND( ar, &g_dpDBClient, DPID_SERVERPLAYER );
	}
}


void CDPSrvr::OnGetItemBank( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE nSlot, nId;
	short nItemNum;

	ar >> nSlot >> nId >> nItemNum;
	if( nSlot >= 3 )
		return;
	
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		if( !pUser->m_bInstantBank )
		{
			if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_BANKING, pUser->GetWorld(), pUser->GetPos() ) )
				return;
		}
		if( pUser->m_nSlot == nSlot || ( pUser->m_idPlayerBank[nSlot] != 0 && pUser->IsCommBank() ) )
		{
			CItemElem* pItemElem	= pUser->m_Bank[nSlot].GetAtId( nId );
			if( NULL == pItemElem )
				return;
	
			if( nItemNum > pItemElem->m_nItemNum )
				nItemNum = pItemElem->m_nItemNum;
			if( nItemNum < 1 )
				nItemNum	= 1;
			
#ifdef __TABBED_INV
			if (pItemElem->GetProp() && !pUser->m_Inventory.IsFull(pItemElem, pItemElem->GetProp(), nItemNum))
#else // __TABBED_INV
			if (MAX_INVENTORY > pUser->m_Inventory.GetCount())
#endif // __TABBED_INV
			{
				CItemElem itemElem;
				itemElem	= *pItemElem;
				itemElem.m_nItemNum		= nItemNum;
				pUser->AddGetItemBank( &itemElem );			// À¯Àú¿¡°Ô Àü¼Û
				pUser->m_Inventory.Add( &itemElem );		// ÀÎº¥¿¡ ³Ö±â

				LogItemInfo aLogItem;
				aLogItem.Action = "G";
				aLogItem.SendName = "BANK";
				aLogItem.RecvName = pUser->GetName();
				aLogItem.WorldId = pUser->GetWorld()->GetID();
				aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
				aLogItem.Gold_1 = pUser->m_dwGoldBank[pUser->m_nSlot];
				aLogItem.nSlot = nSlot;
				OnLogItem( aLogItem, pItemElem, nItemNum );
				pUser->UpdateItemBank( nSlot, nId, UI_NUM, pItemElem->m_nItemNum - nItemNum );		// ÀºÇà¿¡ »©±â¹× Àü¼Û
#ifdef __SECURITY_FIXES
				CWorld* pWorld = pUser->GetWorld();
				g_dpDBClient.SavePlayer( pUser, pWorld->GetID(), pUser->GetPos(), pUser->GetLayer() );
#endif //__SECURITY_FIXES			
			}
			else
			{
				// ²ËÂ÷¼­ ³ÖÀ»¼ö °¡ ¾øÀ½. ¸Þ¼¼Áö Ã³¸®
				pUser->AddBankIsFull();
			}
		}
#ifdef __GAMEGUARD
		if (pUser->GetWorld())
			g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
#endif // __GAMEGUARD
	}
}

void CDPSrvr::OnPutGoldBank( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpbuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	DWORD dwGold;
	BYTE nSlot;
	ar >> nSlot >> dwGold;
	
	int nGold = dwGold;
	if( nGold <= 0 )
		return;

	if( nSlot >= 3 )
		return;

	if( IsValidObj( pUser ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		if( !pUser->m_bInstantBank )
		{
			if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_BANKING, pUser->GetWorld(), pUser->GetPos() ) )
				return;
		}
		if( pUser->m_nSlot == nSlot || ( pUser->m_idPlayerBank[nSlot] != 0 && pUser->IsCommBank() ) )
		{
			if( nGold > pUser->GetGold() )
				nGold = pUser->GetGold();
			
			// ÀºÇàµ·ÀÌ overflowµÇÁö ¾Ê°Ô ÇÑ´Ù.
			if( CanAdd(pUser->m_dwGoldBank[nSlot], nGold) )
			{
				LogItemInfo aLogItem;
				aLogItem.Action = "P";
				aLogItem.SendName = pUser->GetName();
				aLogItem.RecvName = "BANK";
				aLogItem.WorldId = pUser->GetWorld()->GetID();
				aLogItem.Gold = pUser->GetGold();
				aLogItem.Gold2 = pUser->GetGold() - nGold;
				//aLogItem.ItemName = "SEED";
				_stprintf( aLogItem.szItemName, "%d", II_GOLD_SEED1 );
				aLogItem.itemNumber = nGold;
				aLogItem.Gold_1 = pUser->m_dwGoldBank[pUser->m_nSlot];
				aLogItem.nSlot1 = nSlot;
				OnLogItem( aLogItem );
				
				pUser->m_dwGoldBank[nSlot] += nGold;
				pUser->AddGold( -nGold, FALSE );
				
				pUser->AddPutGoldBank( nSlot, pUser->GetGold(), pUser->m_dwGoldBank[nSlot] );
			}
		}	
#ifdef __GAMEGUARD
		if (pUser->GetWorld())
			g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
#endif // __GAMEGUARD
	}
}

void CDPSrvr::OnGetGoldBank( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpbuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );

	DWORD dwGold;
	BYTE nSlot;
	ar >> nSlot >> dwGold;

	int nGold = dwGold;		
	if( nGold <= 0 )
		return;

	if( nSlot >= 3 )
		return;

	if( IsValidObj( pUser ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		if( !pUser->m_bInstantBank )
		{
			if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_BANKING, pUser->GetWorld(), pUser->GetPos() ) )
				return;
		}
		if( pUser->m_nSlot == nSlot || ( pUser->m_idPlayerBank[nSlot] != 0 && pUser->IsCommBank() ) )
		{
			if( nGold > (int)( pUser->m_dwGoldBank[nSlot] ) )
				nGold = pUser->m_dwGoldBank[nSlot];

			if( CanAdd(pUser->GetGold(), nGold) )
			{
				LogItemInfo aLogItem;
				aLogItem.Action = "G";
				aLogItem.SendName = "BANK";
				aLogItem.RecvName = pUser->GetName();
				aLogItem.WorldId = pUser->GetWorld()->GetID();
				aLogItem.Gold = pUser->GetGold();
				aLogItem.Gold2 = pUser->GetGold() + nGold;
				//aLogItem.ItemName = "SEED";
				_stprintf( aLogItem.szItemName, "%d", II_GOLD_SEED1 );
				aLogItem.itemNumber = nGold;
				aLogItem.Gold_1 = pUser->m_dwGoldBank[pUser->m_nSlot];
				aLogItem.nSlot = nSlot;
				OnLogItem( aLogItem );

				pUser->AddGold( nGold, FALSE );
				pUser->m_dwGoldBank[nSlot] -= nGold;
				pUser->AddPutGoldBank( nSlot, pUser->GetGold(), pUser->m_dwGoldBank[nSlot] );		
			}
		}	
#ifdef __GAMEGUARD
		if (pUser->GetWorld())
			g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
#endif // __GAMEGUARD
	}
}

void CDPSrvr::OnMoveBankItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
}

void CDPSrvr::OnChangeBankPass( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	char szLastPass[10] ={0,};
	char szNewPass[10] ={0,};
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		ar.ReadString( szLastPass, 10 );
		ar.ReadString( szNewPass, 10 );

		if( strlen( szLastPass ) > 4 || strlen( szNewPass ) > 4 )
		{
			WriteError( "%s %d, %s, %s", __FILE__, __LINE__, szLastPass, szNewPass );
			return;
		}

		DWORD dwId, dwItemId;
		ar >> dwId >> dwItemId;

		// ¿©±â¼­ ºñ¹Ð¹øÈ£ È®ÀÎÀÛ¾÷
		if( 0 == strcmp( szLastPass, pUser->m_szBankPass ) )
		{
			// ÆÐ½º¿öµå°¡ ¹Ù²åÀ¸¹Ç·Î DB¿Í Å¬¶óÀÌ¾ðÆ®¿¡ °Ô ¹Ù…—´Ù°í º¸³»ÁÜ
			strcpy( pUser->m_szBankPass, szNewPass );
			g_dpDBClient.SendChangeBankPass( pUser->GetName(), szNewPass, pUser->m_idPlayer );
			pUser->AddChangeBankPass( 1, dwId, dwItemId );
		}
		else
		{
			// ´Ù½Ã ÀÔ·ÂÇÏ¶ó°í ¾Ë·ÁÁÜ
			// ÆÐ½º¿öµå°¡ Æ²·ÈÀ½
			pUser->AddChangeBankPass( 0, dwId, dwItemId );
		}
	}
}

void CDPSrvr::OnConfirmBank( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	char szPass[10] ={0,};
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( pUser->m_vtInfo.GetOther() )
			return;
		if( pUser->m_vtInfo.VendorIsVendor() )
			return;
		if( pUser->m_bGuildBank )
			return;
#ifdef __S_SERVER_UNIFY
		if( pUser->m_bAllAction == FALSE )
			return;
#endif // __S_SERVER_UNIFY

		// ¿©±â¼­ ºñ¹Ð¹øÈ£ È®ÀÎÀÛ¾÷
		ar.ReadString( szPass, 10 );

		DWORD dwId, dwItemId;
		ar >> dwId >> dwItemId;

		if( dwId == NULL_ID && !CNpcChecker::GetInstance()->IsCloseNpc( MMI_BANKING, pUser->GetWorld(), pUser->GetPos() ) )
				return;

		if( 0 == strcmp( szPass, pUser->m_szBankPass ) )
		{
			// ºñ¹Ð¹øÈ£¸¦ È®ÀÎ ÇÏ¿´À¸¹Ç·Î ÀºÇàÀ» ¿­¼ö ÀÕ°Ô ÇØÁÜ
			if( dwId != NULL_ID )
			{
				CItemElem* pItemElem = pUser->m_Inventory.GetAtId( dwId );
				if( IsUsableItem( pItemElem ) == FALSE || pItemElem->m_dwItemId != dwItemId )
				{
					return;
				}
				else
				{
					pUser->m_bInstantBank	= TRUE;
					pUser->RemoveItem( (BYTE)( pItemElem->m_dwObjId ), 1 );
				}
			}
			pUser->m_bBank = TRUE;
			pUser->AddconfirmBankPass( 1, dwId, dwItemId );
		}
		else
		{
			// ´Ù½Ã ÀÔ·ÂÇÏ¶ó°í ¾Ë·ÁÁÜ
			// ÆÐ½º¿öµå°¡ Æ²·ÈÀ½
			pUser->AddconfirmBankPass( 0, dwId, dwItemId );
		}
	}
}

void CDPSrvr::OnSfxHit( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	int idSfxHit;
	int nMagicPower;
	DWORD dwSkill;
	OBJID idAttacker;
	int	nDmgCnt;	// ÀÏ¹ÝÀûÀ¸·Ð 0, Áö¼Óµ¥¹ÌÁöÀÇ °æ¿ì Ã¹»§ÀÌÈÄ´Â 1ÀÌ»óÀÌ ³Ñ¾î¿Â´Ù. ÀÌ°æ¿ì´Â µ¥¹ÌÁöÀÇ 10%¸¸ ÁØ´Ù.
	float fDmgAngle, fDmgPower;
	PSfxHit pSfxHit		= NULL;
	CMover* pAttacker	= NULL;

	ar >> idSfxHit >> nMagicPower >> dwSkill >> idAttacker >> nDmgCnt >> fDmgAngle >> fDmgPower;		

	// idAttacker°¡ NULL_ID¸é ¾îÅÂÄ¿¸¦ dpidUser·Î ÇÑ´Ù.
	if( idAttacker == NULL_ID )
		pAttacker = g_UserMng.GetUser( dpidCache, dpidUser );	
	else
		pAttacker = prj.GetMover( idAttacker );

	if( IsValidObj( pAttacker ) == FALSE ) 
		return;

	pSfxHit	= pAttacker->m_sfxHitArray.GetSfxHit( idSfxHit );
	if( pSfxHit == NULL ) 
		return;

	CMover* pTarget	= prj.GetMover( pSfxHit->objid );

	/*
	// Ë¬	// 06-10-23
	if( dwSkill == SI_MAG_FIRE_HOTAIR )	
	{
		if( IsValidObj( pTarget ) && pTarget->IsLive() )
		{
			SFXHIT_INFO si	=
				{ pTarget->GetId(), nMagicPower, dwSkill, nDmgCnt, fDmgAngle, fDmgPower, pSfxHit->dwAtkFlags	};
			AttackBySFX( pAttacker, si );
		}
		return;
	}
	*/

	pAttacker->RemoveSFX( pSfxHit->objid, idSfxHit, ( IsInvalidObj( pTarget ) || pTarget->IsDie() ), dwSkill );
	pAttacker->m_sfxHitArray.RemoveSfxHit( idSfxHit, TRUE );	// ¹«Á¶°Ç Á¦°Å
}

// Å¬¶ó·ÎºÎÅÍ ¹ÞÀº idSfx¸¦ ¾î·¹ÀÌ¿¡ Ãß°¡½ÃÄÑµÒ
void CDPSrvr::OnSfxID( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID	idTarget;
	int		idSfxHit;
	DWORD	dwType,	dwSkill;
	int		nMaxDmgCnt;

	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		ar >> idTarget >> idSfxHit >> dwType >> dwSkill >> nMaxDmgCnt;
		pUser->m_sfxHitArray.Add( idSfxHit, idTarget, dwType, dwSkill, nMaxDmgCnt );		
	}
}

// °ø°ÝÀÌ ºø³ª°¡¼­ ÀúÀý·Î ¾ø¾îÁ³À»¶§ »èÁ¦ ¸í·É.
void CDPSrvr::OnSfxClear( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID	idMover = NULL_ID;
	int	  idSfxHit;

	ar >> idSfxHit;
	ar >> idMover;

	CMover *pMover;

	if( idMover == NULL_ID )
		pMover = g_UserMng.GetUser( dpidCache, dpidUser );
	else
		pMover = prj.GetMover( idMover );

	if( IsValidObj( pMover ) )
	{
		PSfxHit pSfxHit	= pMover->m_sfxHitArray.GetSfxHit( idSfxHit );
		pMover->m_sfxHitArray.RemoveSfxHit( idSfxHit, TRUE );
	}
}


void CDPSrvr::OnMeleeAttack( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwAtkMsg;
	OBJID objid;
	int nParam2, nParam3;
#ifdef __HACK_1023
	FLOAT fVal;
	ar >> dwAtkMsg >> objid >> nParam2 >> nParam3 >> fVal;
#else	// __HACK_1023
	ar >> dwAtkMsg >> objid >> nParam2 >> nParam3;
#endif	// __HACK_1023

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( pUser->GetIndex() == 0 )
		{
			WriteError( "PACKETTYPE_MELEE_ATTACK" );
			return;
		}
#ifdef __HACK_1023
		ItemProp* pHandItemProp	= pUser->GetActiveHandItemProp();
		FLOAT f	= pHandItemProp? pHandItemProp->fAttackSpeed: 0.0F;
		if( f != fVal )
		{
			pUser->AddDefinedText( TID_GAME_MODIFY_ATTACK_SPEED );
			return;
		}
#endif	// __HACK_1023

		CMover* pTargetObj	= prj.GetMover( objid );
		if( IsValidObj( pTargetObj ) )
		{
#ifdef __GAMEGUARD
			if (!pTargetObj->IsNPC() && !pTargetObj->IsPlayer())
				return;
#endif // __GAMEGUARD
#ifdef __PMA_FIX_ATKMSG
			if (pUser->m_pActMover->m_qMeleeAtkMsg.GetSize() > 500)
				return;
#endif
			int nRet = pUser->SendActMsg( (OBJMSG)dwAtkMsg, objid, nParam2, nParam3 );
			
			if( nRet == 0 && pUser->IsFly() == FALSE )
#ifdef __OPT_MEM_0811
				pUser->m_pActMover->m_qMeleeAtkMsg.AddTail( new ACTMSG( dwAtkMsg, objid, nParam2, nParam3 ) );
#else	// __OPT_MEM_0811
				pUser->m_pActMover->m_qMeleeAtkMsg.AddTail( ACTMSG( dwAtkMsg, objid, nParam2, nParam3 ) );
#endif	// __OPT_MEM_0811
			if( nRet != -2 )	// -2´Â ¸í·É ¿ÏÀü ¹«½Ã.
			{
				g_UserMng.AddMeleeAttack( pUser, dwAtkMsg, objid, nParam2, nParam3 );
			}
		}
	}
}

void CDPSrvr::OnMeleeAttack2( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwAtkMsg;
	OBJID objid;
	int nParam2, nParam3;
	ar >> dwAtkMsg >> objid >> nParam2 >> nParam3;
	
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( pUser->GetIndex() == 0 )
		{
			WriteError( "PACKETTYPE_MELEE_ATTACK2" );
			return;
		}

		CMover* pTargetObj	= prj.GetMover( objid );
		if( IsValidObj( pTargetObj ) )
		{		
#ifdef __GAMEGUARD
			if (!pTargetObj->IsNPC() && !pTargetObj->IsPlayer())
				return;
#endif // __GAMEGUARD
			int nRet = pUser->SendActMsg( (OBJMSG)dwAtkMsg, objid, nParam2, nParam3 );
			if( nRet == 0 )
#ifdef __OPT_MEM_0811
				pUser->m_pActMover->m_qMeleeAtkMsg.AddTail( new ACTMSG( dwAtkMsg, objid, nParam2, nParam3 ) );
#else	// __OPT_MEM_0811
				pUser->m_pActMover->m_qMeleeAtkMsg.AddTail( ACTMSG( dwAtkMsg, objid, nParam2, nParam3 ) );
#endif	// __OPT_MEM_0811
			
			if( nRet != -2 )	// -2´Â ¸í·É ¿ÏÀü ¹«½Ã.
				g_UserMng.AddMeleeAttack2( pUser, dwAtkMsg, objid, nParam2, nParam3 );
		}
	}
}


void CDPSrvr::OnMagicAttack( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwAtkMsg;
	OBJID objid;
	int nParam2, nParam3, nMagicPower, idSfxHit;
	ar >> dwAtkMsg >> objid >> nParam2 >> nParam3 >> nMagicPower >> idSfxHit;

	nParam2 = 0;		//  m_qMagicAtkMsg¿¡¼­ nParam2°¡ 0ÀÌ¸é range attackÀ¸·Î °£ÁÖµÈ´Ù.

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CMover* pTargetObj	= prj.GetMover( objid );

		if( IsValidObj( pTargetObj ) ) 
		{
#ifdef __PMA_FIX_ATKMSG
			if (pUser->m_pActMover->m_qMagicAtkMsg.GetSize() > 500)
				return;
#endif
			int nRet = pUser->DoAttackMagic( pTargetObj, nMagicPower, idSfxHit );
			
			if( nRet == 0 && pUser->IsFly() == FALSE )
#ifdef __OPT_MEM_0811
				pUser->m_pActMover->m_qMagicAtkMsg.AddTail( new MAGICATKMSG( dwAtkMsg, objid, nParam2, nParam3, nMagicPower, idSfxHit ) );
#else	// __OPT_MEM_0811
				pUser->m_pActMover->m_qMagicAtkMsg.AddTail( (OBJMSG)dwAtkMsg, objid, nParam2, nParam3, nMagicPower, idSfxHit );
#endif	// __OPT_MEM_0811
		}
	}
}

void CDPSrvr::OnRangeAttack( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{	
	DWORD dwAtkMsg;
	OBJID objid;
	DWORD dwItemID;
	int idSfxHit;

	ar >> dwAtkMsg >> objid >> dwItemID >> idSfxHit;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CMover* pTargetObj	= prj.GetMover( objid );

		if( IsValidObj( pTargetObj ) ) 
		{
#ifdef __GAMEGUARD
			if (!pTargetObj->IsNPC() && !pTargetObj->IsPlayer())
				return;
#endif // __GAMEGUARD
#ifdef __PMA_FIX_ATKMSG
			if (pUser->m_pActMover->m_qMagicAtkMsg.GetSize() > 500)
				return;
#endif
			if( pUser->DoAttackRange( pTargetObj, dwItemID, idSfxHit ) == 0 )
#ifdef __OPT_MEM_0811
				pUser->m_pActMover->m_qMagicAtkMsg.AddTail( new MAGICATKMSG( dwAtkMsg, objid, 1, dwItemID, 0, idSfxHit ) );
#else	// __OPT_MEM_0811
				pUser->m_pActMover->m_qMagicAtkMsg.AddTail( (OBJMSG)dwAtkMsg, objid, 1, dwItemID, 0, idSfxHit );
#endif	// __OPT_MEM_0811
		}
	}
}

void CDPSrvr::OnTeleSkill( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
//	OBJID objid;
	D3DXVECTOR3 vPos;
	ar >> vPos;
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		LPSKILL pSkill	= pUser->GetSkill( SI_MAG_MAG_BLINKPOOL );
		if( pSkill == NULL || pSkill->dwLevel == 0 )
			return;
		// ÇöÀç À§Ä¡ - Å¬¶ô¿öÅ© Áö¿ª x, ´ë»ó À§Ä¡ - Å¬¶ô¿öÅ© Áö¿ª o = ºÒ°¡
//		if( prj.IsGuildQuestRegion( pUser->GetPos() ) == FALSE && prj.IsGuildQuestRegion( vPos ) == TRUE )
		D3DXVECTOR3 v	= pUser->GetPos();
		if( prj.IsGuildQuestRegion( v ) == TRUE || prj.IsGuildQuestRegion( vPos ) )		// Çö ÁÂÇ¥, È¤Àº ´ë»ó ÁÂÇ¥°¡ Å¬¶ô¿öÅ© Áö¿ªÀÌ´Ù.
		{
			CWorld* pWorld	= pUser->GetWorld();
			if( !pWorld )
				return;
			if( fabs( pWorld->GetLandHeight( v ) - v.y ) > 1.0F || fabs( pWorld->GetLandHeight( vPos ) - vPos.y ) > 1.0F )
				return;
		}
		pUser->REPLACE( g_uIdofMulti, pUser->GetWorld()->GetID(), vPos, REPLACE_NORMAL, pUser->GetLayer() );
	}
}


void CDPSrvr::OnSetTarget( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID idTarget;
	BYTE bClear;
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		ar >> idTarget >> bClear;	// idTargetÀº MOVER¶ó°í °¡Á¤ÇÏÀÚ.

		if( bClear == 2 )		// 2 : Å¸°ÙÀâÀº³ðÀ» ±â¾ï.
			pUser->m_idSetTarget = idTarget;
		if( bClear < 2 )		// 0 / 1 : Å¸°ÙÀâÀº³ð¿¡°Ô ³ª¸¦ ±â·Ï / Å¸°ÙÀâÀº³ð¿¡°Ô¼­ ³ª¸¦ Áö¿ò.
		{
			CMover *pTarget = prj.GetMover( idTarget );		// Å¸°ÙÀÇ Æ÷ÀÎÅÍ
			if( IsValidObj( pTarget ) )
			{
#ifdef __GAMEGUARD
				if (!pTarget->IsNPC() && !pTarget->IsPlayer())
				{
					pUser->m_idSetTarget = NULL_ID;
					return;
				}
#endif // __GAMEGUARD
#ifdef __V21FIXES // no have idea for xD
				if (pUser->IsDie() == TRUE || pTarget->IsDie() == TRUE)
				{
					return;
				}
#endif
				if( bClear )	// Å¸°ÙÀÌ ÇØÁ¦‰ç´Ù.
				{
					if( pTarget->m_idTargeter == pUser->GetId() )	// ÀÚ±â°¡ Àâ¾Ò´ø Å¸°Ù¸¸ ÀÚ±â°¡ Ç®¼öÀÖ´Ù.
					{
						pTarget->m_idTargeter = NULL_ID;
#if __VER >= 10 // __LEGEND
						DWORD	dwTmpTick = GetTickCount();
						int	nTmpSkillID = pUser->m_pActMover->GetCastingSKillID();
						if (pUser->m_pActMover->GetCastingEndTick() > dwTmpTick && (nTmpSkillID == SI_KNT_HERO_DRAWING
#ifndef __RM_HERO_SKILL
							|| nTmpSkillID == SI_RIG_HERO_RETURN
#endif
							))
						{
							pUser->m_pActMover->SetCastingEndTick(0);
							pUser->m_pActMover->ClearState();				// »óÅÂ Å¬¸®¾îÇÏ°í ´Ù½Ã ¸ÂÃã.
						}
#endif  //#if __VER >= 10 // __LEGEND
					}
				}
				else
				{
					if( pTarget->m_idTargeter == NULL_ID )			// Å¸°ÙÀâÀº »ç¶÷ÀÌ ¾øÀ»¶§¸¸ Å¸°ÔÅÍ¸¦ ¹ÚÀ» ¼ö ÀÖ´Ù. 0819
						pTarget->m_idTargeter = pUser->GetId();		// pUser°¡ Å¸°ÙÀ» Àâ¾Ò´Ù.
				}
			}
		}
	}
}


void CDPSrvr::OnSnapshot( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE c;
	WORD	wHdr;
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		ar >> c;
		while( c-- )
		{
			ar >> wHdr;
#ifdef __OPTIMIZE
			OnPlayerDestPos(ar, pUser);
#else
			switch (wHdr)
			{
			case SNAPSHOTTYPE_DESTPOS:	OnPlayerDestPos(ar, pUser);	break;
			default:
			{
				// handler not found
				ASSERT(0);
				break;
			}
			}
#endif
		}
	}
}


void CDPSrvr::OnPlayerDestPos( CAr & ar, CUser* pUser )
{
	D3DXVECTOR3 vPos;
	BYTE fForward;
	ar >> vPos >> fForward;

	D3DXVECTOR3 vDistance	= pUser->GetPos() - vPos;
	if( D3DXVec3LengthSq( &vDistance ) > 1000000.0F )
	{
//		Error( "SNAPSHOTTYPE_DESTPOS" );
		return;
	}

#ifdef __IAOBJ0622
	CShip* pIAObj	= NULL;
	OBJID objidIAObj;
	ar >> objidIAObj;

	if( objidIAObj != NULL_ID )
	{
		pIAObj	= (CShip*)prj.GetCtrl( objidIAObj );
		if( IsValidObj( pIAObj ) == FALSE )
		{
			Error( "CShip object not found" );
			return;
		}
	}
#endif	// __IAOBJ0622

	bool bForward = (fForward != 0);

#ifdef __AFK_REWARD_SYSTEM
	pUser->m_dwLastWalkTick = GetTickCount();
	if (pUser->IsAfk())
	{

		pUser->m_bAfk = FALSE;
		g_UserMng.UpdateAfkState(pUser);
	}
#endif //__AFK_REWARD_SYSTEM

	pUser->m_pActMover->DefaultSet();
	pUser->BehaviorActionForceSet();	// ¸í·ÉÀÌ Çàµ¿ ¸í·ÉÀÌ¸é °­Á¦ µ¿±âÇÏ°í, ¹«ºù ¸í·ÉÀÌ¸é ¹«½ÃÇÑ´Ù.

#ifdef __IAOBJ0622
	if( pIAObj )
		pUser->SetDestPos( pIAObj, vPos );
	else
		pUser->SetDestPos( vPos, bForward );
#else	// __IAOBJ0622
	pUser->SetDestPos( vPos, bForward );
#endif	// __IAOBJ0622

#ifdef __IAOBJ0622
	g_UserMng.AddSetDestPos( pUser, vPos, bForward, objidIAObj );
#else	// __IAOBJ0622
	g_UserMng.AddSetDestPos( pUser, vPos, bForward );
#endif	// __IAOBJ0622
}
/*
void CDPSrvr::OnPlayerDestAngle( CAr & ar, CUser* pUser )
{
	float fDestAngle;
	BYTE fLeft;
	ar >> fDestAngle >> fLeft;

	pUser->SetDestAngle( fDestAngle, (bool)(fLeft != 0) );
	g_UserMng.AddSetDestAngle( pUser, fDestAngle, fLeft );
}
*/
void CDPSrvr::OnModifyMode( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		DWORD dwMode;
		BYTE f;
		u_long idFrom;

		ar >> dwMode >> f >> idFrom;

#ifdef __HACK_0516
		DPID dpid;
		ar >> dpid;
		if( pUser->m_Snapshot.dpidUser != dpid )
		{
			Error( "[%s] try to hack : PACKETTYPE_MODIFYMODE", pUser->GetName() );
			return;
		}
		
		if( !pUser->IsAuthHigher(AUTH_GAMEMASTER) )
        {
            Error( "[%s] try to hack with dpid : PACKETTYPE_MODIFYMODE", pUser->GetName() );
            return;
        }
#endif	// __HACK_0516
#ifdef __GAMEGUARD
		if (!pUser->IsAuthHigher(AUTH_GAMEMASTER))
		{
			if (pUser->m_dwMode & (TRANSPARENT_MODE))
			{
				pUser->SetNotMode(TRANSPARENT_MODE);
				g_UserMng.AddModifyMode(pUser);
				return;
			}
			if (pUser->m_dwMode & (EVENT_OLDBOY_MODE | QUERYSETPLAYERNAME_MODE))
			{
				pUser->SetNotMode(EVENT_OLDBOY_MODE | QUERYSETPLAYERNAME_MODE);
				g_UserMng.AddModifyMode(pUser);
				return;
			}
		}

		if (!pUser->IsAuthHigher(AUTH_GAMEMASTER2))
		{
			if (pUser->m_dwMode & (MATCHLESS_MODE | ONEKILL_MODE | MATCHLESS2_MODE))
			{
				pUser->SetNotMode(MATCHLESS_MODE | ONEKILL_MODE | MATCHLESS2_MODE);
				g_UserMng.AddModifyMode(pUser);
				return;
			}
		}
#endif // __GAMEGUARD
		if( f )
			pUser->m_dwMode		|= dwMode;
		else
			pUser->m_dwMode		&= ~dwMode;

		g_UserMng.AddModifyMode( pUser );
	}
}

// ¿î¿µÀÚÀÇ ¼ÒÈ¯ ¸í·É¾î 
void CDPSrvr::OnSummonPlayer(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		u_long idOperator;
		DWORD dwWorldID;
		D3DXVECTOR3 vPos;
		u_long uIdofMulti;

		ar >> idOperator;
		ar >> dwWorldID;
		ar >> vPos;
		ar >> uIdofMulti;

#ifdef __HACK_0516
		DPID dpid;
		ar >> dpid;
		if (pUser->m_Snapshot.dpidUser != dpid)
		{
			Error("[%s] try to hack : PACKETTYPE_SUMMONPLAYER", pUser->GetName());
			return;
		}
#endif	// __HACK_0516
#ifdef __LAYER_1015
		int nLayer;
		ar >> nLayer;
#endif	// __LAYER_1015

		if (!pUser->GetWorld())
		{
			WriteError("PACKETTYPE_SUMMONPLAYER//1");
			return;
		}

		pUser->REPLACE(uIdofMulti, dwWorldID, vPos, REPLACE_FORCE, nLayer);
#ifdef __GAMEGUARD
		if (!pUser->IsAuthHigher(AUTH_GENERAL) && pUser->m_dwLastTeleport + SEC(8) > GetTickCount())
		{
			pUser->m_dwLastTeleport = GetTickCount();
			REPORT_HACK;
		}
#endif // __GAMEGUARD
	}
}

void CDPSrvr::OnTeleportPlayer(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
		u_long idOperator;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	CWorld* pWorld;
	if (IsValidObj(pUser) && (pWorld = pUser->GetWorld()))
	{
		ar >> idOperator;
#ifdef __HACK_0516
		DPID dpid;
		ar >> dpid;
		if (pUser->m_Snapshot.dpidUser != dpid)
		{
			Error("[%s] try to hack : PACKETTYPE_TELEPORTPLAYER", pUser->GetName());
			return;
		}
#endif	// __HACK_0516
#ifdef __LAYER_1015
		g_DPCoreClient.SendSummonPlayer(pUser->m_idPlayer, pWorld->GetID(), pUser->GetPos(), idOperator, pUser->GetLayer());
#else	// __LAYER_1015
		g_DPCoreClient.SendSummonPlayer(pUser->m_idPlayer, pWorld->GetID(), pUser->GetPos(), idOperator);
#endif	// __LAYER_1015
#ifdef __GAMEGUARD
		if (!pUser->IsAuthHigher(AUTH_GENERAL) && pUser->m_dwLastTeleport + SEC(8) > GetTickCount())
		{
			pUser->m_dwLastTeleport = GetTickCount();
			REPORT_HACK;
		}
#endif // __GAMEGUARD
	}
}

void CDPSrvr::OnChangeFace( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long objId;
	DWORD dwFaceNum;
	int cost;

#ifdef __NEWYEARDAY_EVENT_COUPON
	BOOL bUseCoupon;
#ifdef __GAMEGUARD
	ar >> objId >> dwFaceNum >> bUseCoupon;
#else // __GAMEGUARD
	ar >> objId >> dwFaceNum >> cost >> bUseCoupon;
#endif // __GAMEGUARD
#else //__NEWYEARDAY_EVENT_COUPON
#ifdef __GAMEGUARD
	ar >> objId >> dwFaceNum;
#else // __GAMEGUARD
	ar >> objId >> dwFaceNum >> cost;
#endif // __GAMEGUARD
#endif //__NEWYEARDAY_EVENT_COUPON
	
#ifdef __GAMEGUARD
	if (dwFaceNum >= MAX_HEAD || dwFaceNum < 0)
		return;
#endif // __GAMEGUARD

	cost = CHANGE_FACE_COST;
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{	
#ifdef __NEWYEARDAY_EVENT_COUPON
		if(!bUseCoupon)
		{
#ifdef __GAMEGUARD
			if (pUser->GetGold() < CHANGE_FACE_COST)
#else // __GAMEGUARD
			if (pUser->GetGold() < cost)
#endif // __GAMEGUARD
			{
				pUser->AddDefinedText( TID_GAME_LACKMONEY, "" );
				return;
			}
#ifdef __GAMEGUARD
			if (CHANGE_FACE_COST < 0)
				return;

			pUser->AddGold(-(CHANGE_FACE_COST));
#else // __GAMEGUARD
			pUser->AddGold(-(cost));
#endif // __GAMEGUARD
		}
		else
		{
			CItemElem* pItemElem = NULL;
			pItemElem = pUser->m_Inventory.GetAtItemId( II_SYS_SYS_SCR_FACEOFFFREE );
			if( IsUsableItem( pItemElem ) == FALSE )
			{
				pUser->AddDefinedText( TID_GAME_WARNNING_COUPON, "" );
				return;
			}
			pUser->UpdateItem( (BYTE)( pItemElem->m_dwObjId ), UI_NUM, pItemElem->m_nItemNum - 1 );
		}
		pUser->SetHead(dwFaceNum);
#else //__NEWYEARDAY_EVENT_COUPON
#ifdef __GAMEGUARD
		if (pUser->GetGold() < CHANGE_FACE_COST)
#else // __GAMEGUARD
		if (pUser->GetGold() < cost)
#endif // __GAMEGUARD
		{
			pUser->AddDefinedText( TID_GAME_LACKMONEY, "" );
			return;
		}
		pUser->SetHead(dwFaceNum);
#ifdef __GAMEGUARD
		pUser->AddGold(-(CHANGE_FACE_COST));
#else // __GAMEGUARD
		pUser->AddGold(-(cost));
#endif // __GAMEGUARD
#endif //__NEWYEARDAY_EVENT_COUPON
		g_UserMng.AddChangeFace( objId, dwFaceNum );
	}
}

void CDPSrvr::OnExpUp(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		EXPINTEGER nExp;
		ar >> nExp;

		if (pUser->AddExperience(nExp, TRUE, TRUE, TRUE))
			pUser->LevelUpSetting();
		else
			pUser->ExpUpSetting();

		pUser->AddSetExperience(pUser->GetExp1(), (WORD)pUser->m_nLevel, pUser->m_nSkillPoint, pUser->m_nSkillLevel);

#ifdef __REBIRTH
		if (pUser->IsLegendHeroUltimate() // is max job
			&& pUser->GetExpPercent() >= 9999 // has max exp
			&& pUser->GetCampusPoint() < MAX_REBIRTH // doesnt have max rebirths
			&& pUser->GetLevel() >= 298) // is level 300
		{
			pUser->InitLevelRebirth(pUser->m_nJob - 0, 200); // rebirth
		}
#endif


	}
}

void	CDPSrvr::OnChangeJob( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
// Ë¬: hacked
	int nJob;
	BOOL bGamma = TRUE;
	ar >> nJob;
	ar >> bGamma;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( TRUE == IsValidObj( ( CObj* )pUser ) )
	{
		if( bGamma )
		{			
			if( pUser->IsBaseJob() )	// 1Â÷ ÀüÁ÷
			{
				if( pUser->GetLevel() != MAX_JOB_LEVEL )
				{
					pUser->AddDefinedText( TID_GAME_CHGJOBLEVEL15 ); // "·¹º§ 15°¡ µÇ¾ß ÀüÁ÷ÇÒ¼ö ÀÖ½À´Ï´Ù"
					return;
				}			
				
				if( pUser->AddChangeJob( nJob ) )
				{
					( (CUser*)pUser )->AddSetChangeJob( nJob );
					g_UserMng.AddNearSetChangeJob( (CMover*)pUser, nJob, &pUser->m_aJobSkill[MAX_JOB_SKILL] );
					g_dpDBClient.SendLogLevelUp( (CUser*)pUser, 4 );
#if __VER >= 11 // __SYS_PLAYER_DATA
					g_dpDBClient.SendUpdatePlayerData( pUser );
#else	// __SYS_PLAYER_DATA
					g_DPCoreClient.SendPartyMemberJob( (CUser*)pUser );
					g_DPCoreClient.SendFriendChangeJob( (CUser*)pUser );
					if( pUser->m_idGuild != 0 )
						g_DPCoreClient.SendGuildChangeJobLevel( (CUser*)pUser );
#endif	// __SYS_PLAYER_DATA

					return;
				}
				
			}
			else
			if( pUser->IsExpert() )
			{
				if( pUser->GetLevel() < MAX_JOB_LEVEL + MAX_EXP_LEVEL )
				{
					pUser->AddDefinedText( TID_LIMIT_CHANGEJOBLEVEL, "" );	// 60·¹º§ÀÌ µÇ¾ß ÀüÁ÷À» ÇÒ¼ö ÀÖ½À´Ï´Ù
					return;
				}
				
				if( pUser->AddChangeJob( nJob ) )
				{
					( (CUser*)pUser )->AddSetChangeJob( nJob );
					g_UserMng.AddNearSetChangeJob( (CMover*)pUser, nJob, &pUser->m_aJobSkill[MAX_JOB_SKILL] );
					g_dpDBClient.SendLogLevelUp( (CUser*)pUser, 4 );
#if __VER >= 11 // __SYS_PLAYER_DATA
					g_dpDBClient.SendUpdatePlayerData( pUser );
#else	// __SYS_PLAYER_DATA
					g_DPCoreClient.SendPartyMemberJob( (CUser*)pUser );
					g_DPCoreClient.SendFriendChangeJob( (CUser*)pUser );
					if( pUser->m_idGuild != 0 )
						g_DPCoreClient.SendGuildChangeJobLevel( (CUser*)pUser );
#endif	// __SYS_PLAYER_DATA
					return;
				}
			}
		}
		else
		{
			CItemElem* pItemElem = pUser->m_Inventory.GetAtItemId( II_SYS_SYS_SCR_CHACLA );
			if( IsUsableItem( pItemElem ) == FALSE || pUser->IsBaseJob() || pUser->GetJob() == nJob ) 
			{	// ÀÎº¥Åä¸®¿¡ ¾ÆÀÌÅÛÀÌ ¾ø°Å³ª ¹æ¶ûÀÚ°Å³ª °°Àº Á÷¾÷À» ¹Ù±¸·Á¸é ¸®ÅÏ
				return;
			}

			if( pUser->IsExpert() )
			{
				if( JOB_VAGRANT == nJob || MAX_EXPERT <= nJob)	// Expert °è¿­ÀÌ ¾Æ´Ï¸é ¸®ÅÏ
					return;
			}
			else
			{
				if( nJob < MAX_EXPERT || MAX_LEGEND_HERO_ULTIMATE <= nJob )	// Pro °è¿­ÀÌ ¾Æ´Ï¸é ¸®ÅÏ
					return;
			}

			for( DWORD dwParts = 0; dwParts < MAX_HUMAN_PARTS; dwParts++ )
			{
				if( dwParts == PARTS_HEAD || dwParts == PARTS_HAIR || dwParts == PARTS_RIDE )
					continue;
				CItemElem* pArmor	= pUser->m_Inventory.GetEquip( dwParts );
				if( pArmor )
					return;
			}

			pUser->InitLevel( nJob, pUser->GetLevel(), FALSE );
			ItemProp* pItemProp = pItemElem->GetProp();
			if( pItemProp && pItemProp->dwSfxObj3 != -1 )
				g_UserMng.AddCreateSfxObj((CMover *)pUser, pItemElem->GetProp()->dwSfxObj3, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
			pUser->AddDefinedText( TID_GAME_CHANGECLASS, "%s", prj.m_aJob[pUser->GetJob()].szName );
			
			// »ó¿ëÈ­ ¾ÆÀÌÅÛ »ç¿ë ·Î±× »ðÀÔ
			g_dpDBClient.SendLogSMItemUse( "1", pUser, pItemElem, pItemProp );
			pUser->RemoveItem( (BYTE)pItemElem->m_dwObjId, 1 );
		}
	}
}

void	CDPSrvr::OnLogItem( LogItemInfo & info, CItemElem* pItemElem, int nItemCount )
{
	if( pItemElem != NULL )
	{
		info.ItemNo = pItemElem->GetSerialNumber();
		//info.ItemName = pItemElem->GetProp()->szName;
		_stprintf( info.szItemName, "%d", pItemElem->GetProp()->dwID );
		info.itemNumber = nItemCount;
		info.nItemResist = pItemElem->m_bItemResist;
		info.nResistAbilityOption = pItemElem->m_nResistAbilityOption;
		info.nAbilityOption = pItemElem->GetAbilityOption();
		info.Negudo = pItemElem->m_nHitPoint;
		info.MaxNegudo	= pItemElem->m_nRepair;
		info.m_bCharged = pItemElem->m_bCharged;
		info.m_dwKeepTime = pItemElem->m_dwKeepTime;
#if __VER >= 12 // __EXT_PIERCING
		info.nPiercedSize = pItemElem->GetPiercingSize();
		for( int i=0; i<pItemElem->GetPiercingSize(); i++ )
			info.adwItemId[i] = pItemElem->GetPiercingItem( i );
		info.nUMPiercedSize = pItemElem->GetUltimatePiercingSize();
		for( int i=0; i<pItemElem->GetUltimatePiercingSize(); i++ )
			info.adwUMItemId[i] = pItemElem->GetUltimatePiercingItem( i );
#else // __EXT_PIERCING
		info.nPiercedSize = pItemElem->GetPiercingSize();
		info.adwItemId0 = pItemElem->GetPiercingItem( 0 );
		info.adwItemId1 = pItemElem->GetPiercingItem( 1 );
		info.adwItemId2 = pItemElem->GetPiercingItem( 2 );
		info.adwItemId3 = pItemElem->GetPiercingItem( 3 );
#if __VER >= 9 // __ULTIMATE
		info.adwItemId4 = pItemElem->GetPiercingItem( 4 );
#endif // __ULTIMATE
#endif // __EXT_PIERCING
#if __VER >= 11 // __SYS_IDENTIFY
		info.m_iRandomOptItemId = pItemElem->GetRandomOptItemId();
#else	// __SYS_IDENTIFY
		info.m_nRandomOptItemId = pItemElem->GetRandomOptItemId();
#endif	// __SYS_IDENTIFY
#if __VER >= 9 // __PET_0410
		if( pItemElem->m_pPet )
		{
			CPet* pPet = pItemElem->m_pPet;

			info.nPetKind = pPet->GetKind();
			info.nPetLevel = pPet->GetLevel();
			info.dwPetExp = pPet->GetExp();
			info.wPetEnergy = pPet->GetEnergy();
			info.wPetLife = pPet->GetLife();
			info.nPetAL_D = pPet->GetAvailLevel( PL_D );
			info.nPetAL_C = pPet->GetAvailLevel( PL_C );
			info.nPetAL_B = pPet->GetAvailLevel( PL_B );
			info.nPetAL_A = pPet->GetAvailLevel( PL_A );
			info.nPetAL_S = pPet->GetAvailLevel( PL_S );
		}
		// mirchang_100514 TransformVisPet_Log
#if __VER >= 15 // __PETVIS
		else if( pItemElem->IsTransformVisPet() == TRUE )
		{
			info.nPetKind = (BYTE)100;
		}
#endif // __PETVIS
		// mirchang_100514 TransformVisPet_Log
#endif // __PET_0410
	}

	BEFORESENDDUAL( ar, PACKETTYPE_LOG_ALLITEM, DPID_UNKNOWN, DPID_UNKNOWN );
	ar.WriteString( info.Action );
	ar.WriteString( info.SendName );
	ar.WriteString( info.RecvName );
	ar << info.WorldId;
	ar << info.Gold;
	ar << info.Gold2;
	ar << info.ItemNo; // ¾ÆÀÌÅÛ °íÀ¯¹øÈ£
	ar << info.Negudo; // ³»±¸µµ 
	ar << info.MaxNegudo; // ³»±¸µµ 
	if( _tcslen( info.szItemName ) == 0 )
	{
		_stprintf( info.szItemName, "%d", -1 );
	}
	ar.WriteString( info.szItemName );
	ar << info.itemNumber;
	ar << info.nAbilityOption;
	ar << info.Gold_1;
	ar << info.nSlot;
	ar << info.nSlot1;
	ar << info.nItemResist;
	ar << info.nResistAbilityOption;
	ar << info.m_bCharged;
	ar << info.m_dwKeepTime;
#if __VER >= 12 // __EXT_PIERCING
	ar << info.nPiercedSize;
	for( int i=0; i<info.nPiercedSize; i++ )
		ar << info.adwItemId[i];
	ar << info.nUMPiercedSize;
	for( int i=0; i<info.nUMPiercedSize; i++ )
		ar << info.adwUMItemId[i];
#else // __EXT_PIERCING
	ar << info.nPiercedSize;
	ar << info.adwItemId0;
	ar << info.adwItemId1;
	ar << info.adwItemId2;
	ar << info.adwItemId3;
#if __VER >= 9 // __ULTIMATE
	ar << info.adwItemId4;
#endif // __ULTIMATE
#endif // __EXT_PIERCING
#if __VER >= 11 // __SYS_IDENTIFY
	ar << info.m_iRandomOptItemId;
#else	// __SYS_IDENTIFY
	ar << info.m_nRandomOptItemId;
#endif	// __SYS_IDENTIFY
#if __VER >= 9 // __PET_0410
	ar << info.nPetKind;
	ar << info.nPetLevel;
	ar << info.dwPetExp;
	ar << info.wPetEnergy;
	ar << info.wPetLife;
	ar << info.nPetAL_D;
	ar << info.nPetAL_C;
	ar << info.nPetAL_B;
	ar << info.nPetAL_A;
	ar << info.nPetAL_S;
#endif // __PET_0410
	
	SEND( ar, &g_dpDBClient, DPID_SERVERPLAYER );
}


void CDPSrvr::OnMotion( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( pUser->GetIndex() == 0 )
		{
			WriteError( "PACKETTYPE_MOTION" );
			return;
		}

		DWORD dwMsg;
		ar >> dwMsg;

		if( pUser->SendActMsg( (OBJMSG)dwMsg ) == 1 )
		{
//#ifdef __JEFF_VER_8
//			if( dwMsg != OBJMSG_STANDUP )
//#endif	// __JEFF_VER_8
			{
				pUser->ClearDest();
				pUser->ClearDestAngle();
				memset( &pUser->m_CorrAction, 0, sizeof(CORR_ACTION) );
			}
			g_UserMng.AddMotion( pUser, dwMsg );
		}
		else
			pUser->AddMotionError();
	}
}

void CDPSrvr::OnRepairItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		BYTE c, nId;
		ar >> c;

		if( c == 0 || c > MAX_REPAIRINGITEM )
			return;

		CItemElem* apItemRepair[MAX_REPAIRINGITEM];
		int		anRepair[MAX_REPAIRINGITEM];
		memset( anRepair, 0, sizeof(int) * MAX_REPAIRINGITEM );

		CItemElem* pItemElem;
		int nCost	= 0;
		for( int i = 0; i < c; i++ )
		{
			apItemRepair[i]		= NULL;
			ar >> nId;
			pItemElem	= pUser->m_Inventory.GetAtId( nId );
			if( pItemElem )
			{
				ItemProp* pItemProp	= pItemElem->GetProp();
				if( pItemProp && pItemProp->dwItemKind2 >= IK2_WEAPON_HAND && pItemProp->dwItemKind2 <= IK2_ARMORETC && 
					pItemElem->m_nHitPoint < (int)( pItemProp->dwEndurance ) && pItemElem->m_nRepair < pItemProp->nMaxRepair )
				{
					int nRepair	= 100 - ( ( pItemElem->m_nHitPoint * 100 ) / pItemProp->dwEndurance );
					if( nRepair == 0 )
						continue;
					nCost	+= nRepair * ( pItemProp->dwCost / 1000 + 1 );
					apItemRepair[i]		= pItemElem;
					anRepair[i]		= nRepair;
				}
			}
		}

		if( pUser->GetGold() < nCost )
			return;

		for( int i = 0; i < c; i++ )
		{
			if( apItemRepair[i] )
			{
				pUser->UpdateItem( (BYTE)apItemRepair[i]->m_dwObjId, UI_HP, apItemRepair[i]->GetProp()->dwEndurance );
				pUser->UpdateItem( (BYTE)apItemRepair[i]->m_dwObjId, UI_RN, apItemRepair[i]->m_nRepairNumber + anRepair[i] );
			}
		}
#if __VER < 11 // __REMOVE_ENDURANCE
		pUser->AddGold( -nCost );
#endif // __REMOVE_ENDURANCE
		pUser->AddDefinedText( TID_GAME_REPAIRITEM );
	}
}

void CDPSrvr::OnSetHair( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE nHair, nR, nG, nB;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __NEWYEARDAY_EVENT_COUPON
		BOOL bUseCoupon;
		ar >> nHair >> nR >> nG >> nB >> bUseCoupon;
#else //__NEWYEARDAY_EVENT_COUPON
		ar >> nHair >> nR >> nG >> nB;// >> nCost;
#endif //__NEWYEARDAY_EVENT_COUPON

		int nCost;
	
		nCost	= CMover::GetHairCost( (CMover*)pUser, nR, nG, nB, nHair );

#ifdef __NEWYEARDAY_EVENT_COUPON
		if( pUser->GetGold() < nCost  && !bUseCoupon)
#else //__NEWYEARDAY_EVENT_COUPON
		if( pUser->GetGold() < nCost )
#endif //__NEWYEARDAY_EVENT_COUPON
		{
			pUser->AddDefinedText( TID_GAME_LACKMONEY, "" );
			return;
		}

		pUser->SetHair( nHair );
		float r, g, b;
		r	= (float)nR / 255.0f;
		g	= (float)nG / 255.0f;
		b	= (float)nB / 255.0f;

#ifdef __NEWYEARDAY_EVENT_COUPON
		if(!bUseCoupon)
			pUser->AddGold( -( nCost ) );
		else
		{
			CItemElem* pItemElem = NULL;
			pItemElem = pUser->m_Inventory.GetAtItemId( II_SYS_SYS_SCR_HAIRCHANGE );
			if( IsUsableItem( pItemElem ) == FALSE )
			{
				pUser->AddDefinedText( TID_GAME_WARNNING_COUPON, "" );
				return;
			}
			pUser->UpdateItem( (BYTE)( pItemElem->m_dwObjId ), UI_NUM, pItemElem->m_nItemNum - 1 );
		}
#else //__NEWYEARDAY_EVENT_COUPON
		pUser->AddGold( -( nCost ) );
#endif //__NEWYEARDAY_EVENT_COUPON

		pUser->SetHairColor( r, g, b );
		g_UserMng.AddSetHair( pUser, nHair, nR, nG, nB );
	}
}

void CDPSrvr::OnBlock( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
#ifdef __GAMEGUARD
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;
#endif // __GAMEGUARD
	BYTE nGu;
	u_long uidPlayerTo, uidPlayerFrom;
	char szNameTo[MAX_NAME] = {0,};
	char szNameFrom[MAX_NAME] = {0,};
	ar >> nGu;
	ar.ReadString( szNameTo, MAX_NAME );
	ar.ReadString( szNameFrom, MAX_NAME );

#if __VER >= 11 // __SYS_PLAYER_DATA
	uidPlayerTo	 = CPlayerDataCenter::GetInstance()->GetPlayerId( szNameTo );
	uidPlayerFrom	= CPlayerDataCenter::GetInstance()->GetPlayerId( szNameFrom );
#else	// __SYS_PLAYER_DATA
	uidPlayerTo = prj.GetPlayerID( szNameTo );
	uidPlayerFrom = prj.GetPlayerID( szNameFrom );
#endif	// __SYS_PLAYER_DATA

#ifdef __GAMEGUARD
	if (pUser->m_idPlayer != uidPlayerFrom)
		return;
#endif // __GAMEGUARD

	if( uidPlayerTo > 0 && uidPlayerFrom > 0 )
		g_DPCoreClient.SendBlock( nGu, uidPlayerTo, szNameTo, uidPlayerFrom );
}

#if __VER >= 12 // __J12_0
DWORD WhatEleCard( DWORD dwItemType )
{	// ¼Ó¼º Á¦·Ã ¿ë Ä«µåÀÇ Á¾·ù°¡ 
	// ¼Ó¼º ´ç ÇÏ³ª·Î ÅëÇÕµÊ
	switch( dwItemType )
	{
		case SAI79::FIRE:
			return II_GEN_MAT_ELE_FLAME;
		case SAI79::WATER:
			return II_GEN_MAT_ELE_RIVER;
		case SAI79::ELECTRICITY:
			return II_GEN_MAT_ELE_GENERATOR;
		case SAI79::EARTH:
			return II_GEN_MAT_ELE_DESERT;
		case SAI79::WIND:
			return II_GEN_MAT_ELE_CYCLON;
		default:
			return 0;
	}
}
#else	// __J12_0
DWORD WhatEleCard( DWORD dwLV, DWORD dwItemType )
{
	switch( dwItemType )
	{
		case SAI79::FIRE:
			return ( dwLV <= 4 ) ? II_GEN_MAT_ELE_TOUCH: II_GEN_MAT_ELE_FLAME;
		case SAI79::WATER:
			return ( dwLV <= 4 ) ? II_GEN_MAT_ELE_LAKE: II_GEN_MAT_ELE_RIVER;
		case SAI79::ELECTRICITY:
			return ( dwLV <= 4 ) ? II_GEN_MAT_ELE_VOLTAGE: II_GEN_MAT_ELE_GENERATOR;
		case SAI79::EARTH:
			return ( dwLV <= 4 ) ? II_GEN_MAT_ELE_STONE: II_GEN_MAT_ELE_DESERT;
		case SAI79::WIND:
			return ( dwLV <= 4 ) ? II_GEN_MAT_ELE_GALE: II_GEN_MAT_ELE_CYCLON;
		default:
			return 0;
	}
}
#endif	// __J12_0

void CDPSrvr::OnPiercingSize( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwId1, dwId2, dwId3;
	
	ar >> dwId1;
	ar >> dwId2;
	ar >> dwId3;
	
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
#if __VER >= 12 // __EXT_PIERCING
	if( IsValidObj( pUser ) )
		CItemUpgrade::GetInstance()->OnPiercingSize( pUser, dwId1, dwId2, dwId3 );
#else // __EXT_PIERCING
	if( IsValidObj( pUser ) )
	{
		CItemElem* pItemElem0	= pUser->m_Inventory.GetAtId( dwId1 );
		CItemElem* pItemElem1	= pUser->m_Inventory.GetAtId( dwId2 );
		CItemElem* pItemElem2	= pUser->m_Inventory.GetAtId( dwId3 );

		if( IsUsableItem( pItemElem0 ) == FALSE || IsUsableItem( pItemElem1 ) == FALSE )
			return;

		// Ë¬
		if( pUser->m_vtInfo.GetOther() )	// °Å·¡ÁßÀÎ ´ë»óÀÌ ÀÖÀ¸¸é?
			return;
		if( pUser->m_vtInfo.VendorIsVendor() )		// ³»°¡ ÆÈ°í ÀÖÀ¸¸é?
			return;

		int nError = 1;
		if( IsPiercingSize( pUser, pItemElem0, pItemElem1, pItemElem2, nError ) == FALSE )
		{
			if( nError != 1 )
				pUser->AddDefinedText( nError );
			return;
		}

		LogItemInfo aLogItem;
		aLogItem.SendName = pUser->GetName();
		aLogItem.RecvName = "PIERCING";
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		
		int nCost = pItemElem0->GetProp()->dwItemRare * ( 200  + ( pItemElem0->GetPiercingSize()+1) * 200 );

		if( 0 < nCost )
		{
			if( pUser->GetGold() < nCost )
			{
				pUser->AddDefinedText( TID_GAME_LACKMONEY , "" );
				return;
			}
				
			pUser->AddGold( -( nCost ) );

			aLogItem.Gold = pUser->GetGold() + nCost;
			aLogItem.Gold2 = pUser->GetGold();
			aLogItem.Action = "!";
			//aLogItem.ItemName = "SEED";
			_stprintf( aLogItem.szItemName, "%d", II_GOLD_SEED1 );
			aLogItem.itemNumber = nCost;
			OnLogItem( aLogItem );
		}
		else
		{
			return;
		}
		aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();


		int nPersent = 0;
		int n8DicePersent[4] = { 80, 50, 20, 5 };
#if __VER >= 8 //__Y_NEW_ENCHANT
		if( pItemElem1->GetProp()->dwID == II_GEN_MAT_MOONSTONE
			|| pItemElem1->GetProp()->dwID == II_GEN_MAT_MOONSTONE_1 )
			nPersent = n8DicePersent[pItemElem0->GetPiercingSize()];
#else //__Y_NEW_ENCHANT
		int n10DicePersent[4] = { 85, 55, 25, 10 };
		if( pItemElem1->GetProp()->dwID == II_GEN_MAT_DIE_EIGHT )
			nPersent = n8DicePersent[pItemElem0->GetPiercingSize()];
		else if( pItemElem1->GetProp()->dwID == II_GEN_MAT_DIE_TEN )
			nPersent = n10DicePersent[pItemElem0->GetPiercingSize()];
#endif //__Y_NEW_ENCHANT

		if( xRandom( 100 ) > nPersent )
		{	// ½ÇÆÐ
			aLogItem.Action = "!";
			OnLogItem( aLogItem, pItemElem0, pItemElem0->m_nItemNum );
			pUser->AddPlaySound( SND_INF_UPGRADEFAIL );
			g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_INT_FAIL, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
			pUser->AddDefinedText( TID_MMI_PIERCINGFAIL , "" );

			if( pItemElem2 == NULL )								// »ó¿ëÈ­ ¾ÆÀÌÅÛÀ» »ç¿ëÇÏÁö ¾Ê¾Ò´Ù¸é 
				pUser->RemoveItem( dwId1, (short)1 );	// ÇÇ¾î½Ì ´ë»ó ¾ÆÀÌÅÛÀº »èÁ¦µÈ´Ù.
		}
		else
		{	// ¼º°ø			
			pUser->AddPlaySound( SND_INF_UPGRADESUCCESS );			
			g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);			
			pUser->UpdateItem( (BYTE)pItemElem0->m_dwObjId, UI_PIERCING_SIZE, pItemElem0->GetPiercingSize() + 1 );
			pUser->AddDefinedText( TID_MMI_PIERCINGSUCCESS , "" );

			aLogItem.Action = "#";
			OnLogItem( aLogItem, pItemElem0, pItemElem0->m_nItemNum );
		}
		aLogItem.Action = "!";
		OnLogItem( aLogItem, pItemElem1, pItemElem1->m_nItemNum );
		
		// ´ÙÀÌ½º¿Í À¯·á¾ÆÀÌÅÛ »èÁ¦ÇÑ´Ù.
		pUser->RemoveItem( dwId2, (short)1 );
		
		if( dwId3 != NULL_ID )
		{
			aLogItem.Action = "!";
			if( IsUsableItem( pItemElem2 ) )
			{
				OnLogItem( aLogItem, pItemElem2, pItemElem2->m_nItemNum );
				g_dpDBClient.SendLogSMItemUse( "2", pUser, pItemElem2, pItemElem2->GetProp() );
				pUser->RemoveItem( dwId3, (short)1 );
			}
			else
			{
				OnLogItem( aLogItem, NULL, 0 );
			}
		}
	}
#endif // __EXT_PIERCING
}

void CDPSrvr::OnItemTransy( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objidTarget, objidTransy;
	ar >> objidTarget;
	ar >> objidTransy;
#ifdef __SYS_ITEMTRANSY
	DWORD dwChangeId;
	BOOL bCash;
	ar >> dwChangeId;
	ar >> bCash;
#endif // __SYS_ITEMTRANSY
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __SYS_ITEMTRANSY
		CItemUpgrade::GetInstance()->OnItemTransy( pUser, objidTarget, objidTransy, dwChangeId, bCash );
#else // __SYS_ITEMTRANSY
		CItemElem* pItemElemTarget = pUser->m_Inventory.GetAtId( objidTarget );
		CItemElem* pItemElemTransy = pUser->m_Inventory.GetAtId( objidTransy );

		// »ç¿ëÁßÀÎ ¾ÆÀÌÅÛÀÎÁö °Ë»ç
		if( IsUsableItem( pItemElemTarget ) == FALSE || IsUsableItem( pItemElemTransy ) == FALSE )
			return;

		// ÀåÂøµÇ¾î ÀÖ´Â ¾ÆÀÌÅÛÀÌ¸é ¸®ÅÏ( ¿À¶óÀÌ~~~ ¤»¤» )
		if( pUser->m_Inventory.IsEquip( objidTarget ) || pUser->m_Inventory.IsEquip( objidTransy ) )
		{
			pUser->AddDefinedText( TID_GAME_EQUIPPUT , "" );
			return;
		}
		
		// Àç·á°¡ Æ®·£Áö(ITM)ÀÎÁö °Ë»ç
		if( !(pItemElemTransy->GetProp()->dwID == II_CHR_SYS_SCR_ITEMTRANSY_A || pItemElemTransy->GetProp()->dwID == II_CHR_SYS_SCR_ITEMTRANSY_B) )
			return;
		
		// ·¹º§ °Ë»ç
		if( pItemElemTransy->GetProp()->dwID == II_CHR_SYS_SCR_ITEMTRANSY_A )
		{
			if( 61 <= pItemElemTarget->GetProp()->dwLimitLevel1 )
				return;
		}
		else
		{
			if( pItemElemTarget->GetProp()->dwLimitLevel1 < 61 )
				return;
		}

		// ¼ºº°ÀÌ ÀÖ´Â ¾ÆÀÌÅÛ ÀÎÁö °Ë»ç
		ItemProp* pItemPropChange = NULL;
		ItemProp* pItemProp = pItemElemTarget->GetProp();
		
		pItemPropChange = pUser->GetTransyItem( pItemProp );

		if( pItemPropChange == NULL )
			return;

		// ¾ÆÀÌÅÛ Æ®·£Áö ¼º°ø
		pUser->AddPlaySound( SND_INF_UPGRADESUCCESS );			
		g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);			

		// ±âÁ¸ ¾ÆÀÌÅÛÀÇ Elem Á¤º¸¸¦ ÀúÀå ÇÏ°í ÀÕÀ½...
		CItemElem ItemElemSend;
		ItemElemSend = *pItemElemTarget;
		ItemElemSend.m_dwItemId = pItemPropChange->dwID;
		ItemElemSend.m_nHitPoint	= pItemPropChange->dwEndurance;		// ³»±¸·Â 100%

		g_dpDBClient.SendLogSMItemUse( "1", pUser, pItemElemTransy, pItemElemTransy->GetProp() );
		g_dpDBClient.SendLogSMItemUse( "1", pUser, pItemElemTarget, pItemElemTarget->GetProp(), "RemoveItem" );	
		g_dpDBClient.SendLogSMItemUse( "1", pUser, &ItemElemSend, ItemElemSend.GetProp(), "CreateItem" );	
		pUser->AddDefinedText( TID_GAME_ITEM_TRANSY_SUCCESS, "\"%s\" \"%s\"", pItemElemTarget->GetProp()->szName, ItemElemSend.GetProp()->szName );

		// ±âÁ¸ ¾ÆÀÌÅÛ Àç·á »èÁ¦
		pUser->RemoveItem( objidTarget, (short)1 );
		pUser->RemoveItem( objidTransy, (short)1 );		

		// »õ·Î¿î ¾ÆÀÌÅÛ Áö±Þ
		pUser->CreateItem( &ItemElemSend );
#endif // __SYS_ITEMTRANSY
	}
}

void CDPSrvr::OnExpBoxInfo( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	u_long uIdPlayer;
	OBJID objid;
	
	ar >> uIdPlayer >> objid;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CCtrl* pCtrl;

		pCtrl	= prj.GetCtrl( objid );
		if( IsValidObj( pCtrl ) )
			pUser->AddExpBoxInfo( objid,  ((CCommonCtrl*)pCtrl)->m_CtrlElem.m_dwSet, ((CCommonCtrl*)pCtrl)->m_dwDelete - timeGetTime(), ((CCommonCtrl*)pCtrl)->m_idExpPlayer );
	}
}

void CDPSrvr::OnPiercing( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwId1, dwId2;
	
	ar >> dwId1;
	ar >> dwId2;
	
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
#if __VER >= 12 // __EXT_PIERCING
	if( IsValidObj( pUser ) )
		CItemUpgrade::GetInstance()->OnPiercing( pUser, dwId1, dwId2 );
#else // __EXT_PIERCING
	if( IsValidObj( pUser ) )
	{
		// ÀÎº¥Åä¸®¿¡ ÀÖ´ÂÁö ÀåÂøµÇ¾î ÀÖ´ÂÁö È®ÀÎÀ» ÇØ¾ß ÇÔ
		CItemElem* pItemElem0	= pUser->m_Inventory.GetAtId( dwId1 );
		CItemElem* pItemElem1	= pUser->m_Inventory.GetAtId( dwId2 );
		if( IsUsableItem( pItemElem0 ) == FALSE || IsUsableItem( pItemElem1 ) == FALSE )
			return;

		// ÀåÂøµÇ¾î ÀÖ´Â ¾ÆÀÌÅÛÀº ÇÇ¾î½Ì ¸øÇÔ
		if( pUser->m_Inventory.IsEquip( dwId1 ) )
		{
			pUser->AddDefinedText( TID_GAME_EQUIPPUT , "" );
			return;
		}			

		// Ä«µå°¡ IK3_SOCKETCARD°¡ ¾Æ´Ï¸é ÇÇ¾î½Ì ¸øÇÔ
		if( pItemElem1->GetProp()->dwItemKind3 != IK3_SOCKETCARD )
		{
			pUser->AddDefinedText( TID_UPGRADE_ERROR_WRONGUPLEVEL , "" );			
			return;					
		}

		// Ä«µå°¡ µé¾î°¥ ¾ÆÀÌÅÛÀÌ ½´Æ®( IK3_SUIT ) ÀÎÁö °Ë»ç
		if( pItemElem0->GetProp()->dwItemKind3 != IK3_SUIT )
		{
			pUser->AddDefinedText(  TID_PIERCING_POSSIBLE_ITEM, "" );
			return;
		}
		
		// ÃÑ ÇÇ¾î½ÌµÈ¼ö¿Í ÀüÃ¼ ¼ö¸¦ ºñ±³ÇÑ´Ù.
		int nSize = pItemElem0->GetPiercingSize();
		
		int nCount = 0;
		for( int j = 0; j < nSize; j++ )
		{
			if( pItemElem0->GetPiercingItem( j ) != 0 )
				nCount++;
		}
		
		// ºó°÷ÀÌ ¾øÀ¸¸é Áß´Ü
		if( nCount == nSize )
		{
			pUser->AddDefinedText( TID_PIERCING_ERROR_NOPIERCING, "" );
			return;
		}

		// Ë¬
		if( pUser->m_vtInfo.GetOther() )	// °Å·¡ÁßÀÎ ´ë»óÀÌ ÀÖÀ¸¸é?
			return;
		if( pUser->m_vtInfo.VendorIsVendor() )		// ³»°¡ ÆÈ°í ÀÖÀ¸¸é?
			return;
		
		LogItemInfo aLogItem;
		aLogItem.SendName = pUser->GetName();
		aLogItem.RecvName = "PIERCING";
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
		
		if( pUser->Pierce( pItemElem0, pItemElem1->m_dwItemId ) )
		{
			aLogItem.Action = "$";
			OnLogItem( aLogItem, pItemElem0, pItemElem0->m_nItemNum );
			aLogItem.Action = "!";
			OnLogItem( aLogItem, pItemElem1, pItemElem1->m_nItemNum );

			// ¾ÆÀÌÅÛ ¹Ú±â ¼º°ø~
			pUser->AddPlaySound( SND_INF_UPGRADESUCCESS );			
			g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);			
			// Àç·á ¾ÆÀÌÅÛ »èÁ¦
			pUser->RemoveItem( dwId2, (short)1 );		
		}
	}
#endif // __EXT_PIERCING
}

#if __VER >= 11 // __PIERCING_REMOVE
// ÇÇ¾î½Ì ¿É¼Ç Á¦°Å(Ä«µå Á¦°Å)
void CDPSrvr::OnPiercingRemove( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objId;
	ar >> objId;
	
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;
	
#if __VER >= 12 // __EXT_PIERCING
	CItemUpgrade::GetInstance()->OnPiercingRemove( pUser, objId );
#else // __EXT_PIERCING
	CItemElem* pItemSuit = pUser->m_Inventory.GetAtId( objId );
	if( !IsUsableItem( pItemSuit ) || pItemSuit->GetProp()->dwItemKind3 != IK3_SUIT )
		return;

	if( pUser->m_Inventory.IsEquip( objId ) )
		return;

	// ÇÇ¾î½Ì ¿É¼ÇÀÌ ¾ø´Â °æ¿ì
	if( pItemSuit->GetPiercingSize() == 0 || pItemSuit->GetPiercingItem( 0 ) == 0 )
	{
		pUser->AddDefinedText( TID_GAME_REMOVE_PIERCING_ERROR );
		return;
	}

	int nPayPenya = 1000000; // ÁöºÒÇÒ Æä³Ä
	if( pUser->GetGold() < nPayPenya )	// Æä³Ä°¡ ºÎÁ·ÇÏ´Ù.
	{
		pUser->AddDefinedText( TID_GAME_LACKMONEY );
		return;
	}

	for( int i=pItemSuit->GetPiercingSize()-1; i>=0; i-- )
	{
		if( pItemSuit->GetPiercingItem( i ) != 0 )
		{
			pUser->AddGold( -nPayPenya );	// Æä³Ä ÁöºÒ
			pUser->AddDefinedText( TID_GAME_REMOVE_PIERCING_SUCCESS );
			pUser->UpdateItem( pItemSuit->m_dwObjId, UI_PIERCING, MAKELONG( i, 0 ) );
			
			LogItemInfo aLogItem;
			aLogItem.Action = "$";
			aLogItem.SendName = pUser->GetName();
			aLogItem.RecvName = "PIERCING_REMOVE";
			aLogItem.WorldId = pUser->GetWorld()->GetID();
			aLogItem.Gold = pUser->GetGold() + nPayPenya;
			aLogItem.Gold2 = pUser->GetGold();
			aLogItem.Gold_1 = -nPayPenya;
			OnLogItem( aLogItem, pItemSuit, 1 );
			break;
		}
	}
#endif // __EXT_PIERCING
}
#endif // __PIERCING_REMOVE

void CDPSrvr::OnCreateSfxObj( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwSfxId;
	u_long uIdPlayer;
	BOOL bFlag;
	ar >> dwSfxId >> uIdPlayer >> bFlag;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( uIdPlayer == NULL_ID )
		{
			g_UserMng.AddCreateSfxObj((CMover *)pUser, dwSfxId, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z, bFlag);
		}
		else
		{
			CUser* pUsertmp	= (CUser*)prj.GetUserByID( uIdPlayer );
			if( IsValidObj( pUsertmp ) )
				g_UserMng.AddCreateSfxObj((CMover *)pUsertmp, dwSfxId, pUsertmp->GetPos().x, pUsertmp->GetPos().y, pUsertmp->GetPos().z, bFlag);
		}		
	}
}

// 1000 ´ÜÀ§ÀÇ ÆÛ¼¾Æ®¸¦ ³Ñ±ä´Ù.
// dwID - Á¦·Ã ¾ÆÀÌÅÛ ¾ÆÀÌµð, n - Á¦·Ã ´Ü°è 
int GetEnchantPercent( DWORD dwID, int n )
{
#if __VER >= 8 //__Y_NEW_ENCHANT	
	static int nPersent1[10] = { 1000, 1000, 700, 500, 400, 300, 200, 100, 50, 20 };
#else //__Y_NEW_ENCHANT
	static int nPersent1[10] = {  900,  850, 800, 600, 450, 300, 200, 100, 50, 20 };
#endif //__Y_NEW_ENCHANT
	static int nPersent2[10] = { 1000, 1000, 900, 750, 550, 400, 250, 150, 80, 40 };

	float fFactor = 1.0f;
	if( ::GetLanguage() != LANG_KOR && n >= 3 )	// Á¦·Ã 4ºÎÅÍ 10% È®·ü °¨¼Ò 
		fFactor = 0.9f;

	if( dwID == II_GEN_MAT_DIE_TWELVE )
		return	( (int)( nPersent2[n] * fFactor ) );
	else
		return	( (int)( nPersent1[n] * fFactor ) );
}

#if __VER >= 11 // __SYS_IDENTIFY
void CDPSrvr::OnRemoveItemLevelDown( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwId;
	ar >> dwId;
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CItemElem* pItemElem	= (CItemElem*)pUser->GetItemId( dwId );
		if( !IsUsableItem( pItemElem ) )
			return;
		if( pItemElem->GetLevelDown() == 0 )
		{
			pUser->AddDefinedText( TID_GAME_INVALID_TARGET_ITEM );
			return;
		}
		PutItemLog( pUser, "v", "OnRemoveItemLevelDown", pItemElem );
		pItemElem->SetLevelDown();
		pUser->UpdateItemEx( (BYTE)( pItemElem->m_dwObjId ), UI_RANDOMOPTITEMID, pItemElem->GetRandomOptItemId() );
	}
}

void CDPSrvr::OnDoUseItemTarget( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwMaterial, dwTarget;
	ar >> dwMaterial >> dwTarget;
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CItemElem* pMaterial	= (CItemElem*)pUser->GetItemId( dwMaterial );
		CItemElem* pTarget	= (CItemElem*)pUser->GetItemId( dwTarget );
		if( !IsUsableItem( pMaterial ) || !IsUsableItem( pTarget ) )
			return;
		if( pUser->m_Inventory.IsEquip( dwTarget ) )
		{
			pUser->AddDefinedText( TID_GAME_EQUIPPUT );
			return;
		}
		BOOL	b	= FALSE;
		switch( pMaterial->m_dwItemId ) 
		{
			case II_SYS_SYS_QUE_PETRESURRECTION02_S:
			case II_SYS_SYS_QUE_PETRESURRECTION02_A:
			case II_SYS_SYS_QUE_PETRESURRECTION02_B:
				{
					CPet* pPet	= pTarget->m_pPet;
					if( !pPet || !pTarget->IsFlag( CItemElem::expired ) )
					{
						pUser->AddDefinedText( TID_GAME_PETRESURRECTION_WRONG_TARGET_01 );
					}
					else
					{
						BYTE nLevel		= pPet->GetLevel();
						if( ( nLevel == PL_B && pMaterial->m_dwItemId != II_SYS_SYS_QUE_PETRESURRECTION02_B )
							|| ( nLevel == PL_A && pMaterial->m_dwItemId != II_SYS_SYS_QUE_PETRESURRECTION02_A )
							|| ( nLevel == PL_S && pMaterial->m_dwItemId != II_SYS_SYS_QUE_PETRESURRECTION02_S )
							|| ( nLevel < PL_B )
							)
						{
							pUser->AddDefinedText( TID_GAME_PETRESURRECTION_WRONG_TARGET_02 );
						}
						else
						{
							PutItemLog( pUser, "r", "::PetResurrection", pTarget );

							pTarget->ResetFlag( CItemElem::expired );
							pUser->UpdateItem( (BYTE)( pTarget->m_dwObjId ), UI_FLAG, MAKELONG( pTarget->m_dwObjIndex, pTarget->m_byFlag ) );
							pPet->SetLife( 0 );
							pPet->SetEnergy( pPet->GetMaxEnergy() / 2 );
							pUser->AddPetState( pTarget->m_dwObjId, pPet->GetLife(), pPet->GetEnergy(), pPet->GetExp() );
							pUser->AddDefinedText( TID_GAME_PETRESURRECTION_SUCCESS );
							b	= TRUE;
						}
					}
					break;
				}
			case II_SYS_SYS_SCR_AWAKECANCEL:
			case II_SYS_SYS_SCR_AWAKECANCEL02:
				b	= DoUseItemTarget_InitializeRandomOption( pUser, pTarget, CRandomOptionProperty::eAwakening,
					TID_GAME_AWAKECANCEL_INFO, TID_GAME_AWAKECANCEL,
					"r", "::AwakeCancel" );
				break;
			case II_SYS_SYS_SCR_AWAKE:
#ifdef __NEW_ITEM_VARUNA
				if( pTarget->GetProp()->IsBaruna() )
				{
					b	= DoUseItemTarget_GenRandomOption( pUser, pTarget, CRandomOptionProperty::eAwakening, 
						0, TID_MMI_ERRORSENCHANT_BARUNA, TID_GAME_AWAKE_OR_BLESSEDNESS01,
						"r", "::Awake" );
				}else
#endif // __NEW_ITEM_VARUNA
				{
					b	= DoUseItemTarget_GenRandomOption( pUser, pTarget, CRandomOptionProperty::eAwakening, 
						0, TID_GAME_INVALID_TARGET_ITEM, TID_GAME_AWAKE_OR_BLESSEDNESS01,
						"r", "::Awake" );
				}
				break;
			case II_SYS_SYS_SCR_BLESSEDNESS:
			case II_SYS_SYS_SCR_BLESSEDNESS02:
				b	= DoUseItemTarget_GenRandomOption( pUser, pTarget, CRandomOptionProperty::eBlessing, 
					0, TID_GAME_USE_BLESSEDNESS_INFO, TID_GAME_BLESSEDNESS_INVALID_ITEM,
					"r", "::Blessedness" );
				break;
#if __VER >= 12 // __PET_0519
			case II_SYS_SYS_SCR_EATPETAWAKE:	// ¸ÔÆê °¢¼º
				b	= DoUseItemTarget_GenRandomOption( pUser, pTarget, CRandomOptionProperty::eEatPet,
					TID_GAME_PETAWAKE_S00, TID_GAME_PETAWAKE_E00, TID_GAME_PETAWAKE_E00,
					"r", "EATPETAWAKE" );
				break;
			case II_SYS_SYS_SCR_PETAWAKE:	// ½Ã½ºÅÛ Æê °¢¼º
				b	= DoUseItemTarget_GenRandomOption( pUser, pTarget, CRandomOptionProperty::eSystemPet, 
					TID_GAME_PETAWAKE_S00, TID_GAME_PETAWAKE_E00, TID_GAME_PETAWAKE_E00,
					"r", "PETAWAKE" );
				break;
			case II_SYS_SYS_SCR_PETAWAKECANCEL:		// ½Ã½ºÅÛ Æê °¢¼º Ãë¼Ò
				b	= DoUseItemTarget_InitializeRandomOption( pUser, pTarget, CRandomOptionProperty::eSystemPet,
					TID_GAME_PETAWAKECANCEL_S00, TID_GAME_PETAWAKECANCEL_E00,
					"r", "PETAWAKECANCEL" );
				break;
#endif	// __PET_0519
#ifdef __SYS_SCR_CANCELLATION
			case II_SYS_SYS_SCR_CANCELLATION:
				b = UnbindScroll(pUser, pMaterial, pTarget);
				break;
#endif
			case II_SYS_SYS_SCR_LEVELDOWN01:
			case II_SYS_SYS_SCR_LEVELDOWN02:
				b	= DoUseItemTarget_ItemLevelDown( pUser, pMaterial, pTarget );
				break;
#ifdef __SYS_SYS_ITEMMODELRETURN
			case II_SYS_SYS_ITEMMODELRETURN:
				if (b = (pTarget->GetLook() != NULL_ID))
				{
					if (pUser->HasActivatedEatPet() && pTarget->GetProp()->dwItemKind3 == IK3_PET)
					{
						b = FALSE;
						pUser->AddDefinedText(TID_GAME_PET_IS_NOT_FEED);
						return;
					}
					pTarget->SetLook(NULL_ID);
					pUser->AddLookChange(pTarget->m_dwObjId, NULL_ID);
					pUser->AddDefinedText(TID_MMI_LOOKCHANGE05);
				}
				else
					pUser->AddDefinedText(TID_MMI_LOOKCHANGE02);

				break;
#endif
#ifdef __BLING_BLING
			case II_SYS_SYS_BLING_BLING:
			{
				ItemProp* pPropTarget = pTarget->GetProp();
				if (pPropTarget->dwParts == PARTS_LWEAPON || pPropTarget->dwParts == PARTS_RWEAPON || pPropTarget->dwParts == PARTS_SHIELD)
				{
					if (!pTarget->IsFlag(CItemElem::reflect)
#ifndef __LOOKCHANGE
						&& pPropTarget->nReflect < 1
#endif // __LOOKCHANGE
						)
					{
						pTarget->SetFlag(CItemElem::reflect);
						pUser->UpdateItem((BYTE)pTarget->m_dwObjId, UI_FLAG, MAKELONG(pTarget->m_dwObjIndex, pTarget->m_byFlag));
						b = TRUE;
					}
					else
						pUser->AddText(prj.GetText(TID_BLING_BLING_ERROR), 0xFFFF0000);
				}
				else
					pUser->AddText(prj.GetText(TID_BLING_BLING_ERROR), 0xFFFF0000);
			}
			break;
			case II_SYS_SYS_REMOVE_BLING_BLING:
			{
				ItemProp* pPropTarget = pTarget->GetProp();
				if (pPropTarget->dwParts == PARTS_LWEAPON || pPropTarget->dwParts == PARTS_RWEAPON || pPropTarget->dwParts == PARTS_SHIELD)
				{
					if (pTarget->IsFlag(CItemElem::reflect))
					{
						pTarget->ResetFlag(CItemElem::reflect);
						pUser->UpdateItem((BYTE)(pTarget->m_dwObjId), UI_FLAG, MAKELONG(pTarget->m_dwObjIndex, pTarget->m_byFlag));
						b = TRUE;
					}
				}
			}
			break;
#endif // __BLING_BLING
#ifdef __SWITCH_GLOW_OLDNEW
			case II_SYS_SYS_SCR_CHANGEGLOWOLD:
				b = DoUseItemTarget_ItemChangGlowOldNew(pUser, pMaterial, pTarget);
				break;
#endif // __SWITCH_GLOW_OLDNEW
			default:
				break;
		}
		if( b )
		{
			pUser->AddPlaySound( SND_INF_UPGRADESUCCESS );
			if( pUser->IsMode( TRANSPARENT_MODE ) == 0 )
				g_UserMng.AddCreateSfxObj( pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z );

			PutItemLog( pUser, "u", "OnDoUseItemTarget", pMaterial );

			pUser->UpdateItem( (BYTE)( pMaterial->m_dwObjId ), UI_NUM, pMaterial->m_nItemNum - 1 );	
		}
	}
}
#endif	// __SYS_IDENTIFY

#if __VER >= 14 // __SMELT_SAFETY
#ifndef __LDE_SMELTWND
void CDPSrvr::OnSmeltSafety(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID dwItemId, dwItemMaterialId, dwItemProtScrId, dwItemSmeltScrId;
	ar >> dwItemId >> dwItemMaterialId >> dwItemProtScrId >> dwItemSmeltScrId;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
		//{
#ifdef __QUIZ
		if (pUser->GetWorld() && pUser->GetWorld()->GetID() == WI_WORLD_QUIZ)
		{
			pUser->AddSmeltSafety(0);
			return;
		}
#endif // __QUIZ
	// Ë¬
	if (pUser->m_vtInfo.GetOther() || pUser->m_vtInfo.VendorIsVendor())    // °Å·¡ÁßÀÎ ´ë»óÀÌ ÀÖÀ¸¸é?
	{
		pUser->AddSmeltSafety(0);
		return;
	}

	// ÀÎº¥Åä¸®¿¡ ÀÖ´ÂÁö ÀåÂøµÇ¾î ÀÖ´ÂÁö È®ÀÎÀ» ÇØ¾ß ÇÔ
	CItemElem* pItemElem0 = pUser->m_Inventory.GetAtId(dwItemId);
	CItemElem* pItemElem1 = pUser->m_Inventory.GetAtId(dwItemMaterialId);
	CItemElem* pItemElem2 = pUser->m_Inventory.GetAtId(dwItemProtScrId);
	CItemElem* pItemElem3 = NULL;
	if (dwItemSmeltScrId != NULL_ID)
	{
		pItemElem3 = pUser->m_Inventory.GetAtId(dwItemSmeltScrId);
		if (!IsUsableItem(pItemElem3))
			return;
	}

	if (IsUsableItem(pItemElem0) == FALSE || IsUsableItem(pItemElem1) == FALSE || IsUsableItem(pItemElem2) == FALSE)
	{
		pUser->AddSmeltSafety(0);
		return;
	}

	// ÀåÂøµÇ¾î ÀÖ´Â ¾ÆÀÌÅÛÀº Á¦·Ã ¸øÇÔ
	if (pUser->m_Inventory.IsEquip(dwItemId))
	{
		pUser->AddSmeltSafety(0);
		return;
	}

	if (pItemElem0->m_nResistSMItemId != 0) // »ó¿ëÈ ¾ÆÀÌÅÛ Àû¿ëÁßÀÌ¸é ºÒ°¡´É
	{
		pUser->AddSmeltSafety(0);
		return;
	}

	BYTE nResult = CItemUpgrade::GetInstance()->OnSmeltSafety(pUser, pItemElem0, pItemElem1, pItemElem2, pItemElem3);

	pUser->AddSmeltSafety(nResult);
}
	//}
#else
#include "../_Interface/WndNewUpgrade.h"
void CDPSrvr::OnSmeltSafety(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	unsigned short mainItemOID, matOID, scrollOID, scroll2OID;
	ar >> mainItemOID >> matOID >> scrollOID >> scroll2OID;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->m_vtInfo.GetOther() || pUser->m_vtInfo.VendorIsVendor() || pUser->m_Inventory.IsEquip(mainItemOID))
		{
			pUser->AddSmeltSafety(0);
			pUser->AddText("Unable to smelt in a vendor window or the item is equiped.");
			return;
		}

		CItemElem* itemElem = pUser->m_Inventory.GetAtId(mainItemOID);
		CItemElem* matItem = pUser->m_Inventory.GetAtId(matOID);
		CItemElem* scrollItem = pUser->m_Inventory.GetAtId(scrollOID);
		if (!IsUsableItem(itemElem) || !IsUsableItem(matItem) || !IsUsableItem(scrollItem))
		{
			pUser->AddSmeltSafety(0);
			pUser->AddText("Invalid items. If this continues to happen, please report it to staff");
			return;
		}

		CItemElem* scrollItem2 = pUser->m_Inventory.GetAtId(scroll2OID);
		if (!IsUsableItem(scrollItem2))
			scrollItem2 = nullptr;

		//if (pUser->Player_Smelt_Tick > g_tmCurrent + SEC(10) || g_tmCurrent >= pUser->Player_Smelt_Tick)
		{
			//pUser->Player_Smelt_Tick = g_tmCurrent + Kia::GetUpgradeTimerT() + (60.f / 800.f);
			pUser->AddSmeltSafety(CItemUpgrade::GetInstance()->OnSmeltSafety(pUser, itemElem, matItem, scrollItem, scrollItem2));
		}
		//else
		//    pUser->AddSmeltSafety(0);
	}
}

void CDPSrvr::onPrimeSmelt(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->m_vtInfo.GetOther() || pUser->m_vtInfo.VendorIsVendor())
		{
			pUser->AddSmeltSafety(0);
			return;
		}
		pUser->Player_Smelt_Tick = g_tmCurrent + Kia::GetUpgradeTimerT<Kia::EUpgradeTimer::Default>() - (Kia::GetUpgradeTimerT<Kia::EUpgradeTimer::Default>() / 3.0f);
	}
}
#endif
#endif // __SMELT_SAFETY

void CDPSrvr::OnEnchant( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwItemId, dwItemMaterialId;
	
	ar >> dwItemId;
	ar >> dwItemMaterialId;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __QUIZ
		if( pUser->GetWorld() && pUser->GetWorld()->GetID() == WI_WORLD_QUIZ )
			return;
#endif // __QUIZ
		// Ë¬
		if( pUser->m_vtInfo.GetOther() )	// °Å·¡ÁßÀÎ ´ë»óÀÌ ÀÖÀ¸¸é?
			return;
		if( pUser->m_vtInfo.VendorIsVendor() )		// ³»°¡ ÆÈ°í ÀÖÀ¸¸é?
			return;
#if __VER >= 11 // __SYS_COLLECTING
#if __VER < 14 // __SMELT_SAFETY
		if( pUser->PreRefine( dwItemId, dwItemMaterialId ) )
			return;
#endif // __SMELT_SAFETY
#endif	// __SYS_COLLECTING


		// ÀÎº¥Åä¸®¿¡ ÀÖ´ÂÁö ÀåÂøµÇ¾î ÀÖ´ÂÁö È®ÀÎÀ» ÇØ¾ß ÇÔ
		CItemElem* pItemElem0	= pUser->m_Inventory.GetAtId( dwItemId );
		CItemElem* pItemElem1	= pUser->m_Inventory.GetAtId( dwItemMaterialId );		

		if( IsUsableItem( pItemElem0 ) == FALSE || IsUsableItem( pItemElem1 ) == FALSE )
			return;

		if( pItemElem0->m_nResistSMItemId != 0 ) // »ó¿ëÈ­ ¾ÆÀÌÅÛ Àû¿ëÁßÀÌ¸é ºÒ°¡´É
		{
			pUser->AddDefinedText( TID_GAME_NOTUPGRADE , "" );
			return;
		}

#if __VER < 11 // __SYS_COLLECTING
		if( pUser->m_Inventory.IsEquip( dwItemId ) )
		{
			pUser->AddDefinedText( TID_GAME_EQUIPPUT , "" );
			return;
		}
#endif	// __SYS_COLLECTING

#if __VER < 14 // __SMELT_SAFETY
	#if __VER >= 8 //__Y_NEW_ENCHANT
		if( pItemElem1->GetProp()->dwItemKind3 != IK3_ELECARD && pItemElem1->GetProp()->dwItemKind3 != IK3_ENCHANT
#if __VER >= 19
			|| pItemElem1->GetProp()->dwItemKind3 != IK3_SMELT_ULTIMATE_MATERIAL
			|| pItemElem1->GetProp()->dwItemKind3 != IK3_SMELT_GENERAL_MATERIAL
#endif
 )
	#else //__Y_NEW_ENCHANT
		if( pItemElem1->GetProp()->dwItemKind3 != IK3_ELECARD && pItemElem1->GetProp()->dwItemKind3 != IK3_DICE )
	#endif //__Y_NEW_ENCHANT
		{
			pUser->AddDefinedText( TID_UPGRADE_ERROR_WRONGUPLEVEL , "" );			
			return;					
		}
#endif // __SMELT_SAFETY
#if __VER >= 13 // __EXT_ENCHANT
		CItemUpgrade::GetInstance()->OnEnchant( pUser, pItemElem0, pItemElem1 );
#else // __EXT_ENCHANT
		int nLevDown = 3;		
		int*  pAbilityOption = NULL;
			
		// ¼Ó¼ºÁ¦·ÃÀº ½´Æ®¿Í, ¹«±â¿¡¸¸ Àû¿ë
		if( pItemElem1->GetProp()->dwItemKind3 == IK3_ELECARD )
		{
			pAbilityOption = &(pItemElem0->m_nResistAbilityOption);

			if( pAbilityOption == NULL )
				return;

			// 2°¡Áö ¼Ó¼ºÀº Á¦·ÃÇÒ¼ö ¾øÀ½
			if( pItemElem0->m_bItemResist != SAI79::NO_PROP )
			{
				if( pItemElem0->m_bItemResist != pItemElem1->GetProp()->eItemType )
				{
					pUser->AddDefinedText( TID_UPGRADE_ERROR_TWOELEMENT , "" );								
					return;
				}
			}

			if( !CItemElem::IsEleRefineryAble(pItemElem0->GetProp()) )
			{
				pUser->AddDefinedText( TID_GAME_NOTEQUALITEM , "" );			
				return;								
			}

#if __VER >= 12 // __J12_0
			// ¼Ó¼º ´ç ÇÏ³ªÀÇ ¼Ó¼º Á¦·Ã Ä«µå¸¦ »ç¿ëÇÏµµ·Ï ¼öÁ¤
			DWORD dwReqCard	= WhatEleCard( pItemElem1->GetProp()->eItemType );
#else	// __J12_0
			DWORD dwReqCard = WhatEleCard( *pAbilityOption, pItemElem1->GetProp()->eItemType );
#endif	// __J12_0

			if( pItemElem1->GetProp()->dwID != dwReqCard )
			{
				pUser->AddDefinedText( TID_UPGRADE_ERROR_WRONGUPLEVEL , "" );			
				return;					
			}
		}
		else
		// ÀÏ¹ÝÁ¦·ÃÀº ¹æ¾î±¸, ¹«±â
	#if __VER >= 8 //__Y_NEW_ENCHANT
		if( pItemElem1->GetProp()->dwItemKind3 == IK3_ENCHANT
#if __VER >= 19
			|| pItemElem1->GetProp()->dwItemKind3 == IK3_SMELT_ULTIMATE_MATERIAL
			|| pItemElem1->GetProp()->dwItemKind3 == IK3_SMELT_GENERAL_MATERIAL
#endif
			)
	#else //__Y_NEW_ENCHANT
		if( pItemElem1->GetProp()->dwItemKind3 == IK3_DICE )
	#endif //__Y_NEW_ENCHANT
		{
#if __VER >= 9 // __ULTIMATE
			if( pItemElem0->GetProp()->dwReferStat1 == WEAPON_ULTIMATE )
			{
				pUser->AddDefinedText( TID_GAME_NOTEQUALITEM , "" );
				return;
			}
			
			if( pItemElem1->GetProp()->dwID != II_GEN_MAT_ORICHALCUM01
				&& pItemElem1->GetProp()->dwID != II_GEN_MAT_ORICHALCUM01_1 )
			{
				pUser->AddDefinedText( TID_GAME_NOTEQUALITEM , "" );
				return;
			}
#endif // __ULTIMATE
			pAbilityOption = pItemElem0->GetAbilityOptionPtr();

			if( pAbilityOption == NULL )
				return;

			if( !CItemElem::IsDiceRefineryAble(pItemElem0->GetProp()) )
			{
				pUser->AddDefinedText( TID_GAME_NOTEQUALITEM , "" );			
				return;								
			}

		#if __VER < 8 //__Y_NEW_ENCHANT
			if( pItemElem1->GetProp()->dwID != II_GEN_MAT_DIE_TWELVE )
			{
				if( *pAbilityOption <= 4 )
				{
					if( pItemElem1->GetProp()->dwID != II_GEN_MAT_DIE_FOUR )
					{
						pUser->AddDefinedText( TID_UPGRADE_ERROR_WRONGUPLEVEL , "" );			
						return;					
					}
				}
				else
				{
					if( pItemElem1->GetProp()->dwID != II_GEN_MAT_DIE_SIX )
					{
						pUser->AddDefinedText( TID_UPGRADE_ERROR_WRONGUPLEVEL , "" );			
						return;					
					}
				}
			}
		#endif //__Y_NEW_ENCHANT
		}	
		
		if( *pAbilityOption >= 10 )
		{
			pUser->AddDefinedText( TID_UPGRADE_MAXOVER , "" );			
			return;
		}
		// 1000´ÜÀ§ÀÇ ¼º°ø ÆÛ¼¾Æ® 
		int nPercent = ::GetEnchantPercent( pItemElem1->GetProp()->dwID, *pAbilityOption );

		LogItemInfo aLogItem;
		aLogItem.SendName = pUser->GetName();
		aLogItem.RecvName = "UPGRADEITEM";
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		aLogItem.Gold = pUser->GetGold();
		aLogItem.Gold2 = pUser->GetGold();


		BOOL bSmelprot	= FALSE;
		if( pUser->HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_SMELPROT ) )
		{
			bSmelprot	= TRUE;
			pUser->RemoveBuff( BUFF_ITEM, II_SYS_SYS_SCR_SMELPROT );

			ItemProp* pItemProp = prj.GetItemProp( II_SYS_SYS_SCR_SMELPROT );
			if( pItemProp )
				g_dpDBClient.SendLogSMItemUse( "2", pUser, NULL, pItemProp );
		}
		if( pUser->HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_SMELTING ) )
		{
			if( *pAbilityOption < 7 )
			{
				nPercent	+= 100;
				pUser->RemoveBuff( BUFF_ITEM, II_SYS_SYS_SCR_SMELTING );

				ItemProp* pItemProp = prj.GetItemProp( II_SYS_SYS_SCR_SMELTING );
				if( pItemProp )
					g_dpDBClient.SendLogSMItemUse( "2", pUser, NULL, pItemProp );
			}
		}
#ifdef __SYS_SCR_NOR_SMELTING01
		if (pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_NOR_SMELTING01))
		{
			if (*pAbilityOption >= 3 && *pAbilityOption < 7)
			{
				nPercent += 1000;
				pUser->RemoveBuff(BUFF_ITEM, II_SYS_SYS_SCR_NOR_SMELTING01);

				ItemProp* pItemProp = prj.GetItemProp(II_SYS_SYS_SCR_NOR_SMELTING01);
				if (pItemProp)
					g_dpDBClient.SendLogSMItemUse("2", pUser, NULL, pItemProp);
			}
		}
#endif
#ifdef __SYS_SCR_NOR_SMELTING02
		if (pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_NOR_SMELTING02))
		{
			if (*pAbilityOption >= 7 && *pAbilityOption < 9)
			{
				nPercent += 500;
				pUser->RemoveBuff(BUFF_ITEM, II_SYS_SYS_SCR_NOR_SMELTING02);

				ItemProp* pItemProp = prj.GetItemProp(II_SYS_SYS_SCR_NOR_SMELTING02);
				if (pItemProp)
					g_dpDBClient.SendLogSMItemUse("2", pUser, NULL, pItemProp);
			}
		}
#endif
#ifdef __SYS_SCR_NOR_SMELTING03
		if (pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_NOR_SMELTING03))
		{
			if (*pAbilityOption == 9)
			{
				nPercent += 300;
				pUser->RemoveBuff(BUFF_ITEM, II_SYS_SYS_SCR_NOR_SMELTING03);

				ItemProp* pItemProp = prj.GetItemProp(II_SYS_SYS_SCR_NOR_SMELTING03);
				if (pItemProp)
					g_dpDBClient.SendLogSMItemUse("2", pUser, NULL, pItemProp);
			}
		}
#endif
#ifdef __SM_ITEM_2ND_EX
		BOOL bSmelprot2	= FALSE;
		if( !bSmelprot && pUser->HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_SMELPROT2 ) )
		{
			bSmelprot2	= TRUE;
			pUser->RemoveBuff( BUFF_ITEM, II_SYS_SYS_SCR_SMELPROT2 );
		}
#endif	// __SM_ITEM_2ND_EX

		if( pUser->HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_SUPERSMELTING ) )
		{
			if( *pAbilityOption < 7 )
			{
				nPercent	+= 1000;
				pUser->RemoveBuff( BUFF_ITEM, II_SYS_SYS_SCR_SUPERSMELTING );
				
				ItemProp* pItemProp = prj.GetItemProp( II_SYS_SYS_SCR_SUPERSMELTING );
				if( pItemProp )
					g_dpDBClient.SendLogSMItemUse( "2", pUser, NULL, pItemProp );
			}				
		}

		// ÇØ´ç ¾ÆÀÌÅÛÀÇ ¼Ó¼º, ÀÏ¹Ý ·¹º§À» ¾ò¾î È®À²À» ²¨³½´Ù.
		if( xRandom( 1000 ) > nPercent )
		{
			// ½ÇÆÐ ¸Þ¼¼Áö Ãâ·Â
			pUser->AddDefinedText( TID_UPGRADE_FAIL, "" );
			pUser->AddPlaySound( SND_INF_UPGRADEFAIL );

			if((pUser->IsMode( TRANSPARENT_MODE ) ) == 0)
				g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_INT_FAIL, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);

			// ½ÇÆÐÇÏ¸é nLevDownÀÌ»óÀÌ¸é ¾ÆÀÌÅÛ »èÁ¦
			if( *pAbilityOption >= nLevDown )
			{
				if( !bSmelprot )
				{	// »ç¿ë¾ÈÇÏ¸é µé¾î¿È.. ´ë»ó ¾ÆÀÌÅÛ »èÁ¦ ½ÇÆÐ ·Î±×
				#ifdef __SM_ITEM_2ND_EX
					if( bSmelprot2  )
					{
						if( pItemElem1->GetProp()->dwItemKind3 == IK3_ELECARD )
						{
							pUser->UpdateItem( (BYTE)pItemElem0->m_dwObjId, UI_RAO, pItemElem0->m_nResistAbilityOption - 1 );
							aLogItem.Action = "8";
						}
						else 
					#if __VER >= 8 //__Y_NEW_ENCHANT
						if( pItemElem1->GetProp()->dwItemKind3 == IK3_ENCHANT
#if __VER >= 19
							|| pItemElem1->GetProp()->dwItemKind3 == IK3_SMELT_ULTIMATE_MATERIAL
							|| pItemElem1->GetProp()->dwItemKind3 == IK3_SMELT_GENERAL_MATERIAL
#endif
							)
					#else //__Y_NEW_ENCHANT
						if( pItemElem1->GetProp()->dwItemKind3 == IK3_DICE )
					#endif //__Y_NEW_ENCHANT
						{
							pUser->UpdateItem( (BYTE)pItemElem0->m_dwObjId, UI_AO,  pItemElem0->GetAbilityOption() - 1 );
							aLogItem.Action = "9";
						}
						OnLogItem( aLogItem, pItemElem0, pItemElem0->m_nItemNum );
					}
					else
				#endif	// __SM_ITEM_2ND_EX
					{
						aLogItem.Action = "L";
						OnLogItem( aLogItem, pItemElem0, pItemElem0->m_nItemNum );
						pUser->RemoveItem( dwItemId, (short)1 );
					}
				}
			}
			else
			{	// »ç¿ëÀ» ÇÏ¸é ½ÇÆÐ ·Î±×
				if( pItemElem1->GetProp()->dwItemKind3 == IK3_ELECARD )
				{
					aLogItem.Action = "J";
					OnLogItem( aLogItem, pItemElem0, pItemElem0->m_nItemNum );
				}
				else 
			#if __VER >= 8 //__Y_NEW_ENCHANT
				if( pItemElem1->GetProp()->dwItemKind3 == IK3_ENCHANT
#if __VER >= 19
					|| pItemElem1->GetProp()->dwItemKind3 == IK3_SMELT_ULTIMATE_MATERIAL
					|| pItemElem1->GetProp()->dwItemKind3 == IK3_SMELT_GENERAL_MATERIAL
#endif
					)
			#else //__Y_NEW_ENCHANT
				if( pItemElem1->GetProp()->dwItemKind3 == IK3_DICE )
			#endif //__Y_NEW_ENCHANT
				{
					aLogItem.Action = "F";
					OnLogItem( aLogItem, pItemElem0, pItemElem0->m_nItemNum );
				}		
			}
		}
		else
		{
			// ¼º°ø
			pUser->AddDefinedText( TID_UPGRADE_SUCCEEFUL, "" );
			pUser->AddPlaySound( SND_INF_UPGRADESUCCESS );
			
			if((pUser->IsMode( TRANSPARENT_MODE ) ) == 0)
				g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
			
			if( pItemElem1->GetProp()->dwItemKind3 == IK3_ELECARD )
			{
				pUser->UpdateItem( (BYTE)pItemElem0->m_dwObjId, UI_IR,  pItemElem1->GetProp()->eItemType );
				pUser->UpdateItem( (BYTE)pItemElem0->m_dwObjId, UI_RAO,  pItemElem0->m_nResistAbilityOption+1 );
				aLogItem.Action = "O";
				OnLogItem( aLogItem, pItemElem0, pItemElem0->m_nItemNum );
			}
			else 
		#if __VER >= 8 //__Y_NEW_ENCHANT
			if( pItemElem1->GetProp()->dwItemKind3 == IK3_ENCHANT
#if __VER >= 19
				|| pItemElem1->GetProp()->dwItemKind3 == IK3_SMELT_ULTIMATE_MATERIAL
				|| pItemElem1->GetProp()->dwItemKind3 == IK3_SMELT_GENERAL_MATERIAL
#endif
				) // // ÁÖ»çÀ§
		#else //__Y_NEW_ENCHANT
			if( pItemElem1->GetProp()->dwItemKind3 == IK3_DICE ) // // ÁÖ»çÀ§
		#endif //__Y_NEW_ENCHANT
			{
				pUser->UpdateItem( (BYTE)pItemElem0->m_dwObjId, UI_AO,  pItemElem0->GetAbilityOption()+1 );
				aLogItem.Action = "H";
				OnLogItem( aLogItem, pItemElem0, pItemElem0->m_nItemNum );
			}
		}

		aLogItem.Action = "N";
		OnLogItem( aLogItem, pItemElem1, pItemElem1->m_nItemNum );
		// Á¦·Ã¾ÆÅÛ »èÁ¦ - ¼º°øÀÌ´ø, ½ÇÆÐ´ø...
		pUser->RemoveItem( dwItemMaterialId, (short)1 );
#endif // __EXT_ENCHANT
	}	
}

#if __VER >= 10 // __REMOVE_ATTRIBUTE
void CDPSrvr::OnRemoveAttribute( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nPayPenya = 100000; //¼Ó¼ºÁ¦·Ã Á¦°Å½Ã ÇÊ¿äÇÑ Æä³Ä

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	OBJID objItemId;
	ar >> objItemId;

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId( objItemId );

	if( IsUsableItem( pItemElem ) == FALSE )
	{
		pUser->AddRemoveAttribute( FALSE );
		return;
	}
	// ¹«±â³ª ¹æ¾î±¸¸¸ °¡´É
	if( !CItemElem::IsEleRefineryAble(pItemElem->GetProp()) )
	{
		pUser->AddRemoveAttribute( FALSE );
		pUser->AddDefinedText( TID_GAME_NOTEQUALITEM , "" );
		return;
	}
	if( pItemElem->m_nResistSMItemId != 0 ) // »ó¿ëÈ­ ¾ÆÀÌÅÛ Àû¿ëÁßÀÌ¸é ºÒ°¡´É
	{
		pUser->AddRemoveAttribute( FALSE );
		pUser->AddDefinedText( TID_GAME_NOTUPGRADE , "" );
		return;
	}
	// ÀåÂøµÇ¾î ÀÖ´ÂÁö È®ÀÎÀ» ÇØ¾ß ÇÔ.
	if( pUser->m_Inventory.IsEquip( objItemId ) )
	{
		pUser->AddRemoveAttribute( FALSE );
		pUser->AddDefinedText( TID_GAME_EQUIPPUT , "" );
		return;
	}
	// 10¸¸ Æä³Ä ÀÌ»óÀ» ¼ÒÁöÇØ¾ß¸¸ ¼Ó¼º Á¦°Å °¡´É.
	if( pUser->GetGold() < nPayPenya )
	{
		pUser->AddRemoveAttribute( FALSE );
		pUser->AddDefinedText( TID_GAME_LACKMONEY , "" );
		return;
	}
	
	// ÇöÀç ¹«±â¿¡ ¼Ó¼ºÀÌ Àû¿ëµÇ¾î ÀÖ¾î¾ß °¡´É.
	if( (pItemElem->m_bItemResist != SAI79::NO_PROP) && (pItemElem->m_nResistAbilityOption > 0) )
	{
		pUser->AddGold( -nPayPenya );
		pUser->AddPlaySound( SND_INF_UPGRADESUCCESS );
		if((pUser->IsMode( TRANSPARENT_MODE ) ) == 0)
			g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
	
		pUser->UpdateItem( (BYTE)pItemElem->m_dwObjId, UI_IR,  SAI79::NO_PROP );
		pUser->UpdateItem( (BYTE)pItemElem->m_dwObjId, UI_RAO,  0 );
		pUser->AddRemoveAttribute( TRUE );
		
		// ¼Ó¼ºÁ¦·Ã Á¦°Å ¼º°ø ·Î±×
		LogItemInfo aLogItem;
		aLogItem.SendName = pUser->GetName();
		aLogItem.RecvName = "REMOVE_ATTRIBUTE";
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		aLogItem.Gold = pUser->GetGold() + nPayPenya;
		aLogItem.Gold2 = pUser->GetGold();
		aLogItem.Gold_1 = -nPayPenya;
		aLogItem.Action = "O";
		OnLogItem( aLogItem, pItemElem, 1 );
	}
	else
		pUser->AddRemoveAttribute( FALSE );
	
}
#endif // __REMOVE_ATTRIBUTE

#if __VER >= 13 // __EXT_ENCHANT
void CDPSrvr::OnChangeAttribute( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpbuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	OBJID objTargetItem, objMaterialItem;
	int nAttribute;

	ar >> objTargetItem >> objMaterialItem;
	ar >> nAttribute;

	CItemUpgrade::GetInstance()->ChangeAttribute( pUser, objTargetItem, objMaterialItem, static_cast<SAI79::ePropType>(nAttribute) );
}
#endif // __EXT_ENCHANT

void CDPSrvr::OnRandomScroll( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpbuf, u_long uBufSize )
{
	DWORD dwId1, dwId2;
	
	ar >> dwId1;
	ar >> dwId2;
	
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		// ÀÎº¥Åä¸®¿¡ ÀÖ´ÂÁö ÀåÂøµÇ¾î ÀÖ´ÂÁö È®ÀÎÀ» ÇØ¾ß ÇÔ
		CItemElem* pItemElem0	= pUser->m_Inventory.GetAtId( dwId1 );
		CItemElem* pItemElem1	= pUser->m_Inventory.GetAtId( dwId2 );
		if( IsUsableItem( pItemElem0 ) == FALSE || IsUsableItem( pItemElem1 ) == FALSE )
		{
			return;
		}

		if( pUser->m_Inventory.IsEquip( dwId1 ) )
		{
			pUser->AddDefinedText( TID_GAME_EQUIPPUT , "" );
			return;
		}			

		if( pItemElem1->GetProp()->dwItemKind3 != IK3_RANDOM_SCROLL )
		{
			return;					
		}

		if( !(pItemElem0->GetProp()->dwItemKind1 == IK1_WEAPON || pItemElem0->GetProp()->dwItemKind2 == IK2_ARMOR || pItemElem0->GetProp()->dwItemKind2 == IK2_ARMORETC ) )
		{
			pUser->AddDefinedText(  TID_GAME_RANDOMSCROLL_ERROR, "" );
			return;
		}

		int nSTR[4] = { 1,  9, 21, 37 };
		int nDEX[4] = { 2, 10, 22, 38 };
		int nINT[4] = { 3, 11, 23, 39 };
		int nSTA[4] = { 4, 12, 24, 40 };

		int nValue = 0;
		int nRandom = xRandom( 100 );
		if( nRandom < 64 )
			nValue = 1;
		else if( nRandom < 94 )
			nValue = 2;
		else if( nRandom < 99 )
			nValue = 3;
		else if( nRandom < 100 )
			nValue = 4;

		if( 0 < nValue )
		{
			int nKind = 0;
			int nToolKind = 0;
			if( pItemElem1->GetProp()->dwID == II_SYS_SYS_SCR_RANDOMSTR )
			{
				nKind = nSTR[nValue-1];
				nToolKind = DST_STR;
			}
			else if( pItemElem1->GetProp()->dwID == II_SYS_SYS_SCR_RANDOMDEX )
			{
				nKind = nDEX[nValue-1];
				nToolKind = DST_DEX;
			}
			else if( pItemElem1->GetProp()->dwID == II_SYS_SYS_SCR_RANDOMINT )
			{
				nKind = nINT[nValue-1];
				nToolKind = DST_INT;
			}
			else if( pItemElem1->GetProp()->dwID == II_SYS_SYS_SCR_RANDOMSTA )
			{
				nKind = nSTA[nValue-1];
				nToolKind = DST_STA;
			}

			pUser->UpdateItem( (BYTE)pItemElem0->m_dwObjId, UI_RANDOMOPTITEMID, nKind );

			LogItemInfo aLogItem;
			aLogItem.SendName = pUser->GetName();
			aLogItem.RecvName = "RANDOMSCROLL";
			aLogItem.WorldId = pUser->GetWorld()->GetID();
			aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
			aLogItem.Action = "(";
			OnLogItem( aLogItem, pItemElem0, pItemElem0->m_nItemNum );
			aLogItem.Action = ")";
			OnLogItem( aLogItem, pItemElem1, pItemElem1->m_nItemNum );

			pUser->RemoveItem( (BYTE)( dwId2 ), (short)1 );		

			// ¾ÆÀÌÅÛ ¹Ú±â ¼º°ø~
			pUser->AddPlaySound( SND_INF_UPGRADESUCCESS );			
			g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);			

			DWORD dwStringNum = 0;
			switch( nToolKind )
			{
			case DST_STR:
				dwStringNum = TID_TOOLTIP_STR;
				break;
			case DST_DEX:
				dwStringNum = TID_TOOLTIP_DEX;
				break;
			case DST_STA:
				dwStringNum = TID_TOOLTIP_STA;
				break;
			default: //case DST_INT:
				dwStringNum = TID_TOOLTIP_INT;
				break;
			}
			CString strMessage;
			strMessage.Format( prj.GetText( TID_GAME_RANDOMSCROLL_SUCCESS ), pItemElem0->GetProp()->szName, prj.GetText( dwStringNum ), nValue );
			pUser->AddText( strMessage );
		}
	}
}
	
void CDPSrvr::OnUpgradeBase( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
}


void CDPSrvr::OnCommercialElem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwItemId0, dwItemId1;
	ar >> dwItemId0 >> dwItemId1;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		// ÀÎº¥Åä¸®¿¡ ÀÖ´ÂÁö ÀåÂøµÇ¾î ÀÖ´ÂÁö È®ÀÎÀ» ÇØ¾ß ÇÔ
		// ÀÎº¥Åä¸®¿¡ ÀÖ´ÂÁö °Ë»ç
		CItemElem* pItemElem0	= pUser->m_Inventory.GetAtId( dwItemId0 );
		CItemElem* pItemElem1	= pUser->m_Inventory.GetAtId( dwItemId1 );

		if( IsUsableItem( pItemElem0 ) == FALSE || 
			IsUsableItem( pItemElem1 ) == FALSE || 
			pItemElem0->GetProp()->nLog >=2 || 
			pItemElem1->GetProp()->nLog >=2 )
		{
			return;
		}

		if( pUser->m_Inventory.IsEquip( dwItemId0 ) || pUser->m_Inventory.IsEquip( dwItemId1 ) )
		{
			pUser->AddDefinedText( TID_GAME_EQUIPPUT , "" );
			return;
		}

		// ¹æ¾î±¸(½´Æ®¸¸), ¹«±â·ù°¡ ¾Æ´Ï¸é Á¦·ÃºÒ°¡´É
		if( !( ( pItemElem0->GetProp()->dwItemKind2 == IK2_WEAPON_MAGIC ||
			pItemElem0->GetProp()->dwItemKind2 == IK2_WEAPON_DIRECT ) ||
			( ( pItemElem0->GetProp()->dwItemKind2 == IK2_ARMOR || pItemElem0->GetProp()->dwItemKind2 == IK2_ARMORETC ) 
			&& pItemElem0->GetProp()->dwItemKind3 == IK3_SUIT )
			) )		
		{
			return;			
		}

		if( pItemElem0->m_nResistSMItemId != 0 ) // ÀÌ¹ÌÀû¿ëÇÑ ¾ÆÀÌÅÛÀÌ¸é ºÒ°¡´É
		{
			return;	
		}

		BOOL bResistDelete = FALSE;

		if( pItemElem1->GetProp()->dwItemKind2 == IK2_SYSTEM )
		{
			// ¼Ó¼º °ø°Ý·Â Ãß°¡
			if( pItemElem1->m_dwItemId == II_CHR_SYS_SCR_FIREASTONE ||
				pItemElem1->m_dwItemId == II_CHR_SYS_SCR_WATEILSTONE ||
				pItemElem1->m_dwItemId == II_CHR_SYS_SCR_WINDYOSTONE ||
				pItemElem1->m_dwItemId == II_CHR_SYS_SCR_LIGHTINESTONE ||
				pItemElem1->m_dwItemId == II_CHR_SYS_SCR_EARTHYSTONE ) 
				
			{
				if( pItemElem0->GetProp()->dwItemKind2 == IK2_ARMOR ||
					pItemElem0->GetProp()->dwItemKind2 == IK2_ARMORETC )
				{
					return;	
				}
			}
			else // ¼Ó¼º ¹æ¾î·Â Ãß°¡
			if(	pItemElem1->m_dwItemId == II_CHR_SYS_SCR_DEFIREASTONE ||
				pItemElem1->m_dwItemId == II_CHR_SYS_SCR_DEWATEILSTONE ||
				pItemElem1->m_dwItemId == II_CHR_SYS_SCR_DEWINDYOSTONE ||
				pItemElem1->m_dwItemId == II_CHR_SYS_SCR_DELIGHTINESTONE ||
				pItemElem1->m_dwItemId == II_CHR_SYS_SCR_DEEARTHYSTONE )
			{
				if( pItemElem0->GetProp()->dwItemKind2 == IK2_WEAPON_MAGIC ||
					pItemElem0->GetProp()->dwItemKind2 == IK2_WEAPON_DIRECT )
				{
					return;	
				}
			}
			else // ¼Ó¼º Á¦°Å
			if( pItemElem1->m_dwItemId == II_CHR_SYS_SCR_TINEINEDSTONE )
			{
				if( pItemElem0->m_bItemResist == SAI79::NO_PROP )
				{
					return;	
				}
				pItemElem0->m_bItemResist = SAI79::NO_PROP;
				pItemElem0->m_nResistAbilityOption = 0;
				bResistDelete = TRUE;
			}
			else
			{
				return;	
			}
		}
		else 
		{
			return;	
		}

		// ¼º°ø
		
		if( bResistDelete )
		{
			pUser->AddCommercialElem( pItemElem0->m_dwObjId, 9999 );
		}
		else
		{
			pItemElem0->m_nResistSMItemId = pItemElem1->m_dwItemId;
		}
		
		// ·Î±×
		g_dpDBClient.SendLogSMItemUse( "5", pUser, pItemElem1, pItemElem1->GetProp() );
		LogItemInfo aLogItem;
		aLogItem.Action = "5";
		aLogItem.SendName = pUser->GetName();
		aLogItem.RecvName = pUser->GetName();
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		aLogItem.Gold = pUser->GetGold();
		aLogItem.Gold2 = pUser->GetGold();
		aLogItem.ItemNo = pItemElem0->GetSerialNumber();
		//aLogItem.ItemName = pItemElem0->GetProp()->szName;
		_stprintf( aLogItem.szItemName, "%d", pItemElem0->GetProp()->dwID );
		aLogItem.itemNumber = pItemElem0->m_nItemNum;
		aLogItem.nAbilityOption = pItemElem0->GetAbilityOption();
		aLogItem.nItemResist = pItemElem0->m_bItemResist;
		aLogItem.nResistAbilityOption = pItemElem0->m_nResistAbilityOption;
		aLogItem.Negudo = int((float)pItemElem0->m_nHitPoint * 100 / (float)pItemElem0->GetProp()->dwEndurance );
		OnLogItem( aLogItem );

		pUser->RemoveItem( (BYTE)dwItemId1, (short)1 );
		
		g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_SYS_EXPAN01, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
		pUser->AddCommercialElem( pItemElem0->m_dwObjId, pItemElem0->m_nResistSMItemId );
		
	}
}

#ifdef __GUILDRANK
void CDPSrvr::OnRequestGuildRank( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CTime		tm			= CTime::GetCurrentTime();
	CTimeSpan	tm_update	= tm - CGuildRank::Instance()->m_UpdateTime;

	DWORD	ver;
	
	//	¹öÁ¯ Á¤º¸¸¦ ¹Þ´Â´Ù.
	ar >> ver;

	// °»½ÅµÈÁö ÇÏ·ç°¡ Áö³µ´ÂÁö Ã¼Å©
	if ( tm_update.GetHours() >= 24 )
	{
		// TRANS ¼­¹ö¿¡°Ô ´Ù½Ã ·©Å© Á¤º¸¸¦ °»½ÅÇÒ °ÍÀ» ¿äÃ»ÇÑ´Ù.
		g_dpDBClient.UpdateGuildRanking();
	}
	else
	{
		// ·©Å© Á¤º¸ ¹öÁ¯ÀÌ ´Ù¸¦ °æ¿ì¿£ ·©Å© Á¤º¸¸¦ º¸³»°Ô µÈ´Ù.
		if ( CGuildRank::Instance()->m_Version != ver )
		{
			// ·©Å· Á¤º¸¸¦ º¸³½´Ù.
			CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
			if( IsValidObj( pUser ) )
			{
				pUser->SendGuildRank();
			}
		}
	}
}
#endif

void CDPSrvr::OnBuyingInfo( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	return;
}

void CDPSrvr::OnEnterChattingRoom( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long uidChattingRoom;
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		BOOL bChatting = FALSE;
		if( pUser->m_idChatting == 0 )
		{
			ar >> uidChattingRoom;

			CChatting* pChatting = g_ChattingMng.GetChttingRoom( uidChattingRoom );
			if( pChatting )
			{
				if( pChatting->AddChattingMember( pUser->m_idPlayer ) )
				{
					CUser*			pUsertmp;
					pUser->m_idChatting = uidChattingRoom;

					for( int i = 0 ; i < pChatting->GetChattingMember() - 1 ; ++i )
					{
						pUsertmp	= (CUser*)prj.GetUserByID( pChatting->m_idMember[i] );
						if( IsValidObj( pUsertmp ) )
							pUsertmp->AddEnterChatting( pUser );
					}

					pUser->AddNewChatting( pChatting );
				}
				else
				{
					bChatting	= TRUE;
				}
			}

		}
		else
		{
			bChatting	= TRUE;
		}
	}
}

void CDPSrvr::OnChatting( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	static	TCHAR	sChat[1024];
	ar.ReadString( sChat, 1024 );

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __JEFF_9_20
#if __VER >= 12 // __LORD
		int nText	= pUser->GetMuteText();
		if(  nText )
		{
			pUser->AddDefinedText( nText );
			return;
		}
#else	// __LORD
		if( pUser->IsMute() )
			return;
#endif	// __LORD
#endif	// __JEFF_9_20

		if( !( pUser->HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_FONTEDIT)))
			ParsingEffect( sChat, strlen(sChat) );

		RemoveCRLF( sChat );

		CChatting* pChatting = g_ChattingMng.GetChttingRoom( pUser->m_idChatting );
		if( pChatting )
		{
			int nFind = pChatting->FindChattingMember( pUser->m_idPlayer );
			if( nFind != -1 )
			{
				CUser* pUsertmp;
				for( int i = 0 ; i < pChatting->GetChattingMember() ; ++i )
				{
					pUsertmp	= (CUser*)prj.GetUserByID( pChatting->m_idMember[i] );
					if( IsValidObj( pUsertmp ) )
						pUsertmp->AddChatting( pUser->m_idPlayer, sChat );
				}
			}
			else
			{
				// Ã¤ÆÃ¸â¹ö°¡ ¾Æ´Ô
				pUser->m_idChatting = 0;
				pUser->AddDeleteChatting();
			}
		}
		else
		{
			// Ã¤ÆÃ¹æÀÌ ¾øÀ½.
			pUser->m_idChatting = 0;
			pUser->AddDeleteChatting();
		}

	}
}


void CDPSrvr::OnOpenChattingRoom( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{

		CChatting* pChatting	= g_ChattingMng.GetChttingRoom( pUser->m_idChatting );
		if( pChatting )
		{
			pChatting->m_bState		= TRUE;
			CUser* pUsertmp;
			for( int i = 0 ; i < pChatting->GetChattingMember() ; ++i )
			{
				pUsertmp	= (CUser*)prj.GetUserByID( pChatting->m_idMember[i] );
				if( IsValidObj( pUsertmp ) && pUser->m_idPlayer != pUsertmp->m_idPlayer )
					pUsertmp->AddChttingRoomState( pChatting->m_bState );
			}
		}
	}
}

void CDPSrvr::OnCloseChattingRoom( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{

		CChatting* pChatting = g_ChattingMng.GetChttingRoom( pUser->m_idChatting );
		if( pChatting )
		{
			pChatting->m_bState = FALSE;
			CUser*			pUsertmp;
			
			for( int i = 0 ; i < pChatting->GetChattingMember() ; ++i )
			{
				pUsertmp	= (CUser*)prj.GetUserByID( pChatting->m_idMember[i] );
				if( IsValidObj( pUsertmp ) && pUser->m_idPlayer != pUsertmp->m_idPlayer )
				{
					pUsertmp->AddChttingRoomState( pChatting->m_bState );
				}						
			}
		}

	}
}

void CDPSrvr::OnCommonPlace( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
//		BYTE nType;
//		ar >> nType;
}


void CDPSrvr::QueryDestroyPlayer( DPID dpidCache, DPID dpidSocket, DWORD dwSerial, u_long idPlayer )
{
	BEFORESENDSOLE( ar, PACKETTYPE_QUERY_DESTROY_PLAYER, dpidSocket );
	ar << dwSerial;
	ar << idPlayer;
	SEND( ar, this, dpidCache );
}

void CDPSrvr::OnSetNaviPoint( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	NaviPoint nv;
	OBJID objidTarget;
	ar >> nv.Pos >> objidTarget;

	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( objidTarget == NULL_ID )
		{
			CParty* pParty	= g_PartyMng.GetParty( pUser->m_idparty );
			if( pParty )
			{
				for( int i = 0 ; i < pParty->GetSizeofMember() ; ++i )
				{
					CUser* pUsertmp = (CUser *)prj.GetUserByID( pParty->GetPlayerId( i ) );
					if( IsValidObj( pUsertmp ) )
					{
						pUsertmp->AddSetNaviPoint( nv, pUser->GetId(), pUser->GetName( TRUE ) );
					}
				}
			}
		}
		else
		{
			CUser* pUsertmp	= prj.GetUser( objidTarget );
			if( IsValidObj( pUsertmp ) )
			{
				pUser->AddSetNaviPoint( nv, pUser->GetId(), pUser->GetName( TRUE ) );
				pUsertmp->AddSetNaviPoint( nv, pUser->GetId(), pUser->GetName( TRUE ) );
			}
		}
	}
}

void CDPSrvr::OnGameMasterWhisper( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CHAR	sPlayerFrom[MAX_PLAYER], lpString[260], szChat[1024];
	ar.ReadString( sPlayerFrom, MAX_PLAYER );
	ar.ReadString( lpString, 260 );

	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{	
		sprintf( szChat, "%s -> %s", sPlayerFrom, lpString );
		g_dpDBClient.SendLogGamemaChat( pUser, szChat );
	}
}
/*
#ifdef __S0114_RELOADPRO
void CDPSrvr::SendReloadProject( DPID dpidCache, DPID dpidUser )
{
//	BEFORESENDSOLE( ar1, PACKETTYPE_RELOAD_PROJECT, dpidUser );
//	SEND( ar1, &g_DPSrvr, dpidCache );
}
#endif // __S0114_RELOADPRO
*/
// Çö»ó±Ý °É±â ÆÐÅ¶ 
void CDPSrvr::OnNWWantedGold( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	int		nGold;
	char	szMsg[WANTED_MSG_MAX + 1];

	ar >> nGold;
	ar.ReadString( szMsg, WANTED_MSG_MAX + 1 );

	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	if( pUser->m_idMurderer == 0 )		// ³ª¸¦ Á×ÀÎÀÚ°¡ ¾ø¾úÀ¸¸é Çö»ó±ÝÀ» °É ¼ö ¾ø´Ù.
		return;

	if( szMsg[0] == '\0' )
		return;
	
	if( strlen(szMsg) > WANTED_MSG_MAX )
		return;

	if( nGold < MIN_INPUT_REWARD || nGold > MAX_INPUT_REWARD )			// Çö»ó±ÝÀº ÃÖ¼Ò 1000ÆÐ³Ä¿¡¼­ ÃÖ´ë 2¾ï ÆÐ³Ä±îÁö °É ¼ö ÀÖ´Ù. 
		return;

	int nTax = MulDiv( nGold, 10, 100 );					// °Ç Çö»ó±ÝÀÇ 10%´Â ¼ö¼ö·á·Î Áö±ÞµÈ´Ù. 

	if( pUser->GetGold() >= (nGold + nTax) ) 
		pUser->AddGold( -(nGold + nTax) );
	else
		return;

#if __VER >= 11 // __SYS_PLAYER_DATA
	const char* lpszPlayer	= CPlayerDataCenter::GetInstance()->GetPlayerString( pUser->m_idMurderer );
#else	// __SYS_PLAYER_DATA
	LPCSTR lpszPlayer = prj.GetPlayerString( pUser->m_idMurderer );
#endif	// __SYS_PLAYER_DATA
	if( lpszPlayer == NULL )
		lpszPlayer = "";
	g_DPCoreClient.SendWCWantedGold( lpszPlayer, pUser->m_idMurderer, nGold, szMsg );
}


// Çö»ó±Ý ¸®½ºÆ® ¿äÃ» ÆÐÅ¶
void CDPSrvr::OnNWWantedList( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	{
		BEFORESENDSOLE( out, PACKETTYPE_WN_WANTED_LIST, pUser->m_Snapshot.dpidUser );

		CWantedListSnapshot& wantedListSnapshot = CWantedListSnapshot::GetInstance();
		wantedListSnapshot.Write( out );

		SEND( out, this, dpidCache );
	}
}

void CDPSrvr::OnNWWantedName( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	LPCSTR lpszPlayer = "";
	if( pUser->m_idMurderer )		
	{
#if __VER >= 11 // __SYS_PLAYER_DATA
		lpszPlayer	= CPlayerDataCenter::GetInstance()->GetPlayerString( pUser->m_idMurderer );
#else	// __SYS_PLAYER_DATA
		lpszPlayer = prj.GetPlayerString( pUser->m_idMurderer );
#endif	// __SYS_PLAYER_DATA
		if( lpszPlayer == NULL )
			lpszPlayer	= "";
	}
	
	{
		BEFORESENDSOLE( ar, PACKETTYPE_WN_WANTED_NAME, pUser->m_Snapshot.dpidUser );
		ar.WriteString( lpszPlayer );
		SEND( ar, this, dpidCache );
	}
}


// Çö»ó¹ü ÀÚ¼¼ÇÑÁ¤º¸ ¿äÃ» ÆÐÅ¶ 
void CDPSrvr::OnNWWantedInfo( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	char szPlayer[64];
	ar.ReadString( szPlayer, 64 );

	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	CWantedListSnapshot& wantedListSnapshot = CWantedListSnapshot::GetInstance();
	int nIndex = wantedListSnapshot.GetPlayerIndex( szPlayer );
	if( nIndex < 0 )
		return;

	{
		int nGold = REQ_WANTED_GOLD;
		if( pUser->GetGold() >= nGold ) 
		{
			D3DXVECTOR3 vPos( 0.0f, 0.0f, 0.0f );		// Çö»ó¹üÀÇ À§Ä¡ 
			BYTE		byOnline = 0;					// 1 ÀÌ¸é online
			DWORD		dwWorldID = 0;
			LPCTSTR		lpszWorld = "";

#if __VER >= 11 // __SYS_PLAYER_DATA
			u_long idPlayer		= CPlayerDataCenter::GetInstance()->GetPlayerId( szPlayer );
#else	// __SYS_PLAYER_DATA
			u_long idPlayer = prj.GetPlayerID( szPlayer );
#endif	// __SYS_PLAYER_DATA
			CUser* pTarget	= g_UserMng.GetUserByPlayerID( idPlayer );	
			if( IsValidObj(pTarget) && pTarget->GetWorld() )
			{
				vPos      = pTarget->GetPos();
				byOnline  = 1;
				dwWorldID = pTarget->GetWorld()->GetID();
				lpszWorld = pTarget->GetWorld()->m_szWorldName;

				pUser->AddGold( -nGold );
			}

			pUser->AddWantedInfo( vPos, byOnline, dwWorldID, lpszWorld );
		} 
		else
		{
			pUser->AddDefinedText( TID_GAME_LACKMONEY, "" );	// ÀÎº¥¿¡ µ·ÀÌºÎÁ·
		}
	}
}

void CDPSrvr::OnReqLeave( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	if( pUser->m_dwLeavePenatyTime == 0 )	// Æä³ÎÆ¼ Å¸ÀÓÀ» ¼¼ÆÃÇÑ ÀûÀÌ ¾ø´Â°¡?
		pUser->m_dwLeavePenatyTime = ::timeGetTime() + TIMEWAIT_CLOSE * 1000;	//  ¼¼ÆÃ 
}

void CDPSrvr::OnStateMode( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwStateMode;
	BYTE nFlag;
	ar >> dwStateMode;
	ar >> nFlag;


	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj(pUser) )
	{	
		if( pUser->IsStateMode( dwStateMode ) )
		{
			if( nFlag == STATEMODE_BASEMOTION_CANCEL )
			{
				pUser->SetStateNotMode( STATE_BASEMOTION_MODE, STATEMODE_BASEMOTION_CANCEL );
				pUser->m_nReadyTime = 0;
				pUser->m_dwUseItemId = 0;
			}
		}
	}
}

// ºÎÈ°Ãë¼Ò
void CDPSrvr::OnResurrectionCancel( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj(pUser) && pUser->m_Resurrection_Data.bUseing )
	{	
		pUser->m_Resurrection_Data.bUseing = FALSE;
	}
}

// »ç¿ëÀÚ°¡ OKÇÏ¸é ºÎÈ°À» ¾²°Ô ÇÑ´Ù
void CDPSrvr::OnResurrectionOK( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );

	// ¼­¹ö¿¡¼­ ºÎÈ°¸ðµåÀÎ°¡??
	if( IsValidObj(pUser) && pUser->m_Resurrection_Data.bUseing )
	{	
		if( pUser->IsDie() == FALSE )
		{
			pUser->m_Resurrection_Data.bUseing = FALSE;
			return;
		}
		// ¾à°£ÀÇ ¿¡³ÊÁö¸¦ Ã¤¿öÁÖÀÚ
		if( pUser->GetType() == OT_MOVER )	// Å¸°ÙÀÌ ¹«¹öÀÏ¶§¸¸.
		{		
			RESURRECTION_DATA* pData = &(((CMover *)pUser)->m_Resurrection_Data);
			CUser* pSrc	= (CUser*)prj.GetUserByID( pData->dwPlayerID );

			if( IsValidObj(pSrc) )
			{
				// ºÎÈ° SFXÈ¿°ú
				g_UserMng.AddCreateSfxObj( pUser, XI_SKILL_ASS_HEAL_RESURRECTION01 );
				
				// ºÎÈ°ÇÏ±â
				g_UserMng.AddHdr( pUser, SNAPSHOTTYPE_RESURRECTION );
				pUser->m_pActMover->SendActMsg( OBJMSG_RESURRECTION );
				pUser->m_Resurrection_Data.bUseing = FALSE;
				
				pUser->ApplyParam( (CMover *)pSrc, pData->pSkillProp, pData->pAddSkillProp, TRUE , 0 );
				
				if( pData->pAddSkillProp->dwDestParam2 == DST_RECOVERY_EXP )
					pUser->SubDieDecExp(TRUE, pData->pAddSkillProp->nAdjParamVal2 );	// ºÎÈ°ÀÌ µÇ¸é¼­ °âÄ¡°¡ Á¶±Ý ±ðÀÓ.			
			}	
			else
				pUser->m_Resurrection_Data.bUseing = FALSE;

		}
	}
}

void CDPSrvr::OnChangeMode( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	int nFlag;
	DWORD dwMode;
	ar >> dwMode;
	ar >> nFlag;
	
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj(pUser) )
	{	
		switch( nFlag )
		{
		case 0:	// ÀÚµ¿ PK ON
			pUser->SetMode( FREEPK_MODE );
			break;
		case 1:	// ÀÚµ¿ PK OFF
			pUser->SetNotMode( FREEPK_MODE );
			break;
		case 2:	// ÀÚµ¿ PVP ON
			pUser->SetMode( PVPCONFIRM_MODE );
			break;
		case 3:	// ÀÚµ¿ PVP OFF
			pUser->SetNotMode( PVPCONFIRM_MODE );
			break;
		}
		g_UserMng.AddModifyMode( pUser );
	}
}

void CDPSrvr::OnQuerySetPlayerName( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
// II_SYS_SYS_SCR_CHANAM
	DWORD dwData;
	char lpszPlayer[MAX_PLAYER]	= { 0, };

	ar >> dwData;
	ar.ReadString( lpszPlayer, MAX_PLAYER );

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __QUIZ
		if( pUser->GetWorld() && pUser->GetWorld()->GetID() == WI_WORLD_QUIZ )
			return;
#endif // __QUIZ
#ifdef __RULE_0615
		if( prj.IsInvalidName( lpszPlayer ) || prj.IsAllowedLetter( lpszPlayer ) == FALSE )
		{
			pUser->AddDiagText(prj.GetText(TID_DIAG_0020));
#ifdef __GAMEGUARD
			return;
#endif // __GAMEGUARD
		}
		prj.Formalize( lpszPlayer );
#endif	// __RULE_0615

#ifdef __GAMEGUARD
		int nLen = strlen(lpszPlayer);
		char szH[2];
		char szA[10];
		strcpy(szH, "'");
		strcpy(szA, "\\");

		for (int i = 0; i < nLen; i++)
		{
			if (lpszPlayer[i] != 'a' && lpszPlayer[i] != 'b' && lpszPlayer[i] != 'c' && lpszPlayer[i] != 'd' && lpszPlayer[i] != 'e' && lpszPlayer[i] != 'f'
				&& lpszPlayer[i] != 'g' && lpszPlayer[i] != 'h' && lpszPlayer[i] != 'i' && lpszPlayer[i] != 'j' && lpszPlayer[i] != 'k' && lpszPlayer[i] != 'l'
				&& lpszPlayer[i] != 'm' && lpszPlayer[i] != 'n' && lpszPlayer[i] != 'o' && lpszPlayer[i] != 'p' && lpszPlayer[i] != 'q' && lpszPlayer[i] != 'r'
				&& lpszPlayer[i] != 's' && lpszPlayer[i] != 't' && lpszPlayer[i] != 'u' && lpszPlayer[i] != 'v' && lpszPlayer[i] != 'w' && lpszPlayer[i] != 'x'
				&& lpszPlayer[i] != 'y' && lpszPlayer[i] != 'z' && lpszPlayer[i] != 'A' && lpszPlayer[i] != 'B' && lpszPlayer[i] != 'C' && lpszPlayer[i] != 'D'
				&& lpszPlayer[i] != 'E' && lpszPlayer[i] != 'F' && lpszPlayer[i] != 'G' && lpszPlayer[i] != 'H' && lpszPlayer[i] != 'I' && lpszPlayer[i] != 'J'
				&& lpszPlayer[i] != 'K' && lpszPlayer[i] != 'L' && lpszPlayer[i] != 'M' && lpszPlayer[i] != 'N' && lpszPlayer[i] != 'O' && lpszPlayer[i] != 'P'
				&& lpszPlayer[i] != 'Q' && lpszPlayer[i] != 'R' && lpszPlayer[i] != 'S' && lpszPlayer[i] != 'T' && lpszPlayer[i] != 'U' && lpszPlayer[i] != 'V'
				&& lpszPlayer[i] != 'W' && lpszPlayer[i] != 'X' && lpszPlayer[i] != 'Y' && lpszPlayer[i] != 'Z')
			{
				pUser->AddDiagText(prj.GetText(TID_DIAG_0020));
				return;
			}
		}
#endif // __GAMEGUARD

#ifdef __S_SERVER_UNIFY
		if( pUser->m_bAllAction )
#endif // __S_SERVER_UNIFY
		{
			WORD wId	= LOWORD( dwData );
			WORD wMode	= HIWORD( dwData );
			if( (short)wId >= 0 )
			{
				CItemElem* pItemElem = (CItemElem*)pUser->GetItemId( wId );
				if( IsUsableItem( pItemElem ) && pItemElem->m_dwItemId == II_SYS_SYS_SCR_CHANAM && pItemElem->m_bQuery == FALSE )
				{
					pItemElem->m_bQuery	= TRUE;
					g_dpDBClient.SendQuerySetPlayerName( pUser->m_idPlayer, lpszPlayer, dwData );
				}
			}
		}
#ifdef __S_SERVER_UNIFY
		else
		{
			g_dpDBClient.SendQuerySetPlayerName( pUser->m_idPlayer, lpszPlayer, dwData );
		}
#endif // __S_SERVER_UNIFY
	}
}

void CDPSrvr::OnQuerySetGuildName( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE nId;
	char lpszGuild[MAX_G_NAME]	= { 0, };

	ar >> nId;
	ar.ReadString( lpszGuild, MAX_G_NAME );

	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __RULE_0615
		if( prj.IsInvalidName( lpszGuild ) || prj.IsAllowedLetter( lpszGuild ) == FALSE )
		{
			pUser->AddDiagText(prj.GetText(TID_DIAG_0020));
#ifdef __GAMEGUARD
			return;
#endif // __GAMEGUARD
		}
#endif	// __RULE_0615

#ifdef __GAMEGUARD
		int nLen = strlen(lpszGuild);
		char szH[2];
		char szA[10];
		strcpy(szH, "'");
		strcpy(szA, "\\");

		for (int i = 0; i < nLen; i++)
		{
			if (lpszGuild[i] != 'a' && lpszGuild[i] != 'b' && lpszGuild[i] != 'c' && lpszGuild[i] != 'd' && lpszGuild[i] != 'e' && lpszGuild[i] != 'f'
				&& lpszGuild[i] != 'g' && lpszGuild[i] != 'h' && lpszGuild[i] != 'i' && lpszGuild[i] != 'j' && lpszGuild[i] != 'k' && lpszGuild[i] != 'l'
				&& lpszGuild[i] != 'm' && lpszGuild[i] != 'n' && lpszGuild[i] != 'o' && lpszGuild[i] != 'p' && lpszGuild[i] != 'q' && lpszGuild[i] != 'r'
				&& lpszGuild[i] != 's' && lpszGuild[i] != 't' && lpszGuild[i] != 'u' && lpszGuild[i] != 'v' && lpszGuild[i] != 'w' && lpszGuild[i] != 'x'
				&& lpszGuild[i] != 'y' && lpszGuild[i] != 'z' && lpszGuild[i] != 'A' && lpszGuild[i] != 'B' && lpszGuild[i] != 'C' && lpszGuild[i] != 'D'
				&& lpszGuild[i] != 'E' && lpszGuild[i] != 'F' && lpszGuild[i] != 'G' && lpszGuild[i] != 'H' && lpszGuild[i] != 'I' && lpszGuild[i] != 'J'
				&& lpszGuild[i] != 'K' && lpszGuild[i] != 'L' && lpszGuild[i] != 'M' && lpszGuild[i] != 'N' && lpszGuild[i] != 'O' && lpszGuild[i] != 'P'
				&& lpszGuild[i] != 'Q' && lpszGuild[i] != 'R' && lpszGuild[i] != 'S' && lpszGuild[i] != 'T' && lpszGuild[i] != 'U' && lpszGuild[i] != 'V'
				&& lpszGuild[i] != 'W' && lpszGuild[i] != 'X' && lpszGuild[i] != 'Y' && lpszGuild[i] != 'Z')
			{
				pUser->AddDiagText(prj.GetText(TID_DIAG_0020));
				return;
			}
		}
#endif // __GAMEGUARD

#ifdef __S_SERVER_UNIFY
		if( pUser->m_bAllAction )
#endif // __S_SERVER_UNIFY
		{
			CItemElem* pItemElem = (CItemElem*)pUser->GetItemId( nId );
#ifdef __GAMEGUARD
			if (IsUsableItem(pItemElem) && pItemElem->m_bQuery == FALSE && pItemElem->m_dwItemId == II_SYS_SYS_SCR_GCHANAM)
#else // __GAMEGUARD
			if (IsUsableItem(pItemElem) && pItemElem->m_bQuery == FALSE)
#endif // __GAMEGUARD
			{
				pItemElem->m_bQuery	= TRUE;
				g_DPCoreClient.SendQuerySetGuildName( pUser->m_idPlayer, pUser->m_idGuild, lpszGuild, nId );
			}
		}
#ifdef __S_SERVER_UNIFY
		else
		{
			g_DPCoreClient.SendQuerySetGuildName( pUser->m_idPlayer, pUser->m_idGuild, lpszGuild, nId );
		}
#endif // __S_SERVER_UNIFY
	}
}

void CDPSrvr::PutCreateItemLog( CUser* pUser, CItemElem* pItemElem, const char* szAction, const char* recv )
{
	LogItemInfo logitem;
	logitem.Action		= szAction;
	logitem.SendName = pUser->GetName();
	logitem.RecvName = recv;
	logitem.WorldId = pUser->GetWorld()->GetID();
	logitem.Gold = pUser->GetGold();
	logitem.Gold2 = 0;
	logitem.ItemNo = pItemElem->GetSerialNumber();
	//logitem.ItemName = pItemElem->GetProp()->szName;
	_stprintf( logitem.szItemName, "%d", pItemElem->GetProp()->dwID );
	logitem.itemNumber = pItemElem->m_nItemNum;
	logitem.nAbilityOption = 0;
	logitem.Gold_1 = 0;
	logitem.nItemResist = pItemElem->m_bItemResist;
	logitem.nResistAbilityOption = pItemElem->m_nResistAbilityOption;
	logitem.Negudo		= 100;
	OnLogItem( logitem );
}

// Å¬¶ó·ÎºÎÅÍ Å»Ãâ¿äÃ»ÀÌ µé¾î¿È
void CDPSrvr::OnDoEscape( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		ItemProp* pItemProp = prj.GetItemProp( II_CHR_SYS_SCR_ESCAPEBLINKWING );
		if( pItemProp )
		{
			if( !pUser->IsSMMode( SM_ESCAPE ) )
				pUser->DoUseItemVirtual( II_CHR_SYS_SCR_ESCAPEBLINKWING, FALSE );
			else
				pUser->AddDefinedText( TID_GAME_STILLNOTUSE );		
		}
	}
}

void CDPSrvr::OnCheering( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objid;
	ar >> objid;

	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( pUser->GetId() == objid )
			return;

		CMover* pTarget		= prj.GetMover( objid );
		if( IsValidObj( pTarget ) && pTarget->GetType() == OT_MOVER && pTarget->IsPlayer() )
		{
			DWORD dwTickCount	= GetTickCount();
			if( pUser->m_nCheerPoint <= 0 )
			{
				pUser->AddDefinedText( TID_CHEER_NO1, "%d", (pUser->m_dwTickCheer - dwTickCount) / 60000 );
				return;
			}

			if( pUser->m_nCheerPoint == MAX_CHEERPOINT )
				pUser->SetCheerParam( pUser->m_nCheerPoint - 1, dwTickCount, TICK_CHEERPOINT );
			else
				pUser->SetCheerParam( pUser->m_nCheerPoint - 1, dwTickCount, pUser->m_dwTickCheer - dwTickCount );

			FLOAT fAngle = GetDegree(pTarget->GetPos(), pUser->GetPos());
			pUser->SetAngle(fAngle);

			if( pTarget->GetSex() == pUser->GetSex() )
			{
				((CUser*)pTarget)->AddDefinedText( TID_CHEER_MESSAGE3, "%s", pUser->GetName() );
				pUser->SendActMsg( OBJMSG_MOTION, MTI_CHEERSAME, ANILOOP_1PLAY );
			}
			else
			{
				((CUser*)pTarget)->AddDefinedText( TID_CHEER_MESSAGE4, "%s", pUser->GetName() );
				pUser->SendActMsg( OBJMSG_MOTION, MTI_CHEEROTHER, ANILOOP_1PLAY );
			}

			g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_CHEERSENDEFFECT );
			g_UserMng.AddCreateSfxObj(pTarget, XI_CHEERRECEIVEEFFECT );


			CMover* pSrc = (CMover*)pUser ;
			g_UserMng.AddMoverBehavior( pSrc, pSrc->GetPos(), pSrc->m_pActMover->m_vDelta,
				pSrc->GetAngle(), pSrc->m_pActMover->GetState(), pSrc->m_pActMover->GetStateFlag(), 
				pSrc->m_dwMotion, pSrc->m_pActMover->m_nMotionEx, pSrc->m_pModel->m_nLoop, pSrc->m_dwMotionOption, g_TickCount.GetTickCount(), TRUE );

#ifdef __RECORD_BOOK
			CRecordBook::GetInstance()->AddPlayerRecord(pUser, RecordType::CHEERS_GIVEN, 1, true);
			CRecordBook::GetInstance()->AddPlayerRecord(pTarget, RecordType::CHEERS_RECEIVED, 1, true);
#endif

			ItemProp *pItemProp = prj.GetItemProp( II_CHEERUP ); // ÀÀ¿ø ¾ÆÀÌÅÛ
			if( pItemProp )
				pTarget->DoApplySkill( pTarget, pItemProp, NULL );
		}
		else
		{
			pUser->AddDefinedText( TID_CHEER_NO2, "" );	
		}
	}
}

void CDPSrvr::OnQueryEquip( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objid;
	ar >> objid;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CUser* pUsertmp		= prj.GetUser( objid );
		if( IsValidObj( pUsertmp ) )
		{
#ifdef __NEWCLASS
			if (pUsertmp->IsMode(EQUIP_DENIAL_MODE))
			{
				if (pUser->IsAuthHigher(AUTH_GAMEMASTER))
				{
					pUser->AddQueryEquip(pUsertmp);
			}
				else
				{
					if (pUser->HasBuff(BUFF_SKILL, SI_WINDL_U_SKILL_02))
					{
						if (pUsertmp->IsAuthHigher(AUTH_GAMEMASTER))
						{
							CString str; str.Format(prj.GetText(TID_4TH_JOB_ER_02), NEUZ_TITLE);
							pUser->AddText(str, 0xFFFFFFFF);
						}
						else
						{
							pUser->RemoveBuff(BUFF_SKILL, SI_WINDL_U_SKILL_02);
							pUser->AddQueryEquip(pUsertmp);
						}
					}
					else
						pUser->AddDefinedText(TID_DIAG_0088);
				}
		}
			else
				pUser->AddQueryEquip(pUsertmp);
#else // __NEWCLASS
#ifdef __GAMEMASTER
			if (pUserTarget->IsMode(EQUIP_DENIAL_MODE) && pUser->IsAuthHigher(AUTH_GAMEMASTER2) == FALSE
#else // __GAMEMASTER
			if (pUserTarget->IsMode(EQUIP_DENIAL_MODE) && pUser->IsAuthHigher(AUTH_GAMEMASTER) == FALSE
#endif // __GAMEMASTER
				)
			{
				pUser->AddDefinedText(TID_DIAG_0088);
					return;
			}
			pUser->AddQueryEquip(pUserTarget);
#endif // __NEWCLASS
		}
	}
}

void CDPSrvr::OnQueryEquipSetting( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BOOL bAllow;
	ar >> bAllow;

	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( bAllow )
			pUser->SetNotMode( EQUIP_DENIAL_MODE );
		else
			pUser->SetMode( EQUIP_DENIAL_MODE );
		g_UserMng.AddModifyMode( pUser );
	}
}

#if __VER >= 12 // __UPDATE_OPT
void CDPSrvr::OnOptionEnableRenderMask( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		BOOL bEnable;
		ar >> bEnable;
		if( bEnable )
			pUser->SetNotMode( MODE_OPTION_DONT_RENDER_MASK );
		else
			pUser->SetMode( MODE_OPTION_DONT_RENDER_MASK );
		g_UserMng.AddModifyMode( pUser );
	}
}
#endif	// __UPDATE_OPT

void CDPSrvr::OnReturnScroll( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	int nSelect;
	ar >> nSelect;
	if( nSelect < -1 || nSelect > 2 )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) == FALSE )
		return;

	if( nSelect >= 0 )
	{
		static char* szPos[] = { "flaris",	"saintmorning",	"darkon" };
		pUser->m_lpszVillage = szPos[nSelect];
		pUser->AddReturnScroll();	//ÀÀ´äÀ» º¸³»¸é '±ÍÈ¯ÀÇ µÎ·ç¸¶¸®'¾ÆÀÌÅÛÀ» »ç¿ëÇÑ´Ù.	
	}
	else
	{
		// ÀúÀåµÈ À§Ä¡·Î µ¹¾Æ°¡±â 
		if( pUser->HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_RETURN ) )
			pUser->DoUseItemVirtual( II_SYS_SYS_SCR_RETURN, TRUE );
	}
}

void CDPSrvr::OnEndSkillQueue( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
		pUser->m_playTaskBar.OnEndSkillQueue( pUser );
}

void CDPSrvr::OnQueryPostMail( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	char lpszReceiver[MAX_PLAYER]	= { 0, };
	char lpszTitle[MAX_MAILTITLE]	= { 0, };
	char lpszText[MAX_MAILTEXT]		= { 0, };
	BYTE nItem;
	short nItemNum;
	int nGold;

	ar >> nItem >> nItemNum;
	ar.ReadString( lpszReceiver, MAX_PLAYER );
	
	ar >> nGold;
	ar.ReadString( lpszTitle, MAX_MAILTITLE );
	ar.ReadString( lpszText, MAX_MAILTEXT );

	DWORD nPostGold = 100;

	if( ::GetLanguage() != LANG_KOR )
		nPostGold = 500;
					
	if( nItem < 0 || nGold < 0 || ( nGold + nPostGold ) <= 0 )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bChat == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bChat == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		//raiders.2006.11.27
		if( pUser->m_vtInfo.GetOther() )	// °Å·¡ÁßÀÎ ´ë»óÀÌ ÀÖÀ¸¸é?
			return;
		if( pUser->m_vtInfo.VendorIsVendor() )		// ³»°¡ ÆÈ°í ÀÖÀ¸¸é?
			return;
		if( pUser->m_bBank )				// Ã¢°í¸¦ ¿­°í ÀÖÀ¸¸é?
			return;
#ifdef __S_SERVER_UNIFY
		if( pUser->m_bAllAction == FALSE )
			return;
#endif // __S_SERVER_UNIFY
		//--
#if __VER >= 11 // __SYS_PLAYER_DATA
		u_long idReceiver	= CPlayerDataCenter::GetInstance()->GetPlayerId( lpszReceiver );
#else	// __SYS_PLAYER_DATA
		u_long idReceiver	= prj.GetPlayerID( lpszReceiver );
#endif	// __SYS_PLAYER_DATA
		if( idReceiver > 0 )
		{
#if __VER >= 11 // __SYS_PLAYER_DATA
			if( CPlayerDataCenter::GetInstance()->GetPlayerId( (char*)pUser->GetName() ) == idReceiver )
#else	// __SYS_PLAYER_DATA
			if( prj.GetPlayerID( pUser->GetName() ) == idReceiver )
#endif	// __SYS_PLAYER_DATA
			{
				pUser->AddDiagText(prj.GetText(TID_GAME_MSGSELFSENDERROR));
				return;
			}

			if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_POST, pUser->GetWorld(), pUser->GetPos() ) )
			{
				return;
			}
			CMailBox* pMailBox	= CPost::GetInstance()->GetMailBox( idReceiver );
			if( pMailBox && pMailBox->size() >= MAX_MAIL )
			{
				pUser->AddDefinedText( TID_GAME_MAILBOX_FULL, "%s", lpszReceiver );
				return;
			}

			CItemElem* pItemElem	= pUser->m_Inventory.GetAtId( nItem );
			if( pItemElem )
			{
				if( IsUsableItem( pItemElem ) == FALSE )
				{
					pUser->AddDiagText( prj.GetText( TID_GAME_CANNOT_POST ) );
					return;
				}
				if( pUser->m_Inventory.IsEquip( pItemElem->m_dwObjId ) )
				{
					pUser->AddDiagText( prj.GetText( TID_GAME_CANNOT_POST ) );
					return;
				}
				if( pItemElem->IsQuest() )
				{
					pUser->AddDiagText( prj.GetText( TID_GAME_CANNOT_POST ) );
					return;
				}
				if( pItemElem->IsBinds() )
				{
					pUser->AddDiagText( prj.GetText( TID_GAME_CANNOT_POST ) );
					return;
				}
				if( pUser->IsUsing( pItemElem ) )
				{
					pUser->AddDiagText( prj.GetText( TID_GAME_CANNOT_DO_USINGITEM ) );
					return;
				}
				ItemProp* pProp	= pItemElem->GetProp();
				if( pProp->dwItemKind3 == IK3_CLOAK && pItemElem->m_idGuild != 0 )
				{
					pUser->AddDiagText( prj.GetText( TID_GAME_CANNOT_POST ) );
					return;
				}

//				if( pItemElem->m_dwItemId == II_RID_RID_BOR_EVEINSHOVER || pItemElem->m_dwItemId == II_RID_RID_BOR_LADOLF )
//				{
//					pUser->AddDiagText( prj.GetText( TID_GAME_CANNOT_POST ) );
//					return;
//				}
				if( pProp->dwParts == PARTS_RIDE && pProp->dwItemJob == JOB_VAGRANT )
				{
					pUser->AddDiagText( prj.GetText( TID_GAME_CANNOT_POST ) );
					return;
				}

				if( nItemNum <= 0 )			// hacking
					return;
				if( pItemElem->m_nItemNum < nItemNum )
					nItemNum	= pItemElem->m_nItemNum;
				if( pItemElem->IsCharged() )
				{
					pUser->AddDiagText( prj.GetText( TID_GAME_CANNOT_POST ) );
					return;
				}
			}
#ifdef __SECURITY_FIXES
			if( pUser->GetGold() < (UINT)( ( nPostGold + nGold ) ) )
			{
				pUser->AddDiagText( prj.GetText( TID_GAME_LACKMONEY ) );
				return;
			}

			pUser->AddGold( (int)( (UINT)( nPostGold + nGold ) * (-1) ), TRUE );	// »ç¿ë·á Áö±Þ
#else // __SECURITY_FIXES
			if( pUser->GetGold() < (int)( ( nPostGold + nGold ) ) || nGold > 2000000000) //overflow.
			{
				pUser->AddDiagText( prj.GetText( TID_GAME_LACKMONEY ) );
				return;
			}

			pUser->AddGold( (int)( (int)( nPostGold + nGold ) * (-1) ), TRUE );	// »ç¿ë·á Áö±Þ
#endif // __SECURITY_FIXES			
			CItemElem	itemElem;
			if( pItemElem )
			{
				itemElem	= *pItemElem;
				itemElem.m_nItemNum		= nItemNum;
				pUser->RemoveItem( (BYTE)pItemElem->m_dwObjId, nItemNum );
				CWorld* pWorld	= pUser->GetWorld();
				if( pWorld )
#ifdef __LAYER_1015
					g_dpDBClient.SavePlayer( pUser, pWorld->GetID(), pUser->GetPos(), pUser->GetLayer() );
#else	// __LAYER_1015
					g_dpDBClient.SavePlayer( pUser, pWorld->GetID(), pUser->GetPos() );
#endif	// __LAYER_1015
			}

// 			//	BEGINTEST
// 			Error( "OnQueryPostMail  Receiver[%d] Sender[%d]", idReceiver, pUser->m_idPlayer );

			g_dpDBClient.SendQueryPostMail( idReceiver, pUser->m_idPlayer, itemElem, nGold, lpszTitle, lpszText );
		}
		else
		{
			// input name is wrong
			pUser->AddDiagText(prj.GetText(TID_MAIL_UNKNOW));
		}
	}
	else
	{
// 		//	BEGINTEST
// 		Error( "OnQueryPostMail  pUser == NULL [%d]", dpidUser );
	}

}

void CDPSrvr::OnQueryRemoveMail( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long nMail;
	ar >> nMail;

	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CMailBox* pMailBox = CPost::GetInstance()->GetMailBox( pUser->m_idPlayer );
		if( pMailBox != NULL )
		{
			CMail* pMail = pMailBox->GetMail( nMail );
			if( pMail != NULL )
			{
				g_dpDBClient.SendQueryRemoveMail( pUser->m_idPlayer, nMail );
			}
			else
			{
				Error( "CDPSrvr::OnQueryRemoveMail - Invalid nMail. idReceiver : %07d, nMail :[%d]", pUser->m_idPlayer, nMail );
			}
		}
		else
		{
			Error( "CDPSrvr::OnQueryRemoveMail - Invalid pMailBox. idReceiver : %07d, nMail :[%d]", pUser->m_idPlayer, nMail );
		}
	}
}

void CDPSrvr::OnQueryGetMailItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long nMail;
	ar >> nMail;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
#ifndef __TABBED_INV
		if (pUser->m_Inventory.GetEmptyCount() < 1)
		{
			pUser->AddDiagText(prj.GetText(TID_GAME_LACKSPACE));
			return;
		}
#endif // __TABBED_INV
		
		CMailBox* pMailBox	= CPost::GetInstance()->GetMailBox( pUser->m_idPlayer );
		if( pMailBox )
		{
			CMail* pMail = pMailBox->GetMail(nMail);
			if( pMail && pMail->m_pItemElem )
			{
#ifdef __TABBED_INV
				if (pUser->m_Inventory.GetEmptyCount(pMail->m_pItemElem->GetProp()->GetInvenIndex()) < 1)
				{
					pUser->AddDiagText(prj.GetText(TID_GAME_LACKSPACE));
					return;
				}
#else // __TABBED_INV
				if( pUser->m_Inventory.GetEmptyCount() < 1 )
				{
					pUser->AddDiagText(  prj.GetText( TID_GAME_LACKSPACE ) );
					return;
				}
#endif
				// ±âº» º¸°üÀÏ¼ö Áö³µ´ÂÁö¸¦ °Ë»çÇÏ¿© º¸°ü·á ºÎ°úÇÑ´Ù.
				int nDay = 0;
				DWORD dwTime = 0;
				pMail->GetMailInfo( &nDay, &dwTime );

				// ±âº» º¸°üÀÏ¼ö°¡ Áö³µ´Ù!!!
				if( (MAX_KEEP_MAX_DAY*24) - dwTime > (MAX_KEEP_BASIC_DAY*24) )
				{
					FLOAT fCustody = 0.0f;
					FLOAT fPay = 0.0f;
					fCustody = (FLOAT)( (FLOAT)( MAX_KEEP_MAX_DAY - MAX_KEEP_BASIC_DAY - nDay ) / (FLOAT)( MAX_KEEP_MAX_DAY - MAX_KEEP_BASIC_DAY ) );
					fPay = pMail->m_pItemElem->GetCost() * fCustody;
					if( fPay < 0.0f )
						fPay = 0.0f;

					if( (int)fPay > pUser->GetGold() )
					{
						pUser->AddDiagText( prj.GetText( TID_GAME_LACKMONEY ) );
						return;
					}
					pUser->AddGold( -((int)fPay) );
				}
			}
		}
		g_dpDBClient.SendQueryGetMailItem( pUser->m_idPlayer, nMail );
	}
}

void CDPSrvr::OnQueryGetMailGold( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long nMail;
	ar >> nMail;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		CMailBox* pMailBox = CPost::GetInstance()->GetMailBox( pUser->m_idPlayer );
		if( pMailBox != NULL )
		{
			CMail* pMail = pMailBox->GetMail( nMail );
			if( pMail != NULL )
			{
				g_dpDBClient.SendQueryGetMailGold( pUser->m_idPlayer, nMail );
			}
			else
			{
				Error( "CDPSrvr::OnQueryGetMailGold - Invalid nMail. idReceiver : %07d, nMail :[%d]", pUser->m_idPlayer, nMail );
			}
		}
		else
		{
			Error( "CDPSrvr::OnQueryGetMailGold - Invalid pMailBox. idReceiver : %07d, nMail :[%d]", pUser->m_idPlayer, nMail );
		}
	}
}

void CDPSrvr::OnQueryReadMail( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	u_long nMail;
	ar >> nMail;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bChat == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bChat == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		CMailBox* pMailBox = CPost::GetInstance()->GetMailBox( pUser->m_idPlayer );
		if( pMailBox != NULL )
		{
			CMail* pMail = pMailBox->GetMail( nMail );
			if( pMail != NULL )
			{
				g_dpDBClient.SendQueryReadMail( pUser->m_idPlayer, nMail );
			}
			else
			{
				Error( "CDPSrvr::OnQueryReadMail - Invalid nMail. idReceiver : %07d, nMail :[%d]", pUser->m_idPlayer, nMail );
			}
		}
		else
		{
			Error( "CDPSrvr::OnQueryReadMail - Invalid pMailBox. idReceiver : %07d, nMail :[%d]", pUser->m_idPlayer, nMail );
		}
	}
}

void CDPSrvr::OnQueryMailBox( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
// 	//	BEGINTEST
// 	Error( "OnQueryMailBox [%d]", dpidUser );

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );

	int	nClientReqCount	= 1;

	if( IsValidObj( pUser ) )
	{
		if( pUser->CheckClientReq()== false )
		{
			nClientReqCount	= 1;
		}
		else
		{
			nClientReqCount	= pUser->GetCountClientReq();
		}

		CMailBox* pMailBox	= CPost::GetInstance()->GetMailBox( pUser->m_idPlayer );
		if( pMailBox )
		{
			switch( pMailBox->m_nStatus )
			{
				case CMailBox::data:	// µ¥ÀÌÅÍ°¡ µé¾îÀÖ´Â ¸ÞÀÏ ¹Ú½º¸é ¹Ù·Î »ç¿ëÀÚ Àü¼Û
					{
						if( nClientReqCount <= 1 )
						{
							pUser->AddMailBox( pMailBox );
						}
						else
						{
							g_dpDBClient.SendQueryMailBoxCount( pUser->m_idPlayer, pUser->GetCountClientReq() );
						}

// 						//	BEGINTEST
// 						Error( "OnQueryMailBox CMailBox::data [%d]", dpidUser );
					}
					break;
				case CMailBox::nodata:	// µ¥ÀÌÅÍ°¡ ¾ø´Â ¸ÞÀÏ ¹Ú½º¸é Æ®·£½º ¼­¹ö¿¡ Á¤º¸ ¿äÃ», »óÅÂ´Â ÀÐ´Â Áß
					{
						if( nClientReqCount >= 2 )
						{
							g_dpDBClient.SendQueryMailBoxCount( pUser->m_idPlayer, pUser->GetCountClientReq() );
						}
						else
						{
							g_dpDBClient.SendQueryMailBox( pUser->m_idPlayer );
						}

						pMailBox->m_nStatus		= CMailBox::read;
					}
					break;
				case CMailBox::read:	// µ¥ÀÌÅÍ¸¦ ¿äÃ»ÇÏ°í ´ë±âÇÏ´Â »óÅÂ¸é ¹«½Ã
					{
						if( nClientReqCount >= 2 )
						{
							g_dpDBClient.SendQueryMailBoxCount( pUser->m_idPlayer, pUser->GetCountClientReq() );
						}
// 						//	BEGINTEST
// 						Error( "OnQueryMailBox CMailBox::read [%d]", dpidUser );
					}
					break;
				default:
					{
// 						//	BEGINTEST
// 						Error( "OnQueryMailBox default [%d]", dpidUser );
					}
					break;
			}
		}
		else // ¿ùµå¼­¹ö¿¡ À¯ÀúÀÇ ¸ÞÀÏ¹Ú½º°¡ ¾ø´Ù. Æ®·£½º¿¡ ¿äÃ»
		{
			if( pUser->GetCheckTransMailBox() == FALSE )
			{
				g_dpDBClient.SendQueryMailBoxReq( pUser->m_idPlayer );
			}
			else
			{
				pUser->SendCheckMailBoxReq( FALSE );
			}
		}
	}
	else
	{
		Error( "CDPSrvr::OnQueryMailBox - Invalid User : %d", dpidUser );
	}
}

void CDPSrvr::OnGCApp( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE nState;
	ar >> nState;
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{

		if (pUser->IsDie() == TRUE)
		{
			return;
		}

#ifdef __GUILD_WINNER_BUFF
		if (pUser->m_idGuild == g_GuildCombatMng.m_uWinGuildId && g_GuildCombatMng.m_nWinGuildCount >= 2)
		{
			pUser->AddDiagText(prj.GetText(TID_GAME_GUILDCOMBAT_WIN_EXCESS));
			return;
		}
#endif //__GUILD_WINNER_BUFF
		CGuild *pGuild = pUser->GetGuild();

		// ±æµå°¡ ¾ø°Å³ª ±æµåÀåÀÌ ¾Æ´Ï¸é ½ÅÃ» ºÒ°¡
#ifdef __FL_NEW_GUILD_PERM
		if (!pGuild)
		{
			pUser->AddText("You are not in a guild!");
			return;
		}
		CGuildMember* pMember = pGuild->GetMember(pUser->m_idPlayer);
		if (!pMember)
		{
			return;
		}
		if (pGuild == NULL || (pGuild->IsMaster(pUser->m_idPlayer) == FALSE && pGuild->IsCmdCap(pMember->m_nMemberLv, PF_GUILDCOMBAT) == FALSE))
#else //__FL_NEW_GUILD_PERM
		if (pGuild == NULL || pGuild->IsMaster(pUser->m_idPlayer) == FALSE)
#endif //__FL_NEW_GUILD_PERM
		{
			pUser->AddDiagText( prj.GetText( TID_GAME_GUILDCOMBAT_NOT_GUILD_LEADER ) );
			return;
		}

		if( nState == GC_IN_WINDOW )
		{
			CGuild* pGuild	= g_GuildMng.GetGuild( pUser->m_idGuild );
#ifdef __FL_NEW_GUILD_PERM
			if (pGuild && (pGuild->IsMaster(pUser->m_idPlayer) || pGuild->IsCmdCap(pMember->m_nMemberLv, PF_GUILDCOMBAT)))
#else //__FL_NEW_GUILD_PERM
			if (pGuild && pGuild->IsMaster(pUser->m_idPlayer))
#endif //__FL_NEW_GUILD_PERM
			{
#if __VER >= 11 // __GUILD_COMBAT_1TO1
				// 1:1±æµå´ëÀü¿¡ ÀÔÂûÇÑ ±æµå´Â ÀÔÂû ºÒ°¡´ÉÇÏ´Ù.
				int nIndex = g_GuildCombat1to1Mng.GetTenderGuildIndexByUser( pUser );
				if( nIndex != NULL_ID )
				{
					pUser->AddDefinedText( TID_GAME_GUILDCOMBAT1TO1_ISGC1TO1TENDER );
					return;
				}
#endif // __GUILD_COMBAT_1TO1		
				pUser->AddGCWindow( g_GuildCombatMng.GetPrizePenya( 2 ), g_GuildCombatMng.GetRequstPenya( pUser->m_idGuild ), g_GuildCombatMng.m_nJoinPanya );
			}
		}
		else if( nState == GC_IN_APP )
		{
			DWORD dwPenya;
			ar >> dwPenya;
			g_GuildCombatMng.GuildCombatRequest( pUser, dwPenya );	// 
		}
	}
}
void CDPSrvr::OnGCCancel( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
		g_GuildCombatMng.GuildCombatCancel( pUser );
}
void CDPSrvr::OnGCRequestStatus( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );

	if( IsValidObj( pUser ) )
		pUser->AddGCRequestStatus( g_GuildCombatMng.GetPrizePenya( 2 ), g_GuildCombatMng.vecRequestRanking );
}
void CDPSrvr::OnGCSelectPlayer( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BOOL bWindow;
	ar >> bWindow;
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		// Ä³¸¯ÅÍ¸¦ ¼±ÅÃÇÒ¼ö ÀÖ´Â ½Ã°£ÀÎÁö °Ë»ç
		if( g_GuildCombatMng.m_nGCState != CGuildCombat::NOTENTER_COUNT_STATE ) 
		{
 			pUser->AddText( prj.GetText(TID_GAME_GUILDCOMBAT_CANNOT_MAKEUP) ); //Áö±ÝÀº ¸í´ÜÀÛ¼ºÀ» ÇÒ ¼ö ¾ø½À´Ï´Ù.		
			return;
		}

		// Ä³¸¯ÅÍ¸¦ ¼±ÅÃÇÒ¼ö ÀÖ´Â ±æµå ÀÎÁö °Ë»ç
		if( g_GuildCombatMng.IsRequestWarGuild( pUser->m_idGuild, FALSE ) == FALSE )
		{
			pUser->AddText( prj.GetText(TID_GAME_GUILDCOMBAT_CANNOT_MAKEUP_FAIL) );	//±æµå´ëÀü ÀÔÂûÀ» ÇÏÁö ¾Ê¾Ò°Å³ª ÃÖÁ¾ ¼±¹ß ±æµå¼øÀ§¿¡ µéÁö ¸øÇß½À´Ï´Ù.		
			return;
		}

		CGuild* pGuild	= g_GuildMng.GetGuild( pUser->m_idGuild );
		// Ä³¸¯ÅÍ¸¦ ¼±ÅÃÇÒ¼ö ÀÕ´Â°ÍÀº ¸¶½ºÅÍ¿Í Å·ÇÉ±ÞÀÌ´Ù.
		BOOL bMK = FALSE;
		if( pGuild )
		{
			CGuildMember* pGuildMember = pGuild->GetMember( pUser->m_idPlayer );
			if( pGuildMember )
			{
#ifdef __FL_NEW_GUILD_PERM
				if (pGuildMember->m_nMemberLv == GUD_KINGPIN || pGuildMember->m_nMemberLv == GUD_MASTER || pGuild->IsCmdCap(pGuildMember->m_nMemberLv, PF_GUILDCOMBAT)) // Select players for combat
					bMK = TRUE;
#else //__FL_NEW_GUILD_PERM
				if (pGuildMember->m_nMemberLv == GUD_KINGPIN || pGuildMember->m_nMemberLv == GUD_MASTER)
					bMK = TRUE;
#endif //__FL_NEW_GUILD_PERM
			}
		}
		
		
		if( pGuild && bMK )
		{
			if( bWindow == FALSE )
			{
				// À©µµ¿ì ¸Þ¼¼Áö°¡ ¾Æ´Ï¹Ç·Î Settting
				int nSize;
				u_long uidPlayer, uidDefender;
				vector< u_long > vecSelectPlayer;
				BOOL bMasterOrKinpin = FALSE;
				BOOL bDefender = FALSE;
				BOOL bLevel = FALSE;
				BOOL bLogOut = FALSE;
				BOOL bGuildMember = FALSE;
				BOOL bMastertoDefender = FALSE;
				vecSelectPlayer.clear();
				ar >> uidDefender;
				ar >> nSize;
				if( nSize > g_GuildCombatMng.m_nMaxJoinMember )
					return;

				for( int i = 0 ; i < nSize ; ++i )
				{
					ar >> uidPlayer;
					vecSelectPlayer.push_back( uidPlayer );
					CUser* pUsertmp = g_UserMng.GetUserByPlayerID( uidPlayer );
					if( IsValidObj( pUsertmp ) )
					{
						CGuildMember* pGuildMember = pGuild->GetMember( uidPlayer );
						// ±æµåÀÇ ¸É¹ö
						if( pGuildMember )
						{
							// ¸¶½ºÅÍ°¡ ¸®½ºÆ®¿¡ ÀÖ´ÂÁö?
							if( pGuild->IsMaster( pUsertmp->m_idPlayer ) )
								bMasterOrKinpin = TRUE;
							// Å·ÇÉÀÌ ¸®½ºÆ®¿¡ ÀÖ´ÂÁö?
							if( pGuildMember->m_nMemberLv == GUD_KINGPIN )
								bMasterOrKinpin = TRUE;
							// µðÆæ´õ°¡ ¸®½ºÆ®¿¡ ÀÖ´ÂÁö?
							if( pUsertmp->m_idPlayer == uidDefender )
								bDefender = TRUE;
#ifdef __FL_NEW_GUILD_PERM
							if (pGuild->IsCmdCap(pGuildMember->m_nMemberLv, PF_GUILDCOMBAT))
							{
								bMasterOrKinpin = TRUE;
							}
#endif //__FL_NEW_GUILD_PERM
						}
					}
				}
				// ¸¶½ºÅÍ´Â µðÆæ´õ°¡ µÉ¼ö ¾øÀ½.
				if( 1 < nSize && pGuild->IsMaster( uidDefender ) )
					bMastertoDefender = TRUE;

				if( bMasterOrKinpin && bMastertoDefender == FALSE 
#ifndef _DEBUG
					&& bDefender
#endif // _DEBUG
					)
				{
					g_GuildCombatMng.SelectPlayerClear( pUser->m_idGuild );
					for( int veci = 0 ; veci < (int)( vecSelectPlayer.size() ) ; ++veci )
					{
						// ÃÖ´ë ÀÎ¿ø¼ö ÀÌ»óÀº ¾Èµé¾î°¡Áü.
						if( veci >= g_GuildCombatMng.m_nMaxJoinMember )
							break;

						u_long uidSelectPlayer = vecSelectPlayer[veci];
						CUser* pUsertmp = g_UserMng.GetUserByPlayerID( uidSelectPlayer );
						{
							if( IsValidObj( pUsertmp ) )
							{
								CGuildMember* pGuildMember = pGuild->GetMember( uidPlayer );
								// ±æµåÀÇ ¸É¹ö
								if( pGuildMember )
								{
									// ·¹º§ÀÌ 30ÀÌ»ó¸¸ Âü¿©°¡´É
									if( 30 <= pUsertmp->GetLevel() )
									{
										g_GuildCombatMng.AddSelectPlayer( pUser->m_idGuild, uidSelectPlayer );
									}
								}
							}
						}						
					}
					g_GuildCombatMng.SetDefender( pUser->m_idGuild, uidDefender );			

#ifndef __FIX_TIMER_GW
					WriteLog("GuildCombat SelectPlayer GuildID=%d", pUser->m_idGuild);
#endif //__FIX_TIMER_GW
				}
			}

			vector<CGuildCombat::__JOINPLAYER> vecSelectList;
			g_GuildCombatMng.GetSelectPlayer( pUser->m_idGuild, vecSelectList );
			pUser->AddGCSelectPlayerWindow( vecSelectList, g_GuildCombatMng.GetDefender(pUser->m_idGuild), bWindow, g_GuildCombatMng.IsRequestWarGuild(pUser->m_idGuild, FALSE) );
			if( bWindow == FALSE )
			{
				g_UserMng.AddGCGuildStatus( pUser->m_idGuild );
				g_UserMng.AddGCWarPlayerlist( pUser->m_idGuild );
			}
		}
	}
}
void CDPSrvr::OnGCSelectMap( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	int nMap;
	ar >> nMap;
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )

		g_GuildCombatMng.SetSelectMap( pUser, nMap );
}
void CDPSrvr::OnGCJoin( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_GUILDWAR_JOIN, pUser->GetWorld(), pUser->GetPos() ) )
			return;
		g_GuildCombatMng.GuildCombatEnter( pUser );
	}
}
void CDPSrvr::OnGCGetPenyaGuild( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CGuild *pGuild = pUser->GetGuild();		
		if( pGuild && pGuild->IsMaster( pUser->m_idPlayer ) )
		{
			// ½ÅÃ»±Ý¾× ¹× º¸»óÀÌ ÀÖ´Â°¡?
			__int64 nGetPenya = 0;
			BOOL bFind = FALSE;
			CGuildCombat::__GCRESULTVALUEGUILD ResultValueGuild;
			for( int veci = 0 ; veci < (int)( g_GuildCombatMng.m_GCResultValueGuild.size() ) ; ++veci )
			{
				ResultValueGuild = g_GuildCombatMng.m_GCResultValueGuild[veci];
				if( pGuild->m_idGuild == ResultValueGuild.uidGuild )
				{
					bFind = TRUE;
					nGetPenya = ResultValueGuild.nReturnCombatFee + ResultValueGuild.nReward;
					break;
				}
			}

			if( bFind )
			{
				__int64 nTotal = (__int64)pUser->GetGold() + nGetPenya;
				if( nGetPenya > INT_MAX || nTotal > INT_MAX )
					pUser->AddGCGetPenyaGuild( 3, nGetPenya );
				else
					g_dpDBClient.SendGCGetPenyaGuild( pUser->m_idPlayer, ResultValueGuild.nCombatID, ResultValueGuild.uidGuild );
			}
			else
			{
				pUser->AddGCGetPenyaGuild( 2, nGetPenya );
			}
		}
	}
}

void CDPSrvr::OnGCGetPenyaPlayer( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		// º¸»óÀÌ ÀÖ´Â°¡?
		__int64 nGetPenya = 0;
		BOOL bFind = FALSE;
		CGuildCombat::__GCRESULTVALUEPLAYER ResultValuePlayer;
		for( int veci = 0 ; veci < (int)( g_GuildCombatMng.m_GCResultValuePlayer.size() ) ; ++veci )
		{
			ResultValuePlayer = g_GuildCombatMng.m_GCResultValuePlayer[veci];
			if( pUser->m_idPlayer == ResultValuePlayer.uidPlayer )
			{
				bFind = TRUE;
				nGetPenya = ResultValuePlayer.nReward;
				break;
			}
		}

		if( bFind )
		{
			__int64 nTotal = (__int64)pUser->GetGold() + nGetPenya;
			if( nGetPenya > INT_MAX || nTotal > INT_MAX )
				pUser->AddGCGetPenyaPlayer( 2, nGetPenya );
			else
				g_dpDBClient.SendGCGetPenyaPlayer( pUser->m_idPlayer, ResultValuePlayer.nCombatID, ResultValuePlayer.uidGuild );
		}
		else
		{
			pUser->AddGCGetPenyaPlayer( 1, nGetPenya );
		}
	}
}

#if __VER < 8 // #ifndef __GUILDCOMBAT_85
void CDPSrvr::OnGCGetItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CGuild *pGuild = pUser->GetGuild();		
		if( pGuild && pGuild->IsMember( pUser->m_idPlayer ) )
		{
			if( pGuild->GetGuildId() != g_GuildCombatMng.m_uWinGuildId )
				return;

			if( g_GuildCombatMng.m_nItemPenya > pUser->GetGold() )
			{
				pUser->AddText( prj.GetText(TID_GAME_LACKMONEY) ); //Æä³Ä(µ·)°¡ ºÎÁ·ÇÕ´Ï´Ù.
				return;
			}

			if( g_GuildCombatMng.m_nGCState != CGuildCombat::WAR_CLOSE_STATE && g_GuildCombatMng.m_nGCState != CGuildCombat::WAR_TELEPORT_STATE )
			{
				pUser->AddText( prj.GetText(TID_GAME_GUILDCOMBAT_NOT_GETITEM) ); // ±æµå´ëÀü Áß¿¡´Â »ç¿ëÇÒ¼ö ¾ø½À´Ï´Ù.
				return;
			}

			// ´ëÀü »óÇ° Áö±Þ
			CItemElem itemElem;
			
			if( g_GuildCombatMng.m_nWinGuildCount == 1 )
				itemElem.m_dwItemId	= II_ARM_S_CLO_CLO_DRAGON1;		// ¿ë¸ÁÅä »ý¼º
			else if( g_GuildCombatMng.m_nWinGuildCount == 2 )
				itemElem.m_dwItemId	= II_ARM_S_CLO_CLO_DRAGON2;		// ¿ë¸ÁÅä »ý¼º
			else if( g_GuildCombatMng.m_nWinGuildCount == 3 )
				itemElem.m_dwItemId	= II_ARM_S_CLO_CLO_DRAGON3;		// ¿ë¸ÁÅä »ý¼º
			else if( g_GuildCombatMng.m_nWinGuildCount >= 4 )
				itemElem.m_dwItemId	= II_ARM_S_CLO_CLO_DRAGON4;		// ¿ë¸ÁÅä »ý¼º
			itemElem.m_nItemNum		= 1;
			itemElem.m_idGuild	= pGuild->m_idGuild;
			itemElem.SetSerialNumber();
			ItemProp* pItemProp		= itemElem.GetProp();
			if( pItemProp )
				itemElem.m_nHitPoint	= pItemProp->dwEndurance;
			else
				itemElem.m_nHitPoint	= 0;

			CTime tNextCombat = g_GuildCombatMng.GetNextGuildCobmatTime();
			itemElem.m_dwKeepTime = tNextCombat.GetTime();
			
			if( pUser->CreateItem( &itemElem ) )
			{
				LogItemInfo aLogItem;
				aLogItem.Action = "9";
				aLogItem.SendName = pUser->GetName();
				aLogItem.RecvName = "GUILDCOMBAT";
				aLogItem.WorldId = pUser->GetWorld()->GetID();
				aLogItem.Gold = pUser->GetGold();
				aLogItem.Gold2 = pUser->GetGold() - g_GuildCombatMng.m_nItemPenya;
				OnLogItem( aLogItem, &itemElem, 1 );		// why do not pass &itemElem as argument?
				pUser->AddGold( -g_GuildCombatMng.m_nItemPenya );	
			}
			else
			{
				pUser->AddDefinedText( TID_GAME_LACKSPACE, "" );
			}
		}
	}
}
#endif // __VER < 8
void CDPSrvr::OnGCTele( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		PRegionElem pRgnElem = g_WorldMng.GetRevivalPos(WI_WORLD_MADRIGAL, "flaris");
		if (pRgnElem)
			((CMover*)pUser)->REPLACE(g_uIdofMulti, WI_WORLD_MADRIGAL, D3DXVECTOR3(6983.0f, 0.0f, 3330.0f), REPLACE_NORMAL, nDefaultLayer);
	}
}
void CDPSrvr::OnGCPlayerPoint( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
		pUser->AddGCPlayerPoint();
}

void CDPSrvr::OnSummonFriend( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwData;
	char lpszPlayer[MAX_PLAYER]	= { 0, };
	
	ar >> dwData;
	ar.ReadString( lpszPlayer, MAX_PLAYER );

	if( strlen(lpszPlayer) >= MAX_NAME )
		return;
	
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		int nState = pUser->GetSummonState();
		if( nState != 0 )
		{
			DWORD dwMsgId = 0;
			if( nState == 1 )	// °Å·¡Áß
				dwMsgId = TID_GAME_TRADE_NOTUSE;
			else if( nState == 2 ) // Á×À½
				dwMsgId = TID_GAME_DIE_NOTUSE;
			else if( nState == 3 ) // °³ÀÎ»óÁ¡ Áß
				dwMsgId = TID_GAME_VENDOR_NOTUSE;
			else if( nState == 4 ) // ÀüÅõÁß
				dwMsgId = TID_GAME_ATTACK_NOTUSE;
			else if( nState == 5 ) // ºñÇàÁß
				dwMsgId = TID_GAME_FLY_NOTUSE;
#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
			else if( nState == 6 ) // µà¾óÁß
				dwMsgId = TID_GAME_ATTACK_NOTUSE;
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma

			pUser->AddDefinedText( TID_GAME_STATE_NOTUSE, "\"%s\"", prj.GetText( dwMsgId ) );
			return;
		}

		WORD wId	= LOWORD( dwData );
		WORD wMode	= HIWORD( dwData );
		CItemElem* pItemElem = (CItemElem*)pUser->GetItemId( wId );
		if( IsUsableItem( pItemElem ) )
		{
			if( pItemElem->m_dwItemId != II_SYS_SYS_SCR_FRIENDSUMMON_A && pItemElem->m_dwItemId != II_SYS_SYS_SCR_FRIENDSUMMON_B )
				return;
			if( pItemElem->m_bQuery )
				return;

#if __VER >= 11 // __SYS_PLAYER_DATA
			CUser* pUsertmp = g_UserMng.GetUserByPlayerID( CPlayerDataCenter::GetInstance()->GetPlayerId( lpszPlayer ) );
#else	// __SYS_PLAYER_DATA
			CUser* pUsertmp = g_UserMng.GetUserByPlayerID( prj.GetPlayerID( lpszPlayer ) );
#endif	// __SYS_PLAYER_DATA
			if( IsValidObj( (CObj*)pUsertmp ) )
			{
				nState = pUsertmp->GetSummonState();
				if( nState != 0 )
				{
					DWORD dwMsgId = 0;
					if( nState == 1 )	// °Å·¡Áß
						dwMsgId = TID_GAME_TRADE_NOTUSE1;
					else if( nState == 2 ) // Á×À½
						dwMsgId = TID_GAME_DIE_NOTUSE1;
					else if( nState == 3 ) // °³ÀÎ»óÁ¡ Áß
						dwMsgId = TID_GAME_VENDOR_NOTUSE1;
					else if( nState == 4 ) // ÀüÅõÁß
						dwMsgId = TID_GAME_ATTACK_NOTUSE1;
					else if( nState == 5 ) // ºñÇàÁß
						dwMsgId = TID_GAME_FLY_NOTUSE1;
#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
					else if( nState == 6 ) // µà¾óÁß
						dwMsgId = TID_GAME_ATTACK_NOTUSE1;
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma
					
					pUser->AddDefinedText( TID_GAME_STATE_NOTUSE, "\"%s\"", prj.GetText( dwMsgId ) );
				}
				else if( pUser->m_idPlayer == pUsertmp->m_idPlayer )
				{
					pUser->AddDefinedText( TID_GAME_SUMMON_FRIEND_MY_NOUSE );
				}
				else if( prj.IsGuildQuestRegion( pUser->GetPos() ) )
				{
					pUser->AddDefinedText( TID_GAME_STATE_NOTUSE, "\"%s\"", prj.GetText( TID_GAME_EVENT_WORLD_NOTUSE ) );
				}
				else if( prj.IsGuildQuestRegion( pUsertmp->GetPos() ) )
				{
					pUser->AddDefinedText( TID_GAME_STATE_NOTUSE, "\"%s\"", prj.GetText( TID_GAME_EVENT_WORLD_NOTUSE1 ) );
				}
				else if( pUser->GetWorld()->GetID() != pUsertmp->GetWorld()->GetID()
#if __VER >= 14 // __INSTANCE_DUNGEON
						|| pUser->GetLayer() != pUsertmp->GetLayer()
#endif // __INSTANCE_DUNGEON
					)
				{
					CString strtmp;
					strtmp.Format( prj.GetText( TID_GAME_WORLD_NOTUSE ), pUser->GetWorld()->m_szWorldName, pUsertmp->GetWorld()->m_szWorldName );
					pUser->AddDefinedText( TID_GAME_STATE_NOTUSE, "\"%s\"", strtmp );
				}
#if __VER >= 13 // __RAINBOW_RACE
				else if( CRainbowRaceMng::GetInstance()->IsEntry( pUser->m_idPlayer )
						|| CRainbowRaceMng::GetInstance()->IsEntry( pUsertmp->m_idPlayer ) )
				{
					pUser->AddDefinedText( TID_GAME_RAINBOWRACE_NOTELEPORT );
					return;
				}
#endif // __RAINBOW_RACE
#ifdef __QUIZ
				else if( pUser->GetWorld()->GetID() == WI_WORLD_QUIZ 
						|| pUsertmp->GetWorld()->GetID() == WI_WORLD_QUIZ )
					pUser->AddDefinedText( TID_GAME_QUIZ_DO_NOT_USE );
						
#endif // __QUIZ
				else
				{
#ifdef __RT_1025
					if( pUsertmp->m_RTMessenger.IsBlock( pUser->m_idPlayer ) )
#else	//__RT_1025
					LPFRIEND pFriend	= pUsertmp->m_Messenger.GetFriend( pUser->m_idPlayer );
					if( pFriend && pFriend->dwState == FRS_BLOCK )
#endif	// __RT_1025
					{
						pUser->AddDefinedText( TID_ERROR_SUMMONFRIEND_NOUSER, "\"%s\"", lpszPlayer );
						return;
					}
					pItemElem->m_bQuery		= TRUE;
					pUsertmp->AddSummonFriendConfirm( pUser->GetId(), dwData, pUser->GetName(), pUser->GetWorld()->m_szWorldName );
					pUser->AddDefinedText( TID_GAME_SUMMONFRIEND_CONFIRM, "\"%s\"", lpszPlayer );
				}
			}
			else
			{
				pUser->AddDefinedText( TID_ERROR_SUMMONFRIEND_NOUSER, "\"%s\"", lpszPlayer );
			}
		}	
		else
		{
			ItemProp* pItemProp = prj.GetItemProp( II_SYS_SYS_SCR_FRIENDSUMMON_A );
			if( pItemProp )
				pUser->AddDefinedText( TID_ERROR_SUMMONFRIEND_NOITEM, "\"%s\" \"%s\"", pItemProp->szName, lpszPlayer );
		}
	}
}
void CDPSrvr::OnSummonFriendConfirm( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objid;
	DWORD dwData;

	ar >> objid >> dwData;
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CUser* pUsertmp = prj.GetUser( objid );
		if( IsValidObj( (CObj*)pUsertmp ) )
		{
#ifdef __MOUNT
			if (pUser->m_pActMover->IsUseMount())
			{
				pUser->AddText("You can't teleport while using a mount.", COLOR_ERROR);
				return;
			}
#endif // __MOUNT
			int nState = pUser->GetSummonState();
			if( nState != 0 )
			{
				DWORD dwMsgId = 0;
				if( nState == 1 )	// °Å·¡Áß
					dwMsgId = TID_GAME_TRADE_NOTUSE;
				else if( nState == 2 ) // Á×À½
					dwMsgId = TID_GAME_DIE_NOTUSE;
				else if( nState == 3 ) // °³ÀÎ»óÁ¡ Áß
					dwMsgId = TID_GAME_VENDOR_NOTUSE;
				else if( nState == 4 ) // ÀüÅõÁß
					dwMsgId = TID_GAME_ATTACK_NOTUSE;
				else if( nState == 5 ) // ºñÇàÁß
					dwMsgId = TID_GAME_FLY_NOTUSE;
#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
				else if( nState == 6 ) // µà¾óÁß
					dwMsgId = TID_GAME_ATTACK_NOTUSE;
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma
				
				pUser->AddDefinedText( TID_GAME_STATE_NOTSUMMONOK, "\"%s\"", prj.GetText( dwMsgId ) );
				pUsertmp->AddDefinedText( TID_GAME_STATE_NOTSUMMON, "\"%s\"", prj.GetText( dwMsgId + 1 ) );
				return;
			}

			nState = pUsertmp->GetSummonState();
			if( nState != 0 )
			{
				DWORD dwMsgId = 0;
				if( nState == 1 )	// °Å·¡Áß
					dwMsgId = TID_GAME_TRADE_NOTUSE1;
				else if( nState == 2 ) // Á×À½
					dwMsgId = TID_GAME_DIE_NOTUSE1;
				else if( nState == 3 ) // °³ÀÎ»óÁ¡ Áß
					dwMsgId = TID_GAME_VENDOR_NOTUSE1;
				else if( nState == 4 ) // ÀüÅõÁß
					dwMsgId = TID_GAME_ATTACK_NOTUSE1;
				else if( nState == 5 ) // ºñÇàÁß
					dwMsgId = TID_GAME_FLY_NOTUSE1;
#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
				else if( nState == 6 ) // µà¾óÁß
					dwMsgId = TID_GAME_ATTACK_NOTUSE1;
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma
				
				pUser->AddDefinedText( TID_GAME_STATE_NOTSUMMONOK , "\"%s\"", prj.GetText( dwMsgId ) );
				pUsertmp->AddDefinedText( TID_GAME_STATE_NOTSUMMON , "\"%s\"", prj.GetText( dwMsgId - 1 ) );
				return;
			}

			WORD wId	= LOWORD( dwData );
			WORD wMode	= HIWORD( dwData );
			CItemElem* pItemElem = (CItemElem*)pUsertmp->GetItemId( wId );
			if( IsUsableItem( pItemElem ) )
			{
				if( ( pItemElem->m_dwItemId != II_SYS_SYS_SCR_FRIENDSUMMON_A && pItemElem->m_dwItemId != II_SYS_SYS_SCR_FRIENDSUMMON_B ) || pItemElem->m_bQuery == FALSE )
					return;

				if( prj.IsGuildQuestRegion( pUser->GetPos() ) )
				{
					pUser->AddDefinedText( TID_GAME_STATE_NOTSUMMONOK , "\"%s\"", prj.GetText( TID_GAME_EVENT_WORLD_NOTUSE ) );
					pUsertmp->AddDefinedText( TID_GAME_STATE_NOTSUMMON , "\"%s\"", prj.GetText( TID_GAME_EVENT_WORLD_NOTUSE1 ) );
				}
				else if( prj.IsGuildQuestRegion( pUsertmp->GetPos() ) )
				{
					pUser->AddDefinedText( TID_GAME_STATE_NOTSUMMONOK , "\"%s\"", prj.GetText( TID_GAME_EVENT_WORLD_NOTUSE1 ) );
					pUsertmp->AddDefinedText( TID_GAME_STATE_NOTSUMMON , "\"%s\"", prj.GetText( TID_GAME_EVENT_WORLD_NOTUSE ) );
				}
				else if( pUser->GetWorld()->GetID() != pUsertmp->GetWorld()->GetID()
#if __VER >= 14 // __INSTANCE_DUNGEON
						|| pUser->GetLayer() != pUsertmp->GetLayer()
#endif // __INSTANCE_DUNGEON
					)
				{
					CString strtmp;
					strtmp.Format( prj.GetText( TID_GAME_WORLD_NOTUSE ), pUser->GetWorld()->m_szWorldName, pUsertmp->GetWorld()->m_szWorldName );
					pUser->AddDefinedText( TID_GAME_STATE_NOTSUMMONOK, "\"%s\"", strtmp );
					strtmp.Format( prj.GetText( TID_GAME_WORLD_NOTUSE ), pUsertmp->GetWorld()->m_szWorldName, pUser->GetWorld()->m_szWorldName );
					pUsertmp->AddDefinedText( TID_GAME_STATE_NOTSUMMON, "\"%s\"", strtmp );
				}
#ifdef __QUIZ
				else if( pUser->GetWorld()->GetID() == WI_WORLD_QUIZ 
						|| pUsertmp->GetWorld()->GetID() == WI_WORLD_QUIZ )
					pUser->AddDefinedText( TID_GAME_QUIZ_DO_NOT_USE );
#endif // __QUIZ
				else 
				{
					g_dpDBClient.SendLogSMItemUse( "1", pUsertmp, pItemElem, pItemElem->GetProp(), pUser->GetName() );

					pUser->REPLACE( g_uIdofMulti, pUsertmp->GetWorld()->GetID(), pUsertmp->GetPos(), REPLACE_NORMAL, pUsertmp->GetLayer() );

					pItemElem->m_bQuery		= FALSE;
					pUsertmp->RemoveItem( (BYTE)( wId ), (short)1 );
					pUser->AddDefinedText( TID_GAME_SUMMON_SUCCESS1, "\"%s\"", pUsertmp->GetName() );
					pUsertmp->AddDefinedText( TID_GAME_SUMMON_SUCCESS, "\"%s\"", pUser->GetName() );
				}
			}
			else
			{
				ItemProp* pItemProp = prj.GetItemProp( II_SYS_SYS_SCR_FRIENDSUMMON_A );
				if( pItemProp )
					pUsertmp->AddDefinedText( TID_ERROR_SUMMONFRIEND_NOITEM, "\"%s\" \"%s\"", pItemProp->szName, pUser->GetName() );
			}
		}
	}
}

void CDPSrvr::OnSummonFriendCancel( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objid;
	DWORD dwData;
	ar >> objid >> dwData;
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CUser* pUsertmp = prj.GetUser( objid );
		if( IsValidObj( (CObj*)pUsertmp ) )
		{
			WORD wId	= LOWORD( dwData );
			CItemElem* pItemElem = (CItemElem*)pUsertmp->GetItemId( wId );
			if( IsUsableItem( pItemElem ) && ( pItemElem->m_dwItemId == II_SYS_SYS_SCR_FRIENDSUMMON_A || pItemElem->m_dwItemId == II_SYS_SYS_SCR_FRIENDSUMMON_B ) )
				pItemElem->m_bQuery		= FALSE;
			pUsertmp->AddDefinedText( TID_GAME_SUMMON_FRIEND_CANCEL, "\"%s\"", pUser->GetName() );
		}
	}
}

void CDPSrvr::OnSummonParty( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwData;
	
	ar >> dwData;

	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		int nState = pUser->GetSummonState();
		if( nState != 0 )
		{
			DWORD dwMsgId = 0;
			if( nState == 1 )	// °Å·¡Áß
				dwMsgId = TID_GAME_TRADE_NOTUSE;
			else if( nState == 2 ) // Á×À½
				dwMsgId = TID_GAME_DIE_NOTUSE;
			else if( nState == 3 ) // °³ÀÎ»óÁ¡ Áß
				dwMsgId = TID_GAME_VENDOR_NOTUSE;
			else if( nState == 4 ) // ÀüÅõÁß
				dwMsgId = TID_GAME_ATTACK_NOTUSE;
			else if( nState == 5 ) // ºñÇàÁß
				dwMsgId = TID_GAME_FLY_NOTUSE;
#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
			else if( nState == 6 ) // µà¾óÁß
				dwMsgId = TID_GAME_ATTACK_NOTUSE;
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma
			
			pUser->AddDefinedText( TID_GAME_STATE_NOTUSE, "\"%s\"", prj.GetText( dwMsgId ) );
			return;
		}

		if( prj.IsGuildQuestRegion( pUser->GetPos() ) )
		{
			pUser->AddDefinedText( TID_GAME_STATE_NOTUSE, "\"%s\"", prj.GetText( TID_GAME_EVENT_WORLD_NOTUSE ) );
			return;
		}
#if __VER >= 13 // __RAINBOW_RACE
		if( CRainbowRaceMng::GetInstance()->IsEntry( pUser->m_idPlayer ) )
		{
			pUser->AddDefinedText( TID_GAME_RAINBOWRACE_NOTELEPORT );
			return;
		}
#endif // __RAINBOW_RACE

		
		WORD wId	= LOWORD( dwData );
		WORD wMode	= HIWORD( dwData );
		CItemElem* pItemElem = (CItemElem*)pUser->GetItemId( wId );
#ifdef __GAMEGUARD
		if (pItemElem && IsUsableItem(pItemElem) && pItemElem->GetProp()->dwID == II_SYS_SYS_SCR_PARTYSUMMON)
#else // __GAMEGUARD
		if (IsUsableItem(pItemElem))
#endif // __GAMEGUARD
		{
			CParty* pParty;
			pParty = g_PartyMng.GetParty( pUser->GetPartyId() );
			if( pParty && pParty->IsLeader( pUser->m_idPlayer ) )
			{
				if( !pUser->HasBuff( BUFF_ITEM, (WORD)( pItemElem->GetProp()->dwID ) ) )
				{
					pParty->m_dwWorldId = pUser->GetWorld()->GetID();

					g_dpDBClient.SendLogSMItemUse( "1", pUser, pItemElem, pItemElem->GetProp(), pParty->m_sParty );
					
					ItemProp* pItemProptmp = prj.GetItemProp( II_SYS_SYS_SCR_PARTYSUMMON );
					for( int i = 1 ; i < pParty->m_nSizeofMember ; i++ )
					{
						CUser* pUsertmp		= g_UserMng.GetUserByPlayerID( pParty->GetPlayerId( i ) );
						if( IsValidObj( (CObj*)pUsertmp ) )
						{
//								if( pUser->GetWorld()->GetID() == pUsertmp->GetWorld()->GetID() && !prj.IsGuildQuestRegion( pUsertmp->GetPos() ) )
							{
								pUser->DoApplySkill( (CCtrl*)pUsertmp, pItemElem->GetProp(), NULL );
								pUsertmp->AddSummonPartyConfirm( pUser->GetId(), dwData, pUser->GetWorld()->m_szWorldName );
								if( pItemProptmp )
									g_UserMng.AddCreateSfxObj((CMover *)pUsertmp, pItemProptmp->dwSfxObj3 );
								pUser->AddDefinedText( TID_GAME_SUMMONFRIEND_CONFIRM, "\"%s\"", pUsertmp->GetName() );
							}
//								else
//								{
//									pUser->AddDefinedText( TID_ERROR_SUMMONFRIEND_NOTWORLD );
//								}
						}
						else
						{
#if __VER >= 11 // __SYS_PLAYER_DATA
							pUser->AddDefinedText( TID_ERROR_SUMMONFRIEND_NOUSER, "\"%s\"", CPlayerDataCenter::GetInstance()->GetPlayerString( pParty->GetPlayerId( i ) ) );
#else	// __SYS_PLAYER_DATA
							pUser->AddDefinedText( TID_ERROR_SUMMONFRIEND_NOUSER, "\"%s\"", prj.GetPlayerString( pParty->GetPlayerId( i ) ) );
#endif	// __SYS_PLAYER_DATA
						}
					}
					pUser->DoApplySkill( (CCtrl*)pUser, pItemElem->GetProp(), NULL );
					pUser->RemoveItem( (BYTE)( wId ), (short)1 );

					if( pItemProptmp )
						g_UserMng.AddCreateSfxObj((CMover *)pUser, pItemProptmp->dwSfxObj3 );
				}
				else
				{
					pUser->AddDefinedText( TID_GAME_LIMITED_USE );
				}
			}
		}	
		else
		{
			ItemProp* pItemProp = prj.GetItemProp( II_SYS_SYS_SCR_PARTYSUMMON );
			if( pItemProp )
				pUser->AddDefinedText( TID_ERROR_SUMMONPARTY_NOITEM, "\"%s\"", pItemProp->szName );
		}
	}	
}

void CDPSrvr::OnSummonPartyConfirm( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objid;
	DWORD dwData;
	ar >> objid;
	ar >> dwData;
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CParty* pParty;
		pParty = g_PartyMng.GetParty( pUser->GetPartyId() );
		if( pParty )
		{
			CMover* pLeader = prj.GetUser( objid );
			if( IsValidObj( pLeader ) && pParty->IsLeader( pLeader->m_idPlayer ) && pLeader->HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_PARTYSUMMON ) )
			{
				if( pUser == pLeader )
					return;
				int nState = pUser->GetSummonState();
				if( nState != 0 && nState != 5 )
				{
					DWORD dwMsgId = 0;
					if( nState == 1 )	// °Å·¡Áß
						dwMsgId = TID_GAME_TRADE_NOTUSE;
					else if( nState == 2 ) // Á×À½
						dwMsgId = TID_GAME_DIE_NOTUSE;
					else if( nState == 3 ) // °³ÀÎ»óÁ¡ Áß
						dwMsgId = TID_GAME_VENDOR_NOTUSE;
					else if( nState == 4 ) // ÀüÅõÁß
						dwMsgId = TID_GAME_ATTACK_NOTUSE;
#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
					else if( nState == 6 ) // µà¾óÁß
						dwMsgId = TID_GAME_ATTACK_NOTUSE;
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma
					
					pUser->AddDefinedText( TID_GAME_STATE_NOTSUMMONOK , "\"%s\"", prj.GetText( dwMsgId ) );
					return;
				}
				
				nState = pLeader->GetSummonState();
				if( nState != 0 )
				{
					DWORD dwMsgId = 0;
					if( nState == 1 )	// °Å·¡Áß
						dwMsgId = TID_GAME_TRADE_NOTUSE1;
					else if( nState == 2 ) // Á×À½
						dwMsgId = TID_GAME_DIE_NOTUSE1;
					else if( nState == 3 ) // °³ÀÎ»óÁ¡ Áß
						dwMsgId = TID_GAME_VENDOR_NOTUSE1;
					else if( nState == 4 ) // ÀüÅõÁß
						dwMsgId = TID_GAME_ATTACK_NOTUSE1;
					else if( nState == 5 ) // ºñÇàÁß
						dwMsgId = TID_GAME_FLY_NOTUSE1;
#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
					else if( nState == 6 ) // µà¾óÁß
						dwMsgId = TID_GAME_ATTACK_NOTUSE1;
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma
					
					pUser->AddDefinedText( TID_GAME_STATE_NOTSUMMONOK , "\"%s\"", prj.GetText( dwMsgId ) );
					return;
				}
				
				if( prj.IsGuildQuestRegion( pLeader->GetPos() ) )
				{
					pUser->AddDefinedText( TID_GAME_STATE_NOTSUMMONOK, "\"%s\"", prj.GetText( TID_GAME_EVENT_WORLD_NOTUSE1) );
				}
				else if( prj.IsGuildQuestRegion( pUser->GetPos() ) )
				{
					pUser->AddDefinedText( TID_GAME_STATE_NOTSUMMONOK, "\"%s\"", prj.GetText( TID_GAME_EVENT_WORLD_NOTUSE ) );
				}
				else if( pUser->GetWorld()->GetID() != pParty->m_dwWorldId )
				{
					CWorld* pWorld = g_WorldMng.GetWorld( pParty->m_dwWorldId );
					if( pWorld )
					{
						CString strtmp;
						strtmp.Format( prj.GetText( TID_GAME_WORLD_NOTUSE ), pUser->GetWorld()->m_szWorldName, pWorld->m_szWorldName );
						pUser->AddDefinedText( TID_GAME_STATE_NOTSUMMONOK, "\"%s\"", strtmp );
					}
				}
				else if( pParty->m_dwWorldId != pLeader->GetWorld()->GetID() )
				{
					CWorld* pWorld = g_WorldMng.GetWorld( pParty->m_dwWorldId );
					if( pWorld )
					{
						CString strtmp;
						strtmp.Format( prj.GetText( TID_GAME_WORLDLEADER_NOTUSE ) );
						pUser->AddDefinedText( TID_GAME_STATE_NOTSUMMONOK, "\"%s\"", strtmp );
					}
				}
#if __VER >= 14 // __INSTANCE_DUNGEON
				else if( pLeader->GetLayer() != pUser->GetLayer() )
				{
					CString strtmp;
					strtmp.Format( prj.GetText( TID_GAME_WORLD_NOTUSE ) );
					pUser->AddDefinedText( TID_GAME_STATE_NOTSUMMONOK, "\"%s\"", strtmp );
				}
#endif // __INSTANCE_DUNGEON
#if __VER >= 13 // __RAINBOW_RACE
				else if( CRainbowRaceMng::GetInstance()->IsEntry( pUser->m_idPlayer ) )
				{
					pUser->AddDefinedText( TID_GAME_RAINBOWRACE_NOTELEPORT );
				}
#endif // __RAINBOW_RACE
#ifdef __QUIZ
				else if( pLeader->GetWorld()->GetID() == WI_WORLD_QUIZ 
					|| pUser->GetWorld()->GetID() == WI_WORLD_QUIZ )
					pUser->AddDefinedText( TID_GAME_QUIZ_DO_NOT_USE );
#endif // __QUIZ
				else
				{
					pUser->RemoveBuff( BUFF_ITEM, II_SYS_SYS_SCR_PARTYSUMMON );
					pUser->REPLACE( g_uIdofMulti, pLeader->GetWorld()->GetID(), pLeader->GetPos(), REPLACE_FORCE, pLeader->GetLayer() );
					pUser->AddDefinedText( TID_GAME_SUMMON_SUCCESS1, "\"%s\"", pLeader->GetName() );
					((CUser*)pLeader)->AddDefinedText( TID_GAME_SUMMON_SUCCESS, "\"%s\"", pUser->GetName() );					
					ItemProp* pItemProptmp = prj.GetItemProp( II_SYS_SYS_SCR_PARTYSUMMON );
					if( pItemProptmp )
						g_UserMng.AddCreateSfxObj((CMover *)pUser, pItemProptmp->dwSfxObj3 );
				}
			}
			else
			{
				pUser->AddDefinedText( TID_ERROR_SUMMONPARTY_NOTTIME );
			}
		}
		else
		{
			pUser->AddDefinedText( TID_GAME_NOPARTY );
		}
	}
}

void CDPSrvr::OnRemoveInvenItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD	dwId;
	int		nNum;
	ar >> dwId;
	ar >> nNum;

	if( nNum <= 0 )
		return;

	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) == FALSE )
		return;
	
	CItemElem* pItemElem = pUser->m_Inventory.GetAtId( dwId );
	if( IsUsableItem( pItemElem ) == FALSE )
		return;

	if( pUser->m_Inventory.IsEquip( dwId ) )
		return;
	
	if( pUser->IsUsing( pItemElem ) )
	{
		pUser->AddDefinedText( TID_GAME_CANNOT_DO_USINGITEM );
		return;
	}
	
	if( pItemElem->m_nItemNum < nNum )
		return ;

	if( pItemElem->IsUndestructable() )
		return;

	CString strNum;
	strNum.Format("%d", nNum );
	pUser->AddDefinedText( TID_GAME_SUCCESS_REMOVE_ITEM, "\"%s\" \"%s\"", pItemElem->GetProp()->szName, strNum );

	LogItemInfo aLogItem;
	aLogItem.Action = "*";
	aLogItem.SendName = pUser->GetName();
	aLogItem.RecvName = "GARBAGE";
	aLogItem.WorldId = pUser->GetWorld()->GetID();
	aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
	OnLogItem( aLogItem, pItemElem, nNum );

	pUser->RemoveItem( (BYTE)( dwId ), (short)nNum );
}

#if __VER >= 12 // __ITEMCREATEMON_S0602
void CDPSrvr::OnCreateMonster( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwItemIdRec;
	D3DXVECTOR3 vPos;
	ar >> dwItemIdRec;
	ar >> vPos;

	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) == FALSE )
		return;
	
	DWORD dwId = HIWORD( dwItemIdRec );
	
	if( pUser->IsUsableState( dwId ) == FALSE )
		return;
	
#if __VER >= 12 // __NEW_ITEMCREATEMON_SERVER
	CCreateMonster::GetInstance()->CreateMonster( pUser, dwId, vPos );

#else // __NEW_ITEMCREATEMON_SERVER
	CItemElem* pItemElem = pUser->m_Inventory.GetAtId( dwId );
	if( IsUsableItem( pItemElem ) )
	{
		CWorld* pWorld	= pUser->GetWorld();
		MoverProp* pMoverProp	= NULL;

		DWORD dwMonsterId = g_CreateMonster.GetCreateMonster( pItemElem->GetProp()->dwID );
		if( dwMonsterId )
			pMoverProp	= prj.GetMoverProp( dwMonsterId );
				
		if( pWorld && pMoverProp && pMoverProp->dwID != 0 )
		{
			D3DXVECTOR3 vDist2 = pUser->GetPos() - vPos;
			float fDist = D3DXVec3Length( &vDist2 );			// µÎÁÂÇ¥°£ÀÇ °Å¸®
			if( 15.f < fDist )
				return;

			int nAttr = pWorld->GetHeightAttribute( vPos.x, vPos.z );		// ÀÌµ¿ÇÒ À§Ä¡ÀÇ ¼Ó¼º ÀÐÀ½.
			if( nAttr == HATTR_NOWALK || nAttr == HATTR_NOMOVE )		// ¸ø ¿òÁ÷ÀÌ´Â °÷ÀÌ¸é Pass
				return;
			if( pUser->IsRegionAttr( RA_SAFETY ) )		// ¾ÈÀüÁö¿ªÀÌ¸é Pass
				return;
			if( pWorld->GetID() == WI_WORLD_GUILDWAR )
				return;
#ifdef __DEATH_MATCH
			if (pWorld->GetID() == WI_WORLD_DEATH_MATCH)
				return;
#endif // __DEATH_MATCH
//			g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_CHR_CURSOR2, vPos.x, vPos.y, vPos.z);
			for( DWORD dw = 0; dw < 1; dw++ )
			{
				CObj* pObj	= CreateObj( D3DDEVICE, OT_MOVER, pMoverProp->dwID );
				if( NULL == pObj )	return;	// ASSERT( pObj );
				pObj->SetPos( vPos );
				pObj->InitMotion( MTI_STAND );
				pObj->UpdateLocalMatrix();
			
				((CMover*)pObj)->m_bActiveAttack = 0;
				pWorld->AddObj( pObj, TRUE );
			}
			pUser->AddDefinedText( TID_GAME_CREATEMON_S, "\"%s\"", pMoverProp->szName );
			pUser->RemoveItem( dwId, (short)1 );
		}
	}
	else
	{
		// ¾ÆÀÌÅÛÀÌ ¾ø¾î¼­ »ç¿ëÇÒ¼ö ¾øÀ½.
	}
	#endif // __NEW_ITEMCREATEMON_SERVER
}
#endif // __ITEMCREATEMON_S0602

void CDPSrvr::OnFoucusObj( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objid;
	ar >> objid;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
		pUser->AddFocusObj(objid);
}

void CDPSrvr::OnTrade( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objidTrader;
	ar >> objidTrader;

	CWorld* pWorld;
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) && ( pWorld = pUser->GetWorld() ) && pUser->m_vtInfo.GetOther() == NULL )
	{
		CMover* pTrader		= prj.GetMover( objidTrader );
		if( IsValidObj( pTrader ) && pTrader->GetWorld() && pTrader->m_vtInfo.GetOther() == NULL )
		{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
			if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
			if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
			{
				pUser->AddText("");
				return;
			}
#endif // __WORLDSERVER_MENU
			if( pTrader->IsPlayer() )	// pc
			{

#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
				if( 0 < pUser->m_nDuel ||  0 < pTrader->m_nDuel )
				{
					return;
				}
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma


				//°³ÀÎ»óÁ¡ Áß¿¡´Â °Å·¡ ºÒ°¡ 
				if( pUser->m_vtInfo.VendorIsVendor() || pUser->m_vtInfo.IsVendorOpen() ||
                    pTrader->m_vtInfo.VendorIsVendor() || pTrader->m_vtInfo.IsVendorOpen() )
				{
					return;	//
				}
#ifdef __S_SERVER_UNIFY
				if( pUser->m_bAllAction == FALSE || ((CUser*)pTrader)->m_bAllAction == FALSE )
					return;
#endif // __S_SERVER_UNIFY

				if( pUser->m_bBank || pTrader->m_bBank )
				{
					pUser->AddDefinedText( TID_GAME_TRADELIMITPC, "" );
					return;	//
				}

				if( pUser->m_bGuildBank || pTrader->m_bGuildBank )
				{
					pUser->AddDefinedText( TID_GAME_TRADELIMITPC, "" );
					return;	//
				}

				pUser->m_vtInfo.SetOther( pTrader );
				pTrader->m_vtInfo.SetOther( pUser );

				pUser->AddTrade( (CUser*)pTrader, pUser->m_idPlayer );
				( (CUser*)pTrader )->AddTrade( pUser, pUser->m_idPlayer );
			}
		}
	}
}

void CDPSrvr::OnConfirmTrade( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objidTrader;
	ar >> objidTrader;

	CWorld* pWorld;
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) && ( pWorld = pUser->GetWorld() ) && pUser->m_vtInfo.GetOther() == NULL )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		// ´ëÀüÀå¿¡¼­´Â °Å·¡¸¦ ÇÒ¼ö ¾ø½À´Ï´Ù.
		if( pWorld && pWorld->GetID() == WI_WORLD_GUILDWAR )
		{			
			pUser->AddText( prj.GetText(TID_GAME_GUILDCOMBAT_CANNOT_TRADE) ); //±æµå´ëÀüÀå ¿¡¼­´Â °Å·¡¿¡ °üÇÑ ¸ðµç°ÍµéÀ» ÀÌ¿ë ÇÒ ¼ö ¾ø½À´Ï´Ù.
			return;
		}
#if __VER >= 11 // __GUILD_COMBAT_1TO1
		if( g_GuildCombat1to1Mng.IsPossibleUser( pUser ) )
		{
			pUser->AddText( prj.GetText(TID_GAME_GUILDCOMBAT_CANNOT_TRADE) ); //±æµå´ëÀüÀå ¿¡¼­´Â °Å·¡¿¡ °üÇÑ ¸ðµç°ÍµéÀ» ÀÌ¿ë ÇÒ ¼ö ¾ø½À´Ï´Ù.
			return;
		}
#endif // __GUILD_COMBAT_1TO1

		CMover* pTrader		= prj.GetMover( objidTrader );
		if( IsValidObj( pTrader ) && pTrader->GetWorld() && pTrader->m_vtInfo.GetOther() == NULL )
		{
			if( pTrader->IsPlayer() == FALSE )
				return;

#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
			if( 0 < pUser->m_nDuel ||  0 < pTrader->m_nDuel )
			{
				return;
			}
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma

			if( pTrader->IsAttackMode() )
				pUser->AddDefinedText( TID_GAME_BATTLE_NOTTRADE, "" );
			else
				((CUser*)pTrader)->AddComfirmTrade( pUser->GetId() );
		}

		pUser->RemoveInvisible();		// °Å·¡¸¦ ÇÏ¸é Åõ¸íÀº Ç®¸°´Ù.
	}
}

void CDPSrvr::OnConfirmTradeCancel( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objidTrader;
	ar >> objidTrader;

	CMover* pTrader		= prj.GetMover( objidTrader );
	if( IsValidObj( pTrader ) && pTrader->GetWorld() && pTrader->m_vtInfo.GetOther() == NULL )
	{
#ifdef __WORLDSERVER_MENU
		CUser* pUser = ((CUser*)pTrader);
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			if (IsValidObj(pUser))
			{
				pUser->AddText("");
			}
			return;
}
#endif // __WORLDSERVER_MENU
		((CUser*)pTrader)->AddComfirmTradeCancel(objidTrader);
	}
}

void CDPSrvr::OnTradePut( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE i, nItemType, nId;
	short nItemNum;

	ar >> i >> nItemType >> nId >> nItemNum;
	if( i >= MAX_TRADE || nItemNum < 1 )
		return;

#ifdef __AEGON_FIXES
	if (i < 0)
		return;
#endif

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	CMover* pTrader	= ( pUser ? pUser->m_vtInfo.GetOther() : NULL );
	CWorld* pWorld;

	if( IsValidObj( pUser ) && ( pWorld = pUser->GetWorld() ) && 
		IsValidObj( pTrader ) && pTrader->GetWorld() == pWorld && pTrader->m_vtInfo.GetOther() == pUser )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
#if __VER >= 9 // JYJ
		CItemElem* pItem	= (CItemElem*)pUser->GetItemId( nId );
		if( pItem && pItem->IsFlag( CItemElem::expired ) )
			return;
#endif // __VER >= 9 // JYJ

		if( pUser->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM && pTrader->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM )
		{
			short nItemNumResult	= nItemNum;
			DWORD dwText	= pUser->m_vtInfo.TradeSetItem2( nId, i, nItemNumResult );
			if( dwText == 0 )
			{
				pUser->AddTradePut( pUser->GetId(), i, nItemType, nId, nItemNumResult );
				( (CUser*)pTrader )->AddTradePut( pUser->GetId(), i, nItemType, nId, nItemNumResult );
			}
			else
			{
				pUser->AddDefinedText( dwText );
			}
		}
		else
		{
			pUser->AddTradePutError();
		}
	}
}

void CDPSrvr::OnTradePull( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE i;
	ar >> i;

	if( i >= MAX_TRADE )
		return;

#ifdef __AEGON_FIXES
	if (i < 0)
		return;
#endif

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	CMover* pTrader	= ( pUser ? pUser->m_vtInfo.GetOther() : NULL );
	CWorld* pWorld;

	if( IsValidObj( pUser ) && ( pWorld = pUser->GetWorld() ) && 
		IsValidObj( pTrader ) && pTrader->GetWorld() == pWorld && pTrader->m_vtInfo.GetOther() == pUser )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		if( pUser->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM && pTrader->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM )
		{
			if( pUser->m_vtInfo.TradeClearItem( i ) )
			{
				pUser->AddTradePull( pUser->GetId(), i );
				( (CUser*)pUser->m_vtInfo.GetOther() )->AddTradePull( pUser->GetId(), i );
			}
		}
	}
}

void CDPSrvr::OnTradePutGold( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwGold;
	ar >> dwGold;
	
	int nGold = dwGold;
	if( nGold <= 0 )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	CMover* pTrader	= ( pUser ? pUser->m_vtInfo.GetOther() : NULL );
	CWorld* pWorld;

	if( IsValidObj( pUser ) && ( pWorld = pUser->GetWorld() ) && 
		IsValidObj( pTrader ) && pTrader->GetWorld() == pWorld && pTrader->m_vtInfo.GetOther() == pUser )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		if( pUser->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM && pTrader->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM )
		{
			if( nGold > pUser->GetGold() )
				nGold = pUser->GetGold();
			
			pUser->m_vtInfo.TradeSetGold( nGold );
			pUser->AddGold( -nGold, FALSE );	// raiders.2006.11.28  ÀÎº¥µ· = ÀÎº¥µ· - °Å·¡Ã¢ µ· 

			pUser->AddTradePutGold( pUser->GetId(), nGold );
			( (CUser*)pTrader )->AddTradePutGold( pUser->GetId(), nGold );
		}
	}
}
//raiders.2006.11.28
/*
void CDPSrvr::OnTradeClearGold( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	CMover* pTrader	= ( pUser ? pUser->m_vtInfo.GetOther() : NULL );
	CWorld* pWorld;

	if( IsValidObj( pUser ) && ( pWorld = pUser->GetWorld() ) && 
		IsValidObj( pTrader ) && pTrader->GetWorld() == pWorld && pTrader->m_vtInfo.GetOther() == pUser )
	{
		if( pUser->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM && pTrader->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM )
		{
			pUser->m_vtInfo.TradeSetGold( 0 );

			pUser->AddTradeClearGold( pUser->GetId() );
			( (CUser*)pTrader )->AddTradeClearGold( pUser->GetId() );
		}
	}
}
*/
void CDPSrvr::OnTradeCancel( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	int nMode;
	ar >> nMode;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	CMover* pTrader	= ( pUser ? pUser->m_vtInfo.GetOther() : NULL );
	CWorld* pWorld;

	if( IsValidObj( pUser ) && ( pWorld = pUser->GetWorld() ) &&
		IsValidObj( pTrader ) && pTrader->GetWorld() == pWorld && pTrader->m_vtInfo.GetOther() == pUser )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		pUser->m_vtInfo.TradeClear();
		pTrader->m_vtInfo.TradeClear();

		pUser->AddTradeCancel( pUser->GetId(), pUser->m_idPlayer, nMode );
		( (CUser*)pTrader )->AddTradeCancel( pUser->GetId(), pUser->m_idPlayer, nMode );
	}
}


// pPlayer´Â Áö±Ý ok¸¦ ´©¸¥ »ç¿ëÀÚÀÌ°í pTrdaer´Â ¸ÕÀú ok¸¦ ´©¸¥ »ç¿ëÀÚÀÌ´Ù.	
void CDPSrvr::OnTradelastConfrim( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	CMover* pTrader	= ( pUser ? pUser->m_vtInfo.GetOther() : NULL );	
	CWorld* pWorld;

	if( IsValidObj( pUser ) && ( pWorld = pUser->GetWorld() ) && 
		IsValidObj( pTrader ) && pTrader->GetWorld() == pWorld && pTrader->m_vtInfo.GetOther() == pUser )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		if( pUser->m_vtInfo.TradeGetState() != TRADE_STEP_OK )
			return;

		switch( pTrader->m_vtInfo.TradeGetState() )
		{
		case TRADE_STEP_OK:
			pUser->m_vtInfo.TradeSetState( TRADE_STEP_CONFIRM );	

			pUser->AddTradelastConfirmOk( pUser->GetId() );					// ok¸¦ ´­·¶À½À» Ç¥½ÃÇÏ°Ô ÇÑ´Ù.
			( (CUser*)pTrader )->AddTradelastConfirmOk( pUser->GetId() );	// ok¸¦ ´­·¶À½À» Ç¥½ÃÇÏ°Ô ÇÑ´Ù.
			break;

		case TRADE_STEP_CONFIRM:
			{
				BEFORESENDDUAL( out, PACKETTYPE_LOG_ALLITEM, DPID_UNKNOWN, DPID_UNKNOWN );		// log¿ë ar
				TRADE_CONFIRM_TYPE type = pUser->m_vtInfo.TradeLastConfirm( out );
				switch( type )
				{
				case TRADE_CONFIRM_ERROR:	
					pUser->AddTradeCancel( NULL_ID, pUser->m_idPlayer );	
					( (CUser*)pTrader )->AddTradeCancel( NULL_ID, pUser->m_idPlayer );
					break;
				case TRADE_CONFIRM_OK:
					SEND( out, &g_dpDBClient, DPID_SERVERPLAYER );

					pUser->AddTradeConsent();	
					( (CUser*)pTrader )->AddTradeConsent();
#ifdef __SECURITY_FIXES
					CWorld* pWorld	= ((CUser*)pTrader)->GetWorld();
					g_dpDBClient.SavePlayer( (CUser*)pTrader, pWorld->GetID(), ((CUser*)pTrader)->GetPos(), ((CUser*)pTrader)->GetLayer() );
					pWorld	= pUser->GetWorld();
					g_dpDBClient.SavePlayer( pUser, pWorld->GetID(), pUser->GetPos(), pUser->GetLayer() );
#endif //__SECURITY_FIXES
					break;
				}					
			}
			break;	
		} 
#ifdef __GAMEGUARD
		if (pUser->GetWorld() && (CUser*)pTrader->GetWorld())
		{
			g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
			g_dpDBClient.SavePlayer((CUser*)pTrader, ((CUser*)pTrader)->GetWorld()->GetID(), ((CUser*)pTrader)->GetPos(), ((CUser*)pTrader)->GetLayer());
		}
#endif // __GAMEGUARD
	}
}

// »ç¿ëÀÚ°¡ ok ¹öÆ°À» ´­·¶À» ¶§
void CDPSrvr::OnTradeOk( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	CMover* pTrader	= ( pUser ? pUser->m_vtInfo.GetOther() : NULL );
	CWorld* pWorld;

	if( IsValidObj( pUser ) && ( pWorld = pUser->GetWorld() ) && 
		IsValidObj( pTrader ) && pTrader->GetWorld() == pWorld && pTrader->m_vtInfo.GetOther() == pUser )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		if( pUser->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM )
		{
			pUser->m_vtInfo.TradeSetState( TRADE_STEP_OK ); 

			if( pTrader->m_vtInfo.TradeGetState() == TRADE_STEP_OK )	// »ó´ë°¡ ¸ÕÀú ok¸¦ ´­·¯¼­ ±³È¯ÀÌ ¼º¸³µÇ´Â °æ¿ì
			{
				( (CUser*)pUser )->AddTradelastConfirm();
				( (CUser*)pTrader )->AddTradelastConfirm();
			}
			else	// ³»°¡ ¸ÕÀú ok ¹öÆ°À» ´©¸¥ °æ¿ì
			{
				pUser->AddTradeOk( pUser->GetId() );				// Å¬¶ó¿¡ Àü¼ÛÇØ ok¸¦ ´­·¶À½À» Ç¥½ÃÇÏ°Ô ÇÑ´Ù.
				( (CUser*)pTrader )->AddTradeOk( pUser->GetId() );	// Å¬¶ó¿¡ Àü¼ÛÇØ ok¸¦ ´­·¶À½À» Ç¥½ÃÇÏ°Ô ÇÑ´Ù.
			}
		}
	}
}

void CDPSrvr::OnPVendorOpen( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	if( uBufSize > 55 )	// 4 + 4 + 48 - 1		= 55
		return;

	char szPVendor[MAX_VENDORNAME];	// °³ÀÎ »óÁ¡ ÀÌ¸§( 48 )
	ar.ReadString( szPVendor, MAX_VENDORNAME );	

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );

#ifdef __AFK_REWARD_SYSTEM
	pUser->m_dwLastWalkTick = GetTickCount();
	if (pUser->IsAfk())
	{
		pUser->m_bAfk = FALSE;
		g_UserMng.UpdateAfkState(pUser);
	}
#endif //__AFK_REWARD_SYSTEM

	if( IsValidObj( pUser ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
/*		
#ifdef __Y_BEAUTY_SHOP_CHARGE
		if( ::GetLanguage() == LANG_TWN )
		{
			if( !(pUser->HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_VENDOR ) ) )
			{
				return;
			}
		}
#endif //__Y_BEAUTY_SHOP_CHARGE
*/

#ifdef __RULE_0615
		if( prj.IsInvalidName( szPVendor ) || prj.IsAllowedLetter( szPVendor, TRUE ) == FALSE )
			pUser->AddDiagText( prj.GetText( TID_DIAG_0020 ) ); 
#endif	// __RULE_0615

		if( !( pUser->HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_FONTEDIT ) ) )
			ParsingEffect(szPVendor, strlen(szPVendor) );
		
#ifdef __V21FIXES
		if (_tcslen(szPVendor) < 6 || _tcslen(szPVendor) > 32)
		{
			pUser->AddDefinedText(TID_DIAG_0011);
			return;
		}
#endif

		// ´ëÀüÀå¿¡¼­´Â °³ÀÎ»óÁ¡À» ¿­¼ö ¾ø½À´Ï´Ù.
		CWorld* pWorld = pUser->GetWorld();
		if( pWorld && pWorld->GetID() == WI_WORLD_GUILDWAR )
		{			
			pUser->AddText( prj.GetText(TID_GAME_GUILDCOMBAT_CANNOT_TRADE) ); //±æµå´ëÀüÀå ¿¡¼­´Â °Å·¡¿¡ °üÇÑ ¸ðµç°ÍµéÀ» ÀÌ¿ë ÇÒ ¼ö ¾ø½À´Ï´Ù.
			return;
		}
#if __VER >= 11 // __GUILD_COMBAT_1TO1
		if( g_GuildCombat1to1Mng.IsPossibleUser( pUser ) )
		{
			pUser->AddText( prj.GetText(TID_GAME_GUILDCOMBAT_CANNOT_TRADE) ); //±æµå´ëÀüÀå ¿¡¼­´Â °Å·¡¿¡ °üÇÑ ¸ðµç°ÍµéÀ» ÀÌ¿ë ÇÒ ¼ö ¾ø½À´Ï´Ù.
			return;
		}
#endif // __GUILD_COMBAT_1TO1
#if __VER >= 13 // __HOUSING
		if( pUser->GetWorld() && pUser->GetWorld()->GetID() == WI_WORLD_MINIROOM )
			return;
#endif // __HOUSING
		if( pUser->m_vtInfo.GetOther() )	// °Å·¡Áß ÀÌ¸é °³ÀÎ»óÁ¡ ºÒ°¡ 
			return;
#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
		if( 0 < pUser->m_nDuel )
		{
			return;
		}
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma

		if( pUser->IsAttackMode() )
			return;

		pUser->m_vtInfo.SetTitle( szPVendor );

		if( pUser->m_pActMover->IsFly() )
			return;

#if __VER >= 8 // __S8_PK
		if( pUser->IsChaotic() )
		{
			CHAO_PROPENSITY Propensity = prj.GetPropensityPenalty( pUser->GetPKPropensity() );
			if( !Propensity.nVendor )
			{
				pUser->AddDefinedText( TID_GAME_CHAOTIC_NOT_VENDOR );
				return;
			}
		}
#endif // __VER >= 8 // __S8_PK

#ifdef __S_SERVER_UNIFY
		if( pUser->m_bAllAction == FALSE )
			return;
#endif // __S_SERVER_UNIFY

		if( pUser->m_vtInfo.IsVendorOpen() )
		{
			if( pUser->m_vtInfo.VendorIsVendor() )	
			{
				g_ChattingMng.NewChattingRoom( pUser->m_idPlayer );
				CChatting * pChatting	= g_ChattingMng.GetChttingRoom( pUser->m_idPlayer );

				g_UserMng.AddPVendorOpen( pUser );
				if( pChatting )
				{
					pChatting->m_bState		= TRUE;
					if( pChatting->AddChattingMember( pUser->m_idPlayer ) )
						pUser->m_idChatting		= pUser->m_idPlayer;
					pUser->AddNewChatting( pChatting );
				}
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
				pUser->m_dwHonorCheckTime = GetTickCount();
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
			}
		}
#ifdef __GAMEGUARD		
		if (pUser->GetWorld())
			g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
#endif // __GAMEGUARD	
	}
}

void CDPSrvr::OnPVendorClose( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objidVendor;
	ar >> objidVendor;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		ClosePVendor(pUser, objidVendor);

	
	}	
}

BOOL CDPSrvr::ClosePVendor(CUser* pUser, OBJID objidVendor)
{
	if( pUser->GetId() == objidVendor )
	{
		if( pUser->m_vtInfo.IsVendorOpen() == FALSE && 
			pUser->m_vtInfo.VendorIsVendor() == FALSE )
		{
			return FALSE;
		}
		
		CMover* pTrader	= pUser->m_vtInfo.GetOther();   //raiders.2006.11.27
		pUser->m_vtInfo.VendorClose();

		//raiders.2006.11.27
		pUser->m_vtInfo.TradeClear();
		if (pTrader)
			pTrader->m_vtInfo.TradeClear();
		//--

		g_UserMng.AddPVendorClose(pUser);

		CChatting* pChatting = g_ChattingMng.GetChttingRoom( pUser->m_idChatting );
		if( pChatting )
		{
			for( int i = 0 ; i < pChatting->GetChattingMember() ; ++i )
			{
				CUser* pUserBuf = (CUser*)prj.GetUserByID( pChatting->m_idMember[i] );
				if( IsValidObj( pUserBuf ) )
				{
					// Ã¤ÆÃ¹æÀÌ ¾ø¾îÁü
					pUserBuf->AddDeleteChatting();
					pUserBuf->m_idChatting	= 0;
				}
			}
		}
		g_ChattingMng.DeleteChattingRoom( pUser->m_idPlayer );
		pUser->m_idChatting		= 0;
	}
	else
	{
		if( IsValidObj( pUser->m_vtInfo.GetOther() ) )
		{
			pUser->m_vtInfo.SetOther( NULL );
			pUser->AddPVendorClose( objidVendor );

			CChatting* pChatting	= g_ChattingMng.GetChttingRoom( pUser->m_idChatting );
			if( pChatting )
			{
				for( int i = 0 ; i < pChatting->GetChattingMember() ; ++i )
				{
					CUser* pUserBuf = (CUser*)prj.GetUserByID( pChatting->m_idMember[i] );
					if( IsValidObj( pUserBuf ) )		// Ã¤ÆÃ¿¡¼­ ³ª°¨
					{							
						pUserBuf->AddRemoveChatting( pUser->m_idPlayer );
					}
				}
				pChatting->RemoveChattingMember( pUser->m_idPlayer );
				pUser->m_idChatting		= 0;
			}
		}
	}

	return TRUE;
}

void CDPSrvr::OnBuyPVendorItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objidVendor;
	BYTE nItem;
	DWORD dwItemId;
	short nNum;

	ar >> objidVendor >> nItem >> dwItemId >> nNum;
	if( nItem >= MAX_VENDITEM || nNum <= 0 )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) == FALSE )
		return;

#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
	if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
	if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
	{
		pUser->AddText("");
		return;
	}
#endif // __WORLDSERVER_MENU

	CUser* pPVendor	= prj.GetUser( objidVendor );

	if( IsValidObj( pPVendor ) )
	{
		VENDOR_SELL_RESULT result;
		BOOL bOK = pPVendor->m_vtInfo.VendorSellItem( pUser, nItem, dwItemId, nNum, result );
		if( bOK )
		{
#if __VER < 11 // __MOD_VENDOR
			g_UserMng.AddPVendorItemNum( pPVendor, nItem, result.nRemain );
#endif	// __MOD_VENDOR

			LogItemInfo info;

			info.Action = "Z";
			info.SendName = pUser->GetName();
			info.RecvName = pPVendor->GetName();
			info.WorldId = pUser->GetWorld()->GetID();
			info.Gold = pUser->GetGold() + ( result.item.m_nCost * nNum );
			info.Gold2 = pUser->GetGold();
			info.Gold_1 = pPVendor->GetGold();
			OnLogItem( info, &result.item, nNum );

			info.Action = "X";
			info.SendName = pPVendor->GetName();
			info.RecvName = pUser->GetName();
			info.WorldId = pPVendor->GetWorld()->GetID();
			info.Gold = pPVendor->GetGold() - ( result.item.m_nCost * nNum );
			info.Gold2 = pPVendor->GetGold();
			info.Gold_1 = pUser->GetGold();
			OnLogItem( info, &result.item, nNum );
		}
		else
		{
			if( result.nErrorCode )
				pUser->AddDefinedText( result.nErrorCode, "" );
		}
#ifdef __GAMEGUARD
		if (pUser->GetWorld())
			g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());

		if (pPVendor->GetWorld())
			g_dpDBClient.SavePlayer(pPVendor, pPVendor->GetWorld()->GetID(), pPVendor->GetPos(), pPVendor->GetLayer());

#endif // __GAMEGUARD
	}
}

void CDPSrvr::OnQueryPVendorItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objidVendor;
	ar >> objidVendor;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		if( pUser->m_vtInfo.GetOther() )
			return;
		if( pUser->m_pActMover->IsFly() )
			return;

		CUser* pPVendor	= prj.GetUser( objidVendor );

		if( IsValidObj( pPVendor ) )
		{
			BOOL bChatting = TRUE;
			CChatting* pChatting = g_ChattingMng.GetChttingRoom( pPVendor->m_idChatting );
			if( pChatting )
				bChatting = pChatting->m_bState;

			if( pPVendor->m_vtInfo.IsVendorOpen() )
			{
				pUser->m_vtInfo.SetOther( pPVendor );
				pUser->AddPVendorItem( pPVendor, bChatting );
			}
		}
	}
}

void CDPSrvr::OnUnregisterPVendorItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE i;
	ar >> i;
	if( i >= MAX_VENDITEM )
		return;

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( pUser->m_vtInfo.GetOther() )
			return;
		if( pUser->m_vtInfo.IsVendorOpen() )
			return;

		if( pUser->m_vtInfo.VendorClearItem( i ) )
			pUser->AddUnregisterPVendorItem( i );
	}
}

void CDPSrvr::OnRegisterPVendorItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	BYTE iIndex, nType, nId;
	short nNum;
#ifdef __EXTENDED_SALE_SYSTEM
	int nCost, nPerinCost;
	ar >> iIndex >> nType >> nId >> nNum >> nCost >> nPerinCost;
#else // __EXTENDED_SALE_SYSTEM
	int nCost;
	ar >> iIndex >> nType >> nId >> nNum >> nCost;
#endif // __EXTENDED_SALE_SYSTEM

#if __VER >= 8 //__S8_VENDOR_REVISION
	if( iIndex >= MAX_VENDOR_REVISION )
		return;
#else //__S8_VENDOR_REVISION
	if( iIndex >= MAX_VENDITEM )
		return;
#endif //__S8_VENDOR_REVISION
#ifdef __EXTENDED_SALE_SYSTEM
	if (nPerinCost < 0)
		nPerinCost = 0;

	if (nPerinCost > 9999)
		nPerinCost = 9999;

	if (nCost > 2100000000)
		nCost = 2100000000;

	if (nCost < 1 && nPerinCost < 1)
		nCost = 1;
#else // __EXTENDED_SALE_SYSTEM
	if (nCost < 1)
		nCost = 1;
#endif // __EXTENDED_SALE_SYSTEM

	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		if( pUser->m_vtInfo.GetOther() )
			return;
		if( pUser->m_vtInfo.IsVendorOpen() )
			return;

		if( pUser->IsRegionAttr( RA_FIGHT ) )
		{
			pUser->AddDefinedText( TID_GAME_FAIL_TO_OPEN_SHOP );
			return;
		}

#if __VER >= 13 // __HOUSING
		if( pUser->GetWorld() && pUser->GetWorld()->GetID() == WI_WORLD_MINIROOM )
			return;
#endif // __HOUSING

#if __VER >= 9	// __JEFF_9
		if( CNpcChecker::GetInstance()->IsCloseNpc( pUser->GetWorld(), pUser->GetPos() ) )
		{
			// NPC±ÙÃ³ °³ÀÎ »óÁ¡ ºÒ°¡(3m) - ½Ãµµ ½Ã È®ÀÎÃ¢ÀÌ »ý¼º µÇµµ·Ï Ã³¸®
			pUser->AddDiagText( prj.GetText( TID_GAME_NPC_RADIUS ) );
//			pUser->AddDefinedText( TID_GAME_NPC_RADIUS );
			return;
		}
#endif	// __JEFF_9

#ifdef __QUIZ
		if( pUser->GetWorld() && pUser->GetWorld()->GetID() == WI_WORLD_QUIZ )
		{
			pUser->AddDefinedText( TID_GAME_FAIL_TO_OPEN_SHOP );
			return;
		}
#endif // __QUIZ

		CItemElem* pItemElem = (CItemElem *)pUser->GetItemId( nId );
		if( IsUsableItem( pItemElem ) )		
		{
			if( pItemElem->IsQuest() )
				return;

			if( pItemElem->IsBinds() )
				return;
			if( pUser->IsUsing( pItemElem ) )
			{
				pUser->AddDefinedText( TID_GAME_CANNOT_DO_USINGITEM );
				return;
			}
			
			ItemProp* pProp	= pItemElem->GetProp();
			if( pProp->dwItemKind3 == IK3_CLOAK  && pItemElem->m_idGuild != 0 )
				return;

//			if( pItemElem->m_dwItemId == II_RID_RID_BOR_EVEINSHOVER || pItemElem->m_dwItemId == II_RID_RID_BOR_LADOLF )
//				return;
			if( pProp->dwParts == PARTS_RIDE && pProp->dwItemJob == JOB_VAGRANT )
				return;

			if( pUser->m_Inventory.IsEquip( pItemElem->m_dwObjId ) )
				return;

#if __VER >= 9 // JYJ
			if( pItemElem->IsFlag( CItemElem::expired ) )
				return;
			/*
			if(pProp->dwItemKind3 == IK3_EGG && pItemElem->m_pPet) //»ç¸ÁÇÑ ÆêÀº °Å·¡ ºÒ°¡
			{
				if(pItemElem->m_pPet->GetLife() <= 0)
					return;
			}
			*/
#endif // __VER >= 9 // JYJ	
			if( nNum > pItemElem->m_nItemNum )
				nNum = pItemElem->m_nItemNum;
			if( nNum < 1 )	
				nNum = 1;

			ItemProp* pItemProp	= pItemElem->GetProp();

#if __VER < 8     //8Â÷°ÔÀÓ³»¾ÆÀÌÅÛÆÇ¸Å°¡°ÝÁ¦ÇÑÇ®±â
			if( (DWORD)nCost > (pItemProp->dwCost * 1000) )
				return;
#endif	//  __VER < 8  

#ifdef __EXTENDED_SALE_SYSTEM
			pUser->m_vtInfo.VendorSetItem(nId, iIndex, nNum, nCost, nPerinCost);
			pUser->AddRegisterPVendorItem(iIndex, 0, nId, nNum, nCost, nPerinCost);
#else // __EXTENDED_SALE_SYSTEM
			pUser->m_vtInfo.VendorSetItem(nId, iIndex, nNum, nCost);
			pUser->AddRegisterPVendorItem(iIndex, 0, nId, nNum, nCost);
#endif // __EXTENDED_SALE_SYSTEM
		}
	}
}

#if __VER >= 8 //__CSC_VER8_5
#ifdef __ANGEL_CREATION_FIX
void CDPSrvr::OnCreateAngel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	float greenAngelRate, whiteAngelRate, blueAngelRate, redAngelRate;
	FLOAT fRate[4];
	static DWORD adwItemId[4] = { II_SYS_SYS_QUE_ANGEL_RED, II_SYS_SYS_QUE_ANGEL_BLUE, II_SYS_SYS_QUE_ANGEL_GREEN,  II_SYS_SYS_QUE_ANGEL_WHITE };

	BYTE nSuns, nMoons;

	ar >> nSuns >> nMoons;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (nSuns > 10 || nMoons > 10)
	{
		Error("[Security] OnCreateAngel() Player [%08d] Sunstone[%03d] or Moonstone[%03d] count too high.");
		return;
	}

	int nSunCount = pUser->GetItemNum(II_GEN_MAT_ORICHALCUM01);
	nSunCount += pUser->GetItemNum(II_GEN_MAT_ORICHALCUM01_1);
	if (nSuns > nSunCount)
	{
		pUser->AddText("Not enough Sunstones in inventory.");
		return;
	}

	int nMoonCount = pUser->GetItemNum(II_GEN_MAT_MOONSTONE);
	nMoonCount += pUser->GetItemNum(II_GEN_MAT_MOONSTONE_1);
	if (nMoons > nMoonCount)
	{
		pUser->AddText("Not enough Moonstones in inventory.");
		return;
	}

	// R/B/G/W
	greenAngelRate = (nSuns * 1.0f) + (nMoons * 1.0f);
	whiteAngelRate = greenAngelRate / 10.0f;
	blueAngelRate = greenAngelRate * 2.0f;
	redAngelRate = 100.0f - (whiteAngelRate + greenAngelRate + blueAngelRate);

	fRate[0] = redAngelRate;
	fRate[1] = fRate[0] + blueAngelRate;
	fRate[2] = fRate[1] + greenAngelRate;
	fRate[3] = fRate[2] + whiteAngelRate;

	float rand = xRandom(1000) / 10.0f;
	DWORD dwItemId = 0;
	for (int i = 0; i < 4; i++)
	{
		if (rand <= fRate[i])
		{
			dwItemId = adwItemId[i];
			break;
		}
	}

	if (dwItemId == 0)
		return;

#ifdef __TABBED_INV
	if (pUser->m_Inventory.GetEmptyCount(prj.GetItemProp(dwItemId)->GetInvenIndex()) < 1)
#else // __TABBED_INV
	if (pUser->m_Inventory.GetEmptyCount() < 1)
#endif // __TABBED_INV
	{
		pUser->AddDiagText(prj.GetText(TID_GAME_LACKSPACE));
		return;
	}

	LogItemInfo aLogItem;
	aLogItem.Action = "&";
	aLogItem.SendName = pUser->GetName();
	aLogItem.RecvName = "ANGEL_MATERIAL";
	aLogItem.WorldId = pUser->GetWorld()->GetID();
	aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
	// Suns removal
	_stprintf(aLogItem.szItemName, "%d", II_GEN_MAT_ORICHALCUM01_1);
	int nSunsDeleted = pUser->RemoveItemA(II_GEN_MAT_ORICHALCUM01_1, nSuns);
	aLogItem.itemNumber = nSunsDeleted;
	if (aLogItem.itemNumber > 0)
		OnLogItem(aLogItem);

	_stprintf(aLogItem.szItemName, "%d", II_GEN_MAT_ORICHALCUM01);
	aLogItem.itemNumber = nSuns - nSunsDeleted;
	pUser->RemoveItemA(II_GEN_MAT_ORICHALCUM01, aLogItem.itemNumber);
	if (aLogItem.itemNumber > 0)
		OnLogItem(aLogItem);

	// Moons removal
	_stprintf(aLogItem.szItemName, "%d", II_GEN_MAT_MOONSTONE_1);
	int nMoonsDeleted = pUser->RemoveItemA(II_GEN_MAT_MOONSTONE_1, nMoons);
	aLogItem.itemNumber = nMoonsDeleted;
	if (aLogItem.itemNumber > 0)
		OnLogItem(aLogItem);

	_stprintf(aLogItem.szItemName, "%d", II_GEN_MAT_MOONSTONE);
	aLogItem.itemNumber = nMoons - nMoonsDeleted;
	pUser->RemoveItemA(II_GEN_MAT_MOONSTONE, aLogItem.itemNumber);
	if (aLogItem.itemNumber > 0)
		OnLogItem(aLogItem);

	CItemElem itemElem;
	itemElem.m_dwItemId = dwItemId;
	itemElem.m_nItemNum = 1;
	if (pUser->CreateItem(&itemElem))
	{
		//#ifdef __ANGEL_LOG
		LogItemInfo aLogItem2;
		aLogItem2.Action = "&";
		aLogItem2.SendName = pUser->GetName();
		aLogItem2.RecvName = "ANGEL_CREATE";
		aLogItem2.WorldId = pUser->GetWorld()->GetID();
		aLogItem2.Gold = aLogItem.Gold2 = pUser->GetGold();
		OnLogItem(aLogItem2, &itemElem, 1);
		//#endif // __ANGEL_LOG
	}
}
#else // __ANGEL_CREATION_FIX
void CDPSrvr::OnCreateAngel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nOrichalcum, nMoonstone;
	ItemCountSet itemset[20];
	float greenAngelRate, whiteAngelRate, blueAngelRate, redAngelRate;
	FLOAT fRate[4];
	static DWORD adwItemId[4] = { II_SYS_SYS_QUE_ANGEL_RED, II_SYS_SYS_QUE_ANGEL_BLUE, II_SYS_SYS_QUE_ANGEL_GREEN,  II_SYS_SYS_QUE_ANGEL_WHITE };

	BOOL isSummonWhite = FALSE;
	BOOL isSummonSuccess = FALSE;
	TCHAR sendstr[1024];
	TCHAR tempchr[10];
	CHAR temp[2];
	//	TCHAR createAngel[12];
	int j, k, itemcount;
	CItemElem* pItemElem;

	ar.ReadString(sendstr, 1024);
	CString infostr = sendstr;

	int strlen = infostr.GetLength();
	j = 0;
	k = 0;
	itemcount = 0;
	memset(tempchr, 0, sizeof(TCHAR) * 10);

	for (int i = 0; i < strlen; i++)
	{
		temp[0] = infostr.GetAt(i);
		temp[1] = NULL;
		if (strcmp(temp, "D") == 0)
		{
			CString tempstr;
			tempstr.Format("%s", tempchr);

			temp[0] = infostr.GetAt(i + 1);
			temp[1] = NULL;
			if (strcmp(temp, "D") == 0)
			{
				if (k <= 20)
				{
					itemset[k].extracount = atoi(tempstr);
					memset(tempchr, 0, sizeof(TCHAR) * 10);
					k++;
					i++;
					itemcount++;
					j = 0;
				}
				else
					return; //k°ªÀº MAXÀÎ 20À» ³ÑÀ» ¼ö ¾ø´Ù.
			}
			else
			{
				itemset[k].itemid = atoi(tempstr);
				memset(tempchr, 0, sizeof(TCHAR) * 10);
				j = 0;
			}
		}
		else
		{
			tempchr[j] = temp[0];
			j++;
		}
	}

	nOrichalcum = 0;
	nMoonstone = 0;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	for (int i = 0; i < itemcount; i++)
	{
		pItemElem = (CItemElem*)pUser->GetItemId(itemset[i].itemid);
		if (pItemElem != NULL)
		{
			switch (pItemElem->GetProp()->dwID)
			{
			case II_GEN_MAT_ORICHALCUM01:
			case II_GEN_MAT_ORICHALCUM01_1:
				nOrichalcum += itemset[i].extracount;
				break;
			case II_GEN_MAT_MOONSTONE:
			case II_GEN_MAT_MOONSTONE_1:
				nMoonstone += itemset[i].extracount;
				break;
			};
		}
		else
			return;
	}

	// R/B/G/W
	greenAngelRate = (nOrichalcum * 1.0f) + (nMoonstone * 1.0f);
	whiteAngelRate = greenAngelRate / 10.0f;
	blueAngelRate = greenAngelRate * 2.0f;
	redAngelRate = 100.0f - (whiteAngelRate + greenAngelRate + blueAngelRate);

	fRate[0] = redAngelRate;
	fRate[1] = fRate[0] + blueAngelRate;
	fRate[2] = fRate[1] + greenAngelRate;
	fRate[3] = fRate[2] + whiteAngelRate;

	float rand = xRandom(1000) / 10.0f;
	DWORD dwItemId = 0;
	for (int i = 0; i < 4; i++)
	{
		if (rand <= fRate[i])
		{
			dwItemId = adwItemId[i];
			break;
		}
	}

	if (dwItemId > 0)
	{
		if (IsValidObj(pUser))
		{
			for (int i = 0; i < itemcount; i++)
			{
				pItemElem = (CItemElem*)pUser->GetItemId(itemset[i].itemid);
				if (!IsUsableItem(pItemElem)) //¼ÒºñµÉ ¾ÆÀÌÅÛÀÇ À¯È¿¼º °Ë»ç. ½ÇÆÐ ½Ã RETURN
					return;
			}

			if (pUser->m_Inventory.GetEmptyCount(0) < 1)
			{
				pUser->AddDiagText(prj.GetText(TID_GAME_LACKSPACE));
				return;
			}

			LogItemInfo aLogItem;
			aLogItem.Action = "&";
			aLogItem.SendName = pUser->GetName();
			aLogItem.RecvName = "ANGEL_MATERIAL";
			aLogItem.WorldId = pUser->GetWorld()->GetID();
			aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
			for (int i = 0; i < itemcount; i++)
			{
				pItemElem = (CItemElem*)pUser->GetItemId(itemset[i].itemid);
				if (pItemElem->GetExtra() > 0)
					pItemElem->SetExtra(0);
				//#ifdef __ANGEL_LOG				
				OnLogItem(aLogItem, pItemElem, itemset[i].extracount);
				//#endif // __ANGEL_LOG
				pUser->RemoveItem((BYTE)(pItemElem->m_dwObjId), itemset[i].extracount);
			}

		}
		CItemElem itemElem;
		itemElem.m_dwItemId = dwItemId;
		itemElem.m_nItemNum = 1;
		if (pUser->CreateItem(&itemElem))
		{
			//#ifdef __ANGEL_LOG
			LogItemInfo aLogItem;
			aLogItem.Action = "&";
			aLogItem.SendName = pUser->GetName();
			aLogItem.RecvName = "ANGEL_CREATE";
			aLogItem.WorldId = pUser->GetWorld()->GetID();
			aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
			OnLogItem(aLogItem, &itemElem, 1);
			//#endif // __ANGEL_LOG
		}
	}
}
#endif // __ANGEL_CREATION_FIX

void CDPSrvr::OnAngleBuff( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	// ¿¤Á©À» ¾ø¾Ö°í ¾ÆÀÌÅÛÈ­ ÀÎº¥ ÀÚ¸®°¡ ¾ø´Ù¸é ¸Þ¼¼Áö Ã³¸®
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );

	if( IsValidObj( pUser ) )
	{
		if( pUser->HasBuffByIk3( IK3_ANGEL_BUFF ) == FALSE )
			return;

#ifdef __BUFF_1107
		IBuff* pBuff	= pUser->m_buffs.GetBuffByIk3( IK3_ANGEL_BUFF );
		if( !pBuff )
			return;
		ItemProp* pItemProp	= pBuff->GetProp();
#else	// __BUFF_1107
		LPSKILLINFLUENCE lpSkillIn = pUser->m_SkillState.GetItemBuf( IK3_ANGEL_BUFF );
		if( lpSkillIn == NULL )
			return;
		ItemProp* pItemProp = prj.GetItemProp( lpSkillIn->wID );
#endif	// __BUFF_1107
		if( pItemProp == NULL )
			return;

		int nAngel = (int)( (float)pItemProp->nAdjParamVal1 );
		if( nAngel <= 0 || 100 < nAngel  )
			nAngel = 100;

		EXPINTEGER nMaxAngelExp = prj.m_aExpCharacter[pUser->m_nAngelLevel].nExp1 / 100 * nAngel;
		if( pUser->m_nAngelExp < nMaxAngelExp )
			return;

		CItemElem itemElem;
		switch( pItemProp->dwID )
		{
		case II_SYS_SYS_QUE_ANGEL_RED:
			itemElem.m_dwItemId	= II_SYS_SYS_QUE_ANGEL_RED100;						
			break;
		case II_SYS_SYS_QUE_ANGEL_BLUE:
			itemElem.m_dwItemId	= II_SYS_SYS_QUE_ANGEL_BLUE100;
			break;
		case II_SYS_SYS_QUE_ANGEL_GREEN:
			itemElem.m_dwItemId	= II_SYS_SYS_QUE_ANGEL_GREEN100;
			break;
		default:
			itemElem.m_dwItemId	= II_SYS_SYS_QUE_ANGEL_WHITE100;
			break;
		}

		itemElem.m_nItemNum		= 1;
		if( pUser->CreateItem( &itemElem ) )
		{
			pUser->RemoveIk3Buffs( IK3_ANGEL_BUFF );

			LogItemInfo aLogItem;
			aLogItem.Action = "&";
			aLogItem.SendName = pUser->GetName();
			aLogItem.RecvName = "ANGEL_CREATE_COMPLETED";
			aLogItem.WorldId = pUser->GetWorld()->GetID();
			aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
			OnLogItem( aLogItem, &itemElem, 1 );

#ifndef __DROP_LOG
			char szMessage[512] = { 0, };
			sprintf(szMessage, prj.GetText(TID_EVE_REAPITEM), itemElem.GetProp()->szName);
			pUser->AddText(szMessage);
#endif // __DROP_LOG			
		}
		else
			pUser->AddDefinedText( TID_GAME_NOT_INVEN_ANGEL, "" );
	}
}
#endif //__CSC_VER8_5

#ifdef __EVE_MINIGAME
void CDPSrvr::OnKawibawiboStart( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	pUser->m_nKawibawiboState = prj.m_MiniGame.Result_Kawibawibo( pUser );
	if( pUser->m_nKawibawiboState == CMiniGame::KAWIBAWIBO_WIN )
	{
		CMiniGame::__KAWIBAWIBO Kawibawibo = prj.m_MiniGame.FindKawibawibo( pUser->m_nKawibawiboWin );
		CMiniGame::__KAWIBAWIBO KawibawiboNext = prj.m_MiniGame.FindKawibawibo( pUser->m_nKawibawiboWin + 1 );
		pUser->AddKawibawiboResult( pUser->m_nKawibawiboState, pUser->m_nKawibawiboWin, Kawibawibo.dwItemId, Kawibawibo.nItemCount, KawibawiboNext.dwItemId, KawibawiboNext.nItemCount );
	}
	else
		pUser->AddKawibawiboResult( pUser->m_nKawibawiboState, pUser->m_nKawibawiboWin );
}
void CDPSrvr::OnKawibawiboGetItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;
	
	prj.m_MiniGame.ResultItem_Kawibawibo( pUser );
}

void CDPSrvr::OnReassembleStart( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;
	
	OBJID objItemId[9];
	
	for( int i=0; i<9; ++i )
		ar >> objItemId[i];
		
	BOOL nResult = prj.m_MiniGame.Result_Reassemble( pUser, objItemId, 9 );
	if( nResult == TRUE )
		prj.m_MiniGame.ResultItem_Reassemble( pUser );
		
}

void CDPSrvr::OnReassembleOpenWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	prj.m_MiniGame.OpenWnd_Reassemble( pUser );
}

void CDPSrvr::OnAlphabetOpenWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	prj.m_MiniGame.OpenWnd_Alphabet( pUser );
}

void CDPSrvr::OnAlphabetStart( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;
	
	int nQuestionID = 0;
	OBJID objItemId[5];

	ar >> nQuestionID;
	for( int i=0; i<5; ++i )
		ar >> objItemId[i];

	int nResult = prj.m_MiniGame.Result_Alphabet( pUser, objItemId, 5, nQuestionID );
	if( nResult != CMiniGame::ALPHABET_FAILED && nResult != CMiniGame::ALPHABET_NOTENOUGH_MONEY )
		prj.m_MiniGame.ResultItem_Alphabet( pUser, nResult );
	else
		pUser->AddAlphabetResult( nResult );
//	else
}

void CDPSrvr::OnFiveSystemOpenWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;
	
	prj.m_MiniGame.OpenWnd_FiveSystem( pUser );
}

void CDPSrvr::OnFiveSystemBet( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	int nBetNum;
	int nBetPenya;
	
	ar >> nBetNum;
	ar >> nBetPenya;

	int nResult = prj.m_MiniGame.Bet_FiveSystem( pUser, nBetNum, nBetPenya );
	if( nResult == CMiniGame::FIVESYSTEM_NOTENOUGH )
	{
		pUser->AddFiveSystemResult( nResult );
	}
	else if( nResult == CMiniGame::FIVESYSTEM_OVERMAX )
	{
		pUser->AddFiveSystemResult( nResult );
	}
	else if( nResult == CMiniGame::FIVESYSTEM_FAILED )
	{
		pUser->AddFiveSystemResult( nResult );
	}
}

void CDPSrvr::OnFiveSystemStart( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	int nResult = prj.m_MiniGame.Result_FiveSystem( pUser );

	if( !( prj.m_MiniGame.ResultPenya_FiveSystem( pUser, nResult ) ) )
		pUser->AddFiveSystemResult( CMiniGame::FIVESYSTEM_FAILED );
}	

void CDPSrvr::OnFiveSystemDestroyWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;
	
	prj.m_MiniGame.DestroyWnd_FiveSystem( pUser );
}
#endif // __EVE_MINIGAME

#if __VER >= 9 // __ULTIMATE
void CDPSrvr::OnUltimateMakeItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	OBJID objItemId[MAX_JEWEL];
//	for( int i=0; i<MAX_JEWEL; i++ )
//		ar >> objItemId[i];
	ar.Read( objItemId, sizeof(OBJID) * MAX_JEWEL );

	int nResult = prj.m_UltimateWeapon.MakeItem( pUser, objItemId );
	pUser->AddUltimateMakeItem( nResult );
}

void CDPSrvr::OnUltimateMakeGem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;
	
	OBJID objItemId;
	ar >> objItemId;

	int nNum;
	int nResult = prj.m_UltimateWeapon.MakeGem( pUser, objItemId, nNum );
	pUser->AddUltimateMakeGem( nResult, nNum );
}

void CDPSrvr::OnUltimateTransWeapon( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	OBJID objItemWeapon;
	OBJID objItemGem1;
	OBJID objItemGem2;

	ar >> objItemWeapon;
	ar >> objItemGem1;
	ar >> objItemGem2;

	int nResult = prj.m_UltimateWeapon.TransWeapon( pUser, objItemWeapon, objItemGem1, objItemGem2 );
	pUser->AddUltimateWeapon( ULTIMATE_TRANSWEAPON, nResult );
}

void CDPSrvr::OnUltimateSetGem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	OBJID objItemWeapon;
	OBJID objItemGem;

	ar >> objItemWeapon;
	ar >> objItemGem;

	int nResult = prj.m_UltimateWeapon.SetGem( pUser, objItemWeapon, objItemGem );
	pUser->AddUltimateWeapon( ULTIMATE_SETGEM, nResult );
}

void CDPSrvr::OnUltimateRemoveGem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;
	
	OBJID objItemWeapon;
	OBJID objItemGem;
	
	ar >> objItemWeapon;
	ar >> objItemGem;
	
	int nResult = prj.m_UltimateWeapon.RemoveGem( pUser, objItemWeapon, objItemGem );

	if(nResult == CUltimateWeapon::ULTIMATE_SUCCESS)
	{
		//¼º°ø ¸Þ¼¼Áö Ãâ·Â
		pUser->AddDefinedText( TID_GAME_REMOVEGEM_SUCCESS, "" );
		pUser->AddPlaySound( SND_INF_UPGRADESUCCESS );		
		if((pUser->IsMode( TRANSPARENT_MODE ) ) == 0)
			g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);		
	}
	else if(nResult == CUltimateWeapon::ULTIMATE_FAILED)
	{
		// ½ÇÆÐ ¸Þ¼¼Áö Ãâ·Â
		pUser->AddDefinedText( TID_GAME_REMOVEGEM_FAILED, "" );
		pUser->AddPlaySound( SND_INF_UPGRADEFAIL );
		if((pUser->IsMode( TRANSPARENT_MODE ) ) == 0)
			g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_INT_FAIL, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);				
	}
	pUser->AddUltimateWeapon( ULTIMATE_REMOVEGEM, nResult );
}

void CDPSrvr::OnUltimateEnchantWeapon( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	OBJID objItemWeapon;
	OBJID objItemGem;
	
	ar >> objItemWeapon;
	ar >> objItemGem;

	int nResult = prj.m_UltimateWeapon.EnchantWeapon( pUser, objItemWeapon, objItemGem );

	if(nResult == CUltimateWeapon::ULTIMATE_SUCCESS)
	{
		//¼º°ø ¸Þ¼¼Áö Ãâ·Â
		pUser->AddDefinedText( TID_UPGRADE_SUCCEEFUL, "" );
		pUser->AddPlaySound( SND_INF_UPGRADESUCCESS );		
		if((pUser->IsMode( TRANSPARENT_MODE ) ) == 0)
			g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);		
	}
	else if(nResult == CUltimateWeapon::ULTIMATE_FAILED)
	{
		// ½ÇÆÐ ¸Þ¼¼Áö Ãâ·Â
		pUser->AddDefinedText( TID_UPGRADE_FAIL, "" );
		pUser->AddPlaySound( SND_INF_UPGRADEFAIL );
		if((pUser->IsMode( TRANSPARENT_MODE ) ) == 0)
			g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_INT_FAIL, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);				
	}
	pUser->AddUltimateWeapon( ULTIMATE_ENCHANTWEAPON, nResult );
}
#endif // __ULTIMATE

#ifdef __TRADESYS
void CDPSrvr::OnExchange( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) == FALSE )
		return;

#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
	if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
	if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
	{
		pUser->AddText("");
		return;
	}
#endif // __WORLDSERVER_MENU

	int nMMIid;
	int nListNum;

	ar >> nMMIid;
	ar >> nListNum;

#ifdef __GAMEGUARD
	if (nMMIid < 0 || nMMIid > MAX_MOVER_MENU || nListNum < 0 || !CNpcChecker::GetInstance()->IsCloseNpc(nMMIid, pUser->GetWorld(), pUser->GetPos()))
		return;
#endif // __GAMEGUARD

	int	nResult = prj.m_Exchange.ResultExchange( pUser, nMMIid, nListNum );

	pUser->AddExchangeResult( EXCHANGE_RESULT, nResult );
}
#endif // __TRADESYS

void CDPSrvr::InviteParty( u_long uLeaderid, u_long uMemberid, BOOL bTroup )
{
	CUser* pUser = g_UserMng.GetUserByPlayerID( uMemberid );
	CUser* pLeaderUser = g_UserMng.GetUserByPlayerID( uLeaderid );
	
	if( IsValidObj( pLeaderUser ) && IsValidObj( pUser ) )
	{
		// ´ëÀüÀå¿¡¼­´Â ÆÄÆ¼¸¦ ÇÒ¼ö ¾ø½À´Ï´Ù.
		CWorld* pWorld = pUser->GetWorld();
		if( ( pWorld && pWorld->GetID() == WI_WORLD_GUILDWAR ) || pLeaderUser->GetWorld() && pLeaderUser->GetWorld()->GetID() == WI_WORLD_GUILDWAR )
		{			
			pLeaderUser->AddText( prj.GetText(TID_GAME_GUILDCOMBAT_CANNOT_PARTY) );// "¼öÁ¤ÇØ¾ßÇÔ : ±æµå´ëÀüÀå¿¡´Â ÆÄÆ¼¸¦ ÇÒ¼ö ¾ø½À´Ï´Ù" );
			return;
		}
#if __VER >= 11 // __GUILD_COMBAT_1TO1
		if( g_GuildCombat1to1Mng.IsPossibleUser( pUser ) )
		{
			pLeaderUser->AddText( prj.GetText(TID_GAME_GUILDCOMBAT_CANNOT_PARTY) );// "¼öÁ¤ÇØ¾ßÇÔ : ±æµå´ëÀüÀå¿¡´Â ÆÄÆ¼¸¦ ÇÒ¼ö ¾ø½À´Ï´Ù" );
			return;
		}
#endif // __GUILD_COMBAT_1TO1

#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
		if( 0 < pUser->m_nDuel ||  0 < pLeaderUser->m_nDuel )
		{
			return;
		}
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma
		
		if( pLeaderUser->m_nDuel == 2 )
		{			
			pLeaderUser->AddDefinedText( TID_GAME_PPVP_ADDPARTY, "" );		// ±Ø´Ü µà¾óÁß¿£ ÃÊÃ» ¸øÇÔ´Ù.
		} 
		else
		{
			if( 0 < (CMover*)pUser->GetPartyId() )	// ÀÌ¹Ì ÆÄÆ¼°¡ ÀÖÀ»¶§
			{
				pLeaderUser->AddPartyRequestCancel( uLeaderid, uMemberid, 1 );
			}
			else
			{
				if( pUser->IsAttackMode() )
					pLeaderUser->AddDefinedText( TID_GAME_BATTLE_NOTPARTY, "" );
				else
					pUser->AddPartyRequest( pLeaderUser, pUser, bTroup );
			}
		}
	}
	else
	{
		if( IsValidObj( pLeaderUser ) )
			pLeaderUser->AddPartyRequestCancel( uLeaderid, uMemberid, 4 );
	}
}

void CDPSrvr::InviteCompany( CUser* pUser, OBJID objid )
{
#if __VER >= 12 // __SECRET_ROOM
	if( !IsInviteAbleGuild( pUser ) )
	{
		return;
	}
#endif // __SECRET_ROOM
	
	if( IsValidObj( pUser ) )
	{
		CUser* pUsertmp	= prj.GetUser( objid );
		if( IsValidObj( pUsertmp ) )
		{
			CGuild* pGuild	= g_GuildMng.GetGuild( pUser->m_idGuild );
			if( pGuild )
			{
				CGuildMember* pMember	= pGuild->GetMember( pUser->m_idPlayer );
				if( !pMember )
				{
					// is not member
					return;
				}
				if( !pGuild->IsCmdCap( pMember->m_nMemberLv, PF_INVITATION ) )
				{
					// have no power
					pUser->AddDefinedText( TID_GAME_GUILDINVAITNOTWARR );
					return;
				}
				CGuild* pGuildtmp	= g_GuildMng.GetGuild( pUsertmp->m_idGuild );
				if( pGuildtmp && pGuildtmp->IsMember( pUsertmp->m_idPlayer ) )
				{
					// is already guild member
					pUser->AddDefinedText( TID_GAME_COMACCEPTHAVECOM, "%s", pUsertmp->GetName( TRUE ) );
				}
				else
				{
#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
					if( 0 < pUsertmp->m_nDuel )
					{
						return;
					}
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma

					if( !pGuild->GetWar() )
					{
						if( pUsertmp->IsAttackMode() )
						{
							pUser->AddDefinedText( TID_GAME_BATTLE_NOTGUILD, "" );
						} 
						else
						{
							
							pUsertmp->m_idGuild	= 0;
							pUsertmp->AddGuildInvite( pGuild->m_idGuild, pUser->m_idPlayer );
							pUser->AddDefinedText( TID_GAME_COMACCEPTKINGPIN, "%s", pUsertmp->GetName( TRUE ) );
						}
					}
					else
					{
						pUser->AddDefinedText( TID_GAME_GUILDWARNOMEMBER );
					}
				}
			}
		}
	}	
}

#if __VER >= 12 // __SECRET_ROOM
BOOL CDPSrvr::IsInviteAbleGuild( CUser* pUser )
{
	CGuild* pGuild = pUser->GetGuild();
	if( !pGuild )
		return FALSE;

	// ±æµå´ëÀü
	if( g_GuildCombatMng.m_nState != CGuildCombat::CLOSE_STATE )
	{
		if( g_GuildCombatMng.FindGuildCombatMember( pUser->m_idGuild ) &&
			g_GuildCombatMng.FindGuildCombatMember( pUser->m_idGuild )->bRequest )
		{
			pUser->AddDefinedText( TID_GAME_GUILDCOMBAT_NOT_INVITATION_GUILD );
			return FALSE;
		}
	}

	// 1:1 ±æµå´ëÀü
	if( g_GuildCombat1to1Mng.m_nState != CGuildCombat1to1Mng::GC1TO1_CLOSE )
	{
		if( g_GuildCombat1to1Mng.GetTenderGuildIndexByUser( pUser ) != NULL_ID )
		{
			pUser->AddDefinedText( TID_GAME_GUILDCOMBAT1TO1_NOT_INVITATION_GUILD );
			return FALSE;
		}
	}

	// ºñ¹ÐÀÇ ¹æ
	if( CSecretRoomMng::GetInstance()->m_nState != SRMNG_CLOSE )
	{
		map<BYTE, CSecretRoomContinent*>::iterator it = CSecretRoomMng::GetInstance()->m_mapSecretRoomContinent.begin();
		for( ; it!=CSecretRoomMng::GetInstance()->m_mapSecretRoomContinent.end(); it++ )
		{
			CSecretRoomContinent* pSRCont = it->second;
			if( pSRCont && ( pSRCont->GetTenderGuild( pGuild->GetGuildId() ) != NULL_ID ) )
			{
				pUser->AddDefinedText( TID_GAME_SECRETROOM_NOT_INVITATION_GUILD );
				return FALSE;
			}
		}
	}

	return TRUE;
}
#endif // __SECRET_ROOM

#if __VER < 12 // __EXT_PIERCING
BOOL CDPSrvr::IsPiercingSize( CUser* pUser, CItemElem* pItemElem0, CItemElem* pItemElem1, CItemElem* pItemElem2, int& nError )
{
	if( IsUsableItem( pItemElem0 ) == FALSE || IsUsableItem( pItemElem1 ) == FALSE )
		return FALSE;
	
	if( pUser->m_Inventory.IsEquip( pItemElem0->m_dwObjId ) )
	{
		nError = TID_GAME_EQUIPPUT;
		return FALSE;
	}	
	
	//////////////// Ã¹¹øÂ° ¾ÆÀÌÅÛ //////////////// 
	if( pItemElem0->GetProp()->dwItemKind3 != IK3_SUIT )
	{
		nError = TID_PIERCING_POSSIBLE_ITEM;
		return FALSE;
	}
		
	// ÇÇ¾î½Ì »çÀÌÁî °Ë»ç Áö±ÝÀº 4°³°¡ ÃÖ°í	
	if( pItemElem0->GetPiercingSize() >= MAX_PIERCING_SUIT )
	{
		nError = TID_PIERCING_POSSIBLE;
		return FALSE;
	}
	//////////////// µÎ¹øÂ° ¾ÆÀÌÅÛ //////////////// 
	// ´ÙÀÌ½ºÀÎÁö °Ë»ç
	if( pItemElem1->GetProp()->dwItemKind3 != IK3_PIERDICE
#if __VER >= 19
		|| pItemElem1->GetProp()->dwItemKind3 != IK3_SMELT_ACCESSORY_MATERIAL
#endif
		)
	{
		nError = TID_UPGRADE_ERROR_WRONGUPLEVEL;			
		return FALSE;					
	}
	
#if __VER >= 8 //__Y_NEW_ENCHANT
	if( pItemElem1->GetProp()->dwID != II_GEN_MAT_MOONSTONE 
		&& pItemElem1->GetProp()->dwID != II_GEN_MAT_MOONSTONE_1 )
#else //__Y_NEW_ENCHANT
	if( pItemElem1->GetProp()->dwID != II_GEN_MAT_DIE_EIGHT && pItemElem1->GetProp()->dwID != II_GEN_MAT_DIE_TEN )
#endif //__Y_NEW_ENCHANT
	{
		nError = TID_SBEVE_NOTUSEITEM;			// ÇÇ¾î½Ì¿¡ ÇÊ¿äÇÑ ÁÖ»çÀ§°¡ ¾Æ´Ï¸é ºÒ°¡´É
		return FALSE;
	}
	//////////////// ¼¼¹øÂ° ¾ÆÀÌÅÛ //////////////// 
	if( IsUsableItem( pItemElem2 ) && pItemElem2->m_dwItemId != II_SYS_SYS_SCR_PIEPROT )
	{
		nError = TID_SBEVE_NOTUSEITEM;			// »ó¿ë¾ÆÀÌÅÛÀÌ ¾Æ´Ï¸é ºÒ°¡´É
		return FALSE;
	}
	
	return TRUE;
}
#endif // __EXT_PIERCING

CCommonCtrl* CreateExpBox( CUser* pUser )
{
#if __VER >= 9 // __S_9_ADD
	return NULL;
#endif // __S_9_ADD
	CWorld* pWorld = pUser->GetWorld();

	if( pWorld == NULL  )
		return NULL;

	///////////////////////////////////////////////////////////////////////
	// °æÇèÄ¡°¡ ±ðÀÌÁö ¾ÊÀ¸¸é µå¶øÀ» ¾ÈÇÔ!!!
	CMover* pMover = (CMover*)pUser;
	
	float fRate = 0.1f, fDecExp = 0.0f;
	BOOL  bPxpClear = FALSE, bLvDown = FALSE;
	int   nLevel	= pMover->GetLevel();	
	pMover->GetDieDecExp( nLevel, fRate, fDecExp, bPxpClear, bLvDown );
	if( fDecExp )
	{
#if __VER >= 8 // __S8_PK
		pMover->GetDieDecExpRate( fDecExp, 0, FALSE );
#else // __VER >= 8 // __S8_PK
		pMover->GetDieDecExpRate( fDecExp, 0, pMover->m_nSlaughter );
#endif // __VER >= 8 // __S8_PK
	}

	// Ãàº¹ÀÇ µÎ·ç¸¶¸® »ç¿ë½Ã¿¡´Â °æÇèÄ¡ »óÀÚ ¸¸µéÁö ¾Ê´Â´Ù...

	if( pMover->IsSMMode( SM_REVIVAL ) )
		fDecExp = 0.0f;

	if( pMover->GetExp1() == 0 )
		fDecExp = 0.0f;	

	if( pMover->m_bLastPK || pMover->m_bGuildCombat || pMover->m_bLastDuelParty )		// ¹«Á¶°Ç °æÇèÄ¡ ¾È±ï´Â´Ù...
		fDecExp = 0.0f;			
		
	if( fDecExp == 0.0f )
		return NULL;
	
	CCommonCtrl* pCtrl	= (CCommonCtrl*)CreateObj( D3DDEVICE, OT_CTRL, 46 );
	
	if( !pCtrl )
		return NULL;
	///////////////////////////////////////////////////////////////////////

	pCtrl->m_CtrlElem.m_dwSet    = UA_PLAYER_ID;
	pCtrl->m_idExpPlayer = pUser->m_idPlayer;
	
	EXPINTEGER	nDecExp = (EXPINTEGER)(prj.m_aExpCharacter[pUser->m_nLevel+1].nExp1 * fDecExp );	// ÇöÀç·¹º§ÀÇ ÃÖ´ë°æÇèÄ¡ * ÆÛ¼¾Æ®

	if( nDecExp > pMover->GetExp1() )
		nDecExp = pMover->GetExp1();
	
	pCtrl->m_nExpBox     = (EXPINTEGER)(nDecExp * 0.3f);
	pCtrl->m_dwDelete    = timeGetTime() + MIN( 30 );
	
	pCtrl->SetPos( pUser->GetPos() );
	
	pUser->AddDefinedText(TID_GAME_EXPBOX_INFO_MSG, "" );
	pUser->AddChatText(   TID_GAME_EXPBOX_INFO_MSG, "");
	return pCtrl;
}

#if __VER >= 9	// __PET_0410
void CDPSrvr::OnPetRelease( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( !pUser->HasActivatedSystemPet() )
		{
			pUser->AddDefinedText( TID_GAME_PET_NOT_FOUND );
		}
		else
		{
			CItemElem* pItemElem	= pUser->GetPetItem();
			if( pItemElem && pItemElem->m_pPet )
				pUser->PetRelease();
		}
	}
}

void CDPSrvr::OnUsePetFeed( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
#ifdef __PET_EXP
	return;
#endif
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CPet* pPet	= pUser->GetPet();
		if( pPet == NULL )
		{
			pUser->AddDefinedText( TID_GAME_PET_NOT_FOUND );
			return;
		}
		DWORD dwFeedId;		// ¸ÔÀÌ ½Äº°ÀÚ
		short nNum;
		ar >> dwFeedId;
#if __VER < 12 // __PET_0519
		ar >> nNum;		// ¸ÔÀÌ °³¼ö¸¦ ¼­¹ö¿¡¼­ ±¸ÇÏµµ·Ï ¼öÁ¤
#endif	// __PET_0519
		CItemElem* pFeed	= static_cast<CItemElem*>( pUser->GetItemId( dwFeedId ) );
		if( IsUsableItem( pFeed ) == FALSE )
			return;
		if( !pFeed->IsFeed() )
			return;

#if __VER >= 12 // __PET_0519
		nNum	= pFeed->m_nItemNum;
#else	// __PET_0519
		if( nNum <= 0 )
			nNum	= 1;
		if( nNum > pFeed->m_nItemNum )
			nNum	= pFeed->m_nItemNum;
		if( nNum > 1000 )	// 0723
			nNum	= 1000;
#endif	// __PET_0519

		int nMaxNum	= 0;
		if( pPet->GetLevel() == PL_EGG )
		{
			nMaxNum	= MAX_PET_EGG_EXP - pPet->GetExp();
		}
		else
		{
			nMaxNum	= pPet->GetMaxEnergy() - pPet->GetEnergy();
			nMaxNum	/= 2;	// ¸ÔÀÌ 1´ç ±â·Â 2È¸º¹	// 0723
		}

		if( nNum > nMaxNum )
			nNum	= nMaxNum;
		if( nNum == 0 )
			return;

		if( pPet->GetLevel() == PL_EGG )
		{
			pPet->SetExp( pPet->GetExp() + nNum );
			pUser->AddPetSetExp( pPet->GetExp() );
		}
		else
		{
			pPet->SetEnergy( pPet->GetEnergy() + nNum * 2 );	// ¸ÔÀÌ 1´ç ±â·Â 2È¸º¹	// 0723
			g_UserMng.AddPetFeed( pUser, pPet->GetEnergy() );
		}
		pUser->UpdateItem( (BYTE)( pFeed->m_dwObjId ), UI_NUM, pFeed->m_nItemNum - nNum );
#if __VER >= 12 // __PET_0519
		pUser->AddDefinedText( TID_GAME_PETFEED_S01, "%d", nNum );
#endif	// __PET_0519

		// log
		CItemElem* pPetItem	= pUser->GetPetItem();
		g_dpDBClient.CalluspPetLog( pUser->m_idPlayer, pPetItem->GetSerialNumber(), nNum, PETLOGTYPE_FEED, pPet );
	}
}

void CDPSrvr::OnMakePetFeed( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		DWORD dwMaterialId, dwToolId;
		short nNum;

		ar >> dwMaterialId >> dwToolId >> nNum;

		BOOL bTool	= FALSE;
		CItemElem* pTool	= NULL;
		if( dwToolId != NULL_ID )
		{
			pTool	= (CItemElem*)pUser->GetItemId( dwToolId );
			if( IsUsableItem( pTool ) )
			{
				if( pTool->m_dwItemId == II_SYS_SYS_FEED_MAKER )
					bTool	= TRUE;
			}
			if( !bTool )	// error
				return;
		}

		// Æê Å×ÀÌ¸Ó¿¡ ÀÇÇÑ ¸ÔÀÌ Á¦Á¶ ½Ã, Æê Å×ÀÌ¸Ó¿Í ÀÎÁ¢ÇØ ÀÖÁö ¾ÊÀ¸¸é ¹«½Ã
		if( bTool == FALSE && CNpcChecker::GetInstance()->IsCloseNpc( MMI_PET_FOODMILL, pUser->GetWorld(), pUser->GetPos() ) == FALSE )
			return;

		CItemElem* pMaterial	= (CItemElem*)pUser->GetItemId( dwMaterialId );
		if( IsUsableItem( pMaterial ) == FALSE )
		{
			// error
			return;
		}
		ItemProp* pProp	= pMaterial->GetProp();
		if( pProp == NULL )
		{
			// error
			return;
		}

		if( pMaterial->IsCharged() )
		{
			pUser->AddDefinedText( TID_GAME_PET_FEED_CHARGED );
			return;
		}

		if( pProp->dwItemKind3 != IK3_GEM )
		{
			pUser->AddDefinedText( TID_GAME_PET_IS_NOT_FEED );
			return;
		}

		if( nNum <= 0 )
			nNum	= 1;
		if( nNum > pMaterial->m_nItemNum )
			nNum	= pMaterial->m_nItemNum;

		if( pUser->m_Inventory.IsEquip( dwMaterialId ) )
		{
			pUser->AddDefinedText( TID_GAME_PET_FEED_EQUIPED );
			return;
		}

		CItemElem itemElem;
		itemElem.m_dwItemId		= II_SYS_SYS_FEED_01;
		int nTotalFeed	= 0;
		int nPackMax	= itemElem.GetProp()->dwPackMax;
		for( int i = 0; i < nNum; i++ )
		{
			int nFeed	= CPetProperty::GetInstance()->GetFeedEnergy( pProp->dwCost, (int)bTool );
			if( nTotalFeed + nFeed > nPackMax )
			{
				nNum	= i;
				break;
			}
			nTotalFeed	+= nFeed;
		}
		itemElem.m_nItemNum		= nTotalFeed;
		itemElem.m_nHitPoint	= -1;

		int nResult = pUser->CreateItem( &itemElem );
		if( nResult )
		{
			//¸ÔÀÌ ¸¸µé±â ·Î±× : pMaterialÀÌ ¾ø¾îÁú ¸ÔÀÌ Àç·á, itemElem.m_nItemNumÀÌ »õ·Î »ý¼ºµÈ ¸ÔÀÌ ·®
			LogItemInfo aLogItem;
			aLogItem.Action = "~";
			aLogItem.SendName = pUser->GetName();
			aLogItem.RecvName = "PET_FOOD_MATERIAL_REMOVE";
			aLogItem.WorldId = pUser->GetWorld()->GetID();
			aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
			OnLogItem( aLogItem, pMaterial, nNum );

			aLogItem.RecvName = "PET_FOOD_CREATE";
			OnLogItem( aLogItem, &itemElem, itemElem.m_nItemNum );

			pUser->UpdateItem( (BYTE)( pMaterial->m_dwObjId ), UI_NUM, pMaterial->m_nItemNum - nNum );
			if( bTool )
				pUser->UpdateItem( (BYTE)( pTool->m_dwObjId ), UI_NUM, pTool->m_nItemNum - 1 );
		}
		pUser->AddPetFoodMill(nResult, itemElem.m_nItemNum);
	}
}

void CDPSrvr::OnPetTamerMistake( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwId;
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		ar >> dwId;
		CItemElem* pItemElem	= (CItemElem*)pUser->GetItemId( dwId );
		if( pItemElem && pItemElem->m_dwItemId == II_SYS_SYS_SCR_PET_TAMER_MISTAKE ) // m_dwItemId
		{
			CPet* pPet	= pUser->GetPet();
			if( pPet )
			{
				if( pPet->GetLevel() >= PL_C && pPet->GetLevel() <= PL_S )
				{
					// ÇöÀç ·¹º§¿¡¼­ ¾òÀº ´É·ÂÄ¡°¡ Ãë¼ÒµÇ¸ç,
					// Àü ´Ü°è ·¹º§, °æÇèÄ¡ 100%·Î µ¹¾Æ°£´Ù.
					pPet->SetAvailLevel( pPet->GetLevel(), 0 );		// ´É·ÂÄ¡ Ãë¼Ò
					pPet->SetLevel( pPet->GetLevel() - 1 );
					pPet->SetExp( MAX_PET_EXP );
					// ±âÁ¸ ¹öÇÁ Á¦°Å
					if( pUser->HasPet() )
						pUser->RemovePet();
					pUser->AddPet( pPet, PF_PET_LEVEL_DOWN );	// í»
					g_UserMng.AddPetLevelup( pUser, MAKELONG( (WORD)pPet->GetIndex(), (WORD)pPet->GetLevel() ) );	// öâ
					pUser->UpdateItem( (BYTE)( pItemElem->m_dwObjId ), UI_NUM, pItemElem->m_nItemNum - 1 );

					// log
					CItemElem* pPetItem		= pUser->GetPetItem();
					g_dpDBClient.CalluspPetLog( pUser->m_idPlayer, pPetItem->GetSerialNumber(), 0, PETLOGTYPE_MISTAKE, pPet );
#ifdef __PET_AUTO_LEVEL_UP
					pUser->PetLevelup();
#endif // __PET_AUTO_LEVEL_UP
				}
				else
				{
					pUser->AddDefinedText( TID_GAME_PET_BETWEEN_C_TO_S );
				}
			}
			else
			{
				pUser->AddDefinedText( TID_GAME_PET_NOT_FOUND );
			}
		}
		else
		{
			// error
		}
	}
}

void CDPSrvr::OnPetTamerMiracle( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwId;
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		ar >> dwId;
		CItemElem* pItemElem	= (CItemElem*)pUser->GetItemId( dwId );
		if( pItemElem && pItemElem->m_dwItemId == II_SYS_SYS_SCR_PET_TAMER_MIRACLE )
		{
			CPet* pPet	= pUser->GetPet();
			if( pPet )
			{
				if( pPet->GetLevel() >= PL_B && pPet->GetLevel() <= PL_S )
				{
					// ÇöÀç ·¹º§°ú ±× Àü ·¹º§¿¡¼­ ¾òÀº ´É·ÂÄ¡°¡ Ãë¼ÒµÇ¸ç,
					// ´Ù½Ã ·£´ýÇÏ°Ô ¾ò°Ô µÈ´Ù.
					pPet->SetAvailLevel( pPet->GetLevel() - 1, 0 );		// ´É·ÂÄ¡ Ãë¼Ò
					pPet->SetAvailLevel( pPet->GetLevel(), 0 );		// ´É·ÂÄ¡ Ãë¼Ò
					// ÀÓÀÇ ´É·ÂÄ¡ »ó½Â
					BYTE nAvailLevel	= CPetProperty::GetInstance()->GetLevelupAvailLevel( pPet->GetLevel() - 1 );
					pPet->SetAvailLevel( pPet->GetLevel() - 1, nAvailLevel );
					nAvailLevel	= CPetProperty::GetInstance()->GetLevelupAvailLevel( pPet->GetLevel() );
					pPet->SetAvailLevel( pPet->GetLevel(), nAvailLevel );

					if( pUser->HasPet() )
						pUser->RemovePet();
					pUser->AddPet( pPet, PF_PET_GET_AVAIL );	// í»	// PF_PET_GET_AVAIL 
					g_UserMng.AddPetLevelup( pUser, MAKELONG( (WORD)pPet->GetIndex(), (WORD)pPet->GetLevel() ) );	// öâ
					pUser->UpdateItem( (BYTE)( pItemElem->m_dwObjId ), UI_NUM, pItemElem->m_nItemNum - 1 );

					// log
					CItemElem* pPetItem		= pUser->GetPetItem();
					g_dpDBClient.CalluspPetLog( pUser->m_idPlayer, pPetItem->GetSerialNumber(), 0, PETLOGTYPE_MIRACLE, pPet );
				}
				else
				{
					pUser->AddDefinedText( TID_GAME_PET_BETWEEN_B_TO_S );
				}
			}
			else
			{
				pUser->AddDefinedText( TID_GAME_PET_NOT_FOUND );
			}
		}
		else
		{
			// error
		}
	}
}

void CDPSrvr::OnFeedPocketInactive( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		if( pUser->HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_PET_FEED_POCKET ) )
			pUser->RemoveBuff( BUFF_ITEM, II_SYS_SYS_SCR_PET_FEED_POCKET );
	}
}
#endif	// __PET_0410

#if __VER >= 9 // __CSC_VER9_2
void CDPSrvr::OnModifyStatus( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	int nStrCount, nStaCount, nDexCount, nIntCount;
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	ar >> nStrCount >> nStaCount >> nDexCount >> nIntCount;
	
	if((nStrCount < 0 || nStaCount < 0 || nDexCount < 0 || nIntCount < 0) ||
		(nStrCount + nStaCount + nDexCount + nIntCount <= 0)) //¾ç¼ö °Ë»ç ¹× ÇÕÀÌ 0ÀÌÇÏÀÏ °æ¿ì Áß´Ü.
		return;

#ifdef __GAMEGUARD
	if (pUser->m_nRemainGP < 0 || nStrCount > pUser->m_nRemainGP || nStaCount > pUser->m_nRemainGP || nDexCount > pUser->m_nRemainGP || nIntCount > pUser->m_nRemainGP)
		return;
#endif // __GAMEGUARD

	if( pUser->m_nRemainGP >= (nStrCount + nStaCount + nDexCount + nIntCount) )
	{
		pUser->m_nStr += nStrCount;
		pUser->m_nSta += nStaCount;
		pUser->m_nDex += nDexCount;
		pUser->m_nInt += nIntCount;
		pUser->m_nRemainGP = pUser->m_nRemainGP - (nStrCount + nStaCount + nDexCount + nIntCount);
#ifdef __GAMEGUARD
		pUser->AddSetState(pUser->m_nStr, pUser->m_nSta, pUser->m_nDex, pUser->m_nInt, pUser->m_nRemainGP, FALSE);
#else // __GAMEGUARD
		pUser->AddSetState(pUser->m_nStr, pUser->m_nSta, pUser->m_nDex, pUser->m_nInt, pUser->m_nRemainGP);
#endif // __GAMEGUARD
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
		pUser->CheckHonorStat();
		pUser->AddHonorListAck();//09.02.12
		g_UserMng.AddHonorTitleChange( pUser, pUser->m_nHonor);
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
#ifdef __RECORD_BOOK
		if (nStrCount > 0)
			CRecordBook::GetInstance()->AddPlayerRecord(pUser, RecordType::STR, pUser->GetStr(), false);

		if (nStaCount > 0)
		{
			CRecordBook::GetInstance()->AddPlayerRecord(pUser, RecordType::STA, pUser->GetSta(), false);
			CRecordBook::GetInstance()->AddPlayerRecord(pUser, RecordType::HP, pUser->GetMaxHitPoint(), false);
		}

		if (nDexCount > 0)
			CRecordBook::GetInstance()->AddPlayerRecord(pUser, RecordType::DEX, pUser->GetDex(), false);

		if (nIntCount > 0)
			CRecordBook::GetInstance()->AddPlayerRecord(pUser, RecordType::INTT, pUser->GetInt(), false);
#endif
	}
}	
#endif //__CSC_VER9_2

#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
void CDPSrvr::OnLegendSkillStart( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;
	
	OBJID objItemId[5];
	
	for( int i=0; i<5; ++i )
		ar >> objItemId[i];

#ifdef __NEWCLASS
	if ((pUser->IsHero() == FALSE) && (pUser->IsLegendHero() == FALSE) && (pUser->IsLegendHeroUltimate() == FALSE))
#elif defined (__3RD_LEGEND16)
	if ((pUser->IsHero() == FALSE) && (pUser->IsLegendHero() == FALSE))
#else // __3RD_LEGEND16
	if (pUser->IsHero() == FALSE)
#endif // __3RD_LEGEND16
	{
		return;
	}

	for( int i = 0; i < MAX_SKILL_JOB; i++ ) 
	{				
		LPSKILL lpSkill = &(pUser->m_aJobSkill[i]);
		if( lpSkill && lpSkill->dwSkill != NULL_ID )
		{
			ItemProp* pSkillProp    = prj.GetSkillProp( lpSkill->dwSkill );			
			if( pSkillProp == NULL )
				continue;
			if( pSkillProp->dwItemKind1 != JTYPE_HERO)
				continue;
			if( lpSkill->dwLevel > 4 )
			{
				pUser->AddLegendSkillResult(-1);
				return;
			}
		}
	}	

	CItemElem* pItemElem[14];
	// ÀÏÄ¡ÇÏ´ÂÁö °Ë»ç (ÀÎº¥Åä¸®¿¡¼­ °Ë»ç)
	for( int i=0; i<14; i++ )
	{
		pItemElem[i]	= (CItemElem*)pUser->m_Inventory.GetAtId( objItemId[i] );
		if( IsUsableItem( pItemElem[i] ) == FALSE )
			return ;
	}

	if( pItemElem[0]->m_dwItemId != II_GEN_MAT_DIAMOND ||
		pItemElem[1]->m_dwItemId != II_GEN_MAT_EMERALD ||
		pItemElem[2]->m_dwItemId != II_GEN_MAT_SAPPHIRE ||
		pItemElem[3]->m_dwItemId != II_GEN_MAT_RUBY ||
		pItemElem[4]->m_dwItemId != II_GEN_MAT_TOPAZ
#ifdef __NEWS_DIAMOND
		|| pItemElem[5]->m_dwItemId != II_GEN_MAT_DIAMOND_FOR
		|| pItemElem[6]->m_dwItemId != II_GEN_MAT_DIAMOND_END
		|| pItemElem[7]->m_dwItemId != II_GEN_MAT_DIAMOND_DEX
		|| pItemElem[8]->m_dwItemId != II_GEN_MAT_DIAMOND_INT
		|| pItemElem[9]->m_dwItemId != II_GEN_MAT_DIAMOND_PVP
		|| pItemElem[10]->m_dwItemId != II_GEN_MAT_DIAMOND_SIPHON
		|| pItemElem[11]->m_dwItemId != II_GEN_MAT_DIAMOND_DEF
		|| pItemElem[12]->m_dwItemId != II_GEN_MAT_DIAMOND_ATK
		|| pItemElem[13]->m_dwItemId != II_GEN_MAT_DIAMOND_PV
#endif //__NEWS_DIAMOND
		)
		return;

	// ¸ðµÎ ÀÏÄ¡ÇÏ¸é º¸¼® ¾ÆÀÌÅÛ »èÁ¦
	for( int i=0; i<14 ; i++ )
	{
		LogItemInfo aLogItem;
		aLogItem.Action = "+";
		aLogItem.SendName = pUser->GetName();
		aLogItem.RecvName = "LEGENDSKILL_USE";
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		OnLogItem( aLogItem, pItemElem[i], 1 );
		pUser->RemoveItem( (BYTE)( objItemId[i] ), (short)1 );
	}

	
	if( xRandom(1000) > 766 )
	{
		for( int i = 0; i < MAX_SKILL_JOB; i++ ) 
		{				
			LPSKILL lpSkill = &(pUser->m_aJobSkill[i]);
			if( lpSkill && lpSkill->dwSkill != NULL_ID )
			{
				ItemProp* pSkillProp    = prj.GetSkillProp( lpSkill->dwSkill );			
				if( pSkillProp == NULL )
					continue;
				if( pSkillProp->dwItemKind1 != JTYPE_HERO)
					continue;
				lpSkill->dwLevel++;

				g_dpDBClient.SendLogSkillPoint( LOG_SKILLPOINT_USE, 1, (CMover*)pUser, &(pUser->m_aJobSkill[i]) );
			}
		}	
		g_UserMng.AddCreateSfxObj((CMover *)pUser, XI_SYS_EXCHAN01, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
		pUser->AddDoUseSkillPoint( &(pUser->m_aJobSkill[0]), pUser->m_nSkillPoint );
#ifdef __S_NEW_SKILL_2
		g_dpDBClient.SaveSkill( pUser );
#endif // __S_NEW_SKILL_2
		pUser->AddLegendSkillResult(TRUE);	
	}
	else
	{
		pUser->AddLegendSkillResult(FALSE);
	}
}
#endif	//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

#if __VER >= 11 // __GUILD_COMBAT_1TO1
void CDPSrvr::OnGC1to1TenderOpenWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	g_GuildCombat1to1Mng.SendTenderGuildOpenWnd( pUser );
}

void CDPSrvr::OnGC1to1TenderView( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	g_GuildCombat1to1Mng.SendTenderGuildView( pUser );
}

void CDPSrvr::OnGC1to1Tender( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;
	
	int nPenya;
	ar >> nPenya;

	g_GuildCombat1to1Mng.SetTenderGuild( pUser, nPenya );
}

void CDPSrvr::OnGC1to1CancelTender( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	g_GuildCombat1to1Mng.SetCancelTenderGuild( pUser );
}

void CDPSrvr::OnGC1to1FailedTender( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	g_GuildCombat1to1Mng.SetFailedTenderGuild( pUser );
}


void CDPSrvr::OnGC1to1MemberLineUpOpenWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	g_GuildCombat1to1Mng.SendMemberLineUpOpenWnd( pUser );
}

void CDPSrvr::OnGC1to1MemberLineUp( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	vector<u_long> vecMemberId;
	u_long nTemp;
	int nSize;

	ar >> nSize;

	if( nSize > g_GuildCombat1to1Mng.m_nMaxJoinPlayer || nSize < 0 )
		return;

	for( int i=0; i<nSize; i++ )
	{
		ar >> nTemp;
		vecMemberId.push_back( nTemp );
	}
	
	g_GuildCombat1to1Mng.SetMemberLineUp( pUser, vecMemberId );
}

void CDPSrvr::OnGC1to1TeleportToNPC( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	g_GuildCombat1to1Mng.SetTeleportToNPC( pUser );
}

void CDPSrvr::OnGC1to1TeleportToStage( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	g_GuildCombat1to1Mng.SetTeleportToStage( pUser );
}
#endif // __GUILD_COMBAT_1TO1

#if __VER >= 11 // __SYS_COLLECTING
void CDPSrvr::OnQueryStartCollecting(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->IsDisguise())
			return;

#ifdef __GAMEGUARD
		if (pUser->GetWorld() && pUser->GetWorld()->GetID() == WI_WORLD_MADRIGAL, WI_WORLD_BELIAMARA)
#endif // __GAMEGUARD
		{
#ifdef MAX_FISH_BY_IP
			if (g_UserMng.CanCollect(pUser->m_playAccount.lpAddr))
#endif // MAX_FISH_BY_IP
			{
				pUser->StartCollecting();
			}
#ifdef MAX_FISH_BY_IP
			else
			{
				CString str;
				str.Format(prj.GetText(TID_MAX_COLLECTOR_BY_IP_01), MAX_FISH_BY_IP);
				pUser->AddText(str, 0xFFFF0000);
			}
#endif // MAX_FISH_BY_IP
		}
	}
}

void CDPSrvr::OnQueryStopCollecting(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
		if (IsValidObj(pUser)
#ifdef __AEGON_FIXES
			&& pUser->IsCollecting()
#endif
			)
		pUser->StopCollecting();
}
#endif	// __SYS_COLLECTING

	
#if __VER >= 11 // __MA_VER11_04	// ±æµå Ã¢°í ·Î±× ±â´É world,database,neuz
void CDPSrvr::OnQueryGuildBankLogList( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	bool bMK = FALSE;
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
	{
		BYTE byListType;
		ar >> byListType;
		CGuild *pGuild = pUser->GetGuild();

		if( pGuild )
		{
			CGuildMember* pGuildMember = pGuild->GetMember( pUser->m_idPlayer );
			if( pGuildMember )
			{
				if( pGuildMember->m_nMemberLv == GUD_KINGPIN || pGuildMember->m_nMemberLv == GUD_MASTER )
					g_dpDBClient.SendQueryGetGuildBankLogList( pUser->m_idPlayer, pGuild->m_idGuild,byListType );
			}
		}
		// ±æµå°¡ ¾ø°Å³ª ±æµåÀåÀÌ ¾Æ´Ï¸é ½ÅÃ» ºÒ°¡
	}
}
#endif //__MA_VER11_04	// ±æµå Ã¢°í ·Î±× ±â´É world,database,neuz
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
void CDPSrvr::OnHonorListReq( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
	{
		pUser->AddHonorListAck();
	}
}
void CDPSrvr::OnHonorChangeReq( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
	{
		int nChange;
		ar >> nChange;
		if( nChange > -1 && nChange < MAX_HONOR_TITLE )
		{
			int nNeed =  CTitleManager::Instance()->GetNeedCount( nChange,-1);
			if( nNeed < 0)
				return;
			if( pUser->GetHonorTitle(nChange) >= nNeed )
			{
				pUser->m_nHonor = nChange;
				g_UserMng.AddHonorTitleChange( pUser, nChange );
			}
		}
		else if(nChange == -1)
		{
			pUser->m_nHonor = nChange;
			g_UserMng.AddHonorTitleChange( pUser, nChange );
		}
	}
}
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ

#if __VER >= 11 // __MA_VER11_05	// ÄÉ¸¯ÅÍ ºÀÀÎ °Å·¡ ±â´É world,database,neuz
void CDPSrvr::OnSealCharReq( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
	{
		CGuild *pGuild = pUser->GetGuild();
		if( pGuild != NULL )
		{
			pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CLEANGUILD );
			return;
		}
		if( pUser->IsChaotic() )
		{
			pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CLEANEQUIP );
			return;
		}
		int nSize	= 0;
		for( int i=0; i< pUser->m_Inventory.GetMax(); ++i )
		{
			CItemElem* pItemElem = pUser->m_Inventory.GetAtId( i );
			if( IsUsableItem( pItemElem ) == FALSE )
				continue;
			if( pItemElem->m_nItemNum > 0 )
				nSize++;
		}
		
		if( nSize > 1 )
		{
			pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CLEANINVEN );
			return;
		}
		else
		{
			CItemElem* pItemElem = NULL;
			pItemElem = pUser->m_Inventory.GetAtItemId( II_SYS_SYS_SCR_SEAL );
			if( IsUsableItem( pItemElem ) == FALSE )
			{
				pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CLEANINVEN );
				return;
			}
			else if(pItemElem->m_nItemNum > 1)
			{
				pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CLEANINVEN );
				return;
			}
		}

		if( pUser->GetGold() > 0 )
		{
			pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CLEANEQUIP );
			return;
		}
		int nBankSize	= 0;
		for( int i=0; i< pUser->m_Bank[pUser->m_nSlot].GetMax(); ++i )
		{
			CItemElem* pItemElem = pUser->m_Bank[pUser->m_nSlot].GetAtId( i );
			if( IsUsableItem( pItemElem ) == FALSE )
				continue;
			if( pItemElem->m_nItemNum > 0 )
				nBankSize++;
		}
#if __VER >= 11 // __SYS_POCKET
		if( !pUser->m_Pocket.IsAllClean() )
		{
			pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CLEANBANK );
			return;
		}
#endif		
		if( nBankSize > 0 || pUser->m_dwGoldBank[pUser->m_nSlot] > 0)
		{
			pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CLEANBANK );
			return;
		}
		g_dpDBClient.SendQueryGetSealChar( pUser->m_idPlayer,pUser->m_playAccount.lpszAccount);
//		pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CHARSEND );
	}
}
void CDPSrvr::OnSealCharConmReq( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	OBJID objidSend;
	ar >> objidSend;

	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
	{
		CGuild *pGuild = pUser->GetGuild();
		if( pGuild != NULL )
		{
			pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CLEANGUILD );
			return;
		}
		int nSize	= 0;
		for( int i=0; i< pUser->m_Inventory.GetMax(); ++i )
		{
			CItemElem* pItemElem = pUser->m_Inventory.GetAtId( i );
			if( IsUsableItem( pItemElem ) == FALSE )
				continue;
			if( pItemElem->m_nItemNum > 0 )
				nSize++;
		}

		CItemElem* pItemElemTrue = NULL;
		CItemElem* pItemElemtmp = NULL;
		
		if( nSize > 1 )
		{
			pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CLEANINVEN );
			return;
		}
		else
		{
			pItemElemTrue = pUser->m_Inventory.GetAtItemId( II_SYS_SYS_SCR_SEAL );
			if( IsUsableItem( pItemElemTrue ) == FALSE )
			{
				pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CLEANINVEN );
				return;
			}
			else if(pItemElemTrue->m_nItemNum > 1)
			{
				pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CLEANINVEN );
				return;
			}
			pItemElemtmp = pItemElemTrue;
		}

		if( pUser->GetGold() > 0 )
		{
			pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CLEANEQUIP );
			return;
		}
		int nBankSize	= 0;
		for( int i=0; i< pUser->m_Bank[pUser->m_nSlot].GetMax(); ++i )
		{
			CItemElem* pItemElem = pUser->m_Bank[pUser->m_nSlot].GetAtId( i );
			if( IsUsableItem( pItemElem ) == FALSE )
				continue;
			if( pItemElem->m_nItemNum > 0 )
				nBankSize++;
		}
#if __VER >= 11 // __SYS_POCKET
		if( !pUser->m_Pocket.IsAllClean() )
		{
			pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CLEANBANK );
			return;
		}
#endif
		if( nBankSize > 0 || pUser->m_dwGoldBank[pUser->m_nSlot] > 0)
		{
			pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CLEANBANK );
			return;
		}
	
#if __VER >= 11 // __SYS_PLAYER_DATA
		const char* lpszPlayer	= CPlayerDataCenter::GetInstance()->GetPlayerString( objidSend );
#else	// __SYS_PLAYER_DATA
		LPCSTR lpszPlayer = prj.GetPlayerString( objidSend );
#endif	// __SYS_PLAYER_DATA

		if( lpszPlayer == NULL )
		{
			pUser->AddDefinedText( TID_GAME_SEALCHAR_NO_CHARSEND );
			return;
		}


		CItemElem itemElemSend;
		itemElemSend.m_dwItemId = II_SYS_SYS_SCR_SEALCHARACTER;
		itemElemSend.m_nItemNum	= 1;
		itemElemSend.SetSerialNumber();

//		lstrcpy( itemElemSend.m_szItemText, pUser->GetName() );
		memcpy( itemElemSend.m_szItemText, pUser->GetName(),sizeof(itemElemSend.m_szItemText) );

		itemElemSend.m_nRepairNumber	= pUser->GetLevel();//nlevel
		itemElemSend.m_nHitPoint	= pUser->m_idPlayer;//m_idPlayer
		itemElemSend.m_nRepair	= pUser->GetJob();//njob

		itemElemSend.m_nResistAbilityOption	= pUser->GetRemainGP();//nPOINT

		itemElemSend.SetPiercingSize( 4 );
		itemElemSend.SetPiercingItem( 0, pUser->GetSta() );		//nSTA
		itemElemSend.SetPiercingItem( 1, pUser->GetStr() );		//nSTR
		itemElemSend.SetPiercingItem( 2, pUser->GetDex() );		//nDEX
		itemElemSend.SetPiercingItem( 3, pUser->GetInt() );		//nINT
		
		LogItemInfo aLogItem;
		aLogItem.RecvName = "SEALCHAR";
		g_dpDBClient.SendQueryPostMail( objidSend, 0, itemElemSend, 0, itemElemSend.GetProp()->szName, 	(char*)GETTEXT( TID_MMI_SEALCHARITEM ) );

		aLogItem.Action = "+";
		aLogItem.SendName = pUser->GetName();
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		OnLogItem( aLogItem, &itemElemSend, 1 );


		ItemProp* pItemProp  = pItemElemtmp->GetProp();
		g_dpDBClient.SendLogSMItemUse( "1", pUser, pItemElemtmp, pItemProp );		
//		pItemElemtmp->UseItem();
		OBJID       dwTmpObjId = pItemElemtmp->m_dwObjId;
		pUser->RemoveItem( (BYTE)( dwTmpObjId ), (short)1 );

		pUser->ClearAllSMMode();
		pUser->RemoveAllBuff();

		g_dpDBClient.SendQueryGetSealCharConm( pUser->m_idPlayer);

//		pUser->UpdateItem( pItemElemtmp->m_dwObjId, UI_NUM, pItemElemtmp->m_nItemNum );
//		g_UserMng.DestroyPlayer( pUser );
//		g_UserMng.RemoveUser( pUser->m_dwSerial );
//		g_DPCoreClient.SendKillPlayer( pUser->m_idPlayer, pUser->m_idPlayer );
		QueryDestroyPlayer( pUser->m_Snapshot.dpidCache, pUser->m_Snapshot.dpidUser, pUser->m_dwSerial, pUser->m_idPlayer ); // pUser->m_Snapshot.dpidUser¿¡´Â ¼ÒÄÏ¹øÈ£°¡ µé¾î°¡ ÀÖ´Ù.
	}
}
void CDPSrvr::OnSealCharGetReq( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	DWORD dwData;
	DWORD dwId;

	ar >> dwData ;

	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
	{
		dwId = HIWORD( dwData );

		if( pUser->IsUsableState( dwId ) == FALSE )
			return;

		CItemElem* pItemElem = pUser->m_Inventory.GetAtId( dwId );
		if( IsUsableItem( pItemElem ) )
		{
			if(pItemElem->m_dwItemId != II_SYS_SYS_SCR_SEALCHARACTER )
				return;
			g_dpDBClient.SendQueryGetSealCharGet( pUser->m_idPlayer,pUser->m_playAccount.lpszAccount,dwId);
		}
	}
}

#endif // __MA_VER11_05	// ÄÉ¸¯ÅÍ ºÀÀÎ °Å·¡ ±â´É world,database,neuz

#if __VER >= 11 // __SYS_POCKET
void	CDPSrvr::OnMoveItemOnPocket( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		int nPocket1, nItem, nPocket2;
		short nNum;
		ar >> nPocket1 >> nItem >> nNum >> nPocket2;

#ifdef __SECURITY_FIXES  
		if (nNum <= 0)
		{
			Error("CDPSrvr::OnMoveItemOnPocket : Dupe Try -> [Player ID: %07d], [Player Name: %s], [Packet used: %d,%d,%d,%d]",
				pUser->m_idPlayer, pUser->GetName(), nPocket1, nItem, nNum, nPocket2);
			return;
		}

		if (nItem < 0 || nPocket2 > 2 || nPocket1 < -1 || nPocket2 < -1 || nPocket1 > 52)
		{
			Error("CDPSrvr::OnMoveItemOnPocket : Crash Try -> [Player ID: %07d], [Player Name: %s], [Packet used: %d,%d,%d,%d]",
				pUser->m_idPlayer, pUser->GetName(), nPocket1, nItem, nNum, nPocket2);
			return;
		}
		if (nNum <= 0 || nItem < 0 || nPocket2 > 2 || nPocket1 < -1 || nPocket1 > 52)
			return;
#endif // __SECURITY_FIXES

#ifdef __GAMEGUARD
		if (nNum <= 0 || nItem < 0)
			return;
#endif // __GAMEGUARD

		// mirchang 091214 - Âø¿ëÁßÀÎ ¾ÆÀÌÅÛÀÎÁö Ã¼Å©
		if (nPocket1 == -1)	// ¿øº»ÀÌ ÀÎº¥Åä¸®ÀÎÁö °Ë»ç!
		{
			if (pUser->m_Inventory.IsEquip(nItem))
				return;
		}

		CItemElem* pItem = pUser->GetItemId2(nPocket1, nItem);	// 여기서 휴대가방 만료검사 같이함.
		if (!pItem)
			return;
		if (IsUsableItem(pItem))
		{
			if (nPocket1 < 0 && pUser->IsUsing(pItem))
				return;
			if (nNum > pItem->m_nItemNum)
				return;
#ifdef __SECURITY_FIXES
			if( nNum < 1 )
				return;
#endif // __SECURITY_FIXES

			CItemElem item;
			item	= *pItem;
			item.m_nItemNum		= nNum;
#if (defined (__BAG_LOOT) && defined (__DROP_LOG)) || (defined (__BAG_LOOT) && defined (__FL_FARM_STAT))
			if (pUser->CreateItem2(&item, nPocket2, FALSE))
#else
			if (pUser->CreateItem2(&item, nPocket2))
#endif
			{
				pUser->RemoveItem2( nItem, nNum, nPocket1 );
				// log
				LogItemInfo	log;
				log.Action	= "m";
				log.SendName	= pUser->GetName();
				log.RecvName	= "OnMoveItemOnPocket";
				log.WorldId		= pUser->GetWorld()->GetID();
				log.Gold	= nPocket1;
				log.Gold2	= nPocket2;
				OnLogItem( log, &item, nNum );
			}
		}
	}
}

void	CDPSrvr::OnAvailPocket( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
	{
		int nPocket, nItem;
		ar >> nPocket >> nItem;
		if( nPocket <= 0 && nPocket >= MAX_POCKET )
			return;
		CItemElem* pItemElem	= pUser->m_Inventory.GetAtId( nItem );
		if( IsUsableItem( pItemElem ) )
		{
			ItemProp* pItemProp		= pItemElem->GetProp();
			if( pItemProp->dwItemKind3 == IK3_POCKET )
			{
				if( !pUser->m_Pocket.IsAvailable( nPocket ) )
				{
					pUser->m_Pocket.SetAttribute( CPocketController::avail, nPocket, pItemProp->dwSkillTime );
					// log
					LogItemInfo	log;
					log.Action	= "u";
					log.SendName	= pUser->GetName();
					log.RecvName	= "OnAvailPocket";
					log.WorldId		= pUser->GetWorld()->GetID();
					log.Gold	= pUser->GetGold();
					log.Gold2	= pUser->GetGold();
					log.Gold_1	= nPocket;
					OnLogItem( log, pItemElem, 1 );
					pUser->UpdateItem( (BYTE)( pItemElem->m_dwObjId ), UI_NUM, pItemElem->m_nItemNum - 1 );
#ifdef __INTERNALSERVER
					pUser->AddPocketView();
#endif	// __INTERNALSERVER
				}
			}
		}
	}
}
#endif	// __SYS_POCKET

#if __VER >= 11 // __SYS_IDENTIFY
void	CDPSrvr::OnBlessednessCancel( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
	{
		if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_BLESSING_CANCEL, pUser->GetWorld(), pUser->GetPos() ) )
			return;

		int nItem;
		ar >> nItem;
		CItemElem* pItem	= (CItemElem*)pUser->GetItemId( nItem );
		if( IsUsableItem( pItem ) )
		{
#ifdef __GAMEGUARD
			if (pUser->m_Inventory.IsEquip(pItem->m_dwObjId))
				return;
#endif // __GAMEGUARD
			if( g_xRandomOptionProperty->GetRandomOptionKind( pItem ) == CRandomOptionProperty::eBlessing
				&& g_xRandomOptionProperty->GetRandomOptionSize( pItem->GetRandomOptItemId() ) > 0 )
			{
				g_xRandomOptionProperty->InitializeRandomOption( pItem->GetRandomOptItemIdPtr() );
				pUser->UpdateItemEx( (BYTE)( pItem->m_dwObjId ), UI_RANDOMOPTITEMID, pItem->GetRandomOptItemId() );
				pUser->AddDiagText( prj.GetText( TID_GAME_BLESSEDNESS_CANCEL_INFO ) );
				// log
				LogItemInfo	log;
				log.Action	= "r";
				log.SendName	= pUser->GetName();
				log.RecvName	= "OnBlessednessCancel";
				log.WorldId		= pUser->GetWorld()->GetID();
				log.Gold	= pUser->GetGold();
				log.Gold2	= pUser->GetGold();
				OnLogItem( log, pItem, 1 );
			}
			else
			{
				pUser->AddDefinedText( TID_GAME_BLESSEDNESS_CANCEL );	
			}
		}		
	}
}

void	CDPSrvr::OnAwakening( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
	{
		if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_ITEM_AWAKENING, pUser->GetWorld(), pUser->GetPos() ) )
			return;

		const int	nCost	= 100000;
		if( pUser->GetGold() < nCost )
		{
			pUser->AddDefinedText( TID_GAME_LACKMONEY, "" );
			return;
		}
		int	nItem;
		ar >> nItem;
		CItemElem* pItem	= pUser->m_Inventory.GetAtId( nItem );
		if( IsUsableItem( pItem ) )
		{
			int nRandomOptionKind	= g_xRandomOptionProperty->GetRandomOptionKind( pItem );

			if( nRandomOptionKind != CRandomOptionProperty::eAwakening )
			{
				pUser->AddDefinedText( TID_GAME_INVALID_TARGET_ITEM );
				return;
			}
			if( g_xRandomOptionProperty->GetRandomOptionSize( pItem->GetRandomOptItemId() ) > 0 )
			{
				pUser->AddDefinedText( TID_GAME_AWAKE_OR_BLESSEDNESS01 );
				return;
			}
			g_xRandomOptionProperty->InitializeRandomOption( pItem->GetRandomOptItemIdPtr() );
			g_xRandomOptionProperty->GenRandomOption( pItem->GetRandomOptItemIdPtr(), nRandomOptionKind, pItem->GetProp()->dwParts );
			pUser->UpdateItemEx( (BYTE)( pItem->m_dwObjId ), UI_RANDOMOPTITEMID, pItem->GetRandomOptItemId() );
			pUser->AddGold( -nCost );
			pUser->AddDefinedText( TID_GAME_AWAKENING_SUCCESS );
			// log
			LogItemInfo	log;
			log.Action	= "r";
			log.SendName	= pUser->GetName();
			log.RecvName	= "OnAwakening";
			log.WorldId		= pUser->GetWorld()->GetID();
			log.Gold	= pUser->GetGold() + nCost;
			log.Gold2	= pUser->GetGold();
			log.Gold_1	= -nCost;
			OnLogItem( log, pItem, 1 );
		}
	}
}
#endif	// __SYS_IDENTIFY

#ifdef __NPC_BUFF
void	CDPSrvr::OnNPCBuff(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
#ifdef __GAMEGUARD
		if (pUser->m_dwLastBuff + SEC(10) > GetTickCount())
		{
			pUser->AddText(prj.GetText(TID_GAMEGUARD_02), 0xFFFF0000);
			return;
		}
#endif // __GAMEGUARD

		CHAR	m_szKey[64];
		ar.ReadString(m_szKey, 64);
		LPCHARACTER lpChar = prj.GetCharacter(m_szKey);

#ifdef __BUFF_PANG_UPDATE
		switch (pUser->GetJob())
		{
		case JOB_MERCENARY:
		{
			pUser->DoAddBuff2(SI_MER_SUP_IMPOWERWEAPON, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_SMITEAXE, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_AXEMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_SWORDMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_BLAZINGSWORD, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SHIELD_PANBARRIER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SHIELD_PROTECTION, 20, 10000, pUser);
		}
		break;
		case JOB_BLADE:
		{
			pUser->DoAddBuff2(SI_MER_SUP_IMPOWERWEAPON, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_SMITEAXE, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_AXEMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_SWORDMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_BLAZINGSWORD, 20, 10000, pUser);
		}
		break;
		case JOB_BLADE_MASTER:
		{
			pUser->DoAddBuff2(SI_BLD_MASTER_ONEHANDMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_IMPOWERWEAPON, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_SMITEAXE, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_AXEMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_SWORDMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_BLAZINGSWORD, 20, 10000, pUser);
		}
		break;
		case JOB_STORMBLADE_HERO:
		{
			pUser->DoAddBuff2(SI_STORM_SUP_POWERINCREASE, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_BLD_MASTER_ONEHANDMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_IMPOWERWEAPON, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_SMITEAXE, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_AXEMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_SWORDMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_BLAZINGSWORD, 20, 10000, pUser);
		}
		break;
		case JOB_STORMBLADE_HERO_ULTIMATE:
		{
			pUser->DoAddBuff2(SI_STORM_SUP_POWERINCREASE, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_BLD_MASTER_ONEHANDMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_IMPOWERWEAPON, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_SMITEAXE, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_AXEMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_SWORDMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_BLAZINGSWORD, 20, 10000, pUser);
		}
		break;
		default: break;
		}

		switch (pUser->GetJob())
		{
		case JOB_ACROBAT:
		{
			pUser->DoAddBuff2(SI_ACR_SUP_YOYOMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_ACR_SUP_BOWMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_ACR_YOYO_ABSOLUTEBLOCK, 20, 10000, pUser);
		}
		break;
		case JOB_RANGER:
		{
			pUser->DoAddBuff2(SI_RAG_SUP_FASTATTACK, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_RAG_SUP_NATURE, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ACR_SUP_BOWMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_ACR_YOYO_ABSOLUTEBLOCK, 20, 10000, pUser);
		}
		break;
		case JOB_RANGER_MASTER:
		{
			pUser->DoAddBuff2(SI_RAG_MASTER_BOWMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_RAG_SUP_FASTATTACK, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_RAG_SUP_NATURE, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ACR_SUP_BOWMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_ACR_YOYO_ABSOLUTEBLOCK, 20, 10000, pUser);
		}
		break;
		case JOB_CRACKSHOOTER_HERO:
		{
			pUser->DoAddBuff2(SI_CRA_SUP_POWERINCREASE, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_CRA_SUP_CONTROLINCREASE, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_CRA_SUP_HAWKEYE, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_RAG_MASTER_BOWMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_RAG_SUP_FASTATTACK, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_RAG_SUP_NATURE, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ACR_SUP_BOWMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_ACR_YOYO_ABSOLUTEBLOCK, 20, 10000, pUser);
		}
		break;
		case JOB_CRACKSHOOTER_HERO_ULTIMATE:
		{
			pUser->DoAddBuff2(SI_CRA_SUP_POWERINCREASE, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_CRA_SUP_CONTROLINCREASE, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_CRA_SUP_HAWKEYE, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_RAG_MASTER_BOWMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_RAG_SUP_FASTATTACK, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_RAG_SUP_NATURE, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ACR_SUP_BOWMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_ACR_YOYO_ABSOLUTEBLOCK, 20, 10000, pUser);
		}
		break;
		default: break;
		}

		switch (pUser->GetJob())
		{
		case JOB_ELEMENTOR:
		{
			pUser->DoAddBuff2(SI_ELE_FIRE_FIREMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_EARTH_EARTHMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_WIND_WINDMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_ELECTRICITY_LIGHTINGMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_WATER_WATERMASTER, 10, 10000, pUser);
		}
		break;
		case JOB_ELEMENTOR_MASTER:
		{
			pUser->DoAddBuff2(SI_ELE_MASTER_INTMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_FIRE_FIREMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_EARTH_EARTHMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_WIND_WINDMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_ELECTRICITY_LIGHTINGMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_WATER_WATERMASTER, 10, 10000, pUser);
		}
		break;
		case JOB_ELEMENTORLORD_HERO:
		{
			pUser->DoAddBuff2(SI_ELE_MASTER_INTMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_FIRE_FIREMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_EARTH_EARTHMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_WIND_WINDMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_ELECTRICITY_LIGHTINGMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_WATER_WATERMASTER, 10, 10000, pUser);
		}
		break;
		case JOB_ELEMENTORLORD_HERO_ULTIMATE:
		{
			pUser->DoAddBuff2(SI_ELE_MASTER_INTMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_FIRE_FIREMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_EARTH_EARTHMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_WIND_WINDMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_ELECTRICITY_LIGHTINGMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ELE_WATER_WATERMASTER, 10, 10000, pUser);
		}
		break;
		default: break;
		}

		switch (pUser->GetJob())
		{
		case JOB_ASSIST:
		{
			pUser->DoAddBuff2(SI_ASS_CHEER_STONEHAND, 20, 10000, pUser);
		}
		break;
		case JOB_RINGMASTER:
		{
			pUser->DoAddBuff2(SI_RIN_SUP_PROTECT, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_RIN_SUP_HOLYGUARD, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_RIN_SUP_SPIRITUREFORTUNE, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_RIN_SQU_GEBURAHTIPHRETH, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_ASS_CHEER_STONEHAND, 20, 10000, pUser);
		}
		break;
		case JOB_RINGMASTER_MASTER:
		{
			pUser->DoAddBuff2(SI_RIG_MASTER_BLESSING, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_RIN_SUP_PROTECT, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_RIN_SUP_HOLYGUARD, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_RIN_SUP_SPIRITUREFORTUNE, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_RIN_SQU_GEBURAHTIPHRETH, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_ASS_CHEER_STONEHAND, 20, 10000, pUser);
		}
		break;
		case JOB_RINGMASTER_HERO:
		{
			pUser->DoAddBuff2(SI_RIG_MASTER_BLESSING, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_RIN_SUP_PROTECT, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_RIN_SUP_HOLYGUARD, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_RIN_SUP_SPIRITUREFORTUNE, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_RIN_SQU_GEBURAHTIPHRETH, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_ASS_CHEER_STONEHAND, 20, 10000, pUser);
		}
		break;
		case JOB_FLORIST_HERO:
		{
			pUser->DoAddBuff2(SI_FLO_SQU_BLESSSTEP, 5, 3600, pUser);
			pUser->DoAddBuff2(SI_FLO_SQU_BLESSBODY, 5, 3600, pUser);
			pUser->DoAddBuff2(SI_FLO_SQU_BLESSARMOR, 5, 3600, pUser);
			pUser->DoAddBuff2(SI_FLO_HEAL_DOT, 5, 1800, pUser);
			pUser->DoAddBuff2(SI_RIG_MASTER_BLESSING, 5, 4000, pUser);
			pUser->DoAddBuff2(SI_RIN_SUP_PROTECT, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_RIN_SUP_HOLYGUARD, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_RIN_SUP_SPIRITUREFORTUNE, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_RIN_SQU_GEBURAHTIPHRETH, 10, 3600, pUser);
		}
		break;
		case JOB_FLORIST_HERO_ULTIMATE:
		{
			pUser->DoAddBuff2(SI_FLO_SQU_BLESSSTEP, 5, 3600, pUser);
			pUser->DoAddBuff2(SI_FLO_SQU_BLESSBODY, 5, 3600, pUser);
			pUser->DoAddBuff2(SI_FLO_SQU_BLESSARMOR, 5, 3600, pUser);
			pUser->DoAddBuff2(SI_FLO_HEAL_DOT, 5, 1800, pUser);
			pUser->DoAddBuff2(SI_RIG_MASTER_BLESSING, 5, 4000, pUser);
			pUser->DoAddBuff2(SI_RIN_SUP_PROTECT, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_RIN_SUP_HOLYGUARD, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_RIN_SUP_SPIRITUREFORTUNE, 10, 3600, pUser);
			pUser->DoAddBuff2(SI_RIN_SQU_GEBURAHTIPHRETH, 10, 3600, pUser);
		}
		break;
		default: break;
		}

		switch (pUser->GetJob())
		{
		case JOB_KNIGHT:
		{
			pUser->DoAddBuff2(SI_MER_SUP_IMPOWERWEAPON, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_BLAZINGSWORD, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SUP_SWORDMASTER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_KNT_SUP_GUARD, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_KNT_SUP_RAGE, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_KNT_SUP_PAINREFLECTION, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SHIELD_PANBARRIER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SHIELD_PROTECTION, 20, 10000, pUser);
		}
		break;
		case JOB_KNIGHT_MASTER:
		{
			pUser->DoAddBuff2(SI_KNT_MASTER_TWOHANDMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_KNT_SUP_GUARD, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_KNT_SUP_RAGE, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_KNT_SUP_PAINREFLECTION, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SHIELD_PANBARRIER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SHIELD_PROTECTION, 20, 10000, pUser);
		}
		break;
		case JOB_LORDTEMPLER_HERO:
		{
			pUser->DoAddBuff2(SI_LOD_SUP_HOLYARMOR, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_KNT_MASTER_TWOHANDMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_KNT_SUP_GUARD, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_KNT_SUP_RAGE, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_KNT_SUP_PAINREFLECTION, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SHIELD_PANBARRIER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SHIELD_PROTECTION, 20, 10000, pUser);
		}
		break;
		case JOB_LORDTEMPLER_HERO_ULTIMATE:
		{
			pUser->DoAddBuff2(SI_LOD_SUP_HOLYARMOR, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_KNT_MASTER_TWOHANDMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_KNT_SUP_GUARD, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_KNT_SUP_RAGE, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_KNT_SUP_PAINREFLECTION, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SHIELD_PANBARRIER, 20, 10000, pUser);
			pUser->DoAddBuff2(SI_MER_SHIELD_PROTECTION, 20, 10000, pUser);
		}
		break;
		default: break;
		}

		switch (pUser->GetJob())
		{
		case JOB_JESTER:
		{
			pUser->DoAddBuff2(SI_JST_YOYO_CRITICALSWING, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_JST_SUP_ABSORB, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ACR_SUP_YOYOMASTER, 20, 10000, pUser);
		}
		break;
		case JOB_JESTER_MASTER:
		{
			pUser->DoAddBuff2(SI_JST_MASTER_YOYOMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_JST_YOYO_CRITICALSWING, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_JST_SUP_ABSORB, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ACR_SUP_YOYOMASTER, 20, 10000, pUser);
		}
		break;
		case JOB_WINDLURKER_HERO:
		{
			pUser->DoAddBuff2(SI_WIN_SUP_EVASIONINCREASE, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_WIN_SUP_CONTROLINCREASE, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_JST_MASTER_YOYOMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_JST_YOYO_CRITICALSWING, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_JST_SUP_ABSORB, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ACR_SUP_YOYOMASTER, 20, 10000, pUser);
		}
		break;
		case JOB_WINDLURKER_HERO_ULTIMATE:
		{
			pUser->DoAddBuff2(SI_WIN_SUP_EVASIONINCREASE, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_WIN_SUP_CONTROLINCREASE, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_JST_MASTER_YOYOMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_JST_YOYO_CRITICALSWING, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_JST_SUP_ABSORB, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_ACR_SUP_YOYOMASTER, 20, 10000, pUser);
		}
		break;
		default: break;
		}

		switch (pUser->GetJob())
		{
		case JOB_BILLPOSTER:
		{
			pUser->DoAddBuff2(SI_BIL_PST_ASMODEUS, 10, 10000, pUser);
		}
		break;
		case JOB_BILLPOSTER_MASTER:
		{
			pUser->DoAddBuff2(SI_BIL_MASTER_KNUCKLEMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_BIL_PST_ASMODEUS, 10, 10000, pUser);
		}
		break;
		case JOB_FORCEMASTER_HERO:
		{
			pUser->DoAddBuff2(SI_FOR_SQU_FORCETENACITY, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_FOR_SQU_FORCEANGER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_FOR_SQU_FORCESPEED, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_FOR_SQU_FORCEMAD, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_BIL_MASTER_KNUCKLEMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_BIL_PST_ASMODEUS, 10, 10000, pUser);
		}
		break;
		case JOB_FORCEMASTER_HERO_ULTIMATE:
		{
			pUser->DoAddBuff2(SI_FOR_SQU_FORCETENACITY, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_FOR_SQU_FORCEANGER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_FOR_SQU_FORCESPEED, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_FOR_SQU_FORCEMAD, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_BIL_MASTER_KNUCKLEMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_BIL_PST_ASMODEUS, 10, 10000, pUser);
		}
		break;
		default: break;
		}

		switch (pUser->GetJob())
		{
		case JOB_PSYCHIKEEPER:
		{
			pUser->DoAddBuff2(SI_PSY_NLG_CRUCIOSPELL, 10, 10000, pUser);
		}
		break;
		case JOB_PSYCHIKEEPER_MASTER:
		{
			pUser->DoAddBuff2(SI_PSY_MASTER_INTMASTER, 5, 10000, pUser);
			pUser->DoAddBuff2(SI_PSY_NLG_CRUCIOSPELL, 10, 10000, pUser);
		}
		break;
		case JOB_MENTALIST_HERO:
		{
			pUser->DoAddBuff2(SI_PSY_MASTER_INTMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_PSY_NLG_CRUCIOSPELL, 5, 10000, pUser);
		}
		break;
		case JOB_MENTALIST_HERO_ULTIMATE:
		{
			pUser->DoAddBuff2(SI_PSY_MASTER_INTMASTER, 10, 10000, pUser);
			pUser->DoAddBuff2(SI_PSY_NLG_CRUCIOSPELL, 5, 10000, pUser);
		}
		break;
		default: break;
		}
#endif // __BUFF_PANG_UPDATE

		if (lpChar)
		{
			if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_NPC_BUFF, pUser->GetWorld(), pUser->GetPos()))
				return;

			vector<NPC_BUFF_SKILL> vecNPCBuff = lpChar->m_vecNPCBuffSkill;
			for (int i = 0; i < (int)(vecNPCBuff.size()); i++)
			{
				if (pUser->GetLevel() >= vecNPCBuff[i].nMinPlayerLV && pUser->GetLevel() <= vecNPCBuff[i].nMaxPlayerLV)
				{
					ItemProp* pSkillProp = prj.GetSkillProp(vecNPCBuff[i].dwSkillID);
					if (pSkillProp)
					{
						if (vecNPCBuff[i].dwSkillLV < pSkillProp->dwExpertLV || vecNPCBuff[i].dwSkillLV > pSkillProp->dwExpertMax)
							continue;

						if ((pSkillProp->dwID == SI_GEN_EVE_QUICKSTEP && pUser->HasBuff(BUFF_SKILL, SI_ASS_CHEER_QUICKSTEP))
							|| (pSkillProp->dwID == SI_GEN_EVE_HASTE && pUser->HasBuff(BUFF_SKILL, SI_ASS_CHEER_HASTE))
							|| (pSkillProp->dwID == SI_GEN_EVE_HEAPUP && pUser->HasBuff(BUFF_SKILL, SI_ASS_CHEER_HEAPUP))
							|| (pSkillProp->dwID == SI_GEN_EVE_ACCURACY && pUser->HasBuff(BUFF_SKILL, SI_ASS_CHEER_ACCURACY)))
						{
							pUser->AddDefinedText(TID_GAME_NPCBUFF_FAILED, "\"%s\"", pSkillProp->szName);
							continue;
						}

						AddSkillProp* pAddSkillProp = prj.GetAddSkillProp(pSkillProp->dwSubDefine + vecNPCBuff[i].dwSkillLV - 1);
						if (pAddSkillProp)
						{
							// skill property¸¦ ¼öÁ¤ÇÏ±â ¶§¹®¿¡ ¹é¾÷ÇØµÎ¾ú´Ù°¡
							// ½ºÅ³ ½ÃÀüÈÄ restore½ÃÅ²´Ù.
							DWORD dwReferTarget1Backup = pSkillProp->dwReferTarget1;
							pSkillProp->dwReferTarget1 = NULL_ID;
							DWORD dwReferTarget2Backup = pSkillProp->dwReferTarget2;
							pSkillProp->dwReferTarget2 = NULL_ID;
							DWORD dwSkillTimeBackup = pAddSkillProp->dwSkillTime;
							pAddSkillProp->dwSkillTime = vecNPCBuff[i].dwSkillTime;

							pUser->DoApplySkill(pUser, pSkillProp, pAddSkillProp);
							g_UserMng.AddDoApplySkill(pUser, pUser->GetId(), vecNPCBuff[i].dwSkillID, vecNPCBuff[i].dwSkillLV);

							pSkillProp->dwReferTarget1 = dwReferTarget1Backup;
							pSkillProp->dwReferTarget2 = dwReferTarget2Backup;
							pAddSkillProp->dwSkillTime = dwSkillTimeBackup;
						}
					}
				}
				else
				{
					ItemProp* pSkillProp = prj.GetSkillProp(vecNPCBuff[i].dwSkillID);
					if (pSkillProp)
						pUser->AddDefinedText(TID_GAME_NPCBUFF_LEVELLIMIT, "%d %d \"%s\"", vecNPCBuff[i].nMinPlayerLV, vecNPCBuff[i].nMaxPlayerLV, pSkillProp->szName);
				}
			}
#ifdef __GAMEGUARD
			pUser->m_dwLastBuff = GetTickCount();
#endif // __GAMEGUARD
		}
	}
}
#endif // __NPC_BUFF

#ifdef __JEFF_11_4
void	CDPSrvr::OnArenaEnter(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_ARENA_ENTER, pUser->GetWorld(), pUser->GetPos()))
			return;

		if (pUser->IsBaseJob())
			return;

		pUser->SetMarkingPos();
		pUser->REPLACE(g_uIdofMulti, WI_WORLD_ARENA, D3DXVECTOR3(540.0F, 140.0F, 485.0F), REPLACE_NORMAL, nDefaultLayer);
	}
}

void	CDPSrvr::OnArenaExit( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
		pUser->REPLACE( g_uIdofMulti, pUser->m_idMarkingWorld, pUser->m_vMarkingPos, REPLACE_NORMAL, nTempLayer );
}
#endif	// __JEFF_11_4

#ifdef __JEFF_11
// ÆêÀ» Á¶°¢À¸·Î ±³È¯
void	CDPSrvr::OnQuePetResurrection( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		int nItem;
		ar >> nItem;
		CItemElem*	pItem	= (CItemElem*)pUser->GetItemId( nItem );
		if( !IsUsableItem( pItem ) )
			return;

		CPet* pPet	= pItem->m_pPet;
		if( !pPet || pUser->GetPetId() == pItem->m_dwObjId || pItem->IsFlag( CItemElem::expired ) )
		{
			pUser->AddQuePetResurrectionResult( FALSE );
			return;
		}

		BYTE nLevel		= pPet->GetLevel();
		if( nLevel < PL_B || nLevel > PL_S )
		{
			pUser->AddQuePetResurrectionResult( FALSE );
			return;
		}

		CItemElem itemElem;
		itemElem.m_nItemNum	= 1;
		switch( nLevel )
		{
			case PL_B:	itemElem.m_dwItemId		= II_SYS_SYS_QUE_PETRESURRECTION01_B;	break;
			case PL_A:	itemElem.m_dwItemId		= II_SYS_SYS_QUE_PETRESURRECTION01_A;	break;
			case PL_S:	itemElem.m_dwItemId		= II_SYS_SYS_QUE_PETRESURRECTION01_S;	break;
		}
		// log
		LogItemInfo	log;
		log.Action	= "x";
		log.SendName	= pUser->GetName();
		log.RecvName	= "OnQuePetResurrection";
		OnLogItem( log, pItem, 1 );

		pUser->RemoveItem( nItem, 1 );
		pUser->CreateItem( &itemElem );
		pUser->AddQuePetResurrectionResult( TRUE );
	}
}
#endif	// __JEFF_11

#if __VER >= 12 // __SECRET_ROOM
void	CDPSrvr::OnSecretRoomTenderOpenWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );

	if( IsValidObj( pUser ) == FALSE )
		return;

	CSecretRoomMng::GetInstance()->SetTenderOpenWnd( pUser );
}

void	CDPSrvr::OnSecretRoomTender( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	int nPenya;
	ar >> nPenya;

	if( nPenya <= 0 )
		return;

	CSecretRoomMng::GetInstance()->SetTender( pUser, nPenya );
}

void	CDPSrvr::OnSecretRoomTenderCancelReturn( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );

	if( IsValidObj( pUser ) == FALSE )
		return;

	CSecretRoomMng::GetInstance()->SetTenderCancelReturn( pUser );
}

void	CDPSrvr::OnSecretRoomLineUpOpenWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );

	if( IsValidObj( pUser ) == FALSE )
		return;

	CSecretRoomMng::GetInstance()->SetLineUpOpenWnd( pUser );
}

void	CDPSrvr::OnSecretRoomLineUpMember( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	
	if( IsValidObj( pUser ) == FALSE )
		return;

	set<DWORD> checker;
	vector<DWORD> vecLineUpMember;
	int nSize;
	ar >> nSize;

	if( nSize > CSecretRoomMng::GetInstance()->m_nMaxGuildMemberNum || nSize <= 0 )
		return;

	for( int i=0; i<nSize; i++ )
	{
		DWORD dwIdPlayer;
		ar >> dwIdPlayer;

		// À¯È¿ÇÑ Player ID ÀÎ°¡?
		PlayerData* pData	= CPlayerDataCenter::GetInstance()->GetPlayerData( dwIdPlayer );
		if( !pData )
			return;

		// ID Áßº¹Ã¼Å©		
		if( !checker.insert( dwIdPlayer ).second )
			return;

		vecLineUpMember.push_back( dwIdPlayer );
	}

	CSecretRoomMng::GetInstance()->SetLineUp( pUser, vecLineUpMember );
}

void	CDPSrvr::OnSecretRoomEntrance( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );

	if( IsValidObj( pUser ) == FALSE )
		return;

	CSecretRoomMng::GetInstance()->SetTeleportSecretRoom( pUser );
}

void	CDPSrvr::OnSecretRoomTeleportToNPC( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );

	if( IsValidObj( pUser ) == FALSE )
		return;
	pUser->REPLACE( g_uIdofMulti, WI_WORLD_MADRIGAL, CSecretRoomMng::GetInstance()->GetRevivalPos( pUser ), REPLACE_NORMAL, nDefaultLayer );
}

void CDPSrvr::OnSecretRoomTenderView( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );

	if( IsValidObj( pUser ) == FALSE )
		return;

	CSecretRoomMng::GetInstance()->GetTenderView( pUser );
}

void CDPSrvr::OnTeleportSecretRoomDungeon( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );

	if( IsValidObj( pUser ) == FALSE )
		return;
#if __VER >= 12 // __TAX
	if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_SECRET_ENTRANCE_1, pUser->GetWorld(), pUser->GetPos() ) )
		return;

	__TAXINFO* pTaxInfo = CTax::GetInstance()->GetTaxInfo( CTax::GetInstance()->GetContinent( pUser ) );
	if( pTaxInfo && pUser->GetGuild() && (pTaxInfo->dwId == pUser->GetGuild()->GetGuildId()) )
	{
		pUser->SetMarkingPos();
		pUser->SetAngle( 180.0f );
		int nRandx = xRandom(4) - 2;
		int nRandz = xRandom(4) - 2;
		pUser->REPLACE( g_uIdofMulti, WI_DUNGEON_SECRET_0, D3DXVECTOR3( (float)( 295 + nRandx ), 102.0f, (float)( 530 + nRandz ) ), REPLACE_NORMAL, nDefaultLayer );
	}
	else
		pUser->AddDefinedText( TID_GAME_SECRETROOM_NOENTRANCE_1 );
#endif // __TAX
}
#endif // __SECRET_ROOM

#if __VER >= 12 // __LORD
void CDPSrvr::OnElectionAddDeposit( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		__int64 iTotal;
		ar >> iTotal;

		__int64 iDeposit;
		int nRet	= election::AddDepositRequirements( pUser, iTotal, iDeposit );
		if( nRet )
		{
			pUser->AddDefinedText( nRet );
			return;
		}
		pUser->AddGold( -static_cast<int>( iDeposit ) );
		g_dpDBClient.SendElectionAddDeposit( pUser->m_idPlayer, iDeposit );

		PutPenyaLog( pUser, "d", "DEPOSIT", static_cast<int>( iDeposit ) );
	}
}

void CDPSrvr::PutItemLog( CUser* pUser, const char* szAction, const char* szContext, CItemElem* pItem, int nNum )
{	// ¾ÆÀÌÅÛÀÌ Á¦°ÅµÈ ÀÌÈÄ¿¡ È£ÃâµÇÁö ¾Êµµ·Ï ÁÖÀÇÇØ¾ß ÇÔ
	LogItemInfo	log;
	log.Action	=  szAction;
	log.SendName	= pUser->GetName();
	log.RecvName	= szContext;
	log.WorldId		= pUser->GetWorld() ? pUser->GetWorld()->GetID() : WI_WORLD_NONE;	// chipi_090623 ¼öÁ¤ - Ã¹ Á¢¼Ó½Ã ¸¸·áµÈ ¹öÇÁÀÎ °æ¿ì ¿ùµå°¡ ¾ø´Â »óÅÂ·Î µé¾î¿Â´Ù. 
	log.Gold	= pUser->GetGold();
	log.Gold2	= pUser->GetGold();
	if( nNum == 0 )
		nNum	= pItem->m_nItemNum;
	OnLogItem( log, pItem, nNum );
}

void CDPSrvr::PutPenyaLog( CUser* pUser, const char* szAction, const char* szContext,  int nCost )
{	// ¸ðµç °á°ú Ã³¸® ÈÄ È£ÃâµÇ¾î¾ß ÇÔ
	LogItemInfo	log;
	log.Action	= szAction;
	log.SendName	= pUser->GetName();
	log.RecvName	= szContext;
	log.WorldId		= pUser->GetWorld() ? pUser->GetWorld()->GetID() : WI_WORLD_NONE;	// chipi_090623 ¼öÁ¤ - Ã¹ Á¢¼Ó½Ã ¸¸·áµÈ ¹öÇÁÀÎ °æ¿ì ¿ùµå°¡ ¾ø´Â »óÅÂ·Î µé¾î¿Â´Ù. 
	//log.ItemName	= "SEED";
	_stprintf( log.szItemName, "%d", II_GOLD_SEED1 );
	log.Gold	= pUser->GetGold() + nCost;
	log.Gold2	= pUser->GetGold();
	log.Gold_1	= -nCost;
	OnLogItem( log );
}

void CDPSrvr::OnElectionSetPledge( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	char szPledge[CCandidate::nMaxPledgeLen]	= { 0,};
	ar.ReadString( szPledge, CCandidate::nMaxPledgeLen );
	if( strlen( szPledge ) == 0 )
		return;

	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		int nCost;
		int nRet	= election::SetPledgeRequirements( pUser, nCost );
		if( nRet )
		{
			pUser->AddDefinedText( nRet );
			return;
		}
		pUser->AddGold( -nCost );
		g_dpDBClient.SendElectionSetPledge( pUser->m_idPlayer, szPledge );

		PutPenyaLog( pUser, "p", "PLEDGE", nCost );
	}
}

void CDPSrvr::OnElectionIncVote( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		u_long idPlayer;
		ar >> idPlayer;

		int nRet	= election::IncVoteRequirements( pUser, idPlayer );
		if( nRet )
		{
			pUser->AddDefinedText( nRet );
			return;
		}
		g_dpDBClient.SendElectionIncVote( idPlayer, pUser->m_idPlayer );
	}
}

void CDPSrvr::OnLEventCreate( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		int iEEvent, iIEvent;
		ar >> iEEvent >> iIEvent;
		int nRet	= lordevent::CreateRequirements( pUser, iEEvent, iIEvent );
		if( nRet )
		{
			pUser->AddDefinedText( nRet );
			return;
		}
		ILordEvent* pEvent		= CSLord::Instance()->GetEvent();

		int nPerin	= pUser->RemoveTotalGold( pEvent->GetCost( iEEvent, iIEvent ) );
		char szContext[100]		= { 0,};
		sprintf( szContext, "OnLEventCreate: cost: %d(perin), %I64d(penya)", nPerin, pEvent->GetCost( iEEvent, iIEvent ) - ( nPerin * PERIN_VALUE ) );
		PutPenyaLog( pUser, "e", szContext, 0 );

		g_dpDBClient.SendLEventCreate( pUser->m_idPlayer, iEEvent, iIEvent );
	}
}

void CDPSrvr::OnLordSkillUse( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		int nSkill;
		char szTarget[MAX_PLAYER]	= { 0,};
		ar >> nSkill;
		ar.ReadString( szTarget, MAX_PLAYER );
		u_long idTarget;
		int nRet	= lordskill::UseRequirements( pUser, szTarget, nSkill, idTarget );
		if( nRet )
		{
			pUser->AddDefinedText( nRet );
			return;
		}
		g_dpDBClient.SendLordSkillUse( pUser->m_idPlayer, idTarget, nSkill );
	}
}
#endif	// __LORD

#if __VER >= 12 // __TAX
void CDPSrvr::OnSetTaxRate( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	BYTE nCont;
	int nSalesTaxRate, nPurchaseTaxRate;
	ar >> nCont;
	ar >> nSalesTaxRate >> nPurchaseTaxRate;

	__TAXINFO* pTaxInfo = CTax::GetInstance()->GetTaxInfo( nCont );
	if( pTaxInfo && pUser->m_idGuild == pTaxInfo->dwNextId && pUser->IsGuildMaster() )
		CTax::GetInstance()->SetNextTaxRate( nCont, nSalesTaxRate, nPurchaseTaxRate );
	else
		Error( "\"%\"s User Is Not Next Win Guild Master!!!", pUser->GetName() );
}
#endif // __TAX

#if __VER >= 12 // __HEAVEN_TOWER
void CDPSrvr::OnTeleportToHeavenTower( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_HEAVEN_TOWER, pUser->GetWorld(), pUser->GetPos() ) )
		return;
    	
	int nFloor;
	ar >> nFloor;

	int nCost = 0;
	DWORD dwWorldId = NULL_ID;
	float fAngle = 0.0f;
	D3DXVECTOR3 vPos;

	switch( nFloor )
	{
		case 1 :	// 1Ãþ
			nCost = 10000;	dwWorldId = WI_WORLD_HEAVEN01; vPos = D3DXVECTOR3( 253, 102, 78 ); fAngle = 183.0f;
			break;
		case 2 :	// 2Ãþ
			nCost = 30000;	dwWorldId = WI_WORLD_HEAVEN02; vPos = D3DXVECTOR3( 251, 102, 95 ); fAngle = 183.0f;
			break;
		case 3 :	// 3Ãþ
			nCost = 50000;	dwWorldId = WI_WORLD_HEAVEN03; vPos = D3DXVECTOR3( 264, 102, 227 ); fAngle = 183.0f;
			break;
		case 4 :	// 4Ãþ
			nCost = 70000;	dwWorldId = WI_WORLD_HEAVEN04; vPos = D3DXVECTOR3( 253, 102, 86 ); fAngle = 174.0f;
			break;
		case 5 :	// 5Ãþ
			nCost = 100000;	dwWorldId = WI_WORLD_HEAVEN05; vPos = D3DXVECTOR3( 218, 102, 101); fAngle = 176.0f;
			break;

		default :
			Error( "CDPSrvr::OnTeleportToHeavenTower() - Àß¸øµÈ Ãþ : %d, Name = %s", nFloor, pUser->GetName() );
			return;
	}

	if( pUser->GetGold() < nCost )
	{
		pUser->AddDefinedText( TID_GAME_LACKMONEY );
		return;
	}

#if __VER >= 12 // __TAX
	BYTE nCont = CTax::GetInstance()->GetContinent( pUser );
#endif // __TAX	
	// ÇØ´ç ÃþÀ¸·Î ÅÚ·¹Æ÷Æ® -> ½ÇÆÐ½Ã ±×³É ¸®ÅÏ...
	if( pUser->REPLACE( g_uIdofMulti, dwWorldId, vPos, REPLACE_NORMAL, nDefaultLayer ) )
	{
		pUser->AddGold( -nCost );
		pUser->SetAngle( fAngle );
#if __VER >= 12 // __TAX
		__TAXINFO* pTaxInfo = CTax::GetInstance()->GetTaxInfo( nCont );
		if( pTaxInfo && pTaxInfo->dwId != NULL_ID )
			CTax::GetInstance()->AddTax( nCont, nCost, TAX_ADMISSION );
#endif // __TAX		
		CString strFloor;
		strFloor.Format( "HEAVEN_TOWER_%2d", nFloor );
		PutPenyaLog( pUser, "h", strFloor, nCost );
	}
	else
		return;
}
#endif // __HEAVEN_TOWER

BOOL CDPSrvr::DoUseItemTarget_GenRandomOption(
											  CUser* pUser, CItemElem* pTarget, int nKind,
											  int nOk, int nMismatchKind, int nHasOption,
											  const char* szOperation, const char* szReceive )
{
	int nRandomOptionKind	= g_xRandomOptionProperty->GetRandomOptionKind( pTarget );
	if( nRandomOptionKind != nKind || pTarget->IsFlag( CItemElem::expired ) )
	{
		pUser->AddDefinedText( nMismatchKind );
		return FALSE;
	}

	if( 
#if __VER >= 12 // __J12_0
		// ¿©½ÅÀÇ Ãàº¹°ú ¸ÔÆê °¢¼ºÀº °¢¼º Ãë¼Ò ¾øÀÌ µ¤¾î ¾µ ¼ö ÀÖ°Ô ÇÑ´Ù
		nKind != CRandomOptionProperty::eBlessing && nKind != CRandomOptionProperty::eEatPet &&
#endif	// __J12_0
		g_xRandomOptionProperty->GetRandomOptionSize( pTarget->GetRandomOptItemId() ) > 0
	)
	{
		pUser->AddDefinedText( nHasOption );
		return FALSE;
	}

	if( nOk > 0 )
		pUser->AddDefinedText( nOk );

	// È°¼ºÈ­ µÈ ÇÈ¾÷ÆêÀÌ¸é  ±âÁ¸ È¿°ú¸¦ Á¦°Å	// Ë¬: 2008-09-29 Ãß°¡
	if( pUser->IsUsing( pTarget ) && nKind == CRandomOptionProperty::eEatPet )
		pUser->ResetDestParamRandomOptExtension( pTarget );


	//	mulcom	BEGIN100405	°¢¼º º¸È£ÀÇ µÎ·ç¸¶¸®
	//g_xRandomOptionProperty->InitializeRandomOption( pTarget->GetRandomOptItemIdPtr() );
	//g_xRandomOptionProperty->GenRandomOption( pTarget->GetRandomOptItemIdPtr(), nRandomOptionKind, pTarget->GetProp()->dwParts );
	bool	bCheckedSafeFlag	= false;
	bCheckedSafeFlag	= g_xRandomOptionProperty->IsCheckedSafeFlag( pTarget->GetRandomOptItemId() );

	if( bCheckedSafeFlag == true )
	{
		g_xRandomOptionProperty->ResetSafeFlag( pTarget->GetRandomOptItemIdPtr() );

		g_xRandomOptionProperty->InitializeRandomOption( pTarget->GetNewRandomOptionPtr() );
		g_xRandomOptionProperty->GenRandomOption( pTarget->GetNewRandomOptionPtr(), nRandomOptionKind, pTarget->GetProp()->dwParts, true );

		//	mulcom	BEGIN100426	°¢¼º º¸È£ÀÇ µÎ·ç¸¶¸® ·Î±×.
// 		WriteLog( "UserID [%d] : ItemSerialNumber[%d] Protect GenNewRandomOption [%I64d]", (int)( pUser->GetId() ), (int)( pTarget->GetSerialNumber() ), pTarget->GetNewRandomOption() );
 
		TCHAR	szNewOption[128];
		::memset( szNewOption, 0, sizeof(szNewOption) );
		::_stprintf( szNewOption, "%I64d", pTarget->GetNewRandomOption() );
		g_DPSrvr.PutItemLog( pUser, "z", szNewOption, pTarget, 1 );
		//	mulcom	END100426	°¢¼º º¸È£ÀÇ µÎ·ç¸¶¸® ·Î±×.

		pUser->SendNewRandomOption( (BYTE)( pTarget->m_dwObjId ), (DWORD)( pTarget->GetSerialNumber() ), pTarget->GetNewRandomOption() );

	}
	else
	{
		g_xRandomOptionProperty->InitializeRandomOption( pTarget->GetRandomOptItemIdPtr() );
		g_xRandomOptionProperty->GenRandomOption( pTarget->GetRandomOptItemIdPtr(), nRandomOptionKind, pTarget->GetProp()->dwParts );
	}
	//	mulcom	END100405	°¢¼º º¸È£ÀÇ µÎ·ç¸¶¸®

	pUser->UpdateItemEx( (BYTE)( pTarget->m_dwObjId ), UI_RANDOMOPTITEMID, pTarget->GetRandomOptItemId() );

#if __VER >= 12 // __PET_0519
	// È°¼ºÈ­ µÈ ÇÈ¾÷Æê ¶Ç´Â ¸®¾îÆê °¢¼º Á÷ ÈÄ È¿°ú Àû¿ë
	if( pUser->IsUsing( pTarget ) 
		&& ( nKind == CRandomOptionProperty::eSystemPet || nKind == CRandomOptionProperty::eEatPet ) )
		pUser->SetDestParamRandomOptExtension( pTarget );
#endif	// __PET_0519

#ifdef __RECORD_BOOK
	CRecordBook::GetInstance()->AddPlayerRecord(pUser, RecordType::AWAKES_COUNT, 1, true);
#endif

	// log
	LogItemInfo	log;
	log.Action	= szOperation;
	log.SendName	= pUser->GetName();
	log.RecvName	= szReceive;
	log.WorldId		= pUser->GetWorld()->GetID();
	log.Gold	= pUser->GetGold();
	log.Gold2	= pUser->GetGold();
	OnLogItem( log, pTarget, 1 );
	return TRUE;
}

BOOL CDPSrvr::DoUseItemTarget_InitializeRandomOption(
											  CUser* pUser, CItemElem* pTarget, int nKind,
											  int nOk, int nError,
											  const char* szOperation, const char* szRecv )
{
	int nRandomOptionKind	= g_xRandomOptionProperty->GetRandomOptionKind( pTarget );
	if( nRandomOptionKind == nKind && g_xRandomOptionProperty->GetRandomOptionSize( pTarget->GetRandomOptItemId() ) > 0 )
	{
#if __VER >= 12 // __PET_0519
		// ¸ÔÆê ¶Ç´Â ½Ã½ºÅÛ Æê °¢¼º Ãë¼Ò ÈÄ È¿°ú Á¦°Å
		if( pUser->IsUsing( pTarget ) 
			&& ( nKind == CRandomOptionProperty::eSystemPet || nKind == CRandomOptionProperty::eEatPet ) )
			pUser->ResetDestParamRandomOptExtension( pTarget );
#endif	// __PET_0519

		//	mulcom	BEGIN100405	°¢¼º º¸È£ÀÇ µÎ·ç¸¶¸®
		//g_xRandomOptionProperty->InitializeRandomOption( pTarget->GetRandomOptItemIdPtr() );
#ifdef __PROTECT_AWAKE
		if( pUser->HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AWAKESAFE ) == TRUE && nKind == CRandomOptionProperty::eAwakening )
		{
			nOk = TID_GAME_REGARDLESS_USE04;
			g_xRandomOptionProperty->SetSafeFlag( pTarget->GetRandomOptItemIdPtr() );

			pUser->RemoveBuff( BUFF_ITEM, II_SYS_SYS_SCR_AWAKESAFE );

			//	mulcom	BEGIN100426	°¢¼º º¸È£ÀÇ µÎ·ç¸¶¸® ·Î±×.
			g_DPSrvr.PutItemLog( pUser, "z", "USE_AWAKESAVE_ITEM", pTarget, 1 );
			//	mulcom	END100426	°¢¼º º¸È£ÀÇ µÎ·ç¸¶¸® ·Î±×.

		}
		else
		{
			g_xRandomOptionProperty->InitializeRandomOption( pTarget->GetRandomOptItemIdPtr() );
		}
#else	//__PROTECT_AWAKE
		g_xRandomOptionProperty->InitializeRandomOption( pTarget->GetRandomOptItemIdPtr() );
#endif	//__PROTECT_AWAKE
		//	mulcom	END100405	°¢¼º º¸È£ÀÇ µÎ·ç¸¶¸®

		pUser->UpdateItemEx((BYTE)(pTarget->m_dwObjId), UI_RANDOMOPTITEMID, pTarget->GetRandomOptItemId());
		pUser->AddDefinedText(TID_GAME_AWAKECANCEL_INFO);

		// log
		LogItemInfo	log;
		log.Action	= szOperation;
		log.SendName	= pUser->GetName();
		log.RecvName	= szRecv;
		log.WorldId		= pUser->GetWorld()->GetID();
		log.Gold	= pUser->GetGold();
		log.Gold2	= pUser->GetGold();
		OnLogItem( log, pTarget, 1 );
		return TRUE;
	}
	pUser->AddDefinedText( nError );	
	return FALSE;
}

BOOL CDPSrvr::DoUseItemTarget_ItemLevelDown( CUser* pUser, CItemElem* pMaterial, CItemElem* pTarget )
{
	ItemProp* pProp		= pTarget->GetProp();
	if( pProp->dwParts == NULL_ID || pProp->dwLimitLevel1 == 0xFFFFFFFF )
	{
		pUser->AddDefinedText( TID_GAME_INVALID_TARGET_ITEM );
		return FALSE;
	}

	int nLevelDown	= pTarget->GetLevelDown();
	if( nLevelDown == 0 || ( nLevelDown == -5 && pMaterial->m_dwItemId == II_SYS_SYS_SCR_LEVELDOWN02 ) )
	{
		pTarget->SetLevelDown( pMaterial->m_dwItemId == II_SYS_SYS_SCR_LEVELDOWN01? CItemElem::e5LevelDown: CItemElem::e10LevelDown );
		pUser->UpdateItemEx( (BYTE)( pTarget->m_dwObjId ), UI_RANDOMOPTITEMID, pTarget->GetRandomOptItemId() );
		// log
		LogItemInfo	log;
		log.Action	= "r";
		log.SendName	= pUser->GetName();
		log.RecvName	= "::ItemLevelDown";
		log.WorldId		= pUser->GetWorld()->GetID();
		log.Gold	= pUser->GetGold();
		log.Gold2	= pUser->GetGold();
		OnLogItem( log, pTarget, 1 );
		return TRUE;
	}
	else
		pUser->AddDefinedText( TID_GAME_ITEM_LEVELDOWN01 );

	return FALSE;
}

#if __VER >= 12 // __PET_0519
void CDPSrvr::OnTransformItem( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{	// ¾Ëº¯È¯
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	CTransformStuff stuff;
	stuff.Serialize( ar );	// Àç·á¸¦ ¼ö½Å

	// º¯È¯ ¹øÈ£·ÎºÎÅÍ º¯È¯ ÇÔ¼ö¸¦ °áÁ¤ÇÑ´Ù.
	ITransformer* pTransformer	= ITransformer::Transformer( stuff.GetTransform() );
	pTransformer->Transform( pUser, stuff );	// º¯È¯
}
#endif	// __PET_0519

#if __VER >= 12 // __MOD_TUTORIAL
void CDPSrvr::OnTutorialState( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	int nState;
	char szState[64]	= { 0,};
	char szOut[64]	= { 0,};
	ar >> nState;
	ar.ReadString( szState, 64 );
	MakeTutorialStateString( szOut, nState, pUser->GetName() );
	if( lstrcmp( szOut, szState ) == 0 )
	{
		pUser->SetTutorialState( nState );
		pUser->AddSetTutorialState();
	}
}
#endif	// __MOD_TUTORIAL

#if __VER >= 12 // __PET_0519
// ÇÈ¾÷Æê °¢¼º Ãë¼Ò ¸Þ´º ¼±ÅÃ ÇÚµé·¯
void CDPSrvr::OnPickupPetAwakeningCancel( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;
	if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_PET_AWAK_CANCEL, pUser->GetWorld(), pUser->GetPos() ) )
		return;

	DWORD dwItem;
	ar >> dwItem;
	CItemElem* pItem	= (CItemElem*)pUser->GetItemId( dwItem );
	if( !IsUsableItem( pItem ) )
		return;

	if( DoUseItemTarget_InitializeRandomOption( pUser, pItem, CRandomOptionProperty::eEatPet,
					TID_GAME_PICKUP_PET_AWAKENING_CANCEL_S001, TID_GAME_PICKUP_PET_AWAKENING_CANCEL_E001,
					"k", "PPAC" ) )
	{
		pUser->AddPlaySound( SND_INF_UPGRADESUCCESS );
		if( pUser->IsMode( TRANSPARENT_MODE ) == 0 )
			g_UserMng.AddCreateSfxObj( pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z );
	}
}
#endif	// __PET_0519

#ifdef __AZRIA_1023
void CDPSrvr::OnDoUseItemInput( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	DWORD dwData;
	ar >> dwData;
	char szInput[MAX_INPUT_LEN]		= { 0,};
	ar.ReadString( szInput, MAX_INPUT_LEN );
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;
	pUser->SetInput( szInput );
	pUser->OnDoUseItem( dwData, 0, -1 );
	pUser->ResetInput();
}
#endif	// __AZRIA_1023

#ifdef __PET_1024
void CDPSrvr::OnClearPetName( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		CPet* pPet	= pUser->GetPet();
		if( !pPet )
		{
			pUser->AddDefinedText( TID_GAME_NAME_PET_E00 );
			return;
		}
		pPet->SetName( "" );
		g_UserMng.AddSetPetName( pUser, pPet->GetName() );
	}
}
#endif	// __PET_1024

#if __VER >= 13 // __RAINBOW_RACE
void CDPSrvr::OnRainbowRacePrevRankingOpenWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	pUser->AddRainbowRacePrevRankingOpenWnd();
}

void CDPSrvr::OnRainbowRaceApplicationOpenWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	pUser->AddRainbowRaceApplicationOpenWnd();
}
void CDPSrvr::OnRainbowRaceApplication( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;
	
	CRainbowRaceMng::GetInstance()->SetApplicationUser( pUser );
}
void CDPSrvr::OnRainbowRaceMiniGamePacket( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;
	
	BOOL bExt;
	ar >> bExt;

	__MINIGAME_PACKET* pMiniGamePacket;
	if( bExt )	pMiniGamePacket = new __MINIGAME_EXT_PACKET;
	else		pMiniGamePacket = new __MINIGAME_PACKET;

	pMiniGamePacket->Serialize( ar );
	CRainbowRaceMng::GetInstance()->OnMiniGamePacket( pUser, pMiniGamePacket );
	SAFE_DELETE( pMiniGamePacket );
}

void CDPSrvr::OnRainbowRaceReqFinish( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	CRainbowRaceMng::GetInstance()->SetRanking( pUser );
}
#endif // __RAINBOW_RACE

#if __VER >= 13 // __HOUSING
void CDPSrvr::OnHousingSetupFurniture( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	HOUSINGINFO housingInfo;
	housingInfo.Serialize( ar );

	// ÇÃ·¹ÀÌ¾î°¡ ¹æ¿¡ ÀÖ¾î¾ß ÇÏ°í ÀÚ½ÅÀÇ ·¹ÀÌ¾î¿¡ µé¾î°¡ ÀÖ´Â °æ¿ì¸¸ °¡´É...
	CHousingMng::GetInstance()->ReqSetupFurniture( pUser, housingInfo );
}

void CDPSrvr::OnHousingSetVisitAllow( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	DWORD dwPlayerId;
	BOOL  bAllow;

	ar >> dwPlayerId >> bAllow;

	CHousingMng::GetInstance()->ReqSetAllowVisit( pUser, dwPlayerId, bAllow );
}

void CDPSrvr::OnHousingVisitRoom( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	DWORD dwPlayerId;
	ar >> dwPlayerId;

	CHousingMng::GetInstance()->SetVisitRoom( pUser, dwPlayerId );
}

void CDPSrvr::OnHousingVisitableList( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	CHousingMng::GetInstance()->OnReqVisitableList( pUser );
}

void CDPSrvr::OnHousingGoOut( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	CHousingMng::GetInstance()->GoOut( pUser );
}
#endif // __HOUSING

#if __VER >= 13 // __QUEST_HELPER
void CDPSrvr::OnReqQuestNPCPos( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

#ifdef __KIA_GOALDATA_FIX
	unsigned long questId;
	ar >> questId;

	QuestProp* qProp = prj.m_aPropQuest.GetAt(questId);
	if (qProp && qProp->m_szEndCondCharacter[0])
	{
		const LPCHARACTER lpChar = prj.GetCharacter(qProp->m_szEndCondCharacter);
		if (lpChar)
			pUser->AddNPCPos(lpChar->m_vPos, questId, lpChar->m_dwWorldId);
	}

#else
	char szCharKey[64] = { 0, };
	ar.ReadString(szCharKey, 64);

	const LPCHARACTER lpChar = prj.GetCharacter(szCharKey);
	if (lpChar)
	{
		if (pUser->GetWorld() && pUser->GetWorld()->GetID() == lpChar->m_dwWorldId)
			pUser->AddNPCPos(lpChar->m_vPos);
		else
			pUser->AddDefinedText(TID_GAME_QUESTINFO_FAIL);
	}
#endif
}
#endif // __QUEST_HELPER

#if __VER >= 13 // __COUPLE_1117
void CDPSrvr::OnPropose( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
	{
		char szPlayer[MAX_PLAYER]	= { 0,};
		ar.ReadString( szPlayer, MAX_PLAYER );
		CCoupleHelper::Instance()->OnPropose( pUser, szPlayer );
	}
}

void CDPSrvr::OnRefuse( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
		CCoupleHelper::Instance()->OnRefuse( pUser );
}

void CDPSrvr::OnCouple( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
		CCoupleHelper::Instance()->OnCouple( pUser );
}

void CDPSrvr::OnDecouple( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
		CCoupleHelper::Instance()->OnDecouple( pUser );
}
#endif	// __COUPLE_1117

#ifdef __MAP_SECURITY
void CDPSrvr::OnMapKey( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
	{
		char szFileName[33] = {0,}, szMapKey[33] = {0,};
		ar.ReadString( szFileName, 33 );
		ar.ReadString( szMapKey, 33 );
		g_WorldMng.CheckMapKey( pUser, szFileName, szMapKey );
	}
}
#endif // __MAP_SECURITY

#ifdef __QUIZ
void CDPSrvr::OnQuizEventEntrance( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );

	if( !IsValidObj( pUser ) )
		return;

	int nResult;
	nResult = CQuiz::GetInstance()->EntranceQuizEvent( pUser );
	if( nResult > 0 )
		pUser->AddDefinedText( nResult );
}
void CDPSrvr::OnQuizEventTeleport( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );

	if( !IsValidObj( pUser ) )
		return;

	int nZone;
	ar >> nZone;

	int nResult;
	nResult = CQuiz::GetInstance()->TeleportToQuizEvent( pUser, nZone );
	if( nResult > 0 )
		pUser->AddDefinedText( nResult );
}
#endif // __QUIZ

#if __VER >= 15 // __PETVIS
void CDPSrvr::OnRemoveVis( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	int nPos;
	ar >> nPos;

	CItemUpgrade::GetInstance()->RemovePetVisItem( pUser, nPos );
}

void CDPSrvr::OnSwapVis( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	int nPos1, nPos2;
	ar >> nPos1 >> nPos2;

	CItemUpgrade::GetInstance()->SwapVis( pUser, nPos1, nPos2 );
}
#endif // __PETVIS

#if __VER >= 15 // __GUILD_HOUSE
void CDPSrvr::OnBuyGuildHouse( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	GuildHouseMng->ReqBuyGuildHouse( pUser );
}

void CDPSrvr::OnGuildHousePacket( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	int nPacketType, nIndex;
	GH_Fntr_Info gfi;

	ar >> nPacketType >> nIndex;
	gfi.Serialize( ar );

	if( nPacketType == GUILDHOUSE_PCKTTYPE_LISTUP )
		return;

	GuildHouseMng->SendWorldToDatabase( pUser, nPacketType, gfi, nIndex );
}

void CDPSrvr::OnGuildHouseEnter( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	GuildHouseMng->EnteranceGuildHouse( pUser );
}

void CDPSrvr::OnGuildHouseGoOut( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( !IsValidObj( pUser ) )
		return;

	GuildHouseMng->GoOutGuildHouse( pUser );
}
#endif // __GUILD_HOUSE

#if __VER >= 15 // __TELEPORTER
void CDPSrvr::OnTeleporterReq( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	=	g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) ) 
	{
		CHAR	m_szKey[64];
		int		nIndex;
		ar.ReadString(m_szKey, 64);
		ar >> nIndex;
		
		LPCHARACTER lpChar = prj.GetCharacter( m_szKey );
		if( lpChar )
		{
			if( !CNpcChecker::GetInstance()->IsCloseNpc( MMI_TELEPORTER, pUser->GetWorld(), pUser->GetPos() ) )
				return;

			if( (int)( lpChar->m_vecTeleportPos.size() ) <= nIndex )
				return;

			pUser->REPLACE( g_uIdofMulti, WI_WORLD_MADRIGAL, lpChar->m_vecTeleportPos[nIndex], REPLACE_NORMAL, nDefaultLayer );
		}
	}
}
#endif // __TELEPORTER

#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
void CDPSrvr::OnCheckedQuest( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		int nQuestid;
		BOOL bCheck;
		ar >> nQuestid >> bCheck;
		if( bCheck )
		{
			if( pUser->m_nCheckedQuestSize >= MAX_CHECKED_QUEST )
				return;

			for( int i = 0; i < pUser->m_nCheckedQuestSize; ++i )
			{
				if( pUser->m_aCheckedQuest[ i ] == nQuestid )
				{
					for( int j = i; j < pUser->m_nCheckedQuestSize -1; ++j )
						pUser->m_aCheckedQuest[ j ] = pUser->m_aCheckedQuest[ j+1 ];
					pUser->m_aCheckedQuest[ --pUser->m_nCheckedQuestSize ] = 0;
					break;
				}
			}
			pUser->m_aCheckedQuest[ pUser->m_nCheckedQuestSize++ ] = nQuestid;
		}
		else
		{
			if( pUser->m_nCheckedQuestSize <= 0 )
				return;

			for( int i = 0; i < pUser->m_nCheckedQuestSize; ++i )
			{
				if( pUser->m_aCheckedQuest[ i ] == nQuestid )
				{
					for( int j = i; j < pUser->m_nCheckedQuestSize -1; ++j )
						pUser->m_aCheckedQuest[ j ] = pUser->m_aCheckedQuest[ j+1 ];
					pUser->m_aCheckedQuest[ --pUser->m_nCheckedQuestSize ] = 0;
					break;
				}
			}
		}
		pUser->AddCheckedQuest();
	}
}
#endif // __IMPROVE_QUEST_INTERFACE

#if __VER >= 15 // __CAMPUS
void CDPSrvr::OnInviteCampusMember( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pRequest = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pRequest ) )
	{
		u_long idTarget;
		ar >> idTarget;

		CUser* pTarget = g_UserMng.GetUserByPlayerID( idTarget );
		if( IsValidObj( pTarget ) )
			CCampusHelper::GetInstance()->OnInviteCampusMember( pRequest, pTarget );
	}
}

void CDPSrvr::OnAcceptCampusMember( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pTarget = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pTarget ) )
	{
		u_long idRequest;
		ar >> idRequest;

		CUser* pRequest = g_UserMng.GetUserByPlayerID( idRequest );
		if( IsValidObj( pRequest ) )
			CCampusHelper::GetInstance()->OnAcceptCampusMember( pRequest, pTarget );
	}
}

void CDPSrvr::OnRefuseCampusMember( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pTarget = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pTarget ) )
	{
		u_long idRequest;
		ar >> idRequest;

		CUser* pRequest = g_UserMng.GetUserByPlayerID( idRequest );
		if( IsValidObj( pRequest ) )
			pRequest->AddDefinedText( TID_GAME_TS_REFUSAL, "\"%s\"", pTarget->GetName() );
	}
}

void CDPSrvr::OnRemoveCampusMember( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pRequest = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pRequest ) )
	{
		u_long idTarget;
		ar >> idTarget;

		if( idTarget > 0 )
			CCampusHelper::GetInstance()->OnRemoveCampusMember( pRequest, idTarget );
	}
}
#endif // __CAMPUS




//	mulcom	BEGIN100405	°¢¼º º¸È£ÀÇ µÎ·ç¸¶¸®
void	CDPSrvr::OnItemSelectAwakeningValue( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pRequest = g_UserMng.GetUser( dpidCache, dpidUser );

	if( IsValidObj( pRequest ) == TRUE )
	{
		DWORD	dwItemObjID		= 0;
		DWORD	dwSerialNumber	= 0;
		BYTE	bySelectFlag	= 0;

		ar >> dwItemObjID;
		ar >> dwSerialNumber;
		ar >> bySelectFlag;

		pRequest->SelectAwakeningValue( dwItemObjID, dwSerialNumber, bySelectFlag );
	}
	else
	{
		WriteLog( "pUser is invalid in OnItemSelectAwakeningValue function." );
	}
}
//	mulcom	END100405	°¢¼º º¸È£ÀÇ µÎ·ç¸¶¸®

#ifdef __GUILD_HOUSE_MIDDLE
void CDPSrvr::OnGuildHouseTenderMainWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) == TRUE )
	{
		DWORD dwGHType;
		OBJID objNpcId;
		ar >> dwGHType >> objNpcId;

		GuildHouseMng->ReqTenderGuildHouseList( pUser, dwGHType, objNpcId );
	}
}

void CDPSrvr::OnGuildHouseTenderInfoWnd( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) == TRUE )
	{
		OBJID objGHId;
		ar >> objGHId;

		GuildHouseMng->ReqTenderGuildHouseInfo( pUser, objGHId );
	}
}

void CDPSrvr::OnGuildHouseTenderJoin( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) == TRUE )
	{
		OBJID objGHId;
		int nTenderPerin, nTenderPenya;
		ar >> objGHId >> nTenderPerin >> nTenderPenya;
		
		GuildHouseMng->OnGuildHouseTenderJoin( pUser, objGHId, nTenderPerin, nTenderPenya );
	}
}
#endif // __GUILD_HOUSE_MIDDLE


#ifdef __NEW_ITEM_VARUNA
void CDPSrvr::OnBaruna( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
#ifdef __QUIZ
		if( pUser->GetWorld() && pUser->GetWorld()->GetID() == WI_WORLD_QUIZ )
			return;
#endif
		if( pUser->m_vtInfo.GetOther() )
			return;
		if( pUser->m_vtInfo.VendorIsVendor() )
			return;

		CMover*	pBarunaPet = prj.GetMover( pUser->GetEatPetId( ) );
 		if( pBarunaPet && pBarunaPet->GetProp()->dwAI == AII_NONE )
		{
		}
		else
		{
			pUser->AddDefinedText( TID_MMI_NEWSMELT_OPER01 );
			return;
		}

		BYTE nState;
		ar >> nState;
		switch( nState )
		{
			case BARUNA_ENCHANT: 
			{
				DWORD dwItem01, dwItem02, dwItem03, dwItem04;
				ar >> dwItem01 >> dwItem02 >> dwItem03 >> dwItem04;
				CItemElem* pItemElem0	= pUser->m_Inventory.GetAtId( dwItem01 );
				CItemElem* pItemElem1	= pUser->m_Inventory.GetAtId( dwItem02 );
				CItemElem* pItemElem2	= pUser->m_Inventory.GetAtId( dwItem03 );
				CItemElem* pItemElem3	= pUser->m_Inventory.GetAtId( dwItem04 );

				if( IsUsableItem( pItemElem0 ) == FALSE || IsUsableItem( pItemElem1 ) == FALSE )
					return;
				if( IsUsableItem( pItemElem3 ) == FALSE )
					pItemElem3 = NULL;

				CItemUpgrade::GetInstance()->EnchantBaruna( pUser, pItemElem0, pItemElem1, pItemElem2, pItemElem3 );
			}break;
			case BARUNA_CREATE_CRYSTAL:
			{
				DWORD dwItem01, dwItem02;
				ar >> dwItem01 >> dwItem02;
				CItemElem* pItemElem0	= pUser->m_Inventory.GetAtId( dwItem01 );
				CItemElem* pItemElem1	= pUser->m_Inventory.GetAtId( dwItem02 );

				if( IsUsableItem( pItemElem0 ) == FALSE || IsUsableItem( pItemElem1 ) == FALSE )
					return;

				CItemUpgrade::GetInstance()->CreateBarunaCrystal( pUser, pItemElem0, pItemElem1 );
			}break;
			case BARUNA_EXTRACT_CHAOS_GEM:
			{
				DWORD dwItem01;
				ar >> dwItem01;
				CItemElem* pItemElem0	= pUser->m_Inventory.GetAtId( dwItem01 );

				if( IsUsableItem( pItemElem0 ) == FALSE )
					return;

				CItemUpgrade::GetInstance()->BarunaChaosGemExtract( pUser, pItemElem0 );
			}break;
			case BARUNA_CREATE_STONE:
			{
				DWORD dwItem01, dwItem02, dwItem03;
				ar >> dwItem01 >> dwItem02 >> dwItem03;
				CItemElem* pItemElem0	= pUser->m_Inventory.GetAtId( dwItem01 );
				CItemElem* pItemElem1	= pUser->m_Inventory.GetAtId( dwItem02 );
				CItemElem* pItemElem2	= pUser->m_Inventory.GetAtId( dwItem03 );

				if( IsUsableItem( pItemElem0 ) == FALSE || IsUsableItem( pItemElem1 ) == FALSE || IsUsableItem( pItemElem2 ) == FALSE )
					return;

				CItemUpgrade::GetInstance()->CreateStone( pUser, pItemElem0, pItemElem1, pItemElem2 );
			}break;
			case BARUNA_CREATE_CHAOS_GEM:
			{
				DWORD dwItem01, dwItem02;
				ar >> dwItem01 >> dwItem02;
				CItemElem* pItemElem0	= pUser->m_Inventory.GetAtId( dwItem01 );
				CItemElem* pItemElem1	= pUser->m_Inventory.GetAtId( dwItem02 );

				if( IsUsableItem( pItemElem0 ) == FALSE || IsUsableItem( pItemElem1 ) == FALSE )
					return;

				CItemUpgrade::GetInstance()->CreateBarunaChaosGem( pUser, pItemElem0, pItemElem1 );
			}break;
#ifdef __BARUNA_PIERCING
			case BARUNA_PIERCE:
			{
				DWORD dwItem01, dwItem02, dwItem03, dwItem04;
				ar >> dwItem01 >> dwItem02 >> dwItem03 >> dwItem04;
				CItemElem* pItemElem0	= pUser->m_Inventory.GetAtId( dwItem01 );
				CItemElem* pItemElem1	= pUser->m_Inventory.GetAtId( dwItem02 );
				CItemElem* pItemElem2	= pUser->m_Inventory.GetAtId( dwItem03 );
				CItemElem* pItemElem3	= pUser->m_Inventory.GetAtId( dwItem04 );

				if( IsUsableItem( pItemElem0 ) == FALSE || IsUsableItem( pItemElem1 ) == FALSE )
					return;
				if( IsUsableItem( pItemElem2 ) == FALSE )
					pItemElem2 = NULL;
				if( IsUsableItem( pItemElem3 ) == FALSE )
					pItemElem3 = NULL;

				CItemUpgrade::GetInstance()->CreateBarunaPiercing( pUser, pItemElem0, pItemElem1, pItemElem2, pItemElem3 );

			}break;	
#endif
		}
		}
	}	
#endif

#ifdef __LOOKCHANGE
void CDPSrvr::OnLookChange(CAr &ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser *pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	CItemElem *pDest, *pSrc;
	DWORD dwIdSrc, dwIdDest;
	ar >> dwIdSrc >> dwIdDest;

	pSrc = pUser->m_Inventory.GetAtId(dwIdSrc);
	pDest = pUser->m_Inventory.GetAtId(dwIdDest);

	if (!pSrc || !pDest)
		return;

	if (!IsUsableItem(pSrc) || !IsUsableItem(pDest))
	{
		pUser->AddDefinedText(TID_MMI_LOOKCHANGE06);
		return;
}
	if (pSrc->IsChangedLook() || pDest->IsChangedLook())
	{
		pUser->AddDefinedText(TID_MMI_LOOKCHANGE01);
		return;
	}
	if (pUser->m_Inventory.IsEquip(pSrc->m_dwObjId) || pUser->m_Inventory.IsEquip(pDest->m_dwObjId))
	{
		pUser->AddDefinedText(TID_GAME_EQUIPPUT);
		return;
	}
	if (pSrc->m_dwItemId == pDest->m_dwItemId)
	{
		pUser->AddDefinedText(TID_MMI_LOOKCHANGE08);
		return;
	}

	ItemProp* iPropSrc = pSrc->GetProp();
	ItemProp* iPropDest = pDest->GetProp();
	if (!iPropSrc || !iPropDest)
	{
		pUser->AddDefinedText(TID_MMI_LOOKCHANGE07);
		return;
	}
	switch (pSrc->m_dwItemId)
	{
	case II_ARM_M_CHR_MAJESTY01HAT:
	case II_ARM_M_CHR_MAJESTY01SUIT:
	case II_ARM_M_CHR_MAJESTY01GLOVES:
	case II_ARM_M_CHR_MAJESTY01SHOES:
	case II_ARM_S_CLO_CLO_MAJESTY:
	case II_ARM_F_CHR_MAJESTY01HAT:
	case II_ARM_F_CHR_MAJESTY01SUIT:
	case II_ARM_F_CHR_MAJESTY01GLOVES:
	case II_ARM_F_CHR_MAJESTY01SHOES:
	{
		pUser->AddDefinedText(TID_MMI_LOOKCHANGE08);
		return;
	}
	}
	switch (pDest->m_dwItemId)
	{
	case II_ARM_M_CHR_MAJESTY01HAT:
	case II_ARM_M_CHR_MAJESTY01SUIT:
	case II_ARM_M_CHR_MAJESTY01GLOVES:
	case II_ARM_M_CHR_MAJESTY01SHOES:
	case II_ARM_S_CLO_CLO_MAJESTY:
	case II_ARM_F_CHR_MAJESTY01HAT:
	case II_ARM_F_CHR_MAJESTY01SUIT:
	case II_ARM_F_CHR_MAJESTY01GLOVES:
	case II_ARM_F_CHR_MAJESTY01SHOES:
	{
		pUser->AddDefinedText(TID_MMI_LOOKCHANGE08);
		return;
	}
	}
	if (((iPropSrc->dwItemKind3 == IK3_PET || iPropDest->dwItemKind3 == IK3_PET) && pUser->HasActivatedEatPet()) || (pUser->HasActivatedSystemPet() || (iPropSrc->dwItemKind3 == IK3_EGG || iPropDest->dwItemKind3 == IK3_EGG)))
	{
		pUser->AddDefinedText(TID_GAME_PET_IS_NOT_FEED);
		return;
	}
	if ((iPropDest->dwItemSex == SEX_MALE || iPropDest->dwItemSex == SEX_FEMALE) && (iPropSrc->dwItemSex == SEX_MALE || iPropSrc->dwItemSex == SEX_FEMALE))
	{
		if (iPropDest->dwItemSex != iPropSrc->dwItemSex)
		{
			pUser->AddDefinedText(TID_MMI_LOOKCHANGE07);
			return;
		}
	}

	if (iPropDest->dwItemKind3 != IK3_SHIELD && iPropDest->dwItemKind3 != IK3_MAGICBARUNA && iPropDest->dwItemKind3 != IK3_ZEMBARUNA &&
		iPropSrc->dwItemKind3 != IK3_SHIELD && iPropSrc->dwItemKind3 != IK3_MAGICBARUNA && iPropSrc->dwItemKind3 != IK3_ZEMBARUNA)
	{
		if (iPropDest->dwItemKind3 != iPropSrc->dwItemKind3)
		{
			pUser->AddDefinedText(TID_MMI_LOOKCHANGE07);
			return;
		}
	}
	if ((iPropSrc->dwItemKind3 == IK3_SHIELD || iPropSrc->dwItemKind3 != IK3_MAGICBARUNA || iPropSrc->dwItemKind3 != IK3_ZEMBARUNA) && (iPropDest->dwItemKind3 != IK3_SHIELD || iPropDest->dwItemKind3 != IK3_MAGICBARUNA || iPropDest->dwItemKind3 != IK3_ZEMBARUNA))
	{

	}
	else
	{
		if ((iPropSrc->dwItemKind3 != IK3_SWD || iPropDest->dwItemKind3 != IK3_SWD)
			&& (iPropSrc->dwItemKind3 != IK3_AXE || iPropDest->dwItemKind3 != IK3_AXE)
			&& (iPropSrc->dwItemKind3 != IK3_KNUCKLEHAMMER || iPropDest->dwItemKind3 != IK3_KNUCKLEHAMMER)
			&& (iPropSrc->dwItemKind3 != IK3_CHEERSTICK || iPropDest->dwItemKind3 != IK3_CHEERSTICK)
			&& (iPropSrc->dwItemKind3 != IK3_WAND || iPropDest->dwItemKind3 != IK3_WAND)
			&& (iPropSrc->dwItemKind3 != IK3_STAFF || iPropDest->dwItemKind3 != IK3_STAFF)
			&& (iPropSrc->dwItemKind3 != IK3_BOW || iPropDest->dwItemKind3 != IK3_BOW)
#ifdef __CROSSBOW
			&& (iPropSrc->dwItemKind3 != IK3_CROSSBOW || iPropDest->dwItemKind3 != IK3_CROSSBOW)
#endif
			&& (iPropSrc->dwItemKind3 != IK3_YOYO || iPropDest->dwItemKind3 != IK3_YOYO)
			&& (iPropSrc->dwItemKind3 != IK3_HELMET || iPropDest->dwItemKind3 != IK3_HELMET)
			&& (iPropSrc->dwItemKind3 != IK3_SUIT || iPropDest->dwItemKind3 != IK3_SUIT)
			&& (iPropSrc->dwItemKind3 != IK3_GAUNTLET || iPropDest->dwItemKind3 != IK3_GAUNTLET)
			&& (iPropSrc->dwItemKind3 != IK3_BOOTS || iPropDest->dwItemKind3 != IK3_BOOTS)
			&& (iPropSrc->dwItemKind3 != IK3_HAT || iPropDest->dwItemKind3 != IK3_HAT)
			&& (iPropSrc->dwItemKind3 != IK3_CLOTH || iPropDest->dwItemKind3 != IK3_CLOTH)
			&& (iPropSrc->dwItemKind3 != IK3_GLOVE || iPropDest->dwItemKind3 != IK3_GLOVE)
			&& (iPropSrc->dwItemKind3 != IK3_SHOES || iPropDest->dwItemKind3 != IK3_SHOES)
			&& (iPropSrc->dwItemKind3 != IK3_CLOAK || iPropDest->dwItemKind3 != IK3_CLOAK)
			&& (iPropSrc->dwItemKind3 != IK3_MASK || iPropDest->dwItemKind3 != IK3_MASK)
			&& (iPropSrc->dwItemKind3 != IK3_PET || iPropDest->dwItemKind3 != IK3_PET))
		{
			pUser->AddDefinedText(TID_MMI_ELLDINPOTION_TEXT08);
			return;
		}
	}

	pDest->SetLook(pSrc->m_dwItemId);
	pUser->RemoveItem((BYTE)pSrc->m_dwObjId, 1);
	pUser->AddLookChange(pDest->m_dwObjId, pDest->GetLook());
	pUser->AddDefinedText(TID_MMI_LOOKCHANGE04);
}
#endif

#ifdef __FASHION_COMBINE
void CDPSrvr::OnFashionCombine( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser = g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		DWORD dwItem = NULL_ID;
		CItemElem* pItemElem[8];

		for( int i = 0; i < 8; i++ )
		{
			ar >> dwItem;
			pItemElem[i] = pUser->m_Inventory.GetAtId( dwItem );
			if( !IsUsableItem( pItemElem[i]))
				return;
		}

		BOOL bHack = FALSE;
		if (pItemElem[0]->GetProp()->dwItemKind3 != IK3_HAT || pItemElem[1]->GetProp()->dwItemKind3 != IK3_HAT)
			bHack = TRUE;
		if (pItemElem[2]->GetProp()->dwItemKind3 != IK3_CLOTH || pItemElem[3]->GetProp()->dwItemKind3 != IK3_CLOTH)
			bHack = TRUE;
		if (pItemElem[4]->GetProp()->dwItemKind3 != IK3_GLOVE || pItemElem[5]->GetProp()->dwItemKind3 != IK3_GLOVE)
			bHack = TRUE;
		if (pItemElem[6]->GetProp()->dwItemKind3 != IK3_SHOES || pItemElem[7]->GetProp()->dwItemKind3 != IK3_SHOES)
			bHack = TRUE;

		if (bHack)
		{
#ifdef __GAMEGUARD
			REPORT_HACK;
#endif // __GAMEGUARD
			if (pUser->GetWorld())
				g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());

			QueryDestroyPlayer(pUser->m_Snapshot.dpidCache, pUser->m_Snapshot.dpidUser, pUser->m_dwSerial, pUser->m_idPlayer);
			return;
		}

		if( xRandom( 10000 ) < 10000 )
		{		
			int nResult = 0;
			nResult = g_xRandomOptionProperty->MergeRandomOption( pItemElem[0], pItemElem[1] );
			nResult += g_xRandomOptionProperty->MergeRandomOption( pItemElem[2], pItemElem[3] );
			nResult += g_xRandomOptionProperty->MergeRandomOption( pItemElem[4], pItemElem[5] );
			nResult += g_xRandomOptionProperty->MergeRandomOption( pItemElem[6], pItemElem[7] );
			if( nResult > 0 )
			{
				Error( "packet editor detected. tried to combine more then 3 awakening on one item. User: %s", pUser->GetName() );
			}
			for( int i = 1; i < 8; i += 2 )
			{
				pUser->UpdateItem( (BYTE)pItemElem[i]->m_dwObjId, UI_NUM, 0 );
			}
			for( int i = 0; i < 8; i += 2 )
			{
				pUser->UpdateItemEx( (BYTE)( pItemElem[i]->m_dwObjId ), UI_RANDOMOPTITEMID, pItemElem[i]->GetRandomOptItemId() );
			}

			pUser->AddDefinedText( TID_COSTUME_COSTUMEMIXCOMPLETE );
		}
		else
		{
			pUser->AddPlaySound( SND_INF_UPGRADEFAIL );
			if( pUser->IsMode( TRANSPARENT_MODE ) == 0 )
				g_UserMng.AddCreateSfxObj( (CMover *)pUser, XI_INT_FAIL, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z );

			if( pUser->HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_COSTUMEDEFENDER ) )
			{
				pUser->RemoveBuff( BUFF_ITEM, II_SYS_SYS_SCR_COSTUMEDEFENDER );
				pUser->AddDefinedText( TID_MMI_COSTUME_SAFEMIXITEM03 );

			}
			else
			{
				pUser->AddDefinedText( TID_MMI_COSTUME_COSTUMEMIXFAILED );
				for( int i = 0; i < 8; i++ )
				{
					pUser->UpdateItem( (BYTE)pItemElem[i]->m_dwObjId, UI_NUM, 0 );
				}
			}
		}
	}
}
#endif
#ifdef __NEW_TASKBAR_V19
void CDPSrvr::OnScrollTaskBar(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;
	//if(!g_Option.isClassicTheme() && !g_Option.isRedTheme() && !g_Option.isClassicBlueTheme())
	{
		for (int i = 0; i < 10; ++i)
		{
			SHORTCUT scTemp = pUser->m_playTaskBar.m_aSlotItem[0][i];
			pUser->m_playTaskBar.m_aSlotItem[0][i] = pUser->m_playTaskBar.m_aSlotItem[1][i];
			pUser->m_playTaskBar.m_aSlotItem[1][i] = pUser->m_playTaskBar.m_aSlotItem[2][i];
			pUser->m_playTaskBar.m_aSlotItem[2][i] = scTemp;
		}
	}
}
#endif //__NEW_TASKBAR_V19
#ifdef	__COLOSSEUM
void CDPSrvr::OnColosseum( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		BYTE nState;
		ar >> nState;
		CParty* pParty = g_PartyMng.GetParty( pUser->GetPartyId() );
		switch( nState )
		{
		case 1:
			BYTE byDifficult, byMenu;
			ar >> byDifficult >> byMenu;
			if( pParty && pParty->IsLeader( pUser->m_idPlayer ) )
			{
				if( CColosseumMng::GetInstance()->CreateNewMatch( pUser, byDifficult, byMenu ) )
				{
					CColosseumMatch* pColosseumMatch = CColosseumMng::GetInstance()->GetMatchByParty( pParty );
					if( pColosseumMatch )
						pColosseumMatch->EnterRoom( pUser );
					pUser->AddDefinedText(TID_COLOSSEUM_NOTENTERTIME01);
				}
				else
					pUser->AddDefinedText(TID_COLOSSEUM_NOTENTERTIME01);
			}
			else
				pUser->AddDefinedText(TID_COLOSSEUM_COLONOWPLAYING01);
		break;
		case 2:
			if( pParty )
			{
				CColosseumMatch* pColosseumMatch = CColosseumMng::GetInstance()->GetMatchByParty( pParty );
				if( pColosseumMatch )
					if( pColosseumMatch->m_byMenu == 2 )
					{
						if( pColosseumMatch->m_uGuildID == pUser->m_idGuild )
							pColosseumMatch->EnterRoom( pUser );
					}
					else
						pColosseumMatch->EnterRoom( pUser );
			}
		break;
		case 3:
			if( pParty && pParty->IsLeader( pUser->m_idPlayer ) )
			{
				CColosseumMatch* pColosseumMatch = CColosseumMng::GetInstance()->GetMatchByParty( pParty );
				if( pColosseumMatch )
					pColosseumMatch->EndWaitTime();
			}
		break;
		}
	}
}
#endif

#ifdef __ITEMLINK
void CDPSrvr::OnItemLink( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long )
{
	CUser* pUser	= g_UserMng.GetUser( dpidCache, dpidUser );
	if( IsValidObj( pUser ) )
	{
		BYTE nId;
		DWORD dwPlayerId,dwObjId;
		ar >> nId >> dwPlayerId >> dwObjId;

		if( nId != BYTE_SEND )
			return;

		CUser* pOther = g_UserMng.GetUserByPlayerID( dwPlayerId );
		if( !IsValidObj(pOther) )
		{
			pUser->AddDefinedText(TID_GAME_NOTLOGIN);
			return;
		}
		CItemElem* pItemElem = pOther->m_Inventory.GetAtId( dwObjId );
		if( pItemElem == NULL )
		{
			pUser->AddDefinedText(TID_GAME_ITEM_EXPIRED);
			return;
		}
		pUser->SendItemLink( pItemElem );
	}
}
#endif
#ifdef __SYS_SCR_CANCELLATION
BOOL CDPSrvr::UnbindScroll(CUser* pUser, CItemElem* pMaterial, CItemElem* pTarget)
{
	if (pTarget->GetProp() == NULL)
		return FALSE;

	if (pTarget->IsFlag(CItemElem::binds) && pMaterial->m_dwItemId == II_SYS_SYS_SCR_CANCELLATION && (pTarget->GetProp()->dwFlag & IP_FLAG_EQUIP_BIND))
	{
		pTarget->ResetFlag(CItemElem::binds);
		pUser->UpdateItem((BYTE)(pTarget->m_dwObjId), UI_FLAG, MAKELONG(pTarget->m_dwObjIndex, pTarget->m_byFlag));
		LogItemInfo    log;
		log.Action = "r";
		log.SendName = pUser->GetName();
		log.RecvName = "::binds";
		log.WorldId = pUser->GetWorld()->GetID();
		log.Gold = pUser->GetGold();
		log.Gold2 = pUser->GetGold();
		OnLogItem(log, pTarget, 1);
		pUser->AddDefinedText(TID_GAME_SMELT_SAFETY_SUCCESS);
		return TRUE;
	}
	else
		pUser->AddDefinedText(TID_ITEM_CANCEL_ERROR1);
	return FALSE;
}
#endif

#ifdef __RANDOMOPTION_RETRY
void CDPSrvr::OnRandomOptionRetry(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == TRUE)
	{
		OBJID dwItemId;
		OBJID dwItemId2;
		int nRadio;
		ar >> dwItemId >> dwItemId2 >> nRadio;
		CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwItemId);
		CItemElem* pItemElem2 = pUser->m_Inventory.GetAtId(dwItemId2);
		if (IsUsableItem(pItemElem) && IsUsableItem(pItemElem2))
		{
			if (pItemElem2->GetProp()->dwID != II_SYS_SYS_SCR_RANDOMOPTIONRTRY)
				return;

			if (pUser->m_Inventory.IsEquip(pItemElem->m_dwObjId))
			{
				pUser->AddDefinedText(TID_GAME_EQUIPPUT);
				return;
			}

			if (pUser->HasActivatedSystemPet() && pItemElem->GetProp()->dwItemKind3 == IK3_EGG)
			{
				pUser->AddDefinedText(TID_MMI_RANDOMOPTIONRETRY_ERRORTEXT05);
				return;
			}

			int nRandomOptionKind = g_xRandomOptionProperty->GetRandomOptionKind(pItemElem);
			if (nRandomOptionKind == CRandomOptionProperty::eAwakening)
			{
				int nSize = g_xRandomOptionProperty->GetRandomOptionSize(pItemElem->GetRandomOptItemId());
				int nDst, nAdj, nDst3, nAdj3;
				int nDst2[3];
				int nAdj2[3];

				if (nSize >= 2 && nSize <= 3)
				{
					for (int i = 0; i < nSize; i++)
					{
						g_xRandomOptionProperty->GetParam(pItemElem->GetRandomOptItemId(), i, &nDst, &nAdj);
						nDst2[i] = nDst;
						nAdj2[i] = nAdj;
					}

					int k = nSize;
					g_xRandomOptionProperty->InitializeRandomOption(pItemElem->GetRandomOptItemIdPtr());
					g_xRandomOptionProperty->GenRandomOption(pItemElem->GetRandomOptItemIdPtr(), nRandomOptionKind, pItemElem->GetProp()->dwParts);
					g_xRandomOptionProperty->GetParam(pItemElem->GetRandomOptItemId(), 0, &nDst, &nAdj);

					nDst3 = nDst;
					nAdj3 = nAdj;
					g_xRandomOptionProperty->InitializeRandomOption(pItemElem->GetRandomOptItemIdPtr());

					if (nRadio == 1)
					{
						g_xRandomOptionProperty->SetParam(pItemElem->GetRandomOptItemIdPtr(), nDst3, nAdj3);
						g_xRandomOptionProperty->SetParam(pItemElem->GetRandomOptItemIdPtr(), nDst2[1], nAdj2[1]);

						if (k == 3)
						{
							g_xRandomOptionProperty->SetParam(pItemElem->GetRandomOptItemIdPtr(), nDst2[2], nAdj2[2]);
						}
					}
					else if (nRadio == 2)
					{
						g_xRandomOptionProperty->SetParam(pItemElem->GetRandomOptItemIdPtr(), nDst2[0], nAdj2[0]);
						g_xRandomOptionProperty->SetParam(pItemElem->GetRandomOptItemIdPtr(), nDst3, nAdj3);
						if (k == 3)
						{
							g_xRandomOptionProperty->SetParam(pItemElem->GetRandomOptItemIdPtr(), nDst2[2], nAdj2[2]);
						}
					}
					else if (nRadio == 3)
					{
						g_xRandomOptionProperty->SetParam(pItemElem->GetRandomOptItemIdPtr(), nDst2[0], nAdj2[0]);
						g_xRandomOptionProperty->SetParam(pItemElem->GetRandomOptItemIdPtr(), nDst2[1], nAdj2[1]);
						g_xRandomOptionProperty->SetParam(pItemElem->GetRandomOptItemIdPtr(), nDst3, nAdj3);
					}
					pUser->UpdateItemEx((BYTE)(pItemElem->m_dwObjId), UI_RANDOMOPTITEMID, pItemElem->GetRandomOptItemId());
					pUser->UpdateItem((BYTE)(pItemElem2->m_dwObjId), UI_NUM, pItemElem2->m_nItemNum - 1);
					pUser->AddDefinedText(TID_GAME_SMELT_SAFETY_SUCCESS);
				}
			}
		}
	}
}
#endif

#ifdef __TREASUREBOX
void CDPSrvr::OnTreasureBoxOpen(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		DWORD dwBoxID = NULL, dwKeyID = NULL;
		ar >> dwBoxID >> dwKeyID;
		CItemElem* pBox = pUser->m_Inventory.GetAtId(dwBoxID);
		CItemElem* pKey = pUser->m_Inventory.GetAtId(dwKeyID);
		if (IsUsableItem(pBox) && IsUsableItem(pKey))
		{
			int nFound = 0;
			if ((pBox->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREBOXLV15) && (pKey->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREKEYLOW15 || pKey->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREKEYMIDDLE15 || pKey->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREKEYHIGH15))
				nFound = 1;
			if ((pBox->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREBOXLV60) && (pKey->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREKEYLOW60 || pKey->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREKEYMIDDLE60 || pKey->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREKEYHIGH60))
				nFound = 1;
			if ((pBox->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREBOXLV90) && (pKey->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREKEYLOW90 || pKey->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREKEYMIDDLE90 || pKey->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREKEYHIGH90))
				nFound = 1;
			if ((pBox->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREBOXLV120) && (pKey->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREKEYLOW120 || pKey->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREKEYMIDDLE120 || pKey->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREKEYHIGH120))
				nFound = 1;
			if ((pBox->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREBOXLV150) && (pKey->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREKEYLOW150 || pKey->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREKEYMIDDLE150 || pKey->GetProp()->dwID == II_SYS_SYS_SCR_TREASUREKEYHIGH150))
				nFound = 1;

			if (nFound == 0)
				return;
#ifndef __TABBED_INV
			if (pUser->m_Inventory.GetEmptyCount() < 3)
			{
				pUser->AddDefinedText(TID_GAME_LACKSPACE);
				return;
			}
#endif // __TABBED_INV
			TreasureItem dwIDs[3];
			ZeroMemory(&dwIDs, sizeof(dwIDs));
			for (int i = 0; i < 3; i++)
			{
				int nChance = xRandom(0, 5000);
				int nOffset = xRandom(0, (int)prj.m_vTreasureItem.size());
				BOOL bFound = FALSE;
				for (int j = nOffset; j < (int)prj.m_vTreasureItem.size(); j++)
				{
					if (pKey->GetProp()->dwID == prj.m_vTreasureItem.at(j).dwKeyID && nChance < prj.m_vTreasureItem.at(j).nChance)
					{
						int nContinue = 0;
						for (int k = 0; k < 3; k++)
						{
							if (dwIDs[k].dwItemID == prj.m_vTreasureItem.at(j).dwItemID)
								nContinue++;
						}
						if (nContinue == 0 || (nContinue > 0 && prj.m_vTreasureItem.at(j).nRepeat > nContinue))
						{
							dwIDs[i] = prj.m_vTreasureItem.at(j);
							bFound = TRUE;
							break;
						}
					}
				}

				if (bFound)
					continue;

				for (int j = 0; j < nOffset; j++)
				{
					if (pKey->GetProp()->dwID == prj.m_vTreasureItem.at(j).dwKeyID && nChance < prj.m_vTreasureItem.at(j).nChance)
					{
						int nContinue = 0;
						for (int k = 0; k < 3; k++)
						{
							if (dwIDs[k].dwItemID == prj.m_vTreasureItem.at(j).dwItemID)
								nContinue++;
						}
						if (nContinue == 0 || (nContinue > 0 && prj.m_vTreasureItem.at(j).nRepeat > nContinue))
						{
							dwIDs[i] = prj.m_vTreasureItem.at(j);
							break;
						}
					}
				}
			}
#ifdef __TABBED_INV
			int nCount[4] = { 0,0,0,0 };
			for (int i = 0; i < 3; i++)
			{
				if (dwIDs[i].dwItemID != NULL)
					nCount[prj.GetItemProp(dwIDs[i].dwItemID)->GetInvenIndex()]++;
			}
			for (int i = 0; i < 4; i++)
			{
				if (pUser->m_Inventory.GetEmptyCount(i) < nCount[i])
				{
					pUser->AddDefinedText(TID_GAME_LACKSPACE);
					return;
				}
			}
#endif // __TABBED_INV
			int nCounter[3];
			ZeroMemory(&nCounter, sizeof(nCounter));
			for (int i = 0; i < 3; i++)
			{
				if (dwIDs[i].dwItemID == NULL)
					continue;

				int nCount = xRandom(dwIDs[i].nLimitamount, dwIDs[i].nMaxamount);
				nCounter[i] = nCount;
				CItemElem itemElem;
				itemElem.m_dwItemId = dwIDs[i].dwItemID;
				itemElem.m_nItemNum = nCount;
				itemElem.SetSerialNumber();
				itemElem.m_nHitPoint = 0;
				if (dwIDs[i].bNotice)
				{
					CString str;
					str.Format(prj.GetText(TID_MMI_TREASURE_NOTICETREASUREITEM), pUser->GetName(), itemElem.GetProp()->szName);
#ifdef __ADVANCED_ANNOUNCEMENT
					g_DPCoreClient.SendSystem(str, 5, 0);	// Discovery - Default Shout Font
#else //__ADVANCED_ANNOUNCEMENT
					g_DPCoreClient.SendSystem(str);
#endif //__ADVANCED_ANNOUNCEMENT
				}
				pUser->CreateItem(&itemElem);
			}
			pUser->RemoveItem((BYTE)dwBoxID, 1);
			pUser->RemoveItem((BYTE)dwKeyID, 1);
			pUser->SendTreasure(dwIDs, nCounter);
		}
	}
}
#endif

#ifdef __NEW_CHANGE_JOB
void CDPSrvr::OnSendJobChange(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	int nJob;
	ar >> nJob;
	if (IsValidObj(pUser))
	{
		/*if (pUser->GetLevel() == 15 && g_pPlayer->GetJob() == JOB_VAGRANT)
		{
			switch( nJob )
			{
				case JOB_MERCENARY: pUser->ChangeJob( JOB_MERCENARY ); break;
				case JOB_ASSIST: pUser->ChangeJob( JOB_ASSIST ); break;
				case JOB_ACROBAT: pUser->ChangeJob( JOB_ACROBAT ); break;
				case JOB_MAGICIAN: pUser->ChangeJob( JOB_MAGICIAN ); break;
				default: Error("[Warning] CDPSrvr::OnSendJobChange (1) - %s", pUser->GetName() ); break;
			}
		}*/
		if (pUser->GetLevel() == (MAX_JOB_LEVEL + MAX_EXP_LEVEL) && pUser->IsExpert())
		{
			switch (nJob)
			{
			case JOB_KNIGHT: if (pUser->GetJob() == JOB_MERCENARY) pUser->ChangeJob(JOB_KNIGHT); break;
			case JOB_BLADE: if (pUser->GetJob() == JOB_MERCENARY) pUser->ChangeJob(JOB_BLADE); break;
			case JOB_JESTER: if (pUser->GetJob() == JOB_ACROBAT) pUser->ChangeJob(JOB_JESTER); break;
			case JOB_RANGER: if (pUser->GetJob() == JOB_ACROBAT) pUser->ChangeJob(JOB_RANGER); break;
			case JOB_RINGMASTER: if (pUser->GetJob() == JOB_ASSIST) pUser->ChangeJob(JOB_RINGMASTER); break;
			case JOB_BILLPOSTER: if (pUser->GetJob() == JOB_ASSIST) pUser->ChangeJob(JOB_BILLPOSTER); break;
			case JOB_PSYCHIKEEPER: if (pUser->GetJob() == JOB_MAGICIAN) pUser->ChangeJob(JOB_PSYCHIKEEPER); break;
			case JOB_ELEMENTOR: if (pUser->GetJob() == JOB_MAGICIAN) pUser->ChangeJob(JOB_ELEMENTOR); break;
			default: Error("[Warning] CDPSrvr::OnSendJobChange (2) - %s", pUser->GetName()); break;
			}
		}
		else if (pUser->GetLevel() == MAX_GENERAL_LEVEL && pUser->IsPro() && pUser->GetExpPercent() >= 9999)
		{
			switch (nJob)
			{
			case JOB_KNIGHT_MASTER: if (pUser->GetJob() == JOB_KNIGHT) pUser->ChangeJob(JOB_KNIGHT_MASTER); break;
			case JOB_BLADE_MASTER: if (pUser->GetJob() == JOB_BLADE) pUser->ChangeJob(JOB_BLADE_MASTER); break;
			case JOB_JESTER_MASTER: if (pUser->GetJob() == JOB_JESTER) pUser->ChangeJob(JOB_JESTER_MASTER); break;
			case JOB_RANGER_MASTER: if (pUser->GetJob() == JOB_RANGER) pUser->ChangeJob(JOB_RANGER_MASTER); break;
			case JOB_RINGMASTER_MASTER: if (pUser->GetJob() == JOB_RINGMASTER) pUser->ChangeJob(JOB_RINGMASTER_MASTER); break;
			case JOB_BILLPOSTER_MASTER: if (pUser->GetJob() == JOB_BILLPOSTER) pUser->ChangeJob(JOB_BILLPOSTER_MASTER); break;
			case JOB_PSYCHIKEEPER_MASTER: if (pUser->GetJob() == JOB_PSYCHIKEEPER) pUser->ChangeJob(JOB_PSYCHIKEEPER_MASTER); break;
			case JOB_ELEMENTOR_MASTER: if (pUser->GetJob() == JOB_ELEMENTOR) pUser->ChangeJob(JOB_ELEMENTOR_MASTER); break;
			default: Error("[Warning] CDPSrvr::OnSendJobChange (3) - %s", pUser->GetName()); break;
			}
		}
		else if (pUser->GetLevel() == MAX_GENERAL_LEVEL && pUser->IsMaster() && pUser->GetExpPercent() >= 9999)
		{
			switch (nJob)
			{
			case JOB_KNIGHT_HERO: if (pUser->GetJob() == JOB_KNIGHT_MASTER) pUser->ChangeJob(JOB_KNIGHT_HERO); break;
			case JOB_BLADE_HERO: if (pUser->GetJob() == JOB_BLADE_MASTER) pUser->ChangeJob(JOB_BLADE_HERO); break;
			case JOB_JESTER_HERO: if (pUser->GetJob() == JOB_JESTER_MASTER) pUser->ChangeJob(JOB_JESTER_HERO); break;
			case JOB_RANGER_HERO: if (pUser->GetJob() == JOB_RANGER_MASTER) pUser->ChangeJob(JOB_RANGER_HERO); break;
			case JOB_RINGMASTER_HERO: if (pUser->GetJob() == JOB_RINGMASTER_MASTER) pUser->ChangeJob(JOB_RINGMASTER_HERO); break;
			case JOB_BILLPOSTER_HERO: if (pUser->GetJob() == JOB_BILLPOSTER_MASTER) pUser->ChangeJob(JOB_BILLPOSTER_HERO); break;
			case JOB_PSYCHIKEEPER_HERO: if (pUser->GetJob() == JOB_PSYCHIKEEPER_MASTER) pUser->ChangeJob(JOB_PSYCHIKEEPER_HERO); break;
			case JOB_ELEMENTOR_HERO: if (pUser->GetJob() == JOB_ELEMENTOR_MASTER) pUser->ChangeJob(JOB_ELEMENTOR_HERO); break;
			default: Error("[Warning] CDPSrvr::OnSendJobChange (4) - %s", pUser->GetName()); break;
			}
		}
#ifdef __3RD_LEGEND16
		else if (pUser->GetLevel() == MAX_LEGEND_LEVEL && pUser->IsHero())
		{
			switch (nJob)
			{
			case JOB_LORDTEMPLER_HERO: if (pUser->GetJob() == JOB_KNIGHT_HERO) pUser->ChangeJob(JOB_LORDTEMPLER_HERO); break;
			case JOB_STORMBLADE_HERO: if (pUser->GetJob() == JOB_BLADE_HERO) pUser->ChangeJob(JOB_STORMBLADE_HERO); break;
			case JOB_WINDLURKER_HERO: if (pUser->GetJob() == JOB_JESTER_HERO) pUser->ChangeJob(JOB_WINDLURKER_HERO); break;
			case JOB_CRACKSHOOTER_HERO: if (pUser->GetJob() == JOB_RANGER_HERO) pUser->ChangeJob(JOB_CRACKSHOOTER_HERO); break;
			case JOB_FLORIST_HERO: if (pUser->GetJob() == JOB_RINGMASTER_HERO) pUser->ChangeJob(JOB_FLORIST_HERO); break;
			case JOB_FORCEMASTER_HERO: if (pUser->GetJob() == JOB_BILLPOSTER_HERO) pUser->ChangeJob(JOB_FORCEMASTER_HERO); break;
			case JOB_MENTALIST_HERO: if (pUser->GetJob() == JOB_PSYCHIKEEPER_HERO) pUser->ChangeJob(JOB_MENTALIST_HERO); break;
			case JOB_ELEMENTORLORD_HERO: if (pUser->GetJob() == JOB_ELEMENTOR_HERO) pUser->ChangeJob(JOB_ELEMENTORLORD_HERO); break;
			default: Error("[Warning] CDPSrvr::OnSendJobChange (5) - %s", pUser->GetName()); break;
			}
		}
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
		else if (pUser->GetLevel() == MAX_3RD_LEGEND_LEVEL && pUser->IsLegendHero())
		{
			switch (nJob)
			{
			case JOB_LORDTEMPLER_HERO_ULTIMATE: if (pUser->GetJob() == JOB_LORDTEMPLER_HERO) pUser->ChangeJob(JOB_LORDTEMPLER_HERO_ULTIMATE); break;
			case JOB_STORMBLADE_HERO_ULTIMATE: if (pUser->GetJob() == JOB_STORMBLADE_HERO) pUser->ChangeJob(JOB_STORMBLADE_HERO_ULTIMATE); break;
			case JOB_WINDLURKER_HERO_ULTIMATE: if (pUser->GetJob() == JOB_WINDLURKER_HERO) pUser->ChangeJob(JOB_WINDLURKER_HERO_ULTIMATE); break;
			case JOB_CRACKSHOOTER_HERO_ULTIMATE: if (pUser->GetJob() == JOB_CRACKSHOOTER_HERO) pUser->ChangeJob(JOB_CRACKSHOOTER_HERO_ULTIMATE); break;
			case JOB_FLORIST_HERO_ULTIMATE: if (pUser->GetJob() == JOB_FLORIST_HERO) pUser->ChangeJob(JOB_FLORIST_HERO_ULTIMATE); break;
			case JOB_FORCEMASTER_HERO_ULTIMATE: if (pUser->GetJob() == JOB_FORCEMASTER_HERO) pUser->ChangeJob(JOB_FORCEMASTER_HERO_ULTIMATE); break;
			case JOB_MENTALIST_HERO_ULTIMATE: if (pUser->GetJob() == JOB_MENTALIST_HERO) pUser->ChangeJob(JOB_MENTALIST_HERO_ULTIMATE); break;
			case JOB_ELEMENTORLORD_HERO_ULTIMATE: if (pUser->GetJob() == JOB_ELEMENTORLORD_HERO) pUser->ChangeJob(JOB_ELEMENTORLORD_HERO_ULTIMATE); break;
			default: Error("[Warning] CDPSrvr::OnSendJobChange (6) - %s", pUser->GetName()); break;
			}
		}
#endif // __NEWCLASS
	}
}
#endif // __NEW_CHANGE_JOB

#ifdef __REMOVE_SKILL_BUFF
void CDPSrvr::OnSendRemoveSkillBuff(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		DWORD dwSkillBuff;
		ar >> dwSkillBuff;
		ItemProp* pSkillProp = prj.GetSkillProp(dwSkillBuff);
		if (pSkillProp && (pSkillProp->nEvildoing >= 1
#ifdef __GAMEMASTER
			|| pUser->IsAuthHigher(AUTH_GAMEMASTER2)
#endif // __GAMEMASTER
			) && pUser->HasBuff(BUFF_SKILL, (WORD)(pSkillProp->dwID)))
		{
			pUser->RemoveBuff(BUFF_SKILL, (WORD)(pSkillProp->dwID));
		}
	}
}
#endif // __REMOVE_SKILL_BUFF

#ifdef __MODS_MANAGER
void CDPSrvr::OnSendModsManager(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		BYTE nMode;
		ar >> nMode;
		switch (nMode)
		{
		case 0: pUser->IsMode(MODE_EXPUP_STOP) ? pUser->SetNotMode(MODE_EXPUP_STOP) : pUser->SetMode(MODE_EXPUP_STOP); break;
		case 1: pUser->IsAuthHigher(AUTH_HELPER) ? (pUser->IsMode(ADMINNAME_MODE) ? pUser->SetNotMode(ADMINNAME_MODE) : pUser->SetMode(ADMINNAME_MODE)) : pUser->SetNotMode(ADMINNAME_MODE); break;
		case 2: pUser->IsAuthHigher(AUTH_GAMEMASTER) ? (pUser->IsMode(TRANSPARENT_MODE) ? pUser->SetNotMode(TRANSPARENT_MODE) : pUser->SetMode(TRANSPARENT_MODE)) : pUser->SetNotMode(TRANSPARENT_MODE); break;

		case 3:
			if (pUser->IsAuthHigher(AUTH_GAMEMASTER2))
			{
				if (pUser->IsMode(MATCHLESS_MODE))
					pUser->SetNotMode(MATCHLESS_MODE | MATCHLESS2_MODE);
				else
				{
					pUser->SetMode(MATCHLESS_MODE);
					pUser->SetNotMode(MATCHLESS2_MODE);
				}
			}
			else
				pUser->SetNotMode(MATCHLESS_MODE | MATCHLESS2_MODE);
			break;
		case 4:
			if (pUser->IsAuthHigher(AUTH_GAMEMASTER2))
			{
				if (pUser->IsMode(MATCHLESS2_MODE))
					pUser->SetNotMode(MATCHLESS_MODE | MATCHLESS2_MODE);
				else
				{
					pUser->SetMode(MATCHLESS2_MODE);
					pUser->SetNotMode(MATCHLESS_MODE);
				}
			}
			else
				pUser->SetNotMode(MATCHLESS_MODE | MATCHLESS2_MODE);
			break;

		case 5: pUser->IsAuthHigher(AUTH_GAMEMASTER2) ? (pUser->IsMode(ONEKILL_MODE) ? pUser->SetNotMode(ONEKILL_MODE) : pUser->SetMode(ONEKILL_MODE)) : pUser->SetNotMode(ONEKILL_MODE); break;
		case 6: pUser->IsAuthHigher(AUTH_GAMEMASTER3) ? (pUser->IsMode(FREE_MONEY_MODE) ? pUser->SetNotMode(FREE_MONEY_MODE) : pUser->SetMode(FREE_MONEY_MODE)) : pUser->SetNotMode(FREE_MONEY_MODE);
			pUser->AddGold(-pUser->GetGold());
			break;
		}
		g_UserMng.AddModifyMode(pUser);
	}
}
#endif // __MODS_MANAGER

#ifdef __BAG_LOOT
void CDPSrvr::OnSelectedBag(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	int nSelect;
	ar >> nSelect;

	if (nSelect >= 0 && nSelect <= 3)
	{
		((CMover*)pUser)->m_nSelectedBag = nSelect;
	}
}
#endif //

#ifdef __JOPS_GLOW

void CDPSrvr::OnGlowCol(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwGlowCol;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	ar >> dwGlowCol;
	CString str;

	if (pUser)
	{
		pUser->m_dwGlowColor = dwGlowCol;

	}
}
#endif

#ifdef __JOPS_GLOW
void CDPSrvr::OnGlowChange(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int iGlowBody, iGlowHandLeft, iGlowHandRight, iGlowArmLeft, iGlowArmRight, iGlowLegLeft, iGlowLegRight;
	DWORD dwGlowColor, dwItem;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	ar >> iGlowBody >> iGlowHandLeft >> iGlowHandRight >> iGlowArmLeft >> iGlowArmRight >> iGlowLegLeft >> iGlowLegRight >> dwGlowColor >> dwItem;
	CString str;


	if (pUser)
	{

		CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwItem);
		if (pItemElem && pItemElem->GetProp()->dwID == 31723)
		{
			pUser->UpdateItem((BYTE)pItemElem->m_dwObjId, UI_NUM, 0);
		}
		else
		{
			pUser->AddText("You dont have the Aura Stone!");
			g_UserMng.UpdateGlow(pUser, pUser->m_iGlowBody, pUser->m_iGlowHandLeft, pUser->m_iGlowHandRight, pUser->m_iGlowArmLeft, pUser->m_iGlowArmRight, pUser->m_iGlowLegLeft, pUser->m_iGlowLegRight, pUser->m_dwGlowColor);
			return;
		}

		if (((CMover*)pUser))
		{
			((CMover*)pUser)->m_iGlowBody = iGlowBody;
			((CMover*)pUser)->m_iGlowHandLeft = iGlowHandLeft;
			((CMover*)pUser)->m_iGlowHandRight = iGlowHandRight;
			((CMover*)pUser)->m_iGlowArmLeft = iGlowArmLeft;
			((CMover*)pUser)->m_iGlowArmRight = iGlowArmRight;
			((CMover*)pUser)->m_iGlowLegLeft = iGlowLegLeft;
			((CMover*)pUser)->m_iGlowLegRight = iGlowLegRight;
			((CMover*)pUser)->m_dwGlowColor = dwGlowColor;
			g_UserMng.UpdateGlow(pUser, iGlowBody, iGlowHandLeft, iGlowHandRight, iGlowArmLeft, iGlowArmRight, iGlowLegLeft, iGlowLegRight, dwGlowColor);
		}
		else
		{
			pUser->AddText("Something went wrong!");
		}
	}
}
#endif

#ifdef MULTIPLE_ITEM_PICKER
void CDPSrvr::OnSendMultipleItemPicker(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	BOOL bEnable;
	ar >> bEnable;

	if (IsValidObj(pUser))
	{
#ifdef __GAMEGUARD
		if (pUser->m_dwMultipleItemPicker + 1000 > GetTickCount())
			return;

		pUser->m_dwMultipleItemPicker = GetTickCount();
#endif // __GAMEGUARD
		if (bEnable)
		{
			pUser->SetMode(MODE_MIP);
		}
		else
		{
			pUser->SetNotMode(MODE_MIP);
		}
		g_UserMng.AddModifyMode(pUser);
	}
}
#endif // MULTIPLE_ITEM_PICKER

#ifdef __ITEM_CONVERTER
void CDPSrvr::OnGetItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
#ifdef __WORLDSERVER_MENU
#ifdef __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE && !pUser->IsAuthHigher(AUTH_GAMEMASTER3))
#else // __GAMEMASTER
		if (CDPSrvr::GetInstance()->m_bExchange == FALSE)
#endif // __GAMEMASTER
		{
			pUser->AddText("");
			return;
		}
#endif // __WORLDSERVER_MENU
		int nGetItem;
		int nNumber;
		ar >> nGetItem >> nNumber;
#ifdef __TABBED_INV
		if (pUser->m_Inventory.GetEmptyCount(0) < 1)
#else // __TABBED_INV
		if (pUser->m_Inventory.GetEmptyCount() < 1)
#endif // __TABBED_INV
		{
			pUser->AddDefinedText(TID_GAME_LACKSPACE);
			return;
		}
		CItemElem item;
		item.m_nItemNum = nNumber;
		int nCost;
		bool bCanBuy = TRUE;
		switch (nGetItem)
		{
		case 1:
		{
			if (nNumber > 20 || nNumber <= 0 || nNumber == NULL)
			{
				pUser->AddText(prj.GetText(TID_REALLY_NIGGA), 0xFFFF0000);
				return;
			}
			item.m_dwItemId = II_SYS_SYS_SCR_PERIN;
			item.m_nItemNum = nNumber;
			nCost = PERIN_VALUE * nNumber;
#ifdef __AUTO_PERIN_CONVERTER
			if (!pUser->IsMode(AUTO_CONVERT_MODE))
				bCanBuy = TRUE;
#else // __AUTO_PERIN_CONVERTER
			bCanBuy = TRUE;
#endif // __AUTO_PERIN_CONVERTER
		}
		break;
		case 2: item.m_dwItemId = II_SYS_SYS_SCR_HOLY; item.m_nItemNum = nNumber; break;
		case 3: item.m_dwItemId = II_CHR_SYS_SCR_ACTIVITION; item.m_nItemNum = nNumber; break;
		case 4: item.m_dwItemId = II_CHR_REF_REF_HOLD; item.m_nItemNum = nNumber; break;
		case 5: item.m_dwItemId = II_CHR_FOO_COO_REMANTIS; item.m_nItemNum = nNumber; break;
		case 6: item.m_dwItemId = II_WEA_SEC_ACR_ARROW; item.m_nItemNum = 9999; break;
		case 7: item.m_dwItemId = II_WEA_SEC_RIN_CHARM; item.m_nItemNum = 9999; break;
		case 8: item.m_dwItemId = II_WEA_SEC_BIL_CHARM; item.m_nItemNum = 9999; break;
		case 9: item.m_dwItemId = II_CHR_POT_DRI_VITALX; item.m_nItemNum = nNumber; break;
		default: Error("CDPSrvr::OnGetItem - %s", pUser->GetName()); bCanBuy = FALSE;  return; break;
		}
		ItemProp* pItemProp = prj.GetItemProp(item.m_dwItemId);
		if (pItemProp && bCanBuy && nNumber >= 1 && nNumber <= 9999 && nNumber != NULL)
		{
			nCost = (pItemProp->dwCost) * nNumber;
			if (pUser->GetGold() >= nCost)
			{
				if (pUser->CreateItem(&item))
					pUser->AddGold(-nCost);
			}
			else
				pUser->AddDefinedText(TID_GAME_GUILDHOUSE_BUY_EXPENSE);
		}
		else
			pUser->AddText(prj.GetText(TID_REALLY_NIGGA), 0xFFFF0000);
	}

}
#endif // __ITEM_CONVERTER

#ifdef __PET_FILTER
void CDPSrvr::OnSetPetfilter(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (pUser)
	{
		DWORD dwPetFilter;
		ar >> dwPetFilter;
		pUser->m_dwPetfilter = dwPetFilter;
	}
}
#endif // __PET_FILTER

#ifdef __WEAPON_RARITY
void CDPSrvr::OnUpdateWeaponRarity(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		DWORD dwId1, dwId2; ar >> dwId1 >> dwId2;
		CItemElem* pItem1 = NULL, * pItem2 = NULL; pItem1 = pUser->m_Inventory.GetAtId(dwId1); pItem2 = pUser->m_Inventory.GetAtId(dwId2);

		if (!pItem1 || !pItem2 || pUser->IsUsing(pItem1) || pUser->IsUsing(pItem2)
			|| !IsValidItem(pItem1->GetProp()->dwItemKind3) || !IsValidItem(pItem2->GetProp()->dwItemKind3))
		{
			pUser->AddDefinedText(TID_WR_TEXT_004);
			return;
		}
		if (pItem1->GetProp()->dwID != pItem2->GetProp()->dwID)
		{
			pUser->AddDefinedText(TID_WR_TEXT_006);
			return;
		}
		if (pItem1->GetWeaponRarity() >= prj.m_nHighWeaponRarityLevel || pItem2->GetWeaponRarity() >= prj.m_nHighWeaponRarityLevel
			|| (pItem1->GetWeaponRarity() != pItem2->GetWeaponRarity()))
		{
			pUser->AddDefinedText(TID_WR_TEXT_007);
			return;
		}
		if (pUser->GetGold() < (int)prj.m_dwUpgradePrice)
		{
			pUser->AddDefinedText(TID_GAME_LACKMONEY);
			return;
		}
		pUser->AddGold(-(int)(prj.m_dwUpgradePrice));

		int nRandom = xRandom(100);
		WeaponRarity* nWeaponRarity = prj.m_nWeaponRarity.GetAt(pItem1->GetWeaponRarity());
		if (nWeaponRarity && nRandom >= 0 && nRandom < nWeaponRarity->m_fUpgradeRate)
		{
			pUser->AddDefinedText(TID_WR_TEXT_010);
			pItem1->SetWeaponRarity(pItem1->GetWeaponRarity() + 1);
			pUser->UpdateItem((BYTE)pItem2->m_dwObjId, UI_NUM, pItem2->m_nItemNum - 1);
			pUser->AddWeaponRarity(pItem1->m_dwObjId, pItem1->GetWeaponRarity() + 1);

			if (pUser->HasBuff(BUFF_ITEM, II_SYS_SCR_RPROTECT))
				pUser->RemoveBuff(BUFF_ITEM, II_SYS_SCR_RPROTECT);

			nWeaponRarity = prj.m_nWeaponRarity.GetAt(pItem1->GetWeaponRarity());
			if (nWeaponRarity->m_bReflect)
			{
				pItem1->SetFlag(CItemElem::reflect);
				pUser->UpdateItem((BYTE)pItem1->m_dwObjId, UI_FLAG, MAKELONG(pItem1->m_dwObjIndex, pItem1->m_byFlag));
			}

			pUser->AddSfxSnd(XI_INT_SUCCESS, SND_INF_UPGRADESUCCESS);
		}
		else
		{
			pUser->AddDefinedText(TID_WR_TEXT_009);
			if (!pUser->HasBuff(BUFF_ITEM, II_SYS_SCR_RPROTECT))
			{
				pUser->UpdateItem((BYTE)pItem1->m_dwObjId, UI_NUM, pItem1->m_nItemNum - 1);
				pUser->UpdateItem((BYTE)pItem2->m_dwObjId, UI_NUM, pItem2->m_nItemNum - 1);
			}
			else
				pUser->RemoveBuff(BUFF_ITEM, II_SYS_SCR_RPROTECT);

			pUser->AddSfxSnd(XI_INT_FAIL, SND_INF_UPGRADEFAIL);
		}
	}
}
#endif // __WEAPON_RARITY

#ifdef __NAME_COLOR
void CDPSrvr::OnNameCol(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
		DWORD dwNameCol;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	ar >> dwNameCol;

	if (IsValidObj(pUser))
	{
		((CMover*)pUser)->m_dwNameColor = dwNameCol;
		g_UserMng.AddNameCol(pUser, dwNameCol);
	}
}
#ifdef __NAME_FONT
void CDPSrvr::OnNameFont(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
		DWORD dwNameFont;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	ar >> dwNameFont;

	if (IsValidObj(pUser))
	{
		if (dwNameFont >= 0 && dwNameFont <= 8)
		{
#ifdef __GAMEMASTER
			if (!pUser->IsAuthHigher(AUTH_GAMEMASTER) && dwNameFont == 8)
				dwNameFont = 0;
#endif // __GAMEMASTER			
			((CMover*)pUser)->m_nNameFont = dwNameFont;
			g_UserMng.AddNameFont(pUser, dwNameFont);
		}
	}
}
#endif // __NAME_FONT
#endif // __NAME_COLOR

#ifdef __GUILD_BUFF
void CDPSrvr::OnBuffGuildByAPP(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	try {	
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
		CMover* pMover = pUser;
		int nCurSel;
		int nGold;
		nGold = 0;
		int valid = 0;
		ar >> nCurSel;
		CCtrl* pCtrl = (CCtrl*)pMover;
		CGuild* pGuild = pUser->GetGuild();
		if (IsValidObj(pUser))
		{
			if (pGuild)
			{
				switch (nCurSel)
				{
				case 0:
				{
					if (pUser->GetGuild() != NULL)
					{
						if (pUser->GetGuild()->m_nLevel >= 5)
						{
							if (!pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_GUILDBUFF1))

							{

								CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
								// DWORD pItem1, pItem2;
								// ar >> pItem1 >> pItem2;
								if (IsValidObj(pUser))
								{
									//CItemElem *     pItemElem = pUser->m_Inventory.GetAtId( pItem1 );
									//CItemElem *     pItemElem2 = pUser->m_Inventory.GetAtId( pItem2 );
									CItemElem* pItemElem3 = pUser->m_Inventory.GetAtItemId(II_SYS_SYS_SCR_PERIN);

									if (!pItemElem3)
									{
										pUser->AddText("You need 1 perin to receive a guild buff.");
										return;
									}

									pUser->UpdateItem((BYTE)(pItemElem3->m_dwObjId), UI_NUM, pItemElem3->m_nItemNum - 1);
									pUser->AddText("Hale has been activated.");
								}

								ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_SCR_GUILDBUFF1);
								if (pProp)
								{
									pUser->DoApplySkill(pUser, pProp, NULL);


								}
							}
						}
					}
				}
				break;
				case 1:
				{
					if (pUser->GetGuild() != NULL)
					{
						if (pUser->GetGuild()->m_nLevel >= 10)
						{
							if (!pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_GUILDBUFF2))
							{
								CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
								// DWORD pItem1, pItem2;
								// ar >> pItem1 >> pItem2;
								if (IsValidObj(pUser))
								{
									//CItemElem *     pItemElem = pUser->m_Inventory.GetAtId( pItem1 );
									//CItemElem *     pItemElem2 = pUser->m_Inventory.GetAtId( pItem2 );
									CItemElem* pItemElem3 = pUser->m_Inventory.GetAtItemId(II_SYS_SYS_SCR_PERIN);

									if (!pItemElem3)
									{
										pUser->AddText("You need 1 perin to receive a guild buff.");
										return;
									}

									pUser->UpdateItem((BYTE)(pItemElem3->m_dwObjId), UI_NUM, pItemElem3->m_nItemNum - 1);
									pUser->AddText("Tenacity has been activated.");
								}
								ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_SCR_GUILDBUFF2);
								if (pProp)
								{
									pUser->DoApplySkill(pUser, pProp, NULL);
								}
							}
						}
					}
				}
				break;
				case 2:
				{
					if (pUser->GetGuild() != NULL)
					{
						if (pUser->GetGuild()->m_nLevel >= 15)
						{

							if (!pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_GUILDBUFF3))
							{
								CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
								// DWORD pItem1, pItem2;
								// ar >> pItem1 >> pItem2;
								if (IsValidObj(pUser))
								{
									//CItemElem *     pItemElem = pUser->m_Inventory.GetAtId( pItem1 );
								   // CItemElem *     pItemElem2 = pUser->m_Inventory.GetAtId( pItem2 );
									CItemElem* pItemElem3 = pUser->m_Inventory.GetAtItemId(II_SYS_SYS_SCR_PERIN);

									if (!pItemElem3)
									{
										pUser->AddText("You need 1 perin to receive a guild buff.");
										return;
									}

									pUser->UpdateItem((BYTE)(pItemElem3->m_dwObjId), UI_NUM, pItemElem3->m_nItemNum - 1);
									pUser->AddText("Celerity has been activated.");
								}
								ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_SCR_GUILDBUFF3);
								if (pProp)
								{
									pUser->DoApplySkill(pUser, pProp, NULL);


								}
							}
						}
					}
				}

				break;
				case 3:
				{
					if (pUser->GetGuild() != NULL)
					{
						if (pUser->GetGuild()->m_nLevel >= 20)
						{

							if (!pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_GUILDBUFF4))
							{
								CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
								// DWORD pItem1, pItem2;
								// ar >> pItem1 >> pItem2;
								if (IsValidObj(pUser))
								{
									//CItemElem *     pItemElem = pUser->m_Inventory.GetAtId( pItem1 );
								   // CItemElem *     pItemElem2 = pUser->m_Inventory.GetAtId( pItem2 );
									CItemElem* pItemElem3 = pUser->m_Inventory.GetAtItemId(II_SYS_SYS_SCR_PERIN);

									if (!pItemElem3)
									{
										pUser->AddText("You need 1 perin to receive a guild buff.");
										return;
									}

									pUser->UpdateItem((BYTE)(pItemElem3->m_dwObjId), UI_NUM, pItemElem3->m_nItemNum - 1);
									pUser->AddText("Vision has been activated.");
								}
								ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_SCR_GUILDBUFF4);
								if (pProp)
								{
									pUser->DoApplySkill(pUser, pProp, NULL);

								}
							}
						}
					}
				}
				break;
				case 4:
				{
					if (pUser->GetGuild() != NULL)
					{
						if (pUser->GetGuild()->m_nLevel >= 25)
						{
							if (!pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_GUILDBUFF5))
							{
								CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
								// DWORD pItem1, pItem2;
								// ar >> pItem1 >> pItem2;
								if (IsValidObj(pUser))
								{
									//CItemElem *     pItemElem = pUser->m_Inventory.GetAtId( pItem1 );
									//CItemElem *     pItemElem2 = pUser->m_Inventory.GetAtId( pItem2 );
									CItemElem* pItemElem3 = pUser->m_Inventory.GetAtItemId(II_SYS_SYS_SCR_PERIN);

									if (!pItemElem3)
									{
										pUser->AddText("You need 1 perin to receive a guild buff.");
										return;
									}

									pUser->UpdateItem((BYTE)(pItemElem3->m_dwObjId), UI_NUM, pItemElem3->m_nItemNum - 1);
									pUser->AddText("Gravel has been activated.");
								}
								ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_SCR_GUILDBUFF5);
								if (pProp)
								{
									pUser->DoApplySkill(pUser, pProp, NULL);
								}
							}
						}
					}
				}

				break;
				case 5:
				{
					if (pUser->GetGuild() != NULL)
					{
						if (pUser->GetGuild()->m_nLevel >= 30)
						{
							if (!pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_GUILDBUFF6))
							{
								CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
								// DWORD pItem1, pItem2;
								// ar >> pItem1 >> pItem2;
								if (IsValidObj(pUser))
								{
									//CItemElem *     pItemElem = pUser->m_Inventory.GetAtId( pItem1 );
								   // CItemElem *     pItemElem2 = pUser->m_Inventory.GetAtId( pItem2 );
									CItemElem* pItemElem3 = pUser->m_Inventory.GetAtItemId(II_SYS_SYS_SCR_PERIN);

									if (!pItemElem3)
									{
										pUser->AddText("You need 1 perin to receive a guild buff.");
										return;
									}

									pUser->UpdateItem((BYTE)(pItemElem3->m_dwObjId), UI_NUM, pItemElem3->m_nItemNum - 1);
									pUser->AddText("Hazard has been activated.");
								}
								ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_SCR_GUILDBUFF6);
								if (pProp)
								{
									pUser->DoApplySkill(pUser, pProp, NULL);
								}
							}
						}
					}
				}

				break;
				case 6:
				{
					if (pUser->GetGuild() != NULL)
					{
						if (pUser->GetGuild()->m_nLevel >= 35)
						{
							if (!pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_GUILDBUFF7))
							{
								CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
								//DWORD pItem1, pItem2;
								//ar >> pItem1 >> pItem2;
								if (IsValidObj(pUser))
								{
									//CItemElem *     pItemElem = pUser->m_Inventory.GetAtId( pItem1 );
								   // CItemElem *     pItemElem2 = pUser->m_Inventory.GetAtId( pItem2 );
									CItemElem* pItemElem3 = pUser->m_Inventory.GetAtItemId(II_SYS_SYS_SCR_PERIN);

									if (!pItemElem3)
									{
										pUser->AddText("You need 1 perin to receive a guild buff.");
										return;
									}

									pUser->UpdateItem((BYTE)(pItemElem3->m_dwObjId), UI_NUM, pItemElem3->m_nItemNum - 1);
									pUser->AddText("Strike has been activated.");
								}
								ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_SCR_GUILDBUFF7);
								if (pProp)
								{
									pUser->DoApplySkill(pUser, pProp, NULL);
								}
							}
						}
					}
				}

				break;
				case 7:
				{
					if (pUser->GetGuild() != NULL)
					{
						if (pUser->GetGuild()->m_nLevel >= 40)
						{
							if (!pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_GUILDBUFF8))
							{
								CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
								// DWORD pItem1, pItem2;
								// ar >> pItem1 >> pItem2;
								if (IsValidObj(pUser))
								{
									//CItemElem *     pItemElem = pUser->m_Inventory.GetAtId( pItem1 );
								  //  CItemElem *     pItemElem2 = pUser->m_Inventory.GetAtId( pItem2 );
									CItemElem* pItemElem3 = pUser->m_Inventory.GetAtItemId(II_SYS_SYS_SCR_PERIN);

									if (!pItemElem3)
									{
										pUser->AddText("You need 1 perin to receive a guild buff.");
										return;
									}

									pUser->UpdateItem((BYTE)(pItemElem3->m_dwObjId), UI_NUM, pItemElem3->m_nItemNum - 1);
									pUser->AddText("Crack has been activated.");
								}
								ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_SCR_GUILDBUFF8);
								if (pProp)
								{
									pUser->DoApplySkill(pUser, pProp, NULL);
								}
							}
						}
					}
				}

				break;
				case 8:
				{
					if (pUser->GetGuild() != NULL)
					{
						if (pUser->GetGuild()->m_nLevel >= 45)
						{
							if (!pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_GUILDBUFF9))
							{
								CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
								// DWORD pItem1, pItem2;
								// ar >> pItem1 >> pItem2;
								if (IsValidObj(pUser))
								{
									//CItemElem *     pItemElem = pUser->m_Inventory.GetAtId( pItem1 );
									//CItemElem *     pItemElem2 = pUser->m_Inventory.GetAtId( pItem2 );
									CItemElem* pItemElem3 = pUser->m_Inventory.GetAtItemId(II_SYS_SYS_SCR_PERIN);

									if (!pItemElem3)
									{
										pUser->AddText("You need 1 perin to receive a guild buff.");
										return;
									}

									pUser->UpdateItem((BYTE)(pItemElem3->m_dwObjId), UI_NUM, pItemElem3->m_nItemNum - 1);
									pUser->AddText("Urge has been activated.");
								}
								ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_SCR_GUILDBUFF9);
								if (pProp)
								{
									pUser->DoApplySkill(pUser, pProp, NULL);
								}
							}
						}
					}
				}

				break;
				case 9:
				{

					if (pUser->GetGuild() != NULL)
					{
						if (pUser->GetGuild()->m_nLevel >= 50)
						{
							if (!pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_GUILDBUFF10))
							{
								CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
								//DWORD pItem1, pItem2;
								//ar >> pItem1 >> pItem2;
								if (IsValidObj(pUser))
								{
									//CItemElem *     pItemElem = pUser->m_Inventory.GetAtId( pItem1 );
									//CItemElem *     pItemElem2 = pUser->m_Inventory.GetAtId( pItem2 );
									CItemElem* pItemElem3 = pUser->m_Inventory.GetAtItemId(II_SYS_SYS_SCR_PERIN);

									if (!pItemElem3)
									{
										pUser->AddText("You need 1 perin to receive a guild buff.");
										return;
									}

									pUser->UpdateItem((BYTE)(pItemElem3->m_dwObjId), UI_NUM, pItemElem3->m_nItemNum - 1);
									pUser->AddText("Fury has been activated.");
								}
								ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_SCR_GUILDBUFF10);
								if (pProp)
								{
									pUser->DoApplySkill(pUser, pProp, NULL);
								}
							}
						}
					}
				}

				break;
				default: Error("Error Guild Buff - %s", pUser->GetName()); return;
				}
			}
			else
			{
				pUser->AddDefinedText(TID_GUILD_NO_LVL);
			}
		}
	}
	catch (...)
	{
		Error("Error %s(%d)", __LINE__, __FILE__);
	}
}
#endif// __GUILD_BUFF

#ifdef __AUTO_PERIN_CONVERTER
void CDPSrvr::OnConvertPerin(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	BOOL bEnable;
	ar >> bEnable;

	if (IsValidObj(pUser))
	{
#ifdef __GAMEGUARD
		if (pUser->m_dwAutoPerinConverter + 1000 > GetTickCount())
			return;

		pUser->m_dwAutoPerinConverter = GetTickCount();
#endif // __GAMEGUARD
		if (bEnable)
		{
			pUser->SetMode(AUTO_CONVERT_MODE);
			pUser->AddText(prj.GetText(TID_AUTO_CONVERTER_ON));
		}
		else
		{
			pUser->SetNotMode(AUTO_CONVERT_MODE);
			pUser->AddText(prj.GetText(TID_AUTO_CONVERTER_OFF), 0xFFFF0000);
		}
		g_UserMng.AddModifyMode(pUser);
	}
}
#endif // __AUTO_PERIN_CONVERTER

#ifdef __PARTY_FIND
void CDPSrvr::OnPartyList(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		vector<PARTYFINDER_LIST> vectmp;
		int nCount = 0;

		for (C2PartyPtr::iterator i = g_PartyMng.m_2PartyPtr.begin(); i != g_PartyMng.m_2PartyPtr.end(); i++)
		{
			CParty* pParty = (CParty*)i->second;

			if (!pParty)
				continue;

			if (pParty->GetLeader())
			{
				if (!pParty->GetLeader()->m_bPartyJoin)
					continue;
			}

			if (pParty->GetSizeofMember() < MAX_PTMEMBER_SIZE_SPECIAL)
			{
				PARTYFINDER_LIST partytmp;

				partytmp.m_uPartyId = pParty->m_uPartyId;
				strcpy(partytmp.m_sParty, strlen(pParty->m_sParty) > 3 ? pParty->m_sParty : prj.GetText(TID_APP_PARTY));
				partytmp.m_nSizeofMember = pParty->m_nSizeofMember;
				partytmp.m_nLevel = pParty->m_nLevel;
				partytmp.m_nPoint = pParty->m_nPoint;

				PlayerData* pPlayerData = CPlayerDataCenter::GetInstance()->GetPlayerData(pParty->m_aMember[0].m_uPlayerId);
				if (pPlayerData)
				{
					partytmp.m_nLeaderId = pParty->m_aMember[0].m_uPlayerId;
					sprintf(partytmp.m_sPartyList, "%s, ", pPlayerData->szPlayer);
					strcpy(partytmp.m_sLeader, pPlayerData->szPlayer);
				}
				else
				{
					sprintf(partytmp.m_sPartyList, "N/A, ");
					strcpy(partytmp.m_sLeader, "N/A");
				}

				for (int i = 1; i < pParty->GetSizeofMember(); i++)
				{
					PlayerData* pPlayerData = CPlayerDataCenter::GetInstance()->GetPlayerData(pParty->m_aMember[i].m_uPlayerId);

					if (!pPlayerData)
						continue;

					strcat(partytmp.m_sPartyList, pPlayerData->szPlayer);
					strcat(partytmp.m_sPartyList, ", ");
				}
				partytmp.m_bLinkAttack = pParty->m_nModeTime[PARTY_LINKATTACK_MODE] ? true : false;
				partytmp.m_bFortuneCircle = pParty->m_nModeTime[PARTY_FORTUNECIRCLE_MODE] ? true : false;
				partytmp.m_bGiftBox = pParty->m_nModeTime[PARTY_GIFTBOX_MODE] ? true : false;
				CUser* pLeader = g_UserMng.GetUserByPlayerID(pParty->m_aMember[0].m_uPlayerId);
				if (IsValidObj(pLeader))
				{
					partytmp.m_bSkillFull = (pLeader->IsSMMode(SM_PARTYSKILL1) || pLeader->IsSMMode(SM_PARTYSKILL15) || pLeader->IsSMMode(SM_PARTYSKILL30)) ? true : false;
					partytmp.m_bExpUp = (pLeader->HasBuff(BUFF_ITEM2, II_SYS_SYS_SCR_PARTYEXPUP01_01) || pLeader->HasBuff(BUFF_ITEM2, II_SYS_SYS_SCR_PARTYEXPUP01) || pLeader->HasBuff(BUFF_ITEM2, II_SYS_SYS_SCR_PARTYEXPUP02)) ? true : false;
					partytmp.m_bSkillUp = (pLeader->HasBuff(BUFF_ITEM2, II_SYS_SYS_SCR_PARTYSKILLUP01) || pLeader->HasBuff(BUFF_ITEM2, II_SYS_SYS_SCR_PARTYSKILLUP02) || pLeader->HasBuff(BUFF_ITEM2, II_SYS_SYS_SCR_PARTYSKILLUP01_01)) ? true : false;
					partytmp.m_bSkillIllimited = (pLeader->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_PARTYPOINTFREE01) || pLeader->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_PARTYPOINTFREE02) || pLeader->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_PARTYPOINTFREE03)) ? true : false;
				}
				vectmp.push_back(partytmp);
				nCount++;
			}
		}
		pUser->AddPartyList(vectmp, nCount);
		vectmp.clear();
	}
}

void CDPSrvr::OnPartyAllowJoin(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		int nMode;
		ar >> nMode;
		CParty* pParty = g_PartyMng.GetParty(pUser->GetPartyId());
		if (pParty)
		{
			if (!pParty->IsLeader(pUser->m_idPlayer))
				return;

			pUser->m_bPartyJoin = nMode;
			pUser->AddPartyChangeJoinMode(pUser->m_bPartyJoin);

			for (int i = 1; i < pParty->GetSizeofMember(); i++)
			{
				CUser* pMember = (CUser*)prj.GetUserByID(pParty->m_aMember[i].m_uPlayerId);
				if (IsValidObj(pMember))
					pMember->AddPartyChangeJoinMode(pUser->m_bPartyJoin);
			}
		}
	}
}
#endif // __PARTY_FIND

#ifdef __UPGRADE
void CDPSrvr::OnUpgrade(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) && pUser->IsAuthHigher(AUTH_GAMEMASTER3))
	{
		DWORD dwId1;
		ar >> dwId1;

		CItemElem* pItem = pUser->m_Inventory.GetAtId(dwId1);
		if (IsUsableItem(pItem) && !pUser->IsUsing(pItem) && !pUser->m_Inventory.IsEquip(dwId1))
		{
			bool bSuccess = FALSE;

			BYTE nElem;
			ar >> nElem;

			short nElemLv, nLv, nPiercing;
			ar >> nElemLv >> nLv >> nPiercing;

			if (pItem->GetProp()->dwItemKind3 == IK3_HELMET
				|| pItem->GetProp()->dwItemKind3 == IK3_SUIT
				|| pItem->GetProp()->dwItemKind3 == IK3_GAUNTLET
				|| pItem->GetProp()->dwItemKind3 == IK3_BOOTS
				|| pItem->GetProp()->dwItemKind3 == IK3_SWD
				|| pItem->GetProp()->dwItemKind3 == IK3_AXE
				|| pItem->GetProp()->dwItemKind3 == IK3_KNUCKLEHAMMER
				|| pItem->GetProp()->dwItemKind3 == IK3_CHEERSTICK
				|| pItem->GetProp()->dwItemKind3 == IK3_WAND
				|| pItem->GetProp()->dwItemKind3 == IK3_STAFF
				|| pItem->GetProp()->dwItemKind3 == IK3_BOW
				|| pItem->GetProp()->dwItemKind3 == IK3_YOYO
				|| pItem->GetProp()->dwItemKind3 == IK3_SHIELD
#ifdef __CROSSBOW
				|| pItem->GetProp()->dwItemKind3 == IK3_CROSSBOW
#endif // __CROSSBOW
#ifdef __BARUNA
				|| pItem->GetProp()->dwItemKind3 == IK3_MAGICBARUNA
				|| pItem->GetProp()->dwItemKind3 == IK3_ZEMBARUNA
#endif // __BARUNA
#ifdef __CLASS_RELIC
				|| pItem->GetProp()->dwID == II_WEA_UNLIMITED_ARROW
				|| pItem->GetProp()->dwID == II_WEA_UNLIMITED_BIL_CHARM
				|| pItem->GetProp()->dwID == II_WEA_UNLIMITED_RIN_CHARM
				|| pItem->GetProp()->dwID == II_VOLDS_KNIGT_RELIC
				|| pItem->GetProp()->dwID == II_VOLDS_BLADE_RELIC
				|| pItem->GetProp()->dwID == II_VOLDS_ELEME_RELIC
				|| pItem->GetProp()->dwID == II_VOLDS_PSYKE_RELIC
				|| pItem->GetProp()->dwID == II_VOLDS_HARLE_RELIC
				|| pItem->GetProp()->dwID == II_WEA_UNLIMITED_ARROW2
				|| pItem->GetProp()->dwID == II_WEA_UNLIMITED_BIL_CHARM2
				|| pItem->GetProp()->dwID == II_WEA_UNLIMITED_RIN_CHARM2
				|| pItem->GetProp()->dwID == II_VOLDS_KNIGT_RELIC2
				|| pItem->GetProp()->dwID == II_VOLDS_BLADE_RELIC2
				|| pItem->GetProp()->dwID == II_VOLDS_ELEME_RELIC2
				|| pItem->GetProp()->dwID == II_VOLDS_PSYKE_RELIC2
				|| pItem->GetProp()->dwID == II_VOLDS_HARLE_RELIC2
#endif // __CLASS_RELIC
				)
			{
				if (nElem > 0 && nElem <= 5)
				{
					pUser->UpdateItem((BYTE)(pItem->m_dwObjId), UI_IR, nElem);
					pUser->UpdateItem((BYTE)(pItem->m_dwObjId), UI_RAO, nElemLv);
					bSuccess = TRUE;
				}
				else
				{
					pUser->UpdateItem((BYTE)(pItem->m_dwObjId), UI_IR, 0);
					pUser->UpdateItem((BYTE)(pItem->m_dwObjId), UI_RAO, 0);
					bSuccess = TRUE;
				}
				if (nLv >= 0)
				{
					if (nLv > 20)
						nLv = 20;

					pUser->UpdateItem((BYTE)(pItem->m_dwObjId), UI_AO, nLv);
#if __VER >= 9 // __ULTIMATE
					if (nLv > 5 && pItem->GetProp()->dwReferStat1 == WEAPON_ULTIMATE)
						pUser->UpdateItem((BYTE)pItem->m_dwObjId, UI_ULTIMATE_PIERCING_SIZE, (nLv <= 10 ? nLv - 0 : MAX_PIERCING_ULTIMATE));
#endif // __ULTIMATE
					bSuccess = TRUE;
				}
				if (nPiercing >= 0)
				{
					if (nPiercing > (pItem->GetProp()->dwItemKind3 == IK3_SUIT ? MAX_PIERCING_SUIT : MAX_PIERCING_WEAPON))
						nPiercing = (pItem->GetProp()->dwItemKind3 == IK3_SUIT ? MAX_PIERCING_SUIT : MAX_PIERCING_WEAPON);

					pUser->UpdateItem((BYTE)pItem->m_dwObjId, UI_PIERCING_SIZE, nPiercing);
					bSuccess = TRUE;
				}
			}
			else if (nLv >= 0 && (pItem->GetProp()->dwItemKind2 == IK2_JEWELRY || pItem->GetProp()->dwID == II_GEN_TOO_COL_NORMAL))
			{
				if (nLv > 20)
					nLv = 20;

				pUser->UpdateItem((BYTE)(pItem->m_dwObjId), UI_AO, nLv);
				bSuccess = TRUE;
			}
			else
				pUser->AddText(prj.GetText(TID_GAME_SMELT_SAFETY_ERROR01));

			if (bSuccess)
			{
				pUser->AddSfxSnd(XI_INT_SUCCESS, SND_INF_UPGRADESUCCESS);
			}
		}
		else
			pUser->AddText(prj.GetText(TID_UPGRADE_CANCLE));
	}
}
#endif // __UPGRADE

#ifdef __PLAYERS_MENU
void CDPSrvr::OnSendPlayer(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		char szPlayer[MAX_PLAYER] = { 0, };
		ar.ReadString(szPlayer, MAX_PLAYER);
		u_long idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(szPlayer);
		CUser* pUserTarget = g_UserMng.GetUserByPlayerID(idPlayer);

		if (pUser == pUserTarget)
		{
			pUser->AddText(prj.GetText(TID_REALLY_NIGGA), 0xFFFF0000);
			return;
		}
		int nAction;
		ar >> nAction;

		if (idPlayer > 0)
		{
			if (IsValidObj(pUserTarget))
			{
				CString str[2];
				switch (nAction)
				{
				case 0:
					if (pUser->IsAuthHigher(AUTH_GAMEMASTER2))
					{
						if (pUserTarget->m_dwAuthorization < pUser->m_dwAuthorization)
						{
							g_DPCoreClient.SendKillPlayer(pUser->m_idPlayer, idPlayer);
							str[0].Format(prj.GetText(TID_CMD_OUT_01), pUserTarget->GetName(), pUserTarget->GetAuthStr(TRUE));
							pUser->AddText(str[0]);
						}
						else
						{
							str[0].Format(prj.GetText(TID_CMD_OUT_02), pUserTarget->GetName(), pUserTarget->GetAuthStr(TRUE));
							pUser->AddText(str[0]);

							str[1].Format(prj.GetText(TID_CMD_OUT_03), pUser->GetName(), pUser->GetAuthStr(TRUE));
							pUserTarget->AddText(str[1]);
						}
					}
					break;
				case 1:
					if (pUser->IsAuthHigher(AUTH_GAMEMASTER2))
					{
						if (pUserTarget->m_dwAuthorization < pUser->m_dwAuthorization)
						{
							pUserTarget->m_dwMute = 3600;

							str[0].Format(prj.GetText(TID_CMD_MUTE_01), pUserTarget->GetName(), pUserTarget->GetAuthStr(TRUE));
							pUser->AddText(str[0]);

							str[1].Format(prj.GetText(TID_CMD_MUTE_02), pUser->GetName(), pUser->GetAuthStr(TRUE), 3600);
							pUserTarget->AddText(str[1]);
						}
						else
						{
							str[0].Format(prj.GetText(TID_CMD_MUTE_05), pUserTarget->GetName(), pUserTarget->GetAuthStr(TRUE));
							pUser->AddText(str[0]);

							str[1].Format(prj.GetText(TID_CMD_MUTE_06), pUser->GetName(), pUser->GetAuthStr(TRUE));
							pUserTarget->AddText(str[1]);
						}
					}
					break;
#ifdef __MAC_BAN
				case 2:
					if (pUser->IsAuthHigher(AUTH_GAMEMASTER2))
					{
						if (pUserTarget->m_dwAuthorization <= pUser->m_dwAuthorization)
						{
							str[0].Format(prj.GetText(TID_CMD_BAN_01), pUserTarget->GetName(), pUserTarget->GetAuthStr(TRUE));
							pUser->AddText(str[0]);

							g_dpDBClient.SendBan(pUserTarget->m_playAccount.lpszAccount, 1);
							g_DPSrvr.QueryDestroyPlayer(pUserTarget->m_Snapshot.dpidCache, pUserTarget->m_Snapshot.dpidUser, pUserTarget->m_dwSerial, pUserTarget->m_idPlayer);
						}
						else
						{
							str[0].Format(prj.GetText(TID_CMD_BAN_02), pUserTarget->GetName(), pUserTarget->GetAuthStr(TRUE));
							pUser->AddText(str[0]);

							str[1].Format(prj.GetText(TID_CMD_BAN_03), pUser->GetName(), pUser->GetAuthStr(TRUE));
							pUserTarget->AddText(str[1]);
						}
					}
					break;
				case 3:
					if (pUser->IsAuthHigher(AUTH_GAMEMASTER3))
					{
						if (pUserTarget->m_dwAuthorization < pUser->m_dwAuthorization)
						{
							str[0].Format(prj.GetText(TID_CMD_MAC_BAN_01), pUserTarget->GetName(), pUserTarget->GetAuthStr(TRUE));
							pUser->AddText(str[0]);
							g_dpDBClient.SendMacBan(pUserTarget->m_playAccount.lpszAccount);
							g_dpDBClient.SendBan(pUserTarget->m_playAccount.lpszAccount, 99999);
							g_DPSrvr.QueryDestroyPlayer(pUserTarget->m_Snapshot.dpidCache, pUserTarget->m_Snapshot.dpidUser, pUserTarget->m_dwSerial, pUserTarget->m_idPlayer);
						}
						else
						{
							str[0].Format(prj.GetText(TID_CMD_MAC_BAN_02), pUserTarget->GetName(), pUserTarget->GetAuthStr(TRUE));
							pUser->AddText(str[0]);

							str[1].Format(prj.GetText(TID_CMD_MAC_BAN_03), pUser->GetName(), pUser->GetAuthStr(TRUE));
							pUserTarget->AddText(str[1]);
						}
					}
					break;
#endif // __MAC_BAN					
				case 4:
					if (pUser->IsAuthHigher(AUTH_ADMINISTRATOR))
					{
						if (pUserTarget->m_dwAuthorization < pUser->m_dwAuthorization)
						{
							g_DPCoreClient.SendGetPlayerAddr(pUser->m_idPlayer, idPlayer);
							str[0].Format(prj.GetText(TID_CMD_IP_01), pUserTarget->GetName(), pUserTarget->GetAuthStr(TRUE));
							pUser->AddText(str[0]);

#ifndef __GAMEMASTER
							str[1].Format(prj.GetText(TID_CMD_IP_02), pUser->GetName(), pUser->GetAuthStr(TRUE));
							pUserTarget->AddText(str[1]);
#endif // __GAMEMASTER
						}
						else
						{
							str[0].Format(prj.GetText(TID_CMD_IP_03), pUserTarget->GetName(), pUserTarget->GetAuthStr(TRUE));
							pUser->AddText(str[0]);

							str[1].Format(prj.GetText(TID_CMD_IP_04), pUser->GetName(), pUser->GetAuthStr(TRUE));
							pUserTarget->AddText(str[1]);
						}
					}
					break;
				}
			}
			else
				pUser->AddReturnSay(4, szPlayer);
		}
		else
			pUser->AddReturnSay(3, szPlayer);
	}
}
#endif // __PLAYERS_MENU

#ifdef __PLAYER_LIST
void CDPSrvr::OnPlayerListRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->m_dwPlayerList + 500 > GetTickCount())
		{
			pUser->AddText(prj.GetText(TID_PLAYER_LIST_ERR_04), 0xFFFF0000);
			return;
		}
		pUser->m_dwPlayerList = GetTickCount();

		BOOL bCheck[17];
		for (int i = 0; i < 17; i++)
			ar >> bCheck[i];

		int nMin, nMax;
		ar >> nMin >> nMax;

		TCHAR search[32];
		ar.ReadString(search, 32);

		int nTotal = 0;
		for (auto const& user : g_UserMng.m_users)
		{
			if (IsValidObj(user.second))
			{
				if (bCheck[0] == FALSE && user.second->m_dwAuthorization == AUTH_GENERAL)
					continue;
				if (bCheck[1] == FALSE && user.second->m_dwAuthorization > AUTH_GENERAL)
					continue;
				if (bCheck[2] == FALSE && user.second->GetJob() == JOB_MERCENARY)
					continue;
				if (bCheck[3] == FALSE && (user.second->GetJob() == JOB_KNIGHT || user.second->GetJob() == JOB_KNIGHT_MASTER || user.second->GetJob() == JOB_KNIGHT_HERO
#ifdef __3RD_LEGEND16
					|| user.second->GetJob() == JOB_LORDTEMPLER_HERO
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
					|| user.second->GetJob() == JOB_LORDTEMPLER_HERO_ULTIMATE
#endif // __NEWCLASS
					))
				{
					continue;
				}
				if (bCheck[4] == FALSE && (user.second->GetJob() == JOB_BLADE || user.second->GetJob() == JOB_BLADE_MASTER || user.second->GetJob() == JOB_BLADE_HERO
#ifdef __3RD_LEGEND16
					|| user.second->GetJob() == JOB_STORMBLADE_HERO
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
					|| user.second->GetJob() == JOB_STORMBLADE_HERO_ULTIMATE
#endif // __NEWCLASS
					))
				{
					continue;
				}
				if (bCheck[5] == FALSE && user.second->GetJob() == JOB_ACROBAT)
					continue;
				if (bCheck[6] == FALSE && (user.second->GetJob() == JOB_JESTER || user.second->GetJob() == JOB_JESTER_MASTER || user.second->GetJob() == JOB_JESTER_HERO
#ifdef __3RD_LEGEND16
					|| user.second->GetJob() == JOB_WINDLURKER_HERO
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
					|| user.second->GetJob() == JOB_WINDLURKER_HERO_ULTIMATE
#endif // __NEWCLASS
					))
				{
					continue;
				}
				if (bCheck[7] == FALSE && (user.second->GetJob() == JOB_RANGER || user.second->GetJob() == JOB_RANGER_MASTER || user.second->GetJob() == JOB_RANGER_HERO
#ifdef __3RD_LEGEND16
					|| user.second->GetJob() == JOB_CRACKSHOOTER_HERO
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
					|| user.second->GetJob() == JOB_CRACKSHOOTER_HERO_ULTIMATE
#endif // __NEWCLASS
					))
				{
					continue;
				}
				if (bCheck[8] == FALSE && user.second->GetJob() == JOB_ASSIST)
					continue;
				if (bCheck[9] == FALSE && (user.second->GetJob() == JOB_RINGMASTER || user.second->GetJob() == JOB_RINGMASTER_MASTER || user.second->GetJob() == JOB_RINGMASTER_HERO
#ifdef __3RD_LEGEND16
					|| user.second->GetJob() == JOB_FLORIST_HERO
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
					|| user.second->GetJob() == JOB_FLORIST_HERO_ULTIMATE
#endif // __NEWCLASS
					))
				{
					continue;
				}
				if (bCheck[10] == FALSE && (user.second->GetJob() == JOB_BILLPOSTER || user.second->GetJob() == JOB_BILLPOSTER_MASTER || user.second->GetJob() == JOB_BILLPOSTER_HERO
#ifdef __3RD_LEGEND16
					|| user.second->GetJob() == JOB_FORCEMASTER_HERO
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
					|| user.second->GetJob() == JOB_FORCEMASTER_HERO_ULTIMATE
#endif // __NEWCLASS
					))
				{
					continue;
				}
				if (bCheck[11] == FALSE && user.second->GetJob() == JOB_MAGICIAN)
					continue;
				if (bCheck[12] == FALSE && (user.second->GetJob() == JOB_PSYCHIKEEPER || user.second->GetJob() == JOB_PSYCHIKEEPER_MASTER || user.second->GetJob() == JOB_PSYCHIKEEPER_HERO
#ifdef __3RD_LEGEND16
					|| user.second->GetJob() == JOB_MENTALIST_HERO
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
					|| user.second->GetJob() == JOB_MENTALIST_HERO_ULTIMATE
#endif // __NEWCLASS
					))
				{
					continue;
				}
				if (bCheck[13] == FALSE && (user.second->GetJob() == JOB_ELEMENTOR || user.second->GetJob() == JOB_ELEMENTOR_MASTER || user.second->GetJob() == JOB_ELEMENTOR_HERO
#ifdef __3RD_LEGEND16
					|| user.second->GetJob() == JOB_ELEMENTORLORD_HERO
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
					|| user.second->GetJob() == JOB_ELEMENTORLORD_HERO_ULTIMATE
#endif // __NEWCLASS
					))
				{
					continue;
				}
				if (bCheck[14] == FALSE && user.second->GetSex() == SEX_MALE)
					continue;
				if (bCheck[15] == FALSE && user.second->GetSex() == SEX_FEMALE)
					continue;
				if (bCheck[16] == FALSE && user.second->GetJob() == JOB_VAGRANT)
					continue;
				if (user.second->GetLevel() < nMin || user.second->GetLevel() > nMax)
					continue;
				if (CString(search).GetLength())
				{
					if (!strstr(CString(user.second->GetName()).MakeLower(), CString(search).MakeLower()))
						continue;
				}
				if (!strlen(user.second->GetName()))
					continue;
				if (user.second->IsPLHided() && user.second->m_dwAuthorization >= pUser->m_dwAuthorization)
					continue;

				PlayerList player;
				strcpy(player.szName, user.second->GetName());
#ifdef __GAMEMASTER
				strcpy(player.szRank, user.second->GetAuthStr(TRUE));
#endif
				player.dwJob = user.second->GetJob();
				player.dwLevel = user.second->GetLevel();
				player.dwSex = user.second->GetSex();
				player.nID = nTotal;

				pUser->SendPlayerList(FALSE, player, TRUE, (nTotal == 0));
				nTotal++;
			}
		}
		if (nTotal < 1)
		{
			// reset
			pUser->SendPlayerList(TRUE);
		}
	}
}

void CDPSrvr::OnPlayerListUpdateMods(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		BOOL bCheck;
		ar >> bCheck;

		if (bCheck)
		{
			pUser->SetMode(PLAYER_LIST_HIDE_MODE);
		}
		else
		{
			pUser->SetNotMode(PLAYER_LIST_HIDE_MODE);
		}
		g_UserMng.AddModifyMode(pUser);
	}
}

#endif // __PLAYER_LIST

#ifdef __SWITCH_GLOW_OLDNEW
BOOL CDPSrvr::DoUseItemTarget_ItemChangGlowOldNew(CUser* pUser, CItemElem* pMaterial, CItemElem* pTarget)
{
	if (!IsValidObj(pUser))
		return FALSE;

	if (!IsUsableItem(pTarget))
		return FALSE;

	ItemProp* pProp = pTarget->GetProp();

	if (!pProp || !IsUsableItem(pMaterial))
		return FALSE;

	if ((pProp->dwParts == NULL_ID) || (pProp->dwParts != PARTS_RWEAPON && pProp->dwParts != PARTS_LWEAPON))
	{
		pUser->AddDefinedText(TID_GAME_INVALID_TARGET_ITEM);
		return FALSE;
	}

	if (pMaterial->m_dwItemId == II_SYS_SYS_SCR_CHANGEGLOWOLD)
	{
		pUser->UpdateItem((BYTE)(pTarget->m_dwObjId), UI_CHANGE_GLOWOLD, pTarget->m_bGlowOld ? FALSE : TRUE);
		pUser->AddText(prj.GetText(TID_GLOW_OLDNEW));
		return TRUE;
	}
	return FALSE;
}
#endif // __SWITCH_GLOW_OLDNEW

#ifdef __BATTLEPASS
void CDPSrvr::OnDoBP(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		OBJID idScroll;
		int nCheck;
		BOOL bReward = FALSE;
		BOOL bRewardLoop = FALSE;
		CString strMessage;
		ar >> idScroll >> nCheck;

		CItemElem* pItemElem = pUser->m_Inventory.GetAtId(idScroll);
		if (pItemElem)
		{
			if (pUser->m_Inventory.IsEquip(pItemElem->m_dwObjId))
				return;
			if (pItemElem->m_nItemNum < 1)
				return;

			ItemProp* pItemProp = pItemElem->GetProp();
			if (!pItemProp)
				return;

			if (nCheck == 2)
			{
				map<DWORD, BATTLE_PASS_ITEM_TEMP>::iterator it = prj.mapBattPassItemTemp.find(pItemProp->dwID);
				if (it != prj.mapBattPassItemTemp.end())
				{
					BATTLE_PASS_ITEM_TEMP nBattItemTemp = it->second;

					if (!pUser->IsBattlePass() /*&& nBattItemTemp.nType != pUser->m_nBPType*/)
					{
						int nStartLevel = 1;
						//Misc Start
						pUser->m_nBPLevel = nStartLevel;
						pUser->m_nBPPoints = 0;
						pUser->m_nBPType = nBattItemTemp.nType;
						pUser->m_nBPEnable = 0;
						//Misc End

						// Time Start
						char szBPEndTime[13] = { 0, };
						sprintf(szBPEndTime, "%d", nBattItemTemp.nTime);
						const char* strbuf = szBPEndTime;
						char cYear[5] = { 0, };
						char cMonth[3] = { 0, };
						char cDay[3] = { 0, };
						char cHour[3] = { 0, };
						char cMin[3] = { 0, };

						strncpy(cYear, strbuf, 4);
						strncpy(cMonth, strbuf + 4, 2);
						strncpy(cDay, strbuf + 6, 2);
						strncpy(cHour, strbuf + 8, 2);
						strncpy(cMin, strbuf + 10, 2);

						CTime Timebuf(atoi(cYear), atoi(cMonth), atoi(cDay), atoi(cHour), atoi(cMin), 0);
						pUser->m_szBPEndTime = Timebuf.GetTime();
						// Time End

						pUser->AddText("Temporary Battle Pass Successfully Activated.");
					}
					else
					{
						pUser->AddText("There's an existing battle pass.");
						return;
					}
				}
				else
				{
					pUser->AddText("Invalid Item");
					return;
				}
			}
			else if (nCheck == 1) // BP
			{
				map<DWORD, BATTLE_PASS_ITEM>::iterator it = prj.mapBattPassItem.find(pItemProp->dwID);
				if (it != prj.mapBattPassItem.end())
				{
					BATTLE_PASS_ITEM nBattItem = it->second;

					if (!pUser->IsBattlePass())
					{
						int nStartLevel = 1;

						//Reward Start
						if (pUser->m_Inventory.GetEmptyCount(0) <= 0)
						{
							pUser->AddText("Your Inventory is full.");
							return;
						}
						//Reward End

						//Misc Start
						pUser->m_nBPLevel = nStartLevel;
						pUser->m_nBPPoints = 0;
						pUser->m_nBPType = nBattItem.nType;
						pUser->m_nBPEnable = 1;
						//Misc End

						// Time Start
						char szBPEndTime[13] = { 0, };
						sprintf(szBPEndTime, "%d", nBattItem.nTime);
						const char* strbuf = szBPEndTime;
						char cYear[5] = { 0, };
						char cMonth[3] = { 0, };
						char cDay[3] = { 0, };
						char cHour[3] = { 0, };
						char cMin[3] = { 0, };

						strncpy(cYear, strbuf, 4);
						strncpy(cMonth, strbuf + 4, 2);
						strncpy(cDay, strbuf + 6, 2);
						strncpy(cHour, strbuf + 8, 2);
						strncpy(cMin, strbuf + 10, 2);

						CTime Timebuf(atoi(cYear), atoi(cMonth), atoi(cDay), atoi(cHour), atoi(cMin), 0);
						pUser->m_szBPEndTime = Timebuf.GetTime();
						// Time End

						bReward = TRUE;
					}
					else if (pUser->IsBattlePass() && pUser->m_nBPEnable == 0)
					{
						char szBPEndTime[13] = { 0, };
						sprintf(szBPEndTime, "%d", nBattItem.nTime);
						const char* strbuf = szBPEndTime;
						char cYear[5] = { 0, };
						char cMonth[3] = { 0, };
						char cDay[3] = { 0, };
						char cHour[3] = { 0, };
						char cMin[3] = { 0, };

						strncpy(cYear, strbuf, 4);
						strncpy(cMonth, strbuf + 4, 2);
						strncpy(cDay, strbuf + 6, 2);
						strncpy(cHour, strbuf + 8, 2);
						strncpy(cMin, strbuf + 10, 2);

						CTime Timebuf(atoi(cYear), atoi(cMonth), atoi(cDay), atoi(cHour), atoi(cMin), 0);

						if (pUser->m_szBPEndTime == Timebuf.GetTime() && pUser->m_nBPType == nBattItem.nType)
						{
							//Reward Start
							if (pUser->m_Inventory.GetEmptyCount(0) <= 0)
							{
								pUser->AddText("Your Inventory is full.");
								return;
							}
							//Reward End
							pUser->m_nBPEnable = 1;
							bReward = TRUE;
							bRewardLoop = TRUE;
							pUser->AddText("Battle Pass Successfully Activated.");
						}
						else
						{
							pUser->AddText("Invalid Type of Battle Pass");
							return;
						}
					}
					else
					{
						pUser->AddText("There's an existing battle pass.");
						return;
					}
				}
				else
				{
					pUser->AddText("Invalid Item");
					return;
				}
			}
			else // Points
			{
				if (pUser->IsBattlePass())
				{
					if (pUser->m_nBPLevel >= pUser->BattlePassSize())
					{
						pUser->AddText("You have already reached the maximum level!");
						return;
					}

					map<DWORD, BATTLE_PASS_POINTS>::iterator it = prj.mapBattPassPoints.find(pItemProp->dwID);
					if (it != prj.mapBattPassPoints.end())
					{
						BATTLE_PASS_POINTS nBattPoints = it->second;
						int nValue = xRandom(nBattPoints.nPointsMin, nBattPoints.nPointsMax);

						map<int, BATTLE_PASS>::iterator it = prj.mapBattPass.find(pUser->m_nBPLevel);
						if (it != prj.mapBattPass.end())
						{
							BATTLE_PASS nBattPass = it->second;
							if (nBattPass.nPoints < nBattPoints.nPointsMax)
							{
								pUser->AddText("You can only use a scroll that is less than the maximum required [Battle Points].");
								return;
							}

							int nTotalVal = 0;
							nTotalVal = pUser->m_nBPPoints + nValue;

							/*
							CString strPrintDebug;
							strPrintDebug.Format("%d / %d", nTotalVal, nBattPass.nPoints);
							pUser->AddText(strPrintDebug);
							*/

							if (nTotalVal > nBattPass.nPoints)
							{
								int nVal = (pUser->m_nBPPoints + nValue) - nBattPass.nPoints;
								if (nVal > 0)
								{
									//Reward Start
									if (pUser->m_Inventory.GetEmptyCount(0) <= 0)
									{
										pUser->AddText("Your Inventory is full.");
										return;
									}
									//Reward End
									pUser->m_nBPPoints = nVal;
									pUser->m_nBPLevel += 1;
									bReward = TRUE;

									strMessage.Format("Battle Pass Level up! Your now Level: [%d] ", pUser->m_nBPLevel);
									pUser->AddText(strMessage);
								}
							}
							else
							{
								pUser->m_nBPPoints += nValue;
								strMessage.Format("[%d] Points added Succesfully.", nValue);
								pUser->AddText(strMessage);
							}
						}
					}
					else
					{
						pUser->AddText("Invalid Item");
						return;
					}
				}
				else
				{
					pUser->AddText("There's no battle pass activated.");
					return;
				}
			}

			//Reward BP Start
			if (bReward && pUser->m_nBPLevel > 0 && pUser->m_nBPEnable == 1)
			{
				if (bRewardLoop)
				{
					for (int i = 1; i <= pUser->m_nBPLevel; i++)
					{
						map<int, BATTLE_PASS>::iterator it = prj.mapBattPass.find(i);
						if (it != prj.mapBattPass.end())
						{
							BATTLE_PASS nBattPass = it->second;
							CItemElem item;
							item.m_dwItemId = nBattPass.dwItem;
							item.m_nItemNum = nBattPass.nQuantity;

							ItemProp* pItemPropReward = prj.GetItemProp(nBattPass.dwItem);
							if (pItemPropReward)
							{
								if (pUser->CreateItem(&item))
								{
									if (pUser->m_nBPLevel == 1)
										strMessage.Format("Battle Pass Successfully Activated. You receive [x%d] %s.", nBattPass.nQuantity, pItemPropReward->szName);
									else
										strMessage.Format("Battle Pass Reward. You receive [x%d] %s.", nBattPass.nQuantity, pItemPropReward->szName);
									pUser->AddText(strMessage);
								}
								else
								{
									if (pUser->m_nBPLevel == 1)
										strMessage.Format("Battle Pass Successfully Activated. You receive [x%d] %s.", nBattPass.nQuantity, pItemPropReward->szName);
									else
										strMessage.Format("Battle Pass Reward. You receive [x%d] %s.", nBattPass.nQuantity, pItemPropReward->szName);
									pUser->AddText(strMessage);
									g_dpDBClient.SendQueryPostMail(pUser->m_idPlayer, 0, item, 0, "Battle Pass Reward", "");
								}
							}
						}
					}
				}
				else
				{
					map<int, BATTLE_PASS>::iterator it = prj.mapBattPass.find(pUser->m_nBPLevel);
					if (it != prj.mapBattPass.end())
					{
						BATTLE_PASS nBattPass = it->second;
						CItemElem item;
						item.m_dwItemId = nBattPass.dwItem;
						item.m_nItemNum = nBattPass.nQuantity;

						ItemProp* pItemPropReward = prj.GetItemProp(nBattPass.dwItem);
						if (pItemPropReward)
						{
							if (pUser->CreateItem(&item))
							{
								if (pUser->m_nBPLevel == 1)
									strMessage.Format("Battle Pass Successfully Activated. You receive [x%d] %s.", nBattPass.nQuantity, pItemPropReward->szName);
								else
									strMessage.Format("Battle Pass Reward. You receive [x%d] %s.", nBattPass.nQuantity, pItemPropReward->szName);
								pUser->AddText(strMessage);
							}
							else
							{
								if (pUser->m_nBPLevel == 1)
									strMessage.Format("Battle Pass Successfully Activated. You receive [x%d] %s.", nBattPass.nQuantity, pItemPropReward->szName);
								else
									strMessage.Format("Battle Pass Reward. You receive [x%d] %s.", nBattPass.nQuantity, pItemPropReward->szName);
								pUser->AddText(strMessage);
								g_dpDBClient.SendQueryPostMail(pUser->m_idPlayer, 0, item, 0, "Battle Pass Reward", "");
							}
						}
					}
				}
			}
			//Reward BP End

			g_UserMng.AddBPUpdate(pUser);
			pUser->UpdateItem((BYTE)(pItemElem->m_dwObjId), UI_NUM, pItemElem->m_nItemNum - 1);
			if ((pUser->IsMode(TRANSPARENT_MODE)) == 0)
				g_UserMng.AddCreateSfxObj((CMover*)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
		}
#ifdef __GAMEGUARD
		if (pUser->GetWorld())
			g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
#endif // __GAMEGUARD
	}
}
#endif // __BATTLEPASS

#ifdef __MOUNT
void CDPSrvr::OnMountChange(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		DWORD dwID, dwMountId = 0;
		ar >> dwID;
		ar >> dwMountId;

		if (dwID == 0)
			pUser->SendActMsg(OBJMSG_MODE_FLY, dwMountId, 0, 1);
		else if (dwID == 1)
			pUser->m_pActMover->m_bLand = TRUE;
		else if (dwID == 2)
		{
			pUser->SendActMsg(OBJMSG_MODE_GROUND, 0, 0, 1);
			pUser->SendActMsg(OBJMSG_MOUNT_GROUND_STAND, dwMountId, 0, 1);
		}
		g_UserMng.UpdateMountState(pUser, dwID);
	}
}
#endif // __MOUNT

#ifdef __AWAKE_WINDOW
void CDPSrvr::OnSendAwakeWindow(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		DWORD dwId1;
		ar >> dwId1;

		CItemElem* pItem = pUser->m_Inventory.GetAtId(dwId1);
		if (!IsUsableItem(pItem) || pUser->IsUsing(pItem))
		{
			pUser->AddText("This object is in use ...");
			return;
		}
		if (pUser->m_Inventory.IsEquip(dwId1))
		{

			pUser->AddText("Please remove this equipment from your character");
			return;
		}
		//if (IsUsableItem(pItem) && !pUser->IsUsing(pItem) && !pUser->m_Inventory.IsEquip(dwId1))
		{
#ifdef __GAMEGUARD
			if (pItem->m_dwItemId == II_GEN_TOO_COL_NOMAL || pItem->m_dwItemId == II_GEN_TOO_COL_VTHREE
				|| pItem->m_dwItemId == II_GEN_TOO_COL_POWER || pItem->m_dwItemId == II_GEN_TOO_COL_ULTRA
				|| pItem->m_dwItemId == II_GEN_TOO_COL_NORMAL || pItem->m_dwItemId == II_GEN_TOO_COL_EVENT
				)
			{
				pUser->AddText(prj.GetText(TID_TRANSFER_AWAKE_03), 0xFFFF0000);
				return;
			}
#endif // __GAMEGUARD

#ifdef __NEW_ITEM_VARUNA
			if (pItem->GetProp()->IsBaruna())
			{
				pUser->AddText(prj.GetText(TID_MMI_ERRORSENCHANT_BARUNA), 0xFFFF0000);
				return;
			}
#endif // __NEW_ITEM_VARUNA

			if (g_xRandomOptionProperty->GetRandomOptionKind(pItem) < 0)
			{
				pUser->AddText(prj.GetText(TID_MMI_BARUNA_WAKEUP_E_TEXT03), 0xFFFF0000);
				return;
			}

			if (pItem->GetProp()->dwItemKind3 == IK3_EGG && pUser->HasActivatedSystemPet()
				|| pItem->GetProp()->dwItemKind3 == IK3_PET && pUser->HasActivatedEatPet())
			{
				pUser->AddText(prj.GetText(TID_AWAKE_WINDOW_ERR_1), 0xFFFF0000);
				return;
			}

			if (pUser->GetGold() < 250000)
			{
				pUser->AddDefinedText(TID_GAME_GUILDHOUSE_BUY_EXPENSE);
				return;
			}

			pUser->AddGold(-250000);
			g_xRandomOptionProperty->InitializeRandomOption(pItem->GetRandomOptItemIdPtr());
			g_xRandomOptionProperty->GenRandomOption(pItem->GetRandomOptItemIdPtr(), g_xRandomOptionProperty->GetRandomOptionKind(pItem), pItem->GetProp()->dwParts);
			pUser->UpdateItemEx((BYTE)(pItem->m_dwObjId), UI_RANDOMOPTITEMID, pItem->GetRandomOptItemId());
			pUser->AddSfxSnd(XI_INT_SUCCESS, SND_INF_UPGRADESUCCESS);
		}
		//else
			//pUser->AddText( prj.GetText( TID_UPGRADE_CANCLE ), 0xFFFF0000 );
	}
}
#endif // __AWAKE_WINDOW

#ifdef	__REMOVE_CMM
void CDPSrvr::OnRemoveCmm(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		DWORD nItem;
		ar >> nItem;
		ItemProp* pItemProp = prj.GetItemProp(nItem);
		if (pItemProp)
		{
			bool bRemoved = false;

			for (int i = 0; i <= BUFF_EQUIP; i++)
			{
				if (pUser->HasBuff(i, (WORD)(pItemProp->dwID)))
				{
					pUser->RemoveBuff(i, (WORD)(pItemProp->dwID));
					bRemoved = true;
				}
			}

			if (!bRemoved)
			{
				int nType = -1;
				switch (pItemProp->dwID)
				{
				case II_CHR_SYS_SCR_SHOUTFULL15: 	nType = SM_SHOUT15; 	 break;
				case II_CHR_SYS_SCR_SHOUTFULL30: 	nType = SM_SHOUT30; 	 break;
				case II_CHR_SYS_SCR_SHOUTFULL001: 	nType = SM_SHOUT001; 	 break;
				case II_CHR_SYS_SCR_PSKILLFULL1: 	nType = SM_PARTYSKILL1;  break;
				case II_CHR_SYS_SCR_PSKILLFULL15: 	nType = SM_PARTYSKILL15; break;
				case II_CHR_SYS_SCR_PSKILLFULL30: 	nType = SM_PARTYSKILL30; break;
				case II_CHR_SYS_SCR_COMMBANK15: 	nType = SM_BANK15; 		 break;
				case II_CHR_SYS_SCR_COMMBANK30: 	nType = SM_BANK30; 		 break;
				case II_CHR_SYS_SCR_COMMBANK001: 	nType = SM_BANK001; 	 break;
				case II_CHR_SYS_SCR_ACTIVITION: 	nType = SM_ACTPOINT; 	 break;
				case II_CHR_SYS_SCR_UPCUTSTONE01: 	nType = SM_ATTACK_UP1; 	 break;
				case II_CHR_SYS_SCR_UPCUTSTONE: 	nType = SM_ATTACK_UP; 	 break;
				case II_SYS_SYS_SCR_BLESSING: 		nType = SM_REVIVAL; 	 break;
				case II_SYS_SYS_SCR_VELOCIJUMP: 	nType = SM_VELOCIJUMP; 	 break;
				case II_CHR_SYS_SCR_ESCAPEBLINKWING:nType = SM_ESCAPE; 		 break;
				case II_CHR_REF_REF_HOLD: 			nType = SM_MAINTAIN_MP;  break;
				case II_CHR_POT_DRI_VITALX: 		nType = SM_MAINTAIN_FP;  break;
				case II_CHR_FOO_COO_BULLHAMS: 		nType = SM_MAX_HP; 		 break;
				case II_CHR_FOO_COO_GRILLEDEEL: 	nType = SM_MAX_HP50; 	 break;
				case II_SYS_SYS_VIR_PENALTYSTR: 	nType = SM_STR_DOWN; 	 break;
				case II_SYS_SYS_VIR_PENALTYSTA: 	nType = SM_STA_DOWN; 	 break;
				case II_SYS_SYS_VIR_PENALTYDEX: 	nType = SM_DEX_DOWN; 	 break;
				case II_SYS_SYS_VIR_PENALTYINT: 	nType = SM_INT_DOWN; 	 break;
				}
				if (nType != -1)
				{
					pUser->RemoveSMMode(nType);
					bRemoved = true;
				}
			}

			if (!bRemoved)
			{
				CString strChelou, strBizard;
				strChelou.Format("%s there is an error call an admin and explain your situation!", pUser->GetName());
				strBizard.Format("So you cannot remove this item ''%s''", pItemProp->szName);
				pUser->AddText(strChelou);
				pUser->AddText(strBizard);
			}
			else
			{
				CString strBg;
				strBg.Format("%s you just removed: ''%s''", pUser->GetName(), pItemProp->szName);
				pUser->AddText(strBg);
			}
		}
	}
}
#endif	// __REMOVE_CMM

#ifdef	__MALEVOLENT_CP
void CDPSrvr::OnBuffbyButton(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	BOOL bBuff;
	ar >> bBuff;
	/*	if( pUser->m_dwLastBuffTick + 5000 > GetTickCount() )
	{
	pUser->AddText("Warte ein bisschen");
	return;
	}*/
	if (bBuff == TRUE && IsValidObj(pUser))
	{
		pUser->DoBuff(SI_ASS_CHEER_HEAPUP, 20, pUser);
		pUser->DoBuff(SI_ASS_CHEER_QUICKSTEP, 20, pUser);
		pUser->DoBuff(SI_ASS_HEAL_PATIENCE, 20, pUser);
		pUser->DoBuff(SI_ASS_CHEER_CATSREFLEX, 20, pUser);
		pUser->DoBuff(SI_ASS_CHEER_CANNONBALL, 20, pUser);
		pUser->DoBuff(SI_ASS_CHEER_MENTALSIGN, 20, pUser);
		pUser->DoBuff(SI_ASS_CHEER_BEEFUP, 20, pUser);
		pUser->DoBuff(SI_ASS_CHEER_ACCURACY, 20, pUser);
		pUser->DoBuff(SI_RIN_SUP_SPIRITUREFORTUNE, 10, pUser);
		pUser->DoBuff(SI_ASS_CHEER_HASTE, 20, pUser);
		pUser->AddText("Buffed successfully!");
	}
	else
		return;

	//	pUser->m_dwLastBuffTick = GetTickCount();
}
#endif

#ifdef __HIDE_COAT
void CDPSrvr::OnHideCoat(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		int nPosition;
		BOOL bHide;
		ar >> nPosition >> bHide;
		if (nPosition >= 5 || nPosition < 0)
			return;

		if ((bHide == 1) == pUser->m_abHideCoat[nPosition])
			return;

		pUser->m_abHideCoat[nPosition] = (bHide == 1);
		g_UserMng.AddHideCoat(pUser, nPosition, bHide);
	}
}
#endif // __HIDE_COAT

#ifdef __SHOPPING_CART
void CDPSrvr::OnBuyItemCart(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) && pUser->m_vtInfo.GetOther())
	{
#ifdef __PERIN_BUY_BUG
		if (pUser->m_dwLastBuyItemTick + 500 > GetTickCount()) // ??? ???? ? 0.5???? ?? ????? ??
			return;
#endif // __PERIN_BUY_BUG

		CMover* pVendor = pUser->m_vtInfo.GetOther();
#if __VER >= 11 // __GUILDCOMBATCHIP
		LPCHARACTER lpChar = prj.GetCharacter(pVendor->m_szCharacterKey);
		if (lpChar && lpChar->m_nVenderType != 0)	// 0 - ?? ??
			return;
#endif // __GUILDCOMBATCHIP

		if (pVendor->IsNPC() == FALSE)		// ??? ??? NPC? ????
			return;

		if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_TRADE, pUser->GetWorld(), pUser->GetPos()))
			return;

		CART_ITEM pCartItem;
		pCartItem.Serialize(ar);
		for (int i = 0; i < pCartItem.nCount; i++)
		{
			if (pCartItem.cTab[i] >= MAX_VENDOR_INVENTORY_TAB || pCartItem.cTab[i] < 0 || pCartItem.dwNum[i] < 1)
				continue;
			CItemElem* pItemElem = pVendor->m_ShopInventory[pCartItem.cTab[i]]->GetAtId((BYTE)pCartItem.dwObjID[i]);
			if (NULL == pItemElem)
				continue;

			if (pCartItem.dwItemID[i] != pItemElem->m_dwItemId)
				continue;

			if ((unsigned)pCartItem.dwNum[i] > (unsigned)pItemElem->m_nItemNum)
				pCartItem.dwNum[i] = pItemElem->m_nItemNum;


#ifdef __OCCUPATION_SHOPITEM
			if (CTax::GetInstance()->IsOccupationShopItem(pCartItem.dwItemID[i]) && !CTax::GetInstance()->IsOccupationGuildMember(pUser))
			{
				pUser->AddDefinedText(TID_GAME_SECRETROOM_STORE_BUY);
				continue;
			}
#endif // __OCCUPATION_SHOPITEM

			int nCost = (int)pItemElem->GetCost();
			nCost = (int)(prj.m_fShopCost * nCost);

#ifdef __SHOP_COST_RATE
			nCost = (int)(prj.m_EventLua.GetShopBuyFactor() * nCost);
#endif // __SHOP_COST_RATE

#if __VER < 8 // __S8_PK
			// ??? ?? ???? ??
			KarmaProp* pProp = prj.GetKarmaProp(pUser->m_nSlaughter);
			if (pProp)
			{
				if (pProp->nGrade == -6)
					continue;

				if (pProp->fDiscountRate != 0.0f)
					nCost = (int)(nCost * pProp->fDiscountRate);
			}
#endif // __VER < 8 // __S8_PK
#if __VER >= 11 // __MA_VER11_02
			if (pItemElem->m_dwItemId == II_SYS_SYS_SCR_PERIN)
				nCost = PERIN_VALUE;
#endif //__MA_VER11_02
			if (nCost < 1)
				nCost = 1;

			int nPracticable = pUser->GetGold() / nCost;
			if (pCartItem.dwNum[i] > (DWORD)nPracticable)
				pCartItem.dwNum[i] = (short)nPracticable;

			if (pCartItem.dwNum[i] <= 0)
			{
				pUser->AddDefinedText(TID_GAME_LACKMONEY, "");
				continue;
			}

#if __VER >= 12 // __TAX
			int nTax = 0;
			if (CTax::GetInstance()->IsApplyTaxRate(pUser, pItemElem))
				nTax = (int)(nCost * CTax::GetInstance()->GetPurchaseTaxRate(pUser));
			nCost += nTax;
			nTax *= pCartItem.dwNum[i];
#endif // __TAX

			int nGold = nCost * pCartItem.dwNum[i];
			if (nGold <= 0)
				continue;

			if (pUser->GetGold() >= nGold)
			{
				CItemElem itemElem;
				itemElem = *pItemElem;
				itemElem.m_nItemNum = (short)pCartItem.dwNum[i];
				itemElem.SetSerialNumber();

				if (pUser->CreateItem(&itemElem))
				{
					LogItemInfo aLogItem;
					aLogItem.Action = "B";
					aLogItem.SendName = pUser->GetName();
					aLogItem.RecvName = pVendor->GetName();
					aLogItem.WorldId = pUser->GetWorld()->GetID();
					aLogItem.Gold = pUser->GetGold();
					aLogItem.Gold2 = pUser->GetGold() - nGold;
					aLogItem.Gold_1 = pVendor->GetGold();

					pItemElem->SetSerialNumber(itemElem.GetSerialNumber());
					OnLogItem(aLogItem, pItemElem, pCartItem.dwNum[i]);		// why do not pass &itemElem as argument?
					pItemElem->SetSerialNumber(0);
					pUser->AddGold(-nGold);
#if __VER >= 12 // __TAX
					if (nTax)
						CTax::GetInstance()->AddTax(CTax::GetInstance()->GetContinent(pUser), nTax, TAX_PURCHASE);
#endif // __TAX
				}
				else
					pUser->AddDefinedText(TID_GAME_LACKSPACE);
			}
		}
		pUser->m_dwLastTryBuyItem = 0;
		pUser->m_dwLastBuyItemTick = GetTickCount();
	}
}
#endif // __SHOPPING_CART

#ifdef __MARKET_TELEPORT_V19
void CDPSrvr::OnConsignmentTeleport(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		DWORD dwMMI;
		char szKey[MAX_NAME];
		ar >> dwMMI;
		ar.ReadString(szKey, MAX_NAME);

		if (dwMMI >= MAX_MOVER_MENU)
			return;

		LPCHARACTER lpCharacter = prj.GetCharacter(szKey);
		if (!lpCharacter)
			return;

		if (!CNpcChecker::GetInstance()->IsCloseNpc(dwMMI, pUser->GetWorld(), pUser->GetPos()))
			return;

		if (!lpCharacter->m_abMoverMenu[dwMMI])
			return;

		map<DWORD, TeleportStruct*>::iterator it = lpCharacter->m_mapTeleportMenuPos.find(dwMMI);
		if (it == lpCharacter->m_mapTeleportMenuPos.end())
			return;

		pUser->Replace(g_uIdofMulti, it->second->dwWorldID, it->second->vPos, REPLACE_NORMAL, nDefaultLayer);
	}
}
#endif // __MARKET_TELEPORT_V19

#ifdef __RECYCLE
void CDPSrvr::OnSendRecycleParure(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		DWORD dwItem1;
		ar >> dwItem1;

		CItemElem* pItem1 = NULL;
		pItem1 = pUser->m_Inventory.GetAtId(dwItem1);

		if (!pItem1)
		{
			pUser->AddText(prj.GetText(TID_RECYCLE_TEXT_03), 0xFFFF0000);
			return;
		}

		if (pUser->IsUsing(pItem1))
			return;

		if (IsValidRecycleParure(pItem1->GetProp()->dwID))
		{
			if (pItem1->m_nItemNum == 1)
			{
#ifdef __TABBED_INV
				if (pUser->m_Inventory.GetEmptyCount(0) >= 1)
#else // __TABBED_INV
				if (pUser->m_Inventory.GetEmptyCount() >= 1)
#endif // __TABBED_INV
				{
					const DWORD niveau_du_bijou_a_detruire = pItem1->GetProp()->dwLimitLevel1;
					DWORD fragment_a_creer = 1;

					if (niveau_du_bijou_a_detruire <= 80) {
						fragment_a_creer = II_SYS_SYS_MORCEAUX_DE_PARURE80;
					}
					else if (niveau_du_bijou_a_detruire == 130) {
						fragment_a_creer = II_SYS_SYS_MORCEAUX_DE_PARURE130;
					}
					else if (niveau_du_bijou_a_detruire == 175) {
						fragment_a_creer = II_SYS_SYS_MORCEAUX_DE_PARURE175;
					}
					else {
						return;
					}

					CItemElem item;
					item.m_dwItemId = fragment_a_creer;
					item.m_nItemNum = (short)((pItem1->GetProp()->dwReferValue1) / 8);

					pUser->CreateItem(&item);
					pUser->UpdateItem((BYTE)pItem1->m_dwObjId, UI_NUM, pItem1->m_nItemNum - 1);
					pUser->AddSfxSnd(XI_INT_SUCCESS, SND_INF_UPGRADESUCCESS);
				}
				else
				{
					pUser->AddDefinedText(TID_GAME_LACKSPACE);
					return;
				}
			}
		}
		else
			pUser->AddText(prj.GetText(TID_RECYCLE_TEXT_02), 0xFFFF0000);
	}
}
void CDPSrvr::OnSendRecycleFamillier(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		DWORD dwItem1;
		ar >> dwItem1;

		CItemElem* pItem1 = NULL;
		pItem1 = pUser->m_Inventory.GetAtId(dwItem1);

		if (!pItem1)
		{
			pUser->AddText(prj.GetText(TID_RECYCLE_TEXT_03), 0xFFFF0000);
			return;
		}

		if (pUser->IsUsing(pItem1))
			return;

		if (IsValidRecycleFamillier(pItem1->GetProp()->dwID))
		{
			if (pItem1->m_pPet->GetLevel() == PL_S)
			{
				if (pItem1->m_nItemNum == 1)
				{
#ifdef __TABBED_INV
					if (pUser->m_Inventory.GetEmptyCount(0) >= 1)
#else // __TABBED_INV
					if (pUser->m_Inventory.GetEmptyCount() >= 1)
#endif // __TABBED_INV
					{
						CItemElem item;
						item.m_dwItemId = II_GEN_GEM_GEM_CHROMOSOME;
						item.m_nItemNum = xRandom(10, 50);
						pUser->CreateItem(&item);
						pUser->UpdateItem((BYTE)pItem1->m_dwObjId, UI_NUM, pItem1->m_nItemNum - 1);
						pUser->AddSfxSnd(XI_INT_SUCCESS, SND_INF_UPGRADESUCCESS);
					}
					else
					{
						pUser->AddText("Your inventory is full!");
						return;
					}
				}

			}
			else
			{
				pUser->AddText("Only Class S pets can be transformed into chromosomes!");
				return;
			}
		}
		else
			pUser->AddText("This is not a so-called basic Pet!");
	}
}
void CDPSrvr::OnSendRecycleCape(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		DWORD dwItem1;
		ar >> dwItem1;

		CItemElem* pItem1 = pUser->m_Inventory.GetAtId(dwItem1);

		if (!pItem1)
		{
			pUser->AddText(prj.GetText(TID_RECYCLE_TEXT_03), 0xFFFF0000);
			return;
		}

		if (pUser->IsUsing(pItem1))
			return;

		if (IsValidRecycleCape(pItem1->GetProp()->dwID))
		{
			if (pItem1->m_nItemNum == 1)
			{
#ifdef __TABBED_INV
				if (pUser->m_Inventory.GetEmptyCount(0) >= 1)
#else // __TABBED_INV
				if (pUser->m_Inventory.GetEmptyCount() >= 1)
#endif // __TABBED_INV
				{
					CItemElem item;
					item.m_dwItemId = II_SYS_SYS_SCR_TICKETMAHTOLLE;
					item.m_nItemNum = 1;
					pUser->CreateItem(&item);
					pUser->UpdateItem((BYTE)pItem1->m_dwObjId, UI_NUM, pItem1->m_nItemNum - 1);
					pUser->AddSfxSnd(XI_INT_SUCCESS, SND_INF_UPGRADESUCCESS);
				}
				else
				{
					pUser->AddDefinedText(TID_GAME_LACKSPACE);
					return;
				}
			}
		}
		else
			pUser->AddText("This is not a so-called basic cape!");
	}
}
#endif // __RECYCLE

#ifdef __QUICK_SELL
void CDPSrvr::OnQuickSell(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->m_vtInfo.GetOther()->IsNPC() == FALSE)
			return;

		if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_TRADE, pUser->GetWorld(), pUser->GetPos()))
			return;

		for (int i = 0; i < pUser->m_Inventory.GetMax(); i++)
		{
			CItemElem* pItemElem = static_cast<CItemElem*>(pUser->GetItemId(i));
			if (IsUsableItem(pItemElem))
			{
				ItemProp* pProp = pItemElem->GetProp();
				if (!pProp)
					continue;

				if (pProp->dwItemKind1 != IK1_WEAPON && pProp->dwItemKind1 != IK1_ARMOR)
					continue;

				if (pProp->dwItemKind1 == IK1_WEAPON && pProp->dwReferStat1 != WEAPON_GENERAL)
					continue;


				if (pProp->dwItemKind1 == IK1_ARMOR)
				{
					if (pProp->dwReferStat1 == ARMOR_SET)
						continue;
					if (pProp->dwReferStat1 == WEAPON_UNIQUE)
						continue;

					if (pProp->dwItemKind3 != IK3_SUIT
						&& pProp->dwItemKind3 != IK3_HELMET
						&& pProp->dwItemKind3 != IK3_GAUNTLET
						&& pProp->dwItemKind3 != IK3_BOOTS
						&& pProp->dwItemKind3 != IK3_SHIELD
						&& pProp->dwItemKind3 != IK3_MAGICBARUNA
						&& pProp->dwItemKind3 != IK3_ZEMBARUNA
						)
						continue;
				}

				if (pUser->m_Inventory.IsEquip(i))
					continue;
				if (pUser->IsUsing(pItemElem))
					continue;
				if (pItemElem->m_nAbilityOption > 0)
					continue;
				if (pItemElem->GetRandomOptItemId() > 0)
					continue;
				if (pItemElem->GetPiercingSize() > 0)
					continue;
				if (pItemElem->GetAttrOption() > 0)
					continue;

				int nGold = (pItemElem->GetCost() / 4);
#ifdef __SHOP_COST_RATE
				nGold = (int)(prj.m_EventLua.GetShopSellFactor() * nGold);
#endif // __SHOP_COST_RATE

				int nNum = 1;

				if (nGold == 0)
					nGold = 1;
				int nTax = 0;
				if (CTax::GetInstance()->IsApplyTaxRate(pUser, pItemElem) && pUser->m_dwAuthorization == AUTH_GENERAL)
					nTax = (int)(nGold * CTax::GetInstance()->GetSalesTaxRate(pUser));
				nGold -= nTax;

				if (pItemElem->IsBinds())
					nGold = 1;

				float fTmpGold = (float)(pUser->GetGold() + nGold);

				if (fTmpGold >= 2100000000)
				{
					DWORD nCount = (int)(pUser->m_Inventory.GetAtItemId((DWORD)II_SYS_SYS_SCR_PERIN));
#ifdef __TABBED_INV
					if (pUser->m_Inventory.GetEmptyCount(0) > 0 || nCount % 9999 != 0)
#else // __TABBED_INV
					if (pUser->m_Inventory.GetEmptyCount() > 0 || nCount % 9999 != 0)
#endif // __TABBED_INV
					{
						{
							CItemElem item;
							item.m_nItemNum = 1;
							item.m_dwItemId = II_SYS_SYS_SCR_PERIN;
							item.SetSerialNumber();

							if (pUser->CreateItem(&item))
							{
								pUser->AddGold(-PERIN_VALUE);
							}
							else
								return;
						}
					}
					else
					{
						pUser->AddText("You cannot sell your items because you have too much penya!");
						return;
					}
				}

				LogItemInfo aLogItem;
				aLogItem.Action = "Q";
				aLogItem.SendName = pUser->GetName();
				aLogItem.RecvName = pUser->m_vtInfo.GetOther()->GetName();
				aLogItem.WorldId = pUser->GetWorld()->GetID();
				aLogItem.Gold = pUser->GetGold();
				aLogItem.Gold2 = pUser->GetGold() + nGold;
				int nCost = (int)pItemElem->GetCost() / 4;

				if (nCost < 1)
					nCost = 1;

				if (nGold < 1)
					nGold = 1;

				pUser->AddGold(nGold);
				if (nTax)
					CTax::GetInstance()->AddTax(CTax::GetInstance()->GetContinent(pUser), nTax, TAX_SALES);

				pUser->RemoveItem(i, nNum);
			}
		}

		CWorld* pWorld = pUser->GetWorld();
		if (pWorld)
			g_dpDBClient.SavePlayer(pUser, pWorld->GetID(), pUser->GetPos(), pUser->GetLayer());
	}
}
#endif // __QUICK_SELL

#ifdef __RESIZE_CHARACTER
void CDPSrvr::OnResizeChar(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
		float vScalex, vScaley, vScalez;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	ar >> vScalex >> vScaley >> vScalez;

	if (IsValidObj(pUser))
	{
#ifdef __GAMEGUARD
		if ((vScalex > 1.5f || vScalex < 0.3f))
			return;
#endif // __GAMEGUARD
		if (pUser->GetGold() >= 8000000 || (vScalex == 1.0f && vScaley == 1.0f && vScalez == 1.0f))
		{
			if (vScalex != 1.0f && vScaley != 1.0f && vScalez != 1.0f)
				pUser->AddGold(-8000000);

			pUser->AddText(prj.GetText(TID_RESIZE_CHARACTER_01));
			pUser->m_vScale.x = vScalex;
			pUser->m_vScale.y = vScaley;
			pUser->m_vScale.z = vScalez;
			((CObj*)pUser)->SetScale(D3DXVECTOR3(vScalex, vScaley, vScalez));
			g_UserMng.UpdateResizeChar(pUser, vScalex, vScaley, vScalez);
		}
		else
			pUser->AddDefinedText(TID_GAME_GUILDHOUSE_BUY_EXPENSE);
	}
}
#endif // __RESIZE_CHARACTER

#ifdef __USER_OWN_TITLE
void CDPSrvr::OnCreateOwnTitle(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
		CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		char str[MAX_CUSTOM_TITLE];
		ar.ReadString(str, MAX_CUSTOM_TITLE);
		BOOL b = FALSE;
		if (str[0] == '$')
			ar >> b;

		CItemElem* pItemElem = NULL;
		if (!b)
		{
			int nLen = strlen(str);
			if (nLen < MIN_CUSTOM_TITLE
				|| nLen > MAX_CUSTOM_TITLE
				|| prj.IsInvalidName(str)
				)
			{
				pUser->AddText(prj.GetText(TID_CUSTOM_TITLE_ERR_01), 0xFFFF0000);
				return;
			}
			char szH[2], szA[10];
			strcpy(szH, "'");
			strcpy(szA, "\\");
			for (int i = 0; i < nLen; i++)
			{
				if (str[i] == szH[0] || str[i] == szA[0] || str[i] == '_' || str[i] == '-' || str[i] == ',' || str[i] == '.'
					|| str[i] == '+' || str[i] == '*' || str[i] == '!' || str[i] == '"' || str[i] == '?' || str[i] == '%'
					|| str[i] == '&' || str[i] == '/' || str[i] == '(' || str[i] == ')' || str[i] == '=' || str[i] == '?'
					|| str[i] == '`' || str[i] == '?' || str[i] == '<' || str[i] == '>' || str[i] == '|' || str[i] == '}'
					|| str[i] == ']' || str[i] == '[' || str[i] == '{' || str[i] == '~' || str[i] == '^' || str[i] == '$'
					|| str[i] == '?' || str[i] == ';' || str[i] == ':' || str[i] == '#')
				{
					pUser->AddText(prj.GetText(TID_CUSTOM_TITLE_ERR_01), 0xFFFF0000);
					return;
				}
			}
			pItemElem = pUser->m_Inventory.GetAtItemId(II_SYS_SCR_CUSTOMTITLE);
		}
		else
		{
			if (lstrlen(pUser->m_szOwnTitle) > NULL && pUser->m_szOwnTitle[0] != '$')
				pItemElem = pUser->m_Inventory.GetAtItemId(II_SYS_SCR_REMOVE_CUSTOM);
			else
			{
				pUser->AddText(prj.GetText(TID_CUSTOM_TITLE_ERR_04), 0xFFFF0000);
				return;
			}
		}

		if (IsUsableItem(pItemElem))
		{
			pUser->UpdateItem((BYTE)(pItemElem->m_dwObjId), UI_NUM, pItemElem->m_nItemNum - 1);
			lstrcpy(pUser->m_szOwnTitle, str);
			g_UserMng.UpdateTitle(pUser);
		}
		else
			pUser->AddText(prj.GetText(TID_CUSTOM_TITLE_ERR_02), 0xFFFF0000);
	}
}
#endif // __USER_OWN_TITLE

#ifdef __APP_TELEPORTER
void CDPSrvr::OnTeleport(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	CWorld* pWorld;
	unsigned int nIndex;
	ar >> nIndex;
	if (nIndex >= prj.TPData.size())
		return;
	decltype(auto) teleportInfo = prj.TPData[nIndex];
	CWorld* pTargetWorld = g_WorldMng.GetWorld(teleportInfo.dwWorldID);

	if (IsValidObj(pUser) && (pWorld = pUser->GetWorld()))
	{
		if (pUser->IsCollecting()) { pUser->AddText("You can't teleport while collecting.", COLOR_ERROR); return; }

		if (pUser->IsDie()) { pUser->AddText("You can't teleport while being dead.", COLOR_ERROR); return; }

		if (pUser->IsFly()) { pUser->AddText("You can't teleport while flying.", COLOR_ERROR); return; }

		if (pUser->IsAttackMode()) { pUser->AddText("You cannot teleport if you are in combat.", COLOR_ERROR); return; }
#ifdef __MOUNT
		if (pUser->m_pActMover->IsUseMount()) { pUser->AddText("You can't teleport while using a mount.", COLOR_ERROR); return; }
#endif
#ifdef __REBIRTH_REQ
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&# Farm Islands %#&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
		
		if (teleportInfo.dwWorldID == WI_WORLD_MINE) {
			if (pUser->m_nCampusPoint < 300) {
				pUser->AddText("Rebirth Requirements Not Met for Gold Mine. 300 Min", COLOR_ERROR);
				return;
			}
		}

		if (teleportInfo.dwWorldID == WI_WORLD_WD6)
		{
			if (pUser->m_nCampusPoint < 1200)
			{
				pUser->AddText("Rebirth Requirements Not Met for Tarzia. 1200min", COLOR_ERROR);
				return;
			}
		}

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&# Mysterious Islands %#&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
		
		if (teleportInfo.dwWorldID == WI_WORLD_HEAVEN01) {
			if (pUser->m_nCampusPoint < 1 || pUser->m_nCampusPoint > 20) {
				pUser->AddText("Rebirth Requirements Not Met or Exceeded for Roikian Beach. 1 Min - 20 Max", COLOR_ERROR);
				return;
			}
		}

		if (teleportInfo.dwWorldID == WI_WORLD_HEAVEN02) {
			if (pUser->m_nCampusPoint < 20 || pUser->m_nCampusPoint > 40) {
				pUser->AddText("Rebirth Requirements Not Met or Exceeded for Sacred Forest. 20 Min - 40 Max", COLOR_ERROR);
				return;
			}
		}

		if (teleportInfo.dwWorldID == WI_WORLD_HEAVEN03) {
			if (pUser->m_nCampusPoint < 40 || pUser->m_nCampusPoint > 60) {
				pUser->AddText("Rebirth Requirements Not Met or Exceeded for Cursed Jungle. 40 Min - 60 Max", COLOR_ERROR);
				return;
			}
		}

		if (teleportInfo.dwWorldID == WI_WORLD_HEAVEN04) {
			if (pUser->m_nCampusPoint < 60 || pUser->m_nCampusPoint > 80) {
				pUser->AddText("Rebirth Requirements Not Met or Exceeded for Frozen Amazon. 60 Min - 80 Max", COLOR_ERROR);
				return;
			}
		}

		if (teleportInfo.dwWorldID == WI_WORLD_HEAVEN05) {
			if (pUser->m_nCampusPoint < 80 || pUser->m_nCampusPoint > 100) {
				pUser->AddText("Rebirth Requirements Not Met or Exceeded for The Savannah. 80 Min - 100 Max", COLOR_ERROR);
				return;
			}
		}

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&# Rebirthing Maps %#&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

		if (teleportInfo.dwWorldID == WI_WORLD_CISLAND)
		{
			if (pUser->m_nCampusPoint < 100)
			{
				pUser->AddText("Rebirth Requirements Not Met for Coral Island. 100 Min", COLOR_ERROR);
				return;
			}
		}

		if (teleportInfo.dwWorldID == WI_WORLD_KEBARAS)
		{
			if (pUser->m_nCampusPoint < 1000)
			{
				pUser->AddText("Rebirth Requirements Not Met for Azria. 1000 Min", COLOR_ERROR);
				return;
			}
		}

		if (teleportInfo.dwWorldID == WI_WORLD_RARTESIA)
		{
			if (pUser->m_nCampusPoint < 2000)
			{
				pUser->AddText("Rebirth Requirements Not Met for Traseia. 2000 Min", COLOR_ERROR);
				return;
			}
		}

		if (teleportInfo.dwWorldID == WI_WORLD_DARKRARTESIA)
		{
			if (pUser->m_nCampusPoint < 3000)
			{
				pUser->AddText("Rebirth Requirements Not Met for Dark Traseia. 3000 Min", COLOR_ERROR);
				return;
			}
		}

		if (teleportInfo.dwWorldID == WI_WORLD_EDEN)
		{
			if (pUser->m_nCampusPoint < 4000)
			{
				pUser->AddText("Rebirth Requirements Not Met for Garden of Eden. 4000 Min", COLOR_ERROR);
				return;
			}
		}

		if (teleportInfo.dwWorldID == WI_WORLD_SHADE)
		{
			if (pUser->m_nCampusPoint < 5000)
			{
				pUser->AddText("Rebirth Requirements Not Met for Shade's Rift. 5000 Min", COLOR_ERROR);
				return;
			}
		}

		if (teleportInfo.dwWorldID == WI_INSTANCE_HERNESIA)
		{
			if (pUser->m_nCampusPoint < 10000)
			{
				pUser->AddText("Rebirth Requirements Not Met for Iblis's Grasslands. 10000 Min", COLOR_ERROR);
				return;
			}
		}

#endif // __REBIRTH_REQ

		if (pUser->GetWorld() && pUser->GetWorld()->GetID() == WI_WORLD_GUILDWAR || pUser->GetWorld()->GetID() == WI_WORLD_ARENA)
		{
			pUser->AddText("You can't teleport at this location.", COLOR_ERROR);
			return;
		}

		if (pUser->m_vtInfo.VendorIsVendor() || pUser->m_vtInfo.IsVendorOpen())
		{
			pUser->AddText("You can't teleport while having a shop open or looking at someone elses shop.", COLOR_ERROR);
			return;
		}

		if (!pTargetWorld)
		{
			Error("CDPSrvr::OnTeleport() - WorldID : %d, Name = %s", teleportInfo.dwWorldID, pUser->GetName());
			return;
		}
		pUser->REPLACE(g_uIdofMulti, teleportInfo.dwWorldID, teleportInfo.vPos, REPLACE_NORMAL, nDefaultLayer);
	}
}
#endif //__APP_TELEPORTER

#ifdef __ADVANCED_ANNOUNCEMENT
void CDPSrvr::OnAegonSystemShout(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CHAR szString[512];
	BOOL bShowName, bShowAuth;
	int nImage, nFont;
	ar.ReadString(szString, 512);
	ar >> bShowName;
	ar >> bShowAuth;
	ar >> nImage;
	ar >> nFont;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser) || strlen(szString) <= 0)
		return;

	if (!pUser->IsAuthHigher(AUTH_GAMEMASTER))
	{
		Error("unauthorized sys shout attempt - playerID: %d, playerName: %s", pUser->m_idPlayer, pUser->GetName());
		return;
	}

	if (!pUser->IsAuthHigher(AUTH_OPERATOR))
		bShowName = TRUE;

	CString completeString;

	if (bShowName && bShowAuth)
		completeString.Format("[%s] [%s] %s", pUser->GetAuthString().GetString(), pUser->GetName(), szString);
	else if (bShowName)
		completeString.Format("[%s] %s", pUser->GetName(), szString);
	else if (bShowAuth)
		completeString.Format("[%s] %s", pUser->GetAuthString().GetString(), szString);
	else
		completeString.Format("%s", szString);

	g_DPCoreClient.SendSystem(completeString.GetString(), nImage, nFont);
}
#endif // __ADVANCED_ANNOUNCEMENT

#ifdef __WIKI_ITEMS_V2
void CDPSrvr::OnWikiCreate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	if (pUser->IsAuthHigher(AUTH_GAMEMASTER3) == FALSE)
		return;

	BOOL dwId;
	int nMode;

	ar >> dwId >> nMode;

	ItemProp* pProp = prj.GetItemProp(dwId);
	if (!pProp)
		return;

	int nAmount = 1;
	switch (nMode)
	{
	case 0: nAmount = 1; break;
	case 1: nAmount = 100; break;
	case 2: nAmount = 1000; break;
	case 3: nAmount = pProp->dwPackMax; break;
	default: return;
	}

	if (nAmount > pProp->dwPackMax)
		nAmount = pProp->dwPackMax;

	CItemElem itemElem;
	itemElem.m_dwItemId = dwId;
	itemElem.m_nItemNum = nAmount;
	itemElem.SetSerialNumber();
	itemElem.m_nHitPoint = 0;

	if (!pUser->CreateItem(&itemElem))
		pUser->AddDefinedText(TID_GAME_LACKSPACE);
}
#endif

#ifdef __SYS_WORLDBOSS
void CDPSrvr::OnRegisterHWID(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	char HWID[38];

	ar.ReadString(HWID);

	lstrcpy(pUser->HWID, HWID);
}
#endif //__SYS_WORLDBOSS

#ifdef __AUTO_STATS
void CDPSrvr::OnUpdateAutoStats(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	int nSelectedAutoStat;
	ar >> nSelectedAutoStat;

	if (nSelectedAutoStat < 0 || nSelectedAutoStat > 4)
		return;

	pUser->m_nAutoStat = nSelectedAutoStat;
	pUser->AddAutoStatRefresh();
}
#endif

#ifdef __DEATH_MATCH
void CDPSrvr::OnPlayerSiegeJoin(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		BOOL bNew, bWarJoin;
		ar >> bNew;
		ar >> bWarJoin;
		if (bWarJoin)
		{
			if (g_War.GetState() != -1)
			{
				if (g_War.IsSiegeUser(pUser->m_idPlayer))
				{
					WAR_PLAYER sMember = g_War.GetUser(pUser->m_idPlayer);
					if (sMember.m_idPlayer > 0)
					{
						/*
						CItemElem* pItemElem = NULL;
						pItemElem = pUser->m_Inventory.GetAtItemId( II_CHP_DEATHMATCH );
						if( pItemElem && pItemElem->m_nItemNum > 0 )
						{
							pUser->UpdateItem( (BYTE)( pItemElem->m_dwObjId ), UI_NUM, pItemElem->m_nItemNum - 1 );
						}
						else
						{
							pUser->AddText( prj.GetText( TEXT_PLAYER_WAR_01 ), 0xFFFF0000 );
							return;
						}
						*/
						g_War.CheckUsers(pUser->m_idPlayer, TRUE);
						pUser->REPLACE(g_uIdofMulti, WI_WORLD_DEATH_MATCH, D3DXVECTOR3(159.2f, 107.2f, 277.7f), REPLACE_NORMAL, nDefaultLayer);
						sMember.m_dwRespawnTime = ::GetCurrentTime() + SEC(g_War.WARINFO.m_nRespawnTime);
						g_War.UpdateUser(pUser->m_idPlayer, sMember);
						g_UserMng.AddClientUpdate(pUser->m_idPlayer);
						return;
					}
				}
				else
				{
					pUser->AddText(prj.GetText(TID_PLAYER_WAR_02), 0xFFFF0000);
					return;
				}
			}
			else
			{
				pUser->AddText(prj.GetText(TID_PLAYER_WAR_03), 0xFFFF0000);
				return;
			}
		}

		if (bNew)
		{
			if (g_War.GetState() == -1)
			{
				/*
				CItemElem* pItemElem = NULL;
				pItemElem = pUser->m_Inventory.GetAtItemId( II_CHP_DEATHMATCH );
				if( pItemElem && pItemElem->m_nItemNum > 0 )
				{
					pUser->AddText( prj.GetText( TEXT_PLAYER_WAR_04 ), 0xFFFF0000 );
				}
				else
				{
					pUser->AddText( prj.GetText( TEXT_PLAYER_WAR_01 ), 0xFFFF0000);
					return;
				}
				*/

				if (pUser->GetGold() >= DEATH_MATCH_COST)
				{
					pUser->AddGold(-(DEATH_MATCH_COST));
					g_War.CheckUsers(pUser->m_idPlayer, TRUE);
					g_War.NewUser(pUser->m_idPlayer);
					pUser->AddWarTime(g_War.m_dwWaitTime - GetTickCount(), g_War.GetState());
					g_UserMng.AddClientUpdate(pUser->m_idPlayer);

					pUser->AddText(prj.GetText(TID_PLAYER_WAR_04));
				}
				else
					pUser->AddText(prj.GetText(TID_PLAYER_WAR_01));
			}
			else
				pUser->AddText(prj.GetText(TID_PLAYER_WAR_05), 0xFFFF0000);
		}
		else
		{
			if (!bNew && pUser->IsSiegeUser())
				g_War.RejoinSiegeFight(pUser);
		}
	}
}

void CDPSrvr::OnGetSiegeRanking(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	BOOL bFightRank;
	if (IsValidObj(pUser))
	{
		ar >> bFightRank;
		if (bFightRank != FALSE)
			pUser->AddRankingList();
		else
			g_UserMng.AddClientUpdate(pUser->m_idPlayer);
	}
}
#endif // __DEATH_MATCH
#ifdef __WRITING_SAY
void CDPSrvr::OnWritingSay(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		u_long idToPlayer;
		BOOL m_bIsWriting;
		ar >> idToPlayer;
		ar >> m_bIsWriting;

		CUser* pUserB = (CUser*)prj.GetUserByID(idToPlayer);
		if (IsValidObj(pUserB))
		{
			pUserB->AddIsWritingChat(pUser->GetName(), m_bIsWriting);
		}

	}
}
#endif
#ifdef __MONSTER_CLASH
void	CDPSrvr::OnMonsterClashTenderOpenWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	CMonsterClashMng::GetInstance()->SetTenderOpenWnd(pUser);
}

void	CDPSrvr::OnMonsterClashTender(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	int nPerin;
	ar >> nPerin;

	if (nPerin <= 0)
		return;

	CMonsterClashMng::GetInstance()->SetTender(pUser, nPerin);
}

void	CDPSrvr::OnMonsterClashTenderCancelReturn(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	//CMonsterClashMng::GetInstance()->SetTenderCancelReturn(pUser);
}

void	CDPSrvr::OnMonsterClashLineUpOpenWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	CMonsterClashMng::GetInstance()->SetLineUpOpenWnd(pUser);
}

void	CDPSrvr::OnMonsterClashLineUpMember(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	set<DWORD> checker;
	set<BYTE> jobChecker;
	vector<DWORD> vecLineUpMember;
	int nSize;
	ar >> nSize;

	CMonsterClashMng* pMonsterClash = CMonsterClashMng::GetInstance();

	if (nSize > pMonsterClash->m_nMaxGuildMemberNum || nSize < pMonsterClash->m_nMinGuildMemberNum)
		return;

	for (int i = 0; i < nSize; i++)
	{
		DWORD dwIdPlayer;
		ar >> dwIdPlayer;

		PlayerData* pData = CPlayerDataCenter::GetInstance()->GetPlayerData(dwIdPlayer);
		if (!pData)
			return;

		if (!checker.insert(dwIdPlayer).second)
			return;

		if (!jobChecker.insert(pData->data.nJob).second)
		{
			pUser->AddDefinedText(TID_GAME_MONSTERCLASH_SELECTION_JOB);
			return;
		}

		vecLineUpMember.push_back(dwIdPlayer);
	}

	pMonsterClash->SetLineUp(pUser, vecLineUpMember);
}

void	CDPSrvr::OnMonsterClashEntrance(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	CMonsterClashMng::GetInstance()->SetTeleportEntrance(pUser);
}

void	CDPSrvr::OnMonsterClashTeleportToNPC(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	//pUser->REPLACE(g_uIdofMulti, WI_WORLD_MADRIGAL, CSecretRoomMng::GetInstance()->GetRevivalPos(pUser), REPLACE_NORMAL, nDefaultLayer);
}

void CDPSrvr::OnMonsterClashTenderView(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	CMonsterClashMng::GetInstance()->GetTenderView(pUser);
}
#endif // __MONSTER_CLASH

#ifdef __BADGE
#include "Badge.h"
void CDPSrvr::OnChangeBadgeIcon(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nChange;
	ar >> nChange;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (nChange > static_cast<int>(CBadge::GetInstance()->GetBadgesMap().size()) || nChange < -1)
			return;

		if (CBadge::GetInstance()->IsOwned(static_cast<CMover*>(pUser), nChange))
		{
			pUser->SetBadge(nChange);
			g_UserMng.AddBadgeChange(pUser, nChange);
		}
	}
}
#endif //__BADGE

#ifdef __WHEEL_OF_FORTUNE
void CDPSrvr::OnWofInit(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CWheelOfFortune::GetInstance()->InitProcess(pUser);
}
void CDPSrvr::OnWofFinish(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CWheelOfFortune::GetInstance()->FinishProcess(pUser);
}
#endif

#ifdef __RECORD_BOOK
void CDPSrvr::OnRecordBook(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	pUser->AddRecordBook();
}
#endif
```
