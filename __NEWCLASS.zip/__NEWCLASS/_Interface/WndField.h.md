# WndField.h

Chemin original: `C:\Users\rdiff\Desktop\__NEWCLASS\_Interface\WndField.h`
Chemin relatif: `_Interface\WndField.h`
Nom du fichier: `WndField.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `cp1252`

```cpp
#if !defined(AFX_WNDFIELD_H__A93F3186_63D6_43C1_956F_EC8691E0C7D9__INCLUDED_)
#define AFX_WNDFIELD_H__A93F3186_63D6_43C1_956F_EC8691E0C7D9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "post.h"
#include "guild.h"

#if __VER >= 13 // __CSC_VER13_2
#include "couple.h"
#include "couplehelper.h"
#endif //__CSC_VER13_2

extern 	int g_nSkillCurSelect;
const int MAX_WANTED_LIST =	100;

#if __VER >= 13 // __HONORABLE_TITLE
#include "honor.h"
#endif	// __HONORABLE_TITLE

#ifdef __RECORD_BOOK
#include "RecordBook.h"
#endif

#ifdef __WHEEL_OF_FORTUNE
#include "WheelOfFortune.h"
#endif

#ifdef __MAIL_REQUESTING_BOX
#include "WndMailRequestingBox.h"
#endif // __MAIL_REQUESTING_BOX
#ifdef __LOOKCHANGE
#define POINT_TO_SCREEN( rect, p ) CPoint point2 = p; ClientToScreen( &point2 ); CRect DrawRect = rect; ClientToScreen( &DrawRect );
#define PUT_TOOL_TIP( rect, p, itm ) POINT_TO_SCREEN( rect, p ) g_WndMng.PutToolTip_Item( itm, point2, &DrawRect );
#endif

#ifdef __TABBED_INV
#include "WndInventoryCtrl.h"
#endif // __TABBED_INV

#ifdef __PARTY_FIND
#include "Party.h"
#endif // __PARTY_FIND

//////////////////////////////////////////////////////////////////////////////////////
// GlowShop 
//
#ifdef __JOPS_GLOW
class CWndGlowChange : public CWndNeuz
{
public:
	CItemElem* m_pItemElem;
	CTexture* m_pTexture;
public:
	CWndGlowChange(void);
	~CWndGlowChange(void);
	//original variables
	int GlowBody;
	int GlowHandLeft;
	int GlowHandRight;
	int GlowArmLeft;
	int GlowArmRight;
	int GlowLegLeft;
	int GlowLegRight;
	//counters for output
	int GlowBodyC;
	int GlowHandLeftC;
	int GlowHandRightC;
	int GlowArmLeftC;
	int GlowArmRightC;
	int GlowLegLeftC;
	int GlowLegRightC;
	//for reset when cancel
	int		s_GlowBody;
	int		s_GlowHandLeft;
	int		s_GlowHandRight;
	int		s_GlowArmLeft;
	int		s_GlowArmRight;
	int		s_GlowLegLeft;
	int		s_GlowLegRight;
	CTexture         m_Texture;
	CModelObject* m_pModel;

	BOOL			 m_bLButtonClick;
	CRect			 m_ColorRect[3];
	FLOAT			 m_fColor[3];
	int				 m_nGlowColorCost;

	CPoint			 m_ColorScrollBar[3];
	CPoint			 m_OriginalColorScrollBar[3];

#ifdef __Y_BEAUTY_SHOP_CHARGE
	BOOL			 m_bChange;
#endif //__Y_BEAUTY_SHOP_CHARGE

	int				 m_ChoiceBar;

	virtual HRESULT RestoreDeviceObjects();
	virtual HRESULT InvalidateDeviceObjects();
	virtual HRESULT DeleteDeviceObjects();

public:
	virtual BOOL OnDropIcon(LPSHORTCUT pShortcut, CPoint point);
	void    ReSetBar(FLOAT r, FLOAT g, FLOAT b);
	virtual void OnMouseWndSurface(CPoint point);
	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void UpDateModel();
	virtual void UpdateParts();
	void UpdateModels();
};
#endif
#ifdef __RESIZE_CHARACTER
class CWndResize : public CWndNeuz
{
public:
	CTexture m_Texture;
	CModelObject* m_pModel;

	BOOL m_bLButtonClick;
	CRect m_ColorRect[3];
	FLOAT m_fColor[3];
	int m_nGlowColorCost;

	CPoint m_ColorScrollBar[3];
	CPoint m_OriginalColorScrollBar[3];

#ifdef __Y_BEAUTY_SHOP_CHARGE
	BOOL m_bChange;
#endif //__Y_BEAUTY_SHOP_CHARGE
	int m_ChoiceBar;

public:
	CWndResize();
	~CWndResize();
	void ReSetBar(FLOAT r, FLOAT g, FLOAT b);

	virtual HRESULT RestoreDeviceObjects();
	virtual HRESULT InvalidateDeviceObjects();
	virtual HRESULT DeleteDeviceObjects();

	virtual void OnMouseWndSurface(CPoint point);
	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual	void OnDestroy(void);
};
#endif // __RESIZE_CHARACTER
#ifdef __ITEM_CONVERTER
class CWndOnGetItem_1 : public CWndNeuz
{
public:

	CWndOnGetItem_1();
	virtual ~CWndOnGetItem_1();
	CWndComboBox* m_pComboKind;

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
};

class CWndOnGetItem_2 : public CWndNeuz
{
public:

	CWndOnGetItem_2();
	virtual ~CWndOnGetItem_2();
	CWndComboBox* m_pComboKind;

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
};

class CWndOnGetItem_3 : public CWndNeuz
{
public:

	CWndOnGetItem_3();
	virtual ~CWndOnGetItem_3();
	CWndComboBox* m_pComboKind;

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
};

class CWndOnGetItem_4 : public CWndNeuz
{
public:

	CWndOnGetItem_4();
	virtual ~CWndOnGetItem_4();
	CWndComboBox* m_pComboKind;

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
};

class CWndOnGetItem_5 : public CWndNeuz
{
public:

	CWndOnGetItem_5();
	virtual ~CWndOnGetItem_5();
	CWndComboBox* m_pComboKind;

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
};

class CWndOnGetItem_6 : public CWndNeuz
{
public:

	CWndOnGetItem_6();
	virtual ~CWndOnGetItem_6();
	CWndComboBox* m_pComboKind;

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
};
#endif // __ITEM_CONVERTER
//////////////////////////////////////////////////////////////////////////////////////
// ¾ÖÇÃ·§ À©µµ 
//
class CWndApplet : public CWndNeuz
{
public:
	CWndListBox m_wndList;
	CWndButton m_wndButton1;
	CWndButton m_wndButton2;
	CWndButton m_wndButton3;

	CWndApplet();
	virtual ~CWndApplet();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL,DWORD dwWndId = 0);
	// message
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual BOOL OnChildNotify(UINT message,UINT nID,LRESULT* pLResult);

};

//////////////////////////////////////////////////////////////////////////////////////
// µå·Ó¾ÆÀÌÅÛ 
//
class CWndDropItem : public CWndNeuz 
{ 
public: 
	CItemElem* m_pItemElem;
	D3DXVECTOR3 m_vPos;
	CWndEdit* m_pEdit;

	CWndDropItem(); 
	virtual ~CWndDropItem(); 
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
#if __VER >= 14 // __DROP_CONFIRM_BUG
	virtual BOOL Process( void );
#endif // __DROP_CONFIRM_BUG
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
}; 

class CWndDropConfirm : public CWndNeuz 
{ 
public: 
	CItemElem* m_pItemElem;
	D3DXVECTOR3 m_vPos;
	
	CWndDropConfirm(); 
	virtual ~CWndDropConfirm(); 
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
#if __VER >= 14 // __DROP_CONFIRM_BUG
	virtual BOOL Process( void );
#endif // __DROP_CONFIRM_BUG
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
}; 

class CWndRandomScrollConfirm : public CWndNeuz 
{ 
public:
	BOOL bFlag;
	OBJID objid, objid1;
	void SetItem( OBJID objidBuf, OBJID objid1Buf, BOOL bFlagBuf = FALSE );
public: 
	CWndRandomScrollConfirm(); 
	virtual ~CWndRandomScrollConfirm(); 
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
}; 

class CWndQuestItemWarning : public CWndNeuz 
{ 
public: 
	CItemElem* m_pItemElem;
	D3DXVECTOR3 m_vPos;

	CWndQuestItemWarning(); 
	virtual ~CWndQuestItemWarning(); 
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
}; 

#ifdef __MALEVOLENT_CP
class CWndCharInfoTab : public CWndNeuz
{

public:
	CWndButton		m_wndChangeJob;
	//	CWndChangeJob*	m_pWndChangeJob;
	BOOL			m_fWaitingConfirm;
	BOOL			m_bExpert;
	int				m_nDisplay;

	CWndButton m_wndStrPlus, m_wndStrMinus;
	CWndButton m_wndStaPlus, m_wndStaMinus;
	CWndButton m_wndDexPlus, m_wndDexMinus;
	CWndButton m_wndIntPlus, m_wndIntMinus;

	CWndButton m_wndApply, m_wndReset;

	CWndEdit m_editStrCount;
	CWndEdit m_editStaCount;
	CWndEdit m_editDexCount;
	CWndEdit m_editIntCount;

	int m_nStrCount;
	int m_nStaCount;
	int m_nDexCount;
	int m_nIntCount;

	int m_nGpPoint;

	int m_nATK;
	int m_nDEF;
	int m_nCritical;

public:

	CWndCharInfoTab();
	virtual ~CWndCharInfoTab();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD dwWndId = 0);
	// message
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	void RefreshStatPoint();
#ifdef __NO_HP_DMG_LIMIT
	void GetVirtualATK(long long* pnMin, long long* pnMax);
#else
	void GetVirtualATK(int* pnMin, int* pnMax);
#endif

	int GetVirtualDEF();
	int GetVirtualCritical();
	int GetVirtualCritdmg();
	int GetVirtualCasttime();
	int GetVirtualMeleeBlock();
	int GetVirtualRangeBlock();

protected:
	void RenderATK(C2DRender* p2DRender, int x, int y);
};
class CWndInfoPanel : public CWndNeuz
{
public:
	CWndInfoPanel();
	~CWndInfoPanel();
	void UpdateData(void);
	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnFunctionTele();
};
#endif

#ifdef __MALEVOLENT_CP
class CWndUserpanel : public CWndNeuz
{
public:
	CWndUserpanel();
	~CWndUserpanel();
	CWndCharInfoTab m_WndCharInfoTab;
	CWndInfoPanel	m_WndInfoPanelTab;
	//	CWndRefresher	m_WndRefresherTab;
	/*
	CWndTeleporter ;m_WndTeleporterTab;
	CWndPetfilter m_WndPetfilterTab;
	*/
	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
};
#endif

//////////////////////////////////////////////////////////////////////////////////////
//  Äù½ºÆ® ¾ÆÀÌÅÛ Á¤º¸ Ã¢
//
class CWndQuestItemInfo : public CWndNeuz
{
public:
	CWndQuestItemInfo();
	virtual ~CWndQuestItemInfo();

	CItemBase*	m_pItemBase;
	CPoint		m_Position;

	inline void SetItemBase(CItemBase* pItemBase = NULL) { m_pItemBase = pItemBase; };
	
	BOOL Create(CItemBase* pItemBase, UINT nID, CWndBase* pWndParent = NULL );
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, CItemBase* pItemBase = NULL); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
};

//////////////////////////////////////////////////////////////////////////////////////
// ÀÎº¥Åä¸® 
//
#if __VER >= 9 // __CSC_VER9_1
class CWndRemoveJewelConfirm;
#endif //__CSC_VER9_1

class CWndGold : public CWndButton
{
public:
	CTexture m_texture;
	CWndGold();
	virtual ~CWndGold();
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	virtual	void OnInitialUpdate();
};

class CWndConfirmBuy;
class CWndInventory : public CWndNeuz
{
	CPoint				m_OldPos;
	FLOAT				m_fRot;
	CModelObject*		m_pModel;
	BOOL				m_bLButtonDownRot;
public:
	CRect		 m_InvenRect[MAX_HUMAN_PARTS];

	CModelObject m_meshStage;
	CItemElem* m_pSelectItem;
	BOOL m_bReport;
#ifdef __CLEAR_INV
	CWndMenu m_wndMenu;
#endif
	CTexture* m_TexRemoveItem;

#ifdef __HIDE_COAT
	CWndButton m_awndCheckHide[5];
#endif // __HIDE_COAT
#ifdef __MOUNT
	CWndMenu m_wndMenuMount;
#endif // __MOUNT
public:
	void UpDateModel();

	void UpdateParts();
	CModelObject* GetModel() { return m_pModel; }
	void BaseMouseCursor();
	void RunUpgrade( CItemBase* pItem );
	void SetEnchantCursor();
	
	CSfx*		m_pSfxUpgrade;
	CItemBase*	m_pUpgradeItem;
	CItemBase*	m_pUpgradeMaterialItem;
	BOOL		m_bIsUpgradeMode;
	DWORD		m_dwEnchantWaitTime;

	CWndConfirmBuy* m_pWndConfirmBuy;
	CWndGold     m_wndGold;
#ifdef __TABBED_INV
	CWndInventoryCtrl m_wndInvCtrl[4];
#else // __TABBED_INV
	CWndItemCtrl m_wndItemCtrl;
#endif // __TABBED_INV
#if __VER >= 9 // __CSC_VER9_1
	BOOL		m_bRemoveJewel;
	CWndRemoveJewelConfirm* m_pWndRemoveJewelConfirm;
#endif //__CSC_VER9_1
	CWndInventory();
	virtual ~CWndInventory();
	virtual BOOL Process ();
	virtual void OnMouseWndSurface( CPoint point );
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL,DWORD dwWndId = 0);
	// message
	virtual BOOL OnChildNotify(UINT message,UINT nID,LRESULT* pLResult);
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point);
	virtual void OnRButtonDown(UINT nFlags, CPoint point);
#ifdef __MOUNT
	virtual void OnRButtonUp(UINT nFlags, CPoint point);
#endif // __MOUNT
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point = 0 );
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	virtual void OnDestroyChildWnd( CWndBase* pWndChild );
	virtual void OnDestroy( void );
	virtual BOOL OnSetCursor ( CWndBase* pWndBase, UINT nHitTest, UINT message );
	
#if __VER >= 9 // __CSC_VER9_1
public:
#ifdef __TABBED_INV
	void UpdateTooltip(int nIndex) { m_wndInvCtrl[nIndex].UpdateTooltip(); }
#else // __TABBED_INV
	void UpdateTooltip(void) { m_wndItemCtrl.UpdateTooltip(); }
#endif // __TABBED_INV
#endif //__CSC_VER9_1

};

class CWndQueryEquip : public CWndNeuz
{
	CPoint				m_OldPos;
	FLOAT				m_fRot;
	CModelObject*		m_pModel;
	BOOL				m_bLButtonDownRot;
	DWORD		 m_ObjID;
	CRect		 m_InvenRect[MAX_HUMAN_PARTS];

	EQUIP_INFO_ADD	m_aEquipInfoAdd[MAX_HUMAN_PARTS];
public:

	CMover* GetMover() 
	{ 
		if( m_ObjID != NULL_ID )
			return prj.GetMover( m_ObjID ); 

		return NULL;
	}
	void	SetMover( DWORD		 ObjID );
	void	SetEquipInfoAdd( EQUIP_INFO_ADD* aEquipInfoAdd );
	
	CWndQueryEquip();
	virtual ~CWndQueryEquip();
	virtual BOOL Process ();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual void OnMouseWndSurface( CPoint point );
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL,DWORD dwWndId = 0);
	virtual void OnMouseMove (UINT nFlags, CPoint point);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
};


//////////////////////////////////////////////////////////////////////////////////////
// »óÅÂ 
//
class CWndStateConfirm : public CWndNeuz 
{ 
public:
	UINT m_nId;
	void OnSetState( UINT nId );
	void SendYes( void );
public: 
	CWndStateConfirm(); 
	virtual ~CWndStateConfirm(); 
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
}; 
class CWndCharacterBase : public CWndBase
{
	CTexture m_txInfo;

public:
	CWndCharacterBase();
	virtual ~CWndCharacterBase();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL,DWORD dwWndId = 0);
	// message
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual BOOL OnChildNotify(UINT message,UINT nID,LRESULT* pLResult);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
};

class CWndCharacterDetail : public CWndBase
{
	CWndButton m_wndStr;
	CWndButton m_wndSta;
	CWndButton m_wndDex;
	CWndButton m_wndInt;
	
	int			m_nCnt;

public:
	BOOL	m_fWaitingConfirm;
	CWndCharacterDetail();
	virtual ~CWndCharacterDetail();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL,DWORD dwWndId = 0);
	// message
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual BOOL OnChildNotify(UINT message,UINT nID,LRESULT* pLResult);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnMouseWndSurface( CPoint point );

protected:
	void RenderATK( C2DRender* p2DRender, int x, int y );
};

#if __VER >= 9 // __CSC_VER9_2
class CWndCharacterDetail2 : public CWndBase
{
public:
	CWndButton m_wndStrPlus, m_wndStrMinus;
	CWndButton m_wndStaPlus, m_wndStaMinus;
	CWndButton m_wndDexPlus, m_wndDexMinus;
	CWndButton m_wndIntPlus, m_wndIntMinus;
	
	CWndButton m_wndApply, m_wndReset;
	
	CWndEdit m_editStrCount;
	CWndEdit m_editStaCount;
	CWndEdit m_editDexCount;
	CWndEdit m_editIntCount;

	int m_nStrCount;
	int m_nStaCount;
	int m_nDexCount;
	int m_nIntCount;

	int m_nGpPoint;

	int m_nATK;
	int m_nDEF;
	int m_nCritical;
	int m_nATKSpeed;
	
#ifdef __SHOW_ALL_STATS
	int m_nSpeedDepla;
	int m_nCriticalRate;
	int m_nSpellCastSpeed;
	int m_nReflectDamage;
	int m_nHitRate;
	int m_nBlockmelee;
	int m_nBlockRange;
	int m_nEsquiveRate;
#endif //__SHOW_ALL_STATS

public:
	CWndCharacterDetail2();
	virtual ~CWndCharacterDetail2();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL,DWORD dwWndId = 0);
	// message
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual BOOL OnChildNotify(UINT message,UINT nID,LRESULT* pLResult);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnMouseWndSurface( CPoint point );
	virtual BOOL Process ();
	
	void RefreshStatPoint();
#ifdef __NO_HP_DMG_LIMIT
	void GetVirtualATK(long long* pnMin, long long* pnMax);
#else
	void GetVirtualATK(int* pnMin, int* pnMax);
#endif
	int GetVirtualDEF();
	int GetVirtualCritical();
	float GetVirtualATKSpeed();
#ifdef __SHOW_ALL_STATS
	int GetVirtualSpeedDepla();
#endif //__SHOW_ALL_STATS

protected:
	void RenderATK( C2DRender* p2DRender, int x, int y );
};
#endif //__CSC_VER9_2

class CWndChangeJob;

class CWndPvpBase : public CWndBase
{
	CTexture m_txInfo;
	
public:
	CWndButton m_wndChangeJob;
	CWndChangeJob* m_pWndChangeJob;
	BOOL	m_fWaitingConfirm;
	BOOL m_bExpert;
	int m_nDisplay;			// Á÷¾÷Ã¢ È­¸é ¿É¼Ç

	CWndPvpBase();
	virtual ~CWndPvpBase();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL,DWORD dwWndId = 0);
	// message
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual BOOL OnChildNotify(UINT message,UINT nID,LRESULT* pLResult);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
};

class CWndChangeJob : public CWndNeuz
{
public:
	int m_nJob;
	CWndButton m_wndExpert[ 6 ];
	CWndButton m_wndOk;
	CWndButton m_wndCancel;

	CWndChangeJob( int nJob );
	virtual ~CWndChangeJob();
	virtual void OnDraw( C2DRender* p2DRender );
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize( CWndBase* pWndParent = NULL,DWORD dwWndId = 0 );
	// message
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp( UINT nFlags, CPoint point );
	virtual void OnLButtonDown( UINT nFlags, CPoint point );
};

#ifdef __BADGE
class CWndBadgeList : public CWndListBox
{
protected:
	int m_ID;

public:
	CWndBadgeList();
	virtual ~CWndBadgeList();

	virtual void OnInitialUpdate();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnMouseWndSurface(CPoint point);

	const int GetSelected() const {
		return m_ID;
	}
};

#ifndef __BADGE_HONOR_COMBINE
class CWndBadge : public CWndNeuz
{
private:
	CWndBadgeList m_wndBadgeList;

public:
	CWndBadge();
	virtual ~CWndBadge();
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = nullptr, DWORD dwWndId = 0);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);

	CWndButton* m_pOK;
};
#endif //__BADGE_HONOR_COMBINE
#endif //__BADGE

#if __VER >= 13 // __RENEW_CHARINFO
class CWndCharInfo : public CWndBase
{

public:
	CWndButton		m_wndChangeJob;
	CWndChangeJob*	m_pWndChangeJob;
	BOOL			m_fWaitingConfirm;
	BOOL			m_bExpert;
	int				m_nDisplay;

	CWndButton m_wndStrPlus, m_wndStrMinus;
	CWndButton m_wndStaPlus, m_wndStaMinus;
	CWndButton m_wndDexPlus, m_wndDexMinus;
	CWndButton m_wndIntPlus, m_wndIntMinus;
	
	CWndButton m_wndApply, m_wndReset;
	
	CWndEdit m_editStrCount;
	CWndEdit m_editStaCount;
	CWndEdit m_editDexCount;
	CWndEdit m_editIntCount;

#ifdef __AUTO_STATS
	CWndComboBox m_wndAutoStat;
#endif

	int m_nStrCount;
	int m_nStaCount;
	int m_nDexCount;
	int m_nIntCount;

	int m_nGpPoint;

	int m_nATK;
	int m_nDEF;
	int m_nCritical;
	int m_nATKSpeed;

#ifdef __SHOW_ALL_STATS
	int m_nSpeedDepla;
	int m_nCriticalRate;
	int m_nSpellCastSpeed;
	int m_nReflectDamage;
	int m_nHitRate;
	int m_nBlockmelee;
	int m_nBlockRange;
	int m_nEsquiveRate;
#endif //__SHOW_ALL_STATS

public:

	CWndCharInfo();
	virtual ~CWndCharInfo();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL,DWORD dwWndId = 0);
	// message
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual BOOL OnChildNotify(UINT message,UINT nID,LRESULT* pLResult);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnMouseWndSurface( CPoint point );
	virtual BOOL Process ();
	void RefreshStatPoint();
#ifdef __NO_HP_DMG_LIMIT
	void GetVirtualATK(long long* pnMin, long long* pnMax);
#else
	void GetVirtualATK(int* pnMin, int* pnMax);
#endif
	int GetVirtualDEF();
	int GetVirtualCritical();
	float GetVirtualATKSpeed();

#ifdef __SHOW_ALL_STATS
	int GetVirtualSpeedDepla();
	int GetVirtualCriticalRate();
	int GetVirtualSpellCastSpeed();
	int GetVirtualReflectDamage();
	int GetVirtualHitRate();
	int GetVirtualBlockmelee();
	int GetVirtualBlockRange();
	int GetVirtualEsquiveRate();
#endif //__SHOW_ALL_STATS

protected:
	void RenderATK( C2DRender* p2DRender, int x, int y );
};

class CWndHonor : public CWndNeuz
{
private:
	int						m_nSelectedId;
	int						m_nCount;
	vector<EarnedTitle>		m_vecTitle;	
#ifdef __BADGE_HONOR_COMBINE
	CWndBadgeList			m_wndBadgeList;
#endif //__BADGE_HONOR_COMBINE
public:
#ifdef __BADGE_HONOR_COMBINE
	CWndButton* m_pOK;
#endif //__BADGE_HONOR_COMBINE
	CWndHonor();
	virtual ~CWndHonor();
	virtual void OnDraw( C2DRender* p2DRender );
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize( CWndBase* pWndParent = NULL,DWORD dwWndId = 0 );
	// message
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp( UINT nFlags, CPoint point );
	virtual void OnLButtonDown( UINT nFlags, CPoint point );
	void RefreshList();

};
#endif // __RENEW_CHARINFO

class CWndCharacter : public CWndNeuz
{
public:
#if __VER >= 13 // __RENEW_CHARINFO
	CWndCharInfo		m_wndCharInfo;
	CWndHonor			m_wndHonor;
#ifdef __BADGE
#ifndef __BADGE_HONOR_COMBINE
	CWndBadge			m_wndBadge;
#endif //__BADGE_HONOR_COMBINE
#endif //__BADGE
#else // __RENEW_CHARINFO
#if __VER >= 9 // __CSC_VER9_2
	CWndCharacterDetail2 m_wndStateDetail;
#else //__CSC_VER9_2
	CWndCharacterDetail m_wndStateDetail;
#endif
	CWndCharacterBase   m_wndStateBase;	
	CWndPvpBase         m_wndPvp;
#endif // __RENEW_CHARINFO
public:
	CWndCharacter();
	virtual ~CWndCharacter();
	virtual void SerializeRegInfo( CAr& ar, DWORD& dwVersion );
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL,DWORD dwWndId = 0);
	// message
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual BOOL OnChildNotify(UINT message,UINT nID,LRESULT* pLResult);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
};


class CWndReSkillControl : public CWndNeuz
{
public:
	CWndReSkillControl();
	virtual ~CWndReSkillControl();
	virtual void OnDraw( C2DRender* p2DRender );
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize( CWndBase* pWndParent = NULL,DWORD dwWndId = 0 );
	// message
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp( UINT nFlags, CPoint point );
	virtual void OnLButtonDown( UINT nFlags, CPoint point );
};

class CWndReSkillWarning : public CWndNeuz
{
	BOOL	m_bParentDestroy;
public:
	CWndReSkillWarning();
	virtual ~CWndReSkillWarning();

	void InitItem( BOOL bParentDestroy );
	virtual void OnDraw( C2DRender* p2DRender );
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize( CWndBase* pWndParent = NULL,DWORD dwWndId = 0 );
	// message
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp( UINT nFlags, CPoint point );
	virtual void OnLButtonDown( UINT nFlags, CPoint point );
	virtual void OnDestroy();
};



//////////////////////////////////////////////////////////////////////////////////////
// ½ºÅ³ EX 
//
#ifdef __NEW_SKILL_TREE
class CWndSkillTreeEx : public CWndNeuz
{
protected:
	BOOL			m_bDrag;					//¸¶¿ì½º·Î Å¬¸¯Çß´Âµ¥ ½ºÅ³¾ÆÀÌÄÜ ¿µ¿ª ¾È ÀÎ °æ¿ì TRUE
	LPSKILL			m_pFocusItem;				//¼±ÅÃµÈ ¾ÆÀÌÅÛ : Áï ½ºÅ³À» ´õºíÅ¬¸¯ÇÏ°Å³ª ÇØ¼­ ·¹º§À» ¿Ã¸±¼öÀÖ´Â »óÅÂ·Î ¸¸µç ½ºÅ³¾ÆÀÌÅÛ
	int				m_nCurrSkillPoint;		//ÇöÀç ³²Àº ½ºÅ³Æ÷ÀÎÆ®
	CTexturePack	m_textPackNum;			//½ºÅ³ ·¹º§¼ýÀÚ Ç¥½Ã¿ë ±×¸² ( 1, 2,..... max )
	DWORD			m_dwMouseSkill;			//¸¶¿ì½º¿¡ À§Ä¡ÇÑ ½ºÅ³
	CWndButton*		m_pWndButton[4];		//+, -, reset, finish
	LPSKILL			m_apSkill;				//½ºÅ³ ¸ñ·Ï
	CTexture*		m_atexSkill[ MAX_SKILL_JOB ];
#ifdef __NEWCLASS
	CTexture* m_aTexSkillTrees[5];
#else // __NEWCLASS
	CTexture* m_aTexSkillTrees[4];
#endif // __NEWCLASS
	char			m_cOldJob;
	char			m_cActiveSlot;
	char			m_cActiveJobType;
	CTexture*		m_atexTopDown[2];	//these store the up and down icons
	CPoint			m_pointTreePos;
	CTexture*		m_texSelectSkill;	
	CString			m_strHeroSkillIcon;
public:
	BOOL	IsReSkillPointDone();
	int		GetCurrSkillPoint() { return m_nCurrSkillPoint; }
	void	SubSkillPointDown( LPSKILL lpSkill );
	LPSKILL GetSkill() { return m_apSkill; }
	BOOL	IsDownPoint(DWORD skill);
	int		GetCurSelect() { return g_nSkillCurSelect; }
	BOOL	GetSkillPoint(DWORD dwSkillID, CRect& rect );
	LPSKILL GetSkill( int i );
	LPSKILL GetdwSkill( DWORD dwSkill );
	BOOL	CheckSkill( int i );
	void LoadTextureSkillicon();
	void InitItem( int nJob, LPSKILL apSkill, BOOL bReset = FALSE );
	CWndSkillTreeEx();
	virtual ~CWndSkillTreeEx();

	void SetSlot( char cSlot );
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual BOOL Process ();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL,DWORD dwWndId = 0);
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	virtual void OnMouseWndSurface( CPoint point );
	// message
	virtual BOOL OnChildNotify(UINT message,UINT nID,LRESULT* pLResult);
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point);
	void SetActiveSlot( int nSlot, BOOL bFlag );
	virtual void SerializeRegInfo ( CAr& ar, DWORD& dwVersion );
	virtual HRESULT RestoreDeviceObjects();
	virtual HRESULT InvalidateDeviceObjects();
	virtual HRESULT DeleteDeviceObjects();	
};
#else
class CWndSkillTreeEx : public CWndNeuz
{
protected:
	int			  m_nCount;					//ÇöÀç Á÷¾÷¿¡ ÇØ´çÇÏ´Â ½ºÅ³ ÃÑ °¹¼ö

	int           m_nCurSelect  ;			//À× ¾È¾²°íÀÖ´Âµ¥?
	BOOL          m_bDrag;					//¸¶¿ì½º·Î Å¬¸¯Çß´Âµ¥ ½ºÅ³¾ÆÀÌÄÜ ¿µ¿ª ¾È ÀÎ °æ¿ì TRUE
	LPSKILL       m_pFocusItem;				//¼±ÅÃµÈ ¾ÆÀÌÅÛ : Áï ½ºÅ³À» ´õºíÅ¬¸¯ÇÏ°Å³ª ÇØ¼­ ·¹º§À» ¿Ã¸±¼öÀÖ´Â »óÅÂ·Î ¸¸µç ½ºÅ³¾ÆÀÌÅÛ
	int				m_nCurrSkillPoint;		//ÇöÀç ³²Àº ½ºÅ³Æ÷ÀÎÆ®
	CTexturePack	m_textPackNum;			//½ºÅ³ ·¹º§¼ýÀÚ Ç¥½Ã¿ë ±×¸² ( 1, 2,..... max )
	DWORD			m_dwMouseSkill;			//¸¶¿ì½º¿¡ À§Ä¡ÇÑ ½ºÅ³
	CWndButton*		m_pWndButton[4];		//+, -, reset, finish
	LPSKILL       m_apSkill;				//½ºÅ³ ¸ñ·Ï
	CTexture*     m_atexSkill[ MAX_SKILL_JOB ];
	CTexture*	  m_aSkillLevel[ 3 ];
	//CTexture*     m_atexJobPannel[ 2 ];
	LPIMAGE       m_atexJobPannel[ 2 ];
#if __VER >= 10 // __CSC_VER9_1
	CString		  m_strHeroSkilBg;			//È÷¾î·Î ÀÌ¹ÌÁö ÆÄÀÏ ÀÌ¸§
#endif //__CSC_VER9_1
	int           m_nJob         ;			//class ¹øÈ£
	
	CTexture m_texGauEmptyNormal ;
	CTexture m_texGauFillNormal  ;
	
	LPDIRECT3DVERTEXBUFFER9 m_pVBGauge;

	CTexture*     m_atexTopDown[2];
	int 	m_nTopDownGap;
#if __VER >= 10 // __CSC_VER9_1
	BOOL	m_bSlot[4];
#else
	BOOL	m_bSlot[3];
#endif //__CSC_VER9_1

#if __VER >= 10 // __CSC_VER9_1
	BOOL m_bLegend;							//Àü½Â
	CWndStatic* m_pWndHeroStatic[2];
#endif //__CSC_VER9_1

public:
	BOOL	IsReSkillPointDone();
	int		GetCurrSkillPoint() { return m_nCurrSkillPoint; }
	void	SubSkillPointDown( LPSKILL lpSkill );
	LPSKILL GetSkill() { return m_apSkill; }
	BOOL	IsDownPoint(DWORD skill);
	int		GetCalcImagePos( int nIndex );
	int		GetCurSelect() { return g_nSkillCurSelect; }
	BOOL	GetSkillPoint(DWORD dwSkillID, CRect& rect );
	LPSKILL GetSkill( int i );
	LPSKILL GetdwSkill( DWORD dwSkill );
	BOOL	CheckSkill( int i );
	void LoadTextureSkillicon();
	void InitItem( int nJob, LPSKILL apSkill, BOOL bReset = FALSE );
	CWndSkillTreeEx();
	virtual ~CWndSkillTreeEx();

	void AfterSkinTexture( LPWORD pDest, CSize size, D3DFORMAT d3dFormat = D3DFMT_A4R4G4B4 );
	void SetJob( int nJob );
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual BOOL Process ();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL,DWORD dwWndId = 0);
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	virtual void OnMouseWndSurface( CPoint point );
	// message
	virtual BOOL OnChildNotify(UINT message,UINT nID,LRESULT* pLResult);
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point);
	virtual void OnRButtonDblClk( UINT nFlags, CPoint point);
	void SetActiveSlot( int nSlot, BOOL bFlag );
	virtual void SerializeRegInfo ( CAr& ar, DWORD& dwVersion );
	virtual HRESULT RestoreDeviceObjects();
	virtual HRESULT InvalidateDeviceObjects();
	virtual HRESULT DeleteDeviceObjects();	
};
#endif

//////////////////////////////////////////////////////////////////////////////////////
// ¸Å½ÅÀú  
//

//////////////////////////////////////////////////////////////////////////////////////
// Navigator
//

class CWndNavigator : public CWndNeuz
{
#ifdef __ENGINE_UPGRADE
	CTexture* m_pTexArrow;
#endif //__ENGINGE_UPGRADE
	CWndButton m_wndPlace;
	CWndButton m_wndMover;
	CWndButton m_wndZoomIn;
	CWndButton m_wndZoomOut;
	CWndMenu   m_wndMenuPlace;
	CWndMenu   m_wndMenuMover;
	BILLBOARD  m_billboard;
#ifdef __NAVIGATOR_V19
	CTexture   m_ALPHACIRCLE;
	CTexture   pTextureMap;
	CTexture   pTextureObjs;
	CTexture   pTopTexture;
	CWndButton m_wndClose;
	CWndButton m_wndHelp;

	IDirect3DSurface9* pDstSurface[2];
	CRect innerRect;
#endif // __NAVIGATOR_V19
	CTexture   m_texArrow;
	CTexture   m_texDunFog;
	CTexturePack m_texNavObjs;
	DWORD		 m_iFrame;
	DWORD		 m_iPastTime;
	CTexturePack m_texNavPos;
	inline void	 AccuFrame() { 
		DWORD CurTime = g_tmCurrent;
		if (CurTime - m_iPastTime > 120)
		{
			m_iFrame++; 
			m_iPastTime = CurTime;
		}
		if ( m_iFrame >= 4 )
			m_iFrame = 0;
	};
	void RenderMark( C2DRender* p2DRender, CMover* Player );	//	ÂüÁ¶µÇ´Â º¯¼ö´Â ÇÃ·¹ÀÌ¾î¿Í ÆÄÆ¼ÇÃ·¹ÀÌ¾î¸¦ ¾òÀ» ¼ö ÀÖ´Â °ÍÀÌ¾î¾ß ÇÏÁö¸¸ 
																//	ÇöÀç´Â ÀÚ½Å¸¸À» Âï´Â °ÍÀ» ÇÏ°í ±× ´ÙÀ½¿¡ ÆÄÆ¼ ÇÃ·¹ÀÌ¾îµéÀ» Ã£À»¼ö ÀÖ´Â ¹æ¹ýÀ» Ã£¾Æ º¸ÀÚ²Ù³ª
	void RenderMarkAll( C2DRender* p2DRender , CMover* Player );
	CBillboard m_billArrow;
	CSize      m_size;
	int        m_nSizeCnt;
	TCHAR      m_szName[ 64 ];
	void ResizeMiniMap();
	
	CTexture m_GuildCombatTextureMask;
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
	CTexture* m_pDestinationPositionTexture;
#endif // __IMPROVE_QUEST_INTERFACE

public:
	BOOL m_bObjFilterPlayer ;
	BOOL m_bObjFilterParty  ;
	BOOL m_bObjFilterNPC    ;
	BOOL m_bObjFilterMonster;
	

	void RenderPartyMember( C2DRender* p2DRender, TEXTUREVERTEX** pVertices, CRect rect, D3DXVECTOR3 vPos, u_long uIdPlayer, LPCTSTR lpStr );
	void SetRegionName( TCHAR *tszName );		// Áö¿ª
		
	virtual void SerializeRegInfo( CAr& ar, DWORD& dwVersion );
	
	CWndNavigator(); 
	virtual ~CWndNavigator();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL,DWORD dwWndId = 0);
	// message
	virtual	void SetWndRect( CRect rectWnd, BOOL bOnSize = TRUE );
	virtual BOOL OnChildNotify(UINT message,UINT nID,LRESULT* pLResult);
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnRButtonDown(UINT nFlags, CPoint point);
	virtual BOOL OnEraseBkgnd(C2DRender* p2DRender);
	virtual HRESULT RestoreDeviceObjects();
	virtual HRESULT InvalidateDeviceObjects();
	virtual HRESULT DeleteDeviceObjects();
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point);
};
//////////////////////////////////////////////////////////////////////////////////////
// CWndStatus
//

class CWndStatus : public CWndNeuz
{
	BOOL m_bHPVisible;
	BOOL m_bExpVisible;
public:
	CModel* m_pModel;
	int		m_nDisplay;
public:
	virtual HRESULT RestoreDeviceObjects();
	virtual HRESULT InvalidateDeviceObjects();
	virtual HRESULT DeleteDeviceObjects();
	
	CTexture m_texGauEmptyNormal ;
	CTexture m_texGauEmptySmall  ;
	CTexture m_texGauFillNormal  ;
	CTexture m_texGauFillSmall   ;
#if __VER >= 19
	CTexture m_HPGaugeTexture;
	CTexture m_MPGaugeTexture;
	CTexture m_FPGaugeTexture;
	CTexture m_EXPGaugeTexture;
	CTexture m_AEXPGaugeTexture;
#endif // __VER >= 19
	LPDIRECT3DVERTEXBUFFER9 m_pVBHPGauge;
	LPDIRECT3DVERTEXBUFFER9 m_pVBMPGauge;
	LPDIRECT3DVERTEXBUFFER9 m_pVBFPGauge;
	LPDIRECT3DVERTEXBUFFER9 m_pVBEXPGauge;
	
	BOOL m_bVBHPGauge;
	BOOL m_bVBMPGauge;
	BOOL m_bVBFPGauge;
	BOOL m_bVBEXPGauge;

#if __VER >= 15 // __GUILD_HOUSE
	BOOL m_bShowTip_AEXP;
	BOOL m_bVBAEXPGauge;
	LPDIRECT3DVERTEXBUFFER9 m_pVBAEXPGauge;
#endif
	
	int m_nHPWidth ;
	int m_nMPWidth ;
	int m_nFPWidth ;
	int m_nEXPWidth;
	int m_nPXPWidth;
#ifdef __FL_SMOOTH_STATUS
	int nWidthOldHp;
	int nWidthOldMp;
	int nWidthOldFp;
	int nWidthOldExp;
#endif //__FL_SMOOTH_STATUS

	void MakeGaugeVertex();
	
	CWndStatus(); 
	virtual ~CWndStatus();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL,DWORD dwWndId = 0);
	// message
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual BOOL OnEraseBkgnd(C2DRender* p2DRender);
	virtual	void SetWndRect( CRect rectWnd, BOOL bOnSize = TRUE );
	virtual	void PaintFrame( C2DRender* p2DRender );

#if __VER >= 15 // __GUILD_HOUSE
	virtual void OnMouseWndSurface( CPoint point );
#endif
};

class CWndQuit : public CWndMessageBox
{
	BOOL	m_bFlag;	
public:
	CWndQuit() { }
	virtual ~CWndQuit() { }
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD dwWndId = 0 );
	// message
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
};	
class CWndLogOut : public CWndMessageBox
{
public:
	CWndLogOut() { }
	virtual ~CWndLogOut() { }
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD dwWndId = 0 );
	// message
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
};	


class CWndLogOutWaitting : public CWndNeuz
{
	BOOL  m_bIsLogOut;
	DWORD dwTime;
public:
	CWndLogOutWaitting();
	virtual ~CWndLogOutWaitting();
	void	SetIsLogOut(BOOL bFlag) { m_bIsLogOut = bFlag; }
	virtual BOOL Process ();
	virtual BOOL Initialize( CWndBase* pWndParent );
	virtual	void OnInitialUpdate();
	// message
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
};	

//DECLARE_WNDMESSAGEBOX( CWndLogOut    ) // ·Î±×¾Æ¿ô Ã³¸®ÇÏ´Â ¸Þ½ÃÁö ¹Ú½º Å¬·¹½º 

//BEGIN_WNDCLASS( CWndMacro )
//END_WNDCLASS

//BEGIN_WNDCLASS( CWndStyle )
//END_WNDCLASS

class CWndTradeGold : public CWndNeuz 
{ 
public: 
	UINT m_nIdWndTo;
	SHORTCUT m_Shortcut;
	D3DXVECTOR3 m_vPos;
	DWORD m_dwGold;
	CWndBase* m_pWndBase;
	CWndStatic* pStatic;
	CWndStatic* pStaticCount;
#if __VER >= 11 // __SYS_POCKET
	char m_nSlot;
	char m_nPutSlot;
#else
	BYTE m_nSlot;
	BYTE m_nPutSlot;
#endif
	CWndTradeGold(); 
	virtual ~CWndTradeGold(); 

	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual BOOL Process( void );
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
};

class CWndConfirmTrade : public CWndNeuz 
{ 
	OBJID m_objid;
public: 
	CWndConfirmTrade(); 
	virtual ~CWndConfirmTrade(); 

	void OnSetName( const char* szName, OBJID objid );
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
}; 

class CWndTradeConfirm : public CWndNeuz 
{ 
public: 
	BOOL bMsg;
	CWndTradeConfirm(); 
	virtual ~CWndTradeConfirm(); 
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
}; 

BEGIN_WNDCLASS( CWndTrade )

	CWndTradeCtrl m_wndItemCtrlYou;
	CWndTradeCtrl m_wndItemCtrlI  ;
	CWndStatic    m_wndGold       ;
	int           m_nGoldI, m_nGoldYou;

	void DoCancel();

END_WNDCLASS

//////////

BEGIN_WNDCLASS( CWndEmotion )
	CWndTreeCtrl  m_wndViewCtrl;
	CWndEdit      m_wndEdit;
	CWndButton    m_wndDefault;
	LPTREEELEM    m_lpSelectTreeElem;
END_WNDCLASS


class CWndRevival : public CWndNeuz 
{ 
public: 
	CWndButton* m_pLodeLight;
	CWndButton* m_pLodeStar;
	CWndButton* m_pRevival;
#if __VER >= 9 // __S_9_ADD
	CWndButton* m_pShop;
#endif // __S_9_ADD
	CWndRevival(); 
	virtual ~CWndRevival(); 

	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
	void	EnableButton( int nButton, BOOL bEnable );
}; 

class CWndReWanted : public CWndNeuz 
{ 
public: 
	CWndReWanted(); 
	virtual ~CWndReWanted(); 

private:
	CString      m_strWanted;
	
public: 
	BOOL         CheckWantedInfo( int nGold, LPCTSTR szMsg );
	void		 SetWantedName( LPCTSTR szWanted );

	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
}; 

class CWndResurrectionConfirm : public CWndNeuz 
{ 
public: 
	CWndResurrectionConfirm(); 
	virtual ~CWndResurrectionConfirm(); 
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
}; 

class CWndWantedConfirm : public CWndNeuz 
{ 
	int		 m_nGold;
	char	 m_szName[ MAX_NAME ];
public: 
	CWndWantedConfirm(); 
	virtual ~CWndWantedConfirm(); 
	
	void		 SetInfo( const char szName[], const int nGold );
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
}; 


struct WANTEDLIST
{
	char	 szName[ MAX_NAME ];		// ÀÌ¸§.
	__int64	 nGold;						// Çö»ó±Ý
	char     szDate[32];
	char	 szMsg[WANTED_MSG_MAX + 1];	// ½ÊÀÚÆò 
};

class CWndWanted : public CWndNeuz 
{ 
private: 
	CWndWantedConfirm*  m_pWantedConfirm;
	time_t				m_recvTime;
	CWndScrollBar		m_wndScrollBar;
	int					m_nMax;
	WANTEDLIST			m_aList[MAX_WANTED_LIST];
	int					m_nSelect;

public: 
	CWndWanted(); 
	virtual ~CWndWanted(); 
	
	int          GetSelectIndex( const CPoint& point );	
	void		 Init( time_t lTime );
	void		 InsertWanted( const char szName[], __int64 nGold,  int nTime, const char szMsg[] );	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
	virtual	void OnRButtonUp( UINT nFlags, CPoint point );
	virtual void OnRButtonDown( UINT nFlags, CPoint point );
	virtual void OnMouseMove(UINT nFlags, CPoint point );
	virtual BOOL OnMouseWheel( UINT nFlags, short zDelta, CPoint pt );
	virtual void OnMouseWndSurface( CPoint point );
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point);	
}; 


class CWndCommItemDlg : public CWndNeuz 
{ 
public: 
	CWndEdit*		m_pWndEdit;
	DWORD			m_dwObjId;
	DWORD			m_dwCtrlId;
	void			SetItem( DWORD dwDefindText, DWORD dwObjId, DWORD dwCtrlId );
	CWndCommItemDlg(); 
	virtual ~CWndCommItemDlg(); 
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
}; 

class CWndChangeClass1 : public CWndNeuz 
{ 
public: 
	int			nJob;
	void		SetJob();

	CWndChangeClass1(); 
	virtual ~CWndChangeClass1(); 
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
}; 

class CWndChangeClass2 : public CWndNeuz 
{ 
public: 
	int			nJob;
	void		SetJob();
	
	CWndChangeClass2(); 
	virtual ~CWndChangeClass2(); 
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
}; 

class CWndPostSendConfirm;

class CWndPostSend : public CWndNeuz
{
	int		m_nCost;
	int		m_nCount;
	BYTE    m_nItem;

public:	
	void ClearData();
	CWndPostSend(); 
	virtual ~CWndPostSend(); 
	
	
	BYTE GetItemId() { return m_nItem; }
	void SetItemId( BYTE nId );
	void SetCost( int nCost ) { m_nCost = nCost; }
	void SetCount( int nCount ) { m_nCount = nCount; }
	void SetReceive( char* pchar );
	void SetTitle( char* pchar );	
	void SetText( char* pchar );	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );		
	virtual void OnRButtonUp( UINT nFlags, CPoint point );
	virtual void AdditionalSkinTexture( LPWORD pDest, CSize sizeSurface, D3DFORMAT d3dFormat = D3DFMT_A4R4G4B4 );
};

class CWndPostItemWarning : public CWndNeuz 
{ 
public: 
	int	   m_nMailIndex;
	
	CWndPostItemWarning(); 
	virtual ~CWndPostItemWarning(); 
	
	void	SetIndex( int nIndex ) { m_nMailIndex = nIndex; }
	void	SetString( char* string );
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
}; 

class CWndPostDeleteConfirm;
class CWndPostRead : public CWndNeuz
{
	int					m_nMailIndex;
	CWndGold			m_wndGold;
	BOOL				m_bDrag;
	CWndPostDeleteConfirm* m_pDeleteConfirm;
	
public:	
	CWndPostItemWarning*		m_pWndPostItemWarning;
	void MailReceiveItem();
	void MailReceiveGold();
	void ClearData();
	CWndPostRead(); 
	virtual ~CWndPostRead(); 
	
	void SetValue( int nMailIndex );
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
	virtual void OnMouseMove(UINT nFlags, CPoint point );	
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );		
	virtual void OnRButtonUp( UINT nFlags, CPoint point );
#ifdef __ADVANCED_MAIL
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);
#endif // __ADVANCED_MAIL
};


class CWndPostReceive : public CWndNeuz
{
#ifdef __ADVANCED_MAIL
	CWndMenu m_wndMenu;
	CWndPostDeleteConfirm* m_pWndPostDeleteConfirm;
#endif // __ADVANCED_MAIL
	CTexture			m_Texture[3];
	CWndScrollBar		m_wndScrollBar;
	int					m_nSelect;
	int					m_nMax;
	CWndPostRead*		m_wndPostRead;
public:	
	void UpdateScroll();
	
	CWndPostReceive(); 
	virtual ~CWndPostReceive(); 

	int          GetSelectIndex( const CPoint& point );	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
	virtual BOOL OnMouseWheel( UINT nFlags, short zDelta, CPoint pt );
	virtual	void OnLButtonDblClk( UINT nFlags, CPoint point );
	virtual HRESULT DeleteDeviceObjects();
	virtual void OnMouseWndSurface( CPoint point );
#ifdef __ADVANCED_MAIL
	virtual void OnRButtonUp(UINT nFlags, CPoint point);
#endif // __ADVANCED_MAIL
};
class CWndPost : public CWndNeuz
{
public:
	CWndPostSend		m_PostTabSend;
	CWndPostReceive		m_PostTabReceive;
	
	CWndPost(); 
	virtual ~CWndPost(); 
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 

#ifdef __MAIL_REQUESTING_BOX
public:
	void LoadLastMailBox( void );
	void SaveLastMailBox( void );
	void CloseMailRequestingBox( void );

private:
	CWndMailRequestingBox* m_pWndMailRequestingBox;
#endif // __MAIL_REQUESTING_BOX
};
class CWndPostSendConfirm : public CWndNeuz
{
protected:
	CWndText	m_wndText;
	
	BYTE		m_nItem;
	short		m_nItemNum;
	int			m_nGold;
	char		m_szReceiver[MAX_NAME];
	char		m_szTitle[MAX_MAILTITLE];	
	char		m_szText[MAX_MAILTEXT];		
public: 
	CWndPostSendConfirm();
	virtual ~CWndPostSendConfirm();
	
	void			SetValue( BYTE nItem, short nItemNum, char* lpszReceiver, int nGold, char* lpszTitle, char* lpszText );
	virtual	BOOL	Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual	BOOL	OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual	void	OnDraw( C2DRender* p2DRender );
	virtual	void	OnInitialUpdate();
	virtual	BOOL	OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase );
	virtual	void	OnSize( UINT nType, int cx, int cy );
	virtual void	OnLButtonUp( UINT nFlags, CPoint point );
	virtual	void	OnLButtonDown( UINT nFlags, CPoint point );
}; 

class CWndPostDeleteConfirm : public CWndNeuz
{
protected:
	CWndText	m_wndText;
	int		m_nIndex;
public: 
	CWndPostDeleteConfirm();
	virtual ~CWndPostDeleteConfirm();
	
	void			SetValue( int nIndex ) { m_nIndex = nIndex; }
	virtual	BOOL	Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual	BOOL	OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual	void	OnDraw( C2DRender* p2DRender );
	virtual	void	OnInitialUpdate();
	virtual	BOOL	OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase );
	virtual	void	OnSize( UINT nType, int cx, int cy );
	virtual void	OnLButtonUp( UINT nFlags, CPoint point );
	virtual	void	OnLButtonDown( UINT nFlags, CPoint point );
}; 

struct GUILDLIST
{
	char	 szGuild[ MAX_NAME ];		// ÀÌ¸§.
	char	 szName[ MAX_NAME ];		// ÀÌ¸§.
	int		 nNum;
};

class CWndGuildCombatOffer : public CWndNeuz
{
protected:
	DWORD			m_dwReqGold;
	DWORD			m_dwMinGold;
	DWORD			m_dwBackupGold;

public: 
	CWndGuildCombatOffer();
	virtual ~CWndGuildCombatOffer();
	
	virtual	BOOL	Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual	BOOL	OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual	void	OnDraw( C2DRender* p2DRender );
	virtual	void	OnInitialUpdate();
	virtual	BOOL	OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase );
	virtual	void	OnSize( UINT nType, int cx, int cy );
	virtual void	OnLButtonUp( UINT nFlags, CPoint point );
	virtual	void	OnLButtonDown( UINT nFlags, CPoint point );
	void			SetGold( DWORD nCost );
	void			SetTotalGold( __int64 nCost );
	void			SetMinGold( DWORD dwMinGold )		{ m_dwMinGold    = dwMinGold; }
	void			SetReqGold( DWORD dwReqGold )		{ m_dwReqGold    = dwReqGold; }
	void			SetBackupGold( DWORD dwBackupGold ) { m_dwBackupGold = dwBackupGold; }
	void			EnableAccept( BOOL bFlag );	
}; 

class CWndGuildCombatBoard : public CWndNeuz
{
protected:
#if __VER >= 11 // __GUILD_COMBAT_1TO1
public:
	int m_nCombatType;
#endif	//__GUILD_COMBAT_1TO1
public: 
#if __VER >= 11 // __GUILD_COMBAT_1TO1
	CWndGuildCombatBoard(int m_nCombatType);
#else //__GUILD_COMBAT_1TO1
	CWndGuildCombatBoard();
#endif //__GUILD_COMBAT_1TO1
	virtual ~CWndGuildCombatBoard();
	
	virtual	BOOL	Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual	BOOL	OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual	void	OnDraw( C2DRender* p2DRender );
	virtual	void	OnInitialUpdate();
	virtual	BOOL	OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase );
	virtual	void	OnSize( UINT nType, int cx, int cy );
	virtual void	OnLButtonUp( UINT nFlags, CPoint point );
	virtual	void	OnLButtonDown( UINT nFlags, CPoint point );
#if __VER >= 11 // __GUILD_COMBAT_1TO1
	virtual void	PaintFrame( C2DRender* p2DRender );
#endif //__GUILD_COMBAT_1TO1
	void			SetString( CHAR* szChar );
}; 

class CGuildCombatSelectionClearMessageBox : public CWndMessageBox
{ 
public: 
	CString m_strMsg;
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD dwWndId = 0 );
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
}; 

class CGuildCombatInfoMessageBox : public CWndNeuz
{
#if __VER >= 11 // __GUILD_COMBAT_1TO1
public:
	int	m_nCombatType;
#endif //__GUILD_COMBAT_1TO1
public:
#if __VER >= 11 // __GUILD_COMBAT_1TO1
	CGuildCombatInfoMessageBox(int nCombatType);
#else //__GUILD_COMBAT_1TO1
	CGuildCombatInfoMessageBox();
#endif //__GUILD_COMBAT_1TO1
	virtual ~CGuildCombatInfoMessageBox();
	void	SetString( CHAR* szChar );
	virtual	void OnInitialUpdate();
	virtual	BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
#if __VER >= 11 // __GUILD_COMBAT_1TO1
	virtual void PaintFrame( C2DRender* p2DRender );
	void	SetString( CString strMsg );
#endif //__GUILD_COMBAT_1TO1
}; 

class CGuildCombatInfoMessageBox2 : public CWndNeuz
{ 
public: 
	CGuildCombatInfoMessageBox2();
	virtual ~CGuildCombatInfoMessageBox2();
	void	SetString( CHAR* szChar );
	virtual	void OnInitialUpdate();
	virtual	BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
}; 



class CWndGuildCombatSelection : public CWndNeuz
{
protected:	
	multimap<int, CGuildMember*>	m_mapSelectPlayer;   // ±æµå¸®½ºÆ®...·¹º§¼ÒÆÃ

	vector<u_long>					m_vecGuildList   ;   // ±æµå ¸®½ºÆ®
	vector<u_long>					m_vecSelectPlayer;   // Âü°¡ÀÚ ¸®½ºÆ®..

	u_long							m_uidDefender;
	CTexture						m_TexDefender;
	int								m_nDefenderIndex;
	
	int								nMaxJoinMember;
	int								nMaxWarMember;
	
public: 
	void Reset();
	CWndGuildCombatSelection();
	virtual ~CWndGuildCombatSelection();
	
	virtual	BOOL	Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual	BOOL	OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual	void	OnDraw( C2DRender* p2DRender );
	virtual	void	OnInitialUpdate();
	virtual	BOOL	OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase );
	virtual	void	OnSize( UINT nType, int cx, int cy );
	virtual void	OnLButtonUp( UINT nFlags, CPoint point );
	virtual	void	OnLButtonDown( UINT nFlags, CPoint point );
	void			EnableFinish( BOOL bFlag );		

	void			SetDefender( u_long uiPlayer );
	void			UpDateGuildListBox();

	void			AddCombatPlayer( u_long uiPlayer );
	void			AddGuildPlayer( u_long uiPlayer );

	void			RemoveCombatPlayer( int nIndex ) ;
	void			RemoveGuildPlayer( int nIndex ) ;

	u_long			FindCombatPlayer( u_long uiPlayer );
	u_long			FindGuildPlayer( u_long uiPlayer );

	void			SetMemberSize( int nMaxJoin,  int nMaxWar );
}; 

class CWndGuildCombatState : public CWndNeuz 
{ 
private: 
	CTimeSpan		m_ct;
	time_t    		m_tEndTime; // timegettime+
	time_t    		m_tCurrentTime; // timegettime+
	
#if __VER >= 11 // __GUILD_COMBAT_1TO1
public:
	int				m_nCombatType;
#endif //__GUILD_COMBAT_1TO1

public:
#if __VER >= 11 // __GUILD_COMBAT_1TO1
	CWndGuildCombatState(int nCombatType);
#else //__GUILD_COMBAT_1TO1
	CWndGuildCombatState();
#endif //__GUILD_COMBAT_1TO1
	virtual ~CWndGuildCombatState(); 
	
	void		 InsertTitle( const char szTitle[] );
	int          GetSelectIndex( const CPoint& point );	
	void		 Init( time_t lTime );
	void		 InsertGuild( const char szGuild[], const char szName[], int nNum );	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
	virtual	void OnRButtonUp( UINT nFlags, CPoint point );
	virtual void OnRButtonDown( UINT nFlags, CPoint point );
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point);	
#if __VER >= 11 // __GUILD_COMBAT_1TO1
	virtual void	PaintFrame( C2DRender* p2DRender );
#endif //__GUILD_COMBAT_1TO1
	virtual BOOL Process ();
#if __VER < 11 // __GUILD_COMBAT_1TO1
	void		 SetTotalGold( __int64 nGold );
#endif //__GUILD_COMBAT_1TO1
	void		 SetGold( int nGold );
	void		 SetRate( int nRate );
	void	 	 SetTime( time_t tTime ) { m_tCurrentTime = 0; m_tEndTime = time_null() + tTime; }
}; 

class CWndGuildCombatJoinSelection : public CWndNeuz
{
protected:
	int	   m_nMapNum;
	CTimer m_timerInputTimeOut;
	DWORD  m_dwOldTime;
	
public: 
	CWndGuildCombatJoinSelection();
	virtual ~CWndGuildCombatJoinSelection();
	
	virtual	BOOL	Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual	BOOL	OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual	void	OnDraw( C2DRender* p2DRender );
	virtual	void	OnInitialUpdate();
	virtual	BOOL	OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase );
	virtual	void	OnSize( UINT nType, int cx, int cy );
	virtual void	OnLButtonUp( UINT nFlags, CPoint point );
	virtual	void	OnLButtonDown( UINT nFlags, CPoint point );
	virtual BOOL	Process ();

	void			SetTimeOut( DWORD dwSec ) { m_dwOldTime = g_tmCurrent + dwSec; }
	void			SetMapNum( int nMap ) { m_nMapNum = nMap; }
}; 

class CWndGuildWarAppConfirm : public CWndNeuz
{
protected:
	CWndText	m_wndText;
public: 
	CWndGuildWarAppConfirm();
	virtual ~CWndGuildWarAppConfirm();
	
	virtual	BOOL	Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual	BOOL	OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual	void	OnDraw( C2DRender* p2DRender );
	virtual	void	OnInitialUpdate();
	virtual	BOOL	OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase );
	virtual	void	OnSize( UINT nType, int cx, int cy );
	virtual void	OnLButtonUp( UINT nFlags, CPoint point );
	virtual	void	OnLButtonDown( UINT nFlags, CPoint point );
}; 
class CWndGuildWarCancelConfirm : public CWndNeuz
{
protected:
	CWndText	m_wndText;
#if __VER >= 11 // __GUILD_COMBAT_1TO1
	int			m_nCombatType;
#endif //__GUILD_COMBAT_1TO1
public:
#if __VER >= 11 // __GUILD_COMBAT_1TO1
	CWndGuildWarCancelConfirm(int nCombatType);
#else //__GUILD_COMBAT_1TO1
	CWndGuildWarCancelConfirm();
#endif //__GUILD_COMBAT_1TO1
	virtual ~CWndGuildWarCancelConfirm();
	
	virtual	BOOL	Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual	BOOL	OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual	void	OnDraw( C2DRender* p2DRender );
	virtual	void	OnInitialUpdate();
	virtual	BOOL	OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase );
	virtual	void	OnSize( UINT nType, int cx, int cy );
	virtual void	OnLButtonUp( UINT nFlags, CPoint point );
	virtual	void	OnLButtonDown( UINT nFlags, CPoint point );
#if __VER >= 11 // __GUILD_COMBAT_1TO1
	virtual void	PaintFrame( C2DRender* p2DRender );
#endif //__GUILD_COMBAT_1TO1
}; 
class CWndGuildWarJoinConfirm : public CWndNeuz
{
#if __VER >= 11 // __GUILD_COMBAT_1TO1
public:
	int			m_nCombatType;
#endif //__GUILD_COMBAT_1TO1
protected:
	CWndText	m_wndText;
public:
#if __VER >= 11 // __GUILD_COMBAT_1TO1
	CWndGuildWarJoinConfirm(int nCombatType);
#else //__GUILD_COMBAT_1TO1
	CWndGuildWarJoinConfirm();
#endif //__GUILD_COMBAT_1TO1
	virtual ~CWndGuildWarJoinConfirm();
	
	virtual	BOOL	Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual	BOOL	OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual	void	OnDraw( C2DRender* p2DRender );
	virtual	void	OnInitialUpdate();
	virtual	BOOL	OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase );
	virtual	void	OnSize( UINT nType, int cx, int cy );
	virtual void	OnLButtonUp( UINT nFlags, CPoint point );
	virtual	void	OnLButtonDown( UINT nFlags, CPoint point );
#if __VER >= 11 // __GUILD_COMBAT_1TO1
	virtual void	PaintFrame( C2DRender* p2DRender );
#endif //__GUILD_COMBAT_1TO1
}; 

class CWndGuildWarState : public CWndNeuz 
{ 
private: 
	CWndScrollBar		m_wndScrollBar;
	int					m_nMax;
	GUILDLIST			m_aList[MAX_WANTED_LIST];
	int					m_nSelect;
	
public: 
	CWndGuildWarState(); 
	virtual ~CWndGuildWarState(); 
	
	void		 InsertTitle( const char szTitle[] );
	int          GetSelectIndex( const CPoint& point );	
	void		 Init( time_t lTime );
	void		 InsertGuild( const char szGuild[], const char szName[], int nNum );	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
	virtual	void OnRButtonUp( UINT nFlags, CPoint point );
	virtual void OnRButtonDown( UINT nFlags, CPoint point );
	virtual void OnMouseMove(UINT nFlags, CPoint point );
	virtual BOOL OnMouseWheel( UINT nFlags, short zDelta, CPoint pt );
	virtual void OnMouseWndSurface( CPoint point );
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point);	
}; 


struct GUILDNAME
{
	char	 szGuild[ MAX_NAME ];		// ÀÌ¸§.
};

class CWndGuildCombatRanking : public CWndNeuz 
{ 
private: 
	CWndScrollBar		m_wndScrollBar;
	int					m_nMax;
	multimap< int, GUILDNAME > m_multimapRanking;
	int					m_nSelect;
	
public: 
	void SortRanking();
	CWndGuildCombatRanking(); 
	virtual ~CWndGuildCombatRanking(); 
	
	int          GetSelectIndex( const CPoint& point );	
	void		 Init( time_t lTime );
	void		 InsertGuild( const char szGuild[], int nWinCount );	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
	virtual	void OnRButtonUp( UINT nFlags, CPoint point );
	virtual void OnRButtonDown( UINT nFlags, CPoint point );
	virtual void OnMouseMove(UINT nFlags, CPoint point );
	virtual BOOL OnMouseWheel( UINT nFlags, short zDelta, CPoint pt );
	virtual void OnMouseWndSurface( CPoint point );
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point);	
}; 

// ±æµå °á°ú ·Î±× - ±æµå
class CWndGuildCombatTabResultRate : public CWndNeuz 
{ 
public: 
	CWndGuildCombatTabResultRate(); 
	virtual ~CWndGuildCombatTabResultRate(); 
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
}; 
// ±æµå °á°ú ·Î±× - °³ÀÎ
class CWndGuildCombatTabResultLog : public CWndNeuz 
{ 
public: 
	CWndGuildCombatTabResultLog(); 
	virtual ~CWndGuildCombatTabResultLog(); 
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
}; 

// ±æµå °á°ú ·Î±×Ã¢
class CWndGuildCombatResult : public CWndNeuz 
{ 
public: 
	void InsertLog( CString str );
	void InsertPersonRate( CString str );
	void InsertGuildRate( CString str );
	CWndGuildCombatResult(); 
	virtual ~CWndGuildCombatResult(); 
	
	CWndGuildCombatTabResultRate   m_WndGuildCombatTabResultRate;
	CWndGuildCombatTabResultLog    m_WndGuildCombatTabResultLog;
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
	virtual void OnMouseMove(UINT nFlags, CPoint point );
}; 



typedef struct __GUILDCOMBAT_RANK_INFO
{
	u_long	uidPlayer;
	int		nJob;
} __GUILDCOMBAT_RANK_INFO;

typedef struct __GUILDCOMBAT_RANK_INFO2
{
	CString strName;
	CString strJob;
	u_long	uidPlayer;
	int		nPoint;	
} __GUILDCOMBAT_RANK_INFO2;

#define MAX_GUILDCOMBAT_RANK_PER_PAGE 11
#define MAX_GUILDCOMBAT_RANK		  100


// ±æµå ·©Å· ÅÇ- Á÷¾÷º°
class CWndGuildCombatRank_Class : public CWndNeuz 
{ 
public: 
	CWndScrollBar		m_wndScrollBar;
	int					m_nMax;
	int					m_nSelect;

	int		m_nRate;
	int		m_nOldRate;

	__GUILDCOMBAT_RANK_INFO2		m_listRank[MAX_GUILDCOMBAT_RANK];

	CWndGuildCombatRank_Class(); 
	virtual ~CWndGuildCombatRank_Class(); 

	void		 InsertRank( int nJob, u_long uidPlayer, int nPoint );
	int          GetSelectIndex( const CPoint& point );	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual BOOL OnMouseWheel( UINT nFlags, short zDelta, CPoint pt );
	virtual	void OnLButtonDown( UINT nFlags, CPoint point );
}; 

// ±æµå ·©Å· - Á÷¾÷º°
class CWndGuildCombatRank_Person : public CWndNeuz 
{ 
public: 
	multimap< int, __GUILDCOMBAT_RANK_INFO > m_mTotalRanking;
			
	CWndGuildCombatRank_Person(); 
	virtual ~CWndGuildCombatRank_Person(); 
	
	CWndGuildCombatRank_Class    m_WndGuildCombatTabClass_Tot;
	CWndGuildCombatRank_Class    m_WndGuildCombatTabClass_Mer;
	CWndGuildCombatRank_Class    m_WndGuildCombatTabClass_Mag;
	CWndGuildCombatRank_Class    m_WndGuildCombatTabClass_Acr;
	CWndGuildCombatRank_Class    m_WndGuildCombatTabClass_Ass;
	
	CWndGuildCombatRank_Class*  __GetJobKindWnd( int nJob );
	void						InsertRank( int nJob, u_long	uidPlayer, int nPoint );
	void						UpdateList();
	void						DivisionList();
	void						UpdatePlayer( int nJob, u_long idPlayer );
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
	virtual void OnMouseMove(UINT nFlags, CPoint point );

}; 

class CWndFontEdit : public CWndNeuz 
{ 
	CTexture*        m_pTexture;
	CPoint			 m_ColorScrollBar[3];
	CPoint			 m_OriginalColorScrollBar[3];
	
	CRect			 m_ColorRect[3];
	FLOAT			 m_fColor[3];
	
	BOOL			 m_bLButtonClick;
	
public: 
	CWndText* m_pWndText;
	CWndFontEdit(); 
	virtual ~CWndFontEdit(); 
	
	void	ReSetBar( FLOAT r, FLOAT g, FLOAT b );
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
	virtual void OnMouseWndSurface( CPoint point );
}; 

#if __VER >= 8 //__CSC_VER8_3

#include "WndWorld.h"

class CWndBuffStatus : public CWndNeuz 
{
public:
	vector< multimap<DWORD, BUFFSKILL> > m_pBuffTexture;
	list<BUFFICON_INFO> m_pBuffIconInfo;

	int m_BuffIconViewOpt;
#ifdef __NEW_BUFF_FORMAT
	CTexture* pTextureBG;
	CTexture* pTextureBG2;
#endif // __NEW_BUFF_FORMAT
public:
	CWndBuffStatus(); 
	virtual ~CWndBuffStatus(); 
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
	virtual void OnRButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnRButtonDown( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point );
	virtual void OnRButtonDblClk( UINT nFlags, CPoint point );
	virtual void OnMouseWndSurface( CPoint point );
	virtual	void PaintFrame( C2DRender* p2DRender );

#ifdef __BUFF_1107
	void RenderBuffIcon( C2DRender *p2DRender, IBuff* pBuff, BOOL bPlayer, BUFFICON_INFO* pInfo, CPoint ptMouse );
#else	// __BUFF_1107
	void RenderBuffIcon( C2DRender *p2DRender, SKILLINFLUENCE* pSkill, BOOL bPlayer, BUFFICON_INFO* pInfo, CPoint ptMouse );
#endif	// __BUFF_1107
	void RenderOptBuffTime(C2DRender *p2DRender, CPoint& point, CTimeSpan &ct, DWORD dwColor );
	void SetBuffIconInfo();
	BOOL GetHitTestResult();
};
#endif //__CSC_VER8_3

#if __VER >= 9 // __CSC_VER9_1
/*******************************
	Á¦·Ã ½Ã½ºÅÛ °ü·Ã Window
********************************/
#include "WndSummonAngel.h"

class CWndMixJewelConfirm : public CWndNeuz
{
public: 
	CWndMixJewelConfirm(); 
	virtual ~CWndMixJewelConfirm(); 
	
	virtual void OnDestroy();
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
};

class CWndMixJewel : public CWndNeuz 
{ 
public:
	CWndText* m_pText;
	GENMATDIEINFO m_MatJewel[MAX_JEWEL];	// cr : uw :
	ItemCountSet m_ItemInfo[MAX_JEWEL];		// cr : uw :
	
	int m_nitemcount;
	int m_nSelectCtrl;
	int m_nOrichalcum;
	int m_nMoonstone;
	
	BOOL m_bStart;
	
	CWndInventory* m_pWndInventory;
	CWndMixJewelConfirm* m_pConfirm;
public: 
	
	CWndMixJewel(); 
	~CWndMixJewel(); 
	
	virtual void SerializeRegInfo( CAr& ar, DWORD& dwVersion );
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point );
	virtual void OnRButtonDblClk( UINT nFlags, CPoint point );
	virtual	void OnMouseMove( UINT nFlags, CPoint point );
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
	virtual void OnDestroy( void );
	virtual	void	OnDestroyChildWnd( CWndBase * pWndChild );	// cr : uw :
	
	void SetDescription( CHAR* szChar );		
	int HitTest( CPoint point );
	void ReceiveResult(int nResult);
	void SetJewel(CItemElem* pItemElem);
	void SetStartBtn(BOOL buse);
	void SetConfirmInit();
};

class CWndExtraction : public CWndNeuz
{
public:
	CWndText* m_pText;
	CItemElem* m_pItemElem;
	ItemProp* m_pEItemProp;
	
public: 
	CWndExtraction(); 
	virtual ~CWndExtraction(); 
	
	virtual void OnDestroy();
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point );
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point );
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
	
	void SetDescription(CHAR* szChar);
	void ReceiveResult(int result, int nCount);
	void SetWeapon(CItemElem* pItemElem);
};

class CWndSmeltJewel : public CWndNeuz
{
public:
	CModelObject* m_pMainItem;
	CItemElem* m_pItemElem;
	CItemElem* m_pJewelElem;
	CWndText* m_pText;
	
#ifdef __ULTIMATE_GEMSLOT_UPGRADE
	DWORD m_dwJewel[10];
	int m_nJewelSlot[10];
#else
	DWORD m_dwJewel[5];
	int m_nJewelSlot[5];
#endif
	int m_nJewelCount;
	int m_nUsableSlot;
	OBJID m_objJewelId;

	float m_fRotate;
	float m_fAddRot;

	int m_nStatus;
	int m_nCount;
	int m_nDelay;
	int m_nAlpha;
	float m_nEyeYPos;
	BOOL m_bFlash;
	
public:
	CWndSmeltJewel(); 
	~CWndSmeltJewel();
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point );
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point );
	virtual	void OnDestroy( void );
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
	virtual BOOL Process ();
	
	void SetDescription(CHAR* szChar);
	void ReceiveResult(int result);
	void InitializeJewel(CItemElem* pItemElem);
	void SetJewel(CItemElem* pItemElem);
};

class CWndChangeWeapon : public CWndNeuz
{
public:
	CWndText* m_pText1;
	CWndText* m_pText2;
	CItemElem* m_pWItemElem;
	CItemElem* m_pJItemElem[2];
	int m_nWeaponType;
	BOOL m_bIsSendChange;
	
public:
	CWndChangeWeapon(int nType);
	virtual ~CWndChangeWeapon(); 
	
	virtual void OnDestroy();
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point );
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point );
	virtual void OnMouseWndSurface( CPoint point );	
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
	virtual BOOL Process ();
	
	void SetDescription(CHAR* szChar);
	void ReceiveResult(int result);
	void SetItem(CItemElem* pItemElem);
};

class CWndRemoveJewelConfirm : public CWndNeuz 
{
public:
	CWndInventory* m_pInventory;
	CItemBase*	m_pUpgradeItem;

public: 
	CWndRemoveJewelConfirm(); 
	virtual ~CWndRemoveJewelConfirm(); 
	
	virtual void OnDestroy();
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point );

	void SetItem(CItemBase*	m_pItem);
};
#endif //__CSC_VER9_1

#if __VER >= 10 // __CSC_VER9_1 -> __LEGEND
/*******************************
	Àü½Â ½Ã½ºÅÛ °ü·Ã Window
********************************/
class CWndHeroSkillUp : public CWndNeuz
{
public:
	CWndText* m_pText;
	CItemElem* m_pItemElem[5];
#ifdef __NEWS_DIAMOND
	int m_JewelID[13];
#else
	int m_JewelID[5];
#endif //__NEWS_DIAMOND
	int m_SlotID[5];
	int m_PicJewel[5];
	BOOL m_bSendHeroSkillup;
	
public: 
	CWndHeroSkillUp(); 
	virtual ~CWndHeroSkillUp(); 
	
	virtual void OnDestroy();
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point );
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point );
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
	
	int HitTest( CPoint point );
	void SetDescription(CHAR* szChar);
	void ReceiveResult(int nresult);
	void SetJewel(CItemElem* pItemElem);
};

#endif //__CSC_VER9_1 -> __LEGEND

#ifdef __TRADESYS

#define MAX_LIST_COUNT 15

class CWndDialogEvent : public CWndNeuz
{
public:
	vector<int> m_nVecList;
	vector<int> m_nDescList;

	int m_nChoiceNum;
	int m_nListCount;
	int m_nDescCount;
	int m_nCurrentPage;
	int m_nMMI;
	int m_nGap;			//List Gap
	int m_nListOffset;	//Selected List Rect Offset
	
public:
	CWndDialogEvent();
	virtual ~CWndDialogEvent(); 
	
	virtual void OnDestroy();
	virtual BOOL Initialize( CWndBase* pWndParent = NULL,DWORD dwWndId = 0 ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	
	void SetDescription(CHAR* szChar);
	void SetMMI(int mmi);
	void ReceiveResult(int result);
};
#endif //__TRADESYS

#if __VER >= 12 // __HEAVEN_TOWER
#define MAX_FLOOR_COUNT 15

class CWndHeavenTower : public CWndNeuz
{
public:
	vector<int> m_nVecList;
	vector<int> m_nDescList;
	vector<int> m_nMsgList;
	vector<int>	m_nCost;

	int m_nChoiceNum;
	int m_nListCount;
	int m_nDescCount;
	int m_nCurrentPage;
	int m_nGap;			//List Gap
	int m_nListOffset;	//Selected List Rect Offset
	
public:
	CWndHeavenTower();
	virtual ~CWndHeavenTower(); 
	
	virtual void OnDestroy();
	virtual BOOL Initialize( CWndBase* pWndParent = NULL,DWORD dwWndId = 0 ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	
	void InitText();
	void InitWnd();
};

class CWndHeavenTowerEntranceConfirm : public CWndMessageBox
{ 
public: 
	DWORD	m_nFloor;

public:
	void	SetValue( CString str, DWORD nFloor );
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD dwWndId = 0 );
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
}; 

#endif //__HEAVEN_TOWER

#if __VER >= 10 // __REMOVE_ATTRIBUTE

class CWndRemoveAttributeConfirm : public CWndNeuz 
{
public: 
	CWndRemoveAttributeConfirm(); 
	virtual ~CWndRemoveAttributeConfirm(); 
	
	virtual void OnDestroy();
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point );
};

class CWndRemoveAttribute : public CWndNeuz
{
public:
	CWndText* m_pText;
	CItemElem* m_pItemElem;
	ItemProp* m_pEItemProp;
	CTexture* m_pTexture;
	
	CWndRemoveAttributeConfirm* m_pWndConfirm;

public: 
	CWndRemoveAttribute(); 
	virtual ~CWndRemoveAttribute(); 
	
	virtual void OnDestroy();
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point );
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point );
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
	
	void SetDescription(CHAR* szChar);
	void ReceiveResult(BOOL result);
	void SetWeapon(CItemElem* pItemElem);
};

#endif //__REMOVE_ATTRIBUTE

#if __VER >= 11 // __PIERCING_REMOVE
class CWndRemovePiercing : public CWndNeuz
{
public:
	CWndText*	m_pText;
	CItemElem*	m_pItemElem;
	ItemProp*	m_pEItemProp;
	CTexture*	m_pTexture;
#if __VER >= 12 // __CSC_VER12_4
	int			m_nInfoSlot[10];
#endif //__CSC_VER12_4
	
public: 
	CWndRemovePiercing(); 
	virtual ~CWndRemovePiercing(); 
	
	virtual void OnDestroy();
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point );
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point );
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
	
	void SetDescription(CHAR* szChar);
#if __VER >= 12 // __CSC_VER12_4
	virtual void OnMouseWndSurface( CPoint point );
	void SetItem(CItemElem* pItemElem);
#else //__CSC_VER12_4
	void SetSuit(CItemElem* pItemElem);
#endif //__CSC_VER12_4
};
#endif //__PIERCING_REMOVE

#if __VER >= 12 // __CSC_VER12_4
class CWndRemoveJewel : public CWndNeuz
{
public:
	CWndText*	m_pText;
	CItemElem*	m_pItemElem;
	CItemElem*	m_pMoonstone;
	ItemProp*	m_pEItemProp;
	CTexture*	m_pTexture;
	CTexture*	m_pMoonstoneTex;
	int			m_nJewelCount;
#ifdef __ULTIMATE_GEMSLOT_UPGRADE
	int			m_nJewelID[10];
	int			m_nJewelSlot[10];
	CTexture* m_pJewelTex[10];
	int			m_nInfoSlot[10];
#else
	int			m_nJewelID[5];
	int			m_nJewelSlot[5];
	CTexture* m_pJewelTex[5];
	int			m_nInfoSlot[5];
#endif
	
public: 
	CWndRemoveJewel(); 
	virtual ~CWndRemoveJewel(); 
	
	virtual void OnDestroy();
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual void OnLButtonUp( UINT nFlags, CPoint point ); 
	virtual void OnLButtonDown( UINT nFlags, CPoint point );
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point );
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
	virtual void OnMouseWndSurface( CPoint point );

	void SetDescription(CHAR* szChar);
	void SetItem(CItemElem* pItemElem);

private:
	void ResetJewel();
};
#endif //__CSC_VER12_4

#if __VER >= 13 // __EXT_ENCHANT
class CWndChangeAttribute : public CWndNeuz 
{
public:
	CWndText* m_pText;
	int m_nAttributeNum;
	int m_nAttributeStaticID[5];
	int m_nTooltipTextIndx[6];
	CItemElem* m_pItemElem;
	CItemElem* m_pChangeItem;
	CTexture* m_pTexture;

public: 
	CWndChangeAttribute(); 
	virtual ~CWndChangeAttribute();
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual	void OnInitialUpdate();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual void OnLButtonUp( UINT nFlags, CPoint point );
	virtual BOOL OnSetCursor( CWndBase* pWndBase, UINT nHitTest, UINT message );
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point );
	virtual BOOL Process();

public:
	void SetChangeItem( CItemElem* pItemElem );
	void FillRect(C2DRender *p2DRender, CRect rectBg, DWORD dwColorstart, DWORD dwColorend);
};
#endif //__EXT_ENCHANT

#if __VER >= 13 // __CSC_VER13_2
class CWndCoupleMessage : public CWndMessageBox
{
public:
	enum { CM_SENDPROPOSE = 0, CM_RECEIVEPROPOSE, CM_CANCELCOUPLE };

	CString m_strText;
	int m_nMode;
	CObj* m_pTargetObj;

public:	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD dwWndId = 0 );
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );

public:
	void SetMessageMod(CString strText, int nMode, CObj* pTargetObj = NULL);
};

class CWndCoupleTabInfo : public CWndNeuz 
{
public:
	CCouple* m_pCouple;

	CTexture m_texGauEmptyNormal;
	CTexture m_texGauFillNormal;
	LPDIRECT3DVERTEXBUFFER9 m_pVBGauge;

public: 
	CWndCoupleTabInfo(); 
	virtual ~CWndCoupleTabInfo();
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual	void OnInitialUpdate();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual HRESULT RestoreDeviceObjects();
	virtual HRESULT InvalidateDeviceObjects();
	virtual HRESULT DeleteDeviceObjects();	
};

class CWndCoupleTabSkill : public CWndNeuz 
{
public:
	CWndText* m_pText;
	CTexture* m_pSkillBgTexture;

public: 
	CWndCoupleTabSkill(); 
	virtual ~CWndCoupleTabSkill();
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual	void OnInitialUpdate();
	virtual void OnDraw(C2DRender* p2DRender);
};

class CWndCoupleManager : public CWndNeuz 
{
public:
	CWndCoupleTabInfo	m_wndCoupleTabInfo;
	CWndCoupleTabSkill	m_wndCoupleTabSkill;
public: 
	CWndCoupleManager(); 
	virtual ~CWndCoupleManager();
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual	void OnInitialUpdate();
};
#endif //__CSC_VER13_2

#ifdef __FUNNY_COIN
class CWndFunnyCoinConfirm : public CWndNeuz 
{
public:
	DWORD m_dwItemId;
	CItemElem* m_pItemElem;

public: 
	CWndFunnyCoinConfirm(); 
	virtual ~CWndFunnyCoinConfirm(); 
	
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual	void OnInitialUpdate(); 
	void SetInfo(DWORD dwItemId, CItemElem* pItemElem);
};
#endif //__FUNNY_COIN

#if __VER >= 14 // __SMELT_SAFETY

class CWndSmeltSafety : public CWndNeuz
{
public:
#if __VER >= 15 // __15_5TH_ELEMENTAL_SMELT_SAFETY
	enum WndMode { WND_NORMAL, WND_ACCESSARY, WND_PIERCING, WND_ELEMENT };
#else // __15_5TH_ELEMENTAL_SMELT_SAFETY
	enum WndMode {WND_NORMAL, WND_ACCESSARY, WND_PIERCING};
#endif // __15_5TH_ELEMENTAL_SMELT_SAFETY
	enum { SMELT_MAX = 10 };
	enum { EXTENSION_PIXEL = 32, HALF_EXTENSION_PIXEL = EXTENSION_PIXEL / 2 };
#if __VER >= 15 // __15_5TH_ELEMENTAL_SMELT_SAFETY
	enum { GENERAL_NON_USING_SCROLL2_LEVEL = 7, ELEMENTAL_NON_USING_SCROLL2_LEVEL = 10 };
#endif // __15_5TH_ELEMENTAL_SMELT_SAFETY

private:
	WndMode m_eWndMode;
	CItemElem* m_pItemElem;
	CTexture* m_pItemTexture;
	CTexture* m_pNowGaugeTexture;
	CTexture* m_pSuccessTexture;
	CTexture* m_pFailureTexture;
	int m_nMaterialCount;
	int m_nScroll1Count;
	int m_nScroll2Count;
	int m_nResultCount;
	BOOL m_bStart;
	bool m_bResultSwitch;
	DWORD m_dwEnchantTimeStart;
	DWORD m_dwEnchantTimeEnd;
	float m_fGaugeRate;
	int m_nValidSmeltCounter;
	int m_nCurrentSmeltNumber;
	int m_nResultStaticID[SMELT_MAX];
	GENMATDIEINFO m_Material[SMELT_MAX];
	GENMATDIEINFO m_Scroll1[SMELT_MAX];
	GENMATDIEINFO m_Scroll2[SMELT_MAX];
	bool m_bResultStatic[SMELT_MAX];
	LPDIRECT3DVERTEXBUFFER9 m_pVertexBufferGauge;
	LPDIRECT3DVERTEXBUFFER9 m_pVertexBufferSuccessImage;
	LPDIRECT3DVERTEXBUFFER9 m_pVertexBufferFailureImage;
#if __VER >= 15 // __15_5TH_ELEMENTAL_SMELT_SAFETY
	ItemProp* m_pSelectedElementalCardItemProp;
#endif // __15_5TH_ELEMENTAL_SMELT_SAFETY

public:
	CWndSmeltSafety(WndMode eWndMode);
	virtual ~CWndSmeltSafety();

	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual	void OnInitialUpdate();
	virtual BOOL Process();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point = 0 );
	virtual void OnLButtonDblClk( UINT nFlags, CPoint point);
	virtual HRESULT RestoreDeviceObjects();
	virtual HRESULT InvalidateDeviceObjects();
	virtual HRESULT DeleteDeviceObjects();

	void SetItem(CItemElem* pItemElem);
	void RefreshInformation(void);
	void RefreshText(void);
	void RefreshValidSmeltCounter(void);
	void StopSmelting(void);
	void DisableScroll2(void);
	void ResetData(void);
	void AddListItem(GENMATDIEINFO* pListItem, CItemElem* pItemElem);
	void SubtractListItem(GENMATDIEINFO* pListItem);
	void DrawListItem(C2DRender* p2DRender);
	BOOL IsDropMaterialZone(CPoint point);
	BOOL IsDropScroll1Zone(CPoint point);
	BOOL IsDropScroll2Zone(CPoint point);
	BOOL IsAcceptableMaterial(ItemProp* pItemProp);
	BOOL IsAcceptableScroll1(ItemProp* pItemProp);
	BOOL IsAcceptableScroll2(ItemProp* pItemProp);
	int GetNowSmeltValue(void);
	int GetDefaultMaxSmeltValue(void);
	void SetResultSwitch(bool bResultSwitch) { m_bResultSwitch = bResultSwitch; }
	void SetCurrentSmeltNumber(int nCurrentSmeltNumber) { m_nCurrentSmeltNumber = nCurrentSmeltNumber; }
	void SetResultStatic(bool bResultStatic, int nIndex) { m_bResultStatic[nIndex] = bResultStatic; }
	CItemElem* GetItemElement(void) const { return m_pItemElem; }
	bool GetResultSwitch(void) const { return m_bResultSwitch; }
	int GetCurrentSmeltNumber(void) const { return m_nCurrentSmeltNumber; }
	int GetResultStaticID(int nIndex) const { return m_nResultStaticID[nIndex]; }
};

class CWndSmeltSafetyConfirm : public CWndNeuz
{
public:
	enum ErrorMode { WND_ERROR1, WND_ERROR2, WND_ERROR3 };

private:
	ErrorMode m_eErrorMode;
	CItemElem* m_pItemElem;

public:
	CWndSmeltSafetyConfirm(ErrorMode eErrorMode);
	virtual ~CWndSmeltSafetyConfirm();

public:
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual	void OnInitialUpdate();
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );
	virtual void OnDestroy( void );

	void SetWndMode(CItemElem* pItemElem);
};

#endif //__SMELT_SAFETY

#if __VER >= 14 // __EQUIP_BIND
class CWndEquipBindConfirm : public CWndNeuz
{
public:
	enum EquipAction { EQUIP_DOUBLE_CLICK, EQUIP_DRAG_AND_DROP };

public:
	CWndEquipBindConfirm(EquipAction eEquipAction);
	virtual ~CWndEquipBindConfirm(void);

public:
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual	void OnInitialUpdate( void );
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );

public:
	void SetInformation(CItemBase* pItemBase, DWORD dwObjId);
	void SetInformation(CItemElem* pItemElem);

private:
	void EquipItem( void );

private:
	EquipAction m_eEquipAction;
	CItemBase* m_pItemBase;
	DWORD m_dwObjId;
	CItemElem* m_pItemElem;
};
#endif // __EQUIP_BIND

#if __VER >= 14 // __RESTATE_CONFIRM
class CWndRestateConfirm : public CWndNeuz
{
public:
	CWndRestateConfirm(DWORD dwItemID);
	virtual ~CWndRestateConfirm(void);

public:
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual	void OnInitialUpdate( void );
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );

public:
	void SetInformation(DWORD dwItemObjID, OBJID m_ObjID, int nPart = -1);

private:
	DWORD m_dwItemID;
	DWORD m_dwItemObjID;
	OBJID m_ObjID;
	int m_nPart;
};
#endif // __RESTATE_CONFIRM

#if __VER >= 15 // __CAMPUS
class CWndCampusInvitationConfirm : public CWndNeuz
{
public:
	CWndCampusInvitationConfirm( u_long idSender = 0, const CString& rstrSenderName = _T( "" ) );
	virtual ~CWndCampusInvitationConfirm( void );

public:
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual	void OnInitialUpdate( void );
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );

private:
	u_long m_idSender;
	CString m_strSenderName;
};

class CWndCampusSeveranceConfirm : public CWndNeuz
{
public:
	CWndCampusSeveranceConfirm( u_long idTarget = 0, const CString& rstrTargetName = _T( "" ) );
	virtual ~CWndCampusSeveranceConfirm( void );

public:
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK );
	virtual	void OnInitialUpdate( void );
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult );

private:
	u_long m_idTarget;
	CString m_strTargetName;
};
#endif // __CAMPUS

#ifdef __APP_TELEPORTER
class CWndDropList : public CWndListBox
{
public:
	CWndDropList();
	~CWndDropList();
	const int nIconSize = 30;
	virtual void OnDraw(C2DRender* p2DRender);
};
class CWndTeleporter : public CWndNeuz
{
private:
	CRect           m_defaultSize;
	TeleportInfo    m_TeleportInfo;
	CWndDropList* m_pWndDropList;
	CWndListBox* m_pLocationList;
public:
	int m_nCursorIndex;
	CWndTeleporter();
	~CWndTeleporter();
	virtual BOOL Initialize(CWndBase* pWndParent = nullptr, DWORD dwStyle = 0);
	virtual void OnInitialUpdate();
	virtual void CWndTeleporter::OnDraw(C2DRender* p2DRender);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	void UpdateIndex(int nIndex = 0);
};
#endif //__APP_TELEPORTER

#ifdef __NEW_ITEM_VARUNA
class CWndBarunaNPC : public CWndNeuz
{
public:
	CWndBarunaNPC( );
	virtual ~CWndBarunaNPC( );
	
	virtual void OnDestroy();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL,DWORD dwWndId = 0);
	virtual BOOL Process();
	virtual void SetInfo( DWORD dwItemId );
//	virtual void PaintFrame( C2DRender* p2DRender );

	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase = NULL );
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	
	virtual HRESULT RestoreDeviceObjects();
	virtual HRESULT InvalidateDeviceObjects();
	virtual HRESULT DeleteDeviceObjects();

	CTexture m_texGauEmptyNormal ;
	CTexture m_texGauEmptySmall  ;
	CTexture m_texGauFillNormal  ;
	CTexture m_texGauFillSmall   ;
	LPDIRECT3DVERTEXBUFFER9 m_pVBEXPGauge;
	BOOL m_bVBEXPGauge;
	int m_nEXPWidth;
	
	void MakeGaugeVertex();

	DWORD m_dwItemId;
protected:
	CWndStatic* m_pLevelStatic;

	int m_nLevel;
	int m_nFailCounter;
	int m_nFailLevelTable[5];

	CModelObject* m_pPetModel; // Pet Model Object.
	float	m_fRadius;
};


class CWndBarunaExtractOffer : public CWndNeuz
{
public:
	CItemElem* m_pItemElem;
	ItemProp* m_pEItemProp;
	CTexture* m_pTexture;
public: 
	CWndBarunaExtractOffer(); 
	virtual ~CWndBarunaExtractOffer(); 

	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
};
class CWndBarunaOffer : public CWndNeuz
{
public:
	CItemElem* m_pItemElem;
	ItemProp* m_pEItemProp;
	CTexture* m_pTexture;

	CItemElem* m_pItemElem2;
	ItemProp* m_pEItemProp2;
	CTexture* m_pTexture2;
public: 
	CWndBarunaOffer(); 
	virtual ~CWndBarunaOffer(); 

	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
};
class CWndBarunaEnchant : public CWndNeuz
{
public:
	CItemElem* m_pItemElem;
	ItemProp* m_pEItemProp;
	CTexture* m_pTexture;

	CItemElem* m_pItemElem2;
	ItemProp* m_pEItemProp2;
	CTexture* m_pTexture2;

	CItemElem* m_pItemElem3;
	ItemProp* m_pEItemProp3;
	CTexture* m_pTexture3;
public: 
	CWndBarunaEnchant(); 
	virtual ~CWndBarunaEnchant(); 

	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
};
class CWndBarunaSeed : public CWndNeuz
{
public:
	CItemElem* m_pItemElem;
	ItemProp* m_pEItemProp;
	CTexture* m_pTexture;

	CItemElem* m_pItemElem2;
	ItemProp* m_pEItemProp2;
	CTexture* m_pTexture2;
public: 
	CWndBarunaSeed(); 
	virtual ~CWndBarunaSeed(); 

	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
};
class CWndBarunaOfferSeed : public CWndNeuz
{
public:
	CItemElem* m_pItemElem;
	ItemProp* m_pEItemProp;
	CTexture* m_pTexture;

	CItemElem* m_pItemElem2;
	ItemProp* m_pEItemProp2;
	CTexture* m_pTexture2;

	CItemElem* m_pItemElem3;
	ItemProp* m_pEItemProp3;
	CTexture* m_pTexture3;
public: 
	CWndBarunaOfferSeed(); 
	virtual ~CWndBarunaOfferSeed(); 

	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
};
#ifdef __BARUNA_PIERCING
class CWndBarunaPiercing : public CWndNeuz
{
public:
	DWORD	m_dwItemId[4];
	CTexture* m_pTexture[4];
	CItemElem* m_pItemElem[4];
	LPWNDCTRL m_wndCtrl[4];
	
public: 
	CWndBarunaPiercing(); 
	virtual ~CWndBarunaPiercing(); 

	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
};
#endif // __BARUNA_PIERCING
#endif // __NEW_ITEM_VARUNA
#ifdef __LOOKCHANGE
class CWndLookChange : public CWndNeuz
{
private:
	CItemElem *m_pItemSource;
	CItemElem *m_pItemDest;
	CRect *m_pRectDest;
	CRect *m_pRectSource;
	CRect *m_pRectResult;
	CWndButton *m_pStart;
	
public:
	CWndLookChange();
	virtual void OnDestroy();
	virtual void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase *pWndParent = NULL, DWORD dwStyle = 0);
	virtual BOOL OnDropIcon(LPSHORTCUT pShortcut, CPoint point = 0);
	virtual void OnMouseWndSurface(CPoint point);
	virtual void OnDraw(C2DRender *p2DRender);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT *pLResult);
	virtual void OnRButtonUp(UINT nFlags, CPoint point);
	BOOL SetItem(CItemElem *pItem);

private:
	int IsValidItem(CItemElem *pItem);
};
#endif

#ifdef __CHANGE_HOT_KEY
#define CH_KEY_UP		(DWORD)0xffffff00
#define CH_KEY_DOWN		(DWORD)0xffffff01
#define CH_KEY_LEFT		(DWORD)0xffffff02
#define CH_KEY_RIGHT	(DWORD)0xffffff03
#define CH_KEY_TRACE	(DWORD)0xffffff04
#define CH_KEY_WALK		(DWORD)0xffffff05

class CWndChangeHotkeyList : public CWndListBox
{
private:
	map<DWORD, char*> m_mapApplet;

public:
	CWndChangeHotkeyList();
	virtual ~CWndChangeHotkeyList();

	virtual void OnInitialUpdate();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);

	void Apply();
	void Init();
	void Clear();
	void OnKeyInput(int nVirtKey);
};

class CWndChangeHotkey : public CWndNeuz
{
private:
	CWndChangeHotkeyList m_wndHKList;
public:
	virtual void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD dwStyle = 0);

	void Save();
	void Reset();
	void OnKeyInput(int nVirtKey);
};
#endif // __CHANGE_HOT_KEY

#ifdef __INVENTORY_SORTING
struct sItem
{
	DWORD dwId;
	DWORD dwKind2;
	DWORD dwItemId;
	BYTE nIndex;
	sItem()
	{
		dwId = dwKind2 = dwItemId = nIndex = 0;
	}
	bool operator < (const sItem p2)
	{
		if (dwKind2 == p2.dwKind2)
		{
			return dwItemId < p2.dwItemId;
		}
		else
		{
			return dwKind2 < p2.dwKind2;
		}
	}
};

class CInventorySort0
{
public:
	CInventorySort0()
	{
		m_dwPos = 0;
	}
	~CInventorySort0() {}
private:
	sItem m_Item[42];
	DWORD m_dwPos;
public:
	void Add(BYTE nIndex)
	{
		if (m_dwPos >= 42)
		{
			return;
		}
		m_Item[m_dwPos].nIndex = nIndex;
		m_Item[m_dwPos].dwId = m_dwPos;
		m_dwPos++;
	}

	BYTE GetItemSrc(DWORD dwId)
	{
		for (int i = 0; i < 42; i++)
		{
			if (m_Item[i].dwId == dwId)
			{
				return m_Item[i].nIndex;
			}
		}
		return 255;
	}

	void MoveItem(DWORD dwSrcId, BYTE dest)
	{
		BYTE nTmp = 0;
		bool bDest = false, bSrc = false;
		for (int i = 0; i < 42; i++)
		{
			if (dwSrcId == m_Item[i].dwId)
			{
				nTmp = m_Item[i].nIndex;
				m_Item[i].nIndex = dest;
			}
		}
		for (int i = 0; i < 42; i++)
		{
			if (dest == m_Item[i].nIndex)
			{
				m_Item[i].nIndex = nTmp;
			}
		}
	}
};

class CInventorySort1
{
public:
	CInventorySort1()
	{
		m_dwPos = 42;
	}
	~CInventorySort1() {}
private:
	sItem m_Item[84];
	DWORD m_dwPos;
public:
	void Add(BYTE nIndex)
	{
		if (m_dwPos >= 84)
		{
			return;
		}
		m_Item[m_dwPos].nIndex = nIndex;
		m_Item[m_dwPos].dwId = m_dwPos;
		m_dwPos++;
	}

	BYTE GetItemSrc(DWORD dwId)
	{
		for (int i = 42; i < 84; i++)
		{
			if (m_Item[i].dwId == dwId)
			{
				return m_Item[i].nIndex;
			}
		}
		return 255;
	}

	void MoveItem(DWORD dwSrcId, BYTE dest)
	{
		BYTE nTmp = 42;
		bool bDest = false, bSrc = false;
		for (int i = 42; i < 84; i++)
		{
			if (dwSrcId == m_Item[i].dwId)
			{
				nTmp = m_Item[i].nIndex;
				m_Item[i].nIndex = dest;
			}
		}
		for (int i = 42; i < 84; i++)
		{
			if (dest == m_Item[i].nIndex)
			{
				m_Item[i].nIndex = nTmp;
			}
		}
	}
};

class CInventorySort2
{
public:
	CInventorySort2()
	{
		m_dwPos = 84;
	}
	~CInventorySort2() {}
private:
	sItem m_Item[126];
	DWORD m_dwPos;
public:
	void Add(BYTE nIndex)
	{
		if (m_dwPos >= 126)
		{
			return;
		}
		m_Item[m_dwPos].nIndex = nIndex;
		m_Item[m_dwPos].dwId = m_dwPos;
		m_dwPos++;
	}

	BYTE GetItemSrc(DWORD dwId)
	{
		for (int i = 84; i < 126; i++)
		{
			if (m_Item[i].dwId == dwId)
			{
				return m_Item[i].nIndex;
			}
		}
		return 255;
	}

	void MoveItem(DWORD dwSrcId, BYTE dest)
	{
		BYTE nTmp = 84;
		bool bDest = false, bSrc = false;
		for (int i = 84; i < 126; i++)
		{
			if (dwSrcId == m_Item[i].dwId)
			{
				nTmp = m_Item[i].nIndex;
				m_Item[i].nIndex = dest;
			}
		}
		for (int i = 84; i < 126; i++)
		{
			if (dest == m_Item[i].nIndex)
			{
				m_Item[i].nIndex = nTmp;
			}
		}
	}
};

class CInventorySort3
{
public:
	CInventorySort3()
	{
		m_dwPos = 126;
	}
	~CInventorySort3() {}
private:
	sItem m_Item[168];
	DWORD m_dwPos;
public:
	void Add(BYTE nIndex)
	{
		if (m_dwPos >= 168)
		{
			return;
		}
		m_Item[m_dwPos].nIndex = nIndex;
		m_Item[m_dwPos].dwId = m_dwPos;
		m_dwPos++;
	}

	BYTE GetItemSrc(DWORD dwId)
	{
		for (int i = 126; i < 168; i++)
		{
			if (m_Item[i].dwId == dwId)
			{
				return m_Item[i].nIndex;
			}
		}
		return 255;
	}

	void MoveItem(DWORD dwSrcId, BYTE dest)
	{
		BYTE nTmp = 126;
		bool bDest = false, bSrc = false;
		for (int i = 126; i < 168; i++)
		{
			if (dwSrcId == m_Item[i].dwId)
			{
				nTmp = m_Item[i].nIndex;
				m_Item[i].nIndex = dest;
			}
		}
		for (int i = 126; i < 168; i++)
		{
			if (dest == m_Item[i].nIndex)
			{
				m_Item[i].nIndex = nTmp;
			}
		}
	}
};
#endif // __INVENTORY_SORTING
#ifdef __FASHION_COMBINE
class CWndFashionCombine : public CWndNeuz
{
public:
	CItemElem* m_pItemElem[12];
	CTexture*  m_pTexture[12];

public: 
	CWndFashionCombine(); 
	virtual ~CWndFashionCombine(); 

	virtual void OnDraw( C2DRender* p2DRender ); 
	virtual	void OnInitialUpdate(); 
	virtual BOOL Initialize( CWndBase* pWndParent = NULL, DWORD nType = MB_OK ); 
	virtual BOOL OnChildNotify( UINT message, UINT nID, LRESULT* pLResult ); 
	virtual BOOL OnCommand( UINT nID, DWORD dwMessage, CWndBase* pWndBase ); 
	virtual void OnSize( UINT nType, int cx, int cy ); 
	virtual BOOL OnDropIcon( LPSHORTCUT pShortcut, CPoint point );
};
#endif // __FASHION_COMBINE
#ifdef __DROP_LOG
#define REMOVE_TIMEOUT	15000
#define GOLD_FADEOUT	15000
#define GOLD_RESET		2000

typedef struct 			s_dropLog
{
	DWORD 				dwNameColor;
	DWORD 				dwRemoveTime;
	DWORD 				dwAlpha;
	CTexture* pTexture;
	char 				szName[256];
	struct s_dropLog* next;
	struct s_dropLog* prev;
}						t_dropLogNew, * t_dropLog;

class CWndDropLog
{
private:
	DWORD			m_dwNextProcessAdd;
	DWORD			m_dwLastAddGold;
	unsigned int 	m_qwTotalReapGold;
	char 			m_szTotalReapGold[128];
	CTexture* m_pGoldTexture;
	t_dropLog 		m_pHead;
	t_dropLog 		m_pTail;
	t_dropLog		m_pFreeList;
	t_dropLog 		m_pAddList;
	int 			m_nSizeofAddList;

public:
	CWndDropLog();
	~CWndDropLog();
	static 			CWndDropLog* GetInstance()
	{
		static 		CWndDropLog wnd;
		return 		&wnd;
	}
	void			InitDeviceObjects();
	void			DeleteDeviceObjects();
	void			Process();
	void			Render(C2DRender* p2DRender, const int& nWindowHeight);
	void			Add(const ItemProp* pProp);
	void			AddGold(unsigned int nGold);
	void			Clear();
};
#endif //__DROP_LOG
#ifdef __ITEMLINK
class CWndLinkedItem : public CWndNeuz
{
protected:
	CItemElem* m_pItemElem;
	CEditString m_strItem;
	CRect m_rectRender;
	CStatic stat;
	CTexture* m_pTex;
public:
	CWndLinkedItem();
	virtual ~CWndLinkedItem();
	void			InsertItem(CItemElem* pItemElem);
	virtual BOOL	Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL	OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void	OnDraw(C2DRender* p2DRender);
	virtual	void	OnInitialUpdate();
	void MakeToolTipText(CEditString &str);
	virtual void	OnSize(UINT nType, int cx, int cy);
};
#endif
#ifdef __COLLECT_EXTRA
class CWndCollectingItems : public CWndNeuz
{
private:
	CWndListBox* m_pListbox;
public:
	CWndCollectingItems(void);
	~CWndCollectingItems(void);

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual void OnInitialUpdate();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);

};
#endif
#ifdef __TREASUREBOX
class CWndTreasureBox : public CWndNeuz
{
public:
	float m_nSmeltWidth;
	LPDIRECT3DVERTEXBUFFER9 m_pVBSmeltGauge;
	CTexture m_texGauEmptyNormal;
	BOOL m_bVBSmeltGauge;
	BOOL m_bStart;
	DWORD m_dwStartTime;
	DWORD m_dwEndTime;
	int m_nDelay;
	float m_fGaugeRate;
	CWndTreasureBox(DWORD dwObjID);
	virtual ~CWndTreasureBox();
	CItemElem* m_pItemElem;
	CItemElem* m_pBoxItem;
	CTexture* m_pTexture;
	CRect m_nCtrlId;
	CRect m_nBoxRect;
	virtual BOOL    OnDropIcon(LPSHORTCUT pShortcut, CPoint point);
	virtual BOOL	Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL	OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void	OnDraw(C2DRender* p2DRender);
	virtual	void	OnInitialUpdate();
	virtual void	OnLButtonDblClk(UINT nFlags, CPoint point);
	virtual	void	OnDestroy(void);
	virtual BOOL	Process();
	HRESULT RestoreDeviceObjects();
	HRESULT InvalidateDeviceObjects();
	HRESULT DeleteDeviceObjects();
	BOOL IsOpenKey(CItemElem* pKey);
};

class CWndTreasureRecieve : public CWndNeuz
{
public:
	DWORD m_dwTreasures[3];
	int	m_nCount[3];
	CRect m_nCtrlId[3];
	CTexture* pTexture[3];
	CWndTreasureRecieve();
	virtual ~CWndTreasureRecieve();
	void InsertItem(DWORD dwID, int idx, int nCount);
	virtual BOOL	Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL	OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void	OnDraw(C2DRender* p2DRender);
	virtual	void	OnInitialUpdate();
};
#endif

#ifdef __USER_OWN_TITLE
class CWndCreateOwnTitle : public CWndNeuz
{
public:
	CWndCreateOwnTitle();
	virtual ~CWndCreateOwnTitle();
	virtual	void OnInitialUpdate();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual void OnSize(UINT nType, int cx, int cy);

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
};
#endif // __USER_OWN_TITLE

#ifdef __RECYCLE
class CWndRecycleParure : public CWndNeuz
{
private:
	CTexture* pCustom;
	CItemElem* pItem1;
	CTexture* pItem1Tex;

public:
	CWndRecycleParure();
	virtual ~CWndRecycleParure();

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual BOOL OnDropIcon(LPSHORTCUT pShortcut, CPoint point = 0);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual void OnMouseWndSurface(CPoint point);
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);
};
class CWndRecycleFamillier : public CWndNeuz
{
private:
	CTexture* pCustom;
	CItemElem* pItem1;
	CTexture* pItem1Tex;

public:
	CWndRecycleFamillier();
	virtual ~CWndRecycleFamillier();

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual BOOL OnDropIcon(LPSHORTCUT pShortcut, CPoint point = 0);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual void OnMouseWndSurface(CPoint point);
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);
};
class CWndRecycleCape : public CWndNeuz
{
private:
	CTexture* pCustom;
	CItemElem* pItem1;
	CTexture* pItem1Tex;

public:
	CWndRecycleCape();
	virtual ~CWndRecycleCape();

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual BOOL OnDropIcon(LPSHORTCUT pShortcut, CPoint point = 0);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual void OnMouseWndSurface(CPoint point);
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);
};
#endif // __RECYCLE
#ifdef __DEATH_MATCH
class CWndJoinPlayerSiege : public CWndNeuz
{
public:
	CWndJoinPlayerSiege();
	virtual ~CWndJoinPlayerSiege();

	virtual	void OnInitialUpdate();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual void OnSize(UINT nType, int cx, int cy);

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
};
#endif // __DEATH_MATCH
#ifdef __RANDOMOPTION_RETRY
class CWndRandomOptionRetry : public CWndNeuz
{
private:
	CItemElem* m_pItemElem;
	CItemElem* m_pMaterialItem;
	CRect m_Rect;

public:
	CWndRandomOptionRetry();
	~CWndRandomOptionRetry();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual BOOL OnDropIcon(LPSHORTCUT pShortcut, CPoint point);
	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual	void OnInitialUpdate();
	virtual void OnRButtonUp(UINT nFlags, CPoint point);
	virtual void SetItemId(CItemElem* pItemElem);
};
#endif

#ifdef __PET_FILTER
class CWndPetfilter : public CWndNeuz
{
public:
	CWndPetfilter();
	~CWndPetfilter();

	DWORD dwPetfilter;
	virtual void SetButtonStatus();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
};
#endif // __PET_FILTER

#ifdef __PARTY_FIND
class CWndPartyFind : public CWndNeuz
{
private:
	int						m_nSelected;
	CWndListBox* pWndListBox;
	CWndText* pWndText;

public:
	CWndPartyFind();
	~CWndPartyFind();

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	vector<PARTYFINDER_LIST>	GetPartyList() const;
	void RefreshItemList();
	vector<PARTYFINDER_LIST>	m_mapItem;
};
#endif //__PARTY_FIND

#ifdef __NEW_CHANGE_JOB
class CWndNewChangeJob : public CWndNeuz
{
private:
	CWndButton* m_pWndButton1;
	CWndButton* m_pWndButton2;
	CWndButton* m_pWndButton3;
	CWndButton* m_pWndButton4;
	CWndButton* m_pWndButtonOK;
	CWndStatic* m_pWndStatic1;
	CWndStatic* m_pWndStatic2;
	CWndStatic* m_pWndStatic3;
	CWndStatic* m_pWndStatic4;
	CWndStatic* m_pWndStatic5;
	CWndText* m_pWndText1;
	CWndText* m_pWndText2;
	CWndText* m_pWndText3;
	CWndText* m_pWndText4;
	int m_nJob;

public:
	CWndNewChangeJob();
	virtual ~CWndNewChangeJob();

	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
};

class CWndNewChangeJob2 : public CWndNeuz
{
private:
	CWndButton* m_pWndButton1;
	CWndButton* m_pWndButton2;
	CWndButton* m_pWndButtonOK;
	CWndStatic* m_pWndStatic1;
	CWndStatic* m_pWndStatic2;
	CWndStatic* m_pWndStatic3;
	CWndText* m_pWndText1;
	CWndText* m_pWndText2;
	int m_nJob;

public:
	CWndNewChangeJob2();
	virtual ~CWndNewChangeJob2();

	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual int GetNewJob(int nButton);
};

class CWndNewChangeJob3 : public CWndNeuz
{

private:
	CWndButton* m_pWndButton1;
	CWndButton* m_pWndButtonOK;
	CWndStatic* m_pWndStatic1;
	CWndStatic* m_pWndStatic2;
	CWndText* m_pWndText1;
	int m_nJob;

public:
	CWndNewChangeJob3();
	virtual ~CWndNewChangeJob3();

	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual int GetNewJob();
};
#endif // __NEW_CHANGE_JOB

#ifdef __WIKIPEDIA_JOB
class CWndWikipediaJobCreate;
class CWndWikipediaJob : public CWndNeuz
{
private:
	int	m_nJob;
	CWndWikipediaJobCreate* m_pCreate;
public:
	CWndWikipediaJob(void);
	~CWndWikipediaJob(void);

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual void OnInitialUpdate();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	void OnMouseWndSurface(CPoint point);
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);
	virtual void OnRButtonDblClk(UINT nFlags, CPoint point);
	virtual void Refresh();
	virtual void SetJob(int nJob);
};
class CWndWikipediaJobCreate : public CWndNeuz
{
private:
	int	m_nJob;
	int m_nMaxLevel;
	int m_nRank;
public:
	CWndWikipediaJobCreate(void);
	~CWndWikipediaJobCreate(void);

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD dwStyle = 0);
	virtual void OnInitialUpdate();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void SetJob(int nJob);
};
#endif // __WIKIPEDIA_JOB

#ifdef __MODS_MANAGER
class CWndModsManager : public CWndNeuz
{
private:
	CWndButton* pButton[7];

public:
	CWndModsManager();
	virtual ~CWndModsManager();

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
};
#endif // __MODS_MANAGER

#ifdef __WEAPON_RARITY
class CWndWeaponRarity : public CWndNeuz
{
private:
	CTexture* pCustom;

	CItemElem* pItem1;
	CItemElem* pItem2;
	CItemElem* pItem3;

	CTexture* pItem1Tex;
	CTexture* pItem2Tex;
	CTexture* pItem3Tex;

public:
	CWndWeaponRarity();
	virtual ~CWndWeaponRarity();

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual BOOL OnDropIcon(LPSHORTCUT pShortcut, CPoint point = 0);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnMouseWndSurface(CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);
};
#endif // __WEAPON_RARITY
#ifdef __WIKIPEDIA_MONSTER
class CWndWikipediaMonsterCreate;
class CWndWikipediaMonster : public CWndNeuz
{
private:
	vector<MoverProp*>	m_vecMover;
	CWndWikipediaMonsterCreate* m_pCreate;
	CWndListBox* m_pListbox;
	CWndEdit* m_pEdit;
public:
	CWndWikipediaMonster(void);
	~CWndWikipediaMonster(void);

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual void OnInitialUpdate();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);

	void UpdateList();
	vector<MoverProp*>* GetMoverList() { return &m_vecMover; }
};

class CWndWikipediaMonsterCreate : public CWndNeuz
{
private:
	MoverProp* m_pMoverPropCreate;
	CWndEdit* m_pEdit;
	CWndButton* m_pButtOk;
	CWndButton* m_pCheck1;
	CWndButton* m_pCheck2;
	CWndStatic* m_pStatic;
public:
	CWndWikipediaMonsterCreate();
	~CWndWikipediaMonsterCreate(void);
	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD dwStyle = 0);
	virtual void OnInitialUpdate();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	void SetItem(MoverProp* pMoverProp);
};
#endif // __WIKIPEDIA_MONSTER
#ifdef __UPGRADE
class CWndUpgrade : public CWndNeuz
{
private:
	CTexture* pCustom;
	CItemElem* pItem1;
	CTexture* pItem1Tex;

	CWndComboBox* m_pWndComboBox;
	CWndEdit* m_pWndEdit[3];
	CWndButton* m_pWndButton[7];

public:
	CWndUpgrade();
	virtual ~CWndUpgrade();

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual BOOL OnDropIcon(LPSHORTCUT pShortcut, CPoint point = 0);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnMouseWndSurface(CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);
};
#endif // __UPGRADE

#ifdef __PLAYER_LIST
class CWndPlayerList : public CWndNeuz
{

private:
	CWndButton* pWndCheck[18];
	CWndEdit* pWndEdit[3];
	CWndListBox* pListBox;
	vector<PlayerList>	m_vecPlayerList;
	CWndMenu			m_wndMenu;

public:
	CWndPlayerList();
	~CWndPlayerList();

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual	void OnRButtonUp(UINT nFlags, CPoint point);
	virtual void OnRButtonDown(UINT nFlags, CPoint point);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnGetPlayerList(CAr& ar);
};
#endif // __PLAYER_LIST

#ifdef __AWAKE_WINDOW
class CWndAwakeWindow : public CWndNeuz
{
private:
	CTexture* pCustom;
	CItemElem* pItem1;
	CTexture* pItem1Tex;

	// loading
	float m_nSmeltWidth;
	LPDIRECT3DVERTEXBUFFER9 m_pVBSmeltGauge;
	CTexture m_texGauEmptyNormal;
	BOOL m_bVBSmeltGauge;
	BOOL m_bStart;
	DWORD m_dwStartTime;
	DWORD m_dwEndTime;

	int m_nDelay;
	float m_fGaugeRate;

public:
	CWndAwakeWindow();
	virtual ~CWndAwakeWindow();

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual BOOL OnDropIcon(LPSHORTCUT pShortcut, CPoint point = 0);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnMouseWndSurface(CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);
	virtual BOOL	Process();

	// loading
	HRESULT RestoreDeviceObjects();
	HRESULT InvalidateDeviceObjects();
	HRESULT DeleteDeviceObjects();
};
#endif // __AWAKE_WINDOW

#ifdef	__REMOVE_CMM
class CWndRemoveCmm : public CWndNeuz
{
public:
	CWndRemoveCmm(DWORD dwItemID);
	~CWndRemoveCmm();

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD dwStyle = 0);
	virtual void OnInitialUpdate();
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
private:
	DWORD m_dwItemID;
};
#endif	//__REMOVE_CMM

#ifdef __FARM_BOT
class CWndRefresher : public CWndNeuz
{
public:
	CItemElem* m_pItemElem[4];
	CTexture* m_pTexture[4];
	DWORD m_dwitemid[4];
	int n_MoverSelectCount;
	DWORD m_CoolTime;
	CSfx* dSfx;
	DWORD m_dwsfxtime;
	BOOL bStart;
	BOOL bStartmp;
	BOOL bStartfp;
	CRect    m_rect[60];
	vector<int> Skill;
	vector<int> BuffItem;
	CWndRefresher(void);
	~CWndRefresher(void);


	virtual HRESULT RestoreDeviceObjects();
	virtual HRESULT InvalidateDeviceObjects();
	virtual HRESULT DeleteDeviceObjects();


public:
	CRect      m_Rect[4];
	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void OnDraw(C2DRender* p2DRender);
	virtual void OnInitialUpdate();
	virtual BOOL Process();
	virtual BOOL OnCommand(UINT nID, DWORD dwMessage, CWndBase* pWndBase);
	virtual BOOL    OnDropIcon(LPSHORTCUT pShortcut, CPoint point);
	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	BOOL IsBuffItem(DWORD itemId);

};
#endif
#ifdef __WHEEL_OF_FORTUNE
class CWndWof : public CWndNeuz
{
	const CPoint CENTER = CPoint(270, 300);
	const int RADIUS = 240;
	const int RADIUS_ITEMS = RADIUS - 28;

	int m_nWndState;

	double m_arrowAngle;
	double m_arrowDistance;
	double m_initialArrowDistance;

	int m_nLampStateNoneRenderMode; // 0 - m_nCurrentYellowLamp, 1 - even, 2 - odd
	DWORD m_dwTimerChangeLampMode;
	int m_nTotalLampModeChanges;
	bool m_bLampGoToNext;
	int m_nCurrentYellowLamp;
	DWORD m_dwTimerChangeLamp;

	bool m_bWinItemFlash;
	DWORD m_dwTimerChangeWinItemFlash;
	int m_nTotalItemFlashChanges;

	CWndButton* m_pWndBtnInit;
	CWndButton* m_pWndBtnClose;

	CTexture* m_pTexFLGray;
	CTexture* m_pTexFLYellow;
	CTexture* m_pTexArrow;
	CTexture* m_pTexItemBg;

	vector<WOF_ITEM> m_vecSortedItem;
	CWndListBox* m_pWndListChances;

public:
	CWndWof();
	virtual ~CWndWof();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual	BOOL Process();

	enum { STATE_NONE, STATE_WAIT_INIT, STATE_INIT, STATE_WAIT_FINISH, STATE_FINISH };
	void SetState(int nState, int nVal = -1);

	void DrawWheel(C2DRender* p2DRender);
	void DrawTicket(C2DRender* p2DRender);
	void DrawChances(C2DRender* p2DRender);
	void DrawHistory(C2DRender* p2DRender);

	void ProcessLamp();
	void ProcessGame();
	void ProcessItemFlash();

	double GetAngle(int nZone);
	double CalculateSpeed(double initialSpeed, double remainingDistance, double totalDistance);

	void ResetLamps();
	void ResetListChances();
};
#endif
#ifdef __RECORD_BOOK
class CWndRecordBook : public CWndNeuz
{
	CWndTreeCtrl* m_pWndTreeCategories;
	CWndListBox* m_pListBoxRecords;
	CWndStatic* m_pStaticPlayerName;

	std::string m_strKeyword;
	std::unordered_map<std::string, RecordType> m_mapKeyword;

	CMover m_Mover;
	FLOAT	m_fRot;
	bool	m_bLButtonDownRot;
	CPoint	m_OldPos;

	CTexture* m_pTexTop[3];

public:
	CWndRecordBook();
	virtual ~CWndRecordBook();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual	BOOL Process();
	virtual	void OnInitialUpdate();
	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD nType = MB_OK);
	virtual BOOL OnChildNotify(UINT message, UINT nID, LRESULT* pLResult);
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);

	int GetCategoryByKeyword();
	void RefreshListBox();
	void DrawListBox(C2DRender* p2DRender);
	bool IsTimeValue(int nRecordType);
	void RefreshSelectedCharacter();
};
#endif

#endif // !defined(AFX_WNDFIELD_H__A93F3186_63D6_43C1_956F_EC8691E0C7D9__INCLUDED_)
```
