# Mover.cpp

Chemin original: `C:\Users\rdiff\Desktop\__NEWCLASS\_AIInterface\Mover.cpp`
Chemin relatif: `_AIInterface\Mover.cpp`
Nom du fichier: `Mover.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "stdafx.h"
#include "..\_AIInterface\ActionMover.h"
#include "Mover.h"
#include "ModelObject.h"
#include "defineText.h"
#include "defineItem.h"
#include "defineObj.h"
#include "defineSound.h"
#include "defineSkill.h"
#include "lang.h"
#include "ModelObject.h"  
#include "authorization.h"
#include "CreateObj.h"
#include "eveschool.h"
#ifdef __JOPS_GLOW
#ifdef __CLIENT
#include "WndManager.h"
#include "WndField.h"
#include "WndBase.h"
#endif
#endif
#ifdef	__COLOSSEUM
#include "Colosseum.h"
#endif // __COLOSSEUM

extern	CGuildCombat	g_GuildCombatMng;
#include "..\_aiinterface\aipet.h"

#if __VER >= 9	// __PET_0410
#include "pet.h"
#endif	// __PET_0410

#if __VER >= 12 // __LORD
#ifdef __WORLDSERVER
#include "slord.h"
#endif	// __WORLDSERVER
#endif	// __LORD

#ifdef __SYS_TICKET
#ifdef __WORLDSERVER
#include "ticket.h"
#endif	// __WORLDSERVER
#endif	// __SYS_TICKET

#if __VER >= 11 // __SYS_IDENTIFY
#include "randomoption.h"
#endif	// __SYS_IDENTIFY

#if __VER >= 11 // __SYS_PLAYER_DATA
#include "playerdata.h"
#endif	// __SYS_PLAYER_DATA

#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
	#include "honor.h"
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ

#ifdef __QUIZ
#include "Quiz.h"
#endif // __QUIZ

#ifdef __BADGE
#include "Badge.h"
#endif //__BADGE

#ifdef __CLIENT
	#include "..\_Common\ParticleMng.h"
	#include "Resdata.h"
	#include "DPClient.h"
	#include "DialogMsg.h"
	extern	CDPClient	g_DPlay;
	#include "GuildRender.h"
#else	// __CLIENT
	#include "User.h"
	#include "UserMacro.h"
	#include "WorldMng.h"
	#include "DPSrvr.h"
	#include "DPCoreClient.h"
	#include "dpdatabaseclient.h"
	#include "spevent.h"

	extern	CUserMng	g_UserMng;
	extern	CWorldMng	g_WorldMng;
	extern	CDPSrvr		g_DPSrvr;
	extern	CDPDatabaseClient	g_dpDBClient;
	extern	CDPCoreClient	g_DPCoreClient;

#endif	// __CLIENT

	#include "..\_AIInterface\AIInterface.h"

#include "party.h"
extern	CPartyMng	g_PartyMng;

#include "guild.h"
extern	CGuildMng	g_GuildMng;
#include "guildwar.h"
extern	CGuildWarMng	g_GuildWarMng;

#include "definequest.h"
#include "Ship.h"
#ifdef __WORLDSERVER
	#include "User.h"
#endif

#ifdef __EVENT_MONSTER
#include "EventMonster.h"
#endif // __EVENT_MONSTER

#if __VER >= 12 // __SECRET_ROOM
#include "SecretRoom.h"
#endif // __SECRET_ROOM

#if __VER >= 12 // __NEW_ITEMCREATEMON_SERVER
#include "CreateMonster.h"
#endif // __NEW_ITEMCREATEMON_SERVER

#ifdef __MOUNT
#include "defineNeuz.h"
#endif // __MOUNT

#if defined(__FTOOL) && defined(__CLIENT)
#include "FTool.h"
extern CFTool g_FTool;
#endif // __FTOOL

#ifdef __RECORD_BOOK
#include "RecordBook.h"
#endif

extern	BOOL CanAdd( DWORD dwGold, int nPlus );

#ifndef __VM_0820
#ifndef __MEM_TRACE
#ifdef __WORLDSERVER
	#ifdef __VM_0819
	CMoverPool*	CMover::m_pPool	= new CMoverPool( 1024, "CMover" );
	#else	// __VM_0819
	CMoverPool*	CMover::m_pPool	= new CMoverPool( 1024 );
	#endif	// __VM_0819
#else	// __WORLDSERVER
	#ifdef __VM_0819
	CMoverPool*	CMover::m_pPool	= new CMoverPool( 128, "CMover" );
	#else	// __VM_0819
	CMoverPool*	CMover::m_pPool	= new CMoverPool( 128 );
	#endif	// __VM_0819
#endif	// __WORLDSERVER
#endif	// __MEM_TRACE
#endif	// __VM_0820


const int	MAX_DIALOGFILENAME = 32;

#ifdef __CLIENT
// Äù½ºÆ® ¾ÆÀÌÄÜ È®Ãà ÇÁ·Î¼¼½º 
BOOL CMover::m_bQuestEmoticonAdd = TRUE;
FLOAT CMover::m_fQuestEmoticonScale = 1.0f;

#if __VER >= 8 //__Y_EYE_FLASH_8
LPDIRECT3DTEXTURE9 CMover::m_pTextureEye[2][MAX_HEAD] = { 0, };
LPDIRECT3DTEXTURE9 CMover::m_pTextureEyeFlash[2][MAX_HEAD] = { 0, };
#endif //__Y_EYE_FLASH_8

#endif

#if __VER >= 11 // __SYS_COLLECTING
#include "collecting.h"
#endif

#ifdef __MONSTER_CLASH
#include "MonsterClash.h"
#endif // __MONSTER_CLASH

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
#pragma warning ( disable : 4355 )

CMover::CMover()
#ifdef __BUFF_1107
:
m_buffs( this )
#endif	// __BUFF_1107
{
	Init();
}

CMover::~CMover()  
{
#ifdef __CLIENT
	SAFE_DELETE( m_pLadolf );		// g_Object3DMng°¡ ÆÄ±«µÇ±âÀü¿¡ ºÎ¸¦°Í
#if __VER >= 8 //__CSC_VER8_5
	SAFE_DELETE( m_pAngel );
#endif //__CSC_VER8_5
#ifdef __EVE_BALLOON
	SAFE_DELETE( m_pBalloon );
#endif //__EVE_BALLOON
#endif //__CLIENT

#ifdef __WORLDSERVER
	SAFE_DELETE( m_pNpcProperty );
#endif

#ifdef __WORLDSERVER
#if __VER >= 12 // __NEW_ITEMCREATEMON_SERVER
	CCreateMonster::GetInstance()->RemoveInfo( this );
#endif // __NEW_ITEMCREATEMON_SERVER
#endif // __WORLDSERVER

	CMover* pOther = m_vtInfo.GetOther();
	if( IsValidObj( pOther ) )
	{
		if( pOther->m_vtInfo.GetOther() == this )
			pOther->m_vtInfo.TradeClear();
	}

#ifdef __CLIENT
	m_vtInfo.VendorClose();
	g_DialogMsg.ClearMessage((CObj*)this);
#endif	// __CLIENT

	SAFE_DELETE( m_pActMover );

	for( int i = 0; i < MAX_VENDOR_INVENTORY_TAB; i++ )
		SAFE_DELETE( m_ShopInventory[ i ] );

	if( GetWorld() )
	{
	#if !defined(__CLIENT)
	#ifdef __LAYER_1021
		GetWorld()->m_respawner.Increment( GetRespawn(), GetRespawnType(), m_bActiveAttack, GetLayer() );
	#else	// __LAYER_1021
		GetWorld()->m_respawner.Increment( GetRespawn(), GetRespawnType(), m_bActiveAttack );
	#endif	// __LAYER_1021
	#endif
	}

	SAFE_DELETE_ARRAY( m_aQuest );
	SAFE_DELETE_ARRAY( m_aCompleteQuest );
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
	SAFE_DELETE_ARRAY( m_aCheckedQuest );
#endif // __IMPROVE_QUEST_INTERFACE

#ifdef __CLIENT
	m_pSfxWing = NULL;
#if __VER >= 15 // __PETVIS
	m_pSfxBuffPet = NULL;
#endif

#ifdef __BS_EFFECT_LUA
	CSfxModelMng::GetThis()->SubData( GetId() );
#endif //__BS_EFFECT_LUA

#endif	// __CLIENT
}

void CMover::Init()
{
#ifdef __BAG_LOOT
	m_nSelectedBag = 0;
#endif
#ifdef __LNB_ANIMATED_HATS
	SetAnimatedHat(nullptr);
#endif
#ifdef __WINGSFX
	m_dwWingSfx = NULL_ID;
#endif
	m_dwMotion		    = -1;
	m_dwMotionOption    = 0;
	m_dwType			= OT_MOVER;
	m_vMarkingPos	    = D3DXVECTOR3( 0, 0, 0 );
	m_nCount			= xRandom( 128 );		// ¸®½ºÆù µÇ´Â ¸÷¸¶´Ù ½ÃÀÛÄ«¿îÅÍ¸¦ ¾à°£¾¿ Æ²¸®°Ô ÇØ¼­ Á»´õ ´Ù¾çÇÑ ¹ÝÀÀÀÌ ³ª¿À°Ô Çß´Ù.
	m_bPlayer			= FALSE;
	m_dwTypeFlag		= 0;
	m_pRide				= NULL;  
	m_pAIInterface		= NULL;
	m_nHitPoint			= 100;
	m_nManaPoint		= 100;
	m_nFatiguePoint		= 100;
	m_vDestPos			= D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
	m_idDest			= NULL_ID;
	m_fArrivalRange		= 0.0f;
	SetSex( SEX_FEMALE );
	m_dwVirtItem		= II_WEA_HAN_HAND;
	m_dwVirtType		= VT_ITEM;
	m_nHitPoint			= 100;
	m_nManaPoint		= 100;
	m_nFatiguePoint		= 100;
	m_dwRideItemIdx		= II_RID_RID_STI_MAGIC;
	m_nRemainGP			= 0;
	m_nDefenseMin		= 0;
	m_nDefenseMax		= 0;
	m_nJob				= -1;
	memset( m_szName, 0, sizeof(TCHAR) );
	m_nAdjHitRate		= 0;
	m_nAdjParry         = 0;
	m_nStr				= 15;
	m_nSta				= 15;
	m_nDex				= 15;
	m_nInt				= 15;
	m_nLevel			= 1;
	m_nExp1				= 0;
	m_nDeathExp			= 0;
	m_nDeathLevel		= 0;
	m_dwFace			= 0;
	m_dwSkinSet			= 0;
	m_dwHairMesh		= 0;
	m_dwHairColor		= 0;
	m_dwHeadMesh		= 0;
#if __VER >= 12 // __MOD_TUTORIAL
	m_nTutorialState	= 0;
#else	// __MOD_TUTORIAL
	m_nFlightLv			= 0;
#endif	// __MOD_TUTORIAL
	m_nFxp				= 0;
#ifdef __BATTLEPASS
	m_nBPLevel = 0;
	m_nBPPoints = 0;
	m_nBPType = 0;
	m_nBPEnable = 0;
	m_szBPEndTime = 0;
#endif // __BATTLEPASS
	m_szCharacterKey[ 0 ] = 0;
	{
		int i;
		for( i = 0; i < MAX_ADJPARAMARY; i ++ )		m_adjParamAry[i] = 0;
		for( i = 0; i < MAX_ADJPARAMARY; i ++ )		m_chgParamAry[i] = 0x7FFFFFFF;	// ÀÌÀ¯°¡ ÀÖ´Ù.
	}

	ClearEquipInfo();

	m_vtInfo.Init( this );

#if __VER >= 11 // __SYS_POCKET
#ifdef __WORLDSERVER
	m_Pocket.Init( this );
#endif	// __WORLDSERVER
#endif	// __SYS_POCKET

	m_idPlayer			= NULL_ID;
#if defined(__ANI_WING) && defined(__CLIENT)
	m_pMask = NULL;
#endif
	m_dwAuthorization	= AUTH_GENERAL;
	m_idMarkingWorld	= NULL_ID;
	m_dwRegionAttr		= 0;
	m_dwOldRegionAttr	= 0;
	m_bPositiveX		= m_bPositiveZ	= false;
	m_fDestAngle		= -1.0f;
	m_bLeft				= false;
	m_bForward			= true;
	m_dwMode			= 0;
	memset( &m_CorrAction, 0, sizeof(CORR_ACTION) );
	m_fWaitQueryGetPos	= FALSE;
	m_nCorr				= 0;
	m_uRemnantCorrFrm	= 0;
	m_fHairColorR		= 1.0f;
	m_fHairColorG		= 1.0f;
	m_fHairColorB		= 1.0f;
	m_dwHairColor		= D3DCOLOR_COLORVALUE( 1.0f, 1.0f, 1.0f, 1.0f );
	m_nQuestSize		= 0;
	m_aQuest	        = NULL;
	m_aCompleteQuest    = NULL; 
	m_nCompleteQuestSize = 0; 
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
	m_aCheckedQuest		= NULL;
	m_nCheckedQuestSize = 0;
#endif // __IMPROVE_QUEST_INTERFACE
#ifdef __WORLDSERVER
	m_timerQuestLimitTime.Set( MIN( 1 ) );
	m_dwPKTargetLimit = 0;
#else // __WORLDSERVER
	m_nQuestEmoticonIndex = -1; 
	m_bShowQuestEmoticon = TRUE;
#endif // __WORLDSERVER
	m_idparty			= 0;

	m_oaCmd				= m_oaAct = OBJACT_NONE;
	memset( m_nCParam, 0, sizeof(m_nCParam) );
	memset( m_nAParam, 0, sizeof(m_nAParam) );
	m_dwFlag			= 0;
	m_nAtkCnt			= 0;
	m_wStunCnt			= 0;
#ifndef __BUFF_1107
	m_SkillState.Init();
	m_SkillState.SetMover( this );
#endif	// __BUFF_1107
	m_idAttacker		= NULL_ID;
	m_idTargeter		= NULL_ID;
	m_idTracking		= NULL_ID;
	m_fExpRatio			= 1.0f;
	m_idMurderer		= NULL_ID;
	m_tmActionPoint		= timeGetTime();
	m_nDead				= 0;
#if __VER >= 8 // __S8_PK
	m_dwPKTime			= 0;
	m_nPKValue			= 0;
	m_dwPKPropensity	= 0;
	m_dwPKExp			= 0;
#else // __VER >= 8 // __S8_PK
	m_nNumKill			= 0;				// Å³¼ö
	m_nSlaughter		= 0;				// ½½·ÎÅÍ Æ÷ÀÎÆ®
	m_dwKarmaTick		= 0;
#endif // __VER >= 8 // __S8_PK
	m_wDarkCover        = 0;

	m_idLastHitMover	= NULL_ID;			// this°¡ ¸¶Áö¸·À¸·Î ÃÆ´ø ¹«¹ö¾ÆÀÌµð
	m_nFame				= 0;				// ¸í¼º
	m_nDuel				= 0;				// µà¾óÁßÀÎ°¡.
	m_idDuelOther		= NULL_ID;
	m_idDuelParty		= 0;
	m_nFuel				= -1;				// ÃÊ±â°ªÀº -1ÀÌ´Ù.
	m_tmAccFuel			= 0;				// 0ÀÌ¸é °¡¼Ó ¸øÇÏ´Â »óÅÂ.
	m_fAniSpeed			= 1.0f;
	m_idPoisonAttacker	= NULL_ID;
	m_wPoisonCnt		= 0;
	m_tmPoisonUnit		= 0;
	m_wPoisonDamage		= 0;
	m_wDarkCnt			= 0;
	m_wDarkVal			= 0;
	m_idBleedingAttacker	= NULL_ID;
	m_wBleedingCnt		= 0;
	m_tmBleedingUnit	= 0;
	m_wBleedingDamage	= 0;
	m_nMovePattern		= 0;
	m_nMoveEvent		= 0;
	m_nMoveEventCnt		= 0;


	m_idGuild			= 0;
	m_idGuildCloak		= 0;
	m_bGuildBank		= FALSE;
	m_idWar				= 0;

	m_nPlusMaxHitPoint = 0;
	memset( m_dwSMTime, 0, sizeof( DWORD ) * SM_MAX );
	m_nAttackResistLeft = (BYTE)0xff;
	m_nAttackResistRight = (BYTE)0xff;
	m_nDefenseResist = (BYTE)0xff;

#ifdef __WORLDSERVER
	m_bLastPK		= FALSE;
	m_bLastDuelParty = FALSE;
	m_bGuildCombat = FALSE;
	m_tGuildMember	= CTime::GetCurrentTime();

	m_nQuestKeeping	= 0;			// ±æµåÄù½ºÆ® Å¬¶ô¿öÅ© Äù½ºÆ®¿Í °ü·Ã 
	m_nPartyQuestKeeping	= 0;
	
//	m_idCollecter	= NULL_ID;
//	m_nResource		= 0;
//	m_nCollectOwnCnt = 0;
#endif // __WORLDSERVER

#ifdef __CLIENT
	m_nDmgCnt			= 0;
	m_nWaterCircleCount = 0;
	m_idSfxHit		= 0;
	m_dwReqFlag		= 0;
	m_pCloakTexture = NULL;
	m_fDestScale	= 1.0f;
	m_fDestScaleSlerp = 0;
#else // CLIENT
	m_nReflexDmg = 0;
#endif	// not Client

	m_pActMover = new CActionMover( this );
	m_pActMover->SetMover( this );

	m_dwTickRecovery = ::timeGetTime() + NEXT_TICK_RECOVERY;
	m_dwTickRecoveryStand = ::timeGetTime() + NEXT_TICK_RECOVERYSTAND;
	m_dwTickDuel = ::timeGetTime() + NEXT_TICK_DUEL;
	m_dwTickEndDuel = ::timeGetTime() + NEXT_TICK_ENDDUEL;
	m_nDuelState = 0;
#ifdef __ATTACK_TRACKING	
	m_dwLastPlayerAttacked = 0;
	m_dwAttackCount = 0;
	m_dbLastAttackTime = 0;
#endif //__ATTACK_TRACKING	
#ifdef __ATTACKER_TRACKING
	m_dbLastAttackReceived = 0;
	m_dbLastMessageSent = 0;
	m_vRecentAttackers.clear();
#endif //
	memset( &m_Resurrection_Data, 0, sizeof(m_Resurrection_Data) );

	m_bRegenItem		= TRUE;
	m_bActiveAttack		= FALSE;
	m_dwGold			= 0;		// 0À¸·Î ÇÒ°Í.  -xuzhu-

	for( int i = 0; i < MAX_VENDOR_INVENTORY_TAB; i++ )
		m_ShopInventory[ i ] = 0;
	
#if __VER >= 8     // 8Â÷ µà¾óÁ¸¿¡ °ü°è¾øÀÌ PVP°¡´ÉÇÏ°ÔÇÔ   Neuz, World
	m_bPVPEnd	=	FALSE;
#endif	// __VER >= 8  

#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	m_nLegend	=	LEGEND_CLASS_NORMAL;
#endif	//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#if __VER >= 11 // __MA_VER11_06				// È®À²½ºÅ³ È¿°ú¼öÁ¤ world,neuz
	memset( dwRemoveSfxObj, 0, sizeof( DWORD ) * MAX_SKILLBUFF_COUNT );
#endif // __MA_VER11_06				// È®À²½ºÅ³ È¿°ú¼öÁ¤ world,neuz

#ifdef	__CLIENT
	m_dwLadolfFlag = 0;
	m_pLadolf = NULL;
#if __VER >= 8 //__CSC_VER8_5
	m_pAngel = NULL;
	m_pAngelFlag = FALSE;
	m_dwAngelKind = 0;
#endif //__CSC_VER8_5

#ifdef __EVE_BALLOON
	m_pBalloonFlag = FALSE;
	m_pBalloon = NULL;
	m_dwBalloonKind = 0;
	m_fBalloonYPos = 1.0f;
	m_bBalloon = TRUE;
#endif	//__EVE_BALLOON

#if __VER >= 14 // __WING_ITEM
	m_eWingStateFlag = FLOATING;
	m_fOldLengthSq = 0.0f;
#endif // __WING_ITEM

#endif //__CLIENT
	m_fCrrSpd	= 0.0f;
	m_dwStateMode = 0;
	m_nReadyTime = 0;
	m_dwUseItemId = 0;
	m_bItemFind = TRUE;
	m_dwTickCheer= 0;
	m_nCheerPoint	= 0;
	m_pIADestPos = NULL;
	SetEatPetId( NULL_ID );

	ZeroMemory( m_tmReUseDelay, sizeof( m_tmReUseDelay ) );

#ifdef __WORLDSERVER
	m_pNpcProperty = NULL;
	m_dwTickCreated	= 0;
#endif
	
	m_nGuildCombatState = 0;
	m_dwCtrlReadyTime   = 0xffffffff;
	m_dwCtrlReadyId     = NULL_ID;

	m_nSkillLevel = 0;
	m_nSkillPoint = 0;

	m_dwMotionArrive = OBJMSG_STAND;

	m_SkillTimerStop = FALSE;
#if __VER >= 8 //__CSC_VER8_5
	m_nAngelExp = 0;				/// ¿£Á© °æÇèÄ¡
	m_nAngelLevel = 0;				/// ¿£Á© Level
#endif // __CSC_VER8_5
	
#if __VER >= 8 //__Y_EYE_FLASH_8
#ifdef __CLIENT
	m_tmEye[0].Set( SEC(6) );
	m_tmEye[1].Set( 200 );
#endif //__CLIENT
#endif //__Y_EYE_FLASH_8
	
#ifdef __CLIENT
	m_SkillTimer.Set(1000); //Function Key´©¸£°í ÀÖÀ» °æ¿ì Skill Delay°ª.
#endif //__CLIENT

#if __VER >= 9	// __PET_0410
	m_dwPetId	= NULL_ID;
	m_nHealCnt	= 0;
#endif	// __PET_0410
#if __VER >= 9	//__AI_0509
	m_fSpeedFactor	= 1.0F;
#endif	// __AI_0509
	
#ifdef __CLIENT
	m_pSfxWing = NULL;
	m_dwWingTime = -1;

#if __VER >= 15 // __PETVIS
	m_pSfxBuffPet = NULL;
#endif  //__PETVIS
#endif //__CLIENT

#ifdef __JEFF_9_20
	m_dwMute	= 0;
#endif	// __JEFF_9_20

#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
	m_nHonor = -1;					// ´ÞÀÎ¼±ÅÃ 
	m_dwHonorCheckTime = 0;			//´ÞÀÎ ½Ã°£Ã¼Å©
	memset( m_aHonorTitle, 0, sizeof( int ) * MAX_HONOR_TITLE );// ´ÞÀÎ¼öÄ¡
	m_strTitle.Empty();
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
#ifdef __VTN_TIMELIMIT
	m_nAccountPlayTime = -1;
#endif // __VTN_TIMELIMIT
#if __VER >= 15 // __PETVIS
	m_objIdVisPet = NULL_ID;
	m_dwMoverSfxId = NULL_ID;
#endif // __PETVIS
#ifdef __AFK_REWARD_SYSTEM
	m_bAfk = FALSE;
#endif //__AFK_REWARD_SYSTEM
#if __VER >= 15 // __CAMPUS
	m_idCampus = 0;
	m_nCampusPoint = 0;
#endif // __CAMPUS
#ifdef __JOPS_GLOW
	m_iGlowBody = 0;
	m_iGlowLegLeft = 0;
	m_iGlowLegRight = 0;
	m_iGlowArmLeft = 0;
	m_iGlowArmRight = 0;
	m_iGlowHandLeft = 0;
	m_iGlowHandRight = 0;
	m_bodyc = FALSE;
	m_gllc = FALSE;
	m_glrc = FALSE;
	m_galc = FALSE;
	m_garc = FALSE;
	m_ghlc = FALSE;
	m_ghrc = FALSE;
#endif
#ifdef __NEW_ITEM_VARUNA
	m_idBarunaPetOwner = NULL_ID;
#endif // __NEW_ITEM_VARUNA
#ifdef __JOPS_GLOW
	m_dwGlowColor = 0;
#endif
#ifdef __MOUNT
	m_pMountModel = NULL;
	m_dwMountItemID = NULL_ID;
#endif // __MOUNT
#ifdef __PARTY_FIND
	m_bPartyJoin = 1;
#endif // __PARTY_FIND
#ifdef __DPSMETER_RYU
#ifdef __CLIENT
	m_bShowDPS = FALSE;
#endif // __CLIENT
#ifdef __WORLDSERVER
	m_bIsDPSMover = FALSE;
#endif // __WORLDSERVER
#endif // __DPSMETER_RYU
#ifdef __HIDE_COAT
	ZeroMemory(m_abHideCoat, sizeof(m_abHideCoat));
#endif // __HIDE_COAT
#ifdef __NAME_COLOR
	m_dwNameColor = 0;
#ifdef __NAME_FONT
	m_nNameFont = 0;
#endif // __NAME_FONT
#endif // __NAME_COLOR
#if defined(__SYS_WORLDBOSS) && defined(__WORLDSERVER)
	m_bIsWorldBoss = FALSE;
#endif //__SYS_WORLDBOSS
#ifdef __DEATH_MATCH
	m_bFightState = FALSE;
#endif // __DEATH_MATCH
#ifdef __BADGE
	m_nBadge = NULL_ID;
#endif //__BADGE
}


#ifdef __NO_HP_DMG_LIMIT
#ifdef __INSTANCE_AGGRO_SYSTEM
void CMover::SendAIMsg(DWORD dwMsg, unsigned long long dwParam1, unsigned long long dwParam2, unsigned long long dwParam3)
#else // __INSTANCE_AGGRO_SYSTEM
void CMover::SendAIMsg(DWORD dwMsg, unsigned long long dwParam1, unsigned long long dwParam2)
#endif // __INSTANCE_AGGRO_SYSTEM
#else
#ifdef __INSTANCE_AGGRO_SYSTEM
void CMover::SendAIMsg(DWORD dwMsg, DWORD dwParam1, DWORD dwParam2, DWORD dwParam3)
#else // __INSTANCE_AGGRO_SYSTEM
void CMover::SendAIMsg(DWORD dwMsg, DWORD dwParam1, DWORD dwParam2)
#endif // __INSTANCE_AGGRO_SYSTEM
#endif
{
	if (m_pAIInterface)
	{
#ifdef __INSTANCE_AGGRO_SYSTEM
		m_pAIInterface->SendAIMsg(dwMsg, dwParam1, dwParam2, dwParam3);
#else // __INSTANCE_AGGRO_SYSTEM
		m_pAIInterface->SendAIMsg(dwMsg, dwParam1, dwParam2);
#endif // __INSTANCE_AGGRO_SYSTEM
	}
}

// AI ¸Å½ÃÁö º¸³¿ : °´Ã¼ÀÇ Çàµ¿ ÆÐÅÏ, ÇöÀç »óÅÂ¸¦ ¸Å½ÃÁö·Î Á¦¾îÇÔ 
#ifdef __NO_HP_DMG_LIMIT
#ifdef __INSTANCE_AGGRO_SYSTEM
void CMover::PostAIMsg(DWORD dwMsg, unsigned long long dwParam1, unsigned long long dwParam2, unsigned long long dwParam3)
#else // __INSTANCE_AGGRO_SYSTEM
void CMover::PostAIMsg(DWORD dwMsg, unsigned long long dwParam1, unsigned long long dwParam2)
#endif // __INSTANCE_AGGRO_SYSTEM
#else
#ifdef __INSTANCE_AGGRO_SYSTEM
void CMover::PostAIMsg(DWORD dwMsg, DWORD dwParam1, DWORD dwParam2, DWORD dwParam3)
#else // __INSTANCE_AGGRO_SYSTEM
void CMover::PostAIMsg(DWORD dwMsg, DWORD dwParam1, DWORD dwParam2)
#endif // __INSTANCE_AGGRO_SYSTEM
#endif
{
	if (m_pAIInterface)
	{
#ifdef __INSTANCE_AGGRO_SYSTEM
		m_pAIInterface->PostAIMsg(dwMsg, dwParam1, dwParam2, dwParam3);
#else // __INSTANCE_AGGRO_SYSTEM
		m_pAIInterface->PostAIMsg(dwMsg, dwParam1, dwParam2);
#endif // __INSTANCE_AGGRO_SYSTEM
		}
}
//raiders.2006.11.28	 tradeµ·À» °è»ê¿¡ Æ÷ÇÔÇÏ´ø °ÍÀ» Á¦°Å
BOOL CMover::AddGold(int nGold, BOOL bSend)
{
	if (nGold == 0)
		return TRUE;

	//#ifdef __WORLDSERVER
	//	if( m_vtInfo.TradeGetGold() != 0 )
	//		return FALSE;
	//#endif	// __WORLDSERVER

#ifdef __PERIN_BUY_BUG
	__int64 i64Total = static_cast<__int64>(GetGold()) + static_cast<__int64>(nGold);

	if (i64Total > static_cast<__int64>(INT_MAX))
		i64Total = static_cast<__int64>(INT_MAX);
	else if (i64Total < 0)
		i64Total = 0;

	SetGold(static_cast<int>(i64Total));
#else // __PERIN_BUY_BUG
	int nTotal = GetGold() + nGold;

	if (nGold > 0)
	{
		if (nTotal < 0)		// overflow?
			nTotal = INT_MAX;
	}
	else	// nGold < 0
	{
		if (nTotal < 0)		// underflow?
		{
			//#ifdef __WORLDSERVER
			//			Error( "AddGold: nTotal < 0" );
			//#endif	// __WORLDSERVER
			nTotal = 0;
			//			return FALSE;
}
	}

	SetGold(nTotal);
#endif // __PERIN_BUY_BUG

	if (bSend)
	{
#ifdef __WORLDSERVER
#ifdef __PERIN_BUY_BUG
		g_UserMng.AddSetPointParam(this, DST_GOLD, static_cast<int>(i64Total));
#else // __PERIN_BUY_BUG
		g_UserMng.AddSetPointParam(this, DST_GOLD, nTotal);
#endif // __PERIN_BUY_BUG
#endif	// __WORLDSERVER
	}

	return TRUE;
}

// ÀÌµ¿ÆÐÅÏ ¼³Á¤.
void CMover::SetMovePattern( int nPattern )		
{
	m_nMovePattern = nPattern;
	m_nMoveEvent = 0;
	m_nMoveEventCnt = 0;
	ClearDest();		// ¸ñÇ¥´Â ¾ø´Ù.
}

// »õ·Î¿î ¸Ó¸®»ö±òÀÌ Àû¿ëµÇ±â Àü¿¡ ÀÌÇÔ¼ö¸¦ »ç¿ëÇØ¾ßÇÔ...
// ¿øº» ¸Ó¸®»ö±òÀ» Âü°íÇÏ±â ¶§¹®...
int	CMover::GetHairCost( CMover* pMover, BYTE nR, BYTE nG, BYTE nB, BYTE nHair )
{
	BYTE nOrignalR = (BYTE)( pMover->m_fHairColorR * 255 );
	BYTE nOrignalG = (BYTE)( pMover->m_fHairColorG * 255 );
	BYTE nOrignalB = (BYTE)( pMover->m_fHairColorB * 255 );

	int nHairCost = 0;
#if __VER >= 8 //__CSC_VER8_4
	int nHairColorCost = 0;
	
	if( nR != nOrignalR || nG != nOrignalG || nB != nOrignalB )
		nHairColorCost = HAIRCOLOR_COST;
	else
		nHairColorCost = 0;

	if( pMover->m_dwHairMesh+1 != nHair+1 )
		nHairCost = HAIR_COST;
	else
		nHairCost = 0;

	return (nHairCost + nHairColorCost);
#else //__CSC_VER8_4
	int nHairColorCostR = 0;
	int nHairColorCostG = 0;
	int nHairColorCostB = 0;
	
	if( nR >= nOrignalR  )
		nHairColorCostR = (nR - nOrignalR)*13;
	else
		nHairColorCostR = (nOrignalR - nR)*7;
	
	if( nG >= nOrignalG  )
		nHairColorCostG = (nG - nOrignalG)*13;
	else
		nHairColorCostG = (nOrignalG - nG)*7;
	
	if( nB >= nOrignalB  )
		nHairColorCostB = (nB - nOrignalB)*13;
	else
		nHairColorCostB = (nOrignalB - nB)*7;
	
	if( pMover->m_dwHairMesh+1 != nHair+1 )
	{
		switch( nHair+1 )
		{
			case 1: nHairCost = 2500;	break;
			case 2:	nHairCost = 2500;	break;
			case 3:	nHairCost = 2500;	break;
			case 4:	nHairCost = 2500;	break;
			case 5:	nHairCost = 2500;	break;
			default: nHairCost = 4000;	break;
		}
	}
	else
	{
		nHairCost = 0;
	}

	return ( nHairColorCostR + nHairColorCostG + nHairColorCostB + nHairCost );
#endif //__CSC_VER8_4
}

#ifdef __WORLDSERVER
void CMover::SubSMMode()
{
	time_t tmCur = (time_t)( CTime::GetCurrentTime().GetTime() );
	for( int i = 0 ; i < SM_MAX ; ++i )
	{
		if( m_dwSMTime[i] > 0 )
		{
			if( g_AddSMMode.bSMModetime[i] )	// Àý´ë½Ã°£
			{
				if( m_dwSMTime[i] < (DWORD)( tmCur ) )
				{
					m_dwSMTime[i] = 0;
				}
			}
			else								// Ä«¿îÆ®
			{
				if( i != SM_REVIVAL )
					--m_dwSMTime[i];	
			}

			if( m_dwSMTime[i] == 0 )
			{
				CItemElem* pItemElemParts = NULL;
				if( i == SM_RESIST_ATTACK_LEFT || i == SM_RESIST_ATTACK_RIGHT )
				{
					int nAttackResist;
					if( i == SM_RESIST_ATTACK_LEFT )
						nAttackResist = m_nAttackResistLeft;
					else
						nAttackResist = m_nAttackResistRight;

					switch( nAttackResist )
					{
					case SAI79::FIRE:
						g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_FIREASTONE;
						break;
					case SAI79::WATER:
						g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_WATEILSTONE;
						break;
					case SAI79::WIND:
						g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_WINDYOSTONE;
						break;
					case SAI79::ELECTRICITY:
						g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_LIGHTINESTONE;
						break;
					case SAI79::EARTH:
						g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_EARTHYSTONE;
						break;
					}
					if( i == SM_RESIST_ATTACK_LEFT )
					{
						m_nAttackResistLeft = (BYTE)0xff;
						pItemElemParts = m_Inventory.GetEquip( PARTS_LWEAPON );
					}
					else
					{
						m_nAttackResistRight = (BYTE)0xff;
						pItemElemParts = m_Inventory.GetEquip( PARTS_RWEAPON );
					}
					
				}
				else if( i == SM_RESIST_DEFENSE )
				{
					switch( m_nDefenseResist )
					{
					case SAI79::FIRE:
						g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_DEFIREASTONE;
						break;
					case SAI79::WATER:
						g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_DEWATEILSTONE;
						break;
					case SAI79::WIND:
						g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_DEWINDYOSTONE;
						break;
					case SAI79::ELECTRICITY:
						g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_DELIGHTINESTONE;
						break;
					case SAI79::EARTH:
						g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_DEEARTHYSTONE;
						break;
					}
					m_nDefenseResist = (BYTE)0xff;
					pItemElemParts = m_Inventory.GetEquip( PARTS_UPPER_BODY );
				}

				if( pItemElemParts && ( i == SM_RESIST_DEFENSE || i == SM_RESIST_ATTACK_LEFT || i == SM_RESIST_ATTACK_RIGHT ) )
				{
					pItemElemParts->m_nResistSMItemId = 0;
					((CUser*)this)->AddCommercialElem( pItemElemParts->m_dwObjId, 0 );
				}

				ItemProp* aItemprop = prj.GetItemProp( g_AddSMMode.dwSMItemID[i] );
				if( aItemprop )
				{
					if( i == SM_MAX_HP )
					{
						ResetDestParam( aItemprop->dwDestParam[0], aItemprop->nAdjParamVal[1], 1 );
					}
					else if( i == SM_MAX_HP50 )
					{
						ResetDestParam( aItemprop->dwDestParam[0], m_nPlusMaxHitPoint, 1 );
					}
					else if( i == SM_VELOCIJUMP )
					{
						if( aItemprop->dwDestParam1 != -1 )
							ResetDestParam( aItemprop->dwDestParam1, aItemprop->nAdjParamVal1 );
						if( aItemprop->dwDestParam2 != -1 )
							ResetDestParam( aItemprop->dwDestParam2, aItemprop->nAdjParamVal2 );
					}
#if __VER >= 12 // 12Â÷ ±Ø´ÜÀ¯·á¾ÆÀÌÅÛ
					// 090917 mirchang - ÆÄ½ºÅ³Ç® ¾ÆÀÌÅÛ »ç¿ë ±â°£ Á¾·á
					else if( i == SM_PARTYSKILL30 || i == SM_PARTYSKILL15 || i == SM_PARTYSKILL1 )
						g_DPCoreClient.SendUserPartySkill( m_idPlayer, PARTY_PARSKILL_MODE, 0, 0, 1 );
#endif // 12Â÷ ±Ø´ÜÀ¯·á¾ÆÀÌÅÛ
					
					g_dpDBClient.SendLogSMItemUse( "2", (CUser*)this, NULL, aItemprop );
				}
				else
				{
					WriteLog( "%s, %d\r\n\tNo SMItem dwSMItemID[%d] : %d / Name : %s", __FILE__, __LINE__, i, g_AddSMMode.dwSMItemID[i], m_szName );
				}

				((CUser*)this)->AddSMMode( i, 0 );

			}
		}
	}
}

#if defined (__BUFF_SERVER) || defined(__REMOVE_CMM)
void CMover::RemoveSMMode(int nType)
{
	time_t tmCur = (time_t)(CTime::GetCurrentTime().GetTime());
	if (nType >= 0 && nType < SM_MAX)
	{
		int i = nType;
		if (m_dwSMTime[i] > 0)
		{
			m_dwSMTime[i] = 0;
			CItemElem* pItemElemParts = NULL;
			if (i == SM_RESIST_ATTACK_LEFT || i == SM_RESIST_ATTACK_RIGHT)
			{
				int nAttackResist;
				if (i == SM_RESIST_ATTACK_LEFT)
					nAttackResist = m_nAttackResistLeft;
				else
					nAttackResist = m_nAttackResistRight;

				switch (nAttackResist)
				{
				case SAI79::FIRE:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_FIREASTONE;
					break;
				case SAI79::WATER:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_WATEILSTONE;
					break;
				case SAI79::WIND:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_WINDYOSTONE;
					break;
				case SAI79::ELECTRICITY:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_LIGHTINESTONE;
					break;
				case SAI79::EARTH:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_EARTHYSTONE;
					break;
				}
				if (i == SM_RESIST_ATTACK_LEFT)
				{
					m_nAttackResistLeft = (BYTE)0xff;
					pItemElemParts = m_Inventory.GetEquip(PARTS_LWEAPON);
				}
				else
				{
					m_nAttackResistRight = (BYTE)0xff;
					pItemElemParts = m_Inventory.GetEquip(PARTS_RWEAPON);
				}

			}
			else if (i == SM_RESIST_DEFENSE)
			{
				switch (m_nDefenseResist)
				{
				case SAI79::FIRE:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_DEFIREASTONE;
					break;
				case SAI79::WATER:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_DEWATEILSTONE;
					break;
				case SAI79::WIND:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_DEWINDYOSTONE;
					break;
				case SAI79::ELECTRICITY:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_DELIGHTINESTONE;
					break;
				case SAI79::EARTH:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_DEEARTHYSTONE;
					break;
				}
				m_nDefenseResist = (BYTE)0xff;
				pItemElemParts = m_Inventory.GetEquip(PARTS_UPPER_BODY);
			}

			if (pItemElemParts && (i == SM_RESIST_DEFENSE || i == SM_RESIST_ATTACK_LEFT || i == SM_RESIST_ATTACK_RIGHT))
			{
				pItemElemParts->m_nResistSMItemId = 0;
				((CUser*)this)->AddCommercialElem(pItemElemParts->m_dwObjId, 0);
			}

			ItemProp* aItemprop = prj.GetItemProp(g_AddSMMode.dwSMItemID[i]);
			if (aItemprop)
			{
				if (i == SM_MAX_HP)
				{
					ResetDestParam(aItemprop->dwDestParam[0], aItemprop->nAdjParamVal[1], 1);
				}
				else if (i == SM_MAX_HP50)
				{
					ResetDestParam(aItemprop->dwDestParam[0], m_nPlusMaxHitPoint, 1);
				}
				else if (i == SM_VELOCIJUMP)
				{
					if (aItemprop->dwDestParam1 != -1)
						ResetDestParam(aItemprop->dwDestParam1, aItemprop->nAdjParamVal1);
					if (aItemprop->dwDestParam2 != -1)
						ResetDestParam(aItemprop->dwDestParam2, aItemprop->nAdjParamVal2);
				}
#if __VER >= 12 // 12Â÷ ±Ø´ÜÀ¯·á¾ÆÀÌÅÛ
				// 090917 mirchang - ÆÄ½ºÅ³Ç® ¾ÆÀÌÅÛ »ç¿ë ±â°£ Á¾·á
				else if (i == SM_PARTYSKILL30 || i == SM_PARTYSKILL15 || i == SM_PARTYSKILL1)
					g_DPCoreClient.SendUserPartySkill(m_idPlayer, PARTY_PARSKILL_MODE, 0, 0, 1);
#endif // 12Â÷ ±Ø´ÜÀ¯·á¾ÆÀÌÅÛ
				g_dpDBClient.SendLogSMItemUse("2", (CUser*)this, NULL, aItemprop);
			}
			else
			{
				WriteLog("%s, %d\r\n\tNo SMItem dwSMItemID[%d] : %d / Name : %s", __FILE__, __LINE__, i, g_AddSMMode.dwSMItemID[i], m_szName);
			}

			((CUser*)this)->AddSMMode(i, 0);

		}
	}
}
#endif // __BUFF_SERVER

void CMover::ClearAllSMMode()
{
	time_t tmCur = (time_t)( CTime::GetCurrentTime().GetTime() );
	for( int i = 0 ; i < SM_MAX ; ++i )
	{
		if( m_dwSMTime[i] > 0 )
		{
			m_dwSMTime[i] = 0;
			CItemElem* pItemElemParts = NULL;
			if( i == SM_RESIST_ATTACK_LEFT || i == SM_RESIST_ATTACK_RIGHT )
			{
				int nAttackResist;
				if( i == SM_RESIST_ATTACK_LEFT )
					nAttackResist = m_nAttackResistLeft;
				else
					nAttackResist = m_nAttackResistRight;

				switch( nAttackResist )
				{
				case SAI79::FIRE:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_FIREASTONE;
					break;
				case SAI79::WATER:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_WATEILSTONE;
					break;
				case SAI79::WIND:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_WINDYOSTONE;
					break;
				case SAI79::ELECTRICITY:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_LIGHTINESTONE;
					break;
				case SAI79::EARTH:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_EARTHYSTONE;
					break;
				}
				if( i == SM_RESIST_ATTACK_LEFT )
				{
					m_nAttackResistLeft = (BYTE)0xff;
					pItemElemParts = m_Inventory.GetEquip( PARTS_LWEAPON );
				}
				else
				{
					m_nAttackResistRight = (BYTE)0xff;
					pItemElemParts = m_Inventory.GetEquip( PARTS_RWEAPON );
				}
					
			}
			else if( i == SM_RESIST_DEFENSE )
			{
				switch( m_nDefenseResist )
				{
				case SAI79::FIRE:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_DEFIREASTONE;
					break;
				case SAI79::WATER:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_DEWATEILSTONE;
					break;
				case SAI79::WIND:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_DEWINDYOSTONE;
					break;
				case SAI79::ELECTRICITY:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_DELIGHTINESTONE;
					break;
				case SAI79::EARTH:
					g_AddSMMode.dwSMItemID[i] = II_CHR_SYS_SCR_DEEARTHYSTONE;
					break;
				}
				m_nDefenseResist = (BYTE)0xff;
				pItemElemParts = m_Inventory.GetEquip( PARTS_UPPER_BODY );
			}

			if( pItemElemParts && ( i == SM_RESIST_DEFENSE || i == SM_RESIST_ATTACK_LEFT || i == SM_RESIST_ATTACK_RIGHT ) )
			{
				pItemElemParts->m_nResistSMItemId = 0;
				((CUser*)this)->AddCommercialElem( pItemElemParts->m_dwObjId, 0 );
			}

			ItemProp* aItemprop = prj.GetItemProp( g_AddSMMode.dwSMItemID[i] );
			if( aItemprop )
			{
				if( i == SM_MAX_HP )
				{
					ResetDestParam( aItemprop->dwDestParam[0], aItemprop->nAdjParamVal[1], 1 );
				}
				else if( i == SM_MAX_HP50 )
				{
					ResetDestParam( aItemprop->dwDestParam[0], m_nPlusMaxHitPoint, 1 );
				}
				else if( i == SM_VELOCIJUMP )
				{
					if( aItemprop->dwDestParam1 != -1 )
						ResetDestParam( aItemprop->dwDestParam1, aItemprop->nAdjParamVal1 );
					if( aItemprop->dwDestParam2 != -1 )
						ResetDestParam( aItemprop->dwDestParam2, aItemprop->nAdjParamVal2 );
				}
#if __VER >= 12 // 12Â÷ ±Ø´ÜÀ¯·á¾ÆÀÌÅÛ
				// 090917 mirchang - ÆÄ½ºÅ³Ç® ¾ÆÀÌÅÛ »ç¿ë ±â°£ Á¾·á
				else if( i == SM_PARTYSKILL30 || i == SM_PARTYSKILL15 || i == SM_PARTYSKILL1 )
					g_DPCoreClient.SendUserPartySkill( m_idPlayer, PARTY_PARSKILL_MODE, 0, 0, 1 );
#endif // 12Â÷ ±Ø´ÜÀ¯·á¾ÆÀÌÅÛ
				g_dpDBClient.SendLogSMItemUse( "2", (CUser*)this, NULL, aItemprop );
			}
			else
			{
				WriteLog( "%s, %d\r\n\tNo SMItem dwSMItemID[%d] : %d / Name : %s", __FILE__, __LINE__, i, g_AddSMMode.dwSMItemID[i], m_szName );
			}

			((CUser*)this)->AddSMMode( i, 0 );

		}
	}
}


BOOL CMover::SetSMMode( int nType, DWORD dwTime )
{
	if( g_AddSMMode.bSMModetime[nType] )	// Àý´ë½Ã°£
	{
		CTime tRealtime	= CTime::GetCurrentTime();
		CTimeSpan ctp( 0, 0, 0, dwTime );
		tRealtime += ctp;
		m_dwSMTime[nType] = (time_t)( tRealtime.GetTime() );
	}
	else	// Ä«¿îÆ®
	{
		m_dwSMTime[nType] = dwTime;
	}

	((CUser*)this)->AddSMMode( nType, m_dwSMTime[nType] );
	
	return TRUE;
}

#endif // __WORLDSERVER

LPCHARACTER CMover::GetCharacter()
{
	return prj.GetCharacter( m_szCharacterKey );
}

#ifdef __WORLDSERVER
void CMover::SetMarkingPos()
{
	m_vMarkingPos = GetPos();
	m_idMarkingWorld	= GetWorld()->GetID();
}
#endif

// NPC°ü·Ã ÇÁ·ÎÆÛÆ¼¸¦ ÃÊ±âÈ­ÇÑ´Ù.
void CMover::InitNPCProperty()
{
#ifdef __WORLDSERVER
	if( m_pNpcProperty == NULL )
		m_pNpcProperty = new CNpcProperty;
#endif
}

#if defined(__WORLDSERVER)	
void CMover::InitCharacter( LPCHARACTER lpCharacter )
{
	if( lpCharacter )
	{
#ifdef __OPT_MEM_0811
		if( lpCharacter->m_nEquipNum > 0 )
			m_Inventory.SetItemContainer( ITYPE_ITEM, MAX_INVENTORY, MAX_HUMAN_PARTS );
#endif	// __OPT_MEM_0811
		strcpy( m_szName, lpCharacter->m_strName );
		for( int i = 0; i < lpCharacter->m_nEquipNum; i++ )
		{
			BYTE nId, nCount;
			short nNum;
			CItemElem itemElem;
			itemElem.m_dwItemId	= lpCharacter->m_adwEquip[ i ];
			itemElem.m_nItemNum	= 1;
			m_Inventory.Add( &itemElem, &nId, &nNum, &nCount );
			CItemElem* pAddItem = m_Inventory.GetAtId( nId );
			m_Inventory.DoEquip( pAddItem->m_dwObjIndex, itemElem.GetProp()->dwParts );
		}

		m_dwHairMesh = lpCharacter->m_dwHairMesh;
		m_dwHairColor = lpCharacter->m_dwHairColor;
		m_dwHeadMesh = lpCharacter->m_dwHeadMesh;
#ifdef __GAMEGUARD
		m_bySex = (BYTE)lpCharacter->m_dwMoverIdx;
#endif // __GAMEGUARD

		AllocShopInventory( lpCharacter );
		LoadDialog();		// npcproperty->LoadDialog()
	#ifdef __OUTPUT_INFO_0803
		prj.OutputStore( lpCharacter->m_szKey, this );
	#endif	// __OUTPUT_INFO_0803
	}
	m_nHitPoint = GetMaxHitPoint();
}

BOOL CMover::LoadDialog()
{
	if( m_pNpcProperty )
	{
		LPCHARACTER lpCharacter = GetCharacter();
		if( lpCharacter )
			return m_pNpcProperty->LoadDialog( lpCharacter );
	}

	return FALSE;
}
#endif // __WORLDSERVER



void CMover::ProcessQuest()
{
#ifdef __WORLDSERVER 
	if( IsPlayer() == FALSE ) 
		return;

#ifdef __AFK_REWARD_SYSTEM
	CUser* pUser = ((CUser*)this);
	if (GetTickCount() - pUser->m_dwLastWalkTick >= MIN(120)) // __AFK_VENDING_TIME
	{
		if (!IsAfk())
		{
			m_bAfk = TRUE;
			g_UserMng.UpdateAfkState(pUser);
			//pUser->AddText("Congratulations! You have been AFK / Vending for 2 hours. Open and Close your Shop to receive your Reward.");

			
			CString szMsg;
			szMsg.Format( "You have been AFK for quite sometime now. If you have been vending for 2 hours just close your shop to unlock the VIP features. If you haven't started vending yet this is your chance to receive rewards from the server. Happy Vending!!!" );
			pUser->AddDiagText( szMsg );

		}
	}
#endif //__AFK_REWARD_SYSTEM
#ifdef __VICIOUS_SUMMONER

	// 		Puppeteer
	if (pUser->HasBuff(BUFF_SKILL, SI_WINDL_U_SKILL_04))
	{
		ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_MONSTERSKILL_01);
		if (pProp)
			pUser->DoApplySkill(pUser, pProp, NULL);
	}
	if (pUser->HasBuff(BUFF_SKILL, SI_WINDL_U_SKILL_04) == FALSE)
	{
		pUser->RemoveBuff(BUFF_ITEM, II_SYS_SYS_MONSTERSKILL_01);
	}
	// 		Demonologist
	if (pUser->HasBuff(BUFF_SKILL, SI_MENTA_U_SKILL_01))
	{
		ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_MONSTERSKILL_02);
		if (pProp)
			pUser->DoApplySkill(pUser, pProp, NULL);
	}
	if (pUser->HasBuff(BUFF_SKILL, SI_MENTA_U_SKILL_01) == FALSE)
	{
		pUser->RemoveBuff(BUFF_ITEM, II_SYS_SYS_MONSTERSKILL_02);
	}
	// 		Buddhist
	if (pUser->HasBuff(BUFF_SKILL, SI_FORCE_U_SKILL_01))
	{
		ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_MONSTERSKILL_03);
		if (pProp)
			pUser->DoApplySkill(pUser, pProp, NULL);
	}
	if (pUser->HasBuff(BUFF_SKILL, SI_FORCE_U_SKILL_01) == FALSE)
	{
		pUser->RemoveBuff(BUFF_ITEM, II_SYS_SYS_MONSTERSKILL_03);
	}
	// 		Prophet
	if (pUser->HasBuff(BUFF_SKILL, SI_FLORI_U_SKILL_01))
	{
		ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_MONSTERSKILL_04);
		if (pProp)
			pUser->DoApplySkill(pUser, pProp, NULL);
	}
	if (pUser->HasBuff(BUFF_SKILL, SI_FLORI_U_SKILL_01) == FALSE)
	{
		pUser->RemoveBuff(BUFF_ITEM, II_SYS_SYS_MONSTERSKILL_04);
	}
	// 		Sniper
	if (pUser->HasBuff(BUFF_SKILL, SI_CRACK_U_SKILL_03))

	{
		ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_MONSTERSKILL_05);
		if (pProp)
			pUser->DoApplySkill(pUser, pProp, NULL);
	}
	if (pUser->HasBuff(BUFF_SKILL, SI_CRACK_U_SKILL_03) == FALSE)
	{
		pUser->RemoveBuff(BUFF_ITEM, II_SYS_SYS_MONSTERSKILL_05);
	}
	// 		Executioner
	if (pUser->HasBuff(BUFF_SKILL, SI_STORM_U_SKILL_01))
	{
		ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_MONSTERSKILL_06);
		if (pProp)
			pUser->DoApplySkill(pUser, pProp, NULL);
	}
	if (pUser->HasBuff(BUFF_SKILL, SI_STORM_U_SKILL_01) == FALSE)
	{
		pUser->RemoveBuff(BUFF_ITEM, II_SYS_SYS_MONSTERSKILL_06);
	}
	// 		Paladin
	if (pUser->HasBuff(BUFF_SKILL, SI_LORDT_U_SKILL_01))
	{
		ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_MONSTERSKILL_07);
		if (pProp)
			pUser->DoApplySkill(pUser, pProp, NULL);
	}
	if (pUser->HasBuff(BUFF_SKILL, SI_LORDT_U_SKILL_01) == FALSE)
	{
		pUser->RemoveBuff(BUFF_ITEM, II_SYS_SYS_MONSTERSKILL_07);
	}
	// 		Necro
	if (pUser->HasBuff(BUFF_SKILL, SI_ELEME_U_SKILL_01))
	{
		ItemProp* pProp = prj.GetItemProp(II_SYS_SYS_MONSTERSKILL_08);
		if (pProp)
			pUser->DoApplySkill(pUser, pProp, NULL);
	}
	if (pUser->HasBuff(BUFF_SKILL, SI_ELEME_U_SKILL_01) == FALSE)
	{
		pUser->RemoveBuff(BUFF_ITEM, II_SYS_SYS_MONSTERSKILL_08);
	}

#endif // __VICIOUS_SUMMONER
	BOOL bTimer = FALSE;
	if( m_timerQuestLimitTime.IsTimeOut() )
	{
		m_timerQuestLimitTime.Reset();
		bTimer = TRUE;
	}
	for( int i = 0; i < m_nQuestSize; i++ )
	{
		LPQUEST lpQuest = (LPQUEST) &m_aQuest[ i ];
		if( lpQuest )
		{
			QuestProp* pQuestProp = prj.m_aPropQuest.GetAt( lpQuest->m_wId );
			if( pQuestProp )
			{
				D3DXVECTOR3 vPos = GetPos();
				// Äù½ºÆ® ¸®Àü¾ÈÀ¸·Î µé¾î°¡¸é ÆäÆ®·Ñ ÀÓ¹« ¼º°ø ÇÃ·º ¼¼ÆÃ 
				if( pQuestProp->m_dwEndCondPatrolWorld == GetWorld()->m_dwWorldID && pQuestProp->m_rectEndCondPatrol.PtInRect( CPoint( (int) vPos.x, (int) vPos.z ) ) )
				{
					if( lpQuest->m_bPatrol == FALSE )
					{
						lpQuest->m_bPatrol = TRUE;
						// ¿©±â¼­ Å¬¶ó¿¡ ¸Å½ÃÁöµµ ÇÏ³ª º¸³»ÀÚ. 
						// Å½»ç¸¦ ¿Ï·áÇß½À´Ï´Ù.
						// 20 ¸¶¸®Áß 2¸¶¸®¸¦ ÅðÄ¡Çß½À´Ï´Ù.
						((CUser*)this)->AddSetQuest( lpQuest ); 
					}
				}
				// ½Ã°£ Á¦ÇÑ Äù½ºÆ® ½Ã°£ Ä«¿îÆ® 
				if( pQuestProp->m_nEndCondLimitTime && bTimer )
				{
					if( lpQuest->m_wTime && !(lpQuest->m_wTime & 0x8000) ) 
					{
						lpQuest->m_wTime--;
						((CUser*)this)->AddSetQuest( lpQuest ); 
					}
				}
			}
			else
			{
				//WriteError( "ProcessQuest : pQuestProp NULLÀÌ´Ù." );
				//CString string;
				//string.Format( "CMover::ProcessQuest : %sÀÇ Quest %dÀÇ pQuestProp NULLÀÌ´Ù.", m_szName, lpQuest->m_wId );
				//OutputDebugString( string );
			}
		}
		else
		{
			//WriteError( "ProcessQuest : lpQuest°¡ NULLÀÌ´Ù." );
			//CString string;
			//string.Format( "CMover::ProcessQuest : %sÀÇ lpQuest°¡ NULLÀÌ´Ù.", m_szName );
			//OutputDebugString( string );
		}
	}
#else // __WORLDSERVER
	if( IsPlayer()  ) 
		return;
	LPCHARACTER lpCharacter = GetCharacter();
	if( lpCharacter )
	{
		CMover* pMover = GetActiveMover();
		m_nQuestEmoticonIndex = -1;
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
		// NPC Äù½ºÆ® ÀÌ¸ðÆ¼ÄÜ ¿ì¼±¼øÀ§ º¯°æ - ¿Ï·á > ½Å±Ô > ÁøÇà > ±Ù·¹º§
		for( int i = 0; i < lpCharacter->m_awSrcQuest.GetSize() ; i++ )
		{
			int nQuest = lpCharacter->m_awSrcQuest.GetAt( i );
			int nItem = lpCharacter->m_anSrcQuestItem.GetAt( i );
			LPQUEST lpQuest = pMover->GetQuest( nQuest );

			// »õ·Î¿î Äù½ºÆ®ÀÏ °æ¿ì
			if( lpQuest == NULL && pMover->IsCompleteQuest( nQuest ) == FALSE )
			{
				// ³»°¡ Äù½ºÆ® ½ÃÀÛ Á¶°ÇÀÎ°¡?
				if( __IsBeginQuestCondition( pMover, nQuest ) && ( nItem == 0 || pMover->GetItemNum( nItem ) ) )
					m_nQuestEmoticonIndex = 1;
				// »õ·Î¿î Äù½ºÆ®°¡ ¾ø°í ±Ù·¹º§¿¡ ¹ÞÀ» ¼ö ÀÖ´Â Äù½ºÆ®°¡ Á¸ÀçÇÑ´Ù¸é..
				else if( m_nQuestEmoticonIndex != 1 && __IsNextLevelQuest( pMover, nQuest ) && ( nItem == 0 || pMover->GetItemNum( nItem ) ) )
					m_nQuestEmoticonIndex = 4;
			}
			// ÁøÇàÁßÀÎ Äù½ºÆ®ÀÏ °æ¿ì
			if( lpQuest && prj.m_aPropQuest.GetAt( lpQuest->m_wId ) && pMover->IsCompleteQuest( nQuest ) == FALSE && lpQuest->m_nState != QS_END )
			{
				if( m_nQuestEmoticonIndex != 1 && ( nItem == 0 || pMover->GetItemNum( nItem ) ) )
					m_nQuestEmoticonIndex = 2;
			}
		}
		for( int i = 0; i < lpCharacter->m_awDstQuest.GetSize(); i++ )
		{
			int nQuest = lpCharacter->m_awDstQuest.GetAt( i );
			int nItem = lpCharacter->m_anDstQuestItem.GetAt( i );
			LPQUEST lpQuest = pMover->GetQuest( nQuest );
			
			// Äù½ºÆ®°¡ ÁøÇà ÁßÀÎ °æ¿ì 
			if( lpQuest && prj.m_aPropQuest.GetAt( lpQuest->m_wId ) && pMover->IsCompleteQuest( nQuest ) == FALSE && lpQuest->m_nState != QS_END )
			{
				// ³»°¡ Äù½ºÆ® Á¾·á Á¶°ÇÀÎ°¡?
				if( __IsEndQuestCondition( pMover, nQuest ) && ( nItem == 0 || pMover->GetItemNum( nItem ) ) )
					m_nQuestEmoticonIndex = 3;
				// ³»°¡ Äù½ºÆ® Á¾·á Á¶°ÇÀÌ ¾Æ´Ï°í »õ·Î¿î Äù½ºÆ®°¡ Á¸ÀçÇÏÁö ¾ÊÀ¸¸é..
				else if( m_nQuestEmoticonIndex != 3 && m_nQuestEmoticonIndex != 1 && ( nItem == 0 || pMover->GetItemNum( nItem ) ) )
					m_nQuestEmoticonIndex = 2;
			}
		}
#else // __IMPROVE_QUEST_INTERFACE
		for( int i = 0; i < lpCharacter->m_awSrcQuest.GetSize() ; i++ )
		{
			int nQuest = lpCharacter->m_awSrcQuest.GetAt( i );
			int nItem = lpCharacter->m_anSrcQuestItem.GetAt( i );
			LPQUEST lpQuest = pMover->GetQuest( nQuest );
			if( lpQuest == NULL && pMover->IsCompleteQuest( nQuest ) == FALSE )
			{
				// ³»°¡ Äù½ºÆ® ½ÃÀÛ Á¶°ÇÀÎ°¡?
				if( __IsBeginQuestCondition( pMover, nQuest ) && ( nItem == 0 || pMover->GetItemNum( nItem ) ) )
					m_nQuestEmoticonIndex = 1;
				// ³»°¡ Äù½ºÆ® ½ÃÀÛ Á¶°ÇÀÌ ¾Æ´Ñ°¡?
				else
				if( m_nQuestEmoticonIndex != 1 && ( nItem == 0 || pMover->GetItemNum( nItem ) ) )
					m_nQuestEmoticonIndex = 0;
			}
		}
		for(  i = 0; i < lpCharacter->m_awDstQuest.GetSize(); i++ )
		{
			int nQuest = lpCharacter->m_awDstQuest.GetAt( i );
			int nItem = lpCharacter->m_anDstQuestItem.GetAt( i );
			LPQUEST lpQuest = pMover->GetQuest( nQuest );
			// Äù½ºÆ®°¡ ÁøÇà ÁßÀÎ °æ¿ì 
			if( lpQuest && prj.m_aPropQuest.GetAt( lpQuest->m_wId ) && pMover->IsCompleteQuest( nQuest ) == FALSE && ( lpQuest->m_nState == 0 || lpQuest->m_nState == 14 ) ) 
			{
				// ³»°¡ Äù½ºÆ® Á¾·á Á¶°ÇÀÎ°¡?
				if( __IsEndQuestCondition( pMover, nQuest ) && ( nItem == 0 || pMover->GetItemNum( nItem ) ) )
					m_nQuestEmoticonIndex = 3;
				// ³»°¡ Äù½ºÆ® Á¾·á Á¶°ÇÀÌ ¾Æ´Ñ°¡?
				else
				if( m_nQuestEmoticonIndex != 3 && ( nItem == 0 || pMover->GetItemNum( nItem ) ) )
					m_nQuestEmoticonIndex = 2;
			}

		}
#endif // __IMPROVE_QUEST_INTERFACE
	}
#endif // __WORLDSERVER
}

#ifdef __WORLDSERVER
void CMover::ProcessAbnormalState()
{
	if( m_wStunCnt > 0 )
	{
		if( --m_wStunCnt <= 0 )
			SetStun( FALSE );	// ½ºÅÏ »óÅÂ ÇØÁ¦.
	}

	if( m_wDarkCover > 0 )
	{
		if( --m_wDarkCover <= 0 )
			SetDarkCover( FALSE );	// ½ºÅÏ »óÅÂ ÇØÁ¦.
	}

	if( GetAdjParam( DST_CHRSTATE ) & CHS_POISON )
	{
		if( IsLive() )
		{
			int nUnitCnt = (int)( (m_tmPoisonUnit / 1000.0f) * PROCESS_COUNT );
			if( nUnitCnt <= 0 )		
			{
				nUnitCnt = 1;
				SetPoison( FALSE );
			} 
			else
			{
				if( (m_nCount % nUnitCnt) == 0 )		// xxÃÊ¸¶´Ù ÇÑ¹ø¾¿ µ¥¹ÌÁö.
				{
					CCtrl *pAttacker = prj.GetCtrl( m_idPoisonAttacker );
					if( IsValidObj( pAttacker ) && pAttacker->GetType() == OT_MOVER )
					{
						m_pActMover->SendDamage( AF_FORCE, 
												 pAttacker->GetId(), 
												 m_wPoisonDamage );
					}
				}

				if( m_wPoisonCnt > 0 )	// µ¶ Áö¼Ó ½Ã°£µ¿¾È.. SkillInfluence·Î µ¹¶§´Â ÀÌ°Ô 0ÀÌ´Ù
					if( --m_wPoisonCnt <= 0 )	// µ¶ ½Ã°£ ´ÙµÇ¸é
						SetPoison( FALSE );		// µ¶»óÅÂ ÇìÁ¦.

			}
		}
	}
	
	if( m_wDarkCnt > 0 )	// ¾ÏÈæ Áö¼Ó½Ã°£µ¿¾È...
	{
		if( --m_wDarkCnt <= 0 )
			SetDark( FALSE );
	}

	if( GetAdjParam( DST_CHRSTATE ) & CHS_BLEEDING )
	{
		if( IsLive() )
		{
			int nUnitCnt = (int)( (m_tmBleedingUnit / 1000.0f) * PROCESS_COUNT );
			if( nUnitCnt <= 0 )		
			{
				nUnitCnt = 1;
				SetBleeding( FALSE );
			} 
			else
			{
				if( (m_nCount % nUnitCnt) == 0 )		// xxÃÊ¸¶´Ù ÇÑ¹ø¾¿ µ¥¹ÌÁö.
				{
					CCtrl *pAttacker = prj.GetCtrl( m_idBleedingAttacker );
					if( IsValidObj( pAttacker ) && pAttacker->GetType() == OT_MOVER )
					{
						m_pActMover->SendDamage( AF_FORCE, 
												 pAttacker->GetId(), 
												 m_wBleedingDamage );
					}
				}

				if( m_wBleedingCnt > 0 )	// ÃâÇ÷ Áö¼Ó ½Ã°£µ¿¾È..
					if( --m_wBleedingCnt <= 0 )	// µ¶ ½Ã°£ ´ÙµÇ¸é
						SetBleeding( FALSE );		// µ¶»óÅÂ ÇØÁ¦.
			}
		}
	}
#if __VER >= 9	// __PET_0410
	int nHeal	= GetAdjParam( DST_HEAL );
	if( nHeal > 0 )	// ÀÚµ¿ Ä¡À¯ »óÅÂ¸é,
	{
		if( m_nHealCnt > 0 )
			m_nHealCnt--;

		if( m_nHealCnt == 0 )
		{
			// HP°¡ 30% ÀÌÇÏ·Î ³»·Á°¬À» ½Ã, Á¤ÇØÁø ¼öÄ¡¸¸Å­ HP°¡ Ã¤¿öÁø´Ù. ÄðÅ¸ÀÓ 6ÃÊ
//			if( IsLive() && GetHitPointPercent( 100 ) <= 30 )
			if( IsLive() )
			{
				m_nHealCnt	= (short)( PROCESS_COUNT * 6.0f );		// ÄðÅ¸ÀÓ 6ÃÊ
				SetPointParam( DST_HP, GetHitPoint() + nHeal );
			}
		}
	}
#endif	// __PET_0410
#ifdef __BARUNA_PIERCING
	if( GetAdjParam( DST_FORCE_DAMAGE_VALUE ) > 0 )
	{
		if( IsLive() )
		{
			for ( int i = 0; i < MAX_BARUNA_DOT; i++ )
			{
				if( m_dwForceAttackerID[i] != 0 )
				{
					int nUnitCnt = (int)( (m_dwForceDamageUnit[i] / 1000.0f) * PROCESS_COUNT );
					if( nUnitCnt <= 0 )		
					{
						nUnitCnt = 1;
						m_dwForceDamageDamage[i] = 0;
						m_dwForceDamageCnt[i] = 0;
						m_dwForceDamageUnit[i] = 0;
						m_dwForceAttackerID[i] = 0;
					} 
					else
					{
						if( (m_nCount % nUnitCnt) == 0 )
						{
							CCtrl *pAttacker = prj.GetCtrl( m_dwForceAttackerID[i] );
							if( IsValidObj( pAttacker ) && pAttacker->GetType() == OT_MOVER )
							{
								m_pActMover->SendDamage( AF_FORCE, 
														 pAttacker->GetId(), 
														 m_dwForceDamageDamage[i] );
							}
						}
						if( m_dwForceDamageCnt[i] > 0 )
							if( --m_dwForceDamageCnt[i] <= 0 )
							{
								m_dwForceDamageDamage[i] = 0;
								m_dwForceDamageCnt[i] = 0;
								m_dwForceDamageUnit[i] = 0;
								m_dwForceAttackerID[i] = 0;
							}
					}
				}
			}
		}
	}
#endif // __BARUNA_PIERCING
}

// ¸ó½ºÅÍÀÇ °æ¿ì Á¤±âÀûÀ¸·Î idAttacker, m_idTargeter¸¦ °Ë»çÇØ¼­ ¾ø¾îÁø³ðÀÌ¸é »èÁ¦ÇÔ.
void CMover::ProcessTarget()
{
	if( m_idAttacker != NULL_ID || m_idTargeter != NULL_ID )		
	{
		CMover *pAttacker = GETMOVER( m_idAttacker );
		if( IsValidObj( pAttacker ) )
		{
			if( IsValidArea( pAttacker, 32.0f ) == FALSE )
			{
				m_idAttacker = NULL_ID;
			}
		} 
		else
		{
			m_idAttacker = NULL_ID;		// ¾îÅÂÄ¿°¡ ¾Æ¿¹ ¾ø¾îÁ³À¸¸é 
		}

		CMover *pTargeter = GETMOVER( m_idTargeter );
		if( IsValidObj( pTargeter ) )
		{
			if( IsValidArea( pTargeter, 32.0f ) == FALSE )
			{
				m_idTargeter = NULL_ID;
			}
		} 
		else
		{
			m_idTargeter = NULL_ID;		// Å¸°ÔÅÍ°¡ ¾Æ¿¹ ¾ø¾îÁ³À¸¸é ÃÊ±âÈ­.
		}
	}
}

void CMover::ProcessScript()
{ 
	if( IsPlayer() ) 
		return;

	if( m_szCharacterKey[ 0 ] && m_pNpcProperty->IsTimeOut() ) 
	{
		m_pNpcProperty->ResetTimer();
		m_pNpcProperty->RunDialog("#auto",NULL,0,GetId(),GetId(),0);
	}
}

void CMover::ProcessRegenItem()
{
	if( IsNPC() )
	{
		if( m_bRegenItem )
		{

			m_bRegenItem = FALSE;
			//
			// vender item ¹ß»ý 
			//
			//#define VENDER_DELAY (60 * 5) // 5ºÐ 
			LPCHARACTER pCharacter = GetCharacter();
			BOOL fShop	= FALSE;
			if( !pCharacter )
				return;

			LPVENDOR_ITEM pVendor;
			for( int i = 0; i < MAX_VENDOR_INVENTORY_TAB; i ++ )
			{
#if __VER >= 11 // __CSC_VER11_3
#ifdef __VENDOR_UPDATE
				if (pCharacter->m_nVenderType != 0)
#else // __VENDOR_UPDATE
				if (pCharacter->m_nVenderType == 1) // Ä¨À¸·Î °Å·¡ÇÏ´Â venderÀÏ °æ¿ì
#endif // __VENDOR_UPDATE
				{
					if(pCharacter->m_venderItemAry2[i].GetSize())
					{
						fShop	= TRUE;
						m_ShopInventory[i]->Clear();		// m_packÀ» ´Ù ¾ø¾Ø´Ù.
						for( int j = 0; j < pCharacter->m_venderItemAry2[i].GetSize(); j++ )
						{
							pVendor	= (LPVENDOR_ITEM)pCharacter->m_venderItemAry2[i].GetAt(j);
							CItemElem itemElem;
							itemElem.m_dwItemId	= pVendor->m_dwItemId;
							itemElem.m_nItemNum	= (short)( prj.GetItemProp( pVendor->m_dwItemId )->dwPackMax );
							itemElem.m_nHitPoint = prj.GetItemProp( pVendor->m_dwItemId )->dwEndurance;
							if ((int)itemElem.GetChipCost() < 1)
								Error( "chip cost < 1 : npc = %s, item = %d", pCharacter->m_szKey, pVendor->m_dwItemId );
							//else
								m_ShopInventory[i]->Add( &itemElem );
						}
					}
				}
				else
				{
#endif //__CSC_VER11_3
					if( pCharacter->m_venderItemAry[i].GetSize() )
					{
						fShop	= TRUE;
						{
							m_ShopInventory[i]->Clear();		// m_packÀ» ´Ù ¾ø¾Ø´Ù.

							ItemProp* apItemProp[MAX_VENDOR_INVENTORY];
							int cbSize	= 0;
							// generate
							for( int j = 0; j < pCharacter->m_venderItemAry[i].GetSize(); j++ )
							{
								pVendor		= (LPVENDOR_ITEM)pCharacter->m_venderItemAry[i].GetAt(j);
								GenerateVendorItem( apItemProp, &cbSize, MAX_VENDOR_INVENTORY, pVendor );
							}
							// sort
							for( int j = 0; j < cbSize - 1; j++ )
							{
								for( int k = j + 1; k < cbSize; k++ )
								{
									if( ( apItemProp[k]->dwItemKind1 < apItemProp[j]->dwItemKind1 ) ||
										( apItemProp[k]->dwItemKind1 == apItemProp[j]->dwItemKind1 && apItemProp[k]->dwItemRare < apItemProp[j]->dwItemRare ) )
									{
										ItemProp* ptmp	= apItemProp[j];
										apItemProp[j]	= apItemProp[k];
										apItemProp[k]	= ptmp;
									}
								}
							}
							// add
							for( int j = 0; j < cbSize; j++ )
							{
								CItemElem itemElem;
								itemElem.m_dwItemId	= apItemProp[j]->dwID;
								itemElem.m_nItemNum		= (short)( apItemProp[j]->dwPackMax );
								itemElem.m_nHitPoint	= apItemProp[j]->dwEndurance;
								if( m_ShopInventory[i]->Add( &itemElem ) == FALSE )
									break;
							}
						}
					}
#if __VER >= 11 // __CSC_VER11_3
				}
#endif //__CSC_VER11_3
#ifdef __ADDSHOPITEM
				if (pCharacter->m_venderItemAry3[i].GetSize())
				{
					fShop = TRUE;
					for (int j = 0; j < pCharacter->m_venderItemAry3[i].GetSize(); j++)
					{
						pVendor = (LPVENDOR_ITEM)pCharacter->m_venderItemAry3[i].GetAt(j);
						CItemElem itemElem;
						itemElem.m_dwItemId = pVendor->m_dwItemId;
						itemElem.m_nItemNum = (short)(prj.GetItemProp(pVendor->m_dwItemId)->dwPackMax);
						itemElem.m_nHitPoint = prj.GetItemProp(pVendor->m_dwItemId)->dwEndurance;

						if (m_ShopInventory[i]->Add(&itemElem) == FALSE)
							break;
					}
				}
#endif // __ADDSHOPITEM
			}

			if( fShop )
				g_UserMng.AddVendor( this );

		}
	}
}

#endif	// __WORLDSERVER

CModel* CMover::LoadModel( LPDIRECT3DDEVICE9 pd3dDevice, DWORD dwType, DWORD dwIndex )
{
	if (m_dwIndex == MI_FEMALE || m_dwIndex == MI_MALE)
		return prj.m_modelMng.LoadModel(pd3dDevice, dwType, dwIndex, TRUE);
	return prj.m_modelMng.LoadModel(pd3dDevice, dwType, dwIndex);
}

void CMover::InitProp( BOOL bInitAI )
{
	MoverProp* pProp = GetProp();
	if( pProp == NULL )
	{  
		Error( "CMover::InitProp - GetProp(%d) return NULL \n", GetIndex() );
		ASSERT( 0 );
		return;
	}

	if( m_szName[0] == '\0' )
		_tcscpy( m_szName, pProp->szName );

#ifdef __WORLDSERVER
	if( bInitAI )
		SetAIInterface( pProp->dwAI );
#else
	UNUSED_ALWAYS( bInitAI );
#endif	

	m_dwBelligerence = pProp->dwBelligerence;

#ifdef __OPT_MEM_0811
	if( IsPlayer() )
	{
		m_Inventory.SetItemContainer( ITYPE_ITEM, MAX_INVENTORY, MAX_HUMAN_PARTS );
		m_Pocket.Avail( 0 );
	}
#else
	m_Inventory.SetItemContainer( ITYPE_ITEM, MAX_INVENTORY, MAX_HUMAN_PARTS );
#endif

	m_nSlot = 0;
	m_bBank = FALSE;
	for( int k = 0 ; k < 3 ; ++k )
	{
		if( IsPlayer() )
			m_Bank[k].SetItemContainer( ITYPE_ITEM, MAX_BANK ) ;
		m_dwGoldBank[k] = 0;
		m_idPlayerBank[k] = 0;
	}
	ZeroMemory( m_ShopInventory, sizeof( m_ShopInventory ) );	
	
	ZeroMemory( m_aJobSkill, sizeof( m_aJobSkill ) );
	ZeroMemory( m_tmReUseDelay, sizeof( m_tmReUseDelay ) );

	for( int i = 0; i < MAX_SKILL_JOB; i++ )
	{
		m_aJobSkill[ i ].dwSkill = NULL_ID;
	}

	if( m_nJob != -1 ) 
	{
		ItemProp** apSkillProp = prj.m_aJobSkill[ m_nJob ];
		int nJobNum = prj.m_aJobSkillNum[ m_nJob ];
		
		LPSKILL lpSkill;
		for( int i = 0; i < nJobNum; i++ )
		{
			ItemProp* pSkillProp = apSkillProp[ i ];
			lpSkill = &m_aJobSkill[ i ];
			lpSkill->dwSkill = pSkillProp->dwID;
		}
	}

	m_nLevel = pProp->dwLevel;
	if( m_nLevel < 1 ) 
		m_nLevel = 1;

	if( IsPlayer() )
	{
		if( m_nJob != -1 )
		{
			m_nHitPoint     = GetMaxHitPoint();
			m_nManaPoint    = GetMaxManaPoint();
			m_nFatiguePoint = GetMaxFatiguePoint();
		}
		else
		{
			m_nHitPoint     = 1;
			m_nManaPoint    = 1;
			m_nFatiguePoint = 1;
		}

#ifdef __GAMEGUARD
		m_pActMover->m_fSpeed = 0.1F;
#else //__GAMEGUARD
		m_pActMover->m_fSpeed = pProp->fSpeed;
#endif //__GAMEGUARD
	}
	else
	{
		m_nStr = pProp->dwStr; 
		m_nSta = pProp->dwSta;
		m_nDex = pProp->dwDex;
		m_nInt = pProp->dwInt;

		m_nHitPoint     = GetMaxHitPoint();
		m_nManaPoint    = pProp->dwAddMp;
		m_nFatiguePoint = GetMaxFatiguePoint();
	}

	UpdateParam();
	m_dwVirtItem = pProp->dwAtk1;

	if( m_bPlayer == FALSE && pProp->dwFlying == 1 )
		m_dwTypeFlag |= OBJTYPE_FLYING;

	if( IsPlayer() )
	{
		m_aQuest = new QUEST[ MAX_QUEST ]; 
		m_aCompleteQuest = new WORD[ MAX_COMPLETE_QUEST ]; 
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
		m_aCheckedQuest = new WORD[ MAX_CHECKED_QUEST ];
#endif // __IMPROVE_QUEST_INTERFACE
	}
}
#ifdef __REBIRTH
void CMover::InitLevelRebirth(int nJob, LONG nLevel, BOOL bGamma)
{
#ifdef __WORLDSERVER
		MoverProp* pProp = GetProp();
	if (pProp)
	{
		if (nJob > 0 && nJob < MAX_LEGEND_HERO_ULTIMATE)
		{
			AddChangeJob(nJob);
		}
		else {
			return;
		}
		int nPoint = 0;
		if (m_nJob == JOB_MERCENARY)
			nPoint += 40;
		else if (m_nJob == JOB_ACROBAT)
			nPoint += 50;
		else if (m_nJob == JOB_ASSIST)
			nPoint += 60;
		else if (m_nJob == JOB_MAGICIAN)
			nPoint += 90;
		else if (m_nJob == JOB_KNIGHT || m_nJob == JOB_BLADE)
			nPoint += 120;
		else if (m_nJob == JOB_JESTER || m_nJob == JOB_RANGER)
			nPoint += 150;
		else if (m_nJob == JOB_RINGMASTER)
			nPoint += 160;
		else if (m_nJob == JOB_BILLPOSTER || m_nJob == JOB_PSYCHIKEEPER)
			nPoint += 180;
		else if (m_nJob == JOB_ELEMENTOR)
			nPoint += 390;
		else if (nJob == JOB_LORDTEMPLER_HERO || nJob == JOB_STORMBLADE_HERO)
			nPoint += 120;
		else if (nJob == JOB_WINDLURKER_HERO || nJob == JOB_CRACKSHOOTER_HERO)
			nPoint += 150;
		else if (nJob == JOB_FLORIST_HERO)
			nPoint += 160;
		else if (nJob == JOB_FORCEMASTER_HERO || nJob == JOB_MENTALIST_HERO)
			nPoint += 180;
		else if (nJob == JOB_ELEMENTORLORD_HERO)
			nPoint += 390;
		else if (nJob == JOB_LORDTEMPLER_HERO_ULTIMATE || nJob == JOB_STORMBLADE_HERO_ULTIMATE)
			nPoint += 120;
		else if (nJob == JOB_WINDLURKER_HERO_ULTIMATE || nJob == JOB_CRACKSHOOTER_HERO_ULTIMATE)
			nPoint += 150;
		else if (nJob == JOB_FLORIST_HERO_ULTIMATE)
			nPoint += 160;
		else if (nJob == JOB_FORCEMASTER_HERO_ULTIMATE || nJob == JOB_MENTALIST_HERO_ULTIMATE)
			nPoint += 180;
		else if (nJob == JOB_ELEMENTORLORD_HERO_ULTIMATE)
			nPoint += 390;

		AddSkillPoint(nPoint);
		m_nLevel = nLevel;

		SetJobLevel(nLevel, nJob);
		m_nDeathLevel = nLevel;
#if __VER >= 10 
		if (IsMaster())
		{
			int dwTmpSkLevel = 1;//60, 72, 84, 96, 108
			if (nLevel > 59 && nLevel < 72)
				dwTmpSkLevel = 1;
			else if (nLevel > 71 && nLevel < 84)
				dwTmpSkLevel = 2;
			else if (nLevel > 83 && nLevel < 96)
				dwTmpSkLevel = 3;
			else if (nLevel > 95 && nLevel < 108)
				dwTmpSkLevel = 4;
			else if (nLevel > 107 && nLevel < 120)
				dwTmpSkLevel = 5;
			for (int i = 0; i < MAX_SKILL_JOB; i++)
			{
				LPSKILL lpSkill = &(m_aJobSkill[i]);
				if (lpSkill && lpSkill->dwSkill != NULL_ID)
				{
					ItemProp* pSkillProp = prj.GetSkillProp(lpSkill->dwSkill);
					if (pSkillProp == NULL)
						continue;
					if (pSkillProp->dwItemKind1 != JTYPE_MASTER)
						continue;
					lpSkill->dwLevel = dwTmpSkLevel;
				}
			}
		}
		else if (IsHero())
		{
			for (int i = 0; i < MAX_SKILL_JOB; i++)
			{
				LPSKILL lpSkill = &(m_aJobSkill[i]);
				if (lpSkill && lpSkill->dwSkill != NULL_ID)
				{
					ItemProp* pSkillProp = prj.GetSkillProp(lpSkill->dwSkill);
					if (pSkillProp == NULL)
						continue;
					if (pSkillProp->dwItemKind1 != JTYPE_MASTER)
						continue;
					lpSkill->dwLevel = 5;
				}
			}
		}
		else if (IsLegendHero())
		{
			for (int i = 0; i < MAX_SKILL_JOB; i++)
			{
				LPSKILL lpSkill = &(m_aJobSkill[i]);
				if (lpSkill && lpSkill->dwSkill != NULL_ID)
				{
					ItemProp* pSkillProp = prj.GetSkillProp(lpSkill->dwSkill);
					if (pSkillProp == NULL)
						continue;
					if (pSkillProp->dwItemKind1 != JTYPE_MASTER)
						continue;
					lpSkill->dwLevel = 5;
				}
			}
		}
		else if (IsLegendHeroUltimate())
		{
			for (int i = 0; i < MAX_SKILL_JOB; i++)
			{
				LPSKILL lpSkill = &(m_aJobSkill[i]);
				if (lpSkill && lpSkill->dwSkill != NULL_ID)
				{
					ItemProp* pSkillProp = prj.GetSkillProp(lpSkill->dwSkill);
					if (pSkillProp == NULL)
						continue;
					if (pSkillProp->dwItemKind1 != JTYPE_MASTER)
						continue;
					lpSkill->dwLevel = 5;
				}
			}
		}
#endif
		if (bGamma)
		{
			m_nExp1 = 0;
		}

		((CUser*)this)->AddSetChangeJob(nJob);
		g_UserMng.AddNearSetChangeJob(this, nJob, &((CUser*)this)->m_aJobSkill[MAX_JOB_SKILL]);


#if __VER >= 11 // __SYS_PLAYER_DATA
		g_dpDBClient.SendUpdatePlayerData((CUser*)this);
#else    // __SYS_PLAYER_DATA
		g_DPCoreClient.SendPartyMemberJob((CUser*)this);
		g_DPCoreClient.SendFriendChangeJob((CUser*)this);
		if (m_idGuild != 0)
			g_DPCoreClient.SendGuildChangeJobLevel((CUser*)this);
#endif    // __SYS_PLAYER_DATA
		SetHitPoint(GetMaxHitPoint());
		SetManaPoint(GetMaxManaPoint());
		SetFatiguePoint(GetMaxFatiguePoint());

		m_nCampusPoint = m_nCampusPoint + 1;

		//Rebirth for Items
		CItemElem itemelem;
		itemelem.m_nItemNum = 0;
		BYTE nID;
		if (m_nCampusPoint >= 1)
		{
			itemelem.m_nItemNum = 500;
			itemelem.m_dwItemId = II_SYS_SYS_FORTUNETOKEN_PLATINUM;
			((CUser*)this)->CreateItem(&itemelem, &nID);
		}
		//Rebirth for Stats
		if (nJob >= 1 && nJob <= 4)
		{
			m_nStr = m_nSta = m_nDex = m_nInt = 15;
			m_nRemainGP = 28;
		}
		if (nJob >= MAX_PROFESSIONAL && nJob <= MAX_LEGEND_HERO_ULTIMATE)
		{
			if (m_nRemainGP > 0)
				m_nRemainGP = 0;

			if (m_nCampusPoint < MAX_REBIRTH)
			{
				m_nRemainGP = (m_nCampusPoint * 100) + 550;
				goto end;
			}
		}
	end:;
		m_nStr = m_nSta = m_nDex = m_nInt = 50;
		g_UserMng.AddSetLevel(this, (WORD)m_nLevel);
		((CUser*)this)->AddSetGrowthLearningPoint(m_nRemainGP);
		((CUser*)this)->AddSetExperience(GetExp1(), (WORD)m_nLevel, m_nSkillPoint, m_nSkillLevel, m_nCampusPoint);
#ifdef __GAMEGUARD
		((CUser*)this)->AddSetState(m_nStr, m_nSta, m_nDex, m_nInt, m_nRemainGP, TRUE);
#else // __GAMEGUARD
		((CUser*)this)->AddSetState(m_nStr, m_nSta, m_nDex, m_nInt, m_nRemainGP);
#endif // __GAMEGUARD
#if __VER >= 13 // __HONORABLE_TITLE 
		((CUser*)this)->CheckHonorStat();
		((CUser*)this)->AddHonorListAck();
		g_UserMng.AddHonorTitleChange(this, m_nHonor);
#endif    // __HONORABLE_TITLE
	}
#endif // __WORLDSERVER
}
#endif //__REBIRTH
void CMover::InitLevel(int nJob, LONG nLevel, BOOL bGamma)
{
#ifdef __WORLDSERVER
		// ¿î¿µÀÚ ¸í·ÉÀ¸·Î ·¹º§¾÷ ÇÏ´Â°÷ÀÓ
		MoverProp* pProp = GetProp();
	if (pProp)
	{
		// ¹æ¶ûÀÚ ½ºÅ³ °ª °¡Áö°í ÀÖ±â.
		int nJobSkillBuf[MAX_JOB_SKILL];
		int nJobSkillLevelBuf[MAX_JOB_SKILL];
		for (int i = 0; i < MAX_JOB_SKILL; ++i)
		{
			nJobSkillBuf[i] = m_aJobSkill[i].dwSkill;
			nJobSkillLevelBuf[i] = m_aJobSkill[i].dwLevel;
		}
		ZeroMemory(m_aJobSkill, sizeof(m_aJobSkill));

		LPSKILL lpSkill;
		// Àâ½ºÅ³ ÃÊ±âÈ­ 
		for (int i = 0; i < MAX_SKILL_JOB; i++)
		{
			m_aJobSkill[i].dwSkill = NULL_ID;
			m_aJobSkill[i].dwLevel = 0;
		}

		// 1. ¹æ¶ûÀÚ ½ºÅ³Àº ±×³É Áö±Þ
		m_nJob = JOB_VAGRANT;
		ItemProp** apSkillProp = prj.m_aJobSkill[m_nJob];
		int nJobNum = prj.m_aJobSkillNum[m_nJob];
		for (int i = 0; i < nJobNum; i++)
		{
			ItemProp* pSkillProp = apSkillProp[i];
			lpSkill = &m_aJobSkill[i];
			lpSkill->dwSkill = pSkillProp->dwID;
		}
		// 2. ±âº» ´É·ÂÄ¡ ÃÊ±âÈ­ 
		m_nLevel = 1;
		m_nStr = m_nSta = m_nDex = m_nInt = 15;
		m_nRemainGP = 0;
		m_nSkillLevel = 0;
		m_nSkillPoint = 0;

		// 3. LP, GP, Á÷¾÷
		for (int i = 1; i < nLevel; i++)
		{
			m_nLevel = i + 1;
			m_nRemainGP += prj.m_aExpCharacter[m_nLevel].dwLPPoint;
#ifdef __NEWCLASS
			if (nJob >= MAX_PROFESSIONAL && i > 59)
				m_nRemainGP++;

#ifdef __GAMEGUARD
			if ( /*IsHero() &&*/ i == MAX_GENERAL_LEVEL)
				m_nRemainGP += 12;
#endif // __GAMEGUARD

			if (nJob < MAX_PROFESSIONAL)
			{
				if ((i + 1) == MAX_JOB_LEVEL)
				{
					if (nJob < MAX_EXPERT)
					{
						AddChangeJob(nJob);
					}
					else
					{
						if (nJob % 2 != 0)
						{
							AddChangeJob((nJob - 5) / 2);
						}
						else
						{
							AddChangeJob((nJob - 4) / 2);
						}
					}
				}
				else
					if ((i + 1) == MAX_JOB_LEVEL + MAX_EXP_LEVEL)
					{
						AddChangeJob(nJob);
					}
			}
			else
			{
				if ((i + 1) == MAX_JOB_LEVEL)
				{
					if (nJob < MAX_MASTER)
					{
						if (nJob % 2 != 0)
						{
							AddChangeJob((nJob - 15) / 2);
						}
						else
						{
							AddChangeJob((nJob - 14) / 2);
						}
					}
					else if (nJob < MAX_HERO)
					{
						if (nJob % 2 != 0)
						{
							AddChangeJob((nJob - 23) / 2);
						}
						else
						{
							AddChangeJob((nJob - 22) / 2);
						}
					}
					else if (nJob < MAX_LEGEND_HERO)
					{
						if (nJob % 2 != 0)
						{
							AddChangeJob((nJob - 31) / 2);
						}
						else
						{
							AddChangeJob((nJob - 30) / 2);
						}
					}
					else
					{
						if (nJob % 2 != 0)
						{
							AddChangeJob((nJob - 39) / 2);
						}
						else
						{
							AddChangeJob((nJob - 38) / 2);
						}
					}
				}
				else
					if ((i + 1) == MAX_JOB_LEVEL + MAX_EXP_LEVEL)
					{
						if (nJob < MAX_MASTER)
						{
							AddChangeJob(nJob - 10);
							AddChangeJob(nJob);
						}
						else if (nJob < MAX_HERO)
						{
							AddChangeJob(nJob - 18);
							AddChangeJob(nJob - 8);
							AddChangeJob(nJob);
						}
						else if (nJob < MAX_LEGEND_HERO)
						{
							AddChangeJob(nJob - 26);
							AddChangeJob(nJob - 16);
							AddChangeJob(nJob - 8);
							AddChangeJob(nJob);
						}
						else
						{
							AddChangeJob(nJob - 34);
							AddChangeJob(nJob - 24);
							AddChangeJob(nJob - 16);
							AddChangeJob(nJob - 8);
							AddChangeJob(nJob);
						}
					}
			}
#else // __NEWCLASS
#ifdef __3RD_LEGEND16
			if (nJob >= MAX_PROFESSIONAL && i > 59)
				m_nRemainGP++;

#ifdef __GAMEGUARD
			if ( /*IsHero() &&*/ i == MAX_GENERAL_LEVEL)
				m_nRemainGP += 12;
#endif // __GAMEGUARD

			if (nJob < MAX_PROFESSIONAL)
			{
				if ((i + 1) == MAX_JOB_LEVEL)
				{
					if (nJob < MAX_EXPERT)
					{
						AddChangeJob(nJob);
					}
					else
					{
						if (nJob % 2 != 0)
						{
							AddChangeJob((nJob - 5) / 2);
						}
						else
						{
							AddChangeJob((nJob - 4) / 2);
						}
					}
				}
				else
					if ((i + 1) == MAX_JOB_LEVEL + MAX_EXP_LEVEL)
					{
						AddChangeJob(nJob);
					}
			}
			else
			{
				if ((i + 1) == MAX_JOB_LEVEL)
				{
					if (nJob < MAX_MASTER)
					{
						if (nJob % 2 != 0)
						{
							AddChangeJob((nJob - 15) / 2);
						}
						else
						{
							AddChangeJob((nJob - 14) / 2);
						}
					}
					else if (nJob < MAX_HERO)
					{
						if (nJob % 2 != 0)
						{
							AddChangeJob((nJob - 23) / 2);
						}
						else
						{
							AddChangeJob((nJob - 22) / 2);
						}
					}
					else
					{
						if (nJob % 2 != 0)
						{
							AddChangeJob((nJob - 31) / 2);
						}
						else
						{
							AddChangeJob((nJob - 30) / 2);
						}
					}
				}
				else
					if ((i + 1) == MAX_JOB_LEVEL + MAX_EXP_LEVEL)
					{
						if (nJob < MAX_MASTER)
						{
							AddChangeJob(nJob - 10);
							AddChangeJob(nJob);
						}
						else if (nJob < MAX_HERO)
						{
							AddChangeJob(nJob - 18);
							AddChangeJob(nJob - 8);
							AddChangeJob(nJob);
						}
						else
						{
							AddChangeJob(nJob - 26);
							AddChangeJob(nJob - 16);
							AddChangeJob(nJob - 8);
							AddChangeJob(nJob);
						}
					}
			}
#else // __3RD_LEGEND16
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			if (nJob >= MAX_PROFESSIONAL && i > 59)
				m_nRemainGP++;

			if (nJob < MAX_PROFESSIONAL)
			{
				if ((i + 1) == MAX_JOB_LEVEL)
				{
					if (nJob < MAX_EXPERT)
					{
						AddChangeJob(nJob);
					}
					else
					{
						if (nJob % 2 != 0)
						{
							AddChangeJob((nJob - 5) / 2);
						}
						else
						{
							AddChangeJob((nJob - 4) / 2);
						}
					}
				}
				else
					if ((i + 1) == MAX_JOB_LEVEL + MAX_EXP_LEVEL)
					{
						AddChangeJob(nJob);
					}
			}
			else
			{
				if ((i + 1) == MAX_JOB_LEVEL)
				{
					if (nJob < MAX_MASTER)
					{
						if (nJob % 2 != 0)
						{
							AddChangeJob((nJob - 15) / 2);
						}
						else
						{
							AddChangeJob((nJob - 14) / 2);
						}
					}
					else
					{
						if (nJob % 2 != 0)
						{
							AddChangeJob((nJob - 23) / 2);
						}
						else
						{
							AddChangeJob((nJob - 22) / 2);
						}
					}
				}
				else
					if ((i + 1) == MAX_JOB_LEVEL + MAX_EXP_LEVEL)
					{
						if (nJob < MAX_MASTER)
						{
							AddChangeJob(nJob - 10);
							AddChangeJob(nJob);
						}
						else
						{
							AddChangeJob(nJob - 18);
							AddChangeJob(nJob - 8);
							AddChangeJob(nJob);
						}
					}
			}
#else //__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			if ((i + 1) == MAX_JOB_LEVEL)
			{
				if (nJob < MAX_EXPERT)
				{
					AddChangeJob(nJob);
				}
				else
				{
					if (nJob % 2 != 0)
					{
						AddChangeJob((nJob - 5) / 2);
					}
					else
					{
						AddChangeJob((nJob - 4) / 2);
					}
				}
			}
			else
				if ((i + 1) == MAX_JOB_LEVEL + MAX_EXP_LEVEL)
				{
					AddChangeJob(nJob);
				}
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#endif // __3RD_LEGEND16
#endif // __NEWCLASS
		}
		int nPoint = 0;
		if (m_nLevel <= 20)
			nPoint = 2 * m_nLevel - 2;
		else if (m_nLevel <= 40)
			nPoint = 3 * m_nLevel - 22;
		else if (m_nLevel <= 60)
			nPoint = 4 * m_nLevel - 62;
		else if (m_nLevel <= 80)
			nPoint = 5 * m_nLevel - 122;
		else if (m_nLevel <= 100)
			nPoint = 6 * m_nLevel - 202;
		else
			nPoint = 7 * m_nLevel - 302;

		if (m_nJob == JOB_MERCENARY)
			nPoint += 40;
		else if (m_nJob == JOB_ACROBAT)
			nPoint += 50;
		else if (m_nJob == JOB_ASSIST)
			nPoint += 60;
		else if (m_nJob == JOB_MAGICIAN)
			nPoint += 90;
		else if (m_nJob == JOB_KNIGHT || m_nJob == JOB_BLADE)
			nPoint += 120;
		else if (m_nJob == JOB_JESTER || m_nJob == JOB_RANGER)
			nPoint += 150;
		else if (m_nJob == JOB_RINGMASTER)
			nPoint += 160;
		else if (m_nJob == JOB_BILLPOSTER || m_nJob == JOB_PSYCHIKEEPER)
			nPoint += 180;
		else if (m_nJob == JOB_ELEMENTOR)
			nPoint += 390;
		m_nSkillLevel = m_nSkillPoint = nPoint;

		SetJobLevel(nLevel, nJob);
		m_nDeathLevel = nLevel;
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if (IsMaster())
		{
			int dwTmpSkLevel = 1;//60, 72, 84, 96, 108
			if (nLevel > 59 && nLevel < 72)
				dwTmpSkLevel = 1;
			else if (nLevel > 71 && nLevel < 84)
				dwTmpSkLevel = 2;
			else if (nLevel > 83 && nLevel < 96)
				dwTmpSkLevel = 3;
			else if (nLevel > 95 && nLevel < 108)
				dwTmpSkLevel = 4;
			else if (nLevel > 107 && nLevel < 120)
				dwTmpSkLevel = 5;
			for (int i = 0; i < MAX_SKILL_JOB; i++)
			{
				LPSKILL lpSkill = &(m_aJobSkill[i]);
				if (lpSkill && lpSkill->dwSkill != NULL_ID)
				{
					ItemProp* pSkillProp = prj.GetSkillProp(lpSkill->dwSkill);
					if (pSkillProp == NULL)
						continue;
					if (pSkillProp->dwItemKind1 != JTYPE_MASTER)
						continue;
					lpSkill->dwLevel = dwTmpSkLevel;
				}
			}
		}

		else if (IsHero()
#ifdef __3RD_LEGEND16
			|| IsLegendHero()
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
			|| IsLegendHeroUltimate()
#endif // __NEWCLASS
			)
		{
			for (int i = 0; i < MAX_SKILL_JOB; i++)
			{
				LPSKILL lpSkill = &(m_aJobSkill[i]);
				if (lpSkill && lpSkill->dwSkill != NULL_ID)
				{
					ItemProp* pSkillProp = prj.GetSkillProp(lpSkill->dwSkill);
					if (pSkillProp == NULL)
						continue;
					if (pSkillProp->dwItemKind1 != JTYPE_MASTER)
						continue;
					lpSkill->dwLevel = 5;
				}
			}
		}
#endif	// 	__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if (bGamma)
		{
			m_nExp1 = 0;
		}

		if (m_nLevel >= 20)
			SetFlightLv(1);
		else
			SetFlightLv(0);

		((CUser*)this)->AddSetChangeJob(nJob);
		g_UserMng.AddNearSetChangeJob(this, nJob, &((CUser*)this)->m_aJobSkill[MAX_JOB_SKILL]);
		// #ifdef __S_RECOMMEND_EVE
		// 		if( g_eLocal.GetState( EVE_RECOMMEND ) && IsPlayer() )
		// 			g_dpDBClient.SendRecommend( (CUser*)this, nJob );
		// #endif // __S_RECOMMEND_EVE

#if __VER >= 11 // __SYS_PLAYER_DATA
		g_dpDBClient.SendUpdatePlayerData((CUser*)this);
#else	// __SYS_PLAYER_DATA
		g_DPCoreClient.SendPartyMemberJob((CUser*)this);
		g_DPCoreClient.SendFriendChangeJob((CUser*)this);
		if (m_idGuild != 0)
			g_DPCoreClient.SendGuildChangeJobLevel((CUser*)this);
#endif	// __SYS_PLAYER_DATA
		SetHitPoint(GetMaxHitPoint());
		SetManaPoint(GetMaxManaPoint());
		SetFatiguePoint(GetMaxFatiguePoint());

		g_UserMng.AddSetLevel(this, (WORD)m_nLevel);
		((CUser*)this)->AddSetGrowthLearningPoint(m_nRemainGP);
		((CUser*)this)->AddSetExperience(GetExp1(), (WORD)m_nLevel, m_nSkillPoint, m_nSkillLevel);
		((CUser*)this)->m_playTaskBar.InitTaskBarShorcutKind(SHORTCUT_SKILL);
		((CUser*)this)->AddTaskBar();
#ifdef __GAMEGUARD
		((CUser*)this)->AddSetState(m_nStr, m_nSta, m_nDex, m_nInt, m_nRemainGP, TRUE);
#else // __GAMEGUARD
		((CUser*)this)->AddSetState(m_nStr, m_nSta, m_nDex, m_nInt, m_nRemainGP);
#endif // __GAMEGUARD
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
		((CUser*)this)->CheckHonorStat();
		((CUser*)this)->AddHonorListAck();
		g_UserMng.AddHonorTitleChange(this, m_nHonor);
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
#ifdef __AUTO_MAX_SKILL
		LPSKILL pSkill = NULL;
		ItemProp* pSkillProp = NULL;
		for (int i = 0; i < MAX_SKILL_JOB; i++)
		{
			pSkill = &(((CUser*)this)->m_aJobSkill[i]);
			if (pSkill == NULL || pSkill->dwSkill == 0xffffffff)
				continue;

			pSkillProp = prj.GetSkillProp(pSkill->dwSkill);
			if (pSkillProp == NULL)
				continue;

			pSkill->dwLevel = pSkillProp->dwExpertMax;
			((CUser*)this)->AddSetSkill(pSkill->dwSkill, pSkill->dwLevel);
}
#endif // __AUTO_MAX_SKILL
	}
#endif // __WORLDSERVER
}
#ifdef __NEW_CHANGE_JOB
void CMover::ChangeJob(int nJob, BOOL bGamma)
{
#ifdef __WORLDSERVER
	// ¿î¿µÀÚ ¸í·ÉÀ¸·Î ·¹º§¾÷ ÇÏ´Â°÷ÀÓ
	MoverProp* pProp = GetProp();
	if (pProp)
	{
		if (nJob != JOB_PUPPETEER && nJob != JOB_GATEKEEPER && nJob != JOB_DOPPLER && nJob >= 0

#ifdef __NEWCLASS
			&& nJob < MAX_LEGEND_HERO_ULTIMATE
#else // __NEWCLASS
			&& nJob < MAX_LEGEND_HERO
#endif // __NEWCLASS

			)
		{
			AddChangeJob(nJob);
			int nLevel = 0;
			if (nJob >= JOB_MERCENARY && nJob <= JOB_MAGICIAN)
			{
				nLevel = 15;

				m_nStr = m_nSta = m_nDex = m_nInt = 15;

				{
					m_nRemainGP = 28;
				}
			}
			if (nJob >= JOB_KNIGHT && nJob <= JOB_ELEMENTOR)
			{
				nLevel = 60;

				m_nStr = m_nSta = m_nDex = m_nInt = 15;

				{
					m_nRemainGP = 118;
				}
			}
			if (nJob >= JOB_KNIGHT_MASTER && nJob <= JOB_ELEMENTOR_MASTER)
			{
				nLevel = 60;

				//m_nStr = m_nSta = m_nDex = m_nInt = 15;

				{
					m_nRemainGP += 118;
				}
			}
			if (nJob >= JOB_KNIGHT_HERO && nJob <= JOB_ELEMENTOR_HERO)
			{
				nLevel = 121;

				//m_nStr = m_nSta = m_nDex = m_nInt = 15;

				{
					m_nRemainGP += 313;
				}
			}
#ifdef __3RD_LEGEND16
			if (nJob >= JOB_LORDTEMPLER_HERO && nJob <= JOB_ELEMENTORLORD_HERO)
			{
				nLevel = 130;

				//m_nStr = m_nSta = m_nDex = m_nInt = 15;

				{
					m_nRemainGP += 340;
				}
			}
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
			if (nJob >= JOB_LORDTEMPLER_HERO_ULTIMATE && nJob <= JOB_ELEMENTORLORD_HERO_ULTIMATE)
			{
				nLevel = 200;

				//m_nStr = m_nSta = m_nDex = m_nInt = 15;

				{
					m_nRemainGP = 475;
				}
			}
#endif // __NEWCLASS
			SetHitPoint(GetMaxHitPoint());
			SetManaPoint(GetMaxManaPoint());
			SetFatiguePoint(GetMaxFatiguePoint());

			m_nLevel = nLevel;
			m_nJob = nJob;
			SetJobLevel(nLevel, nJob);
			m_nDeathLevel = nLevel;

			((CUser*)this)->AddSetChangeJob(nJob);
			if (bGamma)
			{
				m_nExp1 = 0;
			}
			g_UserMng.AddNearSetChangeJob(this, nJob, &((CUser*)this)->m_aJobSkill[MAX_JOB_SKILL]);

#if __VER >= 11 // __SYS_PLAYER_DATA
			g_dpDBClient.SendUpdatePlayerData((CUser*)this);
#else	// __SYS_PLAYER_DATA
			g_DPCoreClient.SendPartyMemberJob((CUser*)this);
			g_DPCoreClient.SendFriendChangeJob((CUser*)this);
			if (m_idGuild != 0)
				g_DPCoreClient.SendGuildChangeJobLevel((CUser*)this);
#endif	// __SYS_PLAYER_DATA

			g_UserMng.AddSetLevel(this, (WORD)m_nLevel);
			((CUser*)this)->AddSetGrowthLearningPoint(m_nRemainGP);
			((CUser*)this)->AddSetExperience(GetExp1(), (WORD)m_nLevel, m_nSkillPoint, m_nSkillLevel);
			((CUser*)this)->m_playTaskBar.InitTaskBarShorcutKind(SHORTCUT_SKILL);
			((CUser*)this)->AddTaskBar();
#ifdef __GAMEGUARD
			((CUser*)this)->AddSetState(m_nStr, m_nSta, m_nDex, m_nInt, m_nRemainGP, TRUE);
#else // __GAMEGUARD
			((CUser*)this)->AddSetState(m_nStr, m_nSta, m_nDex, m_nInt, m_nRemainGP);
#endif // __GAMEGUARD
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
			((CUser*)this)->CheckHonorStat();
			((CUser*)this)->AddHonorListAck();
			g_UserMng.AddHonorTitleChange(this, m_nHonor);
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
#ifdef __BADGE
			static_cast<CUser*>(this)->SetBadgeAddType(HI_EARN_TITLE, GetJobType(GetJob()), GetLevel());
#endif //__BADGE
#ifdef __AUTO_MAX_SKILL
			LPSKILL pSkill = NULL;
			ItemProp* pSkillProp = NULL;

			for (int i = 0; i < MAX_SKILL_JOB; i++)
			{
				pSkill = &(((CUser*)this)->m_aJobSkill[i]);

				if (pSkill == NULL || pSkill->dwSkill == 0xffffffff)
					continue;

				pSkillProp = prj.GetSkillProp(pSkill->dwSkill);

				if (pSkillProp == NULL)
					continue;

				pSkill->dwLevel = pSkillProp->dwExpertMax;
				((CUser*)this)->AddSetSkill(pSkill->dwSkill, pSkill->dwLevel);
			}
#endif // __AUTO_MAX_SKILL
		}
}
#endif // __WORLDSERVER
}
#endif // __NEW_CHANGE_JOB
int   CMover::SetLevel( int nSetLevel )
{
#ifdef __WORLDSERVER
	#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	m_nLevel = nSetLevel;
	m_nExp1 = 0;
	m_nDeathExp = GetExp1();
	m_nDeathLevel = nSetLevel - 1;
	( (CUser *)this )->AddSetExperience( GetExp1(), (WORD)m_nLevel,  m_nSkillPoint, m_nSkillLevel, m_nDeathExp, (WORD)m_nDeathLevel );		// ÇØ´çÀ¯Àú¿¡°Ô exp1,exp2º¯°æµÈ Á¤º¸¸¦ º¸³¿.
	g_UserMng.AddSetLevel( this, (WORD)m_nLevel );
	g_dpDBClient.SendLogLevelUp( this, 1 );	// ·¹º§¾÷ ·Î±×
	#endif//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#endif
	return 0; 
}

int   CMover::AddGPPoint( int nAddGPPoint )
{
#ifdef __WORLDSERVER
	#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	m_nRemainGP += nAddGPPoint;
	( (CUser*)this )->AddSetGrowthLearningPoint( m_nRemainGP );		// pUser¿¡°Ô GPº¯µ¿µÈ°ÍÀ» º¸³¿.
	g_dpDBClient.SendLogLevelUp( this, 1 );	// ·¹º§¾÷ ·Î±×
	#endif//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#endif
	return 0; 
}


BOOL CMover::InitSkillExp()
{
	for( int i = 0 ; i < MAX_SKILL_JOB ; ++i )
	{
		LPSKILL pSkill = &m_aJobSkill[ i ];
		if( pSkill != NULL && pSkill->dwSkill != NULL_ID )
		{
			ItemProp* pSkillProp = prj.GetSkillProp( pSkill->dwSkill );
			if( pSkillProp == NULL )
				return FALSE;

	#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			if( 0 < pSkill->dwLevel && pSkillProp->dwItemKind1 != JTYPE_MASTER && pSkillProp->dwItemKind1 != JTYPE_HERO )
			{
				m_nSkillPoint += (  pSkill->dwLevel * prj.GetSkillPoint( pSkillProp ) ); 
				pSkill->dwLevel = 0;
			}
	#else	//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			if( 0 < pSkill->dwLevel )
				m_nSkillPoint += (  pSkill->dwLevel * prj.GetSkillPoint( pSkillProp ) ); 
			pSkill->dwLevel = 0;
	#endif	//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		}			
	}

	#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	int nMaxPoint = 1280;	// ÃÖ´ëÀÎ JOB_ELEMENTOR ²¨·Î ¼³Á¤ÇÔ
#ifdef __NEWCLASS
	if (m_nJob == JOB_KNIGHT || m_nJob == JOB_BLADE || m_nJob == JOB_KNIGHT_MASTER || m_nJob == JOB_BLADE_MASTER || m_nJob == JOB_KNIGHT_HERO || m_nJob == JOB_BLADE_HERO || m_nJob == JOB_LORDTEMPLER_HERO || m_nJob == JOB_STORMBLADE_HERO || m_nJob == JOB_LORDTEMPLER_HERO_ULTIMATE || m_nJob == JOB_STORMBLADE_HERO_ULTIMATE)
#else // __NEWCLASS
#ifdef __3RD_LEGEND16
	if (m_nJob == JOB_KNIGHT || m_nJob == JOB_BLADE || m_nJob == JOB_KNIGHT_MASTER || m_nJob == JOB_BLADE_MASTER || m_nJob == JOB_KNIGHT_HERO || m_nJob == JOB_BLADE_HERO || m_nJob == JOB_LORDTEMPLER_HERO || m_nJob == JOB_STORMBLADE_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_KNIGHT || m_nJob == JOB_BLADE || m_nJob == JOB_KNIGHT_MASTER || m_nJob == JOB_BLADE_MASTER || m_nJob == JOB_KNIGHT_HERO || m_nJob == JOB_BLADE_HERO)
#endif // __3RD_LEGEND16
#endif // __NEWCLASS
	{
		nMaxPoint = 870;
	}
#ifdef __NEWCLASS
	else if (m_nJob == JOB_JESTER || m_nJob == JOB_RANGER || m_nJob == JOB_JESTER_MASTER || m_nJob == JOB_RANGER_MASTER || m_nJob == JOB_JESTER_HERO || m_nJob == JOB_RANGER_HERO || m_nJob == JOB_WINDLURKER_HERO || m_nJob == JOB_CRACKSHOOTER_HERO || m_nJob == JOB_WINDLURKER_HERO_ULTIMATE || m_nJob == JOB_CRACKSHOOTER_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	else if (m_nJob == JOB_JESTER || m_nJob == JOB_RANGER || m_nJob == JOB_JESTER_MASTER || m_nJob == JOB_RANGER_MASTER || m_nJob == JOB_JESTER_HERO || m_nJob == JOB_RANGER_HERO || m_nJob == JOB_WINDLURKER_HERO || m_nJob == JOB_CRACKSHOOTER_HERO)
#else // __3RD_LEGEND16
	else if (m_nJob == JOB_JESTER || m_nJob == JOB_RANGER || m_nJob == JOB_JESTER_MASTER || m_nJob == JOB_RANGER_MASTER || m_nJob == JOB_JESTER_HERO || m_nJob == JOB_RANGER_HERO)
#endif // __3RD_LEGEND16
	{
		nMaxPoint = 910;
	}
#ifdef __NEWCLASS
	else if (m_nJob == JOB_RINGMASTER || m_nJob == JOB_RINGMASTER_MASTER || m_nJob == JOB_RINGMASTER_HERO || m_nJob == JOB_FLORIST_HERO || m_nJob == JOB_FLORIST_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	else if (m_nJob == JOB_RINGMASTER || m_nJob == JOB_RINGMASTER_MASTER || m_nJob == JOB_RINGMASTER_HERO || m_nJob == JOB_FLORIST_HERO)
#else // __3RD_LEGEND16
	else if (m_nJob == JOB_RINGMASTER || m_nJob == JOB_RINGMASTER_MASTER || m_nJob == JOB_RINGMASTER_HERO)
#endif // __3RD_LEGEND16
	{
		nMaxPoint = 902;
	}
#ifdef __NEWCLASS
	else if (m_nJob == JOB_BILLPOSTER || m_nJob == JOB_PSYCHIKEEPER || m_nJob == JOB_BILLPOSTER_MASTER || m_nJob == JOB_PSYCHIKEEPER_MASTER || m_nJob == JOB_BILLPOSTER_HERO || m_nJob == JOB_PSYCHIKEEPER_HERO || m_nJob == JOB_FORCEMASTER_HERO || m_nJob == JOB_MENTALIST_HERO || m_nJob == JOB_FORCEMASTER_HERO_ULTIMATE || m_nJob == JOB_MENTALIST_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	else if (m_nJob == JOB_BILLPOSTER || m_nJob == JOB_PSYCHIKEEPER || m_nJob == JOB_BILLPOSTER_MASTER || m_nJob == JOB_PSYCHIKEEPER_MASTER || m_nJob == JOB_BILLPOSTER_HERO || m_nJob == JOB_PSYCHIKEEPER_HERO || m_nJob == JOB_FORCEMASTER_HERO || m_nJob == JOB_MENTALIST_HERO)
#else // __3RD_LEGEND16
	else if (m_nJob == JOB_BILLPOSTER || m_nJob == JOB_PSYCHIKEEPER || m_nJob == JOB_BILLPOSTER_MASTER || m_nJob == JOB_PSYCHIKEEPER_MASTER || m_nJob == JOB_BILLPOSTER_HERO || m_nJob == JOB_PSYCHIKEEPER_HERO)
#endif // __3RD_LEGEND16
	{
		nMaxPoint = 950;
	}

	if( m_nSkillPoint > nMaxPoint)
		m_nSkillPoint = nMaxPoint;
	#endif	//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

#ifdef __WORLDSERVER
	( (CUser*)this )->m_playTaskBar.InitTaskBarShorcutKind( SHORTCUT_SKILL );
	( (CUser*)this )->AddTaskBar();
#endif //__WORLDSERVER
	return TRUE;
}

#ifdef __CLIENT
int CMover::GetCurrentMaxSkillPoint()
{
	int nCurrentMaxSkillPoint = m_nSkillPoint;
	for( int i = 0 ; i < MAX_SKILL_JOB ; ++i )
	{
		LPSKILL pSkill = &m_aJobSkill[ i ];
		if( pSkill != NULL && pSkill->dwSkill != NULL_ID )
		{
			ItemProp* pSkillProp = prj.GetSkillProp( pSkill->dwSkill );
			if( pSkillProp != NULL )
			{
				if( 0 < pSkill->dwLevel && pSkillProp->dwItemKind1 != JTYPE_MASTER && pSkillProp->dwItemKind1 != JTYPE_HERO )
					nCurrentMaxSkillPoint += (  pSkill->dwLevel * prj.GetSkillPoint( pSkillProp ) );
			}
		}			
	}

	int nMaxPoint = 1280;	// ÃÖ´ëÀÎ JOB_ELEMENTOR ²¨·Î ¼³Á¤ÇÔ
#ifdef __NEWCLASS
	if (m_nJob == JOB_KNIGHT || m_nJob == JOB_BLADE || m_nJob == JOB_KNIGHT_MASTER || m_nJob == JOB_BLADE_MASTER || m_nJob == JOB_KNIGHT_HERO || m_nJob == JOB_BLADE_HERO || m_nJob == JOB_LORDTEMPLER_HERO || m_nJob == JOB_STORMBLADE_HERO || m_nJob == JOB_LORDTEMPLER_HERO_ULTIMATE || m_nJob == JOB_STORMBLADE_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_KNIGHT || m_nJob == JOB_BLADE || m_nJob == JOB_KNIGHT_MASTER || m_nJob == JOB_BLADE_MASTER || m_nJob == JOB_KNIGHT_HERO || m_nJob == JOB_BLADE_HERO || m_nJob == JOB_LORDTEMPLER_HERO || m_nJob == JOB_STORMBLADE_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_KNIGHT || m_nJob == JOB_BLADE || m_nJob == JOB_KNIGHT_MASTER || m_nJob == JOB_BLADE_MASTER || m_nJob == JOB_KNIGHT_HERO || m_nJob == JOB_BLADE_HERO)
#endif // __3RD_LEGEND16
	{
		nMaxPoint = 870;
	}
#ifdef __NEWCLASS
	else if (m_nJob == JOB_JESTER || m_nJob == JOB_RANGER || m_nJob == JOB_JESTER_MASTER || m_nJob == JOB_RANGER_MASTER || m_nJob == JOB_JESTER_HERO || m_nJob == JOB_RANGER_HERO || m_nJob == JOB_WINDLURKER_HERO || m_nJob == JOB_CRACKSHOOTER_HERO || m_nJob == JOB_WINDLURKER_HERO_ULTIMATE || m_nJob == JOB_CRACKSHOOTER_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	else if (m_nJob == JOB_JESTER || m_nJob == JOB_RANGER || m_nJob == JOB_JESTER_MASTER || m_nJob == JOB_RANGER_MASTER || m_nJob == JOB_JESTER_HERO || m_nJob == JOB_RANGER_HERO || m_nJob == JOB_WINDLURKER_HERO || m_nJob == JOB_CRACKSHOOTER_HERO)
#else // __3RD_LEGEND16
	else if (m_nJob == JOB_JESTER || m_nJob == JOB_RANGER || m_nJob == JOB_JESTER_MASTER || m_nJob == JOB_RANGER_MASTER || m_nJob == JOB_JESTER_HERO || m_nJob == JOB_RANGER_HERO)
#endif // __3RD_LEGEND16
	{
		nMaxPoint = 910;
	}
#ifdef __NEWCLASS
	else if (m_nJob == JOB_RINGMASTER || m_nJob == JOB_RINGMASTER_MASTER || m_nJob == JOB_RINGMASTER_HERO || m_nJob == JOB_FLORIST_HERO || m_nJob == JOB_FLORIST_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	else if (m_nJob == JOB_RINGMASTER || m_nJob == JOB_RINGMASTER_MASTER || m_nJob == JOB_RINGMASTER_HERO || m_nJob == JOB_FLORIST_HERO)
#else // __3RD_LEGEND16
	else if (m_nJob == JOB_RINGMASTER || m_nJob == JOB_RINGMASTER_MASTER || m_nJob == JOB_RINGMASTER_HERO)
#endif // __3RD_LEGEND16
	{
		nMaxPoint = 902;
	}
#ifdef __NEWCLASS
	else if (m_nJob == JOB_BILLPOSTER || m_nJob == JOB_PSYCHIKEEPER || m_nJob == JOB_BILLPOSTER_MASTER || m_nJob == JOB_PSYCHIKEEPER_MASTER || m_nJob == JOB_BILLPOSTER_HERO || m_nJob == JOB_PSYCHIKEEPER_HERO || m_nJob == JOB_FORCEMASTER_HERO || m_nJob == JOB_MENTALIST_HERO || m_nJob == JOB_FORCEMASTER_HERO_ULTIMATE || m_nJob == JOB_MENTALIST_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	else if (m_nJob == JOB_BILLPOSTER || m_nJob == JOB_PSYCHIKEEPER || m_nJob == JOB_BILLPOSTER_MASTER || m_nJob == JOB_PSYCHIKEEPER_MASTER || m_nJob == JOB_BILLPOSTER_HERO || m_nJob == JOB_PSYCHIKEEPER_HERO || m_nJob == JOB_FORCEMASTER_HERO || m_nJob == JOB_MENTALIST_HERO)
#else // __3RD_LEGEND16
	else if (m_nJob == JOB_BILLPOSTER || m_nJob == JOB_PSYCHIKEEPER || m_nJob == JOB_BILLPOSTER_MASTER || m_nJob == JOB_PSYCHIKEEPER_MASTER || m_nJob == JOB_BILLPOSTER_HERO || m_nJob == JOB_PSYCHIKEEPER_HERO)
#endif // __3RD_LEGEND16
	{
		nMaxPoint = 950;
	}

	if( nCurrentMaxSkillPoint > nMaxPoint)
		nCurrentMaxSkillPoint = nMaxPoint;

	return nCurrentMaxSkillPoint;
}

#if __VER >= 15 // __PETVIS
//¹öÇÁÆê ÀÌÆåÆ® 
void CMover::SetSfxBuffPet( const DWORD idEffect )
{
	if( m_pSfxBuffPet )
	{
		g_WorldMng.Get()->RemoveObj( m_pSfxBuffPet );
		m_pSfxBuffPet = NULL;
	}

	if( NULL_ID != idEffect )
		m_pSfxBuffPet =  CreateSfx( g_Neuz.m_pd3dDevice, idEffect, GetPos(), GetId(), GetPos(), GetId(), -1 );
}
#endif //__PETVIS

#endif //__CLIENT
void CMover::ReState()
{
#ifdef __WORLDSERVER
#ifdef __GAMEGUARD
	int nAdd = 0;

	nAdd += (m_nStr - 50);
	m_nStr = 50;

	nAdd += (m_nSta - 50);
	m_nSta = 50;

	nAdd += (m_nDex - 50);
	m_nDex = 50;

	nAdd += (m_nInt - 50);
	m_nInt = 50;

	m_nRemainGP = (m_nCampusPoint * 100) + 550;

	SetHitPoint(GetMaxHitPoint());
	SetManaPoint(GetMaxManaPoint());
	SetFatiguePoint(GetMaxFatiguePoint());
#ifdef __GAMEGUARD
	((CUser*)this)->AddSetState(m_nStr, m_nSta, m_nDex, m_nInt, m_nRemainGP, TRUE);
#else // __GAMEGUARD
	((CUser*)this)->AddSetState(m_nStr, m_nSta, m_nDex, m_nInt, m_nRemainGP);
#endif // __GAMEGUARD

#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
	((CUser*)this)->CheckHonorStat();
	((CUser*)this)->AddHonorListAck();
	g_UserMng.AddHonorTitleChange(this, m_nHonor);
#endif	// __HONORABLE_TITLE
#else // __GAMEGUARD
	m_nStr = m_nSta = m_nDex = m_nInt = 15;
	m_nRemainGP = 0;

	int nLevelFor = m_nLevel;
	if (m_nLevel < m_nDeathLevel)
		nLevelFor = m_nDeathLevel;
#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	for (int i = 1; i < nLevelFor; i++)
	{
		m_nRemainGP += prj.m_aExpCharacter[i + 1].dwLPPoint;
		if ((IsMaster() || IsHero()) && i > 59)
			m_nRemainGP++;

		if (IsHero() && i == MAX_GENERAL_LEVEL)
		{
			m_nRemainGP += 12;
		}
	}
#else // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	for (int i = 1; i < nLevelFor; i++)
		m_nRemainGP += prj.m_aExpCharacter[i + 1].dwLPPoint;
#endif	// __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

	SetHitPoint(GetMaxHitPoint());
	SetManaPoint(GetMaxManaPoint());
	SetFatiguePoint(GetMaxFatiguePoint());
#ifdef __GAMEGUARD
	((CUser*)this)->AddSetState(m_nStr, m_nSta, m_nDex, m_nInt, m_nRemainGP, TRUE);
#else // __GAMEGUARD
	((CUser*)this)->AddSetState(m_nStr, m_nSta, m_nDex, m_nInt, m_nRemainGP);
#endif // __GAMEGUARD

#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
	((CUser*)this)->CheckHonorStat();
	((CUser*)this)->AddHonorListAck();
	g_UserMng.AddHonorTitleChange(this, m_nHonor);
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
#endif // __GAMEGUARD
#endif // __WORLDSERVER
}

#ifdef __S_ADD_RESTATE
void CMover::ReStateOne( int nKind )
{
#ifdef __WORLDSERVER
	int nAdd = 0;
	switch( nKind )
	{
	case 0:		// Str
		{
			nAdd = m_nStr - 15;
			m_nStr = 15;
		}
		break;
	case 1:		// Sta
		{
			nAdd = m_nSta - 15;
			m_nSta = 15;
		}
		break;
	case 2:		// Dex
		{
			nAdd = m_nDex - 15;
			m_nDex = 15;
		}
		break;
	case 3:		// Int
		{
			nAdd = m_nInt - 15;
			m_nInt = 15;
		}
		break;
	}
	m_nRemainGP += nAdd;

	SetHitPoint( GetMaxHitPoint() );
	SetManaPoint( GetMaxManaPoint() );
	SetFatiguePoint( GetMaxFatiguePoint() );
#ifdef __GAMEGUARD
	((CUser*)this)->AddSetState(m_nStr, m_nSta, m_nDex, m_nInt, m_nRemainGP, TRUE);
#else // __GAMEGUARD
	((CUser*)this)->AddSetState(m_nStr, m_nSta, m_nDex, m_nInt, m_nRemainGP);
#endif // __GAMEGUARD
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
	((CUser*)this)->CheckHonorStat();
	((CUser*)this)->AddHonorListAck();
	g_UserMng.AddHonorTitleChange( this, m_nHonor);
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
#endif // __WORLDSERVER
}
#endif // __S_ADD_RESTATE

#ifdef __ADD_RESTATE_LOW
void CMover::ReStateOneLow( int nKind )
{
#ifdef __WORLDSERVER
	int nAdd = 0;
	switch( nKind )
	{
	case 0:		// Str
		{
			if( m_nStr >= RESTATE_LOW + 15 )
			{
				nAdd = RESTATE_LOW;
				m_nStr -= RESTATE_LOW;
			}
			else
			{
				nAdd = m_nStr - 15;
				m_nStr = 15;
			}
		}
		break;
	case 1:		// Sta
		{
			if( m_nSta >= RESTATE_LOW + 15 )
			{
				nAdd = RESTATE_LOW;
				m_nSta -= RESTATE_LOW;
			}
			else
			{
				nAdd = m_nSta - 15;
				m_nSta = 15;
			}
		}
		break;
	case 2:		// Dex
		{
			if( m_nDex >= RESTATE_LOW + 15 )
			{
				nAdd = RESTATE_LOW;
				m_nDex -= RESTATE_LOW;
			}
			else
			{
				nAdd = m_nDex - 15;
				m_nDex = 15;
			}
		}
		break;
	case 3:		// Int
		{
			if( m_nInt >= RESTATE_LOW + 15 )
			{
				nAdd = RESTATE_LOW;
				m_nInt -= RESTATE_LOW;
			}
			else
			{
				nAdd = m_nInt - 15;
				m_nInt = 15;
			}
		}
		break;
	}
	m_nRemainGP += nAdd;

	SetHitPoint( GetMaxHitPoint() );
	SetManaPoint( GetMaxManaPoint() );
	SetFatiguePoint( GetMaxFatiguePoint() );
#ifdef __GAMEGUARD
	((CUser*)this)->AddSetState(m_nStr, m_nSta, m_nDex, m_nInt, m_nRemainGP, TRUE);
#else // __GAMEGUARD
	((CUser*)this)->AddSetState(m_nStr, m_nSta, m_nDex, m_nInt, m_nRemainGP);
#endif // __GAMEGUARD
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
	((CUser*)this)->CheckHonorStat();
	((CUser*)this)->AddHonorListAck();
	g_UserMng.AddHonorTitleChange( this, m_nHonor);
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
#endif // __WORLDSERVER
}
#endif // __ADD_RESTATE_LOW

#ifdef __WORLDSERVER

BOOL CMover::ReplaceInspection( REGIONELEM* pPortkey )
{
	BOOL bResult = TRUE;
	if( bResult != FALSE && pPortkey->m_uItemId != 0xffffffff )
	{
		int nCount = GetItemNum( pPortkey->m_uItemId );
		if( (DWORD)( nCount ) <= pPortkey->m_uiItemCount )
		{
			bResult = TRUE;
		}
		else
		{
			bResult = FALSE;
		}

		TRACE( "ReplaceInspection Item %d Count %d/%d Inspection %d \n", pPortkey->m_uItemId, nCount, pPortkey->m_uiItemCount, bResult );
	}
	if( bResult != FALSE && pPortkey->m_uiMinLevel != 0xffffffff )
	{
		if( pPortkey->m_uiMinLevel <= (UINT)( m_nLevel ) && (UINT)( m_nLevel ) <= pPortkey->m_uiMaxLevel)
		{
			bResult = TRUE;
		}
		else
		{
			bResult = FALSE;
		}

		TRACE( "ReplaceInspection Level (%d~%d) %d Inspection %d \n", pPortkey->m_uiMinLevel, pPortkey->m_uiMaxLevel, m_nLevel, bResult );
	}
	if( bResult != FALSE && pPortkey->m_iQuest != 0xffffffff )
	{
		LPQUEST pCurQuest = GetQuest( pPortkey->m_iQuest );
		if( pCurQuest && ( pPortkey->m_iQuestFlag == 0 || pPortkey->m_iQuestFlag == pCurQuest->m_nState ) )
			bResult = TRUE;
		else
			bResult = FALSE;
		TRACE( "ReplaceInspection Quest %d Flag %d/%d Inspection %d \n", pPortkey->m_iQuest, pPortkey->m_iQuestFlag, pCurQuest->m_nState, bResult );
	}
	if( bResult != FALSE && pPortkey->m_iJob != 0xffffffff )
	{
		if( pPortkey->m_iJob == m_nJob )
			bResult = TRUE;
		else
			bResult = FALSE;
		TRACE( "ReplaceInspection Job %d/%d Inspection %d \n", pPortkey->m_iJob, m_nJob, bResult );
	}
	if( bResult != FALSE && pPortkey->m_iGender != 0xffffffff )
	{
		if( pPortkey->m_iGender == GetSex() )
			bResult = TRUE;
		else
			bResult = FALSE;
		TRACE( "ReplaceInspection Gender %d/%d Inspection %d \n", pPortkey->m_iGender, GetSex(), bResult );
	}
	if( bResult != FALSE && pPortkey->m_bCheckParty != FALSE )
	{
		CParty* pParty	= g_PartyMng.GetParty( m_idparty );
		if( pParty != NULL && pParty->IsMember( m_idPlayer ) )
			bResult = TRUE;
		else 
			bResult = FALSE;
		TRACE( "ReplaceInspection Party Inspection %d \n", bResult );
	}
	if( bResult != FALSE && pPortkey->m_bCheckGuild != FALSE )
	{
		CGuild* pGuild	= g_GuildMng.GetGuild( m_idGuild );
		if( pGuild && pGuild->IsMember( m_idPlayer ) )
			bResult = TRUE;
		else
			bResult = FALSE;
		TRACE( "ReplaceInspection Guild Inspection %d \n", bResult );
	}	
#if __VER < 14 // __INSTANCE_DUNGEON	// »óÀ§ ÇÔ¼öÀÎ ProcessRegion()¿¡¼­ Ã³¸®
	if( bResult != FALSE && IsFly() )
	{
		bResult = FALSE;
	}
#endif // __INSTANCE_DUNGEON

	return bResult;
}

// default type =  REPLACE_NORMAL
BOOL CMover::Replace(u_long uIdofMulti, DWORD dwWorldID, D3DXVECTOR3& vPos, REPLACE_TYPE type, int nLayer, BOOL bTeleportImage)
{
	CWorld* pWorld	= GetWorld();
	if( !pWorld )
		return FALSE;
	if( dwWorldID == 0 || dwWorldID == NULL_ID )
		return FALSE;

#ifdef __LAYER_1015
	CWorld* pTargetWorld	= g_WorldMng.GetWorld( dwWorldID );
	if( !pTargetWorld || !pTargetWorld->m_linkMap.GetLinkMap( nLayer ) )
	{
		Error( "Layer not found" );
		return FALSE;
	}
#endif	// __LAYER_1015

	// Á¶°Ç°Ë»ç 
	if( type == REPLACE_NORMAL )
	{
		if( IsAuthHigher( AUTH_GAMEMASTER ) == FALSE && IsFly() ) 
			return FALSE;
	}

	// ÀÌµ¿À» ¸ØÃá´Ù.
	ClearDest();
	SendActMsg( OBJMSG_ACC_STOP );
	SendActMsg( OBJMSG_STOP_TURN );
	SendActMsg( OBJMSG_STAND );

#if __VER >= 11 // __SYS_COLLECTING
	if( IsCollecting() )
		StopCollecting();
#endif	// __SYS_COLLECTING

#if __VER >= 15 // __REACTIVATE_EATPET
	if (HasActivatedEatPet())
	{
		/*#ifdef __GAMEGUARD
				CMover* pEatPet = prj.GetMover( GetEatPetId() );
				if( IsValidObj( pEatPet ))
				{
					if( !IsValidArea( pEatPet, 32 ))
					{
						pEatPet->SetPos( this->GetPos() );
						g_UserMng.AddSetPos( pEatPet, this->GetPos() );
					}
				}
		#else // __GAMEGUARD*/
		InactivateEatPet();
		//#endif // __GAMEGUARD
	}
#ifdef __GAMEGUARD
	if (HasActivatedSystemPet())
		PetRelease();
	if (HasPet())
		RemovePet();
#endif // __GAMEGUARD
#endif // __REACTIVATE_EATPET

	LPREPLACEOBJ lpReplaceObj	= NULL;

	for( int i = 0; i < pWorld->m_cbModifyLink; i++ )
	{
		if( pWorld->m_apModifyLink[i] == this )
		{
			pWorld->m_apModifyLink[i]	= NULL;
			m_vRemoval	= D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
			break;
		}
	}

	for( int i = 0; i < pWorld->m_cbReplaceObj; i++ )
	{
		if( pWorld->m_aReplaceObj[i].pObj == this )
		{
			lpReplaceObj = &pWorld->m_aReplaceObj[i];
			break;
		}
	}
	if( lpReplaceObj == NULL )
	{
		ASSERT( pWorld->m_cbReplaceObj < MAX_REPLACEOBJ );
		lpReplaceObj = &pWorld->m_aReplaceObj[pWorld->m_cbReplaceObj++];
		lpReplaceObj->pObj	= this;
	}

	lpReplaceObj->dwWorldID	 = dwWorldID;
	lpReplaceObj->vPos       = vPos;
	lpReplaceObj->uIdofMulti = uIdofMulti;
#ifdef __LAYER_1015
	lpReplaceObj->nLayer	= nLayer;
#endif	// __LAYER_1015
#ifdef __AEGON_FIXES
	lpReplaceObj->bTeleportImage = bTeleportImage;
#endif
#if __VER >= 14 // __INSTANCE_DUNGEON
	if( IsPlayer() )
	{
		if( CInstanceDungeonHelper::GetInstance()->IsInstanceDungeon( pWorld->GetID() )
			&& !CInstanceDungeonHelper::GetInstance()->IsInstanceDungeon( dwWorldID ) )
			//ÀÔÀå ÀÎ¿ø¼ö¸¦ °¨¼Ò½ÃÅ²´Ù.
			CInstanceDungeonHelper::GetInstance()->LeaveDungeon( static_cast<CUser*>( this ), pWorld->GetID() );
	}
#endif // __INSTANCE_DUNGEON
#ifdef __PARTY_LOCATION
	if (IsPlayer())
	{
		g_dpDBClient.SendUpdatePlayerData((CUser*)this, dwWorldID);
		CParty* party = g_PartyMng.GetParty(this->m_idparty);
		if (party) {
			for (int i = 0; i < party->GetSizeofMember(); i++) {
				auto member = prj.GetUserByID(g_Party.m_aMember[i].m_uPlayerId);
				if (member) {
					((CUser*)member)->AddPlayerData();
				}
			}
		}
	}
#endif //__PARTY_LOCATION
	return TRUE;
}

#if defined  (__FL_FARM_STAT) || defined (__DROP_LOG)
BOOL CMover::CreateItem(CItemBase* pItemBase, BYTE* pnId, short* pnNum, BYTE nCount, BOOL bAdd)
#else
BOOL CMover::CreateItem(CItemBase* pItemBase, BYTE* pnId, short* pnNum, BYTE nCount)
#endif
{
	if( pItemBase->m_dwItemId == 0 )
		return FALSE;
	CItemElem* pItemElem = (CItemElem*)pItemBase;
	if( pItemElem->m_nHitPoint == -1 )
	{
		ItemProp* pItemProp		= pItemElem->GetProp();
		if( pItemProp )
			pItemElem->m_nHitPoint		= pItemProp->dwEndurance;
		else
			pItemElem->m_nHitPoint		= 0;
	}
	if( pItemBase->GetSerialNumber() == 0 )
		pItemBase->SetSerialNumber();
	BOOL fSuccess;

	if( nCount == 0 )
	{
		BYTE anId[MAX_INVENTORY];
		short anNum[MAX_INVENTORY];
		
		fSuccess	= m_Inventory.Add( (CItemElem*)pItemBase, anId, anNum, &nCount );

		if( fSuccess && IsPlayer() )
		{
			( (CUser*)this )->AddCreateItem( pItemBase, anId, anNum, nCount );
		}
		if( pnId != NULL )
			memcpy( pnId, anId, sizeof(BYTE) * nCount );
		if( pnNum != NULL )
			memcpy( pnNum, anNum, sizeof(short) * nCount );
	}
	else
	{
		CItemElem* pItemElem	= (CItemElem*)pItemBase;
		CItemElem itemElem;
		itemElem	= *pItemElem;
		for( int i = 0; i < nCount; i++ )
		{
			itemElem.m_nItemNum		= pnNum[i];
			m_Inventory.SetAtId( pnId[i], &itemElem );
		}
		if( IsPlayer() )
			( (CUser*)this )->AddCreateItem( pItemBase, pnId, pnNum, nCount );
		fSuccess	= TRUE;
	}
	return fSuccess;
}

void CMover::RemoveItem( BYTE nId, short nNum )
{
	CItemBase* pItemBase = GetItemId(nId);
#ifdef __GAMEGUARD
	if (pItemBase && nNum > 0 && nNum <= 9999)
#else // __GAMEGUARD
	if (pItemBase)
#endif // __GAMEGUARD
	{
#ifdef __GAMEGUARD
		short nItemNum = ((CItemElem*)pItemBase)->m_nItemNum;
		short nCheck = nItemNum - nNum;
		if (nCheck < 0)
			nCheck = 0;

		UpdateItem(nId, UI_NUM, nCheck);
#else // __GAMEGUARD
		UpdateItem(nId, UI_NUM, ((CItemElem*)pItemBase)->m_nItemNum - nNum);
#endif // __GAMEGUARD
	}
}

// IK3·Î »èÁ¦ÇÏ±â ¿¹) IK3_CLOAK
void CMover::RemoveItemIK3( DWORD dwItemKind3 )
{
	int	nSize = m_Inventory.GetMax();
	for( int i = 0 ; i < nSize; i++ )
	{
		CItemElem* pItemElem = m_Inventory.GetAtId( i );
		if( IsUsableItem( pItemElem ) && pItemElem->GetProp()->dwItemKind3 == dwItemKind3 )
		{
			if( pItemElem->GetProp()->dwItemKind3 == IK3_CLOAK && pItemElem->m_idGuild == 0 )
				continue;

			if( m_Inventory.IsEquip( pItemElem->m_dwObjId ) )		
			{
				if( DoEquip( pItemElem, FALSE ) )
				{
					g_UserMng.AddDoEquip( this, -1, pItemElem, FALSE );
					UpdateItem( i, UI_NUM, 0 );		// remove
				}
				else
				{
					// ÀÎº¥ fullÀÌ°í, ÀåÂø»óÅÂÀÌ¸é Á¦°ÅÇÒ ¼ö ¾ø´Ù. 
					// WriteError( "RemoveItemIK3->DoEquip : %s %d, User = %s, Item = %d %d %d", 
					// __FILE__, __LINE__, GetName(), pItemElem->m_dwObjId, pItemElem->GetProp()->dwItemKind3, dwItemKind3 );
				}
			}
			else
			{
				UpdateItem( i, UI_NUM, 0 );		// remove
			}
		}
	}
}

void CMover::RemoveVendorItem( CHAR chTab, BYTE nId, short nNum )
{
#ifdef __GAMEGUARD
	if (chTab < 0)
		return;
#endif // __GAMEGUARD
	short num;
	CItemElem* pItemElem = m_ShopInventory[chTab]->GetAtId( nId );

	if( pItemElem ) 
	{
		if( ( num = pItemElem->m_nItemNum - nNum ) > 0 )
			pItemElem->m_nItemNum	= num;
		else
			m_ShopInventory[chTab]->RemoveAtId( nId );
		g_UserMng.AddUpdateVendor( this, chTab, nId, num );
	}
}
#endif	// __WORLDSERVER

void CMover::UpdateItemBank( int nSlot, BYTE nId, CHAR cParam, DWORD dwValue )
{
	CItemBase* pItemBase = GetItemBankId( nSlot, nId );
	
	if( pItemBase )
	{
		switch( cParam )
		{
		case UI_NUM:
			{
				if( dwValue == 0 ) 
				{
					RemoveItemBankId( nSlot, nId );
				}
				else
				{
					( (CItemElem*)pItemBase )->m_nItemNum	= (short)( dwValue );
				}
				break;
			}
		default:
			break;
		}
	}
#ifdef __WORLDSERVER
	if( IsPlayer() )
		( (CUser*)this )->AddUpdateBankItem( nSlot, nId, cParam, dwValue );
#endif
}

#ifdef __WORLDSERVER
// ÀÎº¥Åä¸®³»¿¡¼­ 1°³ ¾ÆÀÌÅÛÀ» ¶³¾îÆ®¸°´Ù.
int	CMover::DoDropItemRandom( BOOL bExcludeEquip, CMover* pAttacker, BOOL bOnlyEquip )
{
	int i, nMax, nRealMax, nDropCnt;
	CItemElem* pItemElem;
	CItemElem *pElemBuff[ MAX_INVENTORY + MAX_EQUIPMENT ] = { NULL, };

	nRealMax = nDropCnt = 0;

	nMax = m_Inventory.GetMax();
	for( i = 0; i < nMax; ++i ) 		// ÀÎº¥ °¹¼ö¸¸Å­ µ¹¸é¼­ ¾ÆÀÌÅÛÀÌ ÀÖ´ÂÄ­¸¸ Æ÷ÀÎÅÍ¸¦ »Ì¾Æ³õ´Â´Ù.
	{
		pItemElem = m_Inventory.GetAtId( i );
		if( pItemElem == NULL )
			continue;
			
		if( pItemElem->IsQuest() )					// Äù½ºÆ® ¾ÆÀÌÅÛ Á¦¿Ü 
			continue;

		if( pItemElem->IsCharged() )	// À¯·á »óÇ°¾ÆÀÌÅÛ Á¦¿Ü
			continue;

#if __VER >= 8 // __S8_PK
		if( pItemElem->IsEatPet()
#if __VER >= 9	// __PET_0410
			|| IsUsing( pItemElem )
#endif	// __PET_0410
			)
			continue;
#else // __VER >= 8 // __S8_PK
		if( HasActivatedEatPet() && pItemElem->IsEatPet() )
			continue;
#endif // __VER >= 8 // __S8_PK

		if( pItemElem->IsBinds() )
			continue;

		if( bOnlyEquip )
		{
			if( m_Inventory.IsEquip( pItemElem->m_dwObjId ) )		// ÀåÂøµÈ ¾ÆÀÌÅÛ Á¦¿Ü  
				pElemBuff[ nRealMax++ ] = pItemElem;
		}
		else
		{
			if( bExcludeEquip && m_Inventory.IsEquip( pItemElem->m_dwObjId ) )		// ÀåÂøµÈ ¾ÆÀÌÅÛ Á¦¿Ü  
				continue;
			
			pElemBuff[ nRealMax++ ] = pItemElem;
		}
	}

	while( nRealMax )	// °Ë»ö´ë»ó ¾ÆÀÌÅÛÀÌ ´õÀÌ»ó ¾øÀ»°æ¿ì ³¡.
	{
		int nIdx = xRandom( nRealMax );
		pItemElem = pElemBuff[ nIdx ];		// ¾ÆÀÌÅÛ ¸®½ºÆ®¿¡¼­ ·£´ýÀ¸·Î ÇÏ³ª¸¦ »Ì¾Æ¿È

		int nPartBuf = -1;
#if __VER >= 8 // __S8_PK
		CItemElem* pItemElemLWepon = m_Inventory.GetEquip( PARTS_LWEAPON );
		CItemElem* pItemElemRWepon = m_Inventory.GetEquip( PARTS_RWEAPON );
		if( pItemElem == pItemElemLWepon )
			nPartBuf = PARTS_LWEAPON;
		else if( pItemElem == pItemElemRWepon )
			nPartBuf = PARTS_RWEAPON; 
#endif // __VER >= 8 // __S8_PK			
		if( m_Inventory.IsEquip( pItemElem->m_dwObjId ) )	// ÀåÂøÇÏ°í ÀÖÀ¸¸é ¹þ±è 			
		{
			if( DoEquip( pItemElem, FALSE, nPartBuf ) )
				g_UserMng.AddDoEquip( this, nPartBuf, pItemElem, FALSE );
		}

		CItem* pItem = DropItem( pItemElem->m_dwObjId, 0, GetPos(), TRUE );
		if( pItem )	
		{
			UNUSED_ALWAYS( pAttacker );
			return 1;
		}

		// drop¿¡ ½ÇÆÐÇÑ ¾ÆÀÌÅÛÀÌ¶óµµ ¸®½ºÆ®¿¡¼­ »©ÁÖÀÚ.
		for( int j = nIdx; j < nRealMax-1; j ++ )		// ¾ÕÀ¸·Î ÇÑÄ­¾¿ ¶¯±è.
			pElemBuff[j] = pElemBuff[j+1];
		nRealMax --;	// ÇÏ³ª¸¦ ¶³¾îÆ®·ÈÀ¸´Ï ¹öÆÛÀÇ Å©±â¸¦ ÇÏ³ª ÁÙÀÓ
	}		

	return 0;
}
#endif // __WORLDSERVER

CItem *CMover::_DropItemNPC( DWORD dwItemType, DWORD dwID, short nDropNum, const D3DXVECTOR3 &vPos )
{
#ifdef __WORLDSERVER
	if( IsInvalidObj(this) )	
		return NULL;

	CWorld *pWorld = GetWorld();
	if( pWorld == NULL )	
		return NULL;	
	CItemBase* pItemBase = GetItemId( dwID );
	if( NULL == pItemBase )		
		return NULL;
	
	short nNum	= 1;
	nNum = ((CItemElem*)pItemBase)->m_nItemNum;
	if( m_Inventory.IsEquip( pItemBase->m_dwObjId ) ) 
		return NULL;

	if( nDropNum == 0 )
		nDropNum = nNum;
	else if( nNum - (int)nDropNum < 0 )
		return NULL;
	
	CItem* pItem	                             = new CItem;
	pItem->m_pItemBase	                         = new CItemElem;
	*((CItemElem*)pItem->m_pItemBase)            = *((CItemElem*)pItemBase);
	((CItemElem*)pItem->m_pItemBase)->m_nItemNum = nDropNum;
		
	if( pItemBase->m_dwItemId == 0 ) 
		Error( "_DropItemNPC SetIndex: %s \n", GetName() ); 

	pItem->SetIndex( D3DDEVICE, pItemBase->m_dwItemId );
	if( pItem->m_pModel )
	{
		D3DXVECTOR3 v = vPos;
		v.y += ( pItem->m_pModel->m_vMax.y - pItem->m_pModel->m_vMin.y ) / 2.0f;
		pItem->SetPos( v );
		pItem->SetAngle( (float)( xRandom( 360 ) ) );
		pItem->m_dwDropTime = timeGetTime();	// ¶³¾îÆ®·ÈÀ»¶§ÀÇ ½Ã°£.
		pWorld->ADDOBJ( (CObj*)pItem, TRUE, GetLayer() );
		RemoveItem( (BYTE)( dwID ), nDropNum );
		return pItem;
	}
	else
	{
		SAFE_DELETE( pItem );
	}
#endif // WORLDSERVER
	return NULL;
}

// ¾ÆÀÌÅÛÀ» ¶³±¼ ¼ö ÀÖ´Â°¡? PK - PK¸¦ ´çÇÑ °æ¿ì´Â TRUE
BOOL CMover::IsDropableState( BOOL bPK )
{
	if( IsInvalidObj(this) )	
		return FALSE;

#ifdef __WORLDSERVER
	CWorld *pWorld = GetWorld();
	if( pWorld == NULL )	
		return FALSE;

	if( m_pActMover->m_bGround == 0 || m_pActMover->IsFly() )	// ³¯°íÀÖ´Â ÁßÀÌ°Å³ª °øÁß¿¡ ¶°ÀÖ´Â»óÅÂ¿¡¼± ÀÏ´Ü ¸ø¶³¾îÆ®¸®°Ô ÇÏÀÚ.
	{
		if( bPK == FALSE ) //  PK´çÇÑ °æ¿ì°¡ ¾Æ´Ò°æ¿ì¸¸ ¶³±º´Ù.
		{
			((CUser*)this)->AddDefinedText( TID_GAME_FLIGHTDROP, "" );
			return FALSE;
		}
	}

	if( m_vtInfo.GetOtherID() != NULL_ID )		// Æ®·¹ÀÌµåÁßÀÏ¶© ÀÏ´Ü ¸ø¶³¾îÆ®¸®°Ô ÇÏÀÚ
	{
		((CUser*)this)->AddDefinedText( TID_GAME_TRADELIMITITEM, "" );
		return FALSE;
	}

	if( m_vtInfo.VendorIsVendor() )
		return FALSE;

	if( IsMode( ITEM_MODE ) )
		return FALSE;

#endif // __WORLDSERVER
	return TRUE;
}	


// ÀÎº¥ÀÇ ¾ÆÀÌÅÛÀ» ¹Ù´Ú¿¡ ³»·Á³õÀ»¶§ »ç¿ëÇÑ´Ù.
// dwType, dwIDÀÇ ¾ÆÀÌÅÛÀ» vPos¿¡ ¶³¾îÆ®¸°´Ù.
// bPK == YES¸é ÇÃ·¹ÀÌ¾î°¡ PK´çÇØ¼­ ¶³¾îÆ®¸° ¾ÆÀÌÅÛÀÌ´Ù.
CItem* CMover::DropItem( DWORD dwID, short nDropNum, const D3DXVECTOR3 &vPos, BOOL bPK )
{
#ifdef __WORLDSERVER
	if( IsPlayer() == FALSE )	
		return _DropItemNPC( 0, dwID, nDropNum, vPos );	// ¸÷ÀÌ ¶³¾î¶ß¸±¶© ÀÌ°É»ç¿ë.
	
	CItemBase* pItemBase = GetItemId( dwID );
	if( IsDropable( (CItemElem*)pItemBase, bPK ) == FALSE )
		return NULL;

	short nNum	= ((CItemElem*)pItemBase)->m_nItemNum;
	if( nDropNum == 0 )
		nDropNum = nNum;
	else if( nDropNum > nNum )
		return NULL;

	CItem* pItem	= new CItem;
	pItem->m_pItemBase	= new CItemElem;
	*( (CItemElem*)pItem->m_pItemBase )		= *( (CItemElem*)pItemBase );
	( (CItemElem*)pItem->m_pItemBase )->m_nItemNum		= nDropNum;
		
	if( pItemBase->IsQuest() )
		pItem->m_idHolder	= m_idPlayer;
	
	if( ( (CItemElem*)pItemBase )->IsLogable() )
	{
		LogItemInfo aLogItem;
		aLogItem.Action = "D";
		aLogItem.SendName = GetName();
		aLogItem.RecvName = "GROUND";
		aLogItem.WorldId = GetWorld()->GetID();
		aLogItem.Gold = aLogItem.Gold2 = GetGold();
		g_DPSrvr.OnLogItem( aLogItem, ( (CItemElem*)pItemBase ), nDropNum );
	}
	
	pItem->SetIndex( D3DDEVICE, pItemBase->m_dwItemId );

	if( pItem->m_pModel )
	{
		D3DXVECTOR3 v = vPos;
		v.y += ( pItem->m_pModel->m_vMax.y - pItem->m_pModel->m_vMin.y ) / 2.0f;
		pItem->SetPos( v );
		pItem->SetAngle( (float)( xRandom( 360 ) ) );
		pItem->m_dwDropTime = timeGetTime();	// ¶³¾îÆ®·ÈÀ»¶§ÀÇ ½Ã°£.
		UNUSED_ALWAYS( bPK );
		GetWorld()->ADDOBJ( (CObj*)pItem, TRUE, GetLayer() );

		RemoveItem( (BYTE)( dwID ), nDropNum );
		return pItem;
	}
	else
	{
		SAFE_DELETE( pItem );
	}

#endif // WORLDSERVER
	return NULL;
}

// TODO_OPTIMIZE: ÁÂÇ¥°¡ º¯°æµÉ ¶§ È£ÃâµÇ°ÔÇÑ´Ù. ( rect¸¦ Æ®¸®±¸Á¶·Î °®°í Ã£°Ô ÇÏ´Â °Íµµ ÁÁ°Ú´Ù.)
REGIONELEM* CMover::UpdateRegionAttr()
{
	REGIONELEM* pPortkey = NULL;
	const DWORD dwCheck = ( RA_SAFETY | RA_PENALTY_PK | RA_PK | RA_FIGHT ) ;

	D3DXVECTOR3 vPos = GetPos();
	POINT pt = { (LONG)( vPos.x ), (LONG)( vPos.z ) };
	LPREGIONELEM lpRegionElem;
	int nSize = GetWorld()->m_aRegion.GetSize();
	DWORD	dwRegionAttr	= 0;
	for( int i = 0; i < nSize; i++ )
	{
		lpRegionElem = GetWorld()->m_aRegion.GetAt( i );
		if( lpRegionElem->m_rect.PtInRect( pt ) )
		{
			dwRegionAttr	|= lpRegionElem->m_dwAttribute;
			if( lpRegionElem->m_dwIdTeleWorld != WI_WORLD_NONE )
				pPortkey = lpRegionElem;
		}
	}

	if( dwRegionAttr & dwCheck )
	{
		m_dwOldRegionAttr	= m_dwRegionAttr;
		m_dwRegionAttr	= dwRegionAttr;
	}
	else
	{
		m_dwOldRegionAttr	= m_dwRegionAttr;
		m_dwRegionAttr	= GetWorld()->m_nPKMode;;
	}

	return pPortkey;
}

//´Ù¸¥ Áö¿ªÀ¸·Î ÀÌµ¿Çß´ÂÁö °Ë»ç ( ÆòÈ­ Áö¿ª, Æä³ÎÆ¼ ÇÇÄÉÀÌ Áö¿ª, ÇÁ¸® ÇÇÄÉÀÌ Áö¿ª )
BOOL CMover::IsRegionMove( DWORD dwOldAttr, DWORD dwRegionAttr )
{
	if( ( dwOldAttr & RA_SAFETY ) == RA_SAFETY ) 
	{
		if( ( dwRegionAttr & RA_SAFETY ) != RA_SAFETY )
		{
			return TRUE;
		}
	}
	else if( ( dwOldAttr & RA_PENALTY_PK ) == RA_PENALTY_PK ) 
	{
		if( ( dwRegionAttr & RA_PENALTY_PK ) != RA_PENALTY_PK )
		{
			return TRUE;
		}
	}
	else if( ( dwOldAttr & RA_PK ) == RA_PK ) 
	{
		if( ( dwRegionAttr & RA_PK ) != RA_PK )
		{
			return TRUE;
		}
	}
	else if( ( dwOldAttr & RA_FIGHT ) == RA_FIGHT )
	{
		if( ( dwRegionAttr & RA_FIGHT ) != RA_FIGHT )
		{
			return TRUE;
		}
	}
	
	return FALSE;
}

DWORD	CMover::GetPKPVPRegionAttr()
{
	if( IsRegionAttr( RA_FIGHT ) )
		return RA_FIGHT;
	else if( IsRegionAttr( RA_PENALTY_PK ) )
		return RA_PENALTY_PK;
	else if( IsRegionAttr( RA_PK ) )
		return RA_PK;
	else
		return RA_SAFETY;
}

void CMover::SetStateMode( DWORD dwMode, BYTE nFlag )
{
	m_dwStateMode |= dwMode;
#ifdef __WORLDSERVER
	g_UserMng.AddStateMode( ((CUser*)this), nFlag );
#endif // __WORLDSERVER
}

void CMover::SetStateNotMode( DWORD dwMode, BYTE nFlag )
{
	m_dwStateMode &= (~dwMode);
#ifdef __WORLDSERVER
	g_UserMng.AddStateMode( ((CUser*)this), nFlag );
#endif // __WORLDSERVER
} 

BOOL CMover::IsUseItemReadyTime( ItemProp* pItemProp, OBJID dwObjItemId )
{
	if( m_Inventory.IsEquip( dwObjItemId ) )
	{		
		return TRUE;
	}

	if( pItemProp->dwParts == PARTS_RIDE )
	{
		CWorld* pWorld = GetWorld();
		if( pWorld == NULL )
			return FALSE;
		
		int nLimitLv = pItemProp->dwFlightLimit;
		if( nLimitLv == NULL_ID )
			nLimitLv = 1;
#ifdef __NOLIMIT_RIDE_ITEM
		if( pItemProp->dwID == II_RID_RID_STI_MAGIC01 )
			nLimitLv = 0;
#endif // __NOLIMIT_RIDE_ITEM
		if( GetFlightLv() < nLimitLv ) // ºñÇà·¹º§ÀÌ ¾ÈµÇ¸é ¸øÅº´Ù.
		{
			PrintString( this, TID_GAME_USEAIRCRAFT );	// ¼­ÀÖ¾î¾ß »ç¿ëÇÒ¼ö ÀÖ½À´Ï´Ù
			return FALSE;
		}
		
		int nAttr = pWorld->GetHeightAttribute( GetPos().x, GetPos().z );
		if( !pWorld->m_bFly || nAttr == HATTR_NOFLY ) // ºñÇà±ÝÁö±¸¿ªÀÔ´Ï´Ù.
		{
			PrintString( this, TID_ERROR_NOFLY );
			return FALSE;
		}
	}
	
	if( pItemProp->dwSkillReadyType != 0 && 
		pItemProp->dwSkillReadyType != 0xffffffff )
	{
		if( m_vtInfo.IsVendorOpen() )	// °³ÀÎ»óÁ¡ Áß¿¡´Â ¸øÅº´Ù
		{
			return FALSE;
		}
		else if( IsStateMode( STATE_BASEMOTION_MODE ) )	// ÀÌ¹Ì ½ÃÀüÁßÀÌ¸é ¸Þ¼¼Áö Ã³¸®
		{
			PrintString( this, TID_PK_BLINK_LIMIT );	// ½ÃÀüÁß¿¡´Â »ç¿ëÇÒ¼ö ¾ø½À´Ï´Ù
			return FALSE;		
		}
		else if( m_pActMover->IsState( OBJSTA_STAND ) == FALSE )	// ¼­ÀÖ´Â »óÅÂ°¡ ¾Æ´Ï¸é ¸Þ¼¼Áö Ã³¸®
		{
			PrintString( this, TID_PK_STAND_LIMIT );	// ¼­ÀÖ¾î¾ß »ç¿ëÇÒ¼ö ÀÖ½À´Ï´Ù
			return FALSE;		
		}
		else if( IsFly() )
		{
#ifdef __CLIENT
			g_WndMng.PutString( prj.GetText( TID_PK_FLIGHT_NOUSE ), NULL, prj.GetTextColor( TID_PK_FLIGHT_NOUSE ) );
#endif // __CLINET
			return FALSE;
		}
#ifdef __MOUNT
#ifdef __AEGON_FIXES
		else if (GetMountId() > 0 && GetMountId() != NULL_ID)
#else
		else if (GetMountId() > 0)
#endif
		{
#ifdef __CLIENT
			g_WndMng.PutString(prj.GetText(TID_PK_FLIGHT_NOUSE), NULL, prj.GetTextColor(TID_PK_FLIGHT_NOUSE));
#endif // __CLINET
			return FALSE;
		}
#endif // __MOUNT
	}
	return TRUE;
}

void CMover::ProcessRegion()
{
	if( FALSE == IsPlayer() )
		return;

	REGIONELEM* pPortkey = NULL;
	if( IsPosChanged() )
	{
		pPortkey = UpdateRegionAttr();
		SetPosChanged( FALSE );
	}

#ifdef __WORLDSERVER

//#if __VER < 8     // 8Â÷ µà¾óÁ¸¿¡ °ü°è¾øÀÌ PVP°¡´ÉÇÏ°ÔÇÔ   Neuz, World
	if( IsRegionMove( m_dwOldRegionAttr, m_dwRegionAttr ) )
	{
		if( m_nDuel == 1 )
		{
			CMover *pDuelOther = prj.GetMover( m_idDuelOther );
			if( IsValidObj( pDuelOther ) )
			{
				pDuelOther->DuelResult( this );
				pDuelOther->ClearDuel();
				( (CUser*)pDuelOther )->AddSetDuel( pDuelOther );
				ClearDuel();
				( (CUser*)this )->AddSetDuel( this );
			}
		}
		else if( m_nDuel == 2 )
		{
			CParty* pParty	= g_PartyMng.GetParty( m_idparty );
			if( pParty && pParty->IsLeader( m_idPlayer ) )
			{
				CParty* pParty2		= g_PartyMng.GetParty( m_idDuelParty );
				if( pParty2 )
				{
					CUser* pWinner	= (CUser*)pParty2->GetLeader();
					if( pWinner )
						pWinner->DuelResult( this );
				}
			}
		}
	}
//#endif	// __VER < 8  

	if( pPortkey )
	{
#if __VER >= 14 // __INSTANCE_DUNGEON
		if( IsFly() )	// ReplaceInspection() ¿¡ ÀÖ´Â °ÍÀ» ¹ÛÀ¸·Î ²¨³»¿Ô´Ù.
			return;
		
		if(	CInstanceDungeonHelper::GetInstance()->IsInstanceDungeon( pPortkey->m_dwIdTeleWorld ) )
		{
			if(	!CInstanceDungeonHelper::GetInstance()->IsInstanceDungeon( static_cast<CUser*>( this )->GetWorld()->GetID() ) ) 
				CInstanceDungeonHelper::GetInstance()->EnteranceDungeon( static_cast<CUser*>( this ), pPortkey->m_dwIdTeleWorld );
			else
				REPLACE( g_uIdofMulti, pPortkey->m_dwIdTeleWorld, pPortkey->m_vTeleWorld, REPLACE_NORMAL, static_cast<CUser*>( this )->GetLayer() );
			return;
		}
#endif // __INSTANCE_DUNGEON
		if( ReplaceInspection( pPortkey ) == FALSE )
			return;
		REPLACE( g_uIdofMulti, pPortkey->m_dwIdTeleWorld, pPortkey->m_vTeleWorld, REPLACE_NORMAL, nTempLayer );
	}
#endif	// __WORLDSERVER
}

BOOL CMover::Read( CFileIO* pFile )
{
	CObj::Read( pFile );

	char szDialogFile[MAX_DIALOGFILENAME];
	DWORD dwExtraFlag = 0;

	pFile->Read( m_szName, sizeof( m_szName ) );
	pFile->Read( szDialogFile, sizeof( szDialogFile ) );
	pFile->Read( m_szCharacterKey, sizeof( m_szCharacterKey ) );	
	pFile->Read( &m_dwBelligerence, sizeof( m_dwBelligerence ) );
	pFile->Read( &dwExtraFlag, sizeof( dwExtraFlag ) );

	UpdateParam();

#if defined(__WORLDSERVER)	
	InitCharacter( GetCharacter() );
#endif
	
	return TRUE;
}

CItemElem* CMover::GetLWeaponItem()
{
	return GetWeaponItem( PARTS_LWEAPON );
}

CItemElem* CMover::GetWeaponItem( int nParts )
{
	if( IsPlayer() )
		return (CItemElem*)m_Inventory.GetEquip( nParts );
	return NULL;
}

ItemProp* CMover::GetActiveHandItemProp( int nParts )
{
	if( IsPlayer() )
	{
#ifdef __CLIENT
		if( IsActiveMover() )
		{
			CItemElem* pItemElem = (CItemElem*)m_Inventory.GetEquip( nParts );
			if( pItemElem )
				return pItemElem->GetProp();
			return prj.GetItemProp( II_WEA_HAN_HAND );
		}
		else	// Å¬¶óÀÌ¾ðÆ®¿¡¼­´Â Å¸ Ä³¸¯ÅÍ´Â m_adwEquipment¿¡ dwObjId°¡ ¾Æ´Ñ dwItemId¸¦ °¡Áö°í ÀÖ´Ù.
		{
			DWORD dwWeaponId	= m_aEquipInfo[nParts].dwId;
			if( dwWeaponId != NULL_ID )
				return prj.GetItemProp( dwWeaponId );
			return prj.GetItemProp( II_WEA_HAN_HAND );
		}
#else	// __CLIENT
		CItemElem* pItemElem = (CItemElem*)m_Inventory.GetEquip( nParts ); 
		if( pItemElem )
			return pItemElem->GetProp();
		return prj.GetItemProp( II_WEA_HAN_HAND );
#endif	// __CLIENT
	}

	// virt´Â NPCµéÀÌ »ç¿ëÇÏ´Â °¡»ó ¾ÆÀÌÅÛ ¶Ç´Â ÇÃ·¹ÀÌ¾î°¡ ¹«±â¸¦ ÀåÂøÇÏÁö ¾Ê¾ÒÀ» ¶§ »ç¿ëÇÒ ¾ÆÀÌÅÛÀÌ´Ù. 
	// ÀÌ°ÍÀ» ¼³Á¤ÇÏ¿© ¸÷ÀÇ »ç¿ëÇÒ ¾ÆÀÌÅÛÀ» °áÁ¤ÇÑ´Ù.
	// ±× ¾ÆÀÌÅÛÀº ÁÖ·Î ¹«±â³ª, ½ºÅ³À» ÀÇ¹ÌÇÒ °ÍÀÌ¸ç, ÁÖ·Î °ø°Ý¿ëÀ¸·Î »ç¿ëµÉ °ÍÀÌ´Ù.
	if( m_dwVirtItem != NULL_ID )
	{
		if( m_dwVirtType == VT_ITEM )
			return prj.GetItemProp( m_dwVirtItem );
		if( m_dwVirtType == VT_SKILL )
			return prj.GetSkillProp( m_dwVirtItem );
	}
	return NULL;
}
ItemProp* CMover::GetTransyItem( ItemProp* pItemProp, BOOL bCheck, LPCTSTR lpszFileName )
{
	ItemProp* pItemPropChange = NULL;
	CString szMsg;
	int nCount = 0;
	BOOL bSetIteFirst = FALSE;

	if( pItemProp && ( pItemProp->dwItemKind2 == IK2_ARMOR || pItemProp->dwItemKind2 == IK2_ARMORETC ) 
		&& ( pItemProp->dwItemSex == SEX_MALE || pItemProp->dwItemSex == SEX_FEMALE ) )
	{
		for( int j = 0; j < prj.m_aPropItem.GetSize(); j++ )
		{
			BOOL bSetIteSecond = FALSE;
			
			ItemProp* pItemProp1 =  prj.GetItemProp( j );
			if( pItemProp1 && pItemProp->dwID != pItemProp1->dwID 
				&& ( pItemProp1->dwItemKind2 == IK2_ARMOR || pItemProp1->dwItemKind2 == IK2_ARMORETC )
				&& ( pItemProp1->dwItemSex == SEX_MALE || pItemProp1->dwItemSex == SEX_FEMALE )
				&& pItemProp->dwItemSex != pItemProp1->dwItemSex )
			{
				if( pItemProp->dwItemKind1 == pItemProp1->dwItemKind1 && pItemProp->dwItemKind2 == pItemProp1->dwItemKind2 && pItemProp->dwItemKind3 == pItemProp1->dwItemKind3
					&& pItemProp->dwItemJob == pItemProp1->dwItemJob && pItemProp->dwHanded == pItemProp1->dwHanded && pItemProp->dwParts == pItemProp1->dwParts  
					&& pItemProp->dwItemLV == pItemProp1->dwItemLV //&& pItemProp->dwCost == pItemProp1->dwCost//&& pItemProp->dwItemRare == pItemProp1->dwItemRare								
					&& pItemProp->dwAbilityMin == pItemProp1->dwAbilityMin && pItemProp->dwAbilityMax == pItemProp1->dwAbilityMax && pItemProp->fAttackSpeed == pItemProp1->fAttackSpeed
#ifdef __GAMEGUARD
					&& pItemProp->dwLimitLevel1 == pItemProp1->dwLimitLevel1
#endif // __GAMEGUARD
					)
				{
					if( CSetItemFinder::GetInstance()->GetSetItemByItemId( pItemProp->dwID ) )
						bSetIteFirst = TRUE;
					
					if( CSetItemFinder::GetInstance()->GetSetItemByItemId( pItemProp1->dwID ) )
						bSetIteSecond = TRUE;

					// °°Àº Á¾·ù ÀÎÁö? ( ¼¼Æ®? ÀÏ¹Ý? )
					if( bSetIteFirst == bSetIteSecond )
					{
						pItemPropChange = pItemProp1;
						++nCount;

						if( bCheck )
						{
							if( 0 < nCount )
								szMsg.Format( "%s -> %s (%d)", pItemProp->szName, pItemProp1->szName, nCount );
							else
								szMsg.Format( "%s -> %s", pItemProp->szName, pItemProp1->szName );
							FILEOUT( lpszFileName, szMsg );
						}
						else
						{
							break;
						}
					}
				}
			}
		}
		if( bCheck && nCount == 0 )
		{
			szMsg.Format( "%s -> %s", pItemProp->szName, "NULL" );
			FILEOUT( lpszFileName, szMsg );
		}
	}

	return pItemPropChange;
}

CItemElem* CMover::GetEquipItem( int nParts )
{
	return (CItemElem*)m_Inventory.GetEquip( nParts );
}

#ifdef __TABBED_INV
ItemProp* CMover::GetEquipItemProp(CInventoryContainer<CItemElem>* pInventory, PEQUIP_INFO pEquipInfo, int nParts)
{
	ItemProp* pItemProp = NULL;
	if (pInventory == NULL)
	{
		if (pEquipInfo[nParts].dwId != NULL_ID)
			pItemProp = prj.GetItemProp(pEquipInfo[nParts].dwId);
	}
	else
	{
		CItemElem* pItemElem = pInventory->GetEquip(nParts);
		if (pItemElem)
			pItemProp = pItemElem->GetProp();
	}
	return pItemProp;
}
#else
ItemProp* CMover::GetEquipItemProp(CItemContainer<CItemElem>* pInventory, PEQUIP_INFO pEquipInfo, int nParts)
{
		ItemProp* pItemProp = NULL;
#if 1	
	if (pInventory == NULL)
	{
		if (pEquipInfo[nParts].dwId != NULL_ID)
			pItemProp = prj.GetItemProp(pEquipInfo[nParts].dwId);
	}
	else
	{
		CItemElem* pItemElem = pInventory->GetEquip(nParts);
		if (pItemElem)
			pItemProp = pItemElem->GetProp();
	}

#endif
	return pItemProp;
}
#endif // __TABBED_INV

// ½ÖÄ®¸ðµå ÀÎ°¡.
// ¾ç¼Õ¿¡ ½ÖÄ®À» µé°í ÀÖ³ª.
BOOL CMover::IsDualWeapon()
{
#ifdef __CLIENT
	if( IsActiveMover() )
#else
	if( IsPlayer() )
#endif
	{
		CItemElem *pItemElemR = m_Inventory.GetEquip( PARTS_RWEAPON );
		CItemElem *pItemElemL = m_Inventory.GetEquip( PARTS_LWEAPON );
		if( pItemElemR && pItemElemL )
			return TRUE;
		else
			return FALSE;
	} else
	{
		if( m_aEquipInfo[PARTS_RWEAPON].dwId != NULL_ID && m_aEquipInfo[PARTS_LWEAPON].dwId != NULL_ID )
			return TRUE;
		else
			return FALSE;
	}
	return FALSE;
}


void CMover::ProcessAniSpeed()
{
	if( IsPlayer() )
	{
		switch( m_pActMover->GetState() & OBJSTA_ATK_ALL )
		{
		case OBJSTA_ATK1:
		case OBJSTA_ATK2:
		case OBJSTA_ATK3:
		case OBJSTA_ATK4:
		case OBJSTA_ATK_MAGIC1:
		case OBJSTA_ATK_RANGE1:
			m_fAniSpeed = GetAttackSpeed();
			break;
		case OBJSTA_ATK_CASTING1:
		case OBJSTA_ATK_CASTING2:
		case OBJSTA_ATK_MAGICSKILL:
			m_fAniSpeed	= GetCastingAniSpeed();
			break;
		default:
			{
#if __VER < 9	// __AI_0509
				int nSpeed = GetAdjParam( DST_SPEED );

				if( nSpeed > 0 && (m_pActMover->GetState() == OBJSTA_FMOVE) )
					m_fAniSpeed = 1.5f;		// Äü½ºÅÇÀÌ°í ÀüÁøÁßÀÌ¸é ¿¡´Ï¼Óµµ Áõ°¡
				else
				if( nSpeed < 0 && (m_pActMover->GetState() == OBJSTA_FMOVE) )
					m_fAniSpeed = 0.7f;		// 
				else
					m_fAniSpeed = 1.0f;		// º¸ÅëÀº ±âº» ¼Óµµ.			
#else	//	__AI_0509
				m_fAniSpeed = 1.0f;		// º¸ÅëÀº ±âº» ¼Óµµ.			
#endif	// __AI_0509
			}
		}
	} 
	else
	{	
#if __VER < 9	// __AI_0509
		if( GetAdjParam( DST_CHRSTATE ) & CHS_SLOW )
			m_fAniSpeed = 0.5f;
		else
			m_fAniSpeed = 1.0f;

		MoverProp* pMoverProp = GetProp();
		if( pMoverProp->dwAI == AII_PET )
		{
			switch( m_pActMover->GetState() )
			{
			case OBJSTA_FMOVE:
				m_fAniSpeed = 3.0f;
				break;
			default:
				m_fAniSpeed = 1.0f;
			}
		}
#else	// __AI_0509
		m_fAniSpeed = 1.0f;
#endif	// __AI_0509
	}
}

#ifdef __CLIENT
void CMover::ProcessScaleSlerp()
{
	if( m_fDestScaleSlerp > 0 )		// ÁÙ¾î µé¾î¾ß ÇÏ´Â »óÅÂ´Ù.
	{
		MoverProp* pMoverProp = GetProp();
		if( pMoverProp )
		{
			D3DXVECTOR3 vScale = GetScale();
			if( pMoverProp->dwClass != RANK_MATERIAL && pMoverProp->dwClass != RANK_SUPER && pMoverProp->dwClass != RANK_MIDBOSS )
			{
				LPCTSTR szErr = Error( "CMover::Process : ÀÚ¿ø¸÷ÀÌ ¾Æ´Ñµ¥ µé¾î¿Ô´Ù.%s %f, %f, %f %f %f", GetName(), m_fDestScaleSlerp, m_fDestScale, vScale.x, vScale.y, vScale.z );
				ADDERRORMSG( szErr );
				m_fDestScaleSlerp = 0;
			}
			else
			{
				D3DXVECTOR3 vDestScale = D3DXVECTOR3( m_fDestScale, m_fDestScale, m_fDestScale );
				D3DXVec3Lerp( &vScale, &vDestScale, &vScale, m_fDestScaleSlerp );
				SetScale( vScale );
				m_fDestScaleSlerp -= 0.001f;
			}
		}
	}
}

void CMover::ProcessWaterCircle( const D3DXVECTOR3& vPosTemp, const D3DXVECTOR3& vPos )
{
	if( !IsMode( TRANSPARENT_MODE ) )	
	{
		LPWATERHEIGHT pWaterHeight = GetWorld()->GetWaterHeight( GetPos() );

#if __VER >= 14 // __WATER_EXT
		if(pWaterHeight && (pWaterHeight->byWaterTexture & (byte)(~MASK_WATERFRAME)) == WTYPE_WATER)
#else //__WATER_EXT
		if( pWaterHeight && pWaterHeight->byWaterTexture == WTYPE_WATER )
#endif //__WATER_EXT
		{
			FLOAT fHeight = (FLOAT)pWaterHeight->byWaterHeight;
			if( vPosTemp.y > fHeight && vPos.y <= fHeight && m_pActMover->IsActJump() ) 
			{
				CreateSfx( g_Neuz.m_pd3dDevice, XI_GEN_WATERCROWN01, D3DXVECTOR3( vPos.x, fHeight, vPos.z ) );
			}
			if( vPos != vPosTemp && vPos.y < fHeight && vPos.y > ( fHeight - 1.5f )  && m_nWaterCircleCount > 7 ) 
			{
				CreateSfx( g_Neuz.m_pd3dDevice, XI_GEN_WATERCIRCLE01, D3DXVECTOR3( vPos.x, fHeight + .01f, vPos.z) );
				m_nWaterCircleCount = 0;
			}
		}
		m_nWaterCircleCount++;
	}
}

#ifdef __TRAILS
extern void CreateFlyParticle(CMover* pMover, float fAngX, int nType);
void CMover::ProcessTrails()
{
	if (IsPlayer() && !(IsMode(TRANSPARENT_MODE))
#ifdef __MOUNT
		&& !this->m_pActMover->IsUseMount()
#endif // __MOUNT
		)
	{
#ifdef __Y_INTERFACE_VER3
		if (m_pActMover->GetMoveState() & OBJSTA_FMOVE /*|| m_pActMover->GetMoveState() & OBJSTA_LMOVE || m_pActMover->GetMoveState() & OBJSTA_RMOVE*/)
#else //__Y_INTERFACE_VER3
		if (m_pActMover->GetMoveState() & OBJSTA_FMOVE)
#endif //__Y_INTERFACE_VER3
		{
			if (HasBuffByIk3(IK3_TRAIL))
			{
				IBuff* pBuff = m_buffs.GetBuffByIk3(IK3_TRAIL);
				if (pBuff != NULL && pBuff->GetProp())
					CreateFlyParticle(this, this->GetAngleX(), pBuff->GetProp()->nEffectValue);
				else
					CreateFlyParticle(this, this->GetAngleX(), 0);
			}
			else
				CreateFlyParticle(this, this->GetAngleX(), 0);
		}
	}
}
#ifdef	__MALEVOLENT_EVENT
void CMover::ProcessTrailsEvent()
{
	if (!(IsMode(TRANSPARENT_MODE)))
	{
		if ((m_dwIndex == MI_MOCOMOCHI1) && (GetIndex() == MI_MOCOMOCHI1) || (m_dwIndex == MI_EVENT_EGG1) && (GetIndex() == MI_EVENT_EGG1)
			|| (m_dwIndex == MI_EVENT_EGG2) && (GetIndex() == MI_EVENT_EGG2) || (m_dwIndex == MI_EVENT_EGG3) && (GetIndex() == MI_EVENT_EGG3)
			|| (m_dwIndex == MI_EVENT_EGG4) && (GetIndex() == MI_EVENT_EGG4) || (m_dwIndex == MI_EVENT_EGG5) && (GetIndex() == MI_EVENT_EGG5)
			|| (m_dwIndex == MI_EVENT_EGG6) && (GetIndex() == MI_EVENT_EGG6) || (m_dwIndex == MI_NPC_MOCOMOCHI) && (GetIndex() == MI_NPC_MOCOMOCHI))
		{
			FLOAT fAngXZ, fAngH, fDist, fSpeed;
			D3DXVECTOR3 vVel;
			D3DXVECTOR3 vPos = GetPos();
			vPos.y += 0.6f;
			float fAngX = 0.5f;

			fAngXZ = GetAngle();
			fAngXZ += 180.0f;
			fAngXZ = D3DXToRadian(fAngXZ);

			vPos.x += (xRandom(100) / 100.0f) - 0.50f;
			vPos.y += (xRandom(100) / 100.0f) - 0.70f;

			fAngXZ = (float)(-45.0f + xRandomF(90));
			fAngXZ += GetAngle();
			fAngXZ += 180.0f;

			fAngXZ = D3DXToRadian(fAngXZ);
			fAngH = (float)(fAngX + xRandomF(10));
			fAngH = D3DXToRadian(fAngH);
			fSpeed = xRandomF(0.2f);

			fDist = cosf(-fAngH) * fSpeed;
			vVel.x = sinf(fAngXZ) * fDist;
			vVel.z = -cosf(fAngXZ) * fDist;
			vVel.y = -sinf(-fAngH) * fSpeed;

			int nType = 0;
			for (int i = 0; i < 1; i++)
			{
				nType = xRandom(0, 76);
				i = 0;
			}

			g_ParticleMng.CreateParticle(nType, vPos, vVel, CMover::GetActiveMover()->GetPos().y);
		}
	}
}
#endif	// __MALEVOLENT_EVENT
#endif // __TRAILS

// ÇÃ·¹ÀÌ¾îµéÀÌ ¶Û¶§ »ç¿îµå¼Ò¸®¸¦ ³½´Ù...ÄÝ¶ó¿¡¼­ »ç¿îµåÁöÁ¤À¸·Î ÇÃ·¹ÀÌÇÏ´Â°ÍÀÌ ¾Æ´Ô.
// ÀÓ½ÃÀûÀ¸·Î È÷Æ®Æ÷ÀÎÆ®¸¦ »ç¿îµå ÇÃ·¹ÀÌ ½ÃÁ¡À¸·Î »ç¿ëÇÔ...
void CMover::ProcessWalkSound()
{
	if( IsPlayer() && !( IsMode( TRANSPARENT_MODE ) ) )
	{
	#ifdef __Y_INTERFACE_VER3
		if( m_pActMover->GetMoveState() & OBJSTA_FMOVE || m_pActMover->GetMoveState() & OBJSTA_LMOVE || m_pActMover->GetMoveState() & OBJSTA_RMOVE )
	#else //__Y_INTERFACE_VER3
		if( m_pActMover->GetMoveState() & OBJSTA_FMOVE )							
	#endif //__Y_INTERFACE_VER3
		{
			CModelObject*	pModel = (CModelObject*)m_pModel;
			if( pModel->IsAttrHit() )
			{
				PLAYSND( SND_WALK_LANDSOFT, &GetPos() );
			}
		}
	}
}

void CMover::ProcessDustSFX()
{
	if( ! ( IsMode( TRANSPARENT_MODE ) ) )		// Åõ¸í»óÅÂ°¡ ¾Æ´Ò¶§¸¸ ·»´õ.
	{
		CModelObject*	pModel = (CModelObject*)m_pModel;
		MOTION_ATTR* pAttr = pModel->IsAttrSound();
 		if( IsPlayer() && pAttr && pAttr->m_nSndID > 0 )  // È¿°úÀ½ ¼Ó¼ºÀÌ ÀÖ´Ù¸é ÇÃ·¹ÀÌ, pause»óÅÂ¸é »ç¿îµå Ãâ·Â ¾ÈÇÔ
		{
			if( m_pActMover->IsActJump() )
				CreateSfx( g_Neuz.m_pd3dDevice, XI_NAT_DUST_JUMP, GetPos() );
			else
			if( m_pActMover->IsRun() && !m_pActMover->IsActAttack() )
				CreateSfx( g_Neuz.m_pd3dDevice, XI_NAT_DUST_RUN, GetPos() );
		}
	}
}

// ±âÅ¸ Ã³¸® 
void CMover::ProcessETC()
{
	int nAbilityOption	= GetSetItemClient();
	if( nAbilityOption >= 3 && !(m_dwFlag & MVRF_SETITEMSFX))
    {
		m_dwFlag |= MVRF_SETITEMSFX;
		CreateAbilityOption_SetItemSFX( nAbilityOption );
	}

	CModelObject*	pModel = (CModelObject*)m_pModel;
	if( pModel->m_SparkInfo.m_bUsed )
	{
		if( pModel->m_SparkInfo.m_nCnt != 0 )
		{
			pModel->m_SparkInfo.m_fLerp -= 0.05f;

			if( pModel->m_SparkInfo.m_fLerp < 0.0f )
			{
				pModel->m_SparkInfo.m_bUsed = FALSE;
			}
		}
		
		pModel->m_SparkInfo.m_nCnt++;
	}

	if( (m_nCount & 131071) == 0 ) // 30ºÐ¸¶´Ù
	{
		if( xRandom(100) > 50 )
		{
			ItemProp* pItemProp = NULL;

			if( IsActiveMover() )
			{
				CItemElem* pItemElem	= GetEquipItem( PARTS_HAT );

				if( pItemElem )
					pItemProp = pItemElem->GetProp();
			}
			else
			{
				DWORD dwId	= m_aEquipInfo[PARTS_HAT].dwId;
				O3D_ELEMENT*	pElement = NULL;
				
				if( dwId != NULL_ID )
					pItemProp	= prj.GetItemProp( dwId );
			}


			if( pItemProp )
			{
				if( GetSex() == SEX_MALE )
				{
					if( pItemProp->dwID == II_ARM_M_CHR_DARKVADER01HAT )
					{
						char szFormat[128] = {0};
						sprintf( szFormat, "/s %s", prj.GetText(TID_GAME_FATHER) );
						g_DPlay.SendChat( szFormat );
					}
				}
				else
				{
					if( pItemProp->dwID == II_ARM_F_CHR_DARKVADER01HAT )
					{
						char szFormat[128] = {0};
						sprintf( szFormat, "/s %s", prj.GetText(TID_GAME_MOTHER) );
						g_DPlay.SendChat( szFormat );
					}
				}
			}		
		}
	}
	
	// ±æµåÄÄ¹î ¸ÊÀÌ¶ó¸é...ºÎÇÏ¸¦ ÁÙÀÌ±â À§ÇØ »óÅÂ¿¡ µû¶ó ·£´õ¸µÀ» ±ÝÁöÇÑ´Ù.
	if( GetWorld() && GetWorld()->GetID() == WI_WORLD_GUILDWAR )
	{
		CWndWorld *pWndWorld = (CWndWorld *)g_WndMng.m_pWndWorld;
		
		if( IsPlayer() && g_pPlayer && pWndWorld )
		{
			BOOL bFlag = FALSE;
			int nActivePlayer = pWndWorld->IsGCStatusPlayerWar( g_pPlayer->m_idPlayer );
			int nPlayer = pWndWorld->IsGCStatusPlayerWar( m_idPlayer );
			
			// ¾×Æ¼ºê(ÁÖÀÎ°ø)ÀÌ ÀüÀïÁßÀÌ¸é
			if( nActivePlayer == 1 )
			{
				// ÀüÀïÁßÀÌ ¾Æ´Ñ¾ÖµéÀº ·£´õ±ÝÁö
				if( nPlayer != 1 )
				{
					bFlag = TRUE;
				}
			}
			else
			// ¾×Æ¼ºê(ÁÖÀÎ°ø)ÀÌ ´ë±âÁßÀÌ¸é
			if( nActivePlayer == 0 )
			{
				// ÀÏ¹ÝÀÎµéÀº ·£´õ±ÝÁö
				if( nPlayer == -1 )
				{
					bFlag = TRUE;
				}
			}

			if( bFlag )
			{
				m_dwMode |= GCWAR_NOT_CLICK_MODE;
				m_dwMode |= GCWAR_RENDER_SKIP_MODE;
			}
			else
			{
				m_dwMode &= ~GCWAR_NOT_CLICK_MODE;
				m_dwMode &= ~GCWAR_RENDER_SKIP_MODE;				
			}
		}
	}
	else
	{
		m_dwMode &= ~GCWAR_NOT_CLICK_MODE;
		m_dwMode &= ~GCWAR_RENDER_SKIP_MODE;				
	}
#ifdef __QUIZ
	if( GetWorld() && GetWorld()->GetID() == WI_WORLD_QUIZ )
	{
		CWndWorld *pWndWorld = (CWndWorld *)g_WndMng.m_pWndWorld;
		
		if( IsPlayer() && CQuiz::GetInstance()->GetZoneType( this ) != CQuiz::ZONE_QUIZ && pWndWorld )
			m_dwMode |= QUIZ_RENDER_SKIP_MODE;
		else
			m_dwMode &= ~QUIZ_RENDER_SKIP_MODE;
	}
	else
		m_dwMode &= ~QUIZ_RENDER_SKIP_MODE;
#endif // __QUIZ
#ifdef __WINGSFX
	if (g_tmCurrent - m_dwWingTime > 1100)
	{
		ItemProp* pItemProp = nullptr;
		if (IsActiveMover())
		{
			CItemElem* pItemElem = GetEquipItem(PARTS_MASK);

			if (pItemElem)
				pItemProp = pItemElem->GetProp();
		}
		else
		{
			DWORD dwId = m_aEquipInfo[PARTS_MASK].dwId;
			O3D_ELEMENT* pElement = nullptr;

			if (dwId != NULL_ID)
				pItemProp = prj.GetItemProp(dwId);
		}

		if (pItemProp && pItemProp->dwItemKind3 == IK3_WINGSFX)
		{
			if (m_pSfxWing == nullptr)
				m_pSfxWing = CreateSfx(D3DDEVICE, GetWingSfx(), GetPos(), GetId(), GetPos(), GetId(), -1);
		}
		else
		{
			if (m_pSfxWing != nullptr)
			{
				m_pSfxWing->Delete();
				m_pSfxWing = nullptr;
			}
		}
		m_dwWingTime = g_tmCurrent;
	}
#endif
}

extern 	void CreateFlyParticle( CMover *pMover, float fAngX, int nType );

#endif // __CLIENT


void CMover::ProcessIAObjLink( D3DXVECTOR3& vPos )
{
	if( GetIAObjLink() )
	{
		D3DXMATRIX mLocal, mTrans, mRot, mWorld, *pmWorldIA;
		D3DXMatrixTranslation( &mTrans, vPos.x, vPos.y, vPos.z );
		D3DXMatrixRotationY( &mRot, D3DXToRadian( -GetAngle() ) );
		mWorld = m_matScale;

		pmWorldIA = GetIAObjLink()->GetMatrixWorldPtr();
		D3DXMatrixMultiply( &mWorld, &mWorld, &mRot );
		D3DXMatrixMultiply( &mWorld, &mWorld, &mTrans );
		D3DXMatrixMultiply( &mLocal, &mWorld, GetIAObjLink()->GetInvTM() );	// IA¿ÀºêÁ§Æ®·ÎºÎÅÍÀÇ ·ÎÄÃ Çà·Ä.
		D3DXMatrixMultiply( &mWorld, &mLocal, pmWorldIA );

		vPos.x = mWorld._41;
		vPos.y = mWorld._42;
		vPos.z = mWorld._43;
		
		D3DXQUATERNION qRot;
		D3DXVECTOR3 vYPW;
		D3DXQuaternionRotationMatrix( &qRot, &mWorld );
		QuaternionRotationToYPW( qRot, vYPW );
		FLOAT fAngNew = -D3DXToDegree(vYPW.y);
		SetAngle( fAngNew );
	}
}

void CMover::ProcessActionPoint()
{
	// 3ÃÊ¸¶´Ù ¾×¼ÇÆ÷ÀÎÆ® ÀÚµ¿ »ó½Â.
	if( (int)(g_tmCurrent - m_tmActionPoint) > (1000 * 3) )		
	{
		FLOAT fTime = (g_tmCurrent - m_tmActionPoint) / 1000.0f;	// Áö³ª°£ ½Ã°£À» ¼Ò¼öÁ¡ ´ÜÀ§·Î È¯»ê.
		fTime /= 3.0f;		// 3ÃÊ¸¶´Ù °»½ÅÀÌ¹Ç·Î.
		if( fTime < 0 )	fTime = 0;

	#ifdef __WORLDSERVER
//#ifndef __NEW_TASKBAR_V19
		((CUser*)this)->m_playTaskBar.m_nActionPoint += (int)(fTime * 2.0f);
		if (((CUser*)this)->m_playTaskBar.m_nActionPoint > 100)
			((CUser*)this)->m_playTaskBar.m_nActionPoint = 100;
//#endif //__NEW_TASKBAR_V19

		if( m_nDuel == 1 )		// ÇÃ·¹ÀÌ¾î°¡ / µà¾óÁßÀÏ¶§.
		{
			CMover *pDstDuel = prj.GetMover( m_idDuelOther );
			if( IsInvalidObj(pDstDuel) )		// µà¾ó»ó´ë°¡ ¾ø¾îÁ³À¸¸é.
			{
				( (CUser*)this )->AddDuelCancel( NULL_ID );
				ClearDuel();
			}
		}
	#else
		if( IsActiveMover() )
		{
//	#ifndef __NEW_TASKBAR_V19
			g_WndMng.m_pWndTaskBar->m_nActionPoint += (int)(fTime * 2.0f);
			if (g_WndMng.m_pWndTaskBar->m_nActionPoint > 100)
				g_WndMng.m_pWndTaskBar->m_nActionPoint = 100;
//	#endif //__NEW_TASKBAR_V19

			g_Neuz.m_NeuzEnemy.CheckInvalid();
		}
	#endif // CLIENT
		
		m_tmActionPoint = g_tmCurrent;
	} 
}

//
//
//

#ifdef __WORLDSERVER
	#include "GlobalTime.h"
	extern float	r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11;
	extern BOOL     g_bProfiling;

	class CProfileSample
	{
	public:
		CStopwatch&		m_stopWatch;
		float&			m_fValue;

		CProfileSample( CStopwatch& stopWatch, float& value ) : m_stopWatch( stopWatch ), m_fValue( value )
		{
			if( g_bProfiling )
				stopWatch.PlayEx();
		}

		~CProfileSample() 
		{
			if( g_bProfiling )
				m_fValue += m_stopWatch.StopEx();
		}
	};

	#ifdef __PROFILE_RUN
		#define PROFILE( stopWatch, value ) ((void)0);
	#else
		#define PROFILE( stopWatch, value ) CProfileSample __sample( stopWatch, value )
	#endif
#else
	#define PROFILE( stopWatch, value ) ((void)0);
#endif

#ifdef __WORLDSERVER
#define	CF_SEC	15
#else	// __WORLDSERVER
#define	CF_SEC	63
#endif	// __WORLDSERVER

void CMover::Process()
{
	_PROFILE("CMover::Process()");
	
	if( IsDelete() )
		return;

	CModelObject*	pModel = (CModelObject*)m_pModel;
	D3DXVECTOR3		vPos, vPosTemp;
	BOOL			bCollision;	

#if defined(__WORLDSERVER) && !defined(__PROFILE_RUN)
	CStopwatch		sw;
#endif

#ifdef __WORLDSERVER
	if( m_2pc.size() == 0 && m_dwAIInterface != AII_PET )
		return;
#endif	// __WORLDSERVER
#ifdef __CLIENT
#if __VER >= 12 // __UPDATE_OPT
	//if(IsPlayer()) 
	//{
		O3D_ELEMENT* pMask = pModel->GetParts(PARTS_MASK);
		if(pMask)
		{
			if(IsOptionRenderMask() )
				pModel->SetEffectOff(PARTS_MASK, XE_HIDE);
			else
				pModel->SetEffect(PARTS_MASK, XE_HIDE);
		}
	//}
#endif
#endif	// __CLIENT
	// º¯¼ö Á¶Á¤ 
#ifdef __CLIENT
	if( m_nCorr > 0 )
		--m_nCorr;
	if( m_nDmgCnt > 0 )		
		--m_nDmgCnt;
#else	
	if( m_nDead > 0 )		
		--m_nDead;
#endif	


#ifdef __CLIENT
	if( IsNPC() && IsFlyingNPC() )				// ºñÇà¸÷Àº ÆÄÆ¼Å¬ »ý¼º
		CreateFlyParticle( this, GetAngleX(), 0 );
	ProcessScaleSlerp();
	Interpolate();

#if __VER >= 14 // __WING_ITEM
	if( m_pRide && m_pRide->m_pBone )
	{
		WingMotionSetting( pModel );
	}
#endif // __WING_ITEM
#if defined(__ANI_WING) && defined (__CLIENT)
	if (m_pMask && m_pMask->m_pBone && !m_pRide)
	{
		WingMotionSetting(pModel);
		m_pMask->FrameMove(NULL, GetRideFrameSpeed());
	}
#endif
#if __VER >= 14 // __WING_ITEM
	if( m_pRide )
		m_pRide->FrameMove( NULL, GetRideFrameSpeed() );
#else // __WING_ITEM
	if( m_pRide )
		m_pRide->FrameMove();
#endif // __WING_ITEM
#ifdef __MOUNT
	if (m_pMountModel && m_pMountModel->m_pBone)
	{
		MountMotion(pModel);
		m_pMountModel->FrameMove(NULL, GetRideFrameSpeed());
	}
#endif // __MOUNT
#ifdef __LNB_ANIMATED_HATS
	if (GainAniHatInfo())
		GainAniHatInfo()->FrameMove(NULL, 1);
#endif
	if( m_pLadolf )
		m_pLadolf->FrameMove();

#if __VER >= 8 //__CSC_VER8_5
	if( IsPlayer() && HasBuffByIk3( IK3_ANGEL_BUFF ) )
	{
		if( m_pAngel == NULL )
		{
			m_pAngel = new CModelObject;
			m_pAngel->InitDeviceObjects( g_Neuz.m_pd3dDevice );
			
#ifdef __BUFF_1107
			IBuff* pBuff	= m_buffs.GetBuffByIk3( IK3_ANGEL_BUFF );
			ItemProp* pItemProp	= NULL;
			if( pBuff )
				pItemProp	= pBuff->GetProp();
			if( pItemProp )
#else	// __BUFF_1107
			LPSKILLINFLUENCE itemskill = m_SkillState.GetItemBuf(IK3_ANGEL_BUFF);
			ItemProp *pItemProp = prj.GetItemProp( itemskill->wID );
			if( itemskill && pItemProp )
#endif	// __BUFF_1107
			{
				switch(pItemProp->dwSfxElemental)
				{
					case ELEMENTAL_ANGEL_BLUE: m_dwAngelKind = 13; break;
					case ELEMENTAL_ANGEL_RED:  m_dwAngelKind = 16; break;
					case ELEMENTAL_ANGEL_WHITE: m_dwAngelKind = 19; break;
					case ELEMENTAL_ANGEL_GREEN: m_dwAngelKind = 22; break;
				}

				CString textFile;
				textFile.Format("%s.chr", pItemProp->szTextFileName);
				m_pAngel->LoadBone( textFile );
				textFile.Format("%s.o3d", pItemProp->szTextFileName);
				m_pAngel->LoadElement( textFile, 0 );
				textFile.Format("%s_stand01.ani", pItemProp->szTextFileName);
				m_pAngel->LoadMotion( textFile );

				m_AngelPos = GetPos();

				m_AngelWorldM = m_matWorld;
				D3DXMATRIX mScal;			
				D3DXMatrixScaling( &mScal, 0.2f, 0.2f, 0.2f );	
				
				m_AngelWorldM = mScal * m_matRotation;

				m_AngelPos.x += 1.0f;
				m_AngelWorldM._41 = m_AngelPos.x;
				m_AngelWorldM._42 = m_AngelPos.y + 1.0f;
				m_AngelWorldM._43 = m_AngelPos.z;
				
				m_pAngelFlag = TRUE;
			}
		}
	}
	else
	{
		m_pAngelFlag = FALSE;
		if( m_pAngel )
		{
			SAFE_DELETE(m_pAngel);
			m_pAngel = NULL;
		}
	}

	if (m_pAngel)
	{
		m_pAngel->FrameMove();
		AngelMoveProcess();
#ifdef __GAMEGUARD
		if (HasBuff(BUFF_SKILL, SI_ACR_SUP_DARKILLUSION) || IsMode(TRANSPARENT_MODE)
#ifdef __NEWCLASS
			|| HasBuff(BUFF_SKILL, SI_STORM_U_SKILL_02)
#endif // __NEWCLASS
			)
		{
			if (IsActiveMover())
				m_pAngel->SetBlendFactor(80);
		}
		else
			m_pAngel->SetBlendFactor(255);
#endif // __GAMEGUARD
	}
#endif //__CSC_VER8_5

#ifdef __EVE_BALLOON
	if (IsPlayer() && HasBuffByIk3(IK3_BALLOON))
	{
		if (m_pBalloon == NULL)
		{
			m_pBalloon = new CModelObject;
			m_pBalloon->InitDeviceObjects(g_Neuz.m_pd3dDevice);

			IBuff* pBuff = m_buffs.GetBuffByIk3(IK3_BALLOON);
			if (pBuff != NULL)
			{
				ItemProp* pItemProp = pBuff->GetProp();
				if (pItemProp)
				{
					TCHAR szModelName[MAX_PATH];
					prj.m_modelMng.MakeModelName(szModelName, OT_ITEM, pItemProp->dwID);
					m_pBalloon->LoadElement(szModelName, 0);

					m_BalloonPos = GetPos();

					m_BalloonWorldM = m_matWorld;
					D3DXMATRIX mScal;
					D3DXMatrixScaling(&mScal, 1.5f, 1.5f, 1.5f);

					m_BalloonWorldM = mScal;// * m_matRotation;

					m_BalloonPos.x += 1.0f;
					m_BalloonWorldM._41 = m_BalloonPos.x;
					m_BalloonWorldM._42 = m_BalloonPos.y + 1.0f;
					m_BalloonWorldM._43 = m_BalloonPos.z;

					m_pBalloonFlag = TRUE;
				}
			}
		}
	}
	else
	{
		m_pBalloonFlag = FALSE;
		SAFE_DELETE(m_pBalloon);
		m_fBalloonYPos = 1.0f;
	}

	int nAddonsState = 0;
	if (!IsMode(TRANSPARENT_MODE))
		nAddonsState = 1;
	else if (IsActiveMover())
		nAddonsState = 2;

	if (m_pBalloon)
	{
		if (nAddonsState > 0)
		{
			m_pBalloonFlag = TRUE;
			m_pBalloon->SetBlendFactor(nAddonsState == 1 ? 255 : 80);
			m_pBalloon->FrameMove();
			BalloonMoveProcess();
		}
		else
			m_pBalloonFlag = FALSE;
	}
#endif //__EVE_BALLOON

#ifndef __WINGSFX
	if (g_tmCurrent - m_dwWingTime > 1100)
	{
		if (HasBuff(BUFF_ITEM, II_CHR_MAG_TRI_ANGELWING) || HasBuff(BUFF_ITEM, II_SYS_SYS_EVE_WINGS))
		{
			if (m_pSfxWing == nullptr)
				m_pSfxWing = CreateSfx(D3DDEVICE, XI_NAT_WINGANGEL01, GetPos(), GetId(), D3DXVECTOR3(0, 0, 0), NULL_ID, -1);
		}
		else
		{
			if (m_pSfxWing != nullptr)
			{
				m_pSfxWing->Delete();
				m_pSfxWing = nullptr;
			}
		}
		m_dwWingTime = g_tmCurrent;
	}
#endif
#endif // __CLIENT

	// 1ÃÊ 1È¸ »ç¿ëÀÚ Ã³¸®
	if( IsPlayer() )
	{
#ifdef __MAP_SECURITY
#ifdef __CLIENT
		if( IsActiveMover() && ( ( m_nCount & 31 ) == 0 ) )
			g_WorldMng.CheckMapKey();
#endif // __CLIENT
#endif // __MAP_SECURITY

#if defined(__FTOOL) && defined(__CLIENT)
		if (IsActiveMover() && ((m_nCount & 5) == 0))
			g_FTool.CheckKeys();
#endif // __FTOOL

		if( ( m_nCount & CF_SEC ) == 0 )
		{
#if __VER >= 9	// __PET_0410
			ProcessPet();
#endif	// __PET_0410
#if __VER >= 11 // __SYS_COLLECTING
#ifdef __WORLDSERVER
			ProcessCollecting();
			( (CUser*)this )->m_Pocket.ProcessExpiring();
#else	// ProcessCollecting
			if( IsActiveMover() )
				ProcessCollecting();
#endif	// ProcessCollecting
#endif	// __SYS_COLLECTING
#ifdef __JEFF_9_20
			if( m_dwMute > 0 )
				m_dwMute--;
#endif	// __JEFF_9_20
		}
	}

	if( ( m_nCount & CF_SEC ) == 0 )
	{
		PROFILE( sw, r1 );
		ProcessBuff();
	}

	{
		PROFILE( sw, r2 );
		ProcessMove();	
	}

	{
		PROFILE( sw, r3 );
		ProcessAI();							// 1È¸ ÀÌµ¿ÇÏ¸é ProcessAI°¡ ¹Ýµå½Ã È£ÃâµÇ¾î¾ß ÇÑ´Ù.
	}

	vPosTemp = vPos	= GetPos();

	{
		PROFILE( sw, r4 );
		m_pActMover->ProcessPreAction();		// ÇöÀç Çàµ¿ »óÅÂ¿¡ µû¶ó ÀûÀýÇÑ	 ¸ð¼ÇÀ» Ã³¸®ÇÔ
		ProcessAniSpeed();						// °ø¼Ó ¾Ö´Ï¸ÞÀÌ¼Ç ¼Óµµ Á¶Àý.
	}

	{
		PROFILE( sw, r5 );

	#ifdef __X15
		for( int i = 0; i < 4; ++i )
	#endif
		{
			ProcessMovePattern();
			
			m_pActMover->ProcessAction( &vPos );

		#ifdef __CLIENT
			ProcessWalkSound();
#ifdef __TRAILS
			if (!IsFly())
			{
				ProcessTrails();
				//ProcessTrailsEvent();
			}
#endif // __TRAILS
		#endif //__CLIENT
			
			if( IsAnimate() )
			{
#if __VER >= 9	//__AI_0509
				FLOAT fFactor	= 1.0F;
				
				if( !( IsPlayer() && IsFly() ) && ( m_pActMover->IsState( OBJSTA_FMOVE ) || m_pActMover->IsState( OBJSTA_TURN_ALL ) ) )
				{
					int nMaxFrame	= pModel->GetMaxFrame();
					FLOAT fSpeed	= GetSpeed( m_pActMover->m_fSpeed );
//					FLOAT fMaxWidth	= pModel->GetMaxWidth();
//					FLOAT fMaxHeight	= pModel->GetMaxHeight();
					MoverProp* pProp	= GetProp();
					if( IsNPC() )
					{
						switch( pProp->dwAI )
						{
							case AII_MONSTER:
							case AII_PET:
							case AII_EGG:
							case AII_PARTY_AGGRO_LEADER:
							case AII_AGGRO_NORMAL:
							case AII_PARTY_AGGRO_SUB:							
#if __VER >= 19
							case AII_ARENA_REAPER:
#endif
								{
									fFactor	= fSpeed * nMaxFrame / 1.1F;
									break;
								}
						}
					}
					else
						fFactor	= fSpeed * nMaxFrame / 2.2F;

					if( fabs( pProp->fFrame - 0.0F ) < 0.000001F )		// 0ÀÌ¸é ¹«½Ã
						fFactor		= 1.0F;
					else if( pProp->dwFlying == 1 )
						fFactor		= 1.0F;
					else
						fFactor		*= pProp->fFrame;
					if( fabs( fFactor - 0.0F ) < 0.000001F )		// fFactor°¡ 0ÀÌ¸é ±âº» °ª
						fFactor		= 1.0F;
				}
				pModel->FrameMove( &vPos, m_fAniSpeed * fFactor );		// ¾Ö´Ï¸ÞÀÌ¼Ç ÇÁ·¹ÀÓ Áõ°¡
#else	// __AI_0509
				pModel->FrameMove( &vPos, m_fAniSpeed );		// ¾Ö´Ï¸ÞÀÌ¼Ç ÇÁ·¹ÀÓ Áõ°¡
#endif	// __AI_0509
			#ifdef __CLIENT			
				ProcessDustSFX();
			#endif // CLIENT
			}
		}	// for( 4 )
		
		if( m_nAtkCnt > 0 )		// °ø°ÝÇàÀ§¸¦ ÇÏ°í³­ ÀÌÈÄ´Â Ä«¿îÆ®°¡ °è¼Ó Áõ°¡ ÇÑ´Ù.
			++m_nAtkCnt;
	}
	/*
#ifdef __CLIENT
	if(this == g_pPlayer)
	{
		int n = 0;
	}
#endif*/
	{
		PROFILE( sw, r6 );
		bCollision = m_pActMover->ProcessCollision( &vPos );	// ÀÌµ¿¼ººÐ ´õÇÏ±â & Ãæµ¹Ã³¸®.
	}

#ifdef __CLIENT
	ProcessWaterCircle( vPosTemp, vPos );		// ¼ö¸é È¿°ú - Åõ¸íÀÌ ¾Æ´Ò¶§¸¸ Ãâ·Â
#endif

	{
		PROFILE( sw, r7 );
		ProcessIAObjLink( vPos );
	}

	{
		PROFILE( sw, r8 );
	#ifdef __CLIENT
		if( GetWorld()->GetLandscape( vPos ) )
	#endif
		{
			SetPos( vPos );
			if( bCollision )
				OnActCollision();
		}
	}

	{
		PROFILE( sw, r9 );
		ProcessRegion();
		ProcessQuest();
	#ifdef __WORLDSERVER
		ProcessDeleteRespawn();
	#endif // __WORLDSERVER
	}

	#ifdef __WORLDSERVER
	{
		PROFILE( sw, r10 );
		ProcessRegenItem();
		ProcessScript();
	}
	#endif	// __WORLDSERVER
	
	{
		PROFILE( sw, r11 );
	#ifdef __WORLDSERVER
		ProcessRecovery();	// È÷Æ®Æ÷ÀÎÆ®, ¸¶³ªÆ÷ÀÎÆ®, ÇÇ·ÎÆ÷ÀÎÆ® È¸º¹ ÇÏ±â  ÀÏ´ÜÀº ÇÃ·¹ÀÌ¾î¸¸ ÀÚµ¿À¸·Î Âù´Ù.
		ProcessAbnormalState();

		if( IsNPC() )
		{
#ifdef __DPSMETER_RYU
			if (m_bIsDPSMover && IsLive())
			{
				for (int i = 0; i < (int)m_aDPSPlayer.size(); i++)
				{
					CUser* pUserTemp = (CUser*)prj.GetUserByID(m_aDPSPlayer[i].m_idPlayer);
					if (IsValidObj(pUserTemp))
						pUserTemp->SendUpdateDPS(0, m_aDPSPlayer);

					if (IsValidObj(pUserTemp) && IsValidArea(pUserTemp, 64.0f) == FALSE)
					{
						pUserTemp->SendUpdateDPS(FALSE);
						m_aDPSPlayer.erase(m_aDPSPlayer.begin() + i);
					}


					if (IsInvalidObj(pUserTemp))
						m_aDPSPlayer.erase(m_aDPSPlayer.begin() + i);
	}
			}
#endif // __DPSMETER_RYU
//			if( m_nCollectOwnCnt > 0 )
//				--m_nCollectOwnCnt;

			if( (m_nCount & 127) == 0 )		// ¾à 8ÃÊ¸¸¿¡ ÇÑ¹ø¾¿
			{
				ProcessTarget();
				ProcInstantBanker();
				ProcInstantGC();
#ifdef __NEW_ITEM_VARUNA
				ProcBarunaPet();
#endif // __NEW_ITEM_VARUNA
			}
		}
	#endif // __WORLDSERVER

		if( IsPlayer() && IsLive() )
			ProcessActionPoint();
	}	
#ifdef __WORLDSERVER
	ProcessSFXDamage();
#endif	// __WORLDSERVER

#if defined(__CLIENT)
	ProcessETC();
	ProcessEyeFlash();

#if __VER >= 15 // __PETVIS
	if( NULL_ID != m_dwMoverSfxId && !m_pSfxBuffPet )		//gmpbigsun: buffpet effect
		SetSfxBuffPet( m_dwMoverSfxId );
#endif
#ifdef __WINGSFX
	if (GetWingSfx() != NULL_ID && !m_pSfxWing)
		SetWingSfx(GetWingSfx());

#endif
#endif //defined(__CLIENT) 

	++m_nCount;		// ¹«¹ö°¡ ¹ü¿ëÀ¸·Î ¾²´Â ¼øÂ÷Àû Ä«¿îÅÍ. »ý¼ºÀÚ ¿Ü¿£ 0À¸·Î ÃÊ±âÈ­ ÇÏÁö ¸»°Í.

}

#ifdef __CLIENT

#if __VER >= 8 //__CSC_VER8_5
void CMover::AngelMoveProcess()
{
	if( m_pAngelFlag && m_pAngel != NULL )
	{
		D3DXVECTOR3 vDist = GetPos() - m_AngelPos;
		FLOAT fDistSq = D3DXVec3LengthSq( &vDist );
		
		if(fDistSq > 100.0f * 100.0f) //Teleportµî °Å¸®°¡ ¸Ö¾îÁú °æ¿ì ´Ù½Ã »ý¼ºÇÏµµ·Ï ÇÔ.
		{
			if(m_pAngel)
				SAFE_DELETE(m_pAngel);
			m_pAngel = NULL;
			m_pAngelFlag = FALSE;
			return;
		}
		if( fDistSq > 1.0f * 1.0f )
		{
			D3DXVECTOR3 vf1 = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
			D3DXVECTOR3 vf2 = D3DXVECTOR3( 1.0f, 0.0f, 0.0f );
			D3DXVECTOR3 vf3;

			FLOAT fSerp = fDistSq / 10.0f;

			D3DXVec3Lerp( &vf3, &vf1, &vf2, fSerp );

			FLOAT fSpeed = 0.0f;
			m_AngelWorldM = m_matWorld;
			D3DXMATRIX mScal;			
			D3DXMatrixScaling( &mScal, 0.2f, 0.2f, 0.2f );	

			m_AngelWorldM = mScal * m_matRotation;

			D3DXVec3Normalize( &vDist, &vDist );

			fSpeed = GetSpeed( m_pActMover->m_fSpeed ) * vf3.x;

			vDist = vDist * fSpeed;

			m_AngelPos.x += vDist.x;
			m_AngelPos.y += vDist.y;
			m_AngelPos.z += vDist.z;

			m_AngelWorldM._41 = m_AngelPos.x;
			m_AngelWorldM._42 = m_AngelPos.y + 1.0f;
			m_AngelWorldM._43 = m_AngelPos.z;
		}

		CreateAngelParticle( m_AngelPos );
	}
}
#endif //__CSC_VER8_5

#ifdef __EVE_BALLOON
void CMover::BalloonMoveProcess()
{
	if( m_pBalloonFlag && m_pBalloon != NULL )
	{
		D3DXVECTOR3 vDist = GetPos() - m_BalloonPos;
		FLOAT fDistSq = D3DXVec3LengthSq( &vDist );
		
		D3DXMATRIX mScal, mRot;
		if(fDistSq > 100.0f * 100.0f) //Teleportµî °Å¸®°¡ ¸Ö¾îÁú °æ¿ì ´Ù½Ã »ý¼ºÇÏµµ·Ï ÇÔ.
		{
			if(m_pBalloon)
				SAFE_DELETE(m_pBalloon);
			m_pBalloon = NULL;
			m_pBalloonFlag = FALSE;
			return;
		}
		if( fDistSq > 1.0f * 1.0f )
		{
			D3DXVECTOR3 vf1 = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
			D3DXVECTOR3 vf2 = D3DXVECTOR3( 1.0f, 0.0f, 0.0f );
			D3DXVECTOR3 vf3;
			
			FLOAT fSerp = fDistSq / 10.0f;
			
			D3DXVec3Lerp( &vf3, &vf1, &vf2, fSerp );
			
			FLOAT fSpeed = 0.0f;
			m_BalloonWorldM = m_matWorld;			
			D3DXMatrixScaling( &mScal, 1.5f, 1.5f, 1.5f );	
			
			m_BalloonWorldM = mScal;// * m_matRotation;

			D3DXVec3Normalize( &vDist, &vDist );
			
			fSpeed = GetSpeed( m_pActMover->m_fSpeed ) * vf3.x;
			
			vDist = vDist * fSpeed;
			
			m_BalloonPos.x += vDist.x;
			m_BalloonPos.y += vDist.y;
			m_BalloonPos.z += vDist.z;
			
			m_BalloonWorldM._41 = m_BalloonPos.x;
			m_BalloonWorldM._42 = m_BalloonPos.y + m_fBalloonYPos;
			m_BalloonWorldM._43 = m_BalloonPos.z;

			if( m_bBalloon == TRUE )
			{
				m_fBalloonYPos += 0.006f;
				
				if( m_fBalloonYPos > 1.5 )
					m_bBalloon = FALSE;
			}
			else
			{
				m_fBalloonYPos -= 0.006f;
				
				if( m_fBalloonYPos < 0.5 )
					m_bBalloon = TRUE;
			}
		}
		else
		{
			m_BalloonWorldM = m_matWorld;
			D3DXMATRIX mScal;			
			D3DXMatrixScaling( &mScal, 1.5f, 1.5f, 1.5f );
			
			m_BalloonWorldM = mScal;// * m_matRotation;
			
			m_BalloonWorldM._41 = m_BalloonPos.x;
			m_BalloonWorldM._42 = m_BalloonPos.y + m_fBalloonYPos;
			m_BalloonWorldM._43 = m_BalloonPos.z;
			
			if( m_bBalloon == TRUE )
			{
				m_fBalloonYPos += 0.002f;
				
				if( m_fBalloonYPos > 1.3 )
					m_bBalloon = FALSE;
			}
			else
			{
				m_fBalloonYPos -= 0.002f;
				
				if( m_fBalloonYPos < 0.7 )
					m_bBalloon = TRUE;
			}
		}

		D3DXMatrixRotationY(&mRot,timeGetTime()/3000.0f);
		m_BalloonWorldM = mRot * m_BalloonWorldM;
	}
}
#endif //__EVE_BALLOON

void CMover::InitInterpolation()
{
	m_vScrPos	= GetPos();
	m_fScrAngle		= GetAngle();
	m_fScrAngleX	= GetAngleX();
#if __VER >= 9	//__AI_0509
	m_vOldRotate	= D3DXVECTOR3( 0.0F, 0.0F, 0.0F );
#endif	// __AI_0509

	D3DXMatrixTranslation( &m_matTrans, m_vScrPos.x, m_vScrPos.y, m_vScrPos.z );
	D3DXMATRIX matRotX;
	D3DXMatrixRotationX( &matRotX, D3DXToRadian( m_fScrAngleX ) );
	m_matRotation	*= matRotX;
	D3DXMatrixRotationYawPitchRoll( &m_matRotation, D3DXToRadian( -m_fScrAngle ), D3DXToRadian( -m_fScrAngleX ), 0 );
	SetUpdateMatrix( TRUE );
}

void CMover::Interpolate()
{
	D3DXVECTOR3 vPos;
	float fAngle, fAngleX;

	vPos	= GetPos();
	fAngle	= GetAngle();
	fAngleX	= GetAngleX();

	if( TRUE == IsActiveObj() )
	{
//		pos
		if( fabs( vPos.x - m_vScrPos.x ) > 0.001 || fabs( vPos.y - m_vScrPos.y ) > 0.001 || fabs( vPos.z - m_vScrPos.z ) > 0.001 )	// dif
		{
			m_vScrPos	= vPos;
			D3DXMatrixTranslation( &m_matTrans, m_vScrPos.x, m_vScrPos.y, m_vScrPos.z );
			SetUpdateMatrix( TRUE );
		}
//		angle
		if( fabs( fAngle - m_fScrAngle ) > 0.001 || fabs( fAngleX - m_fScrAngleX ) > 0.001 )
		{
			m_fScrAngle		= fAngle;
			D3DXMatrixRotationY( &m_matRotation, D3DXToRadian( -m_fScrAngle ) );


			m_fScrAngleX	= fAngleX;
			D3DXMATRIX matRotX;
			D3DXMatrixRotationX( &matRotX, D3DXToRadian( m_fScrAngleX ) );

			m_matRotation	*= matRotX;
			D3DXMatrixRotationYawPitchRoll( &m_matRotation, D3DXToRadian( -m_fScrAngle ), D3DXToRadian( -m_fScrAngleX ), 0 );
			SetUpdateMatrix( TRUE );
		}
	}
	else
	{
		float d;
//		pos
		if( fabs( vPos.x - m_vScrPos.x ) > 0.001 || fabs( vPos.y - m_vScrPos.y ) > 0.001 || fabs( vPos.z - m_vScrPos.z ) > 0.001 )	// dif
		{
			D3DXVECTOR3 v	= vPos - m_vScrPos;
			d	= D3DXVec3LengthSq( &v );
			if( d > 0.001 )
				m_vScrPos	+= v / 8;
			else
				m_vScrPos	= vPos;
			D3DXMatrixTranslation( &m_matTrans, m_vScrPos.x, m_vScrPos.y, m_vScrPos.z );
			SetUpdateMatrix( TRUE );
		}

//		angle
		if( fabs( fAngle - m_fScrAngle ) > 0.001 || fabs( fAngleX - m_fScrAngleX ) > 0.001 )
		{
			d	= fAngle - m_fScrAngle;
			if( fabs( d ) < 4 )
				m_fScrAngle		= fAngle;
			if( d < -180 )
				d	+= 360;
			else if( d > 180 )
				d	-= 360;
			
			m_fScrAngle		+= d / 8;

			if( m_fScrAngle > 360 )
				m_fScrAngle		-= 360;
			else if( m_fScrAngle < 0 )
				m_fScrAngle		+= 360;

			D3DXMatrixRotationY( &m_matRotation, D3DXToRadian( -m_fScrAngle ) );

			m_fScrAngleX	= fAngleX;
			if( m_fScrAngleX > 45 )
				m_fScrAngleX	= 45;
			else if( m_fScrAngleX < -45 )
				m_fScrAngleX	= -45;

			D3DXMATRIX matRotX;
			D3DXMatrixRotationX( &matRotX, D3DXToRadian( m_fScrAngleX ) );

			m_matRotation	*= matRotX;
			D3DXMatrixRotationYawPitchRoll( &m_matRotation, D3DXToRadian( -m_fScrAngle ), D3DXToRadian( -m_fScrAngleX ), 0 );

#if __VER >= 9	//__AI_0509
			if( 0 )	//if( GetProp()->dwOrthograde == 0 && fabs( m_pWorld->GetLandHeight( m_vScrPos ) - m_vScrPos.y ) < 0.1F )
			{
				D3DXVECTOR3 vScrPos	= m_vScrPos;
				D3DXVECTOR3 vec3Tri[3];
				GetWorld()->GetLandTri( vScrPos.x, vScrPos.z, vec3Tri );
				D3DXVECTOR3 vVector1 = vec3Tri[2] - vec3Tri[0];
				D3DXVECTOR3 vVector2 = vec3Tri[1] - vec3Tri[0];
				D3DXVECTOR3 vNormal;
				D3DXVec3Cross( &vNormal, &vVector1, &vVector2);	
				D3DXVec3Normalize( &vNormal, &vNormal );
				
				D3DXVECTOR3 v3Up = D3DXVECTOR3( 0.0f, -1.0f, 0.0f );
				D3DXVECTOR3 v3Cross;
				FLOAT fDot;
				FLOAT fTheta;
				D3DXVec3Cross( &v3Cross, &v3Up, &vNormal );
				fDot = D3DXVec3Dot( &v3Up, &vNormal );
				fTheta = acos( fDot );
				
				D3DXQUATERNION qDirMap;
				D3DXQuaternionRotationAxis( &qDirMap, &v3Cross, fTheta );
				
				D3DXVECTOR3 vYPW;
				QuaternionRotationToYPW( qDirMap, vYPW );

				D3DXVECTOR3 vRotate;
				vRotate.x = D3DXToDegree(vYPW.x);
				vRotate.y = D3DXToDegree(vYPW.y);
				vRotate.z = D3DXToDegree(vYPW.z);

				d	= vRotate.x - m_vOldRotate.x;
				if( d < -180 )
					d	+= 360;
				else if( d > 180 )
					d	-= 360;
	//			if( d > 0.5F )
					vRotate.x	= m_vOldRotate.x + d / 4.0F;

				if( vRotate.x > 360 )
					vRotate.x	-= 360;
				else if( vRotate.x < 0 )
					vRotate.x	+= 360;

				d	= vRotate.z - m_vOldRotate.z;
				if( d < -180 )
					d	+= 360;
				else if( d > 180 )
					d	-= 360;
	//			if( d > 0.5F )
					vRotate.z	= m_vOldRotate.z + d / 4.0F;

				if( vRotate.z > 360 )
					vRotate.z	-= 360;
				else if( vRotate.z < 0 )
					vRotate.z	+= 360;

				d	= vRotate.y - m_vOldRotate.y;
				if( d < -180 )
					d	+= 360;
				else if( d > 180 )
					d	-= 360;
	//			if( d > 0.5F )
					vRotate.y	= m_vOldRotate.y + d / 4.0F;

				if( vRotate.y > 360 )
					vRotate.y	-= 360;
				else if( vRotate.y < 0 )
					vRotate.y	+= 360;
				
				m_vOldRotate	= vRotate;

				D3DXMATRIX matRotLand;
				D3DXMatrixRotationYawPitchRoll( &matRotLand, D3DXToRadian( vRotate.y ), D3DXToRadian( vRotate.x ), D3DXToRadian( vRotate.z ) );
				m_matRotation	*= matRotLand;
			}
#endif	// __AI_0509
			SetUpdateMatrix( TRUE );
		}
	}
}
void CMover::CreateAbilityOption_SetItemSFX( int nAbilityOption )
{
	DWORD dwSfx = 0;

#ifdef __JOPS_GLOW
	DWORD dwSfxHandRight = 0;
	DWORD dwSfxHandLeft = 0;
	DWORD dwSfxArmRight = 0;
	DWORD dwSfxArmLeft = 0;
	DWORD dwSfxBody = 0;
	DWORD dwSfxLegLeft = 0;
	DWORD dwSfxLegRight = 0;
	switch (m_iGlowBody)
	{
	case 0: dwSfxBody = XI_GEN_ITEM_SETITEM10; break;
	case 1: dwSfxBody = XI_GEN_ITEM_SETITEM101; break;
	case 2: dwSfxBody = XI_GEN_ITEM_SETITEM102; break;
	case 3: dwSfxBody = XI_GEN_ITEM_SETITEM103; break;
	case 4: dwSfxBody = XI_GEN_ITEM_SETITEM104; break;
	case 5: dwSfxBody = XI_GEN_ITEM_SETITEM105; break;
	case 6: dwSfxBody = XI_GEN_ITEM_SETITEM106; break;
	case 7: dwSfxBody = XI_GEN_ITEM_SETITEM107; break;
	case 8: dwSfxBody = XI_GEN_ITEM_SETITEM108; break;
	case 9: dwSfxBody = XI_GEN_ITEM_SETITEM109; break;
	case 10: dwSfxBody = XI_GEN_ITEM_SETITEM1010; break;
	case 11: dwSfxBody = XI_GEN_ITEM_SETITEM1011; break;
	case 12: dwSfxBody = XI_GEN_ITEM_SETITEM1012; break;
	case 13: dwSfxBody = XI_GEN_ITEM_SETITEM1013; break;
	case 14: dwSfxBody = XI_GEN_ITEM_SETITEM1014; break;
	case 15: dwSfxBody = XI_GEN_ITEM_SETITEM1015; break;

	default: dwSfxBody = XI_GEN_ITEM_SETITEM10; break;
	}
	switch (m_iGlowArmLeft)
	{
	case 0: dwSfxArmLeft = XI_GEN_ITEM_SETITEM10; break;
	case 1: dwSfxArmLeft = XI_GEN_ITEM_SETITEM101; break;
	case 2: dwSfxArmLeft = XI_GEN_ITEM_SETITEM102; break;
	case 3: dwSfxArmLeft = XI_GEN_ITEM_SETITEM103; break;
	case 4: dwSfxArmLeft = XI_GEN_ITEM_SETITEM104; break;
	case 5: dwSfxArmLeft = XI_GEN_ITEM_SETITEM105; break;
	case 6: dwSfxArmLeft = XI_GEN_ITEM_SETITEM106; break;
	case 7: dwSfxArmLeft = XI_GEN_ITEM_SETITEM107; break;
	case 8: dwSfxArmLeft = XI_GEN_ITEM_SETITEM108; break;
	case 9: dwSfxArmLeft = XI_GEN_ITEM_SETITEM109; break;
	case 10: dwSfxArmLeft = XI_GEN_ITEM_SETITEM1010; break;
	case 11: dwSfxArmLeft = XI_GEN_ITEM_SETITEM1011; break;
	case 12: dwSfxArmLeft = XI_GEN_ITEM_SETITEM1012; break;
	case 13: dwSfxArmLeft = XI_GEN_ITEM_SETITEM1013; break;
	case 14: dwSfxArmLeft = XI_GEN_ITEM_SETITEM1014; break;
	case 15: dwSfxArmLeft = XI_GEN_ITEM_SETITEM1015; break;

	default: dwSfxArmLeft = XI_GEN_ITEM_SETITEM10; break;
	}
	switch (m_iGlowArmRight)
	{
	case 0: dwSfxArmRight = XI_GEN_ITEM_SETITEM10; break;
	case 1: dwSfxArmRight = XI_GEN_ITEM_SETITEM101; break;
	case 2: dwSfxArmRight = XI_GEN_ITEM_SETITEM102; break;
	case 3: dwSfxArmRight = XI_GEN_ITEM_SETITEM103; break;
	case 4: dwSfxArmRight = XI_GEN_ITEM_SETITEM104; break;
	case 5: dwSfxArmRight = XI_GEN_ITEM_SETITEM105; break;
	case 6: dwSfxArmRight = XI_GEN_ITEM_SETITEM106; break;
	case 7: dwSfxArmRight = XI_GEN_ITEM_SETITEM107; break;
	case 8: dwSfxArmRight = XI_GEN_ITEM_SETITEM108; break;
	case 9: dwSfxArmRight = XI_GEN_ITEM_SETITEM109; break;
	case 10: dwSfxArmRight = XI_GEN_ITEM_SETITEM1010; break;
	case 11: dwSfxArmRight = XI_GEN_ITEM_SETITEM1011; break;
	case 12: dwSfxArmRight = XI_GEN_ITEM_SETITEM1012; break;
	case 13: dwSfxArmRight = XI_GEN_ITEM_SETITEM1013; break;
	case 14: dwSfxArmRight = XI_GEN_ITEM_SETITEM1014; break;
	case 15: dwSfxArmRight = XI_GEN_ITEM_SETITEM1015; break;

	default: dwSfxArmRight = XI_GEN_ITEM_SETITEM10; break;
	}
	switch (m_iGlowLegLeft)
	{
	case 0: dwSfxLegLeft = XI_GEN_ITEM_SETITEM10; break;
	case 1: dwSfxLegLeft = XI_GEN_ITEM_SETITEM101; break;
	case 2: dwSfxLegLeft = XI_GEN_ITEM_SETITEM102; break;
	case 3: dwSfxLegLeft = XI_GEN_ITEM_SETITEM103; break;
	case 4: dwSfxLegLeft = XI_GEN_ITEM_SETITEM104; break;
	case 5: dwSfxLegLeft = XI_GEN_ITEM_SETITEM105; break;
	case 6: dwSfxLegLeft = XI_GEN_ITEM_SETITEM106; break;
	case 7: dwSfxLegLeft = XI_GEN_ITEM_SETITEM107; break;
	case 8: dwSfxLegLeft = XI_GEN_ITEM_SETITEM108; break;
	case 9: dwSfxLegLeft = XI_GEN_ITEM_SETITEM109; break;
	case 10: dwSfxLegLeft = XI_GEN_ITEM_SETITEM1010; break;
	case 11: dwSfxLegLeft = XI_GEN_ITEM_SETITEM1011; break;
	case 12: dwSfxLegLeft = XI_GEN_ITEM_SETITEM1012; break;
	case 13: dwSfxLegLeft = XI_GEN_ITEM_SETITEM1013; break;
	case 14: dwSfxLegLeft = XI_GEN_ITEM_SETITEM1014; break;
	case 15: dwSfxLegLeft = XI_GEN_ITEM_SETITEM1015; break;

	default: dwSfxLegLeft = XI_GEN_ITEM_SETITEM10; break;
	}
	switch (m_iGlowLegRight)
	{
	case 0: dwSfxLegRight = XI_GEN_ITEM_SETITEM10; break;
	case 1: dwSfxLegRight = XI_GEN_ITEM_SETITEM101; break;
	case 2: dwSfxLegRight = XI_GEN_ITEM_SETITEM102; break;
	case 3: dwSfxLegRight = XI_GEN_ITEM_SETITEM103; break;
	case 4: dwSfxLegRight = XI_GEN_ITEM_SETITEM104; break;
	case 5: dwSfxLegRight = XI_GEN_ITEM_SETITEM105; break;
	case 6: dwSfxLegRight = XI_GEN_ITEM_SETITEM106; break;
	case 7: dwSfxLegRight = XI_GEN_ITEM_SETITEM107; break;
	case 8: dwSfxLegRight = XI_GEN_ITEM_SETITEM108; break;
	case 9: dwSfxLegRight = XI_GEN_ITEM_SETITEM109; break;
	case 10: dwSfxLegRight = XI_GEN_ITEM_SETITEM1010; break;
	case 11: dwSfxLegRight = XI_GEN_ITEM_SETITEM1011; break;
	case 12: dwSfxLegRight = XI_GEN_ITEM_SETITEM1012; break;
	case 13: dwSfxLegRight = XI_GEN_ITEM_SETITEM1013; break;
	case 14: dwSfxLegRight = XI_GEN_ITEM_SETITEM1014; break;
	case 15: dwSfxLegRight = XI_GEN_ITEM_SETITEM1015; break;

	default: dwSfxLegRight = XI_GEN_ITEM_SETITEM10; break;
	}


	switch (m_iGlowHandRight)
	{
	case 0: dwSfxHandRight = XI_SETIEM_EFFECTHAND; break;
	case 1: dwSfxHandRight = XI_SETIEM_EFFECTHAND1; break;
	case 2: dwSfxHandRight = XI_SETIEM_EFFECTHAND2; break;
	case 3: dwSfxHandRight = XI_SETIEM_EFFECTHAND3; break;
	case 4: dwSfxHandRight = XI_SETIEM_EFFECTHAND4; break;
	case 5: dwSfxHandRight = XI_SETIEM_EFFECTHAND5; break;
	case 6: dwSfxHandRight = XI_SETIEM_EFFECTHAND6; break;
	case 7: dwSfxHandRight = XI_SETIEM_EFFECTHAND7; break;
	case 8: dwSfxHandRight = XI_SETIEM_EFFECTHAND8; break;
	case 9: dwSfxHandRight = XI_SETIEM_EFFECTHAND9; break;
	case 10: dwSfxHandRight = XI_SETIEM_EFFECTHAND10; break;
	case 11: dwSfxHandRight = XI_SETIEM_EFFECTHAND11; break;
	case 12: dwSfxHandRight = XI_SETIEM_EFFECTHAND12; break;
	case 13: dwSfxHandRight = XI_SETIEM_EFFECTHAND13; break;
	case 14: dwSfxHandRight = XI_SETIEM_EFFECTHAND14; break;
	case 15: dwSfxHandRight = XI_SETIEM_EFFECTHAND15; break;
	case 16: dwSfxHandRight = XI_SETIEM_EFFECTHAND16; break;
	case 17: dwSfxHandRight = XI_SETIEM_EFFECTHAND17; break;
	case 18: dwSfxHandRight = XI_SETIEM_EFFECTHAND18; break;
	case 19: dwSfxHandRight = XI_SETIEM_EFFECTHAND19; break;
	case 20: dwSfxHandRight = XI_SETIEM_EFFECTHAND20; break;
	case 21: dwSfxHandRight = XI_SETIEM_EFFECTHAND21; break;
	case 22: dwSfxHandRight = XI_SETIEM_EFFECTHAND22; break;
	case 23: dwSfxHandRight = XI_SETIEM_EFFECTHAND23; break;

	default: dwSfxHandRight = XI_SETIEM_EFFECTHAND; break; // unchanged // more / less than highest / lowest
	}
	switch (m_iGlowHandLeft)
	{
	case 0: dwSfxHandLeft = XI_SETIEM_EFFECTHAND; break;
	case 1: dwSfxHandLeft = XI_SETIEM_EFFECTHAND1; break;
	case 2: dwSfxHandLeft = XI_SETIEM_EFFECTHAND2; break;
	case 3: dwSfxHandLeft = XI_SETIEM_EFFECTHAND3; break;
	case 4: dwSfxHandLeft = XI_SETIEM_EFFECTHAND4; break;
	case 5: dwSfxHandLeft = XI_SETIEM_EFFECTHAND5; break;
	case 6: dwSfxHandLeft = XI_SETIEM_EFFECTHAND6; break;
	case 7: dwSfxHandLeft = XI_SETIEM_EFFECTHAND7; break;
	case 8: dwSfxHandLeft = XI_SETIEM_EFFECTHAND8; break;
	case 9: dwSfxHandLeft = XI_SETIEM_EFFECTHAND9; break;
	case 10: dwSfxHandLeft = XI_SETIEM_EFFECTHAND10; break;
	case 11: dwSfxHandLeft = XI_SETIEM_EFFECTHAND11; break;
	case 12: dwSfxHandLeft = XI_SETIEM_EFFECTHAND12; break;
	case 13: dwSfxHandLeft = XI_SETIEM_EFFECTHAND13; break;
	case 14: dwSfxHandLeft = XI_SETIEM_EFFECTHAND14; break;
	case 15: dwSfxHandLeft = XI_SETIEM_EFFECTHAND15; break;
	case 16: dwSfxHandLeft = XI_SETIEM_EFFECTHAND16; break;
	case 17: dwSfxHandLeft = XI_SETIEM_EFFECTHAND17; break;
	case 18: dwSfxHandLeft = XI_SETIEM_EFFECTHAND18; break;
	case 19: dwSfxHandLeft = XI_SETIEM_EFFECTHAND19; break;
	case 20: dwSfxHandLeft = XI_SETIEM_EFFECTHAND20; break;
	case 21: dwSfxHandLeft = XI_SETIEM_EFFECTHAND21; break;
	case 22: dwSfxHandLeft = XI_SETIEM_EFFECTHAND22; break;
	case 23: dwSfxHandLeft = XI_SETIEM_EFFECTHAND23; break;

	default: dwSfxHandLeft = XI_SETIEM_EFFECTHAND; break; // unchanged // more / less than highest / lowest
	}
#else				switch( nAbilityOption ) 
	{
	case 3: dwSfx = XI_GEN_ITEM_SETITEM03; break; // blue
	case 4: dwSfx = XI_GEN_ITEM_SETITEM04; break; // blue
	case 5: dwSfx = XI_GEN_ITEM_SETITEM05; break; // yellow
	case 6: dwSfx = XI_GEN_ITEM_SETITEM06; break; // yellow
	case 7: dwSfx = XI_GEN_ITEM_SETITEM07; break; // red
	case 8: dwSfx = XI_GEN_ITEM_SETITEM08; break; // red
	case 9: dwSfx = XI_GEN_ITEM_SETITEM09; break; // lila
	case 10: dwSfx = XI_GEN_ITEM_SETITEM10; break; // lila
	}
#endif
	
	CSfxPartsLinkShoulder* pSfx = NULL;
	D3DXVECTOR3 v3Scal = D3DXVECTOR3( 1.0f, 1.0f, 1.0f );

#ifdef __JOPS_GLOW
	//0 4 8 2 = rechter arm
	//1 5 9 3 = linker arm
	//6 7	  = Body
	//26      = linkes bein
	//29      = rechtes bein
	//8       = rechte Hand
	//9       = linke Hand
	pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfxArmRight, GetPos(), GetId(), GetPos(), GetId(), -1); // rechte schulter
	pSfx->m_nPartsLink = 0;
	pSfx->m_iGlowBody = m_iGlowBody;
	pSfx->m_iGlowHandLeft = m_iGlowHandLeft;
	pSfx->m_iGlowHandRight = m_iGlowHandRight;
	pSfx->m_iGlowArmLeft = m_iGlowArmLeft;
	pSfx->m_iGlowArmRight = m_iGlowArmRight;
	pSfx->m_iGlowLegLeft = m_iGlowLegLeft;
	pSfx->m_iGlowLegRight = m_iGlowLegRight;
	pSfx->m_nOldAbilityOption = nAbilityOption;


	pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfxArmLeft, GetPos(), GetId(), GetPos(), GetId(), -1); // linke schulter
	pSfx->m_nPartsLink = 1;
	pSfx->m_iGlowBody = m_iGlowBody;
	pSfx->m_iGlowHandLeft = m_iGlowHandLeft;
	pSfx->m_iGlowHandRight = m_iGlowHandRight;
	pSfx->m_iGlowArmLeft = m_iGlowArmLeft;
	pSfx->m_iGlowArmRight = m_iGlowArmRight;
	pSfx->m_iGlowLegLeft = m_iGlowLegLeft;
	pSfx->m_iGlowLegRight = m_iGlowLegRight;
	pSfx->m_nOldAbilityOption = nAbilityOption;
	// ¾î±ú, ÆÈ¸ñ Áß°£


	pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfxArmRight, GetPos(), GetId(), GetPos(), GetId(), -1); // rechter oberarm
	pSfx->m_nPartsLink = 4;
	pSfx->m_iGlowBody = m_iGlowBody;
	pSfx->m_iGlowHandLeft = m_iGlowHandLeft;
	pSfx->m_iGlowHandRight = m_iGlowHandRight;
	pSfx->m_iGlowArmLeft = m_iGlowArmLeft;
	pSfx->m_iGlowArmRight = m_iGlowArmRight;
	pSfx->m_iGlowLegLeft = m_iGlowLegLeft;
	pSfx->m_iGlowLegRight = m_iGlowLegRight;


	pSfx->m_nOldAbilityOption = nAbilityOption;
	pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfxArmLeft, GetPos(), GetId(), GetPos(), GetId(), -1); // linker oberarm
	pSfx->m_nPartsLink = 5;
	pSfx->m_iGlowBody = m_iGlowBody;
	pSfx->m_iGlowHandLeft = m_iGlowHandLeft;
	pSfx->m_iGlowHandRight = m_iGlowHandRight;
	pSfx->m_iGlowArmLeft = m_iGlowArmLeft;
	pSfx->m_iGlowArmRight = m_iGlowArmRight;
	pSfx->m_iGlowLegLeft = m_iGlowLegLeft;
	pSfx->m_iGlowLegRight = m_iGlowLegRight;


	pSfx->m_nOldAbilityOption = nAbilityOption;
	// ¸öÅë
	pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfxBody, GetPos(), GetId(), GetPos(), GetId(), -1); // Kopf, vorne, brust
	pSfx->m_nPartsLink = 6;
	pSfx->SetScale(D3DXVECTOR3(3.0f, 4.5f, 3.0f));
	pSfx->m_iGlowBody = m_iGlowBody;
	pSfx->m_iGlowHandLeft = m_iGlowHandLeft;
	pSfx->m_iGlowHandRight = m_iGlowHandRight;
	pSfx->m_iGlowArmLeft = m_iGlowArmLeft;
	pSfx->m_iGlowArmRight = m_iGlowArmRight;
	pSfx->m_iGlowLegLeft = m_iGlowLegLeft;
	pSfx->m_iGlowLegRight = m_iGlowLegRight;


	pSfx->m_nOldAbilityOption = nAbilityOption;
	pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfxBody, GetPos(), GetId(), GetPos(), GetId(), -1); // Kopf, vorne, brust
	pSfx->m_nPartsLink = 7;
	pSfx->SetScale(D3DXVECTOR3(3.0f, 3.0f, 3.0f));
	pSfx->m_iGlowBody = m_iGlowBody;
	pSfx->m_iGlowHandLeft = m_iGlowHandLeft;
	pSfx->m_iGlowHandRight = m_iGlowHandRight;
	pSfx->m_iGlowArmLeft = m_iGlowArmLeft;
	pSfx->m_iGlowArmRight = m_iGlowArmRight;
	pSfx->m_iGlowLegLeft = m_iGlowLegLeft;
	pSfx->m_iGlowLegRight = m_iGlowLegRight;


	pSfx->m_nOldAbilityOption = nAbilityOption;
	// ¼Õ	
	pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfxArmRight, GetPos(), GetId(), GetPos(), GetId(), -1); // rechter arm
	pSfx->m_nPartsLink = 8;
	//pSfx->m_v3Offset.y = 0.1f;
	pSfx->m_iGlowBody = m_iGlowBody;
	pSfx->m_iGlowHandLeft = m_iGlowHandLeft;
	pSfx->m_iGlowHandRight = m_iGlowHandRight;
	pSfx->m_iGlowArmLeft = m_iGlowArmLeft;
	pSfx->m_iGlowArmRight = m_iGlowArmRight;
	pSfx->m_iGlowLegLeft = m_iGlowLegLeft;
	pSfx->m_iGlowLegRight = m_iGlowLegRight;


	pSfx->m_nOldAbilityOption = nAbilityOption;
	pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfxArmLeft, GetPos(), GetId(), GetPos(), GetId(), -1); // linker arm
	pSfx->m_nPartsLink = 9;
	//pSfx->m_v3Offset.y = 0.1f;
	pSfx->m_iGlowBody = m_iGlowBody;
	pSfx->m_iGlowHandLeft = m_iGlowHandLeft;
	pSfx->m_iGlowHandRight = m_iGlowHandRight;
	pSfx->m_iGlowArmLeft = m_iGlowArmLeft;
	pSfx->m_iGlowArmRight = m_iGlowArmRight;
	pSfx->m_iGlowLegLeft = m_iGlowLegLeft;
	pSfx->m_iGlowLegRight = m_iGlowLegRight;


	pSfx->m_nOldAbilityOption = nAbilityOption;
	// ÆÈ¸ñ
	pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfxArmRight, GetPos(), GetId(), GetPos(), GetId(), -1); // rechter oberarm
	pSfx->m_nPartsLink = 2;
	pSfx->m_iGlowBody = m_iGlowBody;
	pSfx->m_iGlowHandLeft = m_iGlowHandLeft;
	pSfx->m_iGlowHandRight = m_iGlowHandRight;
	pSfx->m_iGlowArmLeft = m_iGlowArmLeft;
	pSfx->m_iGlowArmRight = m_iGlowArmRight;
	pSfx->m_iGlowLegLeft = m_iGlowLegLeft;
	pSfx->m_iGlowLegRight = m_iGlowLegRight;

	pSfx->m_nOldAbilityOption = nAbilityOption;
	pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfxArmLeft, GetPos(), GetId(), GetPos(), GetId(), -1); // linker unterarm
	pSfx->m_nPartsLink = 3;
	pSfx->m_iGlowBody = m_iGlowBody;
	pSfx->m_iGlowHandLeft = m_iGlowHandLeft;
	pSfx->m_iGlowHandRight = m_iGlowHandRight;
	pSfx->m_iGlowArmLeft = m_iGlowArmLeft;
	pSfx->m_iGlowArmRight = m_iGlowArmRight;
	pSfx->m_iGlowLegLeft = m_iGlowLegLeft;
	pSfx->m_iGlowLegRight = m_iGlowLegRight;
	pSfx->m_nOldAbilityOption = nAbilityOption;
	// ¹ß
	pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfxLegLeft, GetPos(), GetId(), GetPos(), GetId(), -1); // linkes knie
	pSfx->m_nPartsLink = 26;
	pSfx->m_iGlowBody = m_iGlowBody;
	pSfx->m_iGlowHandLeft = m_iGlowHandLeft;
	pSfx->m_iGlowHandRight = m_iGlowHandRight;
	pSfx->m_iGlowArmLeft = m_iGlowArmLeft;
	pSfx->m_iGlowArmRight = m_iGlowArmRight;
	pSfx->m_iGlowLegLeft = m_iGlowLegLeft;
	pSfx->m_iGlowLegRight = m_iGlowLegRight;
	pSfx->m_nOldAbilityOption = nAbilityOption;

	pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfxLegRight, GetPos(), GetId(), GetPos(), GetId(), -1); // rechtes knie
	pSfx->m_nPartsLink = 29;
	pSfx->m_iGlowBody = m_iGlowBody;
	pSfx->m_iGlowHandLeft = m_iGlowHandLeft;
	pSfx->m_iGlowHandRight = m_iGlowHandRight;
	pSfx->m_iGlowArmLeft = m_iGlowArmLeft;
	pSfx->m_iGlowArmRight = m_iGlowArmRight;
	pSfx->m_iGlowLegLeft = m_iGlowLegLeft;
	pSfx->m_iGlowLegRight = m_iGlowLegRight;
	pSfx->m_nOldAbilityOption = nAbilityOption;




	pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfxHandRight, GetPos(), GetId(), GetPos(), GetId(), -1); //rechte Hand
	pSfx->m_nPartsLink = 8;
	pSfx->m_v3Offset.y = 0.2f;
	pSfx->m_iGlowBody = m_iGlowBody;
	pSfx->m_iGlowHandLeft = m_iGlowHandLeft;
	pSfx->m_iGlowHandRight = m_iGlowHandRight;
	pSfx->m_iGlowArmLeft = m_iGlowArmLeft;
	pSfx->m_iGlowArmRight = m_iGlowArmRight;
	pSfx->m_iGlowLegLeft = m_iGlowLegLeft;
	pSfx->m_iGlowLegRight = m_iGlowLegRight;
	pSfx->m_nOldAbilityOption = nAbilityOption;


	pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfxHandLeft, GetPos(), GetId(), GetPos(), GetId(), -1); // linke Hand
	pSfx->m_nPartsLink = 9;
	pSfx->m_v3Offset.y = 0.2f;
	pSfx->m_iGlowBody = m_iGlowBody;
	pSfx->m_iGlowHandLeft = m_iGlowHandLeft;
	pSfx->m_iGlowHandRight = m_iGlowHandRight;
	pSfx->m_iGlowArmLeft = m_iGlowArmLeft;
	pSfx->m_iGlowArmRight = m_iGlowArmRight;
	pSfx->m_iGlowLegLeft = m_iGlowLegLeft;
	pSfx->m_iGlowLegRight = m_iGlowLegRight;
	pSfx->m_nOldAbilityOption = nAbilityOption;



#else



	if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_15DAY))
	{
		dwSfx = XI_GEN_ITEM_SETITEM03_GOLD; break;
	}




	else
		if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_RED_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_RED_15DAY))
		{
			dwSfx = XI_GEN_ITEM_SETITEM03_RED; break;
		}
		else
			if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_15DAY))
			{
				dwSfx = XI_GEN_ITEM_SETITEM03_BLACK; break;
			}
			else
				if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_15DAY))
				{
					dwSfx = XI_GEN_ITEM_SETITEM03_PUPPLE; break;
				}
				else
					if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_15DAY))
					{
						dwSfx = XI_GEN_ITEM_SETITEM03_GREEN; break;
					}
					else
						if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY))
						{
							dwSfx = XI_GEN_ITEM_SETITEM03_WHITE; break;
						}

						else

							if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX1)
							{
								dwSfx = XI_GEN_ITEM_SETITEM03_GOLD; break;
							}
							else

								if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX2)
								{
									dwSfx = XI_GEN_ITEM_SETITEM03_PUPPLE; break;
								}

								else
								{
									dwSfx = XI_GEN_ITEM_SETITEM03; break;
								}
		}
	case 4:
	{
		if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_15DAY))
		{
			dwSfx = XI_GEN_ITEM_SETITEM04_GOLD; break;
		}
		else
			if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_RED_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_RED_15DAY))
			{
				dwSfx = XI_GEN_ITEM_SETITEM04_RED; break;
			}
			else
				if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_15DAY))
				{
					dwSfx = XI_GEN_ITEM_SETITEM04_BLACK; break;
				}
				else
					if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_15DAY))
					{
						dwSfx = XI_GEN_ITEM_SETITEM04_PUPPLE; break;
					}
					else
						if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_15DAY))
						{
							dwSfx = XI_GEN_ITEM_SETITEM04_GREEN; break;
						}
						else
							if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY))
							{
								dwSfx = XI_GEN_ITEM_SETITEM04_WHITE; break;
							}


							else
								if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX1)
								{
									dwSfx = XI_GEN_ITEM_SETITEM04_GOLD; break;
								}

								else
									if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX2)
									{
										dwSfx = XI_GEN_ITEM_SETITEM04_PUPPLE; break;
									}



									else
									{
										dwSfx = XI_GEN_ITEM_SETITEM04; break;
									}
					}
	case 5:
	{
		if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_15DAY))
		{
			dwSfx = XI_GEN_ITEM_SETITEM05_GOLD; break;
		}
		else
			if (HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_RED_7DAY) || HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_RED_15DAY))
			{
				dwSfx = XI_GEN_ITEM_SETITEM05_RED; break;
			}
			else
				if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_15DAY))
				{
					dwSfx = XI_GEN_ITEM_SETITEM05_BLACK; break;
				}
				else
					if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_15DAY))
					{
						dwSfx = XI_GEN_ITEM_SETITEM05_PUPPLE; break;
					}
					else
						if (HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_7DAY) || HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_15DAY))
						{
							dwSfx = XI_GEN_ITEM_SETITEM05_GREEN; break;
						}
						else
							if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY))
							{
								dwSfx = XI_GEN_ITEM_SETITEM05_WHITE; break;
							}


							else
								if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX1)
								{
									dwSfx = XI_GEN_ITEM_SETITEM05_GOLD; break;
								}

								else
									if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX2)
									{
										dwSfx = XI_GEN_ITEM_SETITEM05_PUPPLE; break;
									}



									else
									{
										dwSfx = XI_GEN_ITEM_SETITEM05; break;
									}
	}
	case 6:
	{
		if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_15DAY))
		{
			dwSfx = XI_GEN_ITEM_SETITEM06_GOLD; break;
		}
		else
			if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_RED_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_RED_15DAY))
			{
				dwSfx = XI_GEN_ITEM_SETITEM06_RED; break;
			}
			else
				if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_15DAY))
				{
					dwSfx = XI_GEN_ITEM_SETITEM06_BLACK; break;
				}
				else
					if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_15DAY))
					{
						dwSfx = XI_GEN_ITEM_SETITEM06_PUPPLE; break;
					}
					else
						if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_15DAY))
						{
							dwSfx = XI_GEN_ITEM_SETITEM06_GREEN; break;
						}
						else
							if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY))
							{
								dwSfx = XI_GEN_ITEM_SETITEM06_WHITE; break;
							}

							else
								if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX1)
								{
									dwSfx = XI_GEN_ITEM_SETITEM06_GOLD; break;
								}

								else
									if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX2)
									{
										dwSfx = XI_GEN_ITEM_SETITEM06_PUPPLE; break;
									}



									else
									{
										dwSfx = XI_GEN_ITEM_SETITEM06; break;
									}
	}
	case 7:
	{
		if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_15DAY))
		{
			dwSfx = XI_GEN_ITEM_SETITEM07_GOLD; break;
		}
		else
			if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_RED_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_RED_15DAY))
			{
				dwSfx = XI_GEN_ITEM_SETITEM07_RED; break;
			}
			else
				if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_15DAY))
				{
					dwSfx = XI_GEN_ITEM_SETITEM07_BLACK; break;
				}
				else
					if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_15DAY))
					{
						dwSfx = XI_GEN_ITEM_SETITEM07_PUPPLE; break;
					}
					else
						if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_15DAY))
						{
							dwSfx = XI_GEN_ITEM_SETITEM07_GREEN; break;
						}
						else
							if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY))
							{
								dwSfx = XI_GEN_ITEM_SETITEM07_WHITE; break;
							}


							else
								if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX1)
								{
									dwSfx = XI_GEN_ITEM_SETITEM07_GOLD; break;
								}

								else
									if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX2)
									{
										dwSfx = XI_GEN_ITEM_SETITEM07_PUPPLE; break;
									}



									else
									{
										dwSfx = XI_GEN_ITEM_SETITEM07; break;
									}
	}
	case 8:
	{
		if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_15DAY))
		{
			dwHandSfx = XI_SETIEM_EFFECTHAND_GOLD;
			dwSfx = XI_GEN_ITEM_SETITEM08_GOLD; break;
		}
		else
			if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_RED_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_RED_15DAY))
			{
				dwHandSfx = XI_SETIEM_EFFECTHAND_RED;
				dwSfx = XI_GEN_ITEM_SETITEM08_RED; break;
			}
			else
				if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_15DAY))
				{
					dwHandSfx = XI_SETIEM_EFFECTHAND_BLACK;
					dwSfx = XI_GEN_ITEM_SETITEM08_BLACK; break;
				}
				else
					if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_15DAY))
					{
						dwHandSfx = XI_SETIEM_EFFECTHAND_PUPPLE;
						dwSfx = XI_GEN_ITEM_SETITEM08_PUPPLE; break;
					}
					else
						if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_15DAY))
						{
							dwHandSfx = XI_SETIEM_EFFECTHAND_GREEN;
							dwSfx = XI_GEN_ITEM_SETITEM08_GREEN; break;
						}
						else
							if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY))
							{
								dwHandSfx = XI_SETIEM_EFFECTHAND_WHITE;
								dwSfx = XI_GEN_ITEM_SETITEM08_WHITE; break;
							}


							else
								if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX1)
								{
									dwSfx = XI_GEN_ITEM_SETITEM08_GOLD; break;
								}

								else
									if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX2)
									{
										dwSfx = XI_GEN_ITEM_SETITEM08_PUPPLE; break;
									}



									else
									{
										dwSfx = XI_GEN_ITEM_SETITEM08; break;
									}
	}
	case 9:
	{
		if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_15DAY))
		{
			dwHandSfx = XI_SETIEM_EFFECTHAND_GOLD;
			dwSfx = XI_GEN_ITEM_SETITEM09_GOLD; break;
		}
		else
			if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_RED_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_RED_15DAY))
			{
				dwHandSfx = XI_SETIEM_EFFECTHAND_RED;
				dwSfx = XI_GEN_ITEM_SETITEM09_RED; break;
			}
			else
				if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_15DAY))
				{
					dwHandSfx = XI_SETIEM_EFFECTHAND_BLACK;
					dwSfx = XI_GEN_ITEM_SETITEM09_BLACK; break;
				}
				else
					if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_15DAY))
					{
						dwHandSfx = XI_SETIEM_EFFECTHAND_PUPPLE;
						dwSfx = XI_GEN_ITEM_SETITEM09_PUPPLE; break;
					}
					else
						if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_15DAY))
						{
							dwHandSfx = XI_SETIEM_EFFECTHAND_GREEN;
							dwSfx = XI_GEN_ITEM_SETITEM09_GREEN; break;
						}
						else
							if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY))
							{
								dwHandSfx = XI_SETIEM_EFFECTHAND_WHITE;
								dwSfx = XI_GEN_ITEM_SETITEM09_WHITE; break;
							}


							else
								if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX1)
								{
									dwSfx = XI_GEN_ITEM_SETITEM09_GOLD; break;
								}

								else
									if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX2)
									{
										dwSfx = XI_GEN_ITEM_SETITEM09_PUPPLE; break;
									}



									else
									{
										dwSfx = XI_GEN_ITEM_SETITEM09; break;
									}
	}
	case 10:
	{

		if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_15DAY))
		{
			dwHandSfx = XI_SETIEM_EFFECTHAND_GOLD;
			dwSfx = XI_GEN_ITEM_SETITEM10_GOLD; break;
		}
		else
			if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_RED_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_RED_15DAY))
			{
				dwHandSfx = XI_SETIEM_EFFECTHAND_RED;
				dwSfx = XI_GEN_ITEM_SETITEM10_RED; break;
			}
			else
				if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_15DAY))
				{
					dwHandSfx = XI_SETIEM_EFFECTHAND_BLACK;
					dwSfx = XI_GEN_ITEM_SETITEM10_BLACK; break;
				}
				else
					if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_15DAY))
					{
						dwHandSfx = XI_SETIEM_EFFECTHAND_PUPPLE;
						dwSfx = XI_GEN_ITEM_SETITEM10_PUPPLE; break;
					}
					else
						if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_15DAY))
						{
							dwHandSfx = XI_SETIEM_EFFECTHAND_GREEN;
							dwSfx = XI_GEN_ITEM_SETITEM10_GREEN; break;
						}
						else
							if (HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY) || HasBuff(BUFF_ITEM, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY))
							{
								dwHandSfx = XI_SETIEM_EFFECTHAND_WHITE;
								dwSfx = XI_GEN_ITEM_SETITEM10_WHITE; break;
							}

							else
								if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX1)
								{
									dwSfx = XI_GEN_ITEM_SETITEM010_GOLD; break;
								}

								else
									if (pItemElem && pItemElem->GetProp() && pItemElem->GetProp()->dwID == II_ARM_S_MAS_SFX2)
									{
										dwSfx = XI_GEN_ITEM_SETITEM010_PUPPLE; break;
									}



									else
									{
										dwSfx = XI_GEN_ITEM_SETITEM10; break;
									}
	}

	}

	CSfxPartsLinkShoulder* pSfx = NULL;
	D3DXVECTOR3 v3Scal = D3DXVECTOR3(1.0f, 1.0f, 1.0f);








	if (nAbilityOption == 3)
	{
		// ¾î±ú
		pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
		pSfx->m_nPartsLink = 0;
		pSfx->m_v3Offset.y = 0.1f;
		pSfx->m_nOldAbilityOption = nAbilityOption;
		pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
		pSfx->m_nPartsLink = 1;
		pSfx->m_v3Offset.y = 0.1f;
		pSfx->m_nOldAbilityOption = nAbilityOption;

	}
	/*
	else
	if( nAbilityOption == 4 )
	{
		// ¸öÅë
		pSfx = (CSfxPartsLinkShoulder*)CreateSfx( D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1 );
		pSfx->m_nPartsLink = 6;
		pSfx->SetScale(D3DXVECTOR3( 2.2f, 2.2f, 2.2f ));
	}
	*/
	else
		if (nAbilityOption == 4)
		{
			// ¸öÅë
			pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
			pSfx->m_nPartsLink = 6;
			pSfx->SetScale(D3DXVECTOR3(3.0f, 3.0f, 3.0f));
			pSfx->m_nOldAbilityOption = nAbilityOption;
		}
		else
			if (nAbilityOption == 5)
			{
				// ¾î±ú
				pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
				pSfx->m_nPartsLink = 0;
				pSfx->m_v3Offset.y = 0.1f;
				pSfx->m_nOldAbilityOption = nAbilityOption;
				pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
				pSfx->m_nPartsLink = 1;
				pSfx->m_v3Offset.y = 0.1f;
				pSfx->m_nOldAbilityOption = nAbilityOption;
				// ¾î±ú, ÆÈ¸ñ Áß°£
				pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
				pSfx->m_nPartsLink = 4;
				pSfx->m_nOldAbilityOption = nAbilityOption;
				pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
				pSfx->m_nPartsLink = 5;
				pSfx->m_nOldAbilityOption = nAbilityOption;
			}
			else
				if (nAbilityOption == 6)
				{
					// ¾î±ú
					pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
					pSfx->m_nPartsLink = 0;
					pSfx->m_nOldAbilityOption = nAbilityOption;
					pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
					pSfx->m_nPartsLink = 1;
					pSfx->m_nOldAbilityOption = nAbilityOption;
					// ¾î±ú, ÆÈ¸ñ Áß°£
					pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
					pSfx->m_nPartsLink = 4;
					pSfx->m_nOldAbilityOption = nAbilityOption;
					pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
					pSfx->m_nPartsLink = 5;
					pSfx->m_nOldAbilityOption = nAbilityOption;
					// ÆÈ¸ñ
					pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
					pSfx->m_nPartsLink = 2;
					pSfx->m_v3Offset.y = 0.1f;
					pSfx->m_nOldAbilityOption = nAbilityOption;
					pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
					pSfx->m_nPartsLink = 3;
					pSfx->m_v3Offset.y = 0.1f;
					pSfx->m_nOldAbilityOption = nAbilityOption;
				}
				else
					if (nAbilityOption == 7)
					{
						// ¾î±ú
						pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
						pSfx->m_nPartsLink = 0;
						pSfx->m_nOldAbilityOption = nAbilityOption;
						pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
						pSfx->m_nPartsLink = 1;
						pSfx->m_nOldAbilityOption = nAbilityOption;
						// ¾î±ú, ÆÈ¸ñ Áß°£
						pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
						pSfx->m_nPartsLink = 4;
						pSfx->m_nOldAbilityOption = nAbilityOption;
						pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
						pSfx->m_nPartsLink = 5;
						pSfx->m_nOldAbilityOption = nAbilityOption;
						// ÆÈ¸ñ
						pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
						pSfx->m_nPartsLink = 2;
						pSfx->m_v3Offset.y = 0.1f;
						pSfx->m_nOldAbilityOption = nAbilityOption;
						pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
						pSfx->m_nPartsLink = 3;
						pSfx->m_v3Offset.y = 0.1f;
						pSfx->m_nOldAbilityOption = nAbilityOption;
						// ¼Õ	
						pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
						pSfx->m_nPartsLink = 8;
						pSfx->m_v3Offset.y = 0.1f;
						pSfx->m_nOldAbilityOption = nAbilityOption;
						pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
						pSfx->m_nPartsLink = 9;
						pSfx->m_v3Offset.y = 0.1f;
						pSfx->m_nOldAbilityOption = nAbilityOption;
					}
					else
						if (nAbilityOption == 8)
						{
							// ¾î±ú
							pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
							pSfx->m_nPartsLink = 0;
							pSfx->m_nOldAbilityOption = nAbilityOption;
							pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
							pSfx->m_nPartsLink = 1;
							pSfx->m_nOldAbilityOption = nAbilityOption;
							// ¾î±ú, ÆÈ¸ñ Áß°£
							pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
							pSfx->m_nPartsLink = 4;
							pSfx->m_nOldAbilityOption = nAbilityOption;
							pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
							pSfx->m_nPartsLink = 5;
							pSfx->m_nOldAbilityOption = nAbilityOption;
							// ÆÈ¸ñ
							pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
							pSfx->m_nPartsLink = 2;
							pSfx->m_v3Offset.y = 0.1f;
							pSfx->m_nOldAbilityOption = nAbilityOption;
							pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
							pSfx->m_nPartsLink = 3;
							pSfx->m_v3Offset.y = 0.1f;
							pSfx->m_nOldAbilityOption = nAbilityOption;
							// ¼Õ	
							pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
							pSfx->m_nPartsLink = 8;
							pSfx->m_v3Offset.y = 0.1f;
							pSfx->m_nOldAbilityOption = nAbilityOption;
							pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
							pSfx->m_nPartsLink = 9;
							pSfx->m_v3Offset.y = 0.1f;
							pSfx->m_nOldAbilityOption = nAbilityOption;

							pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, XI_SETIEM_EFFECTHAND, GetPos(), GetId(), GetPos(), GetId(), -1);
							pSfx->m_nPartsLink = 9;
							pSfx->m_v3Offset.y = 0.2f;
							pSfx->m_nOldAbilityOption = nAbilityOption;
						}
						else
							if (nAbilityOption == 9)
							{
								// ¾î±ú
								pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
								pSfx->m_nPartsLink = 0;
								pSfx->m_nOldAbilityOption = nAbilityOption;
								pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
								pSfx->m_nPartsLink = 1;
								pSfx->m_nOldAbilityOption = nAbilityOption;
								// ¾î±ú, ÆÈ¸ñ Áß°£
								pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
								pSfx->m_nPartsLink = 4;
								pSfx->m_nOldAbilityOption = nAbilityOption;
								pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
								pSfx->m_nPartsLink = 5;
								pSfx->m_nOldAbilityOption = nAbilityOption;
								// ÆÈ¸ñ
								pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
								pSfx->m_nPartsLink = 2;
								pSfx->m_v3Offset.y = 0.1f;
								pSfx->m_nOldAbilityOption = nAbilityOption;
								pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
								pSfx->m_nPartsLink = 3;
								pSfx->m_v3Offset.y = 0.1f;
								pSfx->m_nOldAbilityOption = nAbilityOption;
								// ¼Õ	
								pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
								pSfx->m_nPartsLink = 8;
								pSfx->m_v3Offset.y = 0.1f;
								pSfx->m_nOldAbilityOption = nAbilityOption;
								pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
								pSfx->m_nPartsLink = 9;
								pSfx->m_v3Offset.y = 0.1f;
								pSfx->m_nOldAbilityOption = nAbilityOption;
								// ¹ß
								pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
								pSfx->m_nPartsLink = 26;
								pSfx->SetScale(D3DXVECTOR3(1.5f, 1.5f, 1.5f));
								pSfx->m_nOldAbilityOption = nAbilityOption;
								pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
								pSfx->m_nPartsLink = 29;
								pSfx->SetScale(D3DXVECTOR3(1.5f, 1.5f, 1.5f));
								pSfx->m_nOldAbilityOption = nAbilityOption;


								pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, XI_SETIEM_EFFECTHAND, GetPos(), GetId(), GetPos(), GetId(), -1);
								pSfx->m_nPartsLink = 9;
								pSfx->m_v3Offset.y = 0.2f;
								pSfx->m_nOldAbilityOption = nAbilityOption;
							}
							else
								if (nAbilityOption == 10)
								{
									// ¾î±ú
									pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
									pSfx->m_nPartsLink = 0;
									pSfx->m_nOldAbilityOption = nAbilityOption;
									pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
									pSfx->m_nPartsLink = 1;
									pSfx->m_nOldAbilityOption = nAbilityOption;
									// ¾î±ú, ÆÈ¸ñ Áß°£
									pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
									pSfx->m_nPartsLink = 4;
									pSfx->m_nOldAbilityOption = nAbilityOption;
									pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
									pSfx->m_nPartsLink = 5;
									pSfx->m_nOldAbilityOption = nAbilityOption;
									// ¸öÅë
									pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
									pSfx->m_nPartsLink = 6;
									pSfx->SetScale(D3DXVECTOR3(3.0f, 4.5f, 3.0f));
									pSfx->m_nOldAbilityOption = nAbilityOption;
									pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
									pSfx->m_nPartsLink = 7;
									pSfx->SetScale(D3DXVECTOR3(3.0f, 3.0f, 3.0f));
									pSfx->m_nOldAbilityOption = nAbilityOption;
									// ¼Õ	
									pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
									pSfx->m_nPartsLink = 8;
									pSfx->m_v3Offset.y = 0.1f;
									pSfx->m_nOldAbilityOption = nAbilityOption;
									pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
									pSfx->m_nPartsLink = 9;
									pSfx->m_v3Offset.y = 0.1f;
									pSfx->m_nOldAbilityOption = nAbilityOption;
									// ÆÈ¸ñ
									pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
									pSfx->m_nPartsLink = 2;
									pSfx->m_nOldAbilityOption = nAbilityOption;
									pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
									pSfx->m_nPartsLink = 3;
									pSfx->m_nOldAbilityOption = nAbilityOption;
									// ¹ß
									pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
									pSfx->m_nPartsLink = 26;
									pSfx->m_nOldAbilityOption = nAbilityOption;
									pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
									pSfx->m_nPartsLink = 29;
									pSfx->m_nOldAbilityOption = nAbilityOption;


									pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, XI_SETIEM_EFFECTHAND, GetPos(), GetId(), GetPos(), GetId(), -1);
									pSfx->m_nPartsLink = 8;
									pSfx->m_v3Offset.y = 0.2f;
									pSfx->m_nOldAbilityOption = nAbilityOption;

									pSfx = (CSfxPartsLinkShoulder*)CreateSfx(D3DDEVICE, XI_SETIEM_EFFECTHAND, GetPos(), GetId(), GetPos(), GetId(), -1);
									pSfx->m_nPartsLink = 9;
									pSfx->m_v3Offset.y = 0.2f;
									pSfx->m_nOldAbilityOption = nAbilityOption;
								}
#endif
}

#endif //__CLIENT

//int nItemKind, int nItemKind2, int nNumMax, int nUniqueMin, int nUniqueMax, int nTotalNum, CAnim* pAnimParent, int nMaterialCount )
void CMover::GenerateVendorItem( ItemProp** apItemProp, int* pcbSize, int nMax, LPVENDOR_ITEM pVendor )
{
	CPtrArray* pItemKindAry		= prj.GetItemKindAry( pVendor->m_nItemkind3 );
	ItemProp* pItemProp		= NULL;
	int cbSizeOld	= *pcbSize;

	ASSERT( pVendor->m_nUniqueMin >= 0 );
	ASSERT( pVendor->m_nUniqueMax >= 0 );
	
	if( *pcbSize >= nMax )
		return;

	int nMinIdx	= -1, nMaxIdx	= -1;

	for( int j = pVendor->m_nUniqueMin; j <= pVendor->m_nUniqueMax; j++ )
	{
		nMinIdx		= prj.GetMinIdx( pVendor->m_nItemkind3, j );
		if( nMinIdx != -1 )
			break;
	}
	for( int j = pVendor->m_nUniqueMax; j >= pVendor->m_nUniqueMin; j-- )
	{
		nMaxIdx		= prj.GetMaxIdx( pVendor->m_nItemkind3, j );
		if( nMaxIdx != -1 )
			break;
	}
	if( nMinIdx < 0 )
	{
		WriteError( "VENDORITEM//%s//%d-%d//%d", GetName(), pVendor->m_nUniqueMin, pVendor->m_nUniqueMax, pVendor->m_nItemkind3 );
		return;
	}

	for( int k = nMinIdx; k <= nMaxIdx; k++ )
	{
		pItemProp	= (ItemProp*)pItemKindAry->GetAt( k );

		if( ( NULL == pItemProp ) ||
			( pItemProp->dwShopAble == (DWORD)-1 ) ||
			( pVendor->m_nItemJob != -1 && (DWORD)pItemProp->dwItemJob != pVendor->m_nItemJob ) )
			continue;
		
		if( *pcbSize >= nMax )
			break;

		apItemProp[*pcbSize]	= pItemProp;
		(*pcbSize)++;
	}
}



void CMover::EnforcedGhostCorr()
{
	if( m_CorrAction.fValid == TRUE && ( m_uRemnantCorrFrm - 1 ) == 0 ) {
		if( m_CorrAction.dwStateFlag & OBJSTAF_FLY ) {
			ActionForceSet2( m_CorrAction.v, m_CorrAction.vd, m_CorrAction.f, m_CorrAction.fAngleX,
						m_CorrAction.fAccPower, m_CorrAction.fTurnAngle, 
						m_CorrAction.dwState, m_CorrAction.dwStateFlag,
						m_CorrAction.dwMotion, m_CorrAction.nMotionEx,
						m_CorrAction.nLoop, m_CorrAction.dwMotionOption );
		}
		else {
			ActionForceSet( m_CorrAction.v, m_CorrAction.vd, m_CorrAction.f, m_CorrAction.dwState,
						m_CorrAction.dwStateFlag, m_CorrAction.dwMotion, m_CorrAction.nMotionEx,
						m_CorrAction.nLoop, m_CorrAction.dwMotionOption );
		}
		memset( &m_CorrAction, 0, sizeof(CORR_ACTION) );
	}
}

void CMover::ApproachGhostAngle()
{
	if( m_fDestAngle > -0.001f )
	{
		float f	= m_pActMover->IsFly() ? 0.601f : 4.001f;
		if( fabs( GetAngle() - m_fDestAngle ) < f ) 
		{
			if( m_CorrAction.fValid == FALSE ) 
			{
				SetAngle( m_fDestAngle );
				ClearDestAngle();
				SendActMsg( OBJMSG_STOP_TURN );
			}
			else 
			{
				ClearDestAngle();
				if( (m_CorrAction.dwStateFlag & OBJSTAF_FLY) == 0 ) 
				{
					ActionForceSet( m_CorrAction.v, m_CorrAction.vd, m_CorrAction.f, m_CorrAction.dwState,
						m_CorrAction.dwStateFlag, m_CorrAction.dwMotion, m_CorrAction.nMotionEx,
						m_CorrAction.nLoop, m_CorrAction.dwMotionOption );
				}
				memset( &m_CorrAction, 0, sizeof(CORR_ACTION) );
			}
		}
		else 
		{
			f = m_pActMover->IsFly() ? 0.6f * 100.0f : 0.0f;
			if( m_bLeft )
				SendActMsg( OBJMSG_LTURN, (int)f );
			else
				SendActMsg( OBJMSG_RTURN, (int)f );
		}
	}
}

// ¸ñÇ¥ À§Ä¡¿¡ µµÂøÇßÀ» °æ¿ì È£ÃâµÊ 
void CMover::OnArrive( DWORD dwParam1, DWORD dwParam2 )
{
#ifdef __WORLDSERVER
	if( IsPlayer() )
		((CUser* )this)->OnMsgArrival( dwParam1 );    // dwParam1 - pickup´ë»ó
	else
		PostAIMsg( AIMSG_ARRIVAL, dwParam1, dwParam2 );
#endif // __WORLDSERVER
}

void CMover::OnArriveAtPos()
{  
	if( m_CorrAction.fValid == FALSE )
	{
		SendActMsg( m_dwMotionArrive );			
		OnArrive( NULL_ID, 1 );
	}
	else {
		if( m_CorrAction.fHalf )
		{
			HalfForceSet( m_CorrAction.v, m_CorrAction.vd,
								m_CorrAction.f, m_CorrAction.fAngleX,
								m_CorrAction.fAccPower, m_CorrAction.fTurnAngle );
		}
		else
		{
			if( m_CorrAction.dwStateFlag & OBJSTAF_FLY ) {
				ActionForceSet2( m_CorrAction.v, m_CorrAction.vd, m_CorrAction.f, m_CorrAction.fAngleX,
					m_CorrAction.fAccPower, m_CorrAction.fTurnAngle, 
					m_CorrAction.dwState, m_CorrAction.dwStateFlag,
					m_CorrAction.dwMotion, m_CorrAction.nMotionEx,
					m_CorrAction.nLoop, m_CorrAction.dwMotionOption );
			}
			else {
				ActionForceSet( m_CorrAction.v, m_CorrAction.vd, m_CorrAction.f, m_CorrAction.dwState,
					m_CorrAction.dwStateFlag, m_CorrAction.dwMotion, m_CorrAction.nMotionEx,
					m_CorrAction.nLoop, m_CorrAction.dwMotionOption );
			}
		}
		memset( &m_CorrAction, 0, sizeof(CORR_ACTION) );
	}
	ClearDestPos();
}

BOOL CMover::AddItem( CItemBase* pItemBase )
{
	return m_Inventory.Add( (CItemElem*)pItemBase );
}

BOOL CMover::AddItemBank( int nSlot, CItemElem* pItemElem )
{
	return m_Bank[nSlot].Add( pItemElem );
}

CItemBase* CMover::GetItemId( DWORD dwId )
{
	return m_Inventory.GetAtId( dwId );
}

CItemBase* CMover::GetItemBankId( int nSlot, DWORD dwId )
{
	CItemBase* pItemBase = NULL;
	pItemBase = m_Bank[nSlot].GetAtId( dwId );
	return pItemBase;
}

void CMover::RemoveItemId( DWORD dwId )
{
	if( m_Inventory.IsEquip( dwId ) )
		DoEquip( (CItemElem*)m_Inventory.GetAtId( dwId ), FALSE );		// ½ÇÆÐÇÒ °æ¿ì, ÀåÂø ÇØÁ¦ È¿°ú°¡ ³ªÅ¸³ªÁö ¾ÊÀ¸¹Ç·Î °í·Á°¡ ÇÊ¿äÇÔ.
	m_Inventory.RemoveAtId( dwId );
}

void CMover::SetKeeptimeInven( DWORD dwItemId, DWORD dwTime )
{
	int	nSize = m_Inventory.GetMax();
	for( int i = 0 ; i < nSize; i++ )
	{
		CItemElem* pItemElem = m_Inventory.GetAtId( i );
		if( pItemElem->GetProp()->dwID == dwItemId )
		{
			SetKeeptimeItem( pItemElem, dwTime );
		}
	}		
}
void CMover::SetKeeptimeBank( DWORD dwItemId, DWORD dwTime )
{
	int	nSize = m_Bank[m_nSlot].GetMax();
	for( int i = 0 ; i < nSize; i++ )
	{
		CItemElem* pItemElem = m_Bank[m_nSlot].GetAtId( i );
		if( pItemElem->GetProp()->dwID == dwItemId )
		{
			SetKeeptimeItem( pItemElem, dwTime );
		}
	}			
}
void CMover::SetKeeptimeItem( CItemElem* pItemElem, DWORD dwTime )
{	
	pItemElem->m_dwKeepTime = dwTime;
}

void CMover::RemoveItemBankId( int nSlot, DWORD dwId )
{
	m_Bank[nSlot].RemoveAtId( dwId );
}


#ifdef __CLIENT
void CMover::DialogOut( LPCTSTR lpszText )
{
	g_DialogMsg.AddMessage( this, lpszText, 0xffffffff );
}
#endif

BOOL CMover::SetMotion( DWORD dwMotion, int nLoop, DWORD dwOption )
{
#ifdef __MOUNT
	if (GetMountId() > 0 && m_pMountModel)
	{
		MOUNT_ANIMATION* pMountAnimation = prj.GetMountAnimation(GetMountId());
		if (pMountAnimation)
		{
			if (dwMotion != pMountAnimation->dwPlayerAni)
				return FALSE;
		}
	}
#endif // __MOUNT
	CModelObject* pModel = (CModelObject*)m_pModel;
	DWORD	dwOrigMotion = dwMotion;
	ItemProp* pItemProp = GetActiveHandItemProp();
	if( m_pActMover->IsStateFlag( OBJSTAF_COMBAT ) && (dwOption & MOP_FIXED) == 0 )
	{
#if defined(__CLIENT) 
		if( pItemProp == NULL )
		{
			if( IsPlayer() )
			{
				LPCTSTR szErr = Error( "CMover::SetMotion : Player %s %d %d", GetName(), IsActiveMover(), m_aEquipInfo[PARTS_RWEAPON].dwId );
				ADDERRORMSG( szErr );
			}
			else
			{
				LPCTSTR szErr = Error( "CMover::SetMotion : NPC %s %d", GetName(), m_dwVirtItem );
				ADDERRORMSG( szErr );
			}
			
			return FALSE;
		}
#endif // __CLIENT

		int nIndex = GetIndex();
		if( !IsPlayer() || ( IsPlayer() && 
			( nIndex == MI_MALE || 
			  nIndex == MI_FEMALE || 
			  nIndex == MI_CROWNIBLIS || 
			  nIndex == MI_CROWNSHADE || 
			  nIndex == MI_CROWNBUBBLE || 
			  nIndex == MI_DWARPETMAS ) ) )  
		{
			BOOL bMasterPlayer = FALSE;
			
			if( nIndex == MI_CROWNIBLIS || nIndex == MI_CROWNSHADE || nIndex == MI_CROWNBUBBLE || nIndex == MI_DWARPETMAS ) 
				bMasterPlayer = TRUE;
			
			if( IsDualWeapon() && !bMasterPlayer )
			{
#ifdef __ONEHANDYOYO
				if (pItemProp->dwItemKind3 == IK3_YOYO)
				{
					if (!bMasterPlayer)
						dwMotion += MTI_STAND_14;
					else
						dwMotion += 200;
				}
				else
#endif // __ONEHANDYOYO
				{
					dwMotion += 900;
				}
			} 
			else
			{
				BOOL bHanded = ( pItemProp->dwHanded == HD_TWO ) ? TRUE : FALSE;
				switch( pItemProp->dwItemKind3 )
				{
				case IK3_YOYO: 
					if( !bMasterPlayer ) dwMotion += MTI_STAND_14;
					else dwMotion += 200;
					break;
				case IK3_BOW: 
					if( !bMasterPlayer ) dwMotion += MTI_STAND_13;
					else dwMotion += 200;
					break;               
				case IK3_SWD: 
					if( bHanded )	dwMotion += 800;	
					else			dwMotion += 200; 
					break;
				case IK3_AXE: 
					if( bHanded )	dwMotion += 800;
					else			dwMotion += 500; 
					break;               
				case IK3_WAND:
#ifdef __NEWCLASS
					if (GetJob() == JOB_PSYCHIKEEPER || GetJob() == JOB_PSYCHIKEEPER_MASTER || GetJob() == JOB_PSYCHIKEEPER_HERO || GetJob() == JOB_MENTALIST_HERO || GetJob() == JOB_MENTALIST_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
					if (GetJob() == JOB_PSYCHIKEEPER || GetJob() == JOB_PSYCHIKEEPER_MASTER || GetJob() == JOB_PSYCHIKEEPER_HERO || GetJob() == JOB_MENTALIST_HERO)
#else // __3RD_LEGEND16
#if __VER >= 10 // __LEGEND
					if (GetJob() == JOB_PSYCHIKEEPER || GetJob() == JOB_PSYCHIKEEPER_MASTER || GetJob() == JOB_PSYCHIKEEPER_HERO)
#else // __LEGEND
					if (GetJob() == JOB_PSYCHIKEEPER)
#endif	// __LEGEND
#endif // __3RD_LEGEND16
					{
						dwMotion += MTI_STAND_11;
					}
					else								dwMotion += MTI_STAND_02; 
					break; 
				case IK3_CHEERSTICK: dwMotion += 400; break; 
				case IK3_STAFF: 
					dwMotion += MTI_STAND_05; 
					break; 
				case IK3_KNUCKLEHAMMER: dwMotion += 700; break; 
#ifdef __CROSSBOW
				case IK3_CROSSBOW: dwMotion += MTI_STAND_15;break;
#endif // __CROSSBOW
				default: 
					if( IsPlayer() ) dwMotion += 200; 
					break;
				}
			}
		}
	}
	if( m_dwMotion == dwOrigMotion && m_dwMotionOption == dwOption )
	{
		if( nLoop == ANILOOP_LOOP )		return FALSE;
		if( pModel->m_bEndFrame == FALSE )
			return FALSE;					
		if( pModel->m_bEndFrame && nLoop == ANILOOP_CONT )
			return FALSE;
	}
#ifdef _DEBUG
	if( dwOrigMotion == MTI_WALK )
	{
		int a = 0;
	}
#endif
	prj.m_modelMng.LoadMotion( m_pModel, m_dwType, m_dwIndex, dwMotion );
	m_dwMotion = dwOrigMotion;
	m_dwMotionOption = dwOption;

	pModel->m_bEndFrame = FALSE;
	pModel->SetLoop( nLoop );

	if(m_pModel && m_pModel->m_pModelElem && (m_pModel->m_pModelElem->m_dwIndex == MI_NPC_SNOWMAN01 || m_pModel->m_pModelElem->m_dwIndex == MI_NPC_SNOWMAN02))
		dwOption |= MOP_NO_TRANS;

	if( dwOption & MOP_NO_TRANS )		pModel->SetMotionBlending( FALSE );
	else								pModel->SetMotionBlending( TRUE );
	if( dwOption & MOP_SWDFORCE )
	{
		if( IsPlayer() )
		{
			int nOption = 0;
			DWORD dwColor = D3DCOLOR_ARGB( 255, 255, 255, 255 );
			if( IsActiveMover() )
			{
				CItemElem *pItemElem = GetWeaponItem();
				if( pItemElem )
					nOption = pItemElem->GetAbilityOption();
			} 
			else
			{	
				// Å¸ ÇÃ·¹ÀÌ¾î´Â ÆäÀÌÅ©¾ÆÀÌÅÛÀÌ¹Ç·Î ¿©±â¼­¿¡¼­ °ªÀ» »©¿Â´Ù.
				nOption		= m_aEquipInfo[PARTS_RWEAPON].nOption & 0xFF;
			}

			if( nOption >= 10 )
				dwColor = D3DCOLOR_ARGB( 255, 255, 0, 0 );
			else if( nOption == 9 )
				dwColor = D3DCOLOR_ARGB( 255, 255, 150, 0 );
			else if( nOption >= 7 )
				dwColor = D3DCOLOR_ARGB( 255, 198, 0, 255 );
			else if( nOption >= 5 )
				dwColor = D3DCOLOR_ARGB( 255, 123, 82, 255 );
			else if( nOption >= 3)
				dwColor = D3DCOLOR_ARGB( 255, 129, 221, 251 );
			else if( nOption >= 1 )
				dwColor = D3DCOLOR_ARGB( 255, 201, 251, 190 );
			else
				dwColor = D3DCOLOR_ARGB( 255, 255, 255, 255 );

			pModel->MakeSWDForce( PARTS_RWEAPON, pItemProp->dwItemKind3, (dwOption & MOP_HITSLOW) ? TRUE : FALSE, dwColor, m_fAniSpeed );
			pModel->MakeSWDForce( PARTS_LWEAPON, pItemProp->dwItemKind3, (dwOption & MOP_HITSLOW) ? TRUE : FALSE, dwColor, m_fAniSpeed );
		}
	}
	else
	{
		if( pModel->m_pForce )
			pModel->m_pForce->Clear();
		if( pModel->m_pForce2 )
			pModel->m_pForce2->Clear();
	}

	return TRUE;
}
BOOL CMover::InitMotion(DWORD dwMotion)
{
	prj.m_modelMng.LoadMotion( m_pModel, m_dwType, m_dwIndex, dwMotion );
	m_dwMotion = dwMotion;
	return TRUE;
}


//ÀûÀÇ ¼ýÀÚ¸¦ ±¸ÇÑ´Ù.
int CMover::GetEnemyCount()
{
	int nCount = 0;
	nCount = m_idEnemies.size();
	return nCount;
}

OBJID CMover::GetMaxEnemyHitID()
{
	OBJID objId = NULL_ID;
#ifdef __NO_HP_DMG_LIMIT
	long long nHitPoint = 0;
#else
	int	nHitPoint = 0;
#endif

	for( SET_OBJID::iterator i = m_idEnemies.begin(); i != m_idEnemies.end(); ++i )
	{
		HIT_INFO info = (*i).second;
		if( nHitPoint < info.nHit )
		{
			objId = (*i).first;
			nHitPoint = info.nHit;
		}
	}
	return objId;
}

#ifdef __NO_HP_DMG_LIMIT
long long CMover::GetEnemyHit(unsigned long objid, unsigned long* pdwTick)
#else
int CMover::GetEnemyHit(OBJID objid, DWORD* pdwTick)
#endif
{
#ifdef __NO_HP_DMG_LIMIT
	long long nHit = 0;
#else
	int nHit = 0;
#endif
	DWORD dwTick = 0;

	SET_OBJID::iterator i	= m_idEnemies.find( objid );
	if( i != m_idEnemies.end() )
	{
		HIT_INFO info = (*i).second;
		nHit = info.nHit;
		dwTick = info.dwTick;
	}

	if( pdwTick )
		*pdwTick = dwTick;

	return nHit;
}

// ¸¶Áö¸·À¸·Î ¶§¸° ½Ã°¢À» ¸®ÅÏÇÑ´Ù.
#ifdef __NO_HP_DMG_LIMIT
unsigned long CMover::AddEnemy(OBJID objid, long long nHit)
#else
DWORD CMover::AddEnemy(OBJID objid, int nHit)
#endif
{
	DWORD dwLast = 0;
	SET_OBJID::iterator i	= m_idEnemies.find( objid );
	if( i == m_idEnemies.end() )
	{
		HIT_INFO info;
		info.nHit = nHit;
		info.dwTick = GetTickCount();
		m_idEnemies.insert( make_pair(objid, info) );
	}
	else
	{
		HIT_INFO& info = (*i).second;
		dwLast = info.dwTick;
		info.dwTick = GetTickCount();
		info.nHit += nHit;
	}
	return dwLast;
}

void CMover::RemoveEnemy( OBJID objid )
{
	SET_OBJID::iterator i	= m_idEnemies.find( objid );
	if( i != m_idEnemies.end() )
	{
		if( m_pActMover->GetObjHit() == objid )
			m_pActMover->SetObjHit( NULL_ID );
	#ifdef __WORLDSERVER
		PostAIMsg( AIMSG_DSTDIE, objid );
	#endif

		if( GetDestId() == objid )
		{
			ClearDestObj();
			SendActMsg( OBJMSG_STAND );
		}

	#ifdef __WORLDSERVER
		#if __VER < 8 // __S8_PK
			// PK¼¼¼ÇÀ» Á¾·á½ÃÅ°±â À§ÇØ¼­ ÇÃ·¹ÀÌ¾î°£ÀÇ Àû´ë°ü°è Á¾·á¸¦ º¸³½´Ù.
			if( IsPlayer() )	
			{
				CUser* pEnemy = prj.GetUser( objid );
				if( IsValidObj( pEnemy ) && (GetTickCount() - i->second.dwTick) <= MIN(1) )
				{
					((CUser*)this)->UpdatePlayerEnemy( DEL_PLAYER_ENEMY, objid );
					pEnemy->UpdatePlayerEnemy( DEL_PLAYER_ENEMY, GetId() );
				}
			}	
		#endif // __VER < 8 // __S8_PK
	#endif // __WORLDSERVER

		m_idEnemies.erase( i );
	}
}

void CMover::RemoveAllEnemies()
{
	vector<OBJID>	adwEnemy;
	for( SET_OBJID::iterator it = m_idEnemies.begin(); it != m_idEnemies.end(); ++it )
		adwEnemy.push_back( it->first );
	m_idEnemies.clear();
	
	CMover* pEnemy;
	while( adwEnemy.size() > 0 )
	{
		OBJID objid		= adwEnemy.back();
		pEnemy	= prj.GetMover( objid );
		if( IsValidObj( (CObj*)pEnemy ) )
			pEnemy->RemoveEnemy( GetId() );
		adwEnemy.pop_back();
	}
	adwEnemy.clear();
/*
	int nSizeofEnemies	= 0;
	OBJID	idEnemies[1024];

	for( SET_OBJID::iterator i = m_idEnemies.begin(); i != m_idEnemies.end(); ++i )
	{
		idEnemies[nSizeofEnemies++]	= (*i).first;
		if( nSizeofEnemies >= 1024 )
			break;
	}

	m_idEnemies.clear();

	CMover* pEnemy;
	for( int j = 0; j < nSizeofEnemies; j++ )
	{
		pEnemy	= prj.GetMover( idEnemies[j] );
		if( IsValidObj( (CObj*)pEnemy ) )
			pEnemy->RemoveEnemy( GetId() );
	}
*/
}

//
// this¸¦ Á×°Ô ¸¸µå´Â ¸í·É. - ¿ÜºÎ¿¡¼­ Á÷Á¢ È£ÃâÇØ¼­ Á×ÀÌ±â¸¸ ÇÒ¶§µµ ¾µ¼öÀÖ´Ù.
// Attacker´Â NULLÀÏ ¼öµµ ÀÖ´Ù.  ¾î´ÀÁö¿ª°¡¸é °Á µÚÁö´Â °æ¿ì.
int CMover::DoDie( CCtrl *pAttackCtrl, DWORD dwMsg )
{
#ifdef __WORLDSERVER
	if (IsDie())
		return 0;

	// Å¬¶óÀÌ¾ðÆ®´Â ÀÌÂÊÀ¸·Î ¿ÀÁö ¾ÊÀ½.
	BOOL	bBehavior = FALSE;
	CMover *pAttacker = NULL;

	if( pAttackCtrl && pAttackCtrl->GetType() == OT_MOVER )		// ¾îÅÂÄ¿°¡ ¹«¹ö¶ó¸é ¹«¹ö Æ÷ÀÎÅÍ ¸¸µé¾î µÐ´Ù.
		pAttacker = (CMover *)pAttackCtrl;

	m_bLastPK = FALSE;
	if( pAttacker && pAttacker != this && pAttacker->IsPlayer() )		// ÀÚ»ìÇÑ°Ô ¾Æ´Ï°í, ÇÃ·¹ÀÌ¾î¿¡°Ô Á×¾ú³Ä ¾Æ´Ï³Ä.
	{
		PVP_MODE mode = GetPVPCase( pAttacker ); 
		if( mode == PVP_MODE_PK )	// PK°æ¿ì
		{
#ifdef __JEFF_11_4
#endif	// __JEFF_11_4
			if( g_eLocal.GetState( EVE_PKCOST )
#ifdef __JEFF_11_4
				&& GetWorld()->IsArena() == FALSE
#endif	// __JEFF_11_4
#ifdef __WORLDSERVER_MENU
				&& CDPSrvr::GetInstance()->m_bPk == TRUE
				&& CDPSrvr::GetInstance()->m_bPkCost == TRUE
#endif // __WORLDSERVER_MENU
				)
				m_bLastPK = FALSE;	// °æÇèÄ¡ ´Ù¿î 
			else
				m_bLastPK = TRUE;	// °æÇèÄ¡ ´Ù¿î ¾øÀ½ 						
		}
		else
			m_bLastPK = TRUE;	// °æÇèÄ¡ ´Ù¿î ¾øÀ½ 
		
#ifdef __DEATH_MATCH
		if (GetWorld()->GetID() == WI_WORLD_DEATH_MATCH && g_War.GetState() > -1)
			g_War.Kill((CUser*)pAttacker, (CUser*)this);
#endif // __DEATH_MATCH

		m_bGuildCombat = FALSE;
		if( GetWorld()->GetID() == WI_WORLD_GUILDWAR && g_GuildCombatMng.m_nState != CGuildCombat::CLOSE_STATE )
			m_bGuildCombat = TRUE;
#if __VER >= 11 // __GUILD_COMBAT_1TO1
		if( g_GuildCombat1to1Mng.IsPossibleUser( (CUser*)this ) )
			m_bGuildCombat = TRUE;
#endif // __GUILD_COMBAT_1TO1
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
		if (IsNPC())
		{
			((CUser*)pAttacker)->SetHonorAdd(GetIndex(), HI_HUNT_MONSTER);
#ifdef __BADGE
			static_cast<CUser*>(pAttacker)->SetBadgeAddType(HI_HUNT_MONSTER, GetIndex());
#endif //__BADGE
#ifdef __RECORD_BOOK
			MoverProp* pMoverProp = GetProp();
			if (pMoverProp)
			{
				if (pMoverProp->dwClass == RANK_BOSS || pMoverProp->dwClass == RANK_SUPER)
					CRecordBook::GetInstance()->AddPlayerRecord(pAttacker, RecordType::BOSSES_KILLED, 1, true);
				else
					CRecordBook::GetInstance()->AddPlayerRecord(pAttacker, RecordType::MOBS_KILLED, 1, true);
			}
#endif
		}
		else
		{
#ifdef __RECORD_BOOK
			CRecordBook::GetInstance()->AddPlayerRecord(pAttacker, RecordType::PLAYERS_KILLED, 1, true);
#endif
		}
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
	}

	m_nAtkCnt = 0;		// Á×°í ³­ ÈÄ¿¡´Â ¾îÅÃÄ«¿îÆ®¸¦ Å¬¸®¾î ÇØ¼­ ºøÀÚ·ç¸¦ Å» ¼ö ÀÖ°ÔÇÏÀÚ.
	
	if( IsPlayer() )
	{
		if( IsStateMode( STATE_BASEMOTION_MODE ) )
		{
			SetStateNotMode( STATE_BASEMOTION_MODE, STATEMODE_BASEMOTION_OFF );
			m_nReadyTime = 0;
			m_dwUseItemId = 0;
		}

		SetStun( FALSE );		// ÇÃ·¹ÀÌ¾î¸¸ ºÎÈ°ÈÄ¿¡ ½ºÅÏ ¾È°É·Á ÀÖµµ·Ï Ç®¾îÁÜ.
		SetPoison( FALSE );
		SetDark( FALSE );
		SetBleeding( FALSE );
	}
	
	BOOL fValid	= IsValidObj( this );
	
	if( IsPlayer() && m_pActMover->IsFly() )	// ³¯°íÀÖ´Â Áß¿¡ Á×¾úÀ¸¸é
		UnequipRide();
	
	SendActMsg( OBJMSG_STOP );
	SendActMsg( OBJMSG_DIE, dwMsg, (int)pAttacker );
	
	// ÇÃ·¹ÀÌ¾îÀÎ ³»°¡ Á×¾úÀ¸¸é ³»°¡ Å¸°ÙÀ¸·Î Àâ°íÀÖ´ø³ÑÀ» Ç®¾îÁÜ. ·Î±×¾Æ¿ô °°Àº°Å ÇÒ¶§µµ ¸¶Âù°¡Áö Ã³¸®¸¦ ÇØ¾ßÇÔ.
	if( IsPlayer() )
	{
		CMover *pLastHit = prj.GetMover( m_idLastHitMover );
		if( IsValidObj( pLastHit ) )
		{
			if( pLastHit->m_idAttacker == GetId() )	// pLastHitÀÇ °ø°ÝÀÚ°¡ ³ª·Î ¼³Á¤µÇ¾î ÀÖÀ»¶§¸¸ Ç®¾îÁÜ,.
				pLastHit->m_idAttacker = NULL_ID;	
			if( pLastHit->m_idTargeter == GetId() )
				pLastHit->m_idTargeter = NULL_ID;
		}

		// À¯Àú°¡ Á×¾úÀ»¶§¸¸ ·Î±× ³²±è
		if( fValid )
		{
			g_dpDBClient.SendLogPlayDeath( this, pAttacker );
#if __VER >= 9	// __PET_0410
			// Ä³¸¯ÅÍ°£ÀÇ ÀüÅõ·Î ÀÎÇÑ ¸ðµç Ä³¸¯ÅÍÀÇ »ç¸Á ½Ã ÆêÀº »ç¸ÁÇÏÁö ¾Ê´Â´Ù.	// 0723
			if( IsValidObj( pAttacker ) == FALSE || pAttacker->IsNPC() )
//			if( m_bLastPK == FALSE && m_bGuildCombat == FALSE )
			{
				// Ä³¸¯ÅÍ »ç¸Á ½Ã ¼ÒÈ¯ÁßÀÎ Æêµµ »ç¸Á
				CPet* pPet	= GetPet();
				if( pPet && pPet->GetLevel() != PL_EGG )	// Æê '¾Ë'Àº »ç¸ÁÇÏÁö ¾Êµµ·Ï ¼³Á¤	// 0723
				{
					CItemElem* pItemElem	= GetPetItem();
					int nLife	= (int)pPet->GetLife();
#ifndef __NO_PET_LIFE
					if (--nLife >= 0)
					{
						// »ý¸íÀÌ 0 ÀÌ»óÀÌ¸é, ºÎÈ°
						pPet->SetLife(nLife);
						pPet->SetEnergy(CPetProperty::GetInstance()->GetMaxEnergy(pPet->GetLevel()));
						//					pPet->SetExp( 0 );
#ifdef __GAMEGUARD
						PetRelease();
#endif // __GAMEGUARD
						g_dpDBClient.CalluspPetLog(m_idPlayer, pItemElem->GetSerialNumber(), 0, PETLOGTYPE_DEATH, pPet);
					}
					else
					{
						pPet->SetLife(0);
						pPet->SetEnergy(0);
						pPet->SetExp(0);
						pItemElem->SetFlag(CItemElem::expired);
						UpdateItem((BYTE)(pItemElem->m_dwObjId), UI_FLAG, MAKELONG(pItemElem->m_dwObjIndex, pItemElem->m_byFlag));

						g_dpDBClient.CalluspPetLog(m_idPlayer, pItemElem->GetSerialNumber(), 0, PETLOGTYPE_DEATH, pPet);
					}
#endif
					PetRelease();
					((CUser*)this)->AddPetState(pItemElem->m_dwObjId, pPet->GetLife(), pPet->GetEnergy(), pPet->GetExp());
				}
			}
#endif	// __PET_0410
		}
		// µà¾óÁß ÇÃ·¹ÀÌ¾îÀÇ °æ¿ì 
		// ¸®´õÀÎÁö ÆÇ´ÜÇØ¼­ µà¾óÀ» Ãë¼Ò½ÃÅ°°í 
		// ¾ç ÆÄÆ¼¿øµé¿¡°Ô °á°ú¸¦ Åëº¸ÇÔ.
	}
	
	if( bBehavior ) {
		g_UserMng.AddMoverBehavior2
			( this, GetPos(), m_pActMover->m_vDelta, GetAngle(), GetAngleX(), m_pActMover->m_fAccPower, m_pActMover->m_fTurnAngle, 
			m_pActMover->GetState(), m_pActMover->GetStateFlag(), m_dwMotion, m_pActMover->m_nMotionEx, m_pModel->m_nLoop, m_dwMotionOption, 
			g_TickCount.GetTickCount(), TRUE );
	}
	if( fValid )
	{
//		g_DPCoreClient.SendMoverDeath( this, pAttacker, dwMsg );
		g_UserMng.AddMoverDeath( this, pAttacker, dwMsg );
		
		RemoveAllEnemies();		// pAttacker->SendAIMsg( AIMSG_DSTDIE, GetId() );
	}	// fValid
	
	if( pAttacker )
		pAttacker->m_pActMover->SetObjHit( NULL_ID );
	
	// Å¸°ÙÀ» Á×ÀÎÈÄ AI¿¡¼­ Å¸°ÙÀ» Å¬¸®¾îÇÔ.
	if( IsValidObj(pAttacker) && pAttacker->IsNPC() )
	{
		pAttacker->SendAIMsg( AIMSG_INIT_TARGETCLEAR );		// °ø°ÝÀÚ´Â Å¸°ÙÀ» Å¬¸®¾îÇÏ°í ´ë±â¸ðµå·Î µ¹¾Æ°¨.
	}

	// ¸ó½ºÅÍ¸¦ Á×ÀÌ¸é ¸ó½ºÅÍ°¡ Äù½ºÆ®°¡ ¿ä±¸ÇÏ´Â °ÍÀÎÁö ÆÇ´ÜÇØ¼­ Å³ Ä«¿îÆ® Áõ°¡ 
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
	if( IsPlayer() == FALSE && pAttacker && pAttacker->IsPlayer() )
	{
	
#ifdef	__COLOSSEUM
		CColosseumMatch* pColosseumMatch = CColosseumMng::GetInstance()->GetMatchByMoverID( GetId() );
		if( pColosseumMatch )
			pColosseumMatch->DestroyMover();
#endif // __COLOSSEUM
#ifdef __MONSTER_CLASH
		CMonsterClashMng::GetInstance()->DestroyMover(GetId(), pAttacker->m_idPlayer);
#endif // __MONSTER_CLASH

		for( int i = 0; i < pAttacker->m_nQuestSize; i++ )
		{
			LPQUEST lpQuest = (LPQUEST) &pAttacker->m_aQuest[ i ]; 
			if( !lpQuest )	continue;
			QuestProp* pQuestProp = prj.m_aPropQuest.GetAt( lpQuest->m_wId );
			if( !pQuestProp )	continue;
			
			for( int j = 0; j < MAX_QUEST_COND_KILL; ++j )
			{
				// ÁøÇà ÁßÀÎ Äù½ºÆ®ÀÇ Á¾·á Á¶°Ç°ú °°Àº NPCÀÎ°¡?
				if( pQuestProp->m_nEndCondKillNPCIdx[ j ] != GetIndex() )	continue;

				// ±Ø´Ü Äù½ºÆ®ÀÎ °æ¿ì
				if( pQuestProp->m_nBeginCondParty == 2 )
				{
					CParty* pParty	= g_PartyMng.GetParty( pAttacker->m_idparty );
					// ±Ø´Ü¿øÁß¿¡ ÇØ´ç Äù½ºÆ®¸¦ ÁøÇàÇÏ°í ÀÖÀ¸¸é..
					if( pParty && pParty->IsMember( pAttacker->m_idPlayer ) )
					{
						for( int k = 0; k < pParty->GetSizeofMember(); ++k )
						{
							PartyMember* pPartyMember	= &pParty->m_aMember[k];
							CMover* pMember		= prj.GetUserByID( pPartyMember->m_uPlayerId );
							if( IsValidObj( pMember ) && IsValidArea( pMember, 64.0f ) )
							{
								LPQUEST pMemberQuest	= pMember->GetQuest( lpQuest->m_wId );
								if( pMemberQuest && pMemberQuest->m_nKillNPCNum[j]  < pQuestProp->m_nEndCondKillNPCNum[j] )
								{
									++pMemberQuest->m_nKillNPCNum[j];
									( (CUser*)pMember )->AddSetQuest( pMemberQuest ); 
								}
							}
						}
					}
				}
				else
				if( lpQuest->m_nKillNPCNum[ j ]  < pQuestProp->m_nEndCondKillNPCNum[ j ] )
				{
					++lpQuest->m_nKillNPCNum[ j ];
					( (CUser*)pAttacker )->AddSetQuest( lpQuest );
				}
			}
		}
	}
#else // __IMPROVE_QUEST_INTERFACE
	if( IsPlayer() == FALSE && pAttacker && pAttacker->IsPlayer() )
	{
		for( int i = 0; i < pAttacker->m_nQuestSize; i++ )
		{
			LPQUEST lpQuest = (LPQUEST) &pAttacker->m_aQuest[ i ]; 
			if( lpQuest )
			{
				QuestProp* pQuestProp = prj.m_aPropQuest.GetAt( lpQuest->m_wId );
				if( pQuestProp )
				{
					for( int i = 0; i < MAX_QUEST_COND_KILL; i++ )
					{
						// ÁøÇà ÁßÀÎ Äù½ºÆ®ÀÇ Á¾·á Á¶°Ç°ú °°Àº NPCÀÎ°¡?
						if( pQuestProp->m_nEndCondKillNPCIdx[ i ] == GetIndex() )
						{
							if( lpQuest->m_nKillNPCNum[ i ]  < pQuestProp->m_nEndCondKillNPCNum[ i ] )
							{
								lpQuest->m_nKillNPCNum[ i ]++; // ±×·¸´Ù¸é Å³ ³Ñ¹ö 
								((CUser*)pAttacker)->AddSetQuest( lpQuest ); 
							}
						}
					}
				}
				else
				{
				}
			}
			else
			{
			}
		}
	}
#endif // __IMPROVE_QUEST_INTERFACE

#else // WORLDSERVER
 #ifndef __CLIENT
	CMover *pAttacker = NULL;
	if( pAttackCtrl && pAttackCtrl->GetType() == OT_MOVER )		// ¾îÅÂÄ¿°¡ ¹«¹ö¶ó¸é ¹«¹ö Æ÷ÀÎÅÍ ¸¸µé¾î µÐ´Ù.
		pAttacker = (CMover *)pAttackCtrl;
	SendActMsg( OBJMSG_DIE, dwMsg, (int)pAttacker );
 #endif
#endif // not WORLDSERVER


#if defined(__WORLDSERVER)
	if( GetType() == OT_MOVER )
	{
		RemoveCommonBuffs();
		g_UserMng.AddRemoveAllSkillInfluence( this );
	}

	if( m_nGuildCombatState )
	{
		if( pAttacker && pAttacker->IsPlayer() && GetWorld() )
			GetWorld()->OnDie( this, pAttacker );
	}

#if __VER >= 12 // __SECRET_ROOM
	if( CSecretRoomMng::GetInstance()->IsInTheSecretRoom( this ) )
	{
		if( IsNPC() && pAttacker->IsPlayer() )
			CSecretRoomMng::GetInstance()->SetSecretRoomKill( GetWorld()->GetID(), GetProp()->dwID );
		if( IsPlayer() && CSecretRoomMng::GetInstance()->IsGuildMaster( (CUser*)this ) )
			CSecretRoomMng::GetInstance()->SetFailGuild( (CUser*)this );
	}
#endif // __SECRET_ROOM

#if __VER >= 12 // __NEW_ITEMCREATEMON_SERVER
	if( IsNPC() )
		CCreateMonster::GetInstance()->SetState( GetId(), 'D' );
#endif // __NEW_ITEMCREATEMON_SERVER

#if __VER >= 14 // __INSTANCE_DUNGEON
	if( CInstanceDungeonHelper::GetInstance()->IsInstanceDungeon( GetWorld()->GetID() ) )
	{
		if( !IsPlayer() && pAttacker->IsPlayer() )
			CInstanceDungeonHelper::GetInstance()->SetInstanceDungeonKill( GetWorld()->GetID(), static_cast<DWORD>( this->GetLayer() ), GetProp()->dwID );
	}
#endif // __INSTANCE_DUNGEON
#ifdef __EVENTLUA_SPAWN
	if( IsNPC() )
		prj.m_EventLua.RemoveSpawnedMonster( GetId() );
#endif // __EVENTLUA_SPAWN
#ifdef __MONSTER_HUNTING
	CMonsterHunt::GetInstance()->AddMonsterHuntToPlayer(static_cast<CUser*>(pAttacker), m_dwIndex);
#endif
#ifdef __RECORD_BOOK
	if (IsPlayer())
		CRecordBook::GetInstance()->AddPlayerRecord(this, RecordType::DEATHS, 1, true);
#endif
#endif //__WORLDSERVER	

	return 1;
}


#if __VER >= 8     // 8Â÷ µà¾óÁ¸¿¡ °ü°è¾øÀÌ PVP°¡´ÉÇÏ°ÔÇÔ   Neuz, World

#ifdef __NO_HP_DMG_LIMIT
void	CMover::EndPVP(long long nPVPHP)
#else
void	CMover::EndPVP(int	nPVPHP)
#endif
{
	if(m_bPVPEnd)
		m_bPVPEnd = FALSE;		
	else
		SetPointParam( DST_HP, nPVPHP );	// 2007/11 ¼öÁ¤(HP ºñµ¿±â ¹®Á¦)
		//m_nHitPoint = nPVPHP;
}
//
// µà¾ó³¡³­µÚ Ã³¸®
void	CMover::DoPVPEnd( CCtrl *pAttackCtrl, bool bWinner , DWORD dwMsg )
{
#ifdef __WORLDSERVER

	CMover *pAttacker = NULL;

	if( pAttackCtrl && pAttackCtrl->GetType() == OT_MOVER )		//  ¹«¹ö¶ó¸é ¹«¹ö Æ÷ÀÎÅÍ ¸¸µé¾î µÐ´Ù.
		pAttacker = (CMover *)pAttackCtrl;
	else
		return;

	if( IsPlayer() )
	{
		if( IsStateMode( STATE_BASEMOTION_MODE ) )
		{
			SetStateNotMode( STATE_BASEMOTION_MODE, STATEMODE_BASEMOTION_OFF );
			m_nReadyTime = 0;
			m_dwUseItemId = 0;
		}
	}
	
	SendActMsg( OBJMSG_STOP );
	pAttacker->SendActMsg( OBJMSG_STOP );
	
	m_nDead = PROCESS_COUNT * 3;		// µà¾ó ÈÄ 3ÃÊ°£Àº ¹«Àû
	pAttacker->m_nDead = PROCESS_COUNT * 3;		// µà¾ó ÈÄ 3ÃÊ°£Àº ¹«Àû

	// ÇÃ·¹ÀÌ¾îÀÎ  ³»°¡ Å¸°ÙÀ¸·Î Àâ°íÀÖ´ø³ÑÀ» Ç®¾îÁÜ. 
	if( IsPlayer() )
	{
		CMover *pLastHit = prj.GetMover( m_idLastHitMover );
		if( IsValidObj( pLastHit ) )
		{
			if( pLastHit->m_idAttacker == GetId() )	// pLastHitÀÇ °ø°ÝÀÚ°¡ ³ª·Î ¼³Á¤µÇ¾î ÀÖÀ»¶§¸¸ Ç®¾îÁÜ,.
				pLastHit->m_idAttacker = NULL_ID;	
			if( pLastHit->m_idTargeter == GetId() )
				pLastHit->m_idTargeter = NULL_ID;
		}
	}

	m_bPVPEnd = TRUE;	
	
	if( pAttacker )
	{
		pAttacker->m_pActMover->SetObjHit( NULL_ID );
	}

#endif //__WORLDSERVER	

}
#endif	// __VER >= 8  

#ifdef __WORLDSERVER

#if __VER < 8 // __S8_PK
int CMover::ChangeSlaughter( CHANGE_SLAUGHTER_TYPE type, CMover* pDefender, int nSetCarmaPoint )
{
	int nVal = 0;
	switch( type )
	{
	case CHANGE_SLAUGHTER_KILL:		// PK¿¡ ÀÇÇÑ Slaughter º¯°æ 
		nVal = IncSlaughterPoint( pDefender );	
		break;
	case CHANGE_SLAUGHTER_ATTACK:	// PK½Ãµµ¿¡ ÀÇÇÑ Slaughter º¯°æ 
		nVal = IncSlaughterPoint2( pDefender );	
		break;
	case CHANGE_SLAUGHTER_RECOVERY:	
		if( m_nSlaughter < 0 )
		{
			m_nSlaughter += 1;
			nVal = 1;
		}
		break;
	case CHANGE_SLAUGHTER_SET:
		{
			nVal = nSetCarmaPoint - m_nSlaughter;
			m_nSlaughter = nSetCarmaPoint;
		}
		break;
	}

	if( nVal > 0 )
		((CUser*)this)->AddDefinedText( TID_GAME_GETPKPOINT, "%d", nVal );	// xxx ½½·ÎÅÍ Æ÷ÀÎÆ®¸¦ ¾ò¾ú´Ù
	else if( nVal < 0 )
		((CUser*)this)->AddDefinedText( TID_GAME_DECPKPOINT, "%d", -nVal );	// xxx ½½·ÎÅÍ Æ÷ÀÎÆ®°¡ °¨¼ÒÇß´Ù.

	if( nVal )
	{
		// ½½·ÎÅÍ Æ÷ÀÎÆ®ÀÇ º¯È­°¡ ÀÖ¾úÀ¸¸é °»½Å½ÃÅ´.
		g_UserMng.AddSetSlaughterPoint( this, m_nSlaughter, m_nNumKill );	// ¾îÅÂÄ¿ ÁÖÀ§ Å¬¶ó¿¡ ½½·ÎÅÍÆ÷ÀÎÆ® Áõ°¡¸¦ ¾Ë¸².
		if( pDefender )  // ÀüÅõ¿¡ ÀÇÇÔ 
			g_dpDBClient.SendLogPkPvp( this, pDefender, nVal, 'P' );
	}
	
	return nVal;
}

// Ä«¸£¸¶ µî±ÞÀ» ÇÑ´Ü°è ¿Ã¸°´Ù.
void CMover::UpgradeKarma()
{
	KarmaProp* pProp = prj.GetKarmaProp( m_nSlaughter );
	int nGrade = pProp->nGrade + 1;
	pProp = prj.GetKarmaPropByGrade( nGrade ); 
	ChangeSlaughter( CHANGE_SLAUGHTER_SET, NULL, pProp->nKarmaPoint );
}
#endif // __VER < 8 // __S8_PK

int	CMover::SubPK( CMover *pAttacker, int nReflect )
{
	if( !g_eLocal.GetState( EVE_PK )
#ifdef __JEFF_11_4
		|| GetWorld()->IsArena()
#endif	// __JEFF_11_4
#ifdef __WORLDSERVER_MENU
		|| CDPSrvr::GetInstance()->m_bPk == FALSE
#endif // __WORLDSERVER_MENU
#ifdef __DEATH_MATCH
		|| GetWorld()->m_dwWorldID == WI_WORLD_DEATH_MATCH
#endif // __DEATH_MATCH
		)
		return 1;

#if __VER >= 8 // __S8_PK
	if( GetWorld()->GetID() == WI_WORLD_GUILDWAR && g_GuildCombatMng.m_nState != CGuildCombat::CLOSE_STATE )
		return 1;

	if( pAttacker->GetWorld()->GetID() == WI_WORLD_GUILDWAR && g_GuildCombatMng.m_nState != CGuildCombat::CLOSE_STATE )
		return 1;

#if __VER >= 11 // __GUILD_COMBAT_1TO1
	if( g_GuildCombat1to1Mng.IsPossibleUser( (CUser*)this ) && g_GuildCombat1to1Mng.IsPossibleUser( (CUser*)pAttacker ) )
		return 1;
#endif // __GUILD_COMBAT_1TO1

	if( g_eLocal.GetState( EVE_PKCOST ) 
#ifdef __JEFF_11_4
		&& GetWorld()->IsArena() == FALSE
#endif	// __JEFF_11_4
#ifdef __WORLDSERVER_MENU
		&& CDPSrvr::GetInstance()->m_bPk == TRUE
		&& CDPSrvr::GetInstance()->m_bPkCost == TRUE
#endif // __WORLDSERVER_MENU
		)
	{
		if( IsPlayer() && IsChaotic() )		
		{
#if !defined(__INTERNALSERVER)
			if( m_dwAuthorization < AUTH_HELPER )
#endif
			{
				// ¾ÆÀÌÅÛ µå·Ó 
				// - ÀÎº¥ µå·Ó( ÀåÂøºÎÅÍ µå·ÓÇÏ¸é ¾ÈµÊ - ÀÎº¥°ø°£ÀÌ ºÎÁ·ÇÏ¿© µå·ÓÇÒ¼ö ¾øÀ½ )
				CHAO_PROPENSITY Propensity = prj.GetPropensityPenalty( GetPKPropensity() );
				int nInvenDrop = xRandom( Propensity.nInvenDorpMin, Propensity.nInvenDorpMax + 1 );
				for( int i=0; i < nInvenDrop; ++i )
				{
					if( DoDropItemRandom( TRUE, pAttacker ) == 0 )	
						break;
				}

				// - ÀåÂø µå·Ó
				int nEquipDrop = xRandom( Propensity.nEquipDorpMin, Propensity.nEquipDorpMax + 1 );
				for( int i=0; i < nEquipDrop; ++i )
				{
					if( DoDropItemRandom( FALSE, pAttacker, TRUE ) == 0 )	
						break;
				}				
			}
		}				
	}

	if( !pAttacker->IsPlayer() || IsNPC() )
		return 1;

	BOOL bAdd = FALSE;
	if( pAttacker->IsChaotic() )	// Ä«¿À»óÅÂ
	{
		if( !IsChaotic() )
			bAdd = TRUE;
	}
	else							// ÇÎÅ©»óÅÂ, Èù»ö»óÅÂ
	{
		if( !(IsChaotic() || IsPKPink()) )
			bAdd = TRUE;
	}
	
		/// Ä«¿À¼öÄ¡, ¼ºÇâÀ» ¿Ã·ÁÁÜ
	if( bAdd && nReflect == 0 
		&& pAttacker != this ) // chipi_081119 Áö¼ÓÇü µ¥¹ÌÁö ½ºÅ³ ¹Þ°í ÀçÁ¢ÇÏ¸é ÀÚ»ìµÇ¾î Ä«¿ÀµÇ´Â ¹®Á¦ ¼öÁ¤...
	{
		if( IsPlayer() && pAttacker->IsPlayer() )
		{
			if( !pAttacker->IsChaotic() )
				((CUser*)pAttacker)->AddPlaySound( SND_PC_CHAOS );
			CString szSendMsg;
			szSendMsg.Format( prj.GetText(TID_GAME_PK_DEFENDER) , pAttacker->GetName() );
			((CUser*)this)->AddText( szSendMsg );
			szSendMsg.Format( prj.GetText(TID_GAME_PK_ATTACKER) , GetName() );
			((CUser*)pAttacker)->AddText( szSendMsg );
		}
#ifdef __WORLDSERVER_MENU
		if (CDPSrvr::GetInstance()->m_bPkCost == TRUE)
#endif // __WORLDSERVER_MENU
		{
			pAttacker->SetPKValue(pAttacker->GetPKValue() + 1);
			((CUser*)pAttacker)->AddPKValue();
			pAttacker->SetPKPropensity(pAttacker->GetPKPropensity() + NextPKPropensity(pAttacker->GetPKValue()));
			g_UserMng.AddPKPropensity(pAttacker);
			g_dpDBClient.SendLogPkPvp(pAttacker, this, 0, 'P');
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
#ifndef __MAINSERVER
			if (!pAttacker->IsPlayer())
				FILEOUT("..\\HonorError.txt", "subpk()AddHonorListAck()\n");
#endif // __MAINSERVER
			((CUser*)pAttacker)->SetHonorAdd(HS_PK_COUNT, HI_COUNT_CHECK);
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
		}
	}
#else // __VER >= 8 // __S8_PK
	BOOL bChaotic = IsChaotic();

	m_idMurderer = pAttacker->m_idPlayer;	// ³¯ ¸¶Áö¸·À¸·Î Á×ÀÎ³ðÀÇ ÇÃ·¹ÀÌ¾î¾ÆÀÌµð¸¦ ÀúÀåÇØµÒ.
	pAttacker->m_nNumKill++;				// Å³¼ö Áõ°¡
	((CUser*)this)->AddDefinedText( TID_GAME_PKDEAD, "\"%s\"", pAttacker->m_szName );	// ??¿¡°Ô Á×À½À» ´çÇÏ¿´½À´Ï´Ù.

	int nGap = abs( this->GetLevel() - pAttacker->GetLevel() );
	if( nGap >= 80 )
		ChangeFame( this );	// 80 ÀÌ»óÀÏ Â÷ÀÌ ³¯ °æ¿ì, ¿¹¿ÜÀûÀ¸·Î ¸í¼ºÄ¡ Áõ°¨  

	// º¸»ó±Ý ¶³±¸±â¸¦ ¿äÃ»ÇÑ´Ù.
	CWorld* pWorld = GetWorld();
	if( pWorld )
	{
		//"%s´ÔÀÌ Çö»ó¹ü %s¸¦ Àâ¾Æ Çö»ó±Ý %sÆä³Ä¸¦ ¾ò¾ú½À´Ï´Ù."
		char szFormat[256];
		strcpy( szFormat, pAttacker->GetName() );
		strcat( szFormat, prj.GetText( TID_PK_REWARDNOTICE ) );
		g_DPCoreClient.SendWCWantedReward( m_idPlayer, pAttacker->m_idPlayer, szFormat, pWorld->GetID(), GetPos() );
	}

	if( g_eLocal.GetState( EVE_PKCOST ) 
#ifdef __JEFF_11_4
		&& ( pWorld && pWorld->IsArena() == FALSE )
#endif	// __JEFF_11_4
#ifdef __WORLDSERVER_MENU
		&& CDPSrvr::GetInstance()->m_bPk == TRUE
		&& CDPSrvr::GetInstance()->m_bPkCost == TRUE
#endif // __WORLDSERVER_MENU
		)
	{
		if( bChaotic )		
		{
		#if !defined(__INTERNALSERVER)
			if( m_dwAuthorization < AUTH_HELPER )
		#endif
			{
				// Æä³Äµå·Ó 
				KarmaProp* pProp = prj.GetKarmaProp( m_nSlaughter );
				float fRate = pProp->nDropGoldPercent / 100.0f;
				int nGold = GetGold() * fRate;
			
				if( nGold > 0 )
					DropGold( nGold , GetPos(), TRUE );
					
				// ¾ÆÀÌÅÛ µå·Ó 
				for( int i=0; i<pProp->nDropItem; ++i )
				{
					BOOL bExcludeEquip = ( i == 0 );	// 1°³ ÀÌÇÏÀÇ °æ¿ì, ÀåÂø ¾ÆÀÌÅÛÀº ¶³±¸Áö ¾Ê´Â´Ù.

					if( xRandom( 100 ) < pProp->nDropPercent )	
					{
						if( DoDropItemRandom( bExcludeEquip, pAttacker ) == 0 )	
							break;
					}
				}
			}
		}				
	}

	//pAttackerÀÇ slaughter°ªÀ» º¯°æ½ÃÅ²´Ù.
	pAttacker->ChangeSlaughter( CHANGE_SLAUGHTER_KILL, this );
	// ÁØÄ«¿À À¯Àú´Â PK·Î »ç¸Á ´çÇÒ °æ¿ì, Ä«¸£¸¶ µî±ÞÀÌ ÇÑ ´Ü°è ¿Ã¶ó°£´Ù.
	if( GetSlaughterGrade() == SLAUGHTER_SEMI_CHAOTIC )
		UpgradeKarma();
#endif // __VER >= 8 // __S8_PK
	return 1;
}

int CMover::SubDuel( CMover *pAttacker )
{
	if( m_nDuel )
		pAttacker->DuelResult( this );	// µà¾óÈÄ °á°ú Ã³¸®.

	return 1;
}

int CMover::SubWar( CMover *pAttacker )
{
#ifdef __WORLDSERVER
	// ±æµåÀü °¡´ÉÇÑ ¼­¹öÀÎ°¡.
	if( g_eLocal.GetState( EVE_GUILDWAR ) == 0 )	
		return 0;

	// ³ª¶û ´Ù¸¥±æµåÀÎ°¡(µ¿¸ÍÀÎ°æ¿ì´Â ÀÌ°É·Î ¾ÈµÈ´Ù.)
	if( m_idGuild == pAttacker->m_idGuild )
		return 0;

	// Àû´ë±æµå¿ø¿¡°Ô Á×¾ú´Ù.
	g_DPCoreClient.SendWarDead( m_idPlayer );
#endif	// __WORLDSERVER
	return 1;
}

PVP_MODE CMover::GetPVPCase( CMover *pAttacker )
{
	BOOL bPKEnable = FALSE;
	if( g_eLocal.GetState( EVE_18 ) == 1 )			// 18¼¼ ¼­¹ö 
		bPKEnable = TRUE;

	if( bPKEnable == FALSE || 
		pAttacker == NULL  || 
		pAttacker->IsNPC() || // Á×ÀÎ³ðÀÌ NPC¸é °Á ¸®ÅÏ.
		IsNPC() )			  // Á×Àº³ðÀÌ NPC¸é °Á¸®ÅÏ
		return PVP_MODE_NONE;

	// ÀÌ°Ç »ç¶÷´ë »ç¶÷ÀÇ ½Î¿òÀÌ´Ù!
	if( m_idWar && pAttacker->m_idWar == m_idWar )	// ³ª¶û °°Àº ÀüÀï¿¡ Âü°¡ÁßÀÎ ³ðÀÎ°¡.
	{
		return PVP_MODE_GUILDWAR;
	}
	
#ifdef __AEGON_FIXES
	if (g_GuildCombatMng.m_nState == CGuildCombat::WAR_STATE)
	{
		CWorld* pWorld = GetWorld();
		CWorld* pWorldAttacker = pAttacker->GetWorld();
		if (pWorld && pWorldAttacker && pWorld->GetID() == WI_WORLD_GUILDWAR && pWorldAttacker->GetID() == WI_WORLD_GUILDWAR)
		{
			if (g_GuildCombatMng.IsSelectPlayer((CUser*)pAttacker) && g_GuildCombatMng.IsSelectPlayer((CUser*)this))
			{
				return PVP_MODE_GUILDWAR;
			}
		}
	}

#endif

	if( m_nDuel == 0 || m_nDuelState == 300 )	// PK
	{
/*		if( GetTickCount() < m_dwPKTargetLimit )		// PK¼±°øºÒ°¡½Ã°£µ¿¾È¿¡´Â ¼±°øÀÌ ¾ÈµÊ  
		{
			return PVP_MODE_NONE;
		}	*/	// mirchang 100114 µà¾óÁß Å¸ À¯Àú¿¡°Ô PK´çÇÑ°æ¿ì °æÇèÄ¡ ÇÏ¶ôÀÌ µÇÁö ¾Ê´Â´Ù. ³»°¡ Ä«¿ÀÀÏ °æ¿ì Ä«¿À¼öÄ¡¸¸ ¶³¾îÁö±â ¶§¹®¿¡ ¾Ç¿ëÀÇ ¼ÒÁö°¡ ÀÖÀ½..
		return PVP_MODE_PK;
	} 
	else				//µà¾ó »óÈ².	
	{
		return PVP_MODE_DUEL; 
	}
}

// this°¡ Á×°í ³­ÈÄ PVP(PK, µà¾ó, ±æµåÀü)Ã³¸®
void CMover::SubPVP( CMover *pAttacker, int nReflect )
{
	if( m_nDuel == 1 )
	{
		if( GetId() != pAttacker->m_idDuelOther )
		{
			CUser* pOther	= prj.GetUser( m_idDuelOther );
			if( IsValidObj( (CObj*)pOther ) )
			{
				pOther->AddDuelCancel( pOther->m_idDuelOther );
				pOther->ClearDuel();
			}
			( (CUser*)this )->AddDuelCancel( m_idDuelOther );
			ClearDuel();
			//return;	// mirchang 100114 µà¾ó Áß ´Ù¸¥ À¯Àú¿¡°Ô PK¸¦ ´çÇÑ°æ¿ì SubPK() ·Î °¡µµ·Ï..
		}
	}
	else if( m_nDuel == 2 )
	{
		if( m_idDuelParty != pAttacker->m_idparty || pAttacker->m_nDuelState == 300 )
		{
			CParty *pLoseParty = g_PartyMng.GetParty( m_idparty );

			if( pLoseParty && pLoseParty->IsLeader( m_idPlayer ) )
			{
				g_DPCoreClient.SendSetPartyDuel( m_idDuelParty, pLoseParty->m_uPartyId, FALSE );

				CParty* pParty2	= g_PartyMng.GetParty( m_idDuelParty );
				if( pParty2 )
					pParty2->DoDuelPartyCancel( pLoseParty );
				pLoseParty->DoDuelPartyCancel( pParty2 );
			}
		}
	}

	PVP_MODE mode = GetPVPCase( pAttacker );
	switch( mode )
	{
	case PVP_MODE_GUILDWAR:
		SubWar( pAttacker );
		break;
#if __VER >= 8 // __S8_PK
	case PVP_MODE_NONE:
#endif // __VER >= 8 // __S8_PK
	case PVP_MODE_PK:
		SubPK( pAttacker, nReflect );		// PKÀÇ ¼­ºê·çÆ¾.
		break;
	case PVP_MODE_DUEL:
		SubDuel( pAttacker );
		break;
	}
}

void CMover::AddPartyMemberExperience( CUser * pUser, EXPINTEGER nExp, int nFxp )
{
	if( nFxp )	// ºñÇà°æÇèÄ¡°¡ 0ÀÎ°æ¿ì´Â ¾Æ¹« Ã³¸®µµ ¾ÈÇØµµ µÈ´Ù.
	{
		if( pUser->AddFxp( nFxp ) )
		{
			// ºñÇà·¹º§¾÷!
			g_UserMng.AddSetFlightLevel( pUser, pUser->GetFlightLv() );
		} else
		{
			// ·¹º§¾÷ÇÏÁö ¾Ê°í °æÇèÄ¡¸¸ ¿Ã¶ó°¨.
			// ·Î±× ³²±æ°Í.
		}
		pUser->AddSetFxp( pUser->m_nFxp, pUser->GetFlightLv() );		// ´ç»çÀÚ¿¡°Ô ºñÇà°æÇèÄ¡/·¹º§À» º¸³¿.
	}

	if( nExp > prj.m_aExpCharacter[pUser->m_nLevel].nLimitExp )
		nExp	= prj.m_aExpCharacter[pUser->m_nLevel].nLimitExp;

	if( pUser->AddExperience( nExp, TRUE, TRUE, TRUE ) )
		pUser->LevelUpSetting();
	else
		pUser->ExpUpSetting();

	pUser->AddSetExperience( pUser->GetExp1(), (WORD)pUser->m_nLevel, pUser->m_nSkillPoint, pUser->m_nSkillLevel );
}

// this°¡ Á×Àº¹«¹ö´Ù.
// this¸¦ Áß½ÉÀ¸·Î ¹Ý°æ fRange ÀÌ³»¿¡ ÀÖ´Â »ç¶÷µé¿¡°Ô °æÇèÄ¡¸¦ ºÐ¹èÇÑ´Ù.
void CMover::SubAroundExp( CMover *pAttacker, float fRange )
{
#if 1
#define MAX_AROUND_USER		512

	D3DXVECTOR3	vPos = GetPos();
	D3DXVECTOR3 vDist;
	FLOAT		fDistSq;
	CUser *pUser;
	CUser *pList[ MAX_AROUND_USER ], **ptr;
	int		nMaxList = 0;
	int		i;

	TRACE( "º¸½º¸÷ Á×ÀÓ %s\n", pAttacker->GetName() );
	fRange *= fRange;		// Sq ¹öÀüÀ¸·Î ¹Ù²Þ.

	memset( pList, 0, sizeof(pList) );
	ptr = pList;

	// ¹Ý°æ³»¿¡ ÀÖ´Â À¯Àú¸¦ Ãß·Á³¿.
	FOR_VISIBILITYRANGE( this )
	{
		pUser = USERPTR;
		vDist = vPos - pUser->GetPos();
		fDistSq = D3DXVec3LengthSq( &vDist );		// Á×Àº³Ñ°ú À¯Àú»çÀÌÀÇ °Å¸®Sq¸¦ ±¸ÇÔ 
		if( fDistSq <= fRange )				// ¹Ý°æ fRange ¹ÌÅÍ ÀÌ³»¿¡ ÀÖ´Â »ç¶÷Àº
		{
			*ptr++ = pUser;
			nMaxList ++;
		}
	}	
	NEXT_VISIBILITYRANGE( this )

	if( nMaxList == 0 )
	{
		Error( "CMover::SubAroundExp %sÁÖÀ§¿¡ À¯Àú°¡ ¾ø´Ù. ", GetName() );
		return;
	}


	EXPINTEGER nExp		= GetProp()->nExpValue / (EXPINTEGER)nMaxList;	// 1ÀÎ´ç ¾ó¸¶¾¿ ¹èºÐµÇ¾ß ÇÏ´Â°¡.
	// Ãß·Á³½ À¯Àúµé¿¡°Ô °æÇèÄ¡¸¦ ÁÜ.
	ptr = pList;
	for( i = 0; i < nMaxList; i ++ )
	{
		pUser = *ptr++;

		if( nExp > prj.m_aExpCharacter[pUser->m_nLevel].nLimitExp )
			nExp	= prj.m_aExpCharacter[pUser->m_nLevel].nLimitExp;

		if( pUser->AddExperience( nExp, TRUE, TRUE, TRUE ) )
		{
			// ·¹º§¾÷ µÆ´Ù.
			g_UserMng.AddSetLevel( pUser, (WORD)pUser->m_nLevel );		// pUserÀÇ ÁÖÀ§»ç¶÷¿¡°Ô pUser°¡ ·¹º§ÀÌ ¿Ã¶ú´Ù´Â°É º¸³¿.
			((CUser*)pUser)->AddSetGrowthLearningPoint( pUser->m_nRemainGP );		// pUser¿¡°Ô GPº¯µ¿µÈ°ÍÀ» º¸³¿.
			g_dpDBClient.SendLogLevelUp( pUser, 1 );	// ·¹º§¾÷ ·Î±×
#if __VER >= 11 // __SYS_PLAYER_DATA
			g_dpDBClient.SendUpdatePlayerData( pUser );
#else	// __SYS_PLAYER_DATA
			if( 0 < pUser->GetPartyId() )
			g_DPCoreClient.SendPartyMemberLevel( pUser );
			if( pUser->m_idGuild != 0 )
				g_DPCoreClient.SendGuildChangeJobLevel( (CUser*)pUser );
#endif	// __SYS_PLAYER_DATA
		}
		else
		{
			// ·¹º§¾÷ ¾ÈµÇ°í °âÄ¡¸¸ ¿Ã¶ú´Ù.
			// ·¹º§ 5ÀÌ»óÀÏ¶§´Â °æÇèÄ¡ ¾÷À» ·Î±×_·¹º§¾÷ Å×ÀÌºí¿¡ ·Î±×¸¦ ³²±ä´Ù
			// °æÇèÄ¡ 20% ´ÜÀ§·Î ·Î±×¸¦ ³²±è
#ifdef __EXP_ANGELEXP_LOG
			int nNextExpLog = (int)(pUser->m_nExpLog/20 + 1) * 20;	
			int nExpPercent = (int)( GetExp1() * 100 / GetMaxExp1() );
			if( nExpPercent >= nNextExpLog )
			{
				pUser->m_nExpLog = nExpPercent;
				g_dpDBClient.SendLogLevelUp( this, 5 );
			}
#else // __EXP_ANGELEXP_LOG
			int iLogExp = GetExp1() * 100 / GetMaxExp1();
			iLogExp /= 20;
			if( pUser->GetLevel() > 5 ) // ·¹º§ 5ÀÌ»ó
			{
				if( ( 20 * ( iLogExp + 1 ) ) <= ( pUser->GetExp1() * 100 / pUser->GetMaxExp1() ) )
					g_dpDBClient.SendLogLevelUp( pUser, 5 );
			}
#endif // __EXP_ANGELEXP_LOG
		}
		// pUser¿¡°Ô °æÇèÄ¡ ¹Ù²ï°É º¸³¿
		((CUser*)pUser)->AddSetExperience( pUser->GetExp1(), (WORD)pUser->m_nLevel, pUser->m_nSkillPoint, pUser->m_nSkillLevel );
	}		
#endif // 0
}

void CMover::AddKillRecovery()
{
	if( IsPlayer() == FALSE )	return; // this(Attacker)°¡ ¸ó½ºÅÍ¸é Ã³¸®¾ÈÇÔ.
	
	int nHPPoint = GetParam( DST_KILL_HP, 0 );
	int nMPPoint = GetParam( DST_KILL_MP, 0 );
	int nFPPoint = GetParam( DST_KILL_FP, 0 );
	
	BOOL bSfx = FALSE;
	if( nHPPoint )
	{
		int nHP	   = GetPointParam( DST_HP );
		int nHPMax = GetMaxPoint( DST_HP );
		if( nHP + nHPPoint >= nHPMax )	// Æ÷ÀÎÆ® ´õÇßÀ»¶§ ¿À¹ÙµÇ´Â°É Ã³¸®.
			nHP = nHPMax;
		else
			nHP = nHP + nHPPoint;
		SetPointParam( DST_HP, nHP );
		bSfx = TRUE;
	}
	
	if( nMPPoint )
	{
		int nMP	   = GetPointParam( DST_MP );
		int nMPMax = GetMaxPoint( DST_MP );
		if( nMP + nMPPoint >= nMPMax )	// Æ÷ÀÎÆ® ´õÇßÀ»¶§ ¿À¹ÙµÇ´Â°É Ã³¸®.
			nMP = nMPMax;
		else
			nMP = nMP + nMPPoint;
		SetPointParam( DST_MP, nMP );
		bSfx = TRUE;
	}
	
	if( nFPPoint )
	{
		int nFP	   = GetPointParam( DST_FP );
		int nFPMax = GetMaxPoint( DST_FP );
		if( nFP + nFPPoint >= nFPMax )	// Æ÷ÀÎÆ® ´õÇßÀ»¶§ ¿À¹ÙµÇ´Â°É Ã³¸®.
			nFP = nFPMax;
		else
			nFP = nFP + nFPPoint;
		SetPointParam( DST_FP, nFP );
		bSfx = TRUE;
	}
	
	if( bSfx )
		g_UserMng.AddCreateSfxObj( this, XI_KILL_RECOVERY );
}

// pDead¸¦ Á×ÀÎÈÄ °æÇèÄ¡ Ã³¸®
int CMover::SubExperience( CMover *pDead )
{
	if( IsPlayer() == FALSE )	return 0;	// this(Attacker)°¡ ¸ó½ºÅÍ¸é Ã³¸®¾ÈÇÔ.
	if( pDead->IsPlayer() )	return 0;			// Á×Àº³ÑÀÌ ÇÃ·¹ÀÌ¾î¸é °æÇèÄ¡ Ã³¸®ÇÒÀÏÀÌ ¾øÀ½.
	
	MoverProp* pMoverProp	= pDead->GetProp();
	ASSERT( pMoverProp );

#ifdef __WORLDSERVER
	EXPFLOAT fExpValue = 0;
	float	fFxpValue = 0.0f;
	#ifdef __S1108_BACK_END_SYSTEM
//			fExpValue	= pMoverProp->nExpValue * static_cast<EXPFLOAT>( prj.m_fMonsterExpRate ) * static_cast<EXPFLOAT>( pMoverProp->m_fExp_Rate );
//			fFxpValue	= pMoverProp->nFxpValue * prj.m_fMonsterExpRate * pMoverProp->m_fExp_Rate;
			fExpValue	= pMoverProp->nExpValue * static_cast<EXPFLOAT>( pMoverProp->m_fExp_Rate );
			fFxpValue	= pMoverProp->nFxpValue * pMoverProp->m_fExp_Rate;
	#else // __S1108_BACK_END_SYSTEM
//			fExpValue	= pMoverProp->nExpValue * static_cast<EXPFLOAT>( prj.m_fMonsterExpRate );
// 			fFxpValue	= pMoverProp->nFxpValue * prj.m_fMonsterExpRate;
			fExpValue	= pMoverProp->nExpValue;
 			fFxpValue	= pMoverProp->nFxpValue;
	#endif // __S1108_BACK_END_SYSTEM
#else	// __WORLDSERVER
	EXPFLOAT fExpValue	= static_cast<EXPFLOAT>( pMoverProp->nExpValue );
#ifdef __REBIRTH_EXP
	if (m_nCampusPoint >= 1)
		fExpValue /= m_nCampusPoint;
#endif
	float	fFxpValue	= pMoverProp->nFxpValue;
#endif	// __WORLDSERVER

#ifndef __GAMEGUARD
	if (IsAuthHigher(AUTH_ADMINISTRATOR)) 	// ¿î¿µÀÚ °èÁ¤ÀÏ¶§
#endif // __GAMEGUARD
	{
		if( IsMode( MODE_EXPUP_STOP ) )			// °æÇèÄ¡ »ó½Â ±ÝÁö »óÅÂ¸é
		{
			fExpValue = 0;						// °æÇèÄ¡°ª 0
		}
	}
#ifdef __3RD_LEGEND16
	if (GetLevel() == MAX_LEGEND_LEVEL && !IsLegendHero())
		return FALSE;
#endif // __3RD_LEGEND16

#ifdef __NEWCLASS
	if (GetLevel() == MAX_3RD_LEGEND_LEVEL && !IsLegendHeroUltimate())
		return FALSE;
#endif // __NEWCLASS

	AddExperienceKillMember( pDead, fExpValue, pMoverProp, fFxpValue );
	return 1;
}

BOOL CMover::IsValidArea( CMover* pMover, float fLength )
{
	float fDist;
	D3DXVECTOR3	vDist;
	if( IsValidObj( (CObj*)this) && IsValidObj( (CObj*)pMover ) && GetWorld() == pMover->GetWorld()/*2008.04.11 µ¿¸Ê °Ë»ç Ãß°¡*/
#ifdef __LAYER_1015
		&& GetLayer() == pMover->GetLayer() // 2008.12.26 ·¹ÀÌ¾î °Ë»ç
#endif // __LAYER_1015
		)
	{
		vDist = pMover->GetPos() - GetPos();
		fDist = D3DXVec3LengthSq( &vDist );
		if( fDist < fLength * fLength )
		{
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CMover::GetPartyMemberFind( CParty* pParty, CUser* apMember[], int* nTotalLevel, int* nMaxLevel10, int* nMaxLevel, int* nMemberSize )
{
	CUser* pUsertmp = NULL;
	D3DXVECTOR3	vDist;

	for( int i = 0 ; i < pParty->m_nSizeofMember ; i++ )	
	{
		pUsertmp	= g_UserMng.GetUserByPlayerID( pParty->m_aMember[i].m_uPlayerId );
		if( IsValidArea( (CMover*)pUsertmp, 64.0f ) )
		{
			apMember[(*nMemberSize)++]	= pUsertmp;
			(*nTotalLevel)		+= pUsertmp->GetLevel();
			if( (*nMaxLevel10) < pUsertmp->GetLevel() )
			{
				(*nMaxLevel) = (*nMaxLevel10) = pUsertmp->GetLevel();
			}			
		}
	}
	
	if( 0 < (*nMaxLevel10) - 20 )
	{
		(*nMaxLevel10) -= 20;
	}
	else
	{
		(*nMaxLevel10) = 0;
	}

	if( (*nMemberSize) == 0 || (*nTotalLevel) == 0 )
	{
		return FALSE;
	}

	return TRUE;
}

void CMover::AddExperienceKillMember( CMover *pDead, EXPFLOAT fExpValue, MoverProp* pMoverProp, float fFxpValue )
{
	vector<OBJID>	adwEnemy;
#ifdef __NO_HP_DMG_LIMIT
	std::vector<long long> anHitPoint;
	unsigned long long dwMaxEnemyHit = 0;
#else
	vector<int>        anHitPoint;
	DWORD    dwMaxEnemyHit = 0;
#endif
	for( SET_OBJID::iterator it = pDead->m_idEnemies.begin(); it != pDead->m_idEnemies.end(); ++it )
	{
		adwEnemy.push_back( (*it).first );
		anHitPoint.push_back( (*it).second.nHit );
		dwMaxEnemyHit	+= (*it).second.nHit;
	}

	if( adwEnemy.size() > 1024 )
	{
		Error( "CMover::AddExperienceKillMember - enemy size is too big" );
	}

	if( dwMaxEnemyHit == 0 )		//
		return;

	for( DWORD j = 0; j < adwEnemy.size(); j++ )
	{
		if( adwEnemy[j] == 0 )		// ¹«½Ã
			continue;
		CMover* pEnemy	= prj.GetMover( adwEnemy[j] );
		if( IsValidObj( pEnemy ) && pDead->IsValidArea( pEnemy, 64.0f ) && pEnemy->IsPlayer() )		// ÇÃ·¹ÀÌ¾î, ¹üÀ§ °Ë»ç
		{
#ifdef __NO_HP_DMG_LIMIT
			unsigned long long dwHitPointParty = 0;
#else
			DWORD dwHitPointParty = 0;
#endif
			CParty* pParty	= g_PartyMng.GetParty( pEnemy->m_idparty );
			if( pParty && pParty->IsMember( pEnemy->m_idPlayer ) )
			{
				dwHitPointParty		= anHitPoint[j];
				for( DWORD k = j + 1 ; k < adwEnemy.size(); k++ )
				{
					if( adwEnemy[k] == 0 )
						continue;	// Áßº¹ Ã³¸® ½ºÅµ
					CMover* pEnemy2	= prj.GetMover( adwEnemy[k] );
					if( IsValidObj( pEnemy2 ) && pDead->IsValidArea( pEnemy2, 64.0f ) && pEnemy2->IsPlayer() )	// ÇÃ·¹ÀÌ¾î, ¹üÀ§ °Ë»ç
					{
						if( pEnemy->m_idparty == pEnemy2->m_idparty && pParty->IsMember( pEnemy2->m_idPlayer ) )	// °°Àº ÆÄÆ¼ »èÁ¦ ´ë»ó
						{
							dwHitPointParty		+= anHitPoint[k];
							adwEnemy[k]	= 0;	// Áßº¹ Ã³¸® ¹æÁö
						}
					}
					else
					{
						adwEnemy[k]	= 0;		// »èÁ¦ ´ë»ó
					}
				}
			}
			if( dwHitPointParty > 0 )
				anHitPoint[j]	= dwHitPointParty;
#ifdef __NO_HP_DMG_LIMIT
			double fExpValuePerson = (double)(fExpValue * (double(anHitPoint[j]) / double(dwMaxEnemyHit)));
#else
			float fExpValuePerson = (float)(fExpValue * (float(anHitPoint[j]) / float(dwMaxEnemyHit)));
#endif
			if( dwHitPointParty )		// ±Ø´Ü °æÇèÄ¡ ºÐ¹è
			{	
				int nTotalLevel		= 0;
				int nMaxLevel10	= 0;
				int nMaxLevel	= 0;
				int nMemberSize		= 0;
				CUser* apMember[MAX_PTMEMBER_SIZE];
				memset( apMember, 0, sizeof(apMember) );
				// 1. ÁÖº¯ ¸â¹ö °Ë»ç
				if( pEnemy->GetPartyMemberFind( pParty, apMember, &nTotalLevel, &nMaxLevel10, &nMaxLevel, &nMemberSize ) == FALSE )
					break;
#if __VER >= 14 // __PCBANG
				fExpValuePerson *= CPCBang::GetInstance()->GetPartyExpFactor( apMember, nMemberSize );
#endif // __PCBANG
				if( 1 < nMemberSize )	// ÆÄÆ¼¿ø°¡ °°ÀÌ ÀÖÀ½	// ÆÄÆ¼¿øµé °æÇèÄ¡ ÁÖ±â
					pEnemy->AddExperienceParty( pDead, fExpValuePerson, pMoverProp, fFxpValue, pParty, apMember, &nTotalLevel, &nMaxLevel10, &nMaxLevel, &nMemberSize );
				else	// È¥ÀÚ¼­ ½Î¿î°ÍÀ¸·Î Ã³¸®.
#ifdef __SOLO_PARTY_EXP
				{
					if (pParty)
						pParty->GetPoint(nTotalLevel, nMemberSize, pDead->GetLevel());
					pEnemy->AddExperienceSolo(fExpValuePerson, pMoverProp, fFxpValue, TRUE);
				}
#else
					pEnemy->AddExperienceSolo(fExpValuePerson, pMoverProp, fFxpValue, TRUE);
#endif
			}
			else
			{
#if __VER >= 14 // __PCBANG
				if( IsPlayer() )
					fExpValuePerson *= CPCBang::GetInstance()->GetExpFactor( static_cast<CUser*>( this ) );
#endif // __PCBANG
				pEnemy->AddExperienceSolo( fExpValuePerson, pMoverProp, fFxpValue, FALSE );
			}
		}
	}
}

void CMover::AddExperienceSolo( EXPFLOAT fExpValue, MoverProp* pMoverProp, float fFxpValue, BOOL bParty )
{
	if( g_eLocal.GetState( EVE_EVENT0214 ) && !bParty )	// ¹ß·»Å¸ÀÎ ÀÌº¥Æ® Áß ¼Ö·Î ÇÃ·¹ÀÌ ½Ã °æÇèÄ¡ 1.5¹è
		fExpValue	*= static_cast<EXPFLOAT>( 1.5f );
		

#if __VER < 8    // 8Â÷ ½ºÅ³°æÇèÄ¡´Ù¿îº¯°æ
		// Á×À½ ÀÌÈÄ »óÅÂ¶ó¸é °æÇèÄ¡¸¦ 150%ÁØ´Ù.
		if( IsAfterDeath() )
			fExpValue	*= static_cast<EXPFLOAT>( 1.5f );
#endif	// __VER < 8  

#if __VER < 9 // __S_9_ADD
//#ifdef __VCRITICAL
		// Å©¸®Æ¼Ä®·ü Á¶Á¤. ³» HP°¡ CRITICAL_BERSERK_HP%º¸´Ù ÀûÀ¸¸é Àû¿ë
		int nHitPercent = GetHitPointPercent( 100 );
		if( nHitPercent < CRITICAL_BERSERK_HP )
		{
			// CRITICAL_BERSERK_HP : ( fExpValue * 0.2 ) = nHitPercent : x
			// 30 : ( 1000 * 0.2 ) = 0 : x
			if( nHitPercent <= 10 )
				fExpValue	*= 1.2f;
			else
				fExpValue	+= ( fExpValue * .2f ) - ( ( fExpValue * .2f ) * nHitPercent / CRITICAL_BERSERK_HP );
		}
//#endif
#endif // __S_9_ADD
		// ·¹º§¿¡ µû¶ó °æÇèÄ¡¸¦ ÁØ´Ù. ·¾ÀÌ ³ªº¸´Ù ³·À»°æ¿ì 70  %, ³ªº¸´Ù ³ôÀ»°æ¿ì 130 %
		int dw_Level = GetLevel() - (int)pMoverProp->dwLevel;
		if( dw_Level > 0 )
		{
			if( 1 == dw_Level || dw_Level == 2 )		// 1~2 Â÷ÀÌ
			{
				fExpValue	*= static_cast<EXPFLOAT>( 0.7f );
				fFxpValue	*= 0.7f;
			}
			else if( 3 == dw_Level || dw_Level == 4 )	// 3~4 Â÷ÀÌ
			{
				fExpValue	*= static_cast<EXPFLOAT>( 0.4f );
				fFxpValue	*= 0.4f;
			}
			else										// 5ÀÌ»ó Â÷ÀÌ
			{
				fExpValue	*= static_cast<EXPFLOAT>( 0.1f );
				fFxpValue	*= 0.1f;
			}
		}

		EXPINTEGER	iLogExp		= GetExp1() * 100 / GetMaxExp1();
		iLogExp	/= 20;

		if( fExpValue > static_cast<EXPFLOAT>( prj.m_aExpCharacter[m_nLevel].nLimitExp ) )
			fExpValue	= static_cast<EXPFLOAT>( prj.m_aExpCharacter[m_nLevel].nLimitExp );

		// ¿Ã¸± ºñÇà°æÇèÄ¡°¡ ¾ø´Ù¸é ½ÇÇà¾ÈÇØµµ µÈ´Ù.
		if( fFxpValue )
		{
			if( AddFxp( (int)fFxpValue ) )
			{
#ifdef __WORLDSERVER
				g_UserMng.AddSetFlightLevel( this, GetFlightLv() );
#endif	// __WORLDSERVER
			}
			else
			{
				// ºñÇà°æÇèÄ¡ È¹µæ ·Î±× ³ÖÀ»°Í!
			}
#ifdef __WORLDSERVER
			( (CUser*)this )->AddSetFxp( m_nFxp, GetFlightLv() );
#endif	// __WORLDSERVER
		}
		
		TRACE("Name : %s ¾ò¾îÁö´Â : %I64d ", this->GetName(), static_cast<EXPINTEGER>( fExpValue ) );
		TRACE(" ·¹º§¾÷¿¡ ÇÊ¿äÇÑ:%I64d\n", prj.m_aExpCharacter[m_nLevel+1].nExp1 - m_nExp1 );

		if( AddExperience( static_cast<EXPINTEGER>( fExpValue ), TRUE, TRUE, TRUE ) )	// lv up
#		ifdef __WORLDSERVER
			((CUser*)this)->LevelUpSetting();
#		endif	// __WORLDSERVER
		else
#		ifdef __WORLDSERVER
			((CUser*)this)->ExpUpSetting();
#		endif	// __WORLDSERVER
#		ifdef __WORLDSERVER
		( (CUser*)this )->AddSetExperience( GetExp1(), (WORD)m_nLevel, m_nSkillPoint, m_nSkillLevel );
#		endif	// __WORLDSERVER	
}

void CMover::AddExperienceParty( CMover *pDead, EXPFLOAT fExpValue, MoverProp* pMoverProp, float fFxpValue, CParty* pParty, CUser* apMember[], int* nTotalLevel, int* nMaxLevel10, int* nMaxLevel, int* nMemberSize )
{
	// Á×ÀÌ³Ñ ÁÖº¯ÀÇ ÆÄÆ¼¿øµéÁß ÃÖ°í ·¹º§ ÆÄÆ¼¿øÀ¸·Î °æÇèÄ¡¸¦ °¨¼Ò ½ÃÅ´
	float fFactor = GetExperienceReduceFactor( (int)pMoverProp->dwLevel, *nMaxLevel );
	fExpValue *= static_cast<EXPFLOAT>( fFactor );
	fFxpValue *= fFactor;

	// ¸ó½ºÅÍ ·¹º§°ú ±Ø´ÜÃÑ·¹º§ÀÌ 5ÀÌ»ó ¸ó½ºÅÍ·¹º§ÀÌ ÀûÀ¸¸é °æÇèÄ¡¿Í Æ÷ÀÎÆ®°¡ ¾È¿Ã¶ó°¨
	pParty->GetPoint( (*nTotalLevel), (*nMemberSize), pDead->GetLevel() );

	if( pParty->m_nKindTroup ) // ¼øÈ¸±Ø´Ü
	{
		switch( pParty->m_nTroupsShareExp ) // °æÇèÄ¡ ºÐ¹è ¹æ½Ä
		{
		case 1 :	// ±â¿©ºÐ¹è
			{
				AddExperiencePartyContribution( pDead, apMember, pParty, fExpValue, fFxpValue, (*nMemberSize), (*nMaxLevel10) );
			}
			break;
		case 2 :	// µ¿ÀÏºÐ¹è
			{
				// ¾ÆÁ÷ ±âÈ¹ÀÌ ¹ÌÁ¤ Àû¿ë¾ÈµÊ
			}
			break;
		default:	// ±âº» ºÐ¹è(·¹º§ºÐ¹è)
			{
				AddExperiencePartyLevel( apMember, pParty, fExpValue, fFxpValue, (*nMemberSize), (*nMaxLevel10) );
			}
			break;
		}
	}
	else // ´Ü¸·±Ø´Ü
	{
		// ´Ü¸·±Ø´ÜÀº ¼øÈ¸±Ø´ÜÀÇ ·¹º§ ºÐ¹è¿Í °°´Ù
		AddExperiencePartyLevel( apMember, pParty, fExpValue, fFxpValue, (*nMemberSize), (*nMaxLevel10) );
	}
}

// ±Ø´Ü½Ã ±â¿©ºÐ¹è
void CMover::AddExperiencePartyContribution( CMover *pDead, CUser* apMember[], CParty* pParty, EXPFLOAT fExpValue, float fFxpValue, int nMemberSize, int nMaxLevel10 )
{
	// È¹µæÇÑ °æÇèÄ¡ = ÀÚ½ÅÀÇ Å¸°Ý¿¡ ÀÇÇÑ °æÇèÄ¡ + º¸³Ê½º °æÇèÄ¡ + ¿É¼Ç (¸ó½ºÅÍ°æÇèÄ¡ * ÆÄÆ¼¿øÁß ¶§¸°³ðµé / 100 )
	// º¸³Ê½º °æÇèÄ¡ = ( ¸ó½ºÅÍ °æÇèÄ¡ * 0.15) *( ±Ø´Ü ÀÎ¿ø -1 ) * ((ÀÚ½ÅÀÇ·¹º§ÀÇ Á¦°ö)/( ÆÄÆ¼¿ø °¢°¢ÀÇ ·¹º§ÀÇ Á¦°öÀÇ ÇÕ))
	EXPINTEGER	nMemberExp;
	int nAttackMember = 0;
	float fMaxMemberLevel = 0.0f;
	for( int i = 0 ; i < nMemberSize ; i++ )
	{
		float fContribution = 0;
#ifdef __NO_HP_DMG_LIMIT
		long long nHit = pDead->GetEnemyHit(apMember[i]->GetId());
#else
		int nHit = pDead->GetEnemyHit(apMember[i]->GetId());
#endif
		if( nHit )
		{
			++nAttackMember;
		}
		fMaxMemberLevel += ((float)apMember[i]->GetLevel() * (float)apMember[i]->GetLevel());
	}
	float fAddExp = 0.0f;		// º¸³Ê½º °æÇèÄ¡
	fAddExp = (float)( ( fExpValue * 0.2f ) * ( pParty->m_nSizeofMember - 1 ) );
	float fFullParty = 0.0f;	// Ç®ÆÄÆ¼ º¸³Ê½º °æÇèÄ¡
	if( nMemberSize == MAX_PTMEMBER_SIZE_SPECIAL )
	{
		fFullParty = (float)( ( fExpValue * 0.1f ) );
	}
	float fOptionExp = 0.0f;	// ¿É¼Ç °æÇèÄ¡
	if( 1 < nAttackMember )
	{
		fOptionExp = (float)( (fExpValue * (float)nAttackMember / 100.0f ) );
	}

	TRACE("GetExp(Contribution) : %s -> %f\n ", pParty->m_sParty, fExpValue );
	
	for( int i = 0 ; i < nMemberSize ; i++ )
	{
#ifdef __NO_HP_DMG_LIMIT
		double fContribution = 0;
		unsigned long long nHit = pDead->GetEnemyHit(apMember[i]->GetId());
#else
		float fContribution = 0;
		int nHit = pDead->GetEnemyHit(apMember[i]->GetId());
#endif
		if( nHit )
		{
#ifdef __NO_HP_DMG_LIMIT
			fContribution = (double)nHit * 100 / (double)pDead->GetMaxHitPoint();
#else
			fContribution = (float)nHit * 100 / (float)pDead->GetMaxHitPoint();
#endif
			if( 100 < fContribution )
			{
				fContribution = 100.0f;
			}
			if( nMaxLevel10 < apMember[i]->GetLevel() )
			{
				nMemberExp	= static_cast<EXPINTEGER>( ( fExpValue * ( fContribution / 100.0f ) ) + ( fAddExp * ( ((float)apMember[i]->GetLevel() * (float)apMember[i]->GetLevel()) / fMaxMemberLevel ) ) + fOptionExp + fFullParty );

#if __VER < 8     // 8Â÷ ½ºÅ³°æÇèÄ¡´Ù¿îº¯°æ
				// Á×ÀºÈÄ °æÇèÄ¡ ´õÁÖ±â
				if( apMember[i]->IsAfterDeath() )
					nMemberExp	*= static_cast<EXPFLOAT>( 1.5f );
#endif	// __VER < 8  

#if __VER < 9 // __S_9_ADD
				// HP°¡ ÀûÀ»¶§ °æÇèÄ¡ ´õÁÖ±â
				int nHitPercent = apMember[i]->GetHitPointPercent( 100 );
				if( nHitPercent < CRITICAL_BERSERK_HP )
				{
					if( nHitPercent <= 10 )
						nMemberExp	*= 1.2f;
					else
						nMemberExp	+= ( nMemberExp * .2f ) - ( ( nMemberExp * .2f ) * nHitPercent / CRITICAL_BERSERK_HP );
				}
#endif // __S_9_ADD
				TRACE("GetExp(Contribution) : %s -> %I64d\n ", apMember[i]->GetName(), static_cast<EXPINTEGER>( nMemberExp ) );
				AddPartyMemberExperience( apMember[i], nMemberExp, 0 );
			}
		}
		else	// ÇÑ´ëµµ ¾È¶§·ÈÀ¸¸é º¸³Ê½º °æÄ¡¿Í ¿É¼Ç °æÄ¡¿Í Ç®ÆÄÆ¼º¸³Ê½º°æÄ¡ ¸¸ ÁØ´Ù
		{
			if( nMaxLevel10 < apMember[i]->GetLevel() )
			{
				nMemberExp	= static_cast<EXPINTEGER>( ( fAddExp * ( ((float)apMember[i]->GetLevel() * (float)apMember[i]->GetLevel()) / fMaxMemberLevel ) ) + fOptionExp + fFullParty );

#if __VER < 8     // 8Â÷ ½ºÅ³°æÇèÄ¡´Ù¿îº¯°æ
				// Á×ÀºÈÄ °æÇèÄ¡ ´õÁÖ±â
				if( apMember[i]->IsAfterDeath() )
					nMemberExp	*= static_cast<EXPFLOAT>( 1.5f );
#endif	// __VER < 8  

#if __VER < 9 // __S_9_ADD
				// HP°¡ ÀûÀ»¶§ °æÇèÄ¡ ´õÁÖ±â
				int nHitPercent = apMember[i]->GetHitPointPercent( 100 );
				if( nHitPercent < CRITICAL_BERSERK_HP )
				{
					if( nHitPercent <= 10 )
						nMemberExp	*= 1.2f;
					else
						nMemberExp	+= ( nMemberExp * .2f ) - ( ( nMemberExp * .2f ) * nHitPercent / CRITICAL_BERSERK_HP );
				}
#endif // __S_9_ADD
				TRACE("GetExp(Contribution) : %s -> %I64d\n ", apMember[i]->GetName(), static_cast<EXPINTEGER>( nMemberExp ) );
				AddPartyMemberExperience( apMember[i], nMemberExp, 0 );
			}
		}
	}
}

void CMover::AddExperiencePartyLevel( CUser* apMember[], CParty* pParty, EXPFLOAT fExpValue, float fFxpValue, int nMemberSize, int nMaxLevel10 )
{
	EXPINTEGER nMemberExp;
//	int	  nMemberFxp;
	float fMaxMemberLevel = 0.0f;
	for( int i = 0 ; i < nMemberSize ; i++ )
	{
		fMaxMemberLevel += ((float)apMember[i]->GetLevel() * (float)apMember[i]->GetLevel());
	}
	float fAddExp = 0.0f;
	fAddExp = (float)( ( fExpValue * 0.2f ) * ( nMemberSize - 1 ) );
	TRACE("GetExp(Level) : %s -> %f\n ", pParty->m_sParty, fExpValue );

	for( int i = 0 ; i < nMemberSize ; i++ )
	{
		if( nMaxLevel10 < apMember[i]->GetLevel() )
		{
			//[ ¸ó½ºÅÍÀÇ °æÇèÄ¡ + {(¸ó½ºÅÍ °æÇèÄ¡ * 0.15) * (±Ø´Ü ÀÎ¿ø - 1)} * (ÀÚ½ÅÀÇ ·¹º§ÀÇ Á¦°ö/¸ðµç ÆÄÆ¼¿ø ·¹º§ Á¦°öÀÇ ÇÕ) ]
			nMemberExp = static_cast<EXPINTEGER>( ( ( fExpValue + fAddExp ) * ( ((float)apMember[i]->GetLevel() * (float)apMember[i]->GetLevel()) / fMaxMemberLevel ) ) ); //+ fFullAddExp );


#if __VER < 8     // 8Â÷ ½ºÅ³°æÇèÄ¡´Ù¿îº¯°æ
			// Á×ÀºÈÄ °æÇèÄ¡ ´õÁÖ±â
			if( apMember[i]->IsAfterDeath() )
				nMemberExp	*= static_cast<EXPFLOAT>( 1.5f );
#endif	// __VER < 8  

#if __VER < 9 // __S_9_ADD
			// HP°¡ ÀûÀ»¶§ °æÇèÄ¡ ´õÁÖ±â
			int nHitPercent = apMember[i]->GetHitPointPercent( 100 );
			if( nHitPercent < CRITICAL_BERSERK_HP )
			{
				if( nHitPercent <= 10 )
					nMemberExp	*= 1.2f;
				else
					nMemberExp	+= ( nMemberExp * .2f ) - ( ( nMemberExp * .2f ) * nHitPercent / CRITICAL_BERSERK_HP );
			}
#endif // __S_9_ADD

			AddPartyMemberExperience( apMember[i], nMemberExp, 0 );
			TRACE("GetExp(Level) : %s -> %I64d\n ", apMember[i]->GetName(), static_cast<EXPINTEGER>( nMemberExp ) );
		}
	}
}

// °æÇèÄ¡ °¨¼Ò°ªÀ» ¸®ÅÏ: ´ë»ó°ú ÁÖº¯ÀÇ ÆÄÆ¼¿øµéÁß ÃÖ°í ·¹º§ ÆÄÆ¼¿øÀÇ Â÷ÀÌ¸¦ ¹ÙÅÁÀ¸·Î ...
float CMover::GetExperienceReduceFactor( int nLevel, int nMaxLevel ) 
{
	float fFactor = 1.0f;
	int nDelta = nMaxLevel - nLevel;
	if( nDelta > 0 )
	{
		nDelta = min( nDelta, 9 );	// ÃÖ´ë 9

		if( ::GetLanguage() == LANG_KOR )
		{
			float fFactors[10] = { 0.7f, 0.7f, 0.7f, 0.4f, 0.4f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f };
			return fFactors[ nDelta ];
		}
		else
		{
			float fFactors[10] = { 0.8f, 0.8f, 0.6f, 0.35f, 0.2f, 0.12f, 0.08f, 0.04f, 0.02f, 0.01f };
			return fFactors[ nDelta ];
		}
	}

	return fFactor;
}
#endif	// __WORLDSERVER not client




// ¼­¹ö¿¡¼­µµ »ç¿ëµÇ´Â ½Å¹öÀü.
BOOL CMover::IsAttackAble( CObj *pObj )
{
#if __VER >= 8 //__Y_FLAG_SKILL_BUFF
	if( HasBuffByIk3(IK3_TEXT_DISGUISE) )
		return FALSE;
#endif //__Y_FLAG_SKILL_BUFF

	BOOL bAble	= FALSE;	

	CWorld* pWorld = GetWorld();
	if( pObj )
	{
		if( IsStateMode( STATE_BASEMOTION_MODE ) )	
		{
		#ifdef __CLIENT
			g_DPlay.SendStateModeCancel( STATE_BASEMOTION_MODE, STATEMODE_BASEMOTION_CANCEL );
		#else
			SetStateNotMode( STATE_BASEMOTION_MODE, STATEMODE_BASEMOTION_CANCEL );
			m_nReadyTime = 0;
			m_dwUseItemId = 0;
		#endif 
			return FALSE;		
		}
		
		if( pObj->GetType() == OT_MOVER )
		{
		#ifdef __CLIENT
			CMover *pMover = (CMover *)pObj;

				if( pMover->IsPlayer() )
				{
					if( g_eLocal.GetState( EVE_18 ) )
					{
						if( IsPVPTarget( pMover ) )			// pvp
						{
							if( m_nDuelState == 1 && !IsFly() && !pMover->IsFly() )
								bAble	= TRUE;
						}
						else if( IsWarTarget( pMover ) )	// war
							bAble	= TRUE;
						else if( IsSchoolTarget( pMover ) )	// event
							bAble	= TRUE;
#ifdef __JEFF_11_4
						else if( IsArenaTarget( pMover ) )
							bAble	= TRUE;
#endif	// __JEFF_11_4
						else								// pk
						{
							bAble	= IsPKAttackAble( pMover );
							if( bAble )
								( (CWndWorld *)g_WndMng.m_pWndWorld )->SetLastTarget( pMover->GetId() );
						}
					}

/*#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
					if( IsPVPTarget( pMover ) )			// pvp
					{
						if( m_nDuelState == 1 && !IsFly() && !pMover->IsFly() )
							bAble	= TRUE;
					}
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma*/

					if( g_eLocal.GetState( EVE_GUILDCOMBAT ) )
					{
						if( pWorld->GetID() == WI_WORLD_GUILDWAR )
						{
							if( IsGuildCombatTarget( pMover ) ) // GuildCombat
								bAble = TRUE;
						}
					}
#ifdef __DEATH_MATCH
					if (pWorld->GetID() == WI_WORLD_DEATH_MATCH && GetSiegeFightState() != FALSE)
					{
						if (IsSiegeTarget(pMover))
							bAble = TRUE;
					}
#endif // __DEATH_MATCH
#if __VER >= 11 // __GUILD_COMBAT_1TO1
 					if( g_eLocal.GetState( EVE_GUILDCOMBAT1TO1 ) )
 					{
 						if( g_GuildCombat1to1Mng.IsPossibleMover( pMover ) && IsGuildCombatTarget( pMover ) )
 							bAble = TRUE;
 					}
#endif // __GUILD_COMBAT_1TO1
				}
				else
				{
					bAble	= IsAttackAbleNPC( pMover );
				}
		#else // __CLIENT			
				if( GetHitType( (CMover *)pObj, TRUE, 0 ) == HITTYPE_FAIL )
					bAble = FALSE;
				else
					bAble = TRUE;
		#endif // __CLIENT
		}
		else
		{
			// no mover
			bAble	= TRUE;
		}
		
	#ifdef __CLIENT
		if( !bAble )
			( (CWndWorld *)g_WndMng.m_pWndWorld )->m_bAutoAttack	= FALSE;
	#endif
	}
	return bAble;
}

BOOL CMover::IsAttackAbleNPC( CMover* pNPC )
{
#if __VER >= 8 //__Y_FLAG_SKILL_BUFF
	if( HasBuffByIk3(IK3_TEXT_DISGUISE) )
		return FALSE;
#endif //__Y_FLAG_SKILL_BUFF
	
	BOOL bAble = TRUE;
	if( pNPC->IsDie() )	// ÀÌ¹Ì Á×Àº³ÑÀº Æ÷Ä¿½º ÇØÁ¦½ÃÅ°°í ´õÀÌ»ó ½ÇÇàÇÏÁö ¾ÊÀ½.
	{
	#ifdef __CLIENT
		g_WorldMng()->SetObjFocus( NULL );
	#else
		if( IsPlayer() )
			((CUser *)this)->AddSetTarget( NULL_ID );
	#endif
		bAble = FALSE;
	} 
	else
	{
		MoverProp *pMoverProp = pNPC->GetProp();	

		if( pMoverProp->bKillable == 0 )	
			return FALSE;		// °ø°ÝÀÌºÒ°¡´ÉÇÑ NPC´Â ¹«Á¶°Ç °ø°Ý¸øÇÔ.
		
		// ÆòÈ­ÀûÀÌ¸é ¸ø¶§¸².
		if( pNPC->IsPeaceful() == TRUE )	// ÆòÈ­ÀûÀÎ³ÑÀº °ø°Ý ¾ÈµÊ
		{
			bAble = FALSE;
		}
		else
		{
			if( pMoverProp->dwClass == RANK_GUARD )					// °¡µåÀÏ¶§¸¸ ¼ºÇâÀ» ºñ±³ÇÑ´Ù.  
			{
				if( pMoverProp->nChaotic < 0 && IsChaotic() == TRUE )			// ¼ºÇâÀÌ ¼­·Î °°À¸¸é °ø°Ý¸øÇÔ.
					bAble = FALSE;
				else if( pMoverProp->nChaotic > 0 && IsChaotic() == FALSE )		// ¼ºÇâÀÌ ¼­·Î °°À¸¸é °ø°Ý¸øÇÔ.
					bAble = FALSE;
			}

			if( m_pActMover->IsFly() && pMoverProp->dwFlying == 0 )	// °ø°ÝÀÚ°¡ ºñÇàÁßÀÌ°í Å¸°ÙÀÌ ºñÇà¸÷ÀÌ ¾Æ´Ï¸é
				bAble = FALSE;
			else if( m_pActMover->IsFly() == FALSE && pMoverProp->dwFlying == 1 )	// °ø°ÝÀÚ Áö»ó / Å¸°Ù ºñÇà¸÷
				bAble = FALSE;
#ifdef __MOUNT
			if (GetMountId() > 0)
				bAble = FALSE;
#endif // __MOUNT
		}
	}

#ifdef __CLIENT
	if( bAble == TRUE )
		if( GetAsyncKeyState(VK_CONTROL) & 0x8000 )	// NPC¿¡°Ô °ø°ÝÅ°¸¦ ´©¸£°í ÀÖÀ»¶§ Å¬¸¯ÇÏ¸é ÀÚµ¿°ø°Ý.
			((CWndWorld *)g_WndMng.m_pWndWorld)->m_bAutoAttack = TRUE;
#endif // Client
				
	return bAble;
}

#ifdef __CLIENT
BOOL CMover::IsPKAttackAble( CMover* pMover )
{
#ifdef __JEFF_11_4
	if( IsArenaTarget( pMover ) )
		return TRUE;
#endif	// __JEFF_11_4
#ifdef __DEATH_MATCH
	if (GetWorld()->m_dwWorldID == WI_WORLD_DEATH_MATCH)
		return FALSE;
#endif // __DEATH_MATCH
	if( !g_eLocal.GetState( EVE_PK ) )
		return FALSE;
	return IsPKInspection( pMover );
}

BOOL CMover::IsPKInspection( CMover* pOther )
{
#if __VER < 8 // __S8_PK
	if( g_Party.IsMember( pOther->m_idPlayer ) )
		return FALSE;

	if( m_idGuild > 0 && m_idGuild == pOther->m_idGuild )
		return FALSE;
#endif // __VER >= 8 // __S8_PK

	DWORD dwRegionAttr	= GetPKPVPRegionAttr();
	BOOL bAble = TRUE;

	int nAttackerPK, nDefenderPK;
	nAttackerPK = nDefenderPK = 0;
	if( nAttackerPK = IsPKPVPInspectionBase( dwRegionAttr, FALSE ) )
		bAble	= FALSE;
	if( nDefenderPK = pOther->IsPKPVPInspectionBase( dwRegionAttr, FALSE ) )
		bAble	= FALSE;

#if __VER >= 8 // __S8_PK
	if( bAble == FALSE && ( pOther->IsChaotic() || (GetAsyncKeyState(VK_CONTROL) & 0x8000)) )
	{
#ifdef __DEATH_MATCH
		if (GetWorld() && GetWorld()->GetID() == WI_WORLD_DEATH_MATCH && IsSiegeTarget(pOther)) 	// ±æµå´ëÀü ÁßÀÎ À¯Àú¿¡°Ô´Â ¸Þ¼¼Áö°¡ ¾È³ª¿À°Ô ÇÏÀÚ
			nAttackerPK = nDefenderPK = 9;
#endif // __DEATH_MATCH
		if(GetWorld() && GetWorld()->GetID() == WI_WORLD_GUILDWAR && IsGuildCombatTarget( pOther ) )	// ±æµå´ëÀü ÁßÀÎ À¯Àú¿¡°Ô´Â ¸Þ¼¼Áö°¡ ¾È³ª¿À°Ô ÇÏÀÚ
			nAttackerPK = nDefenderPK = 9;
#if __VER >= 11 // __GUILD_COMBAT_1TO1
 		else if( g_GuildCombat1to1Mng.IsPossibleMover( this ) )
 			nAttackerPK = nDefenderPK = 9;
#endif // __GUILD_COMBAT_1TO1
		else if(!IsFly() && !pOther->IsFly())
		{
			CWndWorld* pWndWorld	= (CWndWorld*)g_WndMng.GetWndBase( APP_WORLD );
			if( pWndWorld && pWndWorld->m_bLButtonDown && !pWndWorld->m_bLButtonDowned )
			{
				if( nAttackerPK == 1 || nDefenderPK == 1 )
					g_WndMng.PutString( prj.GetText(TID_GMAE_PK_NOT_AREA), NULL, prj.GetTextColor(TID_GMAE_PK_NOT_AREA) );		
				else if( nAttackerPK == 5 )
					g_WndMng.PutString( prj.GetText(TID_GAME_PK_LIMIT_LEVEL0), NULL, prj.GetTextColor(TID_GAME_PK_LIMIT_LEVEL0) );
				else if( nDefenderPK == 5 )
					g_WndMng.PutString( prj.GetText(TID_GAME_PK_LIMIT_LEVEL1), NULL, prj.GetTextColor(TID_GAME_PK_LIMIT_LEVEL1) );
			}
		}		
	}
#endif // __VER >= 8 // __S8_PK
	if( bAble )
	{
		if( pOther->m_vtInfo.IsVendorOpen() )
		{
			if( IsForceAttack() )
			{
				;
			}
			else if( !( g_Neuz.m_NeuzEnemy.IsPKing( pOther->GetId() ) ) )
				bAble	= FALSE;
		}
		else
		{
			if( dwRegionAttr == RA_PENALTY_PK )
			{
				if( IsForceAttack() )
				{
					;
				}
#if __VER >= 8 // __S8_PK
				else if( !pOther->IsChaotic() )
				{
					bAble	= FALSE;
				}
#else // __VER >= 8 // __S8_PK
				else if( !( IsMode( FREEPK_MODE ) || ( g_Neuz.m_NeuzEnemy.IsPKing( pOther->GetId() ) ) || pOther->IsChaotic() )	)
				{
					bAble	= FALSE;
				}
#endif // __VER >= 8 // __S8_PK
			}
		}
	}

	return bAble;
}
#endif // CLIENT

#ifdef __WORLDSERVER
BOOL CMover::IsPVPInspection( CMover* pMover, int nFlag )
{
	int nError	= 0;

	DWORD dwAttr	= GetPKPVPRegionAttr();
#if __VER >= 8     // 8Â÷ µà¾óÁ¸¿¡ °ü°è¾øÀÌ PVP°¡´ÉÇÏ°ÔÇÔ   Neuz, World
	DWORD dwWorldIDtmp = 0;
	DWORD dwDestWorldIDtmp = 1;

	if( GetWorld() && pMover->GetWorld() )
	{
		dwWorldIDtmp = GetWorld()->GetID();
		dwDestWorldIDtmp = pMover->GetWorld()->GetID();
	}
#endif	// __VER >= 8  
	
	switch( nFlag )
	{
		case 1:		// °³ÀÎ PVP
			{
//				1
				if( abs( GetLevel() - pMover->GetLevel() ) >= 30 )	// ·¹º§ 30ÀÌ»ó ³ª´Â°Í
				{
					((CUser*)this)->AddDefinedText( TID_PK_LEVEL_GAP, "" );	// ·¹º§ÀÌ 30ÀÌ»ó Â÷ÀÌ°¡ ³ª¸é PVP¸¦ ÇÒ¼ö ¾ø½À´Ï´Ù
					return FALSE;
				}
//				1	// 2	// 3	// 4	// 5

#if __VER >= 8     // 8Â÷ µà¾óÁ¸¿¡ °ü°è¾øÀÌ PVP°¡´ÉÇÏ°ÔÇÔ   Neuz, World
				if( ( nError = IsPVPInspectionBase( dwAttr,dwDestWorldIDtmp ) ) == 0 )
				{
					nError = pMover->IsPVPInspectionBase( dwAttr ,dwWorldIDtmp);
				}
#else	// __VER >= 8  
				if( ( nError = IsPKPVPInspectionBase( dwAttr ) ) == 0 )
				{
					nError = pMover->IsPKPVPInspectionBase( dwAttr );
				}
#endif	// __VER >= 8  
				if( nError != 0 )
				{
					switch( nError )
					{
					case 1:
						((CUser*)this)->AddDefinedText( TID_PK_SAFETY_NO, "" );	// ¾ÈÀü¿µ¿ª¿¡¼­´Â PVPÇÒ¼ö ¾ø½À´Ï´Ù
						break;
					case 2:
						((CUser*)this)->AddDefinedText( TID_PK_SAME_NO, "" );	// °°Àº¿µ¿ª¿¡ ÀÖ¾î¾ß PVP¸¦ ÇÒ¼ö ÀÖ½À´Ï´Ù
						break;
					case 3:
						((CUser*)this)->AddDefinedText( TID_PK_CHANGEJOB_NO, "" );	// 1Â÷ÀüÁ÷ ÀÌÈÄ¿¡ PVP¸¦ ÇÒ¼ö ÀÖ½À´Ï´Ù
						break;
					}
					return FALSE;
				}
				return TRUE;
			}
		case 2:		// ±Ø´Ü PVP
			{
				CParty* pSrc	= g_PartyMng.GetParty( m_idparty );
				CParty* pDest	= g_PartyMng.GetParty( pMover->m_idparty );
				if( pSrc && pDest )
				{
					DWORD dwTick	= GetTickCount();
					u_long anPlayer[MAX_PTMEMBER_SIZE*2];
					int	nSize	= 0;
					for( int i = 0; i < pSrc->GetSizeofMember(); i++ )
						anPlayer[nSize++]	= pSrc->GetPlayerId( i );
					for( int i = 0; i < pDest->GetSizeofMember(); i++ )
						anPlayer[nSize++]	= pDest->GetPlayerId( i );

					CUser* pLeaderSrc	= (CUser*)pSrc->GetLeader();
					CUser* pLeaderDest	= (CUser*)pDest->GetLeader();
					if( IsValidObj( (CObj*)pLeaderSrc ) && IsValidObj( (CObj*)pLeaderDest ) )
					{
						if( abs( pLeaderSrc->GetLevel() - pLeaderDest->GetLevel() ) >= 30 )
						{
							((CUser*)this)->AddDefinedText( TID_PK_LEVEL_GAP, "" );	// ·¹º§ÀÌ 30ÀÌ»ó Â÷ÀÌ°¡ ³ª¸é PVP¸¦ ÇÒ¼ö ¾ø½À´Ï´Ù
							return FALSE;
						}
					}
					else
					{
						//
						return FALSE;
					}

					for( int i = 0; i < nSize; i++ )
					{
						CUser* pPlayer	= g_UserMng.GetUserByPlayerID( anPlayer[i] );
						if( IsValidObj( (CObj*)pPlayer ) )
						{
#if __VER >= 8     // 8Â÷ µà¾óÁ¸¿¡ °ü°è¾øÀÌ PVP°¡´ÉÇÏ°ÔÇÔ   Neuz, World
							if( ( nError = pPlayer->IsPVPInspectionBase( dwAttr,dwWorldIDtmp ) ) )
#else	// __VER >= 8  
							if( ( nError = pPlayer->IsPKPVPInspectionBase( dwAttr ) ) )
#endif	// __VER >= 8  
							{
								if( nError != 0 )
								{
									switch( nError )
									{
									case 1:
										((CUser*)this)->AddDefinedText( TID_PK_SAFETY_NO, "" );	// ¾ÈÀü¿µ¿ª¿¡¼­´Â PVPÇÒ¼ö ¾ø½À´Ï´Ù
										break;
									case 2:
										((CUser*)this)->AddDefinedText( TID_PK_SAME_NO, "" );	// °°Àº¿µ¿ª¿¡ ÀÖ¾î¾ß PVP¸¦ ÇÒ¼ö ÀÖ½À´Ï´Ù
										break;
									case 3:
										((CUser*)this)->AddDefinedText( TID_PK_CHANGEJOB_NO, "" );	// 1Â÷ÀüÁ÷ ÀÌÈÄ¿¡ PVP¸¦ ÇÒ¼ö ÀÖ½À´Ï´Ù
										break;
									}
									return FALSE;
								}
							}
						}
					}
					return TRUE;
				}
				return FALSE;
			}
	}
	return TRUE;
}


#endif	// __WORLDSERVER

int CMover::IsPKPVPInspectionBase( DWORD dwRegionAttr, BOOL bPVP )
{
	DWORD dwAttr = GetPKPVPRegionAttr();

	if( dwRegionAttr == RA_SAFETY )		// ¾ÈÀüÁö¿ª °Ë»ç
		return 1;
	if( dwRegionAttr != dwAttr )		// °°ÀºÁö¿ª¿¡ ÀÖ´ÂÁö °Ë»ç
		return 2;
	
#ifdef __CLIENT
	if( GetAsyncKeyState( VK_MENU ) & 0x8000 )
		return 9;
#endif	// __CLIENT


	if( bPVP && (dwAttr == RA_FIGHT || dwAttr != RA_PK) )	// PVP³ª Penalty Áö¿ªÀÌ¸é °Ë»ç
	{
		if( IsBaseJob() )
			return 3;
	}

#if __VER >= 8 // __S8_PK
	if( !bPVP && GetLevel() <= prj.m_PKSetting.nLimitLevel )	// PK
		return 5;
#endif // __VER >= 8 // __S8_PK

	if( bPVP )
	{
		if( m_nDuelState != 0 )
			return 9;
	}

	if( IsFly() )
		return 1;
	if( m_idWar > 0 )
		return 1;

	return 0;
}

//8Â÷ µà¾óÁ¸¿¡ °ü°è¾øÀÌ PVP°¡´ÉÇÏ°ÔÇÔ   Neuz, World
#if __VER >= 8     // 8Â÷ µà¾óÁ¸¿¡ °ü°è¾øÀÌ PVP°¡´ÉÇÏ°ÔÇÔ   Neuz, World
int CMover::IsPVPInspectionBase( DWORD dwRegionAttr,DWORD dwWorldID, BOOL bPVP )
{

#ifdef __CLIENT
	if( GetAsyncKeyState( VK_MENU ) & 0x8000 )
		return 9;
#endif	// __CLIENT


	if( IsBaseJob() )
		return 3;

	if( bPVP )
	{
		if( m_nDuelState != 0 )
			return 9;
	}

	if(GetWorld() && GetWorld()->GetID() == WI_WORLD_GUILDWAR)
		return	10;

	if(GetWorld() && GetWorld()->GetID() != dwWorldID)
		return	2;

	if( IsFly() )
		return 1;
	if( m_idWar > 0 )
		return 1;

#ifdef __QUIZ
	if( GetWorld() && GetWorld()->GetID() == WI_WORLD_QUIZ )
		return	1;
#endif // __QUIZ

	return 0;
}
#endif	// __VER >= 8  


BOOL CMover::SubPKPVPInspectionBase( CMover* pMover, CMover* pMover1, DWORD dwPKAttr, int nFlag )
{
	if( IsBaseJob() ) // ÀüÁ÷À» ¾ÈÇÞÀ½
	{
#ifdef __CLIENT
		g_WndMng.PutString( prj.GetText( TID_PK_CHANGEJOB_NO ), NULL, prj.GetTextColor( TID_PK_CHANGEJOB_NO ) );
#endif // __CLIENT
#ifdef __WORLDSERVER
		((CUser*)this)->AddDefinedText( TID_PK_CHANGEJOB_NO, "" );	// 1Â÷ÀüÁ÷ ÀÌÈÄ¿¡ PVP¸¦ ÇÒ¼ö ÀÖ½À´Ï´Ù
		if( IsValidObj( pMover ) )
			((CUser*)pMover)->AddDefinedText( TID_PK_CHANGEJOB_NO, "" );	// 1Â÷ÀüÁ÷ ÀÌÈÄ¿¡ PVP¸¦ ÇÒ¼ö ÀÖ½À´Ï´Ù
#endif // __WORLDSERVER
//		pMover->PrintString( pMover1, TID_GAME_PVP_LOWLEVEL2 );
		return FALSE;
	}
	if( IsFly() )	// ³¯°í ÀÖÀ½
	{
#ifdef __CLIENT
		g_WndMng.PutString( prj.GetText( TID_PK_NOFLIGHT_DURING ), NULL, prj.GetTextColor( TID_PK_NOFLIGHT_DURING ) ); // ºñÇàÁßÀÌ¸é µà¾óÀ» ÇÒ¼ö ¾ø½À´Ï´Ù
#endif // __CLIENT
#ifdef __WORLDSERVER
		((CUser*)this)->AddDefinedText( TID_PK_NOFLIGHT_DURING, "" );	// ºñÇàÁßÀÌ¸é µà¾óÀ» ÇÒ¼ö ¾ø½À´Ï´Ù
		if( IsValidObj( pMover ) )
			((CUser*)pMover)->AddDefinedText( TID_PK_NOFLIGHT_DURING, "" );	// ºñÇàÁßÀÌ¸é µà¾óÀ» ÇÒ¼ö ¾ø½À´Ï´Ù
#endif // __WORLDSERVER		
//		pMover->PrintString( pMover1, TID_GAME_PVP_LOWLEVEL2 );
		return FALSE;
	}

#ifdef __WORLDSERVER
	if( m_idWar )	// ÀüÀïÁß¿£ µà¾ó, PK ¸øÇÔ.
	{
		if( g_eLocal.GetState( EVE_GUILDWAR ) )
		{
			pMover->PrintString( pMover1, TID_GAME_GUILDWARERRORDUEL );	// ÀüÀïÁß¿£ µà¾ó ¸øÇÔ´Ù.
			return FALSE;
		}
	} 
	else
	{
		if( m_nDuelState != 0 )
		{
			return FALSE;
		}
	}
#endif __WORLDSERVER

	if( IsRegionAttr( dwPKAttr ) == FALSE )	// °°Àº Áö¿ª¿¡ ÀÖ´ÂÁö È®ÀÎ
	{
#ifdef __CLIENT
		g_WndMng.PutString( prj.GetText( TID_PK_SAME_NO ), NULL, prj.GetTextColor( TID_PK_SAME_NO ) );
#endif // __CLIENT
#ifdef __WORLDSERVER
		((CUser*)this)->AddDefinedText( TID_PK_SAME_NO, "" );	// °°Àº¿µ¿ª¿¡ ÀÖ¾î¾ß PVP¸¦ ÇÒ¼ö ÀÖ½À´Ï´Ù
		if( IsValidObj( pMover ) )
			((CUser*)pMover)->AddDefinedText( TID_PK_SAME_NO, "" );	// °°Àº¿µ¿ª¿¡ ÀÖ¾î¾ß PVP¸¦ ÇÒ¼ö ÀÖ½À´Ï´Ù
#endif // __WORLDSERVER	
//		pMover->PrintString( pMover1, TID_GAME_PVP_SAFEZONENOATTACK );	//g_WndMng.PutString( prj.GetText( TID_GAME_PVP_SAFEZONENOATTACK ), NULL, prj.GetTextColor( TID_GAME_PVP_SAFEZONENOATTACK ) );
		return FALSE;
	}
	return TRUE;
}

void CMover::PrintString( CMover* pMover, DWORD dwId )
{
#ifdef __CLIENT
	g_WndMng.PutString( prj.GetText( dwId ), NULL, prj.GetTextColor( dwId ) );
#endif // __CLIENT
#ifdef __WORLDSERVER
	((CUser*)this)->AddDefinedText( dwId, "" );
	if( IsValidObj( pMover ) )
		((CUser*)pMover)->AddDefinedText( dwId, "" );
#endif // __WORLDSERVER
}
// this´Â °ø°ÝÀÚ
// this°¡ pTargetÀ» ½ºÆ¿ÇÏ·Á´ÂÁö °Ë»ç.
// pTargetÀº ¹Ýµå½Ã IsValid Ã¼Å©¸¦ ÇÏ°í ³Ñ¾î¿Í¾ß ÇÑ´Ù.
#ifdef __WORLDSERVER
int CMover::IsSteal( CMover *pTarget )
{
	if( IsNPC() || ::GetLanguage() == LANG_JAP )	
		return 0;		// °ø°ÝÀÚ°¡ NPC¸é ½ºÆ¿ Ã¼Å©´ë»ó ¾Æ´Ô.

	if( ::GetLanguage() == LANG_THA && pTarget->GetIndex() == MI_MRPUMPKIN5 )	// ÅÂ±¹ÀÇ °æ¿ì ±«¼ö ¹Ì½ºÅÍÆßÅ²Àº ½ºÆ¿ÀÌ Çã¿ëµÊ.
		return 0;												

	if( pTarget->GetIndex() == MI_DEMIAN5 || pTarget->GetIndex() == MI_KEAKOON5 || pTarget->GetIndex() == MI_MUFFRIN5 )
		return 0;		// ¾êµéÀº ÀÌº¥Æ®¸÷ÀÌ¹Ç·Î ¾Æ¹«³ª ½ºÆ¿ °¡´É
		
	// ÇÃ·¹ÀÌ¾î¸¸ ¿©±â·Î µé¾î¿Â´Ù.
#if __VER >= 8 // __S8_PK
	if( pTarget->IsNPC() )	// °ø°ÝÀÚ:ÇÃ·¹ÀÌ¾î, ¸Â´ÂÀÚ:NPC 
#else // __VER >= 8 // __S8_PK
	if( pTarget->IsNPC() || (pTarget->IsPlayer() && pTarget->IsChaotic() == FALSE) )	// °ø°ÝÀÚ:ÇÃ·¹ÀÌ¾î, ¸Â´ÂÀÚ:NPC È¤Àº ÂøÇÑ»ç¶÷. (½½·ÎÅÍ´Â ´Ù±¸¸®´çÇØµµ µÈ´Ù).
#endif // __VER >= 8 // __S8_PK
	{
		BOOL bStealCheck = TRUE;
		if( pTarget->m_idTargeter == NULL_ID )	
		{
			return 0;	//Å¸°ÙÀ»¸¦ ´©±º°¡°¡ ÂòÇÑ ÈçÀûÀÌ ¾øÀ¸¸é ½ºÆ¿¾Æ´Ô.
		}
		CMover *pOtherPlayer = prj.GetMover( pTarget->m_idTargeter );		// pTarget¸¦ ÂòÇÑ ´Ù¸¥ À¯Àú.
		if( IsValidObj(pOtherPlayer) )
		{
			// °ø°ÝÀÚ°¡ ÆÄÆ¼°¡ ÀÖ°í pTarget¸¦ ¶§·È´ø »ç¶÷ÀÌ °°Àº ÆÄÆ¼¸é ½ºÆ¿ÀÌ ¾Æ´Ï´Ù.
			if( m_idparty && (pOtherPlayer->m_idparty == m_idparty) )
				bStealCheck = FALSE;
			if( m_idWar && m_idGuild && (pOtherPlayer->m_idGuild == m_idGuild) ) // ÀüÀïÁß¿¡ ³ª¶û°°Àº ±æµå³¢¸® Ä¡´Â°Ç ½ºÆ¿ÀÌ ¾Æ´Ï´Ù.
				bStealCheck = FALSE;
			if( g_eLocal.GetState( EVE_SCHOOL ) )
				bStealCheck	= FALSE;
			if( pTarget->GetProp()->dwClass == RANK_SUPER )		// º¸½º¸÷Àº ½ºÆ¿¾øÀ½.
				bStealCheck = FALSE;
		} else
			bStealCheck = FALSE;	// pTarget¸¦ ¶§·È´ø À¯Àú°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é ½ºÆ¿ÀÌ ¾Æ´Ï´Ù.

		if( bStealCheck && 
			pTarget->m_idTargeter != NULL_ID && pTarget->m_idTargeter != GetId()) // pTarget¸¦ ÂòÇÑ³ðÀÌ ÀÖ°í ±×°Ô ÇöÀç°ø°ÝÀÚ°¡ ¾Æ´Ï¶ó¸é ½ºÆ¿.
		{
			((CUser*)this)->AddDefinedText( TID_GAME_PRIORITYMOB, "" );	// ¸ó½ºÅÍ°¡ ´Ù¸¥Ä³¸¯ÅÍ¶û ÀüÅõÁßÀÓ´Ù.
			return 1;		// ½ºÆ¿.
		}
	}

	return 0;	// ½ºÆ¿ÀÌ ¾Æ´Ô.
}


// 
// Á×¾úÀ»¶§ °æÇèÄ¡ ±ð´Â ºÎºÐ.
//
void  CMover::GetDieDecExp( int nLevel, FLOAT& fRate, FLOAT& fDecExp, BOOL& bPxpClear, BOOL& bLvDown )
{
#if __VER >= 8  
	bPxpClear = FALSE;

	// HPÈ¸º¹¼öÄ¡(%)
	DWORD	veci = 0;
	for( veci = 0 ; veci < prj.m_vecRevivalPenalty.size() ; ++veci )
	{
		if( veci == 0 && nLevel <= prj.m_vecRevivalPenalty[veci].nLevel )
			break;
		if( veci != 0 && prj.m_vecRevivalPenalty[veci-1].nLevel < nLevel && nLevel <= prj.m_vecRevivalPenalty[veci].nLevel )
			break;
	}
	if( prj.m_vecRevivalPenalty.size() <= veci )
	{
		veci = prj.m_vecRevivalPenalty.size()-1;
	}
	fRate = (float)prj.m_vecRevivalPenalty[veci].nValue / 10000.0f;

	// °æÇèÄ¡´Ù¿î(%)
	for( veci = 0 ; veci < prj.m_vecDecExpPenalty.size() ; ++veci )
	{
		if( veci == 0 && nLevel <= prj.m_vecDecExpPenalty[veci].nLevel )
			break;
		if( veci != 0 && prj.m_vecDecExpPenalty[veci-1].nLevel < nLevel && nLevel <= prj.m_vecDecExpPenalty[veci].nLevel )
			break;
	}
	if( prj.m_vecDecExpPenalty.size() <= veci )
	{
		veci = prj.m_vecDecExpPenalty.size()-1;
	}
	fDecExp = (float)prj.m_vecDecExpPenalty[veci].nValue / 10000.0f;

	// ·¹º§´Ù¿î(À¯/¹«)
	for( veci = 0 ; veci < prj.m_vecLevelDownPenalty.size() ; ++veci )
	{
		if( veci == 0 && nLevel <= prj.m_vecLevelDownPenalty[veci].nLevel )
			break;
		if( veci != 0 && prj.m_vecLevelDownPenalty[veci-1].nLevel < nLevel && nLevel <= prj.m_vecLevelDownPenalty[veci].nLevel )
			break;
	}
	if( prj.m_vecLevelDownPenalty.size() <= veci )
	{
		veci = prj.m_vecLevelDownPenalty.size()-1;
	}
	bLvDown = (prj.m_vecLevelDownPenalty[veci].nValue)? TRUE : FALSE;

#else //  __VER >= 8  
	if( nLevel == 1 )		{ fRate	= 0.8f; fDecExp = 0.0f ; bPxpClear = FALSE; bLvDown = FALSE; }
	else if( nLevel == 2 )	{ fRate	= 0.6f; fDecExp = 0.0f ; bPxpClear = FALSE; bLvDown = FALSE; }
	else if( nLevel <= 5 )	{ fRate	= 0.5f; fDecExp = 0.0f ; bPxpClear = FALSE; bLvDown = FALSE; }
	else if( nLevel <= 10 )	{ fRate	= 0.4f; fDecExp = 0.0f ; bPxpClear = TRUE ; bLvDown = FALSE; }
	else if( nLevel <= 15 )	{ fRate	= 0.3f; fDecExp = 0.02f; bPxpClear = TRUE ; bLvDown = FALSE; }
	else					{ fRate	= 0.3f; fDecExp = 0.03f; bPxpClear = TRUE ; bLvDown = TRUE;  }	
#endif //  __VER >= 8  
}
#if __VER >= 8 // __S8_PK
void CMover::GetDieDecExpRate( FLOAT& fDecExp, DWORD dwDestParam, BOOL bResurrection )
{
	// ·Îµå½ºÅ¸/¶óÀÌÆ®·Î ºÎÈ°ÇÑ°ÍÀº °æÇèÄ¡ ÇÏ¶ô.
	if( dwDestParam != 0 )
	{
		FLOAT fAddDec = (float)(100 - dwDestParam) / 100.0f;
		fDecExp = fDecExp - (fDecExp * fAddDec);
	}
	
	if( IsChaotic() && ( IsSMMode( SM_REVIVAL ) || bResurrection ) )
		fDecExp = fDecExp * 0.9f;
	else if( IsSMMode( SM_REVIVAL ) )
		fDecExp = 0.0f;
}
#else // __VER >= 8 // __S8_PK
void CMover::GetDieDecExpRate( FLOAT& fDecExp, DWORD dwDestParam, int nSlaughter )
{
	// ·Îµå½ºÅ¸/¶óÀÌÆ®·Î ºÎÈ°ÇÑ°ÍÀº °æÇèÄ¡ ÇÏ¶ô.
	if( dwDestParam != 0 )
	{
		FLOAT fAddDec = (float)(100 - dwDestParam) / 100.0f;
		fDecExp = fDecExp - (fDecExp * fAddDec);
	}
	
	// Ä«¸£¸¶ µî±ÞÀº ±âÁ¸ÀÇ »ç¸Á½Ã °æÇèÄ¡ ÇÏ¶ô¿¡µµ ¿µÇâÀ» ¹ÌÄ£´Ù.
	KarmaProp* pProp = prj.GetKarmaProp( nSlaughter );
	if( pProp )
	{
		//fDecExp = ( fDecExp * (1.0f + ( 30.0f / 100.0f) ));
		fDecExp = ( fDecExp * (1.0f + ( (float)pProp->nSubtractExpRate / 100.0f) ));
	}
	
}
#endif // __VER >= 8 // __S8_PK

#if __VER >= 8 // __S8_PK
float CMover::SubDieDecExp( BOOL bTransfer, DWORD dwDestParam, BOOL bResurrection )
#else // __VER >= 8 // __S8_PK
float CMover::SubDieDecExp( BOOL bTransfer, DWORD dwDestParam )
#endif // __VER >= 8 // __S8_PK
{
	if( IsNPC() )	
		return 0.0f;

	float fRate = 0.1f, fDecExp = 0.0f;
	BOOL  bPxpClear = FALSE, bLvDown = FALSE;
	int nLevel	= GetLevel();

	GetDieDecExp( nLevel, fRate, fDecExp, bPxpClear, bLvDown );

	if( m_bLastPK )		// ¹«Á¶°Ç °æÇèÄ¡ ¾È±ï´Â´Ù...
		return fRate;

	if( m_bGuildCombat )
		return fRate;

	if( m_bLastDuelParty )
	{
		m_bLastDuelParty = FALSE;
		return fRate;
	}
#if __VER >= 8	// __CSC_VER8_5
#if __VER < 12 // __ANGEL_NODIE
	( (CUser*)this )->RemoveAngel();
#endif // __ANGEL_NODIE
#endif	// __CSC_VER8_5

//#if __VER < 8  
	bLvDown = FALSE;	// »ç¸Á ½Ã °æÇèÄ¡ ÇÏ¶ôÀ¸·Î ÀÎÇÑ ·¹º§ ÇÏ¶ô ¸·±â
//#endif //  __VER < 8  

	if( fDecExp )
	{
		if( IsAfterDeath() == FALSE ) 
		{
			m_nDeathExp = m_nExp1;		// ÇöÀç °æÇèÄ¡¸¦ Á×¾úÀ» ¶§ °æÇèÄ¡¿¡ ±â·Ï 
			m_nDeathLevel = m_nLevel;	// ÇöÀç ·¹º§ ±â·Ï 
		}

#if __VER >= 8 // __S8_PK
		GetDieDecExpRate( fDecExp, dwDestParam, bResurrection );
#else // __VER >= 8 // __S8_PK
		GetDieDecExpRate( fDecExp, dwDestParam, m_nSlaughter );
#endif // __VER >= 8 // __S8_PK


#if __VER >= 8 // __S8_PK
		if( bResurrection == FALSE && IsSMMode( SM_REVIVAL ) )
			((CUser*)this)->SetSMMode( SM_REVIVAL, 0 );

		bLvDown = DecExperiencePercent( fDecExp, bPxpClear, bLvDown );
#else // __VER >= 8 // __S8_PK
		if( IsSMMode( SM_REVIVAL ) )
			((CUser*)this)->SetSMMode( SM_REVIVAL, 0 );
		else
			bLvDown = DecExperiencePercent( fDecExp, bPxpClear, bLvDown );
#endif // __VER >= 8 // __S8_PK

		if( bTransfer )
		{
			if( bLvDown )	// ·¹º§ ´Ù¿îÀÌ µÇ¾ú´Â°¡?
			{
				g_UserMng.AddSetLevel( this, (WORD)m_nLevel );		// thisÀÌ¿ÜÀÇ ÁÖº¯¿¡ ·¹º§º¯°æÁ¤º¸¸¦ º¸³¿.
				((CUser *)this)->AddSetGrowthLearningPoint( m_nRemainGP );		// ÇØ´çÀ¯Àú¿¡°Ô GPº¯°æÁ¤º¸¸¦ º¸³¿.
			}
			else
				( (CUser *)this )->AddSetExperience( GetExp1(), (WORD)m_nLevel,  m_nSkillPoint, m_nSkillLevel, m_nDeathExp, (WORD)m_nDeathLevel );		// ÇØ´çÀ¯Àú¿¡°Ô exp1,exp2º¯°æµÈ Á¤º¸¸¦ º¸³¿.
		}
	}
	
	return fRate;	// ºÎÈ°ÇÒ¶§ ¾ó¸¶ÀÇ HP¸¦ È¸º¹ÇÒ²¨³Ä.
}

#endif // WORLDSERVER



BOOL CMover::DropItemByDied( CMover* pAttacker )
{
	BOOL bResult;
	OBJID objid = GetMaxEnemyHitID();
	if( objid != NULL_ID )
	{
		CMover* pMover	= prj.GetMover( objid );
		if( IsValidObj( pMover ) )
			bResult = DropItem( pMover );
		else
			objid = NULL_ID;
	}

	if( objid == NULL_ID )
		bResult = DropItem( pAttacker );

	return bResult;
}

// ¸÷ÀÌ Á×¾î¼­ ¾ÆÀÌÅÛÀ» µå¶øÇÒ¶§ »ç¿ë
// Å¬¶ó´Â ÀÌÂÊÀ¸·Î ¾Èµé¾î¿Â´Ù.
// Á×¾î¼­ ¹°°ÇÀ» ¶³¾îÆ®¸®´Â³ÑÀÌ this´Ù.
BOOL CMover::DropItem( CMover* pAttacker )
{
		MoverProp* lpMoverProp	= GetProp();
#ifdef __WORLDSERVER
	if( pAttacker->IsPlayer() && IsNPC() )
	{
#ifdef __VTN_TIMELIMIT
		//	mulcom	BEGIN100315	º£Æ®³² ½Ã°£ Á¦ÇÑ
 		if( ::GetLanguage() == LANG_VTN )
 		{
			if( pAttacker->m_nAccountPlayTime > MIN( 300 ) )
			{
				return	TRUE;
			}
		}
		//	mulcom	END100315	º£Æ®³² ½Ã°£ Á¦ÇÑ
#endif // __VTN_TIMELIMIT

		if( !lpMoverProp )
			return FALSE;

		if( m_nQuestKeeping > 0 )
		{
			CGuildQuestProcessor* pProcessor	= CGuildQuestProcessor::GetInstance();
			GUILDQUESTELEM* pElem	= pProcessor->GetGuildQuest( m_nQuestKeeping );
			if( pElem && pElem->objidWormon == GetId() )
			{
				CGuild* pGuild	= pAttacker->GetGuild();
				if( pGuild )
				{
					pGuild->SetQuest( pElem->nId, pElem->ns );
					g_dpDBClient.SendUpdateGuildQuest( pGuild->m_idGuild, pElem->nId, pElem->ns );
					pElem->nProcess	= GQP_GETITEM;
					pElem->dwEndTime	= GetTickCount() + MIN( 20 );
					pElem->ns	= pElem->nf	= 0;
					pElem->nState	= 0;
					pElem->objidWormon	= NULL_ID;
				}
			}
		}

		if( m_nPartyQuestKeeping > 0 )
		{
			CPartyQuestProcessor* pProcessor	= CPartyQuestProcessor::GetInstance();
			PARTYQUESTELEM* pElem	= pProcessor->GetPartyQuest( m_nPartyQuestKeeping );
			if( pElem && pElem->objidWormon == GetId() )
			{
				CParty* pParty	= g_PartyMng.GetParty( pAttacker->m_idparty );				
				if( pParty )
				{
					pElem->nProcess	= PQP_GETITEM;
					pElem->dwEndTime	= GetTickCount() + MIN( 20 );
					pElem->ns	= pElem->nf	= 0;
					pElem->nState	= 0;
					pElem->objidWormon	= NULL_ID;
					
					pProcessor->SendQuestLimitTime( PQP_GETITEM, MIN( 20 ), pAttacker->m_idparty );
				}
			
			}
		}

		if( ( pAttacker->m_nLevel - (int)lpMoverProp->dwLevel ) < 10 )
		{
			int nNum	= 0;
			CEventItem* pEventItem	= CEventGeneric::GetInstance()->GetItem( &nNum );
			while( pEventItem )
			{
#ifdef __BUGFIX_0326
				if( lpMoverProp->dwFlying )	//
				{
					CItemElem itemElem;
					itemElem.m_dwItemId	= pEventItem->m_dwItemId;
					itemElem.m_nItemNum		= nNum;
					itemElem.SetSerialNumber();
#ifndef __DROP_LOG
					if (pAttacker->CreateItem(&itemElem) == TRUE)
					{
						ItemProp* pItemProp = itemElem.GetProp();
						if (pItemProp)
							((CUser*)pAttacker)->AddDefinedText(TID_GAME_REAPITEM, "\"%s\"", pItemProp->szName);
					}
#endif // __DROP_LOG
				}
				else
#endif	// __BUGFIX_0326
				{
					CItemElem* pItemElem	= new CItemElem;
					pItemElem->m_dwItemId	= pEventItem->m_dwItemId;
					pItemElem->m_nItemNum	= nNum;
					pItemElem->m_nHitPoint	= -1;
					pItemElem->SetSerialNumber();
					CItem* pItem	= new CItem;
					pItem->m_pItemBase	= pItemElem;
					pItem->m_idOwn	= pAttacker->GetId();
					pItem->m_dwDropTime		= timeGetTime();
					pItem->m_bDropMob	= TRUE;
					pItem->SetIndex( D3DDEVICE, pItem->m_pItemBase->m_dwItemId );
					D3DXVECTOR3 vPos = GetPos();
					vPos.x += ( xRandomF(2.0f) - 1.0f );
					vPos.z += ( xRandomF(2.0f) - 1.0f );
					vPos.y = GetPos().y;
					pItem->SetPos( vPos );
					GetWorld()->ADDOBJ( pItem, TRUE, GetLayer() );
				}
				pEventItem	= CEventGeneric::GetInstance()->GetItem( &nNum );
			}
#if __VER >= 9 // __EVENTLUA
			map<DWORD, int> mapItemList = prj.m_EventLua.GetItem( lpMoverProp->dwLevel );

			for( map<DWORD, int>::iterator it=mapItemList.begin(); it!=mapItemList.end(); it++ )
			{
	#ifdef __BUGFIX_0326
				if( lpMoverProp->dwFlying )	//
				{
					CItemElem itemElem;
					itemElem.m_dwItemId	= it->first;
					itemElem.m_nItemNum	= it->second;
					itemElem.SetSerialNumber();
#ifndef __DROP_LOG
					if (pAttacker->CreateItem(&itemElem) == TRUE)
					{
						ItemProp* pItemProp = itemElem.GetProp();
						if (pItemProp)
							((CUser*)pAttacker)->AddDefinedText(TID_GAME_REAPITEM, "\"%s\"", pItemProp->szName);
					}
#endif // __DROP_LOG
				}
				else
	#endif	// __BUGFIX_0326
				{
					CItemElem* pItemElem	= new CItemElem;
					pItemElem->m_dwItemId	= it->first;
					pItemElem->m_nItemNum	= it->second;
					pItemElem->m_nHitPoint	= -1;
					pItemElem->SetSerialNumber();
					CItem* pItem	= new CItem;
					pItem->m_pItemBase	= pItemElem;
					pItem->m_idOwn	= pAttacker->GetId();
					pItem->m_dwDropTime		= timeGetTime();
					pItem->m_bDropMob	= TRUE;
					pItem->SetIndex( D3DDEVICE, pItem->m_pItemBase->m_dwItemId );
					D3DXVECTOR3 vPos = GetPos();
					vPos.x += ( xRandomF(2.0f) - 1.0f );
					vPos.z += ( xRandomF(2.0f) - 1.0f );
					vPos.y = GetPos().y;
					pItem->SetPos( vPos );
					GetWorld()->ADDOBJ( pItem, TRUE, GetLayer() );
				}
			}
#endif // __EVENTLUA
		}

		QUESTITEM* pQuestItem;
		short nNum;
		u_long uSizeOfQuestItem	= lpMoverProp->m_QuestItemGenerator.GetSize();
		for( u_long i = 0; i < uSizeOfQuestItem; i++ ) 
		{
			pQuestItem	= lpMoverProp->m_QuestItemGenerator.GetAt( i );
			LPQUEST lpQuest = pAttacker->GetQuest( pQuestItem->dwQuest );
			if( lpQuest && lpQuest->m_nState == pQuestItem->dwState ) 
			{
				DWORD dwProbability	= pQuestItem->dwProbability;

				if( pQuestItem->dwQuest == QUEST_VALENTINE || pQuestItem->dwQuest == QUEST_WHITEDAY )
				{
					float f;
					int  d	= pAttacker->m_nLevel - (int)lpMoverProp->dwLevel;
					if( d <= 1 )	f	= 1.0f;
					else if( d <= 2 )	f	= 0.8f;
					else if( d <= 4 )	f	= 0.6f;
					else if( d <= 7 )	f	= 0.3f;
					else	f	= 0.1f;
					dwProbability	= (DWORD)( dwProbability * f );
				}

				if( xRandom( 3000000000 ) <= dwProbability ) 
				{
					if( pQuestItem->dwNumber == 0 )
						Error( "CMover::DropItem : %sÀÇ quest item drop %d¹øÂ°ÀÇ dwNumber°¡ 0", GetName(), i );
					nNum	= (short)( xRandom( pQuestItem->dwNumber ) + 1 );
					if( pQuestItem->dwIndex == 0 )
					{
						WriteLog( "%s, %d\r\n\t%s", __FILE__, __LINE__, lpMoverProp->szName );
						break;
					}
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
					CParty* pParty	= g_PartyMng.GetParty( pAttacker->m_idparty );
					if( pParty && pParty->IsMember( pAttacker->m_idPlayer ) )	// party
					{
						for( int j = 0; j < pParty->GetSizeofMember(); ++j )
						{
							PartyMember* pPartyMember	= &pParty->m_aMember[j];
							CMover* pMember		= prj.GetUserByID( pPartyMember->m_uPlayerId );
							if( !IsValidObj( pMember ) || !IsValidArea( pMember, 64.0f ) )
								continue;
							
							LPQUEST pMemberQuest	= pMember->GetQuest( pQuestItem->dwQuest );
							if( pMemberQuest && pMemberQuest->m_nState == pQuestItem->dwState )
							{
								BYTE nId;
								CItemElem itemElem;
								itemElem.m_dwItemId		= pQuestItem->dwIndex;
								itemElem.m_nItemNum		= nNum;
								itemElem.m_nHitPoint	= -1;
								if( pMember->CreateItem( &itemElem, &nId ) == FALSE )
								{
									CItemElem* pItemElem	= new CItemElem;
									pItemElem->m_dwItemId	= pQuestItem->dwIndex;
									pItemElem->m_nItemNum	= nNum;
									ItemProp* pItemProp		= pItemElem->GetProp();
									if( pItemProp )
										pItemElem->m_nHitPoint		= pItemProp->dwEndurance;
									pItemElem->SetSerialNumber();
									CItem* pItem	= new CItem;
									pItem->m_pItemBase	= pItemElem;
									if( pItemElem->m_dwItemId == 0 )
										Error("DropItem:1st %s\n", GetName() );
									pItem->SetIndex( D3DDEVICE, pItemElem->m_dwItemId );
									pItem->SetPos( pMember->GetPos() );
									pItem->SetAngle( (float)( xRandom( 360 ) ) );
									pItem->m_idHolder	= pMember->m_idPlayer;
									pItem->m_dwDropTime		= timeGetTime();
									pMember->GetWorld()->ADDOBJ( pItem, TRUE, GetLayer() );
								}
								else
								{
									( (CUser*)pMember )->AddDefinedText( TID_EVE_REAPITEM, "\"%s\"", prj.GetItemProp( pQuestItem->dwIndex )->szName );
									CItemBase* pItemBase	= pMember->GetItemId( nId );
									if( pItemBase )
									{
										CItemElem* pItemElem	= (CItemElem*)pItemBase;
										LogItemInfo aLogItem;
										aLogItem.Action = "Q";
										aLogItem.SendName = pMember->m_szName;
										aLogItem.RecvName = "QUEST";
										aLogItem.WorldId = pMember->GetWorld()->GetID();
										aLogItem.Gold = aLogItem.Gold2 = pMember->GetGold();
										g_DPSrvr.OnLogItem( aLogItem, pItemElem, pItemElem->m_nItemNum );
									}
								}
							}
						}
					}
					else	// solo
					{
						BYTE nId;
						CItemElem itemElem;
						itemElem.m_dwItemId		= pQuestItem->dwIndex;
						itemElem.m_nItemNum		= nNum;
						itemElem.m_nHitPoint	= -1;
						if( pAttacker->CreateItem( &itemElem, &nId ) == FALSE )
						{
							CItemElem* pItemElem	= new CItemElem;
							pItemElem->m_dwItemId	= pQuestItem->dwIndex;
							pItemElem->m_nItemNum	= nNum;
							ItemProp* pItemProp		= pItemElem->GetProp();
							if( pItemProp )
								pItemElem->m_nHitPoint		= pItemProp->dwEndurance;
							pItemElem->SetSerialNumber();
							CItem* pItem	= new CItem;
							pItem->m_pItemBase	= pItemElem;
							if( pItemElem->m_dwItemId == 0 )
								Error("DropItem:1st %s\n", GetName() );
							pItem->SetIndex( D3DDEVICE, pItemElem->m_dwItemId );
							pItem->SetPos( pAttacker->GetPos() );
							pItem->SetAngle( (float)( xRandom( 360 ) ) );
							pItem->m_idHolder	= pAttacker->m_idPlayer;
							pItem->m_dwDropTime		= timeGetTime();
							pAttacker->GetWorld()->ADDOBJ( pItem, TRUE, GetLayer() );
						}
						else
						{
							( (CUser*)pAttacker )->AddDefinedText( TID_EVE_REAPITEM, "\"%s\"", prj.GetItemProp( pQuestItem->dwIndex )->szName );
							CItemBase* pItemBase	= pAttacker->GetItemId( nId );
							if( pItemBase )
							{
								CItemElem* pItemElem	= (CItemElem*)pItemBase;
								LogItemInfo aLogItem;
								aLogItem.Action = "Q";
								aLogItem.SendName = pAttacker->m_szName;
								aLogItem.RecvName = "QUEST";
								aLogItem.WorldId = pAttacker->GetWorld()->GetID();
								aLogItem.Gold = aLogItem.Gold2 = pAttacker->GetGold();
								g_DPSrvr.OnLogItem( aLogItem, pItemElem, pItemElem->m_nItemNum );
							}
						}
					}
#else // __IMPROVE_QUEST_INTERFACE
					int nMemberSize		= 0;
					CMover* pMember;
					CMover* apMember[MAX_PTMEMBER_SIZE];
					// 1
					CParty* pParty	= g_PartyMng.GetParty( pAttacker->m_idparty );
					if( pParty && pParty->IsMember( pAttacker->m_idPlayer ) )
					{
						int nPartyMemberSize	= pParty->GetSizeofMember();
						for( int j = 0; j < nPartyMemberSize; j++ )
						{
							PartyMember* pPartyMember	= &pParty->m_aMember[j];
							pMember		= prj.GetUserByID( pPartyMember->m_uPlayerId );
							if( IsValidObj( pMember ) && IsNearPC( pMember->GetId() ) )
							{
								LPQUEST pMemberQuest	= pMember->GetQuest( pQuestItem->dwQuest );
								if( pMemberQuest && pMemberQuest->m_nState == pQuestItem->dwState )
									apMember[nMemberSize++]	= pMember;
							}
						}
					}
					// 3
					// 4
					CMover* pTakeMover;
					if( nMemberSize > 0 )
						pTakeMover	= apMember[xRandom( nMemberSize )];
					else
						pTakeMover	= pAttacker;

					BYTE nId;
					CItemElem itemElem;
					itemElem.m_dwItemId		= pQuestItem->dwIndex;
					itemElem.m_nItemNum		= nNum;
					itemElem.m_nHitPoint	= -1;
					if( pTakeMover->CreateItem( &itemElem, &nId ) == FALSE )
					{
						CItemElem* pItemElem	= new CItemElem;
						pItemElem->m_dwItemId	= pQuestItem->dwIndex;
						pItemElem->m_nItemNum	= nNum;
						ItemProp* pItemProp		= pItemElem->GetProp();
						if( pItemProp )
							pItemElem->m_nHitPoint		= pItemProp->dwEndurance;
						pItemElem->SetSerialNumber();
						CItem* pItem	= new CItem;
						pItem->m_pItemBase	= pItemElem;
						if( pItemElem->m_dwItemId == 0 ) Error("DropItem:1st %s\n", GetName() );
						pItem->SetIndex( D3DDEVICE, pItemElem->m_dwItemId );
						pItem->SetPos( pTakeMover->GetPos() );
						pItem->SetAngle( xRandom( 360 ) );
						pItem->m_idHolder	= pTakeMover->m_idPlayer;
						pItem->m_dwDropTime		= timeGetTime();
						pTakeMover->GetWorld()->ADDOBJ( pItem, TRUE, GetLayer() );
					}
					else
					{
						( (CUser*)pTakeMover )->AddDefinedText( TID_EVE_REAPITEM, "\"%s\"", prj.GetItemProp( pQuestItem->dwIndex )->szName );
						// Äù½ºÆ® ¾ÆÀÌÅÛ ·Î±×
						CItemBase* pItemBase	= pTakeMover->GetItemId( nId );
						if( pItemBase )
						{
							CItemElem* pItemElem	= (CItemElem*)pItemBase;
							LogItemInfo aLogItem;
							aLogItem.Action = "Q";
							aLogItem.SendName = pTakeMover->m_szName;
							aLogItem.RecvName = "QUEST";
							aLogItem.WorldId = pTakeMover->GetWorld()->GetID();
							aLogItem.Gold = aLogItem.Gold2 = pTakeMover->GetGold();
							g_DPSrvr.OnLogItem( aLogItem, pItemElem, pItemElem->m_nItemNum );
						}
					}
#endif // __IMPROVE_QUEST_INTERFACE
				}
			}
		}

		int nloop = 1;
		BOOL bUnique = FALSE;
		if( pAttacker->m_idparty ) // ³»°¡ ÆÄÆ¼¿¡ Âü¿© ¿©ºÎ
		{
			CParty* pParty = g_PartyMng.GetParty( pAttacker->m_idparty );
			if( pParty )
			{
				// ¼øÈ¸±Ø´ÜÀÌ¸ç ¸µÅ©¾îÅÃÁßÀÌ¸ç ´ÜÀå¸¸ µ¥¹ÌÁö¸¦ ³ô¿©ÁØ´Ù
				if( pParty->m_nKindTroup == 1 )
				{
					if( pParty->m_nModeTime[PARTY_GIFTBOX_MODE] || pParty->m_nModeTime[PARTY_FORTUNECIRCLE_MODE] )
					{
#if __VER >= 12 // __PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
						if( pParty->m_nModeTime[PARTY_PARSKILL_MODE] )
						{
							if( pParty->m_nModeTime[PARTY_GIFTBOX_MODE] )
								nloop = 2;
							if( pParty->m_nModeTime[PARTY_FORTUNECIRCLE_MODE] )
								bUnique = TRUE;
						}
						else
						{
							CUser* pLeader = g_UserMng.GetUserByPlayerID( pParty->m_aMember[0].m_uPlayerId );
							if( IsValidObj( (CObj*)pLeader )/* && pLeader->IsNearPC( (CUser*)pAttacker ) && IsOrigin()*/ )
							{
								if( pLeader->IsValidArea( pAttacker, 255.0f ) )
								{
									if( pParty->m_nModeTime[PARTY_GIFTBOX_MODE] )
										nloop = 2;
									if( pParty->m_nModeTime[PARTY_FORTUNECIRCLE_MODE] )
										bUnique = TRUE;
								}
							}
						}
#else	//__PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
						// ¿©±â¼­ ´ÜÀåÁÖÀ§¸¦ °Ë»öÇÏ¿© ÁÖÀ§ÀÌ¸é ÇÒ¼ö ÀÕ°Ô ÇÔ
						CUser* pLeader = g_UserMng.GetUserByPlayerID( pParty->m_aMember[0].m_uPlayerId );
						if( IsValidObj( (CObj*)pLeader )/* && pLeader->IsNearPC( (CUser*)pAttacker ) && IsOrigin()*/ )
						{
							if( pLeader->IsSMMode( SM_PARTYSKILL1 ) || pLeader->IsSMMode( SM_PARTYSKILL15 ) || pLeader->IsSMMode( SM_PARTYSKILL30 ) )	// ¿©±â¼­ À¯·á ¾ÆÀÌÅÛ »ç¿ëÁßÀÎÁö È®ÀÎ
							{
								if( pParty->m_nModeTime[PARTY_GIFTBOX_MODE] )
								{
									nloop = 2;
								}
								if( pParty->m_nModeTime[PARTY_FORTUNECIRCLE_MODE] )
								{
									bUnique = TRUE;
								}
							}
							else
							{
								if( pLeader->IsValidArea( pAttacker, 255.0f ) )
								{
									if( pParty->m_nModeTime[PARTY_GIFTBOX_MODE] )
									{
										nloop = 2;
									}
									if( pParty->m_nModeTime[PARTY_FORTUNECIRCLE_MODE] )
									{
										bUnique = TRUE;
									}
								}
							}
						}
#endif //__PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
					}
				}
			}
		}
#if __VER >= 9 // __II_SYS_SYS_SCR_GET
		if( pAttacker->HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_GET01 ) )
			nloop += 1;
		if( pAttacker->HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_GET02 ) )
			nloop += 2;
#endif // __II_SYS_SYS_SCR_GET
#ifdef __DST_GIFTBOX
			nloop += pAttacker->GetAdjParam( DST_GIFTBOX );
#endif // __DST_GIFTBOX
#ifdef MAX_GIFT_BOX
			if (nloop > MAX_GIFT_BOX)
				nloop = MAX_GIFT_BOX;
#endif // MAX_GIFT_BOX
		D3DXVECTOR3 vPos;		// µå¶øµÉ À§Ä¡.

#ifdef __EVENT_MONSTER
		// ÀÌº¥Æ® ¸ó½ºÅÍ´Â ¼³Á¤¿¡ µû¶ó ÇÑ¹ø¸¸ µå¶øÇÑ´Ù.
		if( CEventMonster::GetInstance()->SetEventMonster( lpMoverProp->dwID ) )
			if( !CEventMonster::GetInstance()->IsGiftBoxAble() )
				nloop = 1;
#endif // __EVENT_MONSTER
#ifdef __SHUFFLE_DROP
		int nShuffleSize = lpMoverProp->m_DropItemGenerator.GetSize();
		vector<int> shuffleVec(nShuffleSize);
		for (int j = 0; j < nShuffleSize; j++)
		{
			shuffleVec[j] = j;
		}
		std::random_shuffle(shuffleVec.begin(), shuffleVec.end());
#endif
		for( int k = 0 ; k < nloop ; k++ )
		{
			// ¾ÆÀÌÅÛ µå·Ó È®·ü		
			int nProbability	= 100, nPenyaRate	= 100;
			BOOL bAdjDropRate = TRUE;	// ÀÏ¹ÝÀûÀ¸·Ð ·¹º§Â÷¿¡ ÀÇÇÑ µå¶ø·üÀúÇÏ°¡ ÀÌ·ïÁø´Ù.

			if( GetIndex() == MI_CLOCKWORK1 )	//·¹º§Â÷¿¡ÀÇÇÑ µå¶ø·üÀúÇÏ°¡ ¾ø´Ù.
				bAdjDropRate = FALSE;

			if( GetIndex() == MI_DEMIAN5 || GetIndex() == MI_KEAKOON5 || GetIndex() == MI_MUFFRIN5 )
				bAdjDropRate = FALSE;		// ÀÌº¥Æ®¸÷µéµµ ·¹º§Â÷¿¡ÀÇÇÑ µå¶ø·ü ÀúÇÏ°¡ ¾ø´Ù.
#ifdef __EVENT_MONSTER
			if( CEventMonster::GetInstance()->SetEventMonster( lpMoverProp->dwID ) )
				bAdjDropRate = FALSE;
#endif // __EVENT_MONSTER
#ifdef __EVENTLUA_SPAWN
			if( prj.m_EventLua.IsEventSpawnMonster( lpMoverProp->dwID ) )
				bAdjDropRate = FALSE;
#endif // __EVENTLUA_SPAWN
			if( bAdjDropRate )
			{
				int d	= pAttacker->m_nLevel - (int)lpMoverProp->dwLevel;
				if( d <= 1 )	{	nProbability	= 100;	nPenyaRate	= 100;	}
				else if( d <= 2 )	{	nProbability	= 80;	nPenyaRate	= 100;	}
				else if( d <= 4 )	{	nProbability	= 60;	nPenyaRate	= 80;	}
				else if( d <= 7 )	{	nProbability	= 30;	nPenyaRate	= 65;	}
				else	{	nProbability	= 10;	nPenyaRate	= 50;	}
			}

			FLOAT fItemDropRate		= nProbability * GetItemDropRateFactor( pAttacker );

			if( xRandom( 100 ) < fItemDropRate )	// ¾ÆÀÌÅÛÀ» µå·ÓÇÒÁö ¸»Áö °áÁ¤. ·¹º§Â÷°¡ ¸¹ÀÌ ³ª¸é ¾Æ¿¹ ¶³¾îÆ®¸®Áö ¾Ê´Â´Ù.
			{
				int nSize	= lpMoverProp->m_DropItemGenerator.GetSize();
				int nNumber	= 0;
				DROPITEM* lpDropItem;
		
				for( int i = 0; i < nSize; i++ )
				{
#ifdef __SHUFFLE_DROP
					if (i >= 0 && i < shuffleVec.size())
						lpDropItem = lpMoverProp->m_DropItemGenerator.GetAt(shuffleVec[i], bUnique, GetPieceItemDropRateFactor(pAttacker));
					else
						lpDropItem = NULL;

					if (lpDropItem != NULL)
#else // __SHUFFLE_DROP
					if ((lpDropItem = lpMoverProp->m_DropItemGenerator.GetAt(i, bUnique, GetPieceItemDropRateFactor(pAttacker))) != NULL)
#endif // __SHUFFLE_DROP
					{
						if( lpDropItem->dtType == DROPTYPE_NORMAL )
						{
#ifdef __GAMEGUARD
							ItemProp* pProp = prj.GetItemProp(lpDropItem->dwIndex);
							if (!pProp)
							{
								Error("CMover::DropItemByDied() [ItemID:%d][MoverID:%d]", lpDropItem->dwIndex, GetProp()->dwID);
								continue;
							}
#endif // __GAMEGUARD
							DWORD dwNum		= lpDropItem->dwNumber;
							if(  dwNum == (DWORD)-1 )
								dwNum	= 1;

							if( lpMoverProp->dwFlying )
							{
								CItemElem itemElem;
								itemElem.m_dwItemId	= lpDropItem->dwIndex;
								itemElem.m_nItemNum	= (short)( xRandom( dwNum ) + 1 );
								itemElem.SetAbilityOption( lpDropItem->dwLevel );
								
								if( pAttacker->CreateItem( &itemElem ) == TRUE )
								{	// log
									ItemProp* pItemProp	= itemElem.GetProp();
									if( pItemProp )
									{
#ifndef __DROP_LOG
										((CUser*)pAttacker)->AddDefinedText(TID_GAME_REAPITEM, "\"%s\"", pItemProp->szName);
#endif // __DROP_LOG
										if( pItemProp->dwItemKind1 == IK1_WEAPON || pItemProp->dwItemKind1 == IK1_ARMOR || ( pItemProp->dwItemKind1 == IK1_GENERAL && pItemProp->dwItemKind2 == IK2_JEWELRY ) )
										{
											switch( pItemProp->nLog )
											{
												case 1:		g_dpDBClient.SendLogUniqueItem2( pAttacker, itemElem.GetProp(), itemElem.GetAbilityOption() );	break;
												case 2:		g_dpDBClient.SendLogUniqueItem2( pAttacker, itemElem.GetProp(), 200 );	break;
												case 3:		g_dpDBClient.SendLogUniqueItem2( pAttacker, itemElem.GetProp(), 100 );	break;
											}
										}
									}
									if( lpDropItem->dwNumber != (DWORD)-1 )
										nNumber++;
									if(  (DWORD)( nNumber ) >= lpMoverProp->m_DropItemGenerator.m_dwMax )
										break;
								}
								continue;
							}
							CItemElem* pItemElem	= new CItemElem;
							pItemElem->m_dwItemId	= lpDropItem->dwIndex;
							pItemElem->m_nItemNum	= (short)( xRandom( dwNum ) + 1 );
							ItemProp* pItemProp		= pItemElem->GetProp();
							if( pItemProp )
							{
								pItemElem->m_nHitPoint	= pItemProp->dwEndurance;
								pItemElem->SetRandomOpt( CRandomOptItemGen::GetInstance()->GenRandomOptItem( lpMoverProp->dwLevel, (FLOAT)nProbability / 100.0f, pItemProp, lpMoverProp->dwClass ) );
							}
							pItemElem->SetAbilityOption( lpDropItem->dwLevel );		// Ãß°¡ ´É·ÂÄ¡ +1, +2 °°Àº°Å.
#ifdef __WEAPON_RARITY
							pItemElem->SetRandomWeaponRarity();
#endif // __WEAPON_RARITY
							pItemElem->SetSerialNumber();
							CItem* pItem	= new CItem;
							pItem->m_pItemBase	= pItemElem;
							BOOL bJJim = TRUE;		// ÁÖÀÎÀÌ ÀÖ´Ù´Â°É Ç¥½ÃÇØ¾ßÇÏ´Â ÅÛÀÎ°¡.
							if( lpMoverProp->dwClass == RANK_SUPER )		// º¸½º¸÷ÀÌ µå·ÓÇÑ ¾ÆÀÌÅÛÀº ¾Æ¹«³ª ¸ÔÀ»¼ö ÀÖ´Ù.
								bJJim = FALSE;
							if( GetIndex() == MI_DEMIAN5 || GetIndex() == MI_KEAKOON5 || GetIndex() == MI_MUFFRIN5 )
								bJJim = FALSE;		// ¾êµéÀº ÀÌº¥Æ®¸÷ÀÌ¹Ç·Î Âò¾ÈÇØ³öµµ µÈ´Ù. ¾Æ¹«³ª ¸ÔÀ»¼ö ÀÖÀ½
							if( bJJim )
							{
								pItem->m_idOwn = pAttacker->GetId();	// ÀÌ ¾ÆÀÌÅÛÀÇ ¼ÒÀ¯°¡ pAttacker(¾îÅÂÄ¿)²¨¶õ°É Ç¥½Ã.
								pItem->m_dwDropTime = timeGetTime();	// µå¶ø ÇßÀ»´ç½ÃÀÇ ½Ã°£À» ±â·ÏÇÔ.
							}
							pItem->m_bDropMob = TRUE;		// ¸÷ÀÌ Á×¾î¼­ ¶³±º µ·Àº Ç¥½Ã¸¦ ÇØµÒ.
							if( pItem->m_pItemBase->m_dwItemId == 0 ) Error("DropItem:2nd %s\n", GetName() );
							pItem->SetIndex( D3DDEVICE, pItem->m_pItemBase->m_dwItemId );

							vPos = GetPos();
							vPos.x += ( xRandomF(2.0f) - 1.0f );
							vPos.z += ( xRandomF(2.0f) - 1.0f );
							vPos.y = GetPos().y;
					#ifdef __EVENT_MONSTER
							// ÀÌº¥Æ® ¸ó½ºÅÍ°¡ µå¶øÇÑ ¾ÆÀÌÅÛÀº ¸ó½ºÅÍÀÇ ID¸¦ ±â¾ïÇÑ´Ù(ÆêÀÌ ¸ø ÁÝ°Ô...)
							if( CEventMonster::GetInstance()->SetEventMonster( lpMoverProp->dwID ) )
							{
								// ÀÌº¥Æ® ¸ó½ºÅÍ´Â ¹«Á¶°Ç ¼±Á¡±ÇÀ» °®´Â´Ù.
								pItem->m_idOwn	= pAttacker->GetId();
								pItem->m_dwDropTime		= timeGetTime();

								pItem->m_IdEventMonster = lpMoverProp->dwID;
								float fItemDropRange = CEventMonster::GetInstance()->GetItemDropRange(); 
								vPos = GetPos();
								vPos.x += ( xRandomF( fItemDropRange ) - (fItemDropRange / 2.0f) );
								vPos.z += ( xRandomF( fItemDropRange ) - (fItemDropRange / 2.0f) );
							}
					#endif // __EVENT_MONSTER
							pItem->SetPos( vPos );

							GetWorld()->ADDOBJ( pItem, TRUE, GetLayer() );

							if( lpDropItem->dwNumber != (DWORD)-1 )
								nNumber++;

							if( pItemProp->dwItemKind1 == IK1_WEAPON || pItemProp->dwItemKind1 == IK1_ARMOR || ( pItemProp->dwItemKind1 == IK1_GENERAL && pItemProp->dwItemKind2 == IK2_JEWELRY ) )
							{
								switch( pItemProp->nLog )
								{
								case 1:		g_dpDBClient.SendLogUniqueItem( pAttacker, pItem, pItemElem->GetAbilityOption() );	// ÀÏ¹Ý ¾ÆÀÌÅÛ +¾ÆÀÌÅÛ
									break;
								case 2:		g_dpDBClient.SendLogUniqueItem( pAttacker, pItem, 200 );	// ÀÌÆåÆ® ¾ÆÀÌÅÛ
									break;
								case 3:		g_dpDBClient.SendLogUniqueItem( pAttacker, pItem, 100 );	// À¯´ÏÅ© ¾ÆÀÌÅÛ
									break;
								}
							}

							if( nNumber == lpMoverProp->m_DropItemGenerator.m_dwMax )
								break;
						} else
						// µ·Àº ¹«Á¶°Ç¶³¾îÁ®¾ß ÇÑ´Ù.
						if( lpDropItem->dtType == DROPTYPE_SEED && k == 0 )
						{
							int	nSeedID = 0;
							int nNumGold = lpDropItem->dwNumber + xRandom( lpDropItem->dwNumber2 - lpDropItem->dwNumber );	// Number ~ Number2 »çÀÌÀÇ ·£´ý°ª.
							nNumGold	= nNumGold * nPenyaRate / 100;
	#ifdef __S1108_BACK_END_SYSTEM
							nNumGold	= (int)( nNumGold * prj.m_fGoldDropRate * lpMoverProp->m_fPenya_Rate );
							if( nNumGold == 0 )
								continue;
	#else // __S1108_BACK_END_SYSTEM
							nNumGold	*= prj.m_fGoldDropRate;
	#endif // __S1108_BACK_END_SYSTEM
							
	#if __VER >= 9 // __EVENTLUA
							nNumGold	= (int)( nNumGold * prj.m_EventLua.GetGoldDropFactor() );
	#endif // __EVENTLUA
#ifdef __DST_CHANCEDROP_GOLD
							double dPenyaRate = pAttacker->GetAdjParam(DST_GOLDDROP) / 100.0 + 1.0;
							nNumGold = (int)(nNumGold * dPenyaRate);
#endif //__DST_CHANCEDROP_GOLD

							if( lpMoverProp->dwFlying )
							{
								if( CanAdd( pAttacker->GetGold(), nNumGold ) )
								{
									pAttacker->AddGold( nNumGold );
									( (CUser*)pAttacker )->AddGoldText( nNumGold );
								}
							}
							else
							{
								// µ·¾×¼ö¿¡ µû¶ó ¾î¶²¸ð¾çÀÇ ½Ãµå¸¦ »ç¿ëÇÒÁö °áÁ¤ÇÑ´Ù.
								if( nNumGold <= (int)( prj.GetItemProp( II_GOLD_SEED1 )->dwAbilityMax ) )
									nSeedID = II_GOLD_SEED1;
								else if( nNumGold <= (int)( prj.GetItemProp( II_GOLD_SEED2 )->dwAbilityMax ) )
									nSeedID = II_GOLD_SEED2;
								else if( nNumGold <= (int)( prj.GetItemProp( II_GOLD_SEED3 )->dwAbilityMax ) )
									nSeedID = II_GOLD_SEED3;
								else 
									nSeedID = II_GOLD_SEED4;

								CItemElem* pItemElem	= new CItemElem;
								pItemElem->m_dwItemId	= nSeedID;
								pItemElem->m_nItemNum	= nNumGold;	// µ·¾×¼ö
								pItemElem->m_nHitPoint	= nNumGold;
								CItem* pItem	= new CItem;
								pItem->m_pItemBase	= pItemElem;
								BOOL bJJim = TRUE;
								if( lpMoverProp->dwClass == RANK_SUPER )		// º¸½º¸÷ÀÌ µå·ÓÇÑ ¾ÆÀÌÅÛÀº ¾Æ¹«³ª ¸ÔÀ»¼ö ÀÖ´Ù.
									bJJim = FALSE;
								if( GetIndex() == MI_DEMIAN5 || GetIndex() == MI_KEAKOON5 || GetIndex() == MI_MUFFRIN5 )
									bJJim = FALSE;		// ¾êµéÀº ÀÌº¥Æ®¸÷ÀÌ¹Ç·Î Âò¾ÈÇØ³öµµ µÈ´Ù. ¾Æ¹«³ª ¸ÔÀ»¼ö ÀÖÀ½
								if( bJJim )
								{
									pItem->m_idOwn = pAttacker->GetId();	// ÀÌ ¾ÆÀÌÅÛÀÇ ¼ÒÀ¯°¡ pAttacker(¾îÅÂÄ¿)²¨¶õ°É Ç¥½Ã.
									pItem->m_dwDropTime = timeGetTime();	// µå¶ø ÇßÀ»´ç½ÃÀÇ ½Ã°£À» ±â·ÏÇÔ.
								}
								pItem->m_bDropMob = TRUE;		// ¸÷ÀÌ Á×¾î¼­ ¶³±º µ·Àº Ç¥½Ã¸¦ ÇØµÒ.
								if( pItem->m_pItemBase->m_dwItemId == 0 ) Error("DropItem: 3rd %s\n", GetName() );
								pItem->SetIndex( D3DDEVICE, pItem->m_pItemBase->m_dwItemId );

								vPos = GetPos();
								vPos.x += ( xRandomF(2.0f) - 1.0f );
								vPos.z += ( xRandomF(2.0f) - 1.0f );
						#ifdef __EVENT_MONSTER
								// ÀÌº¥Æ® ¸ó½ºÅÍ°¡ µå¶øÇÑ ¾ÆÀÌÅÛÀº ¸ó½ºÅÍÀÇ ID¸¦ ±â¾ïÇÑ´Ù(ÆêÀÌ ¸ø ÁÝ°Ô...)
								if( CEventMonster::GetInstance()->SetEventMonster( lpMoverProp->dwID ) )
								{
									// ÀÌº¥Æ® ¸ó½ºÅÍ´Â ¹«Á¶°Ç ¼±Á¡±ÇÀ» °®´Â´Ù.
									pItem->m_idOwn	= pAttacker->GetId();
									pItem->m_dwDropTime		= timeGetTime();
									
									pItem->m_IdEventMonster = lpMoverProp->dwID;
									float fItemDropRange = CEventMonster::GetInstance()->GetItemDropRange(); 
									vPos = GetPos();
									vPos.x += ( xRandomF( fItemDropRange ) - (fItemDropRange / 2.0f) );
									vPos.z += ( xRandomF( fItemDropRange ) - (fItemDropRange / 2.0f));
								}
						#endif // __EVENT_MONSTER
								pItem->SetPos( vPos );
								GetWorld()->ADDOBJ( pItem, TRUE, GetLayer() );
							}
						} // DROPTYPE_SEED
					} // if
					//////////////
					//  ¿©±â±îÁö for-loop¾È³»·Á¿À°í continueÇÏ´Â ¼öµµ ÀÖÀ¸´Ï±î ¿©±â´Ù ÄÚµå ³ÖÁö ¸»°Í.
					///////////
				} // for nSize

				nSize	= lpMoverProp->m_DropKindGenerator.GetSize();
				DROPKIND* pDropKind;
				CPtrArray* pItemKindAry;
				int nAbilityOption; //, nDropLuck;
				BOOL bDrop = FALSE;
				for( int i = 0; i < nSize; i++ )
				{
					bDrop = FALSE;
					pDropKind	= lpMoverProp->m_DropKindGenerator.GetAt( i );
					pItemKindAry	= prj.GetItemKindAry( pDropKind->dwIK3 );
					int nMinIdx	= -1,	nMaxIdx		= -1;
					for( int j = pDropKind->nMinUniq; j <= pDropKind->nMaxUniq; j++ )
					{
						nMinIdx		= prj.GetMinIdx( pDropKind->dwIK3, j );
						if( nMinIdx != -1 )
							break;
					}
					for( int j = pDropKind->nMaxUniq; j >= pDropKind->nMinUniq; j-- )
					{
						nMaxIdx		= prj.GetMaxIdx( pDropKind->dwIK3, j );
						if( nMaxIdx != -1 )
							break;
					}
					if( nMinIdx < 0 || nMaxIdx < 0 )
					{
#ifdef __INTERNALSERVER
						WriteLog( "dropkind, 1, dwIndex = %d, nIndex = %d", lpMoverProp->dwID, i );
#endif	// __INTERNALSERVER
						continue;
					}
					ItemProp* pItemProp		= (ItemProp*)pItemKindAry->GetAt( nMinIdx + xRandom( nMaxIdx - nMinIdx + 1 ) );
					if( NULL == pItemProp )
					{
#ifdef __INTERNALSERVER
						WriteLog( "dropkind, 2, dwIndex = %d, nIndex = %d", lpMoverProp->dwID, i );
#endif	// __INTERNALSERVER
						continue;
					}

					nAbilityOption	= xRandom( 11 );	// 0 ~ 10

					DWORD dwAdjRand;
					
					for( int k = nAbilityOption; k >= 0; k-- )
					{
						DWORD dwPrabability		= (DWORD)( prj.m_adwExpDropLuck[( pItemProp->dwItemLV > 120? 119: pItemProp->dwItemLV-1 )][k]
						* ( (float)lpMoverProp->dwCorrectionValue / 100.0f ) );

						dwAdjRand	= xRandom( 3000000000 );
						if( bUnique && dwPrabability <= 10000000 )
							dwAdjRand	/= 2;
						
						if( dwAdjRand < dwPrabability )
						{
							if( lpMoverProp->dwFlying )
							{
								CItemElem itemElem;
								itemElem.m_dwItemId		= pItemProp->dwID;
								itemElem.m_nItemNum		= 1;
								itemElem.SetAbilityOption( k );
								itemElem.SetRandomOpt( CRandomOptItemGen::GetInstance()->GenRandomOptItem( lpMoverProp->dwLevel, (FLOAT)nProbability / 100.0f, pItemProp, lpMoverProp->dwClass ) );

								if( pAttacker->CreateItem( &itemElem ) == TRUE )
								{	// log
#ifndef __DROP_LOG
									((CUser*)pAttacker)->AddDefinedText(TID_GAME_REAPITEM, "\"%s\"", pItemProp->szName);
#endif // __DROP_LOG
									if( pItemProp->dwItemKind1 == IK1_WEAPON || pItemProp->dwItemKind1 == IK1_ARMOR || ( pItemProp->dwItemKind1 == IK1_GENERAL && pItemProp->dwItemKind2 == IK2_JEWELRY ) )
									{
										switch( pItemProp->nLog )
										{
											case 1:		g_dpDBClient.SendLogUniqueItem2( pAttacker, itemElem.GetProp(), itemElem.GetAbilityOption() );	break;
											case 2:		g_dpDBClient.SendLogUniqueItem2( pAttacker, itemElem.GetProp(), 200 );	break;
											case 3:		g_dpDBClient.SendLogUniqueItem2( pAttacker, itemElem.GetProp(), 100 );	break;
										}
									}
									break;
								}
							}

							CItemElem* pItemElem	= new CItemElem;
							pItemElem->m_dwItemId	= pItemProp->dwID;
							pItemElem->m_nItemNum	= 1;
							pItemElem->m_nHitPoint	= pItemProp->dwEndurance;
							pItemElem->SetAbilityOption( k );
							pItemElem->SetRandomOpt( CRandomOptItemGen::GetInstance()->GenRandomOptItem( lpMoverProp->dwLevel, (FLOAT)nProbability / 100.0f, pItemProp, lpMoverProp->dwClass ) );
							pItemElem->SetSerialNumber();
							CItem* pItem	= new CItem;
							pItem->m_pItemBase	= pItemElem;
							BOOL bJJim = TRUE;

							if( lpMoverProp->dwClass == RANK_SUPER )		// º¸½º¸÷ÀÌ µå·ÓÇÑ ¾ÆÀÌÅÛÀº ¾Æ¹«³ª ¸ÔÀ»¼ö ÀÖ´Ù.
								bJJim = FALSE;
							if( GetIndex() == MI_DEMIAN5 || GetIndex() == MI_KEAKOON5 || GetIndex() == MI_MUFFRIN5 )
								bJJim = FALSE;		// ¾êµéÀº ÀÌº¥Æ®¸÷ÀÌ¹Ç·Î Âò¾ÈÇØ³öµµ µÈ´Ù. ¾Æ¹«³ª ¸ÔÀ»¼ö ÀÖÀ½
							if( bJJim )
							{
								pItem->m_idOwn	= pAttacker->GetId();
								pItem->m_dwDropTime		= timeGetTime();
							}
							pItem->m_bDropMob	= TRUE;
					#ifdef __EVENT_MONSTER
							if( CEventMonster::GetInstance()->SetEventMonster( lpMoverProp->dwID ) )
							{
								// ÀÌº¥Æ® ¸ó½ºÅÍ´Â ¹«Á¶°Ç ¼±Á¡±ÇÀ» °®´Â´Ù.
								pItem->m_idOwn	= pAttacker->GetId();
								pItem->m_dwDropTime		= timeGetTime();

								pItem->m_IdEventMonster = lpMoverProp->dwID;
							}
					#endif // __EVENT_MONSTER
							if( pItem->m_pItemBase->m_dwItemId == 0 ) Error("DropItem: 4th %s\n", GetName() );
							pItem->SetIndex( D3DDEVICE, pItem->m_pItemBase->m_dwItemId );
							pItem->SetPos( GetPos() );
							GetWorld()->ADDOBJ( pItem, TRUE, GetLayer() );
							bDrop = TRUE;

							if( pItemProp->dwItemKind1 == IK1_WEAPON || pItemProp->dwItemKind1 == IK1_ARMOR || ( pItemProp->dwItemKind1 == IK1_GENERAL && pItemProp->dwItemKind2 == IK2_JEWELRY ) )
							{
								switch( pItemProp->nLog )
								{
								case 1:		g_dpDBClient.SendLogUniqueItem( pAttacker, pItem, pItemElem->GetAbilityOption() );	break;
								case 2:		g_dpDBClient.SendLogUniqueItem( pAttacker, pItem, 200 );	break;
								case 3:		g_dpDBClient.SendLogUniqueItem( pAttacker, pItem, 100 );	break;
								}
							}
							break;
						}
					}

					if( GetProp()->dwClass == RANK_SUPER )
					{
						if( bDrop )		// KIND¾ÆÀÌÅÛÀ» ÇÏ³ª ¶³¾îÆ®·È´Ù¸é 
							break;		// ´õÀÌ»ó ¶³¾îÆ®¸®Áö ¾Ê°í Á¾·á.
					}
				} // for( i = 0; i < nSize; i++ )
			}	// if( xRandom( 100 ) < fItemDropRate )
		}	// for( int k = 0 ; k < nloop ; k++ )
	}
	
	if( IsNPC() )	// ¸÷ÀÌ Á×¾úÀ»¶§..
	{
		MoverProp* pMoverProp	= GetProp();
		if( pMoverProp->m_nLoot == 2 )	// 2¾Æ d¿É¼Ç.  ¾ÆÀÌÅÛ ¸Ô°í ¹ñ±â±îÁö ÇÏ´Â ¿É¼Ç.
		{
			int nSize = m_Inventory.GetSize();
			int i;
			CItemElem *pElem = NULL;
			for( i = 0; i < nSize; i ++ )
			{
				pElem = m_Inventory.GetAt( i );
				if( pElem )
				{
					D3DXVECTOR3 vPos = GetPos();
				#ifdef __WORLDSERVER
					vPos.x += ( xRandomF(2.0f) - 1.0f );
					vPos.z += ( xRandomF(2.0f) - 1.0f );
				#endif
					CItem *pItem = DropItem( i, pElem->m_nItemNum, vPos, FALSE );
					pItem->m_idOwn	= pAttacker->GetId();
					pItem->m_dwDropTime		= timeGetTime();
				}
			}
		}
	}

#endif	// __WORLDSERVER

	return TRUE;
}

// this¿ÀºêÁ§Æ®¿¡´Ù ÂòÇÑ»ç¶÷(JJimer -_-;;;) ÀÇ ¾ÆÀÌµð¸¦ ¹Ú¾ÆµÖ¼­ 
// this°¡ Âò´çÇß´Ù´Â°É Ç¥½Ã.
void CMover::SetJJim( CMover *pJJimer )
{
	if( ::GetLanguage() == LANG_THA )	// ÅÂ±¹ÀÇ °æ¿ì
		if( GetIndex() == MI_MRPUMPKIN5 )	// ±«¼ö ¹Ì½ºÅÍÆßÅ²Àº
			return;													// ½ºÆ¿ÀÌ Çã¿ëµÊ.

	if( GetProp()->dwClass == RANK_SUPER )		// ½´ÆÛ¸÷Àº ½ºÆ¿ Çã¿ë.
		return;

#ifdef __EVENT_MONSTER
	// ÀÌº¥Æ® ¸ó½ºÅÍ´Â ½ºÆ¿ Çã¿ë
	if( CEventMonster::GetInstance()->IsEventMonster( GetProp()->dwID ) )
		return;
#endif // __EVENT_MONSTER
		
	// ÂòÇÑ³ÑÀº »ç¶÷ / Âò´çÇÑ³ÑÀº NPCÀÏ¶§¸¸.
	if( pJJimer->IsPlayer() && IsNPC() ) //this != pJJimer )		// ÂòÇÑ»ç¶÷ÀÌ »ç¶÷ÀÏ°æ¿ì¸¸ Àû¿ë./ ÀÚ±âÀÚ½ÅÀ» ÂòÇÒ¼ø ¾ø´Ù.
	{
		m_idTargeter = pJJimer->GetId();
	}
}


CGuild* CMover::GetGuild()
{
#ifdef __WORLDSERVER
//	locked
	CGuild* pGuild	= g_GuildMng.GetGuild( m_idGuild );
	if( pGuild && pGuild->IsMember( m_idPlayer ) )
		return pGuild;
	return NULL;
#else	// __WORLDSERVER
#ifdef __CLIENT
	if( m_idGuild > 0 && CMover::GetActiveMover() &&
		 m_idGuild == CMover::GetActiveMover()->m_idGuild )
	{
		CGuild* pGuild	= g_GuildMng.GetGuild( m_idGuild );
		if( pGuild && pGuild->IsMember( m_idPlayer ) )
			return pGuild;
		return NULL;
	}
	else
	{
		return g_GuildMng.GetGuild( m_idGuild );
	}
#endif	// __CLIENT
#endif	// __WORLDSERVER
}

CGuildWar* CMover::GetWar()
{
	return g_GuildWarMng.GetWar(m_idWar);
}

#ifdef  __WORLDSERVER
// HP, MP, FPÈ¸º¹À» Ã³¸®ÇÑ´Ù.
void CMover::ProcessRecovery()
{
	if( IsPlayer() == FALSE || IsDie() )
		return;

#ifdef __NEWCLASS
	if (HasBuff(BUFF_SKILL, SI_WINDL_U_SKILL_04))
		return;
#endif // __NEWCLASS

	DWORD dwCurTick = g_tmCurrent;

#if __VER < 8 // __S8_PK
	// ÀÏÁ¤½Ã°£¸¶´Ù Ä«¸£¸¶ È¸º¹ 
	KarmaProp* pProp = prj.GetKarmaProp( m_nSlaughter );
	if( pProp->dwKarmaRecoverPoint )
	{
		if( m_dwKarmaTick == 0 )
		{
			m_dwKarmaTick = dwCurTick + pProp->dwKarmaRecoverPoint * 1000;
		}
		else if( dwCurTick > m_dwKarmaTick )
		{
			m_dwKarmaTick = 0; 
			ChangeSlaughter( CHANGE_SLAUGHTER_RECOVERY, NULL );
		}
	}
#endif // __VER < 8 // __S8_PK

	if( dwCurTick > m_dwTickDuel )	// µÎ¾ó ½ÃÀÛÈÄ 1ÃÊ¿¡ 3, 2, 1, Fight
	{
		if( 100 <= m_nDuelState && m_nDuelState < 200 )		// 100 ~ 200 Àº µà¾ó ½ÃÀÛÈÄ ½ÃÀÛ Å¸ÀÓ
		{
			--m_nDuelState;
			if( 100 == m_nDuelState )	// ¸¶Áö¸· Fight ¸Þ¼¼Áö¸¦ º¸³¿
			{
				m_nDuelState = 1;		// µà¾ó ÁßÀÌ¶ó°í ¼¼ÆÃ
				if( m_nDuel == 1 )
				{
					CMover *pDuelOther = prj.GetMover( m_idDuelOther );
					if( pDuelOther )
					{
						((CUser*)this)->AddDuelStart( pDuelOther->m_idPlayer, 1 );	// Fight
						((CUser*)this)->AddDuelCount( 0 );
					}
				}
				else if( m_nDuel == 2 )
				{
					CParty* pParty = g_PartyMng.GetParty( m_idDuelParty );		// ½ÅÃ»ÀÚÀÇ ÆÄÆ¼²¨³¿
					if( pParty )
					{
						LPCSTR pszPartyName;
						if( pParty->m_nKindTroup ) // ¼øÈ¸±Ø´Ü
							pszPartyName = pParty->m_sParty;
						else // ´Ü¸·±Ø´Ü
#if __VER >= 11 // __SYS_PLAYER_DATA
							pszPartyName = CPlayerDataCenter::GetInstance()->GetPlayerString( pParty->GetPlayerId( 0 ) );
#else	// __SYS_PLAYER_DATA
							pszPartyName = prj.GetPlayerString( pParty->GetPlayerId( 0 ) );
#endif	// __SYS_PLAYER_DATA

						if( !pszPartyName )
						{
							Error( "Error Party PVP 2" );
						}
						else
						{
							int		j;
							OBJID	pDstMember[ MAX_PTMEMBER_SIZE ];
							memset( pDstMember, 0xff, sizeof(pDstMember) );
							CMover *pMember2;

							for( j = 0; j < pParty->m_nSizeofMember; j ++ )
							{
								pMember2 = (CMover *)g_UserMng.GetUserByPlayerID( pParty->m_aMember[j].m_uPlayerId );
								if( IsValidObj(pMember2) )
									pDstMember[j] = pMember2->GetId();
							}
							// »ó´ë ÆÄÆ¼¿¡ ´ëÇÑ Á¤º¸¸¦ ¿ì¸®¸â¹öµé¿¡°Ô º¸³¿
							((CUser *)this)->AddDuelPartyStart( pszPartyName, pParty->m_nSizeofMember, pDstMember, pParty->m_uPartyId, 1 );		// »ó´ë¹æ ¸â¹öÀÇ ID¸¦ ´Ùº¸³½´Ù. 2°ªÀ¸·Î
							((CUser*)this)->AddDuelCount( 0 );
						}
					}
				}
			}
			else
			{
				((CUser*)this)->AddDuelCount( m_nDuelState - 100 );
			}
		}
		m_dwTickDuel = dwCurTick + NEXT_TICK_DUEL;		
	}

	if( m_nDuel != 0 && dwCurTick > m_dwTickEndDuel )
	{
		// µà¾óÃë¼Ò 3ºÐµ¿¾È ±³ÀüÀÌ ¾ø¾úÀ½
		if( m_nDuel == 1 )
		{
			CMover *pDuelOther = prj.GetMover( m_idDuelOther );
			if( pDuelOther )
			{
				pDuelOther->ClearDuel();
				( (CUser*)pDuelOther )->AddSetDuel( pDuelOther );
				ClearDuel();
				( (CUser*)this )->AddSetDuel( this );
			}
		}
		else if( m_nDuel == 2 )
		{
			CParty* pParty = g_PartyMng.GetParty( m_idparty );
			if( pParty && pParty->IsLeader( m_idPlayer ) )
			{
				u_long uidDuelParty = m_idDuelParty;
				CMover *pMember;
				CParty* pParty2 = g_PartyMng.GetParty( uidDuelParty );
				for( int k = 0 ; k < pParty->m_nSizeofMember ; ++k )
				{
					pMember	= (CMover *)g_UserMng.GetUserByPlayerID( pParty->m_aMember[k].m_uPlayerId );					
					if( IsValidObj( pMember ) )
					{
						if( pParty2 )
						{
							pParty2->DoDuelPartyCancel( pParty );
						}
						else 
						{
							pParty->DoDuelPartyCancel( NULL );
							Error( "CMover::ProcessRecovery : ÆÄÆ¼¸â¹ö %sÀÇ Á¤º¸ÀÌ»ó. %d %d", pMember->GetName(), pMember->m_idDuelParty, uidDuelParty );
						}
					}
				}
				if( pParty2 )
				{
					for( int k = 0 ; k < pParty2->m_nSizeofMember ; ++k )
					{
						pMember	= (CMover *)g_UserMng.GetUserByPlayerID( pParty2->m_aMember[k].m_uPlayerId );					
						if( IsValidObj( pMember ) )
						{	
							pParty->DoDuelPartyCancel( pParty2 );
						}
					}
				}
				g_DPCoreClient.SendSetPartyDuel( m_idparty, uidDuelParty, FALSE );
			}
		}
	}
	
	if( m_pActMover->IsSit() )		
	{
		// ¾É¾ÆÀÖÀ» ¶§
		float fRecovery = 1.0f;
		if( dwCurTick <= m_dwTickRecovery )	
			return;
		m_dwTickRecovery = dwCurTick + NEXT_TICK_RECOVERY;
		
		// ÆÄÆ¼ PARTY_STRETCHING_MODEÀÏ ¶§ 
		CParty* pParty = g_PartyMng.GetParty( m_idparty );
		if( pParty && pParty->IsMember( m_idPlayer ) )
		{
			if( pParty->m_nKindTroup == 1 && pParty->m_nModeTime[PARTY_STRETCHING_MODE] )
			{
#if __VER >= 12 // __PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
				BOOL nMItem = FALSE;
				CUser* pLeader = g_UserMng.GetUserByPlayerID( pParty->m_aMember[0].m_uPlayerId );
				if( pParty->m_nModeTime[PARTY_PARSKILL_MODE] )
				{
					nMItem = TRUE;
				}
				else
				{
					if( IsValidObj( (CObj*)pLeader ) )
					{
						if( IsValidArea( pLeader, 255.0f ) )
							nMItem = TRUE;
					}				
				}
				if( nMItem )
				{
					if( IsValidObj( pLeader ) && ( pLeader->GetJob() == JOB_ASSIST || pLeader->GetJob() == JOB_RINGMASTER || pLeader->GetJob() == JOB_BILLPOSTER || pLeader->GetJob() == JOB_BILLPOSTER_MASTER || pLeader->GetJob() == JOB_BILLPOSTER_HERO || pLeader->GetJob() == JOB_RINGMASTER_MASTER || pLeader->GetJob() == JOB_RINGMASTER_HERO || pLeader->GetJob() == JOB_FLORIST_HERO || pLeader->GetJob() == JOB_FORCEMASTER_HERO ))
						fRecovery = 1.8f;
					else
						fRecovery = 1.5f;
				}
#else	//__PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
				CUser* pLeader = g_UserMng.GetUserByPlayerID( pParty->m_aMember[0].m_uPlayerId );
				if( IsValidObj( (CObj*)pLeader ) )
				{
					BOOL nMItem = FALSE;
					if( pLeader->IsSMMode( SM_PARTYSKILL1 ) || pLeader->IsSMMode( SM_PARTYSKILL15 ) || pLeader->IsSMMode( SM_PARTYSKILL30 ) )	// ¿©±â¼­ À¯·á ¾ÆÀÌÅÛ »ç¿ëÁßÀÎÁö È®ÀÎ
					{
						nMItem = TRUE;
					}
					else
					{
						if( IsValidArea( pLeader, 255.0f ) )
						{
							nMItem = TRUE;
						}
					}				

					if( nMItem )
					{
						if( pLeader->GetJob() == JOB_ASSIST || pLeader->GetJob() == JOB_RINGMASTER || pLeader->GetJob() == JOB_BILLPOSTER || pLeader->GetJob() == JOB_BILLPOSTER_MASTER || pLeader->GetJob() == JOB_BILLPOSTER_HERO || pLeader->GetJob() == JOB_RINGMASTER_MASTER || pLeader->GetJob() == JOB_RINGMASTER_HERO || pLeader->GetJob() == JOB_FLORIST_HERO || pLeader->GetJob() == JOB_FORCEMASTER_HERO )
							fRecovery = 1.8f;
						else
							fRecovery = 1.5f;
					}
				}
#endif //__PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
			}
		}
		else
		{
			m_idparty	= 0;
		}
#ifdef __HEAL_SHOW
#ifdef __NO_HP_DMG_LIMIT
		IncHitPoint(GetHPRecovery()* fRecovery, (GetHitPoint() < GetMaxHitPoint()));
#else
		IncHitPoint((int)(GetHPRecovery()* fRecovery), (GetHitPoint() < GetMaxHitPoint()));
#endif
#else // __HEAL_SHOW
		IncHitPoint((int)(GetHPRecovery()* fRecovery));
#endif // __HEAL_SHOW
		IncManaPoint( (int)( GetMPRecovery() * fRecovery ) );
		IncFatiguePoint( (int)( GetFPRecovery() * fRecovery ) );
	} 
	else	
	{
		// ¼­ÀÖÀ» ¶§
		m_dwTickRecovery = dwCurTick + NEXT_TICK_RECOVERY; // ¾É¾ÆÀÖ±â È¸º¹À» ¸·´Â´Ù.
		//if( m_pActMover->IsActAttack() == FALSE )	
		if( IsAttackMode() == FALSE )	// IsActAttackÀº °ø°Ýµ¿ÀÛÀÏ ¶§¸¸, IsAttackMode´Â ÀüÅõÁß
		{
			// ¾îÅÃ»óÅÂ°¡ ¾Æ´Ò¶§¸¸ ÀÏÁ¤½Ã°£¸¶´Ù ÇÇÂù´Ù.
			if( dwCurTick > m_dwTickRecoveryStand )	
			{
				m_dwTickRecoveryStand = dwCurTick + NEXT_TICK_RECOVERYSTAND;
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
				if( ! (GetAdjParam( DST_CHRSTATE ) & CHS_SETSTONE) )
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
				{
					IncHitPoint( GetHPRecovery() );
					IncManaPoint( GetMPRecovery() );
					IncFatiguePoint( GetFPRecovery() );
				}
			}
		} 
		else
		{
			// ¾îÅÃ »óÅÂÀÏ ¶§´Â °è¼Ó ½Ã°£À» ¸®¼ÂÇÑ´Ù.
			m_dwTickRecoveryStand = dwCurTick + NEXT_TICK_RECOVERYSTAND;	
		}
	}
}
#endif // __WORLDSERVER

void CMover::AllocShopInventory( LPCHARACTER pCharacter )
{
	if( IsVendorNPC() )
	{
		m_ShopInventory[ 0 ] = new CItemContainer< CItemElem  >; m_ShopInventory[ 0 ]->SetItemContainer( ITYPE_ITEM, MAX_VENDOR_INVENTORY );
		m_ShopInventory[ 1 ] = new CItemContainer< CItemElem  >; m_ShopInventory[ 1 ]->SetItemContainer( ITYPE_ITEM, MAX_VENDOR_INVENTORY );
		m_ShopInventory[ 2 ] = new CItemContainer< CItemElem  >; m_ShopInventory[ 2 ]->SetItemContainer( ITYPE_ITEM, MAX_VENDOR_INVENTORY );
		m_ShopInventory[ 3 ] = new CItemContainer< CItemElem  >; m_ShopInventory[ 3 ]->SetItemContainer( ITYPE_ITEM, MAX_VENDOR_INVENTORY );
	}
}

BOOL CMover::IsVendorNPC()
{
	LPCHARACTER pCharacter	= GetCharacter();
	if( !pCharacter )
		return FALSE;
	for( int i = 0; i < MAX_VENDOR_INVENTORY_TAB; i++ )
	{
		if( pCharacter->m_venderItemAry[i].GetSize() )
			return TRUE;
	}
#if __VER >= 11 // __CSC_VER11_3
#ifdef __VENDOR_UPDATE
	if (pCharacter->m_nVenderType != 0)
	{
#else // __VENDOR_UPDATE
	if (pCharacter->m_nVenderType == 1)
#endif // __VENDOR_UPDATE
		for (int i = 0; i < MAX_VENDOR_INVENTORY_TAB; i++)
		{
			if (pCharacter->m_venderItemAry2[i].GetSize())
				return TRUE;
		}
#ifdef __VENDOR_UPDATE
}
#endif // __VENDOR_UPDATE
#endif //__CSC_VER11_3
#ifdef __ADDSHOPITEM
	for (int i = 0; i < MAX_VENDOR_INVENTORY_TAB; i++)
	{
		if (pCharacter->m_venderItemAry3[i].GetSize())
			return TRUE;
	}
#endif // __ADDSHOPITEM
	return FALSE;
}

#ifdef __CLIENT	
BOOL CMover::EndMotion()
{
	if( !m_pActMover->IsActAttack() &&
		!m_pActMover->IsActDamage() &&
		!m_pActMover->IsActJump() && 
		!m_pActMover->IsFly() && 
		!m_pActMover->IsDie() && 
		!m_pActMover->IsSit() )
	{
		SetAngle( GetDegree(GetWorld()->GetCamera()->m_vPos, GetPos()) );		// ¸ñÇ¥ÂÊÀ¸·Î ¸öÀ» µ¹¸².
		SetMotion( MTI_LOGOUT, ANILOOP_CONT, MOP_FIXED );
		return TRUE;
	}
	return FALSE;
}
#endif //__CLIENT

BOOL CMover::IsBullet( ItemProp* pItemProp )
{
	// ÇÊ¿äÃÑ¾ËÁ¾·ù°¡ ÁöÁ¤µÇ¾î ÀÖ´Ù¸é
	if( pItemProp->dwLinkKindBullet != NULL_ID )
	{
		DWORD dwTip = TID_TIP_NEEDSKILLITEM;
#ifdef __CROSSBOW
		if( pItemProp->dwItemKind3 == IK3_BOW || pItemProp->dwLinkKind == IK3_BOW || pItemProp->dwItemKind3 == IK3_CROSSBOW || pItemProp->dwLinkKind == IK3_CROSSBOW )
#else // __CROSSBOW
		if( pItemProp->dwItemKind3 == IK3_BOW || pItemProp->dwLinkKind == IK3_BOW )
#endif // __CROSSBOW
		{
			dwTip = TID_TIP_NEEDSATTACKITEM;			
		}
		
		ItemProp *pProp = GetActiveHandItemProp( PARTS_BULLET );
		if( pProp )
		{
			if( pProp->dwItemKind2 != pItemProp->dwLinkKindBullet )		// ÇÊ¿äÃÑ¾ËÁ¾·ù¶û ´Ù¸¥°É ÀåÂøÇÏ°í ÀÖÀ¸¸é ¿¡·¯
			{
#ifdef __CLIENT
				g_WndMng.PutString( prj.GetText( dwTip ), NULL, prj.GetTextColor( dwTip ) );
				( (CWndWorld *)g_WndMng.m_pWndWorld )->m_bAutoAttack	= FALSE;
#endif // __CLIENT
#ifdef __WORLDSERVER
				((CUser*)this)->AddDefinedText( dwTip, "" );
#endif // __WORLDSERVER
				return FALSE;
			}
		} else
		{	// ÃÑ¾Ë(?)ÀÌ ¾ø¾îµµ ¿¡·¯
#ifdef __CLIENT
			g_WndMng.PutString( prj.GetText( dwTip ), NULL, prj.GetTextColor( dwTip ) );
#endif // __CLIENT
#ifdef __WORLDSERVER
			((CUser*)this)->AddDefinedText( dwTip, "" );
#endif // __WORLDSERVER
			return FALSE;
		}
	}
	return TRUE;
}

#ifdef __WORLDSERVER
// È­»ìÀ» nCount´ë·Î »èÁ¦
// È­»ìÀ» ÀåÂøµÇ¾î ÀÖ´Â°ÍÀ» ¼Ò¸ðÇßÀ»½Ã ÀÚµ¿À¸·Î °°Àº È­»ìÀ» ÀåÂø
// °°Àº È­»ìÀÎÁö Ã¼Å©
void CMover::ArrowDown( int nCount )
{
	if( IsNPC() )	return;
	CItemElem* pItemElem = m_Inventory.GetEquip( PARTS_BULLET );	// ÀåÂøµÇ¾î ÀÖ´Â È­»ì ¾ÆÀÌÅÛ ²¨³¿
	if( pItemElem )
	{
		// ÀåÂøµÇ¾î ÀÖ´Â°Í ¸ðµÎ ¼ÒÁø µÇ¾úÀ½. ÀåÂøµÇ¾î ÀÖ´Â ¾ÆÀÌÅÛ »èÁ¦ÈÄ
		// ÀÎº¥Åä¸®¿¡¼­ °°Àº È­»ìÀÌ ÀÖÀ¸¸é ±×°ÍÀ» »ç¿ëÇÏ°Ô ÇØÁÜ
		DWORD dwItemId = pItemElem->m_dwItemId;
		BOOL bDoEquip = FALSE;
#ifdef __CLASS_RELIC
		if (dwItemId == II_WEA_UNLIMITED_ARROW || dwItemId == II_WEA_UNLIMITED_ARROW2)
			return;

		if (dwItemId == II_WEA_UNLIMITED_BIL_CHARM
			|| dwItemId == II_WEA_UNLIMITED_RIN_CHARM
			|| dwItemId == II_WEA_UNLIMITED_BIL_CHARM2
			|| dwItemId == II_WEA_UNLIMITED_RIN_CHARM2)
		{
			return;
		}
#endif // __CLASS_RELIC
		for( int i = 0 ; i < 100 && 0 < nCount ; i++ )	// È¤ 100¹øÀº ¾È³ª¿À°ÚÁö?
		{	// ¾ÆÀÌÅÛ »ç¿ëÀÌ 4°³ÀÎµ¥ ¾ÆÀÌÅÛ 1°³Â¥¸®°¡ 4°³ÀÏ¶§ ·çÇÁ°¡ µ¹À½
			BOOL bGetItem = FALSE;
			if( pItemElem->m_nItemNum <= nCount )
			{
				nCount -= pItemElem->m_nItemNum;
				pItemElem->m_nItemNum = 0;
				bGetItem = TRUE;
			}
			else
			{
				pItemElem->m_nItemNum -= nCount;
				nCount = 0;
			}
			UpdateItem( (BYTE)( pItemElem->m_dwObjId ), UI_NUM, pItemElem->m_nItemNum );
			if( bGetItem )
			{
				bDoEquip = FALSE;
				pItemElem = m_Inventory.GetAtItemId( dwItemId );
				if( pItemElem == NULL ) 
				{
					break;
				}
				bDoEquip = TRUE;
			}
		}
		
		if( bDoEquip ) 
		{
			if( TRUE == DoEquip( pItemElem, TRUE, pItemElem->GetProp()->dwParts ) )
			{
				g_UserMng.AddDoEquip( this, pItemElem->GetProp()->dwParts, pItemElem, TRUE );
			}
		}
	}
}
#endif // __WORLDSERVER


void CMover::ClearDuel()
{
	m_nDuel		= 0;
	m_idDuelOther	= NULL_ID;
	m_nDuelState	= 0;
	m_dwTickEndDuel = ::timeGetTime() + NEXT_TICK_ENDDUEL; // 3 min
	SetPKTargetLimit( 10 );								   // PK¼±°øÀ» ¸øÇÏ°Ô ¸·°ÔÇÔ	
}

void CMover::ClearDuelParty()
{
	m_nDuel		= 0;
	m_idDuelParty	= 0;
	m_nDuelState	= 0;
	m_dwTickEndDuel = ::timeGetTime() + NEXT_TICK_ENDDUEL;	// 3 min
	SetPKTargetLimit( 10 );									// PK¼±°øÀ» ¸øÇÏ°Ô ¸·°ÔÇÔ
}

void CMover::SetPKTargetLimit( int nSec )
{
#if defined( __WORLDSERVER ) 
	m_dwPKTargetLimit = GetTickCount() + SEC( nSec );
#endif // defined( __WORLDSERVER )
}

#if defined(__WORLDSERVER)
BOOL CMover::IsItemRedyTime( ItemProp* pItemProp, OBJID dwObjid, BOOL bItemFind )
{
	if( pItemProp->dwSkillReadyType != 0 &&
		pItemProp->dwSkillReadyType != 0xffffffff )
	{
#if __VER >= 15 // __IMPROVE_SYSTEM_VER15
		if( pItemProp->dwItemKind2 == IK2_RIDING )
		{
#ifdef __AUTO_REMOVE_PET
			if (HasActivatedEatPet())
			{
				InactivateEatPet();
			}
			if (HasActivatedSystemPet())
			{
				PetRelease();
			}
			if (HasPet())
			{
				RemovePet();
			}
#else
			if (HasActivatedEatPet() || HasActivatedSystemPet() || HasPet())
			{
				((CUser*)this)->AddDefinedText(TID_GAME_CANNOT_FLY_WITH_PET);
				return FALSE;
			}
#endif
		}
#endif // __IMPROVE_SYSTEM_VER15
		// ¶óÀÌµå¸¦ ÀåÂøÀ» ÇÏ·Á¸é ÇÁ·ÎÆÛÆ¼¿¡ ÀÖ´Â°ªÀ» ÂüÁ¶ÇÏ¿© ½ÃÀüÀ» ÇØ¾ßÇÔ
		if( IsStateMode( STATE_BASEMOTION_MODE ) ) 
		{
			if( m_nReadyTime != 0 )	// ½ÃÀüÁß
			{
				( (CUser*)this )->AddDefinedText(TID_PK_BLINK_LIMIT, "" );	// ½ÃÀüÁß¿¡´Â »ç¿ëÇÒ¼ö ¾ø½À´Ï´Ù
				return FALSE;
			}
			else	// ½ÃÀüÀÌ ¿Ï·áµÈ ½ÃÁ¡
			{
				SetStateNotMode( STATE_BASEMOTION_MODE, STATEMODE_BASEMOTION_OFF );
			}
		}
		else	// ½ÃÀü ™VÆÃ
		{
#if __VER >= 9 // __S_9_ADD
			if( pItemProp->dwItemKind2 == IK2_BLINKWING && m_pActMover->IsSit() )
			{
				( (CUser*)this )->AddDefinedText(TID_GAME_NOTSIT_BLINK, "" );	
				return FALSE;
			}
#endif // __S_9_ADD
			m_nReadyTime = timeGetTime() + pItemProp->dwSkillReadyType;
			m_dwUseItemId = dwObjid;
			m_bItemFind = bItemFind;
			SetStateMode( STATE_BASEMOTION_MODE, STATEMODE_BASEMOTION_ON );
			return FALSE;
		}
	}
	return TRUE;
}
#endif // __WORLDSERVER

#ifdef __CLIENT
CSfx* CMover::CreateSfxArrow( DWORD dwSfxObjArrow, DWORD dwSfxObjHit, D3DXVECTOR3 vPosDest, int idTarget  )
{
	CSfx* pSfx = NULL;

	// È­»ìÀº ¿Þ¼Õ¿¡ ¿¬°á...
	D3DXVECTOR3 vPos;
	CModelObject *pModel = (CModelObject *)m_pModel;
	pModel->GetHandPos( &vPos, PARTS_LWEAPON, GetMatrixWorld() );		// ÁÖ¸Ô ¿ùµåÁÂÇ¥ ±¸ÇÔ	
	
	pSfx = CreateSfx( D3DDEVICE, dwSfxObjArrow, vPos, GetId(), vPosDest , idTarget );
	
	if( dwSfxObjHit != NULL_ID )
	{
		if( pSfx ) 
		{
			((CSfxShoot*)pSfx)->m_dwSfxHit = dwSfxObjHit;
		}
	}
	
	return pSfx;
	
}
#endif
BOOL CMover::IsAfterDeath()	
{	
	if( m_nDeathLevel > m_nLevel )
		return TRUE;

	if( m_nDeathLevel == m_nLevel )
	{
#if __VER >= 8  
		if( m_nExp1 == 0 )
			return TRUE;
#endif //  __VER >= 8  
		if( m_nDeathExp > m_nExp1 )
			return TRUE;
	}
	return FALSE;
}

int CMover::GetSetItem( CItemElem* pItemElem )
{
	static	DWORD adwParts[4]	= { PARTS_UPPER_BODY, PARTS_HAND, PARTS_FOOT, PARTS_CAP	};
	if( !pItemElem )
	{
		pItemElem	= GetEquipItem( PARTS_UPPER_BODY );
	}
	else
	{
		if( !IsSetItemPart( pItemElem->GetProp()->dwParts ) )
			return 0;
	}

	if( !pItemElem )
		return 0;

	if( pItemElem->IsFlag( CItemElem::expired ) )
		return 0;

	int nAbilityOption	= pItemElem->GetAbilityOption();
	DWORD dwParts	= pItemElem->GetProp()->dwParts;

	for( int i = 0; i < 4; i++ )
	{
		if( dwParts != adwParts[i] )
		{
			pItemElem	= GetEquipItem( adwParts[i] );
			if( pItemElem && !pItemElem->IsFlag( CItemElem::expired ) )
			{
				if( nAbilityOption > pItemElem->GetAbilityOption() )
					nAbilityOption	= pItemElem->GetAbilityOption();
				continue;
			}
			return 0;
		}
	}
	return nAbilityOption;
}

int CMover::GetSetItemParts(DWORD dwParts)
{
	CItemElem* pItemElem = NULL;
	ItemProp * pItemProp = NULL;
	
	pItemElem = GetEquipItem( dwParts );
	
	int nAbilityOption = 0;
	
	if( pItemElem )
	{
		nAbilityOption = pItemElem->GetAbilityOption();
	} else
	{
		if( IsActiveMover() )
			return 0;
		nAbilityOption	= (m_aEquipInfo[dwParts].nOption & 0xFF );
	}

	return nAbilityOption;
}
		
int CMover::GetSetItemClient()
{
	static	DWORD adwParts[4]	= { PARTS_UPPER_BODY, PARTS_HAND, PARTS_FOOT, PARTS_CAP	};

	int nAbilityOption	= 10;
	
	for( int i = 0; i < 4; i++ )
	{
		int nValue	= GetSetItemParts( adwParts[i] );
		if( nValue == 0 )
			return 0;
		if( nAbilityOption > nValue )
			nAbilityOption	= nValue;
	}

	return nAbilityOption;
}

BOOL CMover::IsSetItemPart( DWORD dwParts )
{
	switch( dwParts )
	{
		case PARTS_UPPER_BODY:
		case PARTS_HAND:
		case PARTS_FOOT:
		case PARTS_CAP:
			return TRUE;
	}
	return FALSE;
}

void CMover::SetSetItemAvail( int nAbilityOption )
{
	PSETITEMAVAIL pSetItemAvail		= prj.GetSetItemAvail( nAbilityOption );
	if( pSetItemAvail )
	{
//		OutputDebugString( "SetSetItemAvail" );
		if( pSetItemAvail->nHitRate != 0 )
			SetDestParam( DST_ADJ_HITRATE, pSetItemAvail->nHitRate, NULL_CHGPARAM );
		if( pSetItemAvail->nBlock != 0 )
		{
			SetDestParam( DST_BLOCK_RANGE, pSetItemAvail->nBlock, NULL_CHGPARAM );
			SetDestParam( DST_BLOCK_MELEE, pSetItemAvail->nBlock, NULL_CHGPARAM );
		}
		if( pSetItemAvail->nMaxHitPointRate != 0 )
			SetDestParam( DST_HP_MAX_RATE, pSetItemAvail->nMaxHitPointRate, NULL_CHGPARAM );
		if( pSetItemAvail->nAddMagic != 0 )
			SetDestParam( DST_ADDMAGIC, pSetItemAvail->nAddMagic, NULL_CHGPARAM );
		if( pSetItemAvail->nAdded != 0 )
		{
			SetDestParam( DST_STR, pSetItemAvail->nAdded, NULL_CHGPARAM );
			SetDestParam( DST_DEX, pSetItemAvail->nAdded, NULL_CHGPARAM );
			SetDestParam( DST_INT, pSetItemAvail->nAdded, NULL_CHGPARAM );
			SetDestParam( DST_STA, pSetItemAvail->nAdded, NULL_CHGPARAM );
		}
	}
}

void CMover::ResetSetItemAvail( int nAbilityOption )
{
	PSETITEMAVAIL pSetItemAvail		= prj.GetSetItemAvail( nAbilityOption );
	if( pSetItemAvail )
	{
//		OutputDebugString( "ResetSetItemAvail" );
		if( pSetItemAvail->nHitRate != 0 )
			ResetDestParam( DST_ADJ_HITRATE, pSetItemAvail->nHitRate, TRUE );
		if( pSetItemAvail->nBlock != 0 )
		{
			ResetDestParam( DST_BLOCK_RANGE, pSetItemAvail->nBlock, TRUE );
			ResetDestParam( DST_BLOCK_MELEE, pSetItemAvail->nBlock, TRUE );
		}
		if( pSetItemAvail->nMaxHitPointRate != 0 )
			ResetDestParam( DST_HP_MAX_RATE, pSetItemAvail->nMaxHitPointRate, TRUE );
		if( pSetItemAvail->nAddMagic != 0 )
			ResetDestParam( DST_ADDMAGIC, pSetItemAvail->nAddMagic, TRUE );
		if( pSetItemAvail->nAdded != 0 )
		{
			ResetDestParam( DST_STR, pSetItemAvail->nAdded, TRUE );
			ResetDestParam( DST_DEX, pSetItemAvail->nAdded, TRUE );
			ResetDestParam( DST_INT, pSetItemAvail->nAdded, TRUE );
			ResetDestParam( DST_STA, pSetItemAvail->nAdded, TRUE );
		}
	}
}

void CMover::DestParamPiercingAvail( CItemElem* pItemElem, BOOL bSET )
{
#if __VER >= 12 // __EXT_PIERCING
	if( !pItemElem->IsPierceAble() )
#else // __EXT_PIERCING
	if( pItemElem->GetProp()->dwItemKind3 != IK3_SUIT )
#endif // __EXT_PIERCING
		return;
	
	PIERCINGAVAIL piercingAvail;
	memset( &piercingAvail, 0, sizeof(piercingAvail) );
	
	pItemElem->GetPiercingAvail( &piercingAvail );
	
	for( int i = 0; i < piercingAvail.nSize; i++ )
	{
		if( bSET )
			SetDestParam( piercingAvail.anDstParam[i], piercingAvail.anAdjParam[i], NULL_CHGPARAM );
		else
			ResetDestParam( piercingAvail.anDstParam[i], piercingAvail.anAdjParam[i], TRUE );
	}
}

BOOL CMover::Pierce( CItemElem *pSuit, DWORD dwItemId )
{
	for( int i = 0; i < pSuit->GetPiercingSize(); i++ )
	{
		if( pSuit->GetPiercingItem( i ) == 0 )
		{
			//pSuit->SetPiercingItem( i, dwItemId ); - Áßº¹ ½ÇÇà
			UpdateItem( (BYTE)( pSuit->m_dwObjId ), UI_PIERCING, MAKELONG( i, dwItemId ) );
			return TRUE;
		}

	}
	return FALSE;
}

#ifdef __WORLDSERVER
void CMover::CheckTickCheer()
{
	if( m_nCheerPoint >= MAX_CHEERPOINT )
		return;

	DWORD dwTickCount	= GetTickCount();
	if( dwTickCount > m_dwTickCheer )
		SetCheerParam( m_nCheerPoint + 1, dwTickCount, TICK_CHEERPOINT );
}
#endif	// __WORLDSERVER

void CMover::SetCheerParam( int nCheerPoint, DWORD dwTickCount, DWORD dwRest )
{
#ifdef __WORLDSERVER	// chipi_080411
	BOOL bAdd = FALSE;
	if( m_nCheerPoint < nCheerPoint )
		bAdd = TRUE;
#endif // __WORLDSERVER
	m_nCheerPoint	= nCheerPoint;
	m_dwTickCheer	= dwTickCount + dwRest;
#ifdef __WORLDSERVER
	( (CUser*)this )->AddSetCheerParam( nCheerPoint, dwRest, /* chipi_080411 */ bAdd );
#endif	// __WORLDSERVER
}


BOOL CMover::NoDisguise( LPDIRECT3DDEVICE9 pd3dDevice )     
{ 
#ifdef __CLIENT
	// ÀÌ¹Ì »ç¶÷ ¸ð¾çÀÌ¹Ç·Î ÇØÁ¦ Ã³¸® ÇÒ ÇÊ¿ä ¾øÀ½. 
	if( GetIndex() == MI_MALE || GetIndex() == MI_FEMALE )
		return FALSE;
	// ±âÁ¸ ¸ðµ¨ ÆÄ±« 
	DWORD dwIndex = (GetSex() == SEX_MALE ? MI_MALE : MI_FEMALE);
	SetIndex( pd3dDevice, dwIndex, FALSE, FALSE );
#endif  //__CLIENT
	return TRUE;
}
BOOL CMover::Disguise( LPDIRECT3DDEVICE9 pd3dDevice, DWORD dwMoverIndex )
{
#ifdef __CLIENT
	return SetIndex( pd3dDevice, dwMoverIndex );
#endif // __CLIENT
	return TRUE;
}
BOOL CMover::SetIndex( LPDIRECT3DDEVICE9 pd3dDevice, DWORD dwMoverIndex, BOOL bInitProp, BOOL bDestParam )
{ 
	MoverProp* pMoverProp = prj.GetMoverProp( dwMoverIndex );
	if( pMoverProp == NULL )
	{
		Error( "CMover.SetIndex: property not found: %d", dwMoverIndex );
		return FALSE;
	}
	// ±âÁ¸ ¸ðµ¨ ÆÄ±« 
	if( m_pModel && m_pModel->IsAniable() )
		SAFE_DELETE( m_pModel );
	SetTypeIndex( pd3dDevice, OT_MOVER, dwMoverIndex, bInitProp );//
	m_dwMotion = -1;
	SetMotion( MTI_STAND );
	// ÀÌ·±°Ç ÇÁ·ÎÆÛÆ¼¸¦ ÀÌ¿ëÇÏ´Â°Ô ÁÁ´Ù.
	if( m_bPlayer )
	// ÇÃ·¹ÀÌ¾îÀÏ °æ¿ì¿¡¸¸ ÀåÂøÀ» Àû¿ë. ÀÏ¹Ý npc¿¡ ÀåÂøÀ» Àû¿ëÇÏ¸é ¿©·¯°¡Áö Á¶°Ç °Ë»ç ³¡¿¡ Á÷¾÷, 
	// ´É·Â µîµî¿¡ µû¶ó¼­ ¿ÀÈ÷·Á Àåºñ°¡ Å»ÂøµÉ ¼öµµ ÀÖ±â ¶§¹®¿¡, ¾Æ¿¹ Àû¿ëÀ» ÇÏÁö ¾Ê´Â´Ù.
	// ¾îÂ÷ÇÇ RedoEquip´Â ½Ã°¢ÀûÀÎ °ÍÀÌ¹Ç·Î, ±¸Áö ¾ÈÇØµµ Inventory Â÷¿ø¿¡¼­ ÀåÂøÀº µÇ¾î ÀÖ´Ù.
	{
		if( dwMoverIndex == MI_MALE || dwMoverIndex == MI_FEMALE )
		{
		#if defined( __CLIENT )
			RedoEquip( !IsActiveMover(), bDestParam );
		#else
			RedoEquip( FALSE );
		#endif
			SetHairColor( m_dwHairColor );
		}
	}
	ResetScale();
	UpdateLocalMatrix();
	return TRUE;
}
BOOL CMover::IsDisguise()
{
	if( IsPlayer() )
	{
		return ( GetIndex() != MI_MALE && GetIndex() != MI_FEMALE );
	}
	return FALSE;
}


LPCTSTR CMover::GetName( BOOL bNickname )
{
	if( !bNickname )
		return (LPCTSTR)m_szName;

	if( m_dwAuthorization >= AUTH_GAMEMASTER && ( GetIndex() == MI_CROWNIBLIS || GetIndex() == MI_CROWNSHADE || GetIndex() == MI_CROWNBUBBLE ) )
	{
		MoverProp* pMoverProp	= GetProp();
		if( pMoverProp )
			return (LPCTSTR)pMoverProp->szName;
	}
	return (LPCTSTR)m_szName;
}

#ifdef __GAMEMASTER
CString	CMover::GetAuthStr(BOOL bHook)
{
		CString strAuth[2] = { "", "" };
	switch (m_dwAuthorization)
	{
		// case AUTH_GENERAL: 
		// strAuth[0] += TEXT_RANK_01; 
		// strAuth[1] += TEXT_RANK_02; break;
	case AUTH_HELPER:
		strAuth[0] += prj.GetText(TID_RANK_03);
		strAuth[1] += prj.GetText(TID_RANK_04); break;
	case AUTH_ANIMATOR:
		strAuth[0] += prj.GetText(TID_RANK_05);
		strAuth[1] += prj.GetText(TID_RANK_06); break;
	case AUTH_MAPPER:
		strAuth[0] += prj.GetText(TID_RANK_07);
		strAuth[1] += prj.GetText(TID_RANK_08); break;
	case AUTH_GAMEMASTER:
		strAuth[0] += prj.GetText(TID_RANK_09);
		strAuth[1] += prj.GetText(TID_RANK_10); break;
	case AUTH_GAMEMASTER2:
		strAuth[0] += prj.GetText(TID_RANK_11);
		strAuth[1] += prj.GetText(TID_RANK_12); break;
	case AUTH_GAMEMASTER3:
		strAuth[0] += prj.GetText(TID_RANK_13);
		strAuth[1] += prj.GetText(TID_RANK_14); break;
	case AUTH_OPERATOR:
		strAuth[0] += prj.GetText(TID_RANK_15);
		strAuth[1] += prj.GetText(TID_RANK_16); break;
	case AUTH_ADMINISTRATOR:
		strAuth[0] += prj.GetText(TID_RANK_17);
		strAuth[1] += prj.GetText(TID_RANK_18); break;
	case AUTH_OWNER:
		strAuth[0] += prj.GetText(TID_RANK_19);
		strAuth[1] += prj.GetText(TID_RANK_20); break;
	case AUTH_DEVELOPER:
		strAuth[0] += prj.GetText(TID_RANK_21);
		strAuth[1] += prj.GetText(TID_RANK_22); break;
	default: return ""; break;
	}

	if (GetSex() == 0 || GetSex() == 1)
	{
		if (bHook)
		{
			CString szAuth = " [";
			szAuth += strAuth[GetSex()];
			szAuth += "]";
			return szAuth;
		}
		return strAuth[GetSex()];
	}
	return "";
}
#endif // __GAMEMASTER

void CMover::SetDestParamSetItem( CItemElem* pItemElem )
{
	ITEMAVAIL itemAvail;
	memset( &itemAvail, 0, sizeof(itemAvail) );

	if( pItemElem && !pItemElem->IsFlag( CItemElem::expired ) )
	{
		CSetItem* pSetItem	= CSetItemFinder::GetInstance()->GetSetItemByItemId( pItemElem->m_dwItemId );
		if( pSetItem )
		{
			int nEquiped	= GetEquipedSetItemNumber( pSetItem );
			pSetItem->GetItemAvail( &itemAvail, nEquiped, FALSE );
		}
	}
	else
	{
		map<CSetItem*, int>	mapSetItem;
		map<CSetItem*, int>::iterator i;
		for( int nParts = 0; nParts < MAX_HUMAN_PARTS; nParts++ )
		{
			pItemElem	= GetEquipItem( nParts );
			if( pItemElem && !pItemElem->IsFlag( CItemElem::expired ) )
			{
				CSetItem* pSetItem	= CSetItemFinder::GetInstance()->GetSetItemByItemId( pItemElem->m_dwItemId );
				if( pSetItem )
				{
					i	= mapSetItem.find( pSetItem );
					if( i != mapSetItem.end() )
						i->second++;
					else
						mapSetItem.insert( map<CSetItem*, int>::value_type( pSetItem, 1 ) );
				}
			}
		}
		for( i = mapSetItem.begin(); i != mapSetItem.end(); ++i )
		{
			CSetItem* pSetItem	= i->first;
			int nEquiped	= i->second;
			pSetItem->GetItemAvail( &itemAvail, nEquiped, TRUE );
		}
	}
		
	for( int i = 0; i < itemAvail.nSize; i++ )
		SetDestParam( itemAvail.anDstParam[i], itemAvail.anAdjParam[i], NULL_CHGPARAM );
}

void CMover::ResetDestParamSetItem( CItemElem* pItemElem )
{
	if( pItemElem && !pItemElem->IsFlag( CItemElem::expired ) )
	{
		CSetItem* pSetItem	= CSetItemFinder::GetInstance()->GetSetItemByItemId( pItemElem->m_dwItemId );
		if( pSetItem )
		{
			ITEMAVAIL itemAvail;
			memset( &itemAvail, 0, sizeof(itemAvail) );
			int nEquiped	= GetEquipedSetItemNumber( pSetItem );
			pSetItem->GetItemAvail( &itemAvail, nEquiped + 1, FALSE );
			for( int i = 0; i < itemAvail.nSize; i++ )
				ResetDestParam( itemAvail.anDstParam[i], itemAvail.anAdjParam[i], TRUE );				
		}
	}
}

int CMover::GetEquipedSetItemNumber( CSetItem* pSetItem )
{
	int nEquiped	= 0;
	for( int i = 0; i < pSetItem->m_nElemSize; i++ )
	{
		CItemElem* pItemElem	= GetEquipItem( pSetItem->m_anParts[i] );
		if( pItemElem && pItemElem->m_dwItemId == pSetItem->m_adwItemId[i] && !pItemElem->IsFlag( CItemElem::expired ) )
			nEquiped++;
	}
	return nEquiped;
}

void CMover::GetEquipedSetItem( int nSetItemId, BOOL* pbEquiped, int* pnEquip )
{
	*pnEquip	= 0;
//	memset( pbEquiped, 0, sizeof(BYTE) * MAX_HUMAN_PARTS );
	CSetItem* pSetItem	= CSetItemFinder::GetInstance()->GetSetItem( nSetItemId );
	if( pSetItem )
	{
		for( int i = 0; i < pSetItem->m_nElemSize; i++ )
		{
			CItemElem* pItemElem	= GetEquipItem( pSetItem->m_anParts[i] );
			if( pItemElem && pItemElem->m_dwItemId == pSetItem->m_adwItemId[i] && !pItemElem->IsFlag( CItemElem::expired ) )
			{
				pbEquiped[i]	= TRUE;
				(*pnEquip)++;
			}
		}
	}
}

void CMover::SetDestParamRandomOptOrigin( CItemElem* pItemElem )
{
	if( pItemElem->GetRandomOpt() > 0 )
	{
		PRANDOMOPTITEM pRandomOptItem	= CRandomOptItemGen::GetInstance()->GetRandomOptItem( pItemElem->GetRandomOpt() );
		if( pRandomOptItem )
		{
			for( int i = 0; i < pRandomOptItem->ia.nSize; i++ )
				SetDestParam( pRandomOptItem->ia.anDstParam[i], pRandomOptItem->ia.anAdjParam[i], NULL_CHGPARAM );
		}
	}
}

void CMover::SetDestParamRandomOptExtension( CItemElem* pItemElem )
{
#if __VER >= 11 // __SYS_IDENTIFY
	int cbOption	= g_xRandomOptionProperty->GetRandomOptionSize( pItemElem->GetRandomOptItemId() );
	for( int i = 0; i < cbOption; i++ )
	{
		int nDst, nAdj;
		if( g_xRandomOptionProperty->GetParam( pItemElem->GetRandomOptItemId(), i, &nDst, &nAdj ) )
			SetDestParam( nDst, nAdj, NULL_CHGPARAM );
	}
#endif	// __SYS_IDENTIFY
}

void CMover::SetDestParamRandomOpt( CItemElem* pItemElem )
{
	SetDestParamRandomOptOrigin( pItemElem );
	SetDestParamRandomOptExtension( pItemElem );
}

void CMover::ResetDestParamRandomOptOrigin( CItemElem* pItemElem )
{
	if( pItemElem->GetRandomOpt() > 0 )
	{
		PRANDOMOPTITEM pRandomOptItem	= CRandomOptItemGen::GetInstance()->GetRandomOptItem( pItemElem->GetRandomOpt() );
		if( pRandomOptItem )
		{
			for( int i = 0; i < pRandomOptItem->ia.nSize; i++ )
				ResetDestParam( pRandomOptItem->ia.anDstParam[i], pRandomOptItem->ia.anAdjParam[i], TRUE );
		}
	}
}

void CMover::ResetDestParamRandomOptExtension( CItemElem* pItemElem )
{
#if __VER >= 11 // __SYS_IDENTIFY
	int cbOption	= g_xRandomOptionProperty->GetRandomOptionSize( pItemElem->GetRandomOptItemId() );
	for( int i = 0; i < cbOption; i++ )
	{
		int nDst, nAdj;
		if( g_xRandomOptionProperty->GetParam( pItemElem->GetRandomOptItemId(), i, &nDst, &nAdj ) )
			ResetDestParam( nDst, nAdj, TRUE );
	}
#endif	// __SYS_IDENTIFY
}

void CMover::ResetDestParamRandomOpt( CItemElem* pItemElem )
{
	ResetDestParamRandomOptOrigin( pItemElem );
	ResetDestParamRandomOptExtension( pItemElem );
}

#ifdef __CLIENT
void CMover::OverCoatItemRenderCheck(CModelObject* pModel)
{
	if (!pModel)
		return;

	int nArryEquip1[5] = { PARTS_CAP, PARTS_UPPER_BODY, PARTS_HAND, PARTS_FOOT, PARTS_CLOAK };
	int nArryEquip2[5] = { PARTS_HAT, PARTS_CLOTH, PARTS_GLOVE, PARTS_BOOTS, PARTS_CLOAK2 };

	O3D_ELEMENT* pElem = NULL;
	O3D_ELEMENT* pElem2 = NULL;

	for (int j = 0; j < 5; j++)
	{
		pElem = pModel->GetParts(nArryEquip1[j]);

		if (!pElem)
			continue;

#ifdef __HIDE_COAT
		if (j == 4)
		{
			if (m_abHideCoat[j])
				pElem->m_nEffect |= XE_HIDE;
			else
				pElem->m_nEffect &= ~XE_HIDE;
		}
#endif // __HIDE_COAT

		pElem2 = pModel->GetParts(nArryEquip2[j]);

		if (pElem2)
		{
			if (IsActiveMover())
			{
				CItemElem* pItemElemOvercoat = GetEquipItem(nArryEquip2[j]);

				if (pItemElemOvercoat)
				{
					if (pItemElemOvercoat->IsFlag(CItemElem::expired))
					{
						pElem->m_nEffect &= ~XE_HIDE;
						pElem2->m_nEffect |= XE_HIDE;
						continue;
					}
				}
			}
			else
			{
				DWORD dwId = m_aEquipInfo[nArryEquip2[j]].dwId;
				if ((m_aEquipInfo[nArryEquip2[j]].byFlag & CItemElem::expired))
				{
					pElem->m_nEffect &= ~XE_HIDE;
					pElem2->m_nEffect |= XE_HIDE;
					continue;
				}
			}
#ifdef __HIDE_COAT
			if (j < 4 && m_abHideCoat[j])
			{
				BOOL bHide = FALSE;
				if (IsActiveMover())
					bHide = (GetEquipItem(nArryEquip1[j]) != NULL);
				else
					bHide = (m_aEquipInfo[nArryEquip1[j]].dwId != NULL_ID);

				if (bHide)
				{
					pModel->SetEffectOff(nArryEquip1[j], XE_HIDE);
					pModel->SetEffect(nArryEquip2[j], XE_HIDE);
#ifdef __HIDE_COAT
					if (j == 0)
					{
						CItemElem* itemElem = NULL;
						if (IsActiveMover())
							itemElem = GetEquipItem(PARTS_CAP);

						if (itemElem)
						{
							if (itemElem->GetProp()->dwBasePartsIgnore != -1)
							{
								pModel->SetEffect(itemElem->GetProp()->dwBasePartsIgnore, XE_HIDE);
							}
						}
						else {
							DWORD dwID = m_aEquipInfo[PARTS_CAP].dwId;
							if (dwID)
							{
								ItemProp* pProp = prj.GetItemProp(dwID);
								if (pProp)
								{
									if (pProp->dwBasePartsIgnore != -1)
										pModel->SetEffect(pProp->dwBasePartsIgnore, XE_HIDE);
								}
							}
						}
					}

#endif
				}
				else
				{
					pModel->SetEffect(nArryEquip1[j], XE_HIDE);
					pModel->SetEffectOff(nArryEquip2[j], XE_HIDE);
				}
			}
			else
#endif // __HIDE_COAT
			{
				pElem->m_nEffect |= XE_HIDE;
#ifdef __HIDE_COAT
				pElem2->m_nEffect &= ~XE_HIDE;
				if (j == 0)
				{
					CItemElem* itemElem = NULL;
					if (IsActiveMover())
						itemElem = GetEquipItem(PARTS_CAP);

					if (itemElem)
					{
						if (itemElem->GetProp()->dwBasePartsIgnore != -1)
						{
							pModel->SetEffect(itemElem->GetProp()->dwBasePartsIgnore, XE_HIDE);
						}
					}
					else {
						DWORD dwID = m_aEquipInfo[PARTS_CAP].dwId;
						if (dwID)
						{
							ItemProp* pProp = prj.GetItemProp(dwID);
							if (pProp)
							{
								if (pProp->dwBasePartsIgnore != -1)
									pModel->SetEffect(pProp->dwBasePartsIgnore, XE_HIDE);
							}
						}
							}
						}
#endif
					}

#ifdef __HIDE_COAT
			if (g_Option.m_bViewMask == FALSE)
				pModel->SetEffect(PARTS_MASK, XE_HIDE);
			else
				pModel->SetEffectOff(PARTS_MASK, XE_HIDE);
#endif
				}
			}
		}
#endif	// __CLIENT

#ifdef __WORLDSERVER
void CMover::ProcInstantBanker()
{
	if( m_dwTickCreated && m_dwIndex == MI_INFO_PENG )
	{
		LPCHARACTER lpCharacter	= GetCharacter();
		if( lpCharacter && lstrcmp( lpCharacter->m_szKey, "MaFl_InstantBank" ) == 0 )
		{
			if( GetTickCount() > m_dwTickCreated + TIMEWAIT_INSTANT_BANKER )
				Delete();
		}
	}
}
void CMover::ProcInstantGC()
{
	if( CGuildCombat::WAR_STATE <= g_GuildCombatMng.m_nState  && m_dwIndex == MI_MADA_ACHABEN )
	{
		LPCHARACTER lpCharacter	= GetCharacter();
		if( lpCharacter && lstrcmp( lpCharacter->m_szKey, "Mada_Guildcombatshop" ) == 0 )
		{
			Delete();
		}
	}
}
#ifdef __NEW_ITEM_VARUNA
void CMover::ProcBarunaPet()
{
	if( GetBarunaPetOwner() == NULL_ID )
		return;

	CMover* pOwner		= prj.GetMover( GetBarunaPetOwner() );
	if( IsInvalidObj( pOwner ) )
	{
		Delete();
		return;
	}
	if( pOwner->IsDie() )
	{
		pOwner->InactivateBarunaPet();
		return;
	}
	else if( !pOwner->IsValidArea( this, 16 ) )
	{
		pOwner->InactivateBarunaPet();
		return;
	}
}
#endif // __NEW_ITEM_VARUNA
#endif	// __WORLDSERVER

CItemBase*	CMover::GetVendorItem()
{
	return NULL;
}

void CMover::AddSkillPoint( int nPoint )
{
	int nMaxPoint = 1280;	// ÃÖ´ëÀÎ JOB_ELEMENTOR ²¨·Î ¼³Á¤ÇÔ
	if( IsPro() )
	{
		if( m_nJob == JOB_KNIGHT || m_nJob == JOB_BLADE )
			nMaxPoint = 870;
		else if( m_nJob == JOB_JESTER || m_nJob == JOB_RANGER )
			nMaxPoint = 910;
		else if( m_nJob == JOB_RINGMASTER )
			nMaxPoint = 902;
		else if( m_nJob == JOB_BILLPOSTER || m_nJob == JOB_PSYCHIKEEPER )
			nMaxPoint = 950;
	}
#ifdef __3RD_LEGEND16
	if( m_nJob == JOB_LORDTEMPLER_HERO )
		nMaxPoint = 870 + 90;
	else if( m_nJob == JOB_STORMBLADE_HERO )
		nMaxPoint = 870 + 60;
	else if( m_nJob == JOB_WINDLURKER_HERO )
		nMaxPoint = 910 + 60;
	else if( m_nJob == JOB_CRACKSHOOTER_HERO )
		nMaxPoint = 910 + 60;
	else if( m_nJob == JOB_FLORIST_HERO )
		nMaxPoint = 902 + 90;
	else if( m_nJob == JOB_FORCEMASTER_HERO )
		nMaxPoint = 950 + 60;
	else if( m_nJob == JOB_MENTALIST_HERO )
		nMaxPoint = 950 + 75;
	else if( m_nJob == JOB_ELEMENTORLORD_HERO )
		nMaxPoint = 1280 + 60;
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
	if (m_nJob == JOB_LORDTEMPLER_HERO_ULTIMATE)
		nMaxPoint = 960;
	else if (m_nJob == JOB_STORMBLADE_HERO_ULTIMATE)
		nMaxPoint = 930;
	else if (m_nJob == JOB_WINDLURKER_HERO_ULTIMATE)
		nMaxPoint = 970;
	else if (m_nJob == JOB_CRACKSHOOTER_HERO_ULTIMATE)
		nMaxPoint = 970;
	else if (m_nJob == JOB_FLORIST_HERO_ULTIMATE)
		nMaxPoint = 992;
	else if (m_nJob == JOB_FORCEMASTER_HERO_ULTIMATE)
		nMaxPoint = 1010;
	else if (m_nJob == JOB_MENTALIST_HERO_ULTIMATE)
		nMaxPoint = 1025;
	else if (m_nJob == JOB_ELEMENTORLORD_HERO_ULTIMATE)
		nMaxPoint = 1340;
#endif // __NEWCLASS
	if( m_nSkillLevel >= nMaxPoint )
		return;

	if( nMaxPoint < m_nSkillLevel + nPoint )	// ´õ ÇØÁö¸é ³Ñ´Â °æ¿ì(ÇöÀç ³ÑÁö ¾ÊÀ½)
		nPoint = nMaxPoint - m_nSkillLevel;	// ¸Æ½ºÄ¡¿¡ ¸ðÀÚ¸¥ ¸¸Å­¸¸ Æ÷ÀÎÆ® Áö±Þ

	m_nSkillPoint += nPoint;
	m_nSkillLevel += nPoint;
}

// ÀüÅõÁßÀÎ°¡?
BOOL CMover::IsAttackMode()
{
#if __VER >= 9 // __RECOVERY10
	return ( m_nAtkCnt && m_nAtkCnt < (SEC1 * 10) );
#else // __RECOVERY10
	return ( m_nAtkCnt && m_nAtkCnt < (SEC1 * 5) );
#endif // __RECOVERY10
}

BOOL CMover::IsDropable( CItemElem* pItemElem, BOOL bPK )
{
	return ( IsDropableState( bPK )
		&& IsUsableItem( pItemElem )
		&& !pItemElem->IsBinds()
		&& !( pItemElem->GetProp()->dwItemKind3 == IK3_CLOAK && pItemElem->m_idGuild )
		&& !m_Inventory.IsEquip( pItemElem->m_dwObjId )
		&& !IsUsing( pItemElem )
		&& !( pItemElem->GetProp()->dwParts == PARTS_RIDE && pItemElem->GetProp()->dwItemJob == JOB_VAGRANT )
		&& !pItemElem->IsCharged()
#if __VER >= 9	// __PET_0410
		&& pItemElem->GetProp()->dwItemKind3 != IK3_EGG
#endif	// __PET_0410
#ifdef __JEFF_11
		&& pItemElem->m_dwItemId != II_CHP_RED
#endif	// __JEFF_11
#if __VER >= 11 // __MA_VER11_05	// ÄÉ¸¯ÅÍ ºÀÀÎ °Å·¡ ±â´É world,database,neuz
		&& pItemElem->m_dwItemId != II_SYS_SYS_SCR_SEALCHARACTER
#endif // __MA_VER11_05	// ÄÉ¸¯ÅÍ ºÀÀÎ °Å·¡ ±â´É world,database,neuz

	);
}

#ifdef __CLIENT
BOOL CMover::IsStateDbuff()
{
	int nAdjParam = GetAdjParam( DST_CHRSTATE );

#ifdef __SLEEPING_FIX
	if (nAdjParam & CHS_STUN || nAdjParam & CHS_SLEEPING || nAdjParam & CHS_POISON || nAdjParam & CHS_DARK ||
#else
	if( nAdjParam & CHS_STUN || nAdjParam & CHS_POISON || nAdjParam & CHS_DARK ||
#endif
		nAdjParam & CHS_GROGGY || nAdjParam & CHS_SILENT || nAdjParam & CHS_BLEEDING)
	{
		return TRUE;
	}

	return FALSE;
}
#endif //__CLIENT

int __IsEndQuestCondition( CMover* pMover, int nQuestId )
{
	QuestProp* pQuestProp = prj.m_aPropQuest.GetAt( nQuestId );

	if( pQuestProp )
	{
		int nResult = 0;
		LPQUEST pCurQuest = pMover->GetQuest( nQuestId );
		if( pCurQuest == NULL || pCurQuest->m_nState == QS_END ) 
			return 0;
		// ½Ã°£ Á¦ÇÑ Ã¼Å© 1
		if( pQuestProp->m_nEndCondLimitTime == 0 || pCurQuest->m_wTime )
			nResult++;
		// Á¤Âû ÀÓ¹«  2
		if( pQuestProp->m_dwEndCondPatrolWorld == 0 || pCurQuest->m_bPatrol )
			nResult++;
		// NPC ÅðÄ¡ °¹¼ö  3,4
		for( int i = 0; i < MAX_QUEST_COND_KILL; i++ )
		{
			if( pQuestProp->m_nEndCondKillNPCIdx[ i ] == 0 || pCurQuest->m_nKillNPCNum[ i ] >= pQuestProp->m_nEndCondKillNPCNum[ i ] ) 
				nResult++;
		}
		// ½ºÅ³ 5
		if( pQuestProp->m_nEndCondSkillIdx == 0 )
			nResult++;
		else
		{
			LPSKILL lpSkill = pMover->GetSkill( pQuestProp->m_nEndCondSkillIdx );
			if( lpSkill )
			{
				if( pMover->CheckSkill( pQuestProp->m_nEndCondSkillIdx ) && lpSkill->dwLevel >= (DWORD)( pQuestProp->m_nEndCondSkillLvl ) )
					nResult++;
			}
		}
#if __VER >= 8 // __S8_PK
		// Penya 6
		if( pQuestProp->m_nEndCondGold == 0 )
			nResult++;
		else
		{
			if( pMover->GetGold() >= pQuestProp->m_nEndCondGold )
				nResult++;
		}
		// ·¹º§ 7
		if( pQuestProp->m_nEndCondLevelMin == 0 || ( pMover->GetLevel() >= pQuestProp->m_nEndCondLevelMin && pMover->GetLevel() <= pQuestProp->m_nEndCondLevelMax ) )
			nResult++;
	#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pQuestProp->m_nEndCondExpPercentMin == 0 || ( pMover->GetExpPercent() >= pQuestProp->m_nEndCondExpPercentMin && pMover->GetExpPercent() <= pQuestProp->m_nEndCondExpPercentMax ) )
			nResult++;
	#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

#else // __VER >= 8 // __S8_PK
		// Ä«¸£¸¶ 6
		if( pQuestProp->m_nEndCondKarmaPoint == 0 )
			nResult++;
		else
		{
			if( pQuestProp->m_nEndCondKarmaComp == 0 )
			{
				if( pMover->GetKarma() == pQuestProp->m_nEndCondKarmaPoint )
					nResult++;
			}
			else
			if( pQuestProp->m_nEndCondKarmaComp == -1 )
			{
				if( pMover->GetKarma() <= pQuestProp->m_nEndCondKarmaPoint )
					nResult++;
			}
			else
			if( pQuestProp->m_nEndCondKarmaComp == 1 )
			{
				if( pMover->GetKarma() >= pQuestProp->m_nEndCondKarmaPoint )
					nResult++;
			}
		}
		// Ä«¿ÀÆ½ 7
		if( pQuestProp->m_nEndCondChaotic == 0 )
			nResult++;
		else
		{
			if( pQuestProp->m_nEndCondChaotic == 1 && pMover->IsChaotic() )
				nResult++;
			else
			if( pQuestProp->m_nEndCondChaotic == 2 && pMover->IsChaotic() == FALSE )
				nResult++;
		}
#endif // __VER >= 8 // __S8_PK

#if __VER >= 9	// __PET_0410
		if( pQuestProp->m_nEndCondPetExp == 0 )
			nResult++;
		else
		{
			CPet* pPet	= pMover->GetPet();
			if( pPet && pPet->GetExpPercent() >= pQuestProp->m_nEndCondPetExp )
				nResult++;
		}
		if( pQuestProp->m_nEndCondPetLevel == -1 )
			nResult++;
		else
		{
			CPet* pPet	= pMover->GetPet();
			if( pPet && pPet->GetLevel() == pQuestProp->m_nEndCondPetLevel )
				nResult++;
		}
#endif	// __PET_0410

		// º¯½Å 8
		if( pQuestProp->m_nEndCondDisguiseMoverIndex == 0 )
			nResult++;
		else
		{
			if( pQuestProp->m_nEndCondDisguiseMoverIndex == -1 && pMover->IsDisguise() == FALSE )
				nResult++;
			else
			if( pQuestProp->m_nEndCondDisguiseMoverIndex == pMover->GetIndex() )
				nResult++;
		}
		// ½ºÅ×ÀÌÆ® Ã¼Å© 9 
		if( pQuestProp->m_nEndCondState == 0 )
		{
			int i = QS_BEGIN + 1;
			for( ; i < QS_END; i++ ) // (1~13)
			{
				if( pQuestProp->m_questState[ i ] == NULL )
					break;
			}
			if( ( i - 1 ) == pCurQuest->m_nState )
				nResult++;
		}
		else
		if( pQuestProp->m_nEndCondState == pCurQuest->m_nState )
			nResult++;
		// ¿Ï·á Äù½ºÆ® Ã¼Å© 10,11,12,13,14, 15 
		if( pQuestProp->m_nEndCondCompleteQuestOper == 0 ) // 
			nResult += 6;
		else
		if( pQuestProp->m_nEndCondCompleteQuestOper == 1 ) // or
		{
			int i = NULL;
			for( ; i < 6; i++ )
			{
				if( pMover->IsCompleteQuest( pQuestProp->m_nEndCondCompleteQuest[ i ] ) )
					break;
			}
			if( i != 6 )
				nResult += 6;
		}
		else
		if( pQuestProp->m_nEndCondCompleteQuestOper == 2 ) // and
		{
			for( int i = 0; i < 6; i++ )
			{
				if( pQuestProp->m_nEndCondCompleteQuest[ i ] == 0 || pMover->IsCompleteQuest( pQuestProp->m_nEndCondCompleteQuest[ i ] ) )
					nResult++;
			}
		}
//		else
		// ÆÄÆ¼ ¿©ºÎ 16
		if( pQuestProp->m_nEndCondParty == 0 )
			nResult++;
		else
		{
			BOOL bParty = FALSE;
			BOOL bLeader = FALSE;
			int nSize = 0;
#ifdef __WORLDSERVER
			CParty* pParty = g_PartyMng.GetParty( pMover->m_idparty );
			if( pParty )
			{
				bParty = TRUE;
				nSize = pParty->GetSizeofMember();
				bLeader	= pParty->m_aMember[0].m_uPlayerId == pMover->m_idPlayer;
			}
#else
			bParty = g_Party.IsMember( g_pPlayer->m_idPlayer );
			nSize = g_Party.GetSizeofMember();
			bLeader	= ( g_Party.m_aMember[0].m_uPlayerId == pMover->m_idPlayer );
#endif
			if( pQuestProp->m_nEndCondParty == 1 && bParty == FALSE )
				nResult++;
			else
			if( pQuestProp->m_nEndCondParty == 2 && bParty == TRUE )
			{
				if( pQuestProp->m_nEndCondPartyLeader == 0 || ( pQuestProp->m_nEndCondPartyLeader - 1 ) == bLeader )
				{
					if( pQuestProp->m_nEndCondPartyNum == 0 )
						nResult++;
					else
					if( pQuestProp->m_nEndCondPartyNumComp == 0 )
					{
						if( nSize == pQuestProp->m_nEndCondPartyNum )
							nResult++;
					}
					else
					if( pQuestProp->m_nEndCondPartyNumComp == 1 )
					{
						if( nSize >= pQuestProp->m_nEndCondPartyNum )
							nResult++;
					}	
					else
					if( pQuestProp->m_nEndCondPartyNumComp == -1 )
					{
						if( nSize <= pQuestProp->m_nEndCondPartyNum )
							nResult++;
					}						
				}
			}
		}
		// ±æµå ¿©ºÎ 17 
		if( pQuestProp->m_nEndCondGuild == 0 )
			nResult++;
		else
		{
			BOOL bGuild = FALSE;
			BOOL bLeader = FALSE;
			int nSize = 0;
			CGuild* pGuild	= g_GuildMng.GetGuild( pMover->m_idPlayer );
			if( pGuild )
			{
				bGuild	= TRUE;
				nSize	= pGuild->GetSize();
				bLeader	= ( pGuild->m_idMaster == pMover->m_idPlayer );
			}
			if( pQuestProp->m_nEndCondGuild == 1 && bGuild == FALSE )
				nResult++;
			else
			if( pQuestProp->m_nEndCondGuild == 2 && bGuild == TRUE )
			{
				if( pQuestProp->m_nEndCondGuildLeader == 0 || ( pQuestProp->m_nEndCondGuildLeader - 1 ) == bLeader )
				{
					if( pQuestProp->m_nEndCondGuildNum == 0 )
						nResult++;
					else
					if( pQuestProp->m_nEndCondGuildNumComp == 0 )
					{
						if( nSize == pQuestProp->m_nEndCondGuildNum )
							nResult++;
					}
					else
					if( pQuestProp->m_nEndCondGuildNumComp == 1 )
					{
						if( nSize >= pQuestProp->m_nEndCondGuildNum )
							nResult++;
					}	
					else
					if( pQuestProp->m_nEndCondGuildNumComp == -1 )
					{
						if( nSize <= pQuestProp->m_nEndCondGuildNum )
							nResult++;
					}
				}
			}
		}

#if __VER >= 8 // __S8_PK
		// ¼³Á¤ ¾ÆÀÌÅÛÀÌ ¼³Á¤ÇÑ °¹¼ö°¡ ÀÖÀ¸¸é ÃæÁ·
		int nBufResult = nResult + MAX_QUESTCONDITEM;
		if( pQuestProp->m_nEndCondOneItemNum == 0 )
			nResult += MAX_QUESTCONDITEM;
		else
		for( int i = 0; i < MAX_QUESTCONDITEM; i++ )
		{
			if( i < pQuestProp->m_nEndCondOneItemNum )
			{
				QuestPropItem* pEndCondItem = &pQuestProp->m_paEndCondOneItem[ i ];
				if( pEndCondItem->m_nSex == -1 || pEndCondItem->m_nSex == pMover->GetSex() )
				{
					if( pEndCondItem->m_nType == 0 )
					{
						if( pEndCondItem->m_nJobOrItem == -1 || pEndCondItem->m_nJobOrItem == pMover->GetJob() )
						{
							if( pMover->GetItemNum( pEndCondItem->m_nItemIdx ) >= pEndCondItem->m_nItemNum )
							{
								nResult = nBufResult;
								break;
							}
						}
						else
							nResult++;
					}
					else
					if( pEndCondItem->m_nType == 1 )
					{
						if( pEndCondItem->m_nJobOrItem == -1 || pMover->GetItemNum( pEndCondItem->m_nJobOrItem ) )
						{
							if( pMover->GetItemNum( pEndCondItem->m_nItemIdx ) >= pEndCondItem->m_nItemNum ) 
							{
								nResult = nBufResult;
								break;
							}
						}
						else
							nResult++;
					}
				}
			}
			else
				nResult++;
		}
#endif // __VER >= 8 // __S8_PK
		// ¼öÁý ¾ÆÀÌÅÛ °¹¼ö  17 + MAX_QUESTCONDITEM
		if( pQuestProp->m_nEndCondItemNum == 0 )
			nResult += MAX_QUESTCONDITEM;
		else
		for( int i = 0; i < MAX_QUESTCONDITEM; i++ )
		{
			if( i < pQuestProp->m_nEndCondItemNum )
			{
				QuestPropItem* pEndCondItem = &pQuestProp->m_paEndCondItem[ i ];
				if( pEndCondItem->m_nSex == -1 || pEndCondItem->m_nSex == pMover->GetSex() )
				{
					if( pEndCondItem->m_nType == 0 )
					{
						if( pEndCondItem->m_nJobOrItem == -1 || pEndCondItem->m_nJobOrItem == pMover->GetJob() )
						{
							if( pEndCondItem->m_nItemIdx == 0 || pMover->GetItemNum( pEndCondItem->m_nItemIdx ) >= pEndCondItem->m_nItemNum ) 
								nResult++;
						}
						else
							nResult++;
					}
					else
					if( pEndCondItem->m_nType == 1 )
					{
						if( pEndCondItem->m_nJobOrItem == -1 || pMover->GetItemNum( pEndCondItem->m_nJobOrItem ) )
						{
							if( pEndCondItem->m_nItemIdx == 0 || pMover->GetItemNum( pEndCondItem->m_nItemIdx ) >= pEndCondItem->m_nItemNum ) 
								nResult++;
						}
						else
							nResult++;
					}
				}
			}
			else
				nResult++;
		}
#if __VER >= 15 // __CAMPUS
		if( pQuestProp->m_nEndCondTSP == 0 )
			++nResult;
		else
		{
			if( pMover->GetCampusPoint() >= pQuestProp->m_nEndCondTSP )
				++nResult;
		}
#endif // __CAMPUS
		// ÃÑÇÕÀÌ 17 + MAX_QUESTCONDITEM¸é Äù½ºÆ® Á¶°Ç ¼º¸³ 
#if __VER >= 8 // __S8_PK
	#if __VER >= 9	// __PET_0410
		#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#if __VER >= 15 // __CAMPUS
		if( nResult == 21+ MAX_QUESTCONDITEM + MAX_QUESTCONDITEM ) 
#else // __CAMPUS
		if( nResult == 20+ MAX_QUESTCONDITEM + MAX_QUESTCONDITEM ) 
#endif // __CAMPUS
		#else // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( nResult == 19+ MAX_QUESTCONDITEM + MAX_QUESTCONDITEM ) 
		#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	#else	// __PET_0410
		#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( nResult == 18+ MAX_QUESTCONDITEM + MAX_QUESTCONDITEM ) 
		#else
		if( nResult == 17+ MAX_QUESTCONDITEM + MAX_QUESTCONDITEM ) 
		#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	#endif	//__PET_0410
#else	// __VER >= 8 // __S8_PK
		if( nResult == 17+ MAX_QUESTCONDITEM ) 
#endif	// __VER >= 8 // __S8_PK
		{
			// ¸ðµç Á¶°Ç ´Þ¼º ¼ø°£¿¡ Å¸ÀÌ¸Ó Ä«¿îÆ® ÁßÁö ½ÃÅ°±â 
			// ÀÌÈÄ¿¡ ÀÎº¥Åä¸®°¡ ºÎÁ·ÇØ¼­ Äù½ºÆ®¸¦ ¿Ï·á ¸ø½ÃÅ°´õ¶óµµ ½Ã°£Àº Á¤ÁöµÈ´Ù.
			if( pCurQuest->m_wTime )
				pCurQuest->m_wTime |= 0x8000;
			return 1;
		}
	}

	return 0;
}

#ifdef __WORLDSERVER
#include "User.h"
#endif // __WORLDSERVER
int __IsBeginQuestCondition( CMover* pMover, int nQuestId )
{
	QuestProp* pQuestProp = prj.m_aPropQuest.GetAt( nQuestId );
	if( pQuestProp )
	{
		int nResult = 0;
		LPQUEST pCurQuest = pMover->GetQuest( nQuestId );
		BOOL bComplete = pMover->IsCompleteQuest( nQuestId );
		// Äù½ºÆ®°¡ Á¸ÀçÇÏ°Å³ª, ÀÌ¹Ì ¿Ï·áµÈ ÀûÀÌ ÀÖ´Â Äù½ºÆ®´Â Á¶°Ç ¼º¸³ ¾ÈµÊ. ¹Ýº¹ÇÏ±â À§ÇØ¼­´Â ¿ÏÀüÈ÷ Á¦°ÅÇÏ¿© ¿Ï·á ¹è¿­¿¡ ¾ø¾î¿© ÇÑ´Ù.
		if( pCurQuest || bComplete ) 
			return 0;

#ifdef __WORLDSERVER
		// ½ÃÀÛ ¾ÆÀÌÅÛÀÌ Á¸ÀçÇÒ ¶§ ÀÎº¥Åä¸®¿¡ ºóÄ­ÀÌ ÀÖ´ÂÁö °Ë»ç
		int nItemCount = 0;
		for( int j=0; j<4; j++ )
			if( pQuestProp->m_nBeginSetAddItemIdx[ j ] )
				nItemCount++;
#ifdef __TABBED_INV
		int nItemNumTab[4] = { 0,0,0,0 };
		for (int j = 0; j < 4; j++)
		{
			if (pQuestProp->m_nBeginSetAddItemIdx[j])
				nItemNumTab[prj.GetItemProp(pQuestProp->m_nBeginSetAddItemIdx[j])->GetInvenIndex()]++;
		}
		for (int j = 0; j < 4; j++)
		{
			if (IsValidObj(pMover) && static_cast<CUser*>(pMover)->m_Inventory.GetEmptyCount(j) < nItemNumTab[j])
			{
				static_cast<CUser*>(pMover)->AddDefinedText(TID_GAME_LACKSPACE);
				return 0;
			}
		}
#else // __TABBED_INV
		if( IsValidObj( pMover ) && static_cast<CUser*>(pMover)->m_Inventory.GetEmptyCount() < nItemCount )
		{
			static_cast<CUser*>(pMover)->AddDefinedText( TID_GAME_LACKSPACE );
			return 0;
		}
#endif // __TABBED_INV
		// ½ÃÀÛ ¾ÆÀÌÅÛÀÌ Á¸ÀçÇÒ ¶§ ÀÎº¥Åä¸®¿¡ ºóÄ­ÀÌ ÀÖ´ÂÁö °Ë»ç_END
#endif // __WORLDSERVER
		// ÀÌÀü Äù½ºÆ® 1,2,3,4,5,6
		for( int i = 0; i < 6; i++ )
		{
			if( pQuestProp->m_anBeginCondPreviousQuest[ i ] == 0 ) 
				nResult++;
			else
			{
				LPQUEST pPreQuest = pMover->GetQuest( pQuestProp->m_anBeginCondPreviousQuest[ i ] );
				BOOL bPreComplete = pMover->IsCompleteQuest( pQuestProp->m_anBeginCondPreviousQuest[ i ] );
				if( pQuestProp->m_nBeginCondPreviousQuestType == 0 )
				{
					if( pPreQuest || bPreComplete )
						nResult++;
				}
				else
				if( pQuestProp->m_nBeginCondPreviousQuestType == 1 )
				{
					if( pPreQuest == NULL && bPreComplete )
						nResult++;
				}
				else
				if( pQuestProp->m_nBeginCondPreviousQuestType == 2 )
				{
					if( pPreQuest && bPreComplete == FALSE )
						nResult++;
				}
			}
		}
		// ÀÌÀü Äù½ºÆ® 7,8,9,10,11,12
		for( int i = 0; i < 6; i++ )
		{
			if( pQuestProp->m_anBeginCondExclusiveQuest[ i ] == 0 ) 
				nResult++;
			else
			{
				LPQUEST pPreQuest = pMover->GetQuest( pQuestProp->m_anBeginCondExclusiveQuest[ i ] );
				BOOL bPreComplete = pMover->IsCompleteQuest( pQuestProp->m_anBeginCondPreviousQuest[ i ] );
				if( pPreQuest == NULL && bPreComplete == FALSE )
					nResult++;
			}
		}
		// Á÷¾÷ 13
		if( pQuestProp->m_nBeginCondJobNum == 0 )
			nResult++;
		else
		for( int i = 0; i < pQuestProp->m_nBeginCondJobNum; i++ )
		{
			if( pQuestProp->m_nBeginCondJob[ i ] == pMover->GetJob() )
			{
				nResult++;
				break;
			}
		}
		// ·¹º§ 14
		if( pQuestProp->m_nBeginCondLevelMin == 0 || ( pMover->GetLevel() >= pQuestProp->m_nBeginCondLevelMin && pMover->GetLevel() <= pQuestProp->m_nBeginCondLevelMax ) )
			nResult++;
		// ÆÄÆ¼ ¿©ºÎ 15
		if( pQuestProp->m_nBeginCondParty == 0 )
			nResult++;
		else
		{
			BOOL bParty = FALSE;
			BOOL bLeader = FALSE;
			int nSize = 0;
#ifdef __WORLDSERVER
			CParty* pParty = g_PartyMng.GetParty( pMover->m_idparty );
			if( pParty )
			{
				bParty = TRUE;
				nSize = pParty->GetSizeofMember();
				
			}
#else
			bParty = g_Party.IsMember( g_pPlayer->m_idPlayer );
			nSize = g_Party.GetSizeofMember();
#endif
			if( pQuestProp->m_nBeginCondParty == 1 && bParty == FALSE )
				nResult++;
			else
			if( pQuestProp->m_nBeginCondParty == 2 && bParty == TRUE )
			{
				if( pQuestProp->m_nBeginCondPartyLeader == -1 || pQuestProp->m_nBeginCondPartyLeader == bLeader )
				{
					if( pQuestProp->m_nBeginCondPartyNum == 0 )
						nResult++;
					else
					if( pQuestProp->m_nBeginCondPartyNumComp == 0 )
					{
						if( nSize == pQuestProp->m_nBeginCondPartyNum )
							nResult++;
					}
					else
					if( pQuestProp->m_nBeginCondPartyNumComp == 1 )
					{
						if( nSize >= pQuestProp->m_nBeginCondPartyNum )
							nResult++;
					}	
					else
					if( pQuestProp->m_nBeginCondPartyNumComp == -1 )
					{
						if( nSize <= pQuestProp->m_nBeginCondPartyNum )
							nResult++;
					}			
				}
			}
		}
		// ±æµå ¿©ºÎ 16
		if( pQuestProp->m_nBeginCondGuild == 0 )
			nResult++;
		else
		{
			BOOL bGuild = FALSE;
			BOOL bLeader = FALSE;
			int nSize = 0;
			/*
#ifdef __WORLDSERVER
			g_PartyMng.m_AddRemoveLock.Enter( theLineFile );
			CParty* pParty = g_PartyMng.GetParty( pMover->m_idparty );
			if( pParty )
			{
				bParty = TRUE;
				nSize = pParty->GetSizeofMember();
			}
			g_PartyMng.m_AddRemoveLock.Leave( theLineFile );
#else
			bParty = g_Party.IsMember( g_pPlayer->m_idPlayer );
			nSize = g_Party.GetSizeofMember();
#endif
			*/
			if( pQuestProp->m_nBeginCondGuild == 1 && bGuild == FALSE )
				nResult++;
			else
			if( pQuestProp->m_nBeginCondGuild == 2 && bGuild == TRUE )
			{
				if( pQuestProp->m_nBeginCondGuildLeader == -1 || pQuestProp->m_nBeginCondGuildLeader == bLeader )
				{
					if( pQuestProp->m_nBeginCondGuildNum == 0 )
						nResult++;
					else
					if( pQuestProp->m_nBeginCondGuildNumComp == 0 )
					{
						if( nSize == pQuestProp->m_nBeginCondGuildNum )
							nResult++;
					}
					else
					if( pQuestProp->m_nBeginCondGuildNumComp == 1 )
					{
						if( nSize >= pQuestProp->m_nBeginCondGuildNum )
							nResult++;
					}	
					else
					if( pQuestProp->m_nBeginCondGuildNumComp == -1 )
					{
						if( nSize <= pQuestProp->m_nBeginCondGuildNum )
							nResult++;
					}			
				}
			}
		}
		// ¼ºº° 17
		if( pQuestProp->m_nBeginCondSex == -1 || pQuestProp->m_nBeginCondSex == pMover->GetSex() )
			nResult++;
		// ½ºÅ³ 18
		if( pQuestProp->m_nBeginCondSkillIdx == 0 )
			nResult++;
		else
		{
			LPSKILL lpSkill = pMover->GetSkill( pQuestProp->m_nBeginCondSkillIdx );
			if( lpSkill )
			{
				if( pMover->CheckSkill( pQuestProp->m_nBeginCondSkillLvl ) && lpSkill->dwLevel >= (DWORD)( pQuestProp->m_nBeginCondSkillLvl ) )
					nResult++;
			}
		}
#if __VER >= 8 // __S8_PK
		// PK Value 19
		if( pQuestProp->m_nBeginCondPKValue == 0 )
			nResult++;
		else
		{
			if( pQuestProp->m_nBeginCondPKValue <= pMover->GetPKValue() )			
				nResult++;
		}
		// ¾ÆÀÌÅÛÀÌ ¾ø´Â°Í °Ë»ç MAX_QUESTCONDITEM
		if( pQuestProp->m_nBeginCondNotItemNum == 0 )
			nResult += MAX_QUESTCONDITEM;
		else
		for( int i = 0; i < MAX_QUESTCONDITEM; i++ )
		{
			if( i < pQuestProp->m_nBeginCondNotItemNum )
			{
				QuestPropItem* pBeginCondItem = &pQuestProp->m_paBeginCondNotItem[ i ];
				if( pBeginCondItem->m_nSex == -1 || pBeginCondItem->m_nSex == pMover->GetSex() )
				{
					if( pBeginCondItem->m_nType == 0 )
					{
						if( pBeginCondItem->m_nJobOrItem == -1 || pBeginCondItem->m_nJobOrItem == pMover->GetJob() )
						{
							if( pBeginCondItem->m_nItemIdx == 0 || pMover->GetItemNum( pBeginCondItem->m_nItemIdx ) < pBeginCondItem->m_nItemNum ) 
								nResult++;
						}
						else
							nResult++;
					}
					else
					if( pBeginCondItem->m_nType == 1 )
					{
						if( pBeginCondItem->m_nJobOrItem == -1 || pMover->GetItemNum( pBeginCondItem->m_nJobOrItem ) )
						{
							if( pBeginCondItem->m_nItemIdx == 0 || pMover->GetItemNum( pBeginCondItem->m_nItemIdx ) < pBeginCondItem->m_nItemNum ) 
								nResult++;
						}
						else
							nResult++;
					}
				}
			}
			else
				nResult++;
		}
#else // __VER >= 8 // __S8_PK
		// Ä«¸£¸¶ 19
		if( pQuestProp->m_nBeginCondKarmaPoint == 0 )
			nResult++;
		else
		{
			if( pQuestProp->m_nBeginCondKarmaComp == 0 )
			{
				if( pMover->GetKarma() == pQuestProp->m_nBeginCondKarmaPoint )
					nResult++;
			}
			else
			if( pQuestProp->m_nBeginCondKarmaComp == -1 )
			{
				if( pMover->GetKarma() < pQuestProp->m_nBeginCondKarmaPoint )
					nResult++;
			}
			else
			if( pQuestProp->m_nBeginCondKarmaComp == 1 )
			{
				if( pMover->GetKarma() > pQuestProp->m_nBeginCondKarmaPoint )
					nResult++;
			}
		}
		// Ä«¿ÀÆ½ 20
		if( pQuestProp->m_nBeginCondChaotic == 0 )
			nResult++;
		else
		{
			if( pQuestProp->m_nBeginCondChaotic == 1 && pMover->IsChaotic() )
				nResult++;
			else
			if( pQuestProp->m_nBeginCondChaotic == 2 && pMover->IsChaotic() == FALSE )
				nResult++;
		}
#endif // __VER >= 8 // __S8_PK
		// º¯½Å 21 
		if( pQuestProp->m_nBeginCondDisguiseMoverIndex == 0 )
			nResult++;
		else
		{
			if( pQuestProp->m_nBeginCondDisguiseMoverIndex == -1 && pMover->IsDisguise() == FALSE )
				nResult++;
			else
			if( pQuestProp->m_nBeginCondDisguiseMoverIndex == pMover->GetIndex() )
				nResult++;
		}

#if __VER >= 9	// __PET_0410
		if( pQuestProp->m_nBeginCondPetExp == 0 )
			nResult++;
		else
		{
			CPet* pPet	= pMover->GetPet();
			if( pPet && pPet->GetExpPercent() >= pQuestProp->m_nBeginCondPetExp )
				nResult++;
		}
		if( pQuestProp->m_nBeginCondPetLevel == -1 )
			nResult++;
		else
		{
			CPet* pPet	= pMover->GetPet();
			if( pPet && pPet->GetLevel() == pQuestProp->m_nBeginCondPetLevel )
				nResult++;
		}
#endif	// __PET_0410
#if __VER >= 12 // __MOD_TUTORIAL
		if( pQuestProp->m_nBeginCondTutorialState == -1
			|| pMover->GetTutorialState() >= pQuestProp->m_nBeginCondTutorialState )
			nResult++;
#endif	// __MOD_TUTORIAL

		// ¼öÁý ¾ÆÀÌÅÛ °¹¼ö  21 + MAX_QUESTCONDITEM
		if( pQuestProp->m_nBeginCondItemNum == 0 )
			nResult += MAX_QUESTCONDITEM;
		else
		for( int i = 0; i < MAX_QUESTCONDITEM; i++ )
		{
			if( i < pQuestProp->m_nBeginCondItemNum )
			{
				QuestPropItem* pBeginCondItem = &pQuestProp->m_paBeginCondItem[ i ];
				if( pBeginCondItem->m_nSex == -1 || pBeginCondItem->m_nSex == pMover->GetSex() )
				{
					if( pBeginCondItem->m_nType == 0 )
					{
						if( pBeginCondItem->m_nJobOrItem == -1 || pBeginCondItem->m_nJobOrItem == pMover->GetJob() )
						{
							if( pBeginCondItem->m_nItemIdx == 0 || pMover->GetItemNum( pBeginCondItem->m_nItemIdx ) >= pBeginCondItem->m_nItemNum ) 
								nResult++;
						}
						else
							nResult++;
					}
					else
					if( pBeginCondItem->m_nType == 1 )
					{
						if( pBeginCondItem->m_nJobOrItem == -1 || pMover->GetItemNum( pBeginCondItem->m_nJobOrItem ) )
						{
							if( pBeginCondItem->m_nItemIdx == 0 || pMover->GetItemNum( pBeginCondItem->m_nItemIdx ) >= pBeginCondItem->m_nItemNum ) 
								nResult++;
						}
						else
							nResult++;
					}
				}
			}
			else
				nResult++;
		}
#if __VER >= 15 // __CAMPUS
		if( pQuestProp->m_nBeginCondTSP == 0 )
			++nResult;
		else
		{
			if( pMover->GetCampusPoint() >= pQuestProp->m_nBeginCondTSP )
				++nResult;
		}
#endif // __CAMPUS

#if __VER >= 12 // __MOD_TUTORIAL
#if __VER >= 15 // __CAMPUS
		if( nResult == 24 + MAX_QUESTCONDITEM + MAX_QUESTCONDITEM )
#else // __CAMPUS
		if( nResult == 23 + MAX_QUESTCONDITEM + MAX_QUESTCONDITEM )
#endif // __CAMPUS
#else	// __MOD_TUTORIAL
		if( nResult == 22 + MAX_QUESTCONDITEM + MAX_QUESTCONDITEM )
#endif	// __MOD_TUTORIAL
			return 1;
	}

	return 0;
}

#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
int __IsNextLevelQuest( CMover* pMover, int nQuestId )
{
	QuestProp* pQuestProp = prj.m_aPropQuest.GetAt( nQuestId );
	if( pQuestProp )
	{
		int nResult = 0;
		LPQUEST pCurQuest = pMover->GetQuest( nQuestId );
		BOOL bComplete = pMover->IsCompleteQuest( nQuestId );
		// Äù½ºÆ®°¡ Á¸ÀçÇÏ°Å³ª, ÀÌ¹Ì ¿Ï·áµÈ ÀûÀÌ ÀÖ´Â Äù½ºÆ®´Â Á¶°Ç ¼º¸³ ¾ÈµÊ. ¹Ýº¹ÇÏ±â À§ÇØ¼­´Â ¿ÏÀüÈ÷ Á¦°ÅÇÏ¿© ¿Ï·á ¹è¿­¿¡ ¾ø¾î¿© ÇÑ´Ù.
		if( pCurQuest || bComplete ) 
			return 0;

		// ÀÌÀü Äù½ºÆ® 1,2,3,4,5,6
		for( int i = 0; i < 6; i++ )
		{
			if( pQuestProp->m_anBeginCondPreviousQuest[ i ] == 0 ) 
				nResult++;
			else
			{
				LPQUEST pPreQuest = pMover->GetQuest( pQuestProp->m_anBeginCondPreviousQuest[ i ] );
				BOOL bPreComplete = pMover->IsCompleteQuest( pQuestProp->m_anBeginCondPreviousQuest[ i ] );
				if( pQuestProp->m_nBeginCondPreviousQuestType == 0 )
				{
					if( pPreQuest || bPreComplete )
						nResult++;
				}
				else
				if( pQuestProp->m_nBeginCondPreviousQuestType == 1 )
				{
					if( pPreQuest == NULL && bPreComplete )
						nResult++;
				}
				else
				if( pQuestProp->m_nBeginCondPreviousQuestType == 2 )
				{
					if( pPreQuest && bPreComplete == FALSE )
						nResult++;
				}
			}
		}
		// ÀÌÀü Äù½ºÆ® 7,8,9,10,11,12
		for( int i = 0; i < 6; i++ )
		{
			if( pQuestProp->m_anBeginCondExclusiveQuest[ i ] == 0 ) 
				nResult++;
			else
			{
				LPQUEST pPreQuest = pMover->GetQuest( pQuestProp->m_anBeginCondExclusiveQuest[ i ] );
				BOOL bPreComplete = pMover->IsCompleteQuest( pQuestProp->m_anBeginCondPreviousQuest[ i ] );
				if( pPreQuest == NULL && bPreComplete == FALSE )
					nResult++;
			}
		}
		// Á÷¾÷ 13
		if( pQuestProp->m_nBeginCondJobNum == 0 )
			nResult++;
		else
		for( int i = 0; i < pQuestProp->m_nBeginCondJobNum; i++ )
		{
			if( pQuestProp->m_nBeginCondJob[ i ] == pMover->GetJob() )
			{
				nResult++;
				break;
			}
		}
		// ·¹º§ 14
		if( pMover->GetLevel() < pQuestProp->m_nBeginCondLevelMin && pMover->GetLevel() + 5 >= pQuestProp->m_nBeginCondLevelMin )
			nResult++;
		// ÆÄÆ¼ ¿©ºÎ 15
		if( pQuestProp->m_nBeginCondParty == 0 )
			nResult++;
		else
		{
			BOOL bParty = FALSE;
			BOOL bLeader = FALSE;
			int nSize = 0;
#ifdef __WORLDSERVER
			CParty* pParty = g_PartyMng.GetParty( pMover->m_idparty );
			if( pParty )
			{
				bParty = TRUE;
				nSize = pParty->GetSizeofMember();
				
			}
#else
			bParty = g_Party.IsMember( g_pPlayer->m_idPlayer );
			nSize = g_Party.GetSizeofMember();
#endif
			if( pQuestProp->m_nBeginCondParty == 1 && bParty == FALSE )
				nResult++;
			else
			if( pQuestProp->m_nBeginCondParty == 2 && bParty == TRUE )
			{
				if( pQuestProp->m_nBeginCondPartyLeader == -1 || pQuestProp->m_nBeginCondPartyLeader == bLeader )
				{
					if( pQuestProp->m_nBeginCondPartyNum == 0 )
						nResult++;
					else
					if( pQuestProp->m_nBeginCondPartyNumComp == 0 )
					{
						if( nSize == pQuestProp->m_nBeginCondPartyNum )
							nResult++;
					}
					else
					if( pQuestProp->m_nBeginCondPartyNumComp == 1 )
					{
						if( nSize >= pQuestProp->m_nBeginCondPartyNum )
							nResult++;
					}	
					else
					if( pQuestProp->m_nBeginCondPartyNumComp == -1 )
					{
						if( nSize <= pQuestProp->m_nBeginCondPartyNum )
							nResult++;
					}			
				}
			}
		}
		// ±æµå ¿©ºÎ 16
		if( pQuestProp->m_nBeginCondGuild == 0 )
			nResult++;
		else
		{
			BOOL bGuild = FALSE;
			BOOL bLeader = FALSE;
			int nSize = 0;
			/*
#ifdef __WORLDSERVER
			g_PartyMng.m_AddRemoveLock.Enter( theLineFile );
			CParty* pParty = g_PartyMng.GetParty( pMover->m_idparty );
			if( pParty )
			{
				bParty = TRUE;
				nSize = pParty->GetSizeofMember();
			}
			g_PartyMng.m_AddRemoveLock.Leave( theLineFile );
#else
			bParty = g_Party.IsMember( g_pPlayer->m_idPlayer );
			nSize = g_Party.GetSizeofMember();
#endif
			*/
			if( pQuestProp->m_nBeginCondGuild == 1 && bGuild == FALSE )
				nResult++;
			else
			if( pQuestProp->m_nBeginCondGuild == 2 && bGuild == TRUE )
			{
				if( pQuestProp->m_nBeginCondGuildLeader == -1 || pQuestProp->m_nBeginCondGuildLeader == bLeader )
				{
					if( pQuestProp->m_nBeginCondGuildNum == 0 )
						nResult++;
					else
					if( pQuestProp->m_nBeginCondGuildNumComp == 0 )
					{
						if( nSize == pQuestProp->m_nBeginCondGuildNum )
							nResult++;
					}
					else
					if( pQuestProp->m_nBeginCondGuildNumComp == 1 )
					{
						if( nSize >= pQuestProp->m_nBeginCondGuildNum )
							nResult++;
					}	
					else
					if( pQuestProp->m_nBeginCondGuildNumComp == -1 )
					{
						if( nSize <= pQuestProp->m_nBeginCondGuildNum )
							nResult++;
					}			
				}
			}
		}
		// ¼ºº° 17
		if( pQuestProp->m_nBeginCondSex == -1 || pQuestProp->m_nBeginCondSex == pMover->GetSex() )
			nResult++;
		// ½ºÅ³ 18
		if( pQuestProp->m_nBeginCondSkillIdx == 0 )
			nResult++;
		else
		{
			LPSKILL lpSkill = pMover->GetSkill( pQuestProp->m_nBeginCondSkillIdx );
			if( lpSkill )
			{
				if( pMover->CheckSkill( pQuestProp->m_nBeginCondSkillLvl ) && (int)( lpSkill->dwLevel ) >= pQuestProp->m_nBeginCondSkillLvl )
					nResult++;
			}
		}
#if __VER >= 8 // __S8_PK
		// PK Value 19
		if( pQuestProp->m_nBeginCondPKValue == 0 )
			nResult++;
		else
		{
			if( pQuestProp->m_nBeginCondPKValue <= pMover->GetPKValue() )			
				nResult++;
		}
		// ¾ÆÀÌÅÛÀÌ ¾ø´Â°Í °Ë»ç MAX_QUESTCONDITEM
		if( pQuestProp->m_nBeginCondNotItemNum == 0 )
			nResult += MAX_QUESTCONDITEM;
		else
		for( int i = 0; i < MAX_QUESTCONDITEM; i++ )
		{
			if( i < pQuestProp->m_nBeginCondNotItemNum )
			{
				QuestPropItem* pBeginCondItem = &pQuestProp->m_paBeginCondNotItem[ i ];
				if( pBeginCondItem->m_nSex == -1 || pBeginCondItem->m_nSex == pMover->GetSex() )
				{
					if( pBeginCondItem->m_nType == 0 )
					{
						if( pBeginCondItem->m_nJobOrItem == -1 || pBeginCondItem->m_nJobOrItem == pMover->GetJob() )
						{
							if( pBeginCondItem->m_nItemIdx == 0 || pMover->GetItemNum( pBeginCondItem->m_nItemIdx ) < pBeginCondItem->m_nItemNum ) 
								nResult++;
						}
						else
							nResult++;
					}
					else
					if( pBeginCondItem->m_nType == 1 )
					{
						if( pBeginCondItem->m_nJobOrItem == -1 || pMover->GetItemNum( pBeginCondItem->m_nJobOrItem ) )
						{
							if( pBeginCondItem->m_nItemIdx == 0 || pMover->GetItemNum( pBeginCondItem->m_nItemIdx ) < pBeginCondItem->m_nItemNum ) 
								nResult++;
						}
						else
							nResult++;
					}
				}
			}
			else
				nResult++;
		}
#else // __VER >= 8 // __S8_PK
		// Ä«¸£¸¶ 19
		if( pQuestProp->m_nBeginCondKarmaPoint == 0 )
			nResult++;
		else
		{
			if( pQuestProp->m_nBeginCondKarmaComp == 0 )
			{
				if( pMover->GetKarma() == pQuestProp->m_nBeginCondKarmaPoint )
					nResult++;
			}
			else
			if( pQuestProp->m_nBeginCondKarmaComp == -1 )
			{
				if( pMover->GetKarma() < pQuestProp->m_nBeginCondKarmaPoint )
					nResult++;
			}
			else
			if( pQuestProp->m_nBeginCondKarmaComp == 1 )
			{
				if( pMover->GetKarma() > pQuestProp->m_nBeginCondKarmaPoint )
					nResult++;
			}
		}
		// Ä«¿ÀÆ½ 20
		if( pQuestProp->m_nBeginCondChaotic == 0 )
			nResult++;
		else
		{
			if( pQuestProp->m_nBeginCondChaotic == 1 && pMover->IsChaotic() )
				nResult++;
			else
			if( pQuestProp->m_nBeginCondChaotic == 2 && pMover->IsChaotic() == FALSE )
				nResult++;
		}
#endif // __VER >= 8 // __S8_PK
		// º¯½Å 21 
		if( pQuestProp->m_nBeginCondDisguiseMoverIndex == 0 )
			nResult++;
		else
		{
			if( pQuestProp->m_nBeginCondDisguiseMoverIndex == -1 && pMover->IsDisguise() == FALSE )
				nResult++;
			else
			if( pQuestProp->m_nBeginCondDisguiseMoverIndex == pMover->GetIndex() )
				nResult++;
		}

#if __VER >= 9	// __PET_0410
		if( pQuestProp->m_nBeginCondPetExp == 0 )
			nResult++;
		else
		{
			CPet* pPet	= pMover->GetPet();
			if( pPet && pPet->GetExpPercent() >= pQuestProp->m_nBeginCondPetExp )
				nResult++;
		}
		if( pQuestProp->m_nBeginCondPetLevel == -1 )
			nResult++;
		else
		{
			CPet* pPet	= pMover->GetPet();
			if( pPet && pPet->GetLevel() == pQuestProp->m_nBeginCondPetLevel )
				nResult++;
		}
#endif	// __PET_0410
#if __VER >= 12 // __MOD_TUTORIAL
		if( pQuestProp->m_nBeginCondTutorialState == -1
			|| pMover->GetTutorialState() >= pQuestProp->m_nBeginCondTutorialState )
			nResult++;
#endif	// __MOD_TUTORIAL

		// ¼öÁý ¾ÆÀÌÅÛ °¹¼ö  21 + MAX_QUESTCONDITEM
		if( pQuestProp->m_nBeginCondItemNum == 0 )
			nResult += MAX_QUESTCONDITEM;
		else
		for( int i = 0; i < MAX_QUESTCONDITEM; i++ )
		{
			if( i < pQuestProp->m_nBeginCondItemNum )
			{
				QuestPropItem* pBeginCondItem = &pQuestProp->m_paBeginCondItem[ i ];
				if( pBeginCondItem->m_nSex == -1 || pBeginCondItem->m_nSex == pMover->GetSex() )
				{
					if( pBeginCondItem->m_nType == 0 )
					{
						if( pBeginCondItem->m_nJobOrItem == -1 || pBeginCondItem->m_nJobOrItem == pMover->GetJob() )
						{
							if( pBeginCondItem->m_nItemIdx == 0 || pMover->GetItemNum( pBeginCondItem->m_nItemIdx ) >= pBeginCondItem->m_nItemNum ) 
								nResult++;
						}
						else
							nResult++;
					}
					else
					if( pBeginCondItem->m_nType == 1 )
					{
						if( pBeginCondItem->m_nJobOrItem == -1 || pMover->GetItemNum( pBeginCondItem->m_nJobOrItem ) )
						{
							if( pBeginCondItem->m_nItemIdx == 0 || pMover->GetItemNum( pBeginCondItem->m_nItemIdx ) >= pBeginCondItem->m_nItemNum ) 
								nResult++;
						}
						else
							nResult++;
					}
				}
			}
			else
				nResult++;
		}
#if __VER >= 15 // __CAMPUS
		if( pQuestProp->m_nBeginCondTSP == 0 )
			++nResult;
		else
		{
			if( pMover->GetCampusPoint() >= pQuestProp->m_nBeginCondTSP )
				++nResult;
		}
#endif // __CAMPUS

#if __VER >= 12 // __MOD_TUTORIAL
#if __VER >= 15 // __CAMPUS
		if( nResult == 24 + MAX_QUESTCONDITEM + MAX_QUESTCONDITEM )
#else // __CAMPUS
		if( nResult == 23 + MAX_QUESTCONDITEM + MAX_QUESTCONDITEM )
#endif // __CAMPUS
#else	// __MOD_TUTORIAL
		if( nResult == 22 + MAX_QUESTCONDITEM + MAX_QUESTCONDITEM )
#endif	// __MOD_TUTORIAL
			return 1;
	}

	return 0;
}
#endif // __IMPROVE_QUEST_INTERFACE

#if __VER >= 8 // __S8_PK
void CMover::SetPKValue( int nValue )
{
	if( nValue >= 0 )	// overflow!!
		m_nPKValue = nValue;
}
void CMover::SetPKPropensity( DWORD dwValue )
{
	int nValue = dwValue;
	
	if( nValue >= 0 )	// overflow!!
		m_dwPKPropensity = dwValue;
}

DWORD CMover::NextPKPropensity( int nPKValue )
{
	int nResult = 60 * nPKValue * nPKValue;
	if( nResult < 0 )	// overflow!!
		nResult = 0x7fffffff;
	return nResult;
}
#else // __VER >= 8 // __S8_PK
BOOL CMover::IsGuardReactionChao() 
{ 
	if( m_nSlaughter <= -2000 )
		return TRUE;

	return FALSE;
}

BOOL CMover::IsGuardReactionNormal() 
{ 
	if( m_nSlaughter > 0 )
		return TRUE;
	
	return FALSE;
}
#endif // __VER < 8 // __S8_PK

void CMover::SetJobLevel( int nLevel, int nJob )
{
#if 0
	if( IsBaseJob() )
	{
		m_aJobLv[ nJob ] = nLevel;
	}
	else
	{
		if( nLevel > MAX_EXPJOBLEVEL )
			m_aJobLv[ nJob ] = prj.m_aExpJobLevel[ MAX_EXPJOBLEVEL ];
		else
			m_aJobLv[ nJob ] = prj.m_aExpJobLevel[ nLevel ];
	}
#endif 
}

#ifdef __WORLDSERVER
void CMover::ProcessSFXDamage( void )
{
	ProcessSFXExpire();

//#ifdef __INFINITE_0227
//	DWORD dwTickCount	= GetTickCount();
//	int cbSFXInfo	= m_mapSFXInfo.size();
//	int cbSFXCount	= m_mapSFXCount.size();
//	int nInfo	= 0;
//	int nCount	= 0;
//#endif	// __INFINITE_0227

	map<OBJID, queue<SFXHIT_INFO> >::iterator iInfo	= m_mapSFXInfo.begin();
	while( iInfo != m_mapSFXInfo.end() )
	{
		map<OBJID, queue<SFXHIT_INFO> >::iterator iInfo2	= iInfo;
		++iInfo;
		OBJID idTarget	= iInfo2->first;
		queue<SFXHIT_INFO> &qInfo	= iInfo2->second;
		map<OBJID, queue<SFXHIT_COUNT> >::iterator iCount	= m_mapSFXCount.find( idTarget );
		if( iCount == m_mapSFXCount.end() )
			continue;
		queue<SFXHIT_COUNT> &qCount	= iCount->second;
		// qInfo, qCount
		while( qInfo.size() > 0 && qCount.size() > 0 )
		{
			SFXHIT_INFO &si	= qInfo.front();
			SFXHIT_COUNT &sc	= qCount.front();
			if( si.dwSkill == sc.dwSkill )
			{
//#ifdef __INFINITE_0227
//					nInfo++;
//					nCount++;
//#endif	// __INFINITE_0227
				if( AttackBySFX( this, si ) == FALSE )	// µ¥¹ÌÁö Ã³¸®
				{
					m_mapSFXInfo.erase( idTarget );
					m_mapSFXCount.erase( idTarget );
					break;
				}
				qInfo.pop();
				qCount.pop();
			}
			else
			{
				TRACE( "¿¹¿Ü Ã³¸®\n" );
				if( si.dwTickCount > sc.dwTickCount )
				{
					while( qCount.size() > 0 )
					{
//#ifdef __INFINITE_0227
//						nCount++;
//#endif	// __INFINITE_0227
						SFXHIT_COUNT &sc1	= qCount.front();
						if( si.dwSkill == sc1.dwSkill )
							break;
						qCount.pop();
					}
				}
				else if( si.dwTickCount < sc.dwTickCount )
				{
					while( qInfo.size() > 0 )
					{
//#ifdef __INFINITE_0227
//						nInfo++;
//#endif	// __INFINITE_0227
						SFXHIT_INFO &si1	= qInfo.front();
						if( si1.dwSkill == sc.dwSkill )
							break;
						qInfo.pop();
					}
				}
				else
				{
//#ifdef __INFINITE_0227
//					nInfo++;
//					nCount++;
//#endif	// __INFINITE_0227
					// print
					qInfo.pop();
					qCount.pop();
				}
			}
		}
	}

//#ifdef __INFINITE_0227
//	DWORD d	= GetTickCount() - dwTickCount;
//	if( d > 10 )	// > 10 ms
//		Error( "ProcessSFXDamage: %d ms, i = %d, c = %d, i2 = %d, c2 = %d, n = %s, j = %d",
//		d, cbSFXInfo, cbSFXCount, nInfo, nCount, m_szName, m_nJob );
//#endif	// __INFINITE_0227
}

void CMover::ProcessSFXExpire( void )
{
	DWORD dwTickCount	= GetTickCount();

//#ifdef __INFINITE_0227
//	int cbSFXInfo	= m_mapSFXInfo.size();
//	int cbSFXCount	= m_mapSFXCount.size();
//	int nInfo	= 0;
//	int nCount	= 0;
//#endif	// __INFINITE_0227
	
	// 1.1
	map<OBJID, queue<SFXHIT_INFO> >::iterator iInfo	= m_mapSFXInfo.begin();
	while( iInfo != m_mapSFXInfo.end() )
	{
		map<OBJID, queue<SFXHIT_INFO> >::iterator i2	= iInfo;
		++iInfo;
		OBJID idTarget	= i2->first;
		queue<SFXHIT_INFO> &q	= i2->second;
		
		while( q.size() > 0 )
		{
//#ifdef __INFINITE_0227
//			nInfo++;
//#endif	// __INFINITE_0227
			SFXHIT_INFO &si	= q.front();
			if( si.dwTickCount + SEC( 10 ) < dwTickCount )	// ¸¸·á ½Ã°£ °æ°ú
			{
				q.pop();	// ¸¸·á Á¤º¸ Á¦°Å
				TRACE( "idTarget=%d, INFO ¸¸·áÁ¤º¸ Á¦°Å µÊ\n", idTarget );
				continue;
			}
			else
				break;
		}
		if( q.size() == 0 )
		{
			m_mapSFXInfo.erase( idTarget );
			TRACE( "idTarget=%d, INFO ¿ÏÀü »èÁ¦\n", idTarget);
		}
	}
	// 1.2
	map<OBJID, queue<SFXHIT_COUNT> >::iterator iCount	= m_mapSFXCount.begin();
	while( iCount != m_mapSFXCount.end() )
	{
		map<OBJID, queue<SFXHIT_COUNT> >::iterator i2	= iCount;
		++iCount;
		OBJID idTarget	= i2->first;
		queue<SFXHIT_COUNT> &q	= i2->second;
		
		while( q.size() > 0 )
		{
//#ifdef __INFINITE_0227
//			nCount++;
//#endif	// __INFINITE_0227
			SFXHIT_COUNT &sc	= q.front();
			if( sc.dwTickCount + SEC( 10 ) < dwTickCount )	// ¸¸·á ½Ã°£ °æ°ú
			{
				q.pop();	// ¸¸·á Á¤º¸ Á¦°Å
				TRACE( "idTarget=%d, COUNT ¸¸·áÁ¤º¸ Á¦°Å µÊ\n", idTarget );
				continue;
			}
			else
				break;
		}
		if( q.size() == 0 )
		{
			m_mapSFXCount.erase( idTarget );
			TRACE( "idTarget=%d, COUNT ¿ÏÀü »èÁ¦\n", idTarget);
		}
	}
/*
#ifdef __INFINITE_0227
	DWORD	d	= GetTickCount() - dwTickCount;
	if( d > 10 )	// > 10 ms
		Error( "ProcessSFXExpire: %d ms, i = %d, c = %d, i2 = %d, c2 = %d, n = %s, j = %d",
		d, cbSFXInfo, cbSFXCount, nInfo, nCount, m_szName, m_nJob );
#endif	// __INFINITE_0227
*/
}
#endif	// __WORLDSERVER

#ifdef __CLIENT
void CMover::ProcessEyeFlash()
{
#if __VER >= 8 //__Y_EYE_FLASH_8
	if( IsPlayer() && m_pModel && HasBuffByIk3(IK3_TEXT_DISGUISE) == FALSE && IsDisguise() == FALSE )
	{
		CModelObject* pModelObj = (CModelObject*)m_pModel;
		
		O3D_ELEMENT* pElement = NULL;
		pElement = pModelObj->GetParts(PARTS_HEAD);
		
		if( pElement && pElement->m_pObject3D )
		{
			GMOBJECT* pGmObj = pElement->m_pObject3D->GetGMOBJECT(0);
			
			if( pGmObj )
			{
				if( m_fDistCamera <= 11.0f )
				{
					if( IsDie() )
					{
						(*pGmObj->m_pMtrlBlkTexture) = CMover::m_pTextureEyeFlash[m_bySex][m_dwHeadMesh];
					}
					else
					{
						if( m_tmEye[0].IsTimeOut() )
						{
							FLOAT fSec = 50;  // ±ô¹Ú°Å¸®´Â ½Ã°£...
							(*pGmObj->m_pMtrlBlkTexture) = CMover::m_pTextureEyeFlash[m_bySex][m_dwHeadMesh];
							m_tmEye[0].Set( fSec+1000 );
							m_tmEye[1].Set( fSec );
						}
						
						if( m_tmEye[1].IsTimeOut() )
						{
							// ´«¶°ÀÖ´Â ½Ã°£...
							FLOAT fSec = xRandomF( 2 ) + 5;
							fSec *= 1000.0f;

							if( xRandom( 100 ) < 10 )
								fSec = 500.0f;

							(*pGmObj->m_pMtrlBlkTexture) = CMover::m_pTextureEye[m_bySex][m_dwHeadMesh];
							m_tmEye[1].Set( fSec+1000 );
							m_tmEye[0].Set( fSec );
						}	
					}
				}
				else
				{
					if( IsDie() )
						(*pGmObj->m_pMtrlBlkTexture) = CMover::m_pTextureEyeFlash[m_bySex][m_dwHeadMesh];
					else
						(*pGmObj->m_pMtrlBlkTexture) = CMover::m_pTextureEye[m_bySex][m_dwHeadMesh];
				}
			}
		}
	}
#endif //__Y_EYE_FLASH_8
}

#if __VER >= 14 // __WING_ITEM
void CMover::WingMotionSetting( const CModelObject* pModel )
{
#ifdef __ANI_WING
	if (pModel == NULL || pModel->m_pBone == NULL)
		return;

	if (m_pRide == NULL || m_pRide->m_pBone == NULL)
		return;
#endif

	if( ( m_pActMover->GetState() & OBJSTA_STAND ) && ( D3DXVec3LengthSq( &m_pActMover->m_vDelta ) <= 0.000f ) && pModel->m_fFrameCurrent == 0.0f )
	{
		if( m_eWingStateFlag != FLOATING )
		{
			CString strMotion = m_pRide->GetMotionFileName( _T("stand") );
			assert( strMotion != _T("") );
			m_pRide->LoadMotion( strMotion );
			m_pRide->SetMotionBlending( TRUE );
			m_pRide->SetLoop( ANILOOP_LOOP );
			m_eWingStateFlag = FLOATING;
		}
	}
	else if( m_pActMover->GetStateFlag() & OBJSTAF_ACC )
	{
		if( m_eWingStateFlag != FLYING )
		{
			CString strMotion = m_pRide->GetMotionFileName( _T("walk") );
			assert( strMotion != _T("") );
			m_pRide->LoadMotion( strMotion );
			m_pRide->SetMotionBlending( TRUE );
			m_pRide->SetLoop( ANILOOP_LOOP );
			m_eWingStateFlag = FLYING;
		}
	}
	else if( ( m_pActMover->GetState() & OBJSTA_LTURN ) || ( m_pActMover->GetState() & OBJSTA_RTURN ) )
	{
		if( m_eWingStateFlag != TURNING )
			m_eWingStateFlag = TURNING;
	}
#ifdef __ANI_WING
	else if (+m_pMask != m_pRide && m_pMask != NULL && IsOptionRenderMask())
	{
		if ((m_pActMover->GetState() & OBJSTA_STAND && !m_pActMover->IsSit() && !m_pActMover->IsWalk()))
		{
			if (m_eWingStateFlag != FLOATING)
			{
				CString strMotion = m_pMask->GetMotionFileName("stand");
				assert(strMotion != "");
				m_pMask->LoadMotion(strMotion);
				m_pMask->SetMotionBlending(TRUE);
				m_pMask->SetLoop(ANILOOP_LOOP);
				m_eWingStateFlag = FLOATING;
			}
		}
		else if (m_pActMover->GetState() & OBJSTA_NOT_STAND || m_pActMover->IsWalk())
		{
			if (m_eWingStateFlag != FLYING)
			{
				CString strMotion = m_pMask->GetMotionFileName("walk");
				assert(strMotion != "");
				m_pMask->LoadMotion(strMotion);
				m_pMask->SetMotionBlending(TRUE);
				m_pMask->SetLoop(ANILOOP_LOOP);
				m_eWingStateFlag = FLYING;
			}
		}
		else if ((m_pActMover->GetState() & OBJSTA_LTURN) || (m_pActMover->GetState() & OBJSTA_RTURN) && !m_pActMover->IsWalk() && !m_pActMover->IsSit())
		{
			if (m_eWingStateFlag != TURNING)
				m_eWingStateFlag = TURNING;
		}
	}
#endif
}

float CMover::GetRideFrameSpeed( void )
{
	float fFrameSpeed = 1.0f;
	if (m_pRide
#ifdef __MOUNT
		|| m_pMountModel
#endif // __MOUNT
		)
	{
		float fNowLengthSq = D3DXVec3LengthSq( &m_pActMover->m_vDelta );
#ifdef __MOUNT
		if (GetMountId() > 0)
			fFrameSpeed = 1.0f + (fabs(fNowLengthSq - m_fOldLengthSq) * 100.0f);
		else
#endif // __MOUNT
		{
			fFrameSpeed = 1.0f + (fabs(fNowLengthSq - m_fOldLengthSq) * 7000.0f);
		}
		m_fOldLengthSq = fNowLengthSq;

		if( ( m_pActMover->GetStateFlag() & OBJSTAF_ACC ) && ( m_pActMover->GetStateFlag() & OBJSTAF_TURBO ) )// °¡¼Ó »óÅÂÀÌ°í ÅÍº¸ »óÅÂÀÏ ¶§
			fFrameSpeed += 1.2f;

		if( fFrameSpeed < 1.0f )
			fFrameSpeed = 1.0f;

		if( fFrameSpeed > 4.0f )
			fFrameSpeed = 4.0f;
	}
	return fFrameSpeed;
}
#endif // __WING_ITEM
#endif //__CLIENT

#ifdef __CLIENT
#if __VER >= 8 //__CSC_VER8_5
void CMover::CreateAngelParticle( D3DXVECTOR3 vPos )
{
	FLOAT fAngXZ, fAngH, fDist, fSpeed;
	D3DXVECTOR3 vVel;
		
	fAngXZ = GetAngle();
	fAngXZ += 180.0f; 
	fAngXZ = D3DXToRadian( fAngXZ );
	
	vPos.y += 1.1f;

	for( int j = 0; j < 2; j ++ )
	{
		vPos.y -= 0.03f;

		{
			fAngXZ = (float)(-45.0f + xRandomF(90));
			fAngXZ += GetAngle();
			fAngXZ += 180.0f;
			
			fAngXZ = D3DXToRadian( fAngXZ );
			fAngH = (float)(GetAngleX() + xRandomF(-30) + xRandomF(30) );
			fAngH = D3DXToRadian( fAngH );
			fSpeed = xRandomF(0.02f);
			
			fDist = cosf(-fAngH) * fSpeed;
			vVel.x = sinf(fAngXZ) * fDist;
			vVel.z = -cosf(fAngXZ) * fDist;
			vVel.y = -sinf(-fAngH) * fSpeed;		

			g_ParticleMng.CreateParticle( m_dwAngelKind + xRandom(3), vPos, vVel, GetPos().y + 0.5f );
		}	
	}
}
#endif //__CSC_VER8_5

#if __VER >= 9	// __PET_0410
void CMover::CreatePetParticle( D3DXVECTOR3 vPos )
{
	FLOAT fAngXZ, fAngH, fDist, fSpeed;
	D3DXVECTOR3 vVel;
	
	fAngXZ = GetAngle();
	fAngXZ += 180.0f; 
	fAngXZ = D3DXToRadian( fAngXZ );
	
	for( int j = 0; j < 4; j ++ )
	{
		vPos.y -= 0.03f;
		
		{
			fAngXZ = (float)(-45.0f + xRandomF(360));
			fAngXZ += GetAngle();
			fAngXZ += 180.0f;
			
			fAngXZ = D3DXToRadian( fAngXZ );
			fAngH = (float)(GetAngleX() + xRandomF(-130) + xRandomF(130) );
			fAngH = D3DXToRadian( fAngH );
			fSpeed = xRandomF(0.015f);
			
			fDist = cosf(-fAngH) * fSpeed;
			vVel.x = sinf(fAngXZ) * fDist;
			vVel.z = -cosf(fAngXZ) * fDist;
			vVel.y = -sinf(-fAngH) * fSpeed;
		
			g_ParticleMng.CreateParticle( 13 + xRandom(11), vPos, vVel, GetPos().y + 0.5f );
		}	
	}
}
#endif //__PET_0410

#endif //__CLIENT

#if __VER >= 9	// __PET_0410
void CMover::ProcessPet( void )
{
#ifdef __CLIENT
	// m_dwPetId °¡ Á¸ÀçÇÏ´Âµ¥, m_pPetÀÌ ¾øÀ¸¸é, »ý¼ºÇÑ´Ù.
	// »ý¼º½Ã, ActiveMoverÀÎ °æ¿ì¿Í, ¾Æ´Ñ°æ¿ì¸¦ ºÐ¸®ÇØ¼­ Ã³¸®ÇÑ´Ù.

	if( HasActivatedSystemPet() )
	{
		if( m_pet.GetObj() == NULL )
		{
			DWORD dwIndex	= 0;

			if( IsActiveMover() )
			{
				CItemElem* pItemElem	= GetPetItem();
				if( pItemElem && pItemElem->m_pPet )
					dwIndex	= pItemElem->m_pPet->GetIndex();
			}
			else	//
				dwIndex	= (DWORD)LOWORD( GetPetId() );
			
			if( dwIndex > 0 )
			{
				CMover* pPet	= (CMover *)CreateObj( D3DDEVICE, OT_MOVER, dwIndex );
#ifdef __PET_1024
				if( m_pet.HasName() )
					pPet->SetName( m_pet.GetName() );
#endif	// __PET_1024
				pPet->InitMotion( MTI_STAND );
				pPet->UpdateLocalMatrix();
				pPet->m_pAIInterface	= new CAIEgg( pPet, GetId() );
				pPet->m_dwAIInterface	= AII_EGG;
				pPet->m_dwAIInterfaceState	= 2;
				pPet->SetPos( GetPos() );
				pPet->m_vScrPos	= GetPos();
				GetWorld()->AddObj( pPet, FALSE );
				m_pet.SetObj( pPet );
				
				pPet->InitInterpolation();

				if( IsActiveMover() )
					lstrcpy( pPet->m_szCharacterKey, "MaFl_Pet" );
				CreatePetSfx();
				m_pet.SetLevelup( 0 );

				if( FALSE == g_WndMng.GetWndBase( APP_PET_STATUS ) && this->IsActiveMover() )
				{
					SAFE_DELETE( g_WndMng.m_pWndPetStatus );
					g_WndMng.m_pWndPetStatus = new CWndPetStatus;
					g_WndMng.m_pWndPetStatus->Initialize();
				}

			//	if( FALSE == g_WndMng.GetWndBase( APP_BUFFPET_STATUS ) )
			//	{
			//		SAFE_DELETE( g_WndMng.m_pWndBuffPetStatus );
			//		g_WndMng.m_pWndBuffPetStatus = new CWndBuffPetStatus;
			//		g_WndMng.m_pWndBuffPetStatus->Initialize();
		//		}
			}
		}				
	}
	else 
	{
		if( m_pet.GetObj() )
		{
			m_pet.GetObj()->Delete();
			m_pet.SetObj( NULL );
			
			if( g_WndMng.GetWndBase( APP_PET_STATUS )  && this->IsActiveMover() )
				g_WndMng.m_pWndPetStatus->Destroy();

		//	if( g_WndMng.GetWndBase( APP_BUFFPET_STATUS ) && this->IsActiveMover( ) )
		//		g_WndMng.m_pWndBuffPetStatus->Destroy();
		}
	}

	if( m_pet.GetObj() != NULL )
	{
		if(IsActiveMover())
		{
			CItemElem* m_pPetElem	= g_pPlayer->GetPetItem();
			if(m_pPetElem != NULL && m_pPetElem->m_pPet->GetLevel() == PL_S )
				CreatePetParticle( m_pet.GetObj()->GetScrPos());
		}
		else
		{
			DWORD dwLevel = (DWORD)HIWORD( GetPetId() );
			if(dwLevel == PL_S)
				CreatePetParticle( m_pet.GetObj()->GetScrPos());
		}
	}
#else	// __CLIENT
	ProcessPetAvail();
	ProcessPetEnergy();
	ProcessPetExp();
#if __VER >= 15 // __PETVIS
	ProcessVisPet();
#endif // __PETVIS
#endif	// __CLIENT
}

CItemElem* CMover::GetPetItem( void )
{
	if( HasActivatedSystemPet() )
	{
		CItemElem* pItemElem	= static_cast<CItemElem*>( GetItemId( m_dwPetId ) );
		if( pItemElem && pItemElem->IsPet() )
			return pItemElem;
	}
	return NULL;
}

CPet* CMover::GetPet( void )
{
	CItemElem* pItemElem	= GetPetItem();
	if( pItemElem )
		return pItemElem->m_pPet;
	return NULL;
}

void CMover::PetLevelup( void )
{
#ifdef __CLIENT
	if( m_pet.GetObj() )	// Á¦°Å ÇÏ¸é, ÇÁ·Î¼¼½º¿¡¼­ Àç»ý
	{
		m_pet.SetLevelup( PF_PET_LEVEL_UP );
		m_pet.GetObj()->Delete();
		m_pet.SetObj( NULL );
	}
#else	// __CLIENT
	CItemElem* pItemElem	= GetPetItem();
	CPet* pPet	= pItemElem->m_pPet;

	if( pPet->GetLevel() == PL_EGG )	// ºÎÈ­
	{
		pPet->SetKind( CPetProperty::GetInstance()->Hatch() );
		pPet->SetLife( 1 );
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
        ((CUser*)this)->SetHonorAdd(HS_HATCHING_EGG,HI_COUNT_CHECK);
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
	}

	pPet->IncLevel();
	pItemElem->m_dwItemId	= pPet->GetItemId();
	pPet->SetExp( 0 );
	pPet->SetEnergy( pPet->GetMaxEnergy() );
								
	BYTE nAvailLevel	= CPetProperty::GetInstance()->GetLevelupAvailLevel( pPet->GetLevel() );
	pPet->SetAvailLevel( pPet->GetLevel(), nAvailLevel );
	if( HasPet() )
		RemovePet();

	g_dpDBClient.CalluspPetLog( m_idPlayer, pItemElem->GetSerialNumber(), 0, PETLOGTYPE_LEVELUP, pPet );

	( (CUser*)this )->AddPet( pPet, PF_PET_LEVEL_UP );	// í»
	g_UserMng.AddPetLevelup( this, MAKELONG( (WORD)pPet->GetIndex(), (WORD)pPet->GetLevel() ) );	// öâ
#endif	// __CLIENT
}

#ifdef __WORLDSERVER
void CMover::ProcessPetAvail( void )
{
	CPet* pPet	= GetPet();
	if( pPet )
	{
		if( HasPet() == FALSE )
		{
			CItemElem* pItemElem	= GetPetItem();
			DWORD dwDestParam;
			int nParam;
			pPet->GetAvailDestParam( dwDestParam, nParam );
			if( dwDestParam > 0 )
			{
				// wID: dwItemId
				// dwLevel: dwDestParam(H) + nParam(L)
				AddBuff( BUFF_PET, (WORD)( pItemElem->m_dwItemId ), MAKELONG( (WORD)nParam, (WORD)dwDestParam ), 0 ); 
				SetDestParam( dwDestParam, nParam, NULL_CHGPARAM, TRUE );
			}
#if __VER >= 12 // __PET_0519
			SetDestParamRandomOptExtension( pItemElem );
#endif	// __PET_0519
		}
	}
	else
	{
		PetRelease();
	}
}

void CMover::ProcessPetEnergy( void )
{
//#ifdef __INTERNALSERVER
//	if( ( m_nCount & 3 ) != 0 )	// ±â·ÂÀÌ 0.2ÃÊ¿¡ 1p °¨¼Ò
//#else	// __INTERNALSERVER
	if( ( m_nCount & 15 ) != 0 )	// ±â·ÂÀÌ 1ÃÊ¿¡ 1p °¨¼Ò
//#endif	// __INTERNALSERVER
		return;

	CPet* pPet	= GetPet();
	if( pPet == NULL )
		return;

	if( pPet->GetLevel() == PL_EGG )
		return;

#ifndef __NO_PET_LIFE
	if (HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_PET_TONIC_A)
		|| HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_PET_TONIC_B)
		)	// ?? ???? ??????(A)	// ?? ???? ??????(B)	???? ??? ???? ????.
#endif
		return;
#if __VER >= 12 // __JHMA_VER12_1	//12Â÷ ±Ø´ÜÀ¯·á¾ÆÀÌÅÛ
	if( HasBuff( BUFF_ITEM2, II_SYS_SYS_SCR_SPETGOOD )
		&& pPet->GetLevel() == PL_S 
		)	// S±Þ Æê Àü¿ë ¸ÔÀÌ	
		return;
#endif // //12Â÷ ±Ø´ÜÀ¯·á¾ÆÀÌÅÛ

	// ÀÚµ¿ ¸ÔÀÌ °¡¹æ
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_PET_FEED_POCKET )
#ifdef __JEFF_11_1
		|| HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_PET_FEED_POCKET02 )
#endif	// __JEFF_11_1
		)
	{
		// ¸ÔÀÌ¸¦ °Ë»öÇØ¼­ °³¼ö¸¦ °¨¼Ò½ÃÅ²´Ù.
		CItemElem* ptr;
		int nMax	= m_Inventory.GetMax();
		for( int i = 0 ; i < nMax; i++ )
		{
			ptr	= m_Inventory.GetAtId( i );
			if( IsUsableItem( ptr ) && ptr->m_dwItemId == II_SYS_SYS_FEED_01 )	// »ç¿ë °¡´ÉÇÑ ¸ÔÀÌ¸é
			{
				if( ( m_nCount & 0X1F ) == 0 )	// 2ÃÊ´ç ¸ÔÀÌ 1¼Ò¸ð		// 0723
					UpdateItem( (BYTE)( ptr->m_dwObjId ), UI_NUM, ptr->m_nItemNum - 1 );
				return;
			}
		}
	}

	CItemElem* pItemElem	= GetPetItem();
	// ±â·ÂÀÌ 0ÀÌÇÏ¸é, »ý¸í 1 °¨¼Ò
	int nEnergy		= (int)pPet->GetEnergy();
	if( --nEnergy <= 0 )
	{
		int nLife	= (int)pPet->GetLife();
		if( --nLife >= 0 )
		{
			// »ý¸íÀÌ 0 ÀÌ»óÀÌ¸é, ºÎÈ°
			pPet->SetLife( nLife );
			pPet->SetEnergy( CPetProperty::GetInstance()->GetMaxEnergy( pPet->GetLevel() ) );
//			pPet->SetExp( 0 );
			
			g_dpDBClient.CalluspPetLog( m_idPlayer, pItemElem->GetSerialNumber(), 0, PETLOGTYPE_DEATH, pPet );
		}
		else
		{
			// »ý¸íÀÌ 0 ¹Ì¸¸ÀÌ¸é, ¿ÏÀü ¼Ò¸ê
			pPet->SetLife( 0 );
			pPet->SetEnergy( 0 );
			pPet->SetExp( 0 );
			// ¸¸·á ¾ÆÀÌÅÛÀÇ °æ¿ì, ¾ËÀÌ¸é »ç¸ÁÀÌ¶ó°í Ç¥½Ã
			pItemElem->SetFlag( CItemElem::expired );
			UpdateItem( (BYTE)( pItemElem->m_dwObjId ), UI_FLAG, MAKELONG( pItemElem->m_dwObjIndex, pItemElem->m_byFlag ) );

			g_dpDBClient.CalluspPetLog( m_idPlayer, pItemElem->GetSerialNumber(), 0, PETLOGTYPE_DEATH, pPet );

			// Æê ¼ÒÈ¯ ÇØÁ¦
			PetRelease();
		}
	}
	else
	{
		pPet->SetEnergy( nEnergy );
	}
	( (CUser*)this )->AddPetState( pItemElem->m_dwObjId , pPet->GetLife(), pPet->GetEnergy(), pPet->GetExp() );
}

void CMover::ProcessPetExp( void )
{
	if( ( m_nCount & 1023 ) != 0 )
		return;

	CPet* pPet	= GetPet();
	if( pPet == NULL )
		return;

	if( pPet->GetLevel() != PL_EGG && pPet->GetLevel() != PL_S )
	{
		if( pPet->GetExp() == MAX_PET_EXP )
#ifdef __PET_AUTO_LEVEL_UP
		{
			PetLevelup();
			PLAYSND("PCSkillCastCheer.wav");
		}
#else // __PET_AUTO_LEVEL_UP
			return;
#endif // __PET_AUTO_LEVEL_UP
#ifdef PETS_RATE
		float fFactor;

		if (HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_PET_TONIC_B)) {
			fFactor = 1.5f;
		}
		else {
			fFactor = 1.0f;
		}
		fFactor *= (float)(PETS_RATE);
#else // __PETS_RATE
		float fFactor;

		if (HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_PET_TONIC_B)) {
			fFactor = 1.5f;
		}
		else {
			fFactor = 1.0f;
		}
#endif // PETS_RATE
		
		// 100000 = 100%
#ifdef __DST_PET_EXPERIENCE
		int nDst = GetParam(DST_PET_EXPERIENCE, 0);
		fFactor = fFactor + ((float)nDst / 100.0f);
		DWORD dwExp = (DWORD)(pPet->GetExp() + CPetProperty::GetInstance()->GetIncrementExp(pPet->GetLevel()) * fFactor);
#else
		DWORD dwExp = (DWORD)(pPet->GetExp() + CPetProperty::GetInstance()->GetIncrementExp(pPet->GetLevel()) * fFactor);
#endif
		if( dwExp > MAX_PET_EXP )
			dwExp	= MAX_PET_EXP;
		pPet->SetExp( dwExp );
		( (CUser*)this )->AddPetSetExp( dwExp );
	}
}

#endif	// __WORLDSERVER

#ifdef __CLIENT
#ifdef __VOICE_LINES
void CMover::PlayClientVoiceLines(ItemProp* pSkillProp)
{
	DWORD voices[6];

	if (m_bySex == SEX_FEMALE)
	{
		if (pSkillProp->dwSkillType == KT_SKILL)
		{
			voices[0] = VOC_F_ONE_CLEANHIT;
			voices[1] = VOC_F_ONE_BRANDISH;
			voices[2] = VOC_F_ONE_OVERCUTTER;
			voices[3] = VOC_F_ONE_SPLMASH;
			voices[4] = VOC_F_ONE_KEENWHEEL;
			voices[5] = VOC_F_ONE_BLINDSIDE;
		}
		else
		{
			voices[0] = VOC_F_CHEER_CIRCLEHEALING;
			voices[1] = VOC_F_FIRE_BOOMERANG;
			voices[2] = VOC_F_FIRE_HOTAIR;
			voices[3] = VOC_F_FIRE_BOMB;
			voices[4] = VOC_F_WIND_SWORDWIND;
			voices[5] = VOC_F_WIND_STRONGWIND;
		}

		if (pSkillProp->nEvildoing == 1)
		{
			voices[0] = VOC_F_SHIELD_PROTECTION;
			voices[1] = VOC_F_SHIELD_PANBARRIER;
			voices[2] = VOC_F_HEAL_PATIENCE;
			voices[3] = VOC_F_CHEER_HEAPUP;
			voices[4] = VOC_F_CHEER_CANNONBALL;
			voices[5] = VOC_F_HEAL_HEALING;
		}
	}
	else
	{
		if (pSkillProp->dwSkillType == KT_SKILL)
		{
			voices[0] = VOC_M_ONE_CLEANHIT;
			voices[1] = VOC_M_ONE_BRANDISH;
			voices[2] = VOC_M_ONE_OVERCUTTER;
			voices[3] = VOC_M_ONE_SPLMASH;
			voices[4] = VOC_M_ONE_KEENWHEEL;
			voices[5] = VOC_M_ONE_BLINDSIDE;
		}
		else
		{
			voices[0] = VOC_M_CHEER_CIRCLEHEALING;
			voices[1] = VOC_M_FIRE_BOOMERANG;
			voices[2] = VOC_M_FIRE_HOTAIR;
			voices[3] = VOC_M_FIRE_BOMB;
			voices[4] = VOC_M_WIND_SWORDWIND;
			voices[5] = VOC_M_WIND_STRONGWIND;
		}

		if (pSkillProp->nEvildoing == 1)
		{
			voices[0] = VOC_M_SHIELD_PROTECTION;
			voices[1] = VOC_M_SHIELD_PANBARRIER;
			voices[2] = VOC_M_HEAL_PATIENCE;
			voices[3] = VOC_M_CHEER_HEAPUP;
			voices[4] = VOC_M_CHEER_CANNONBALL;
			voices[5] = VOC_M_HEAL_HEALING;
		}
	}

	int randomVoice = xRandom(6);
	PLAYSND(voices[randomVoice], &GetPos(), TRUE);
}
#endif //__VOICE_LINES

void	CMover::CreatePetSfx( void )
{
	CMover* pPet	= m_pet.GetObj();
	if( !pPet )
		return;

	switch( m_pet.GetLevelup() )
	{
		case PF_PET_LEVEL_UP:
			//level up Sound
			PLAYSND( "PCSkillCastCheer.wav" );
			//level up Effect
			break;
		case PF_PET_LEVEL_DOWN:	// ½ÅÂù : Æê Å×ÀÌ¸ÓÀÇ ½Ç¼ö »ç¿ë Á÷ÈÄ
			// °øÅë È¿°ú
			break;
		case PF_PET_GET_AVAIL:	// ½ÅÂù : Æê Å×ÀÌ¸ÓÀÇ ±âÀû »ç¿ë Á÷ÈÄ
			if( IsActiveMover() )
			{
				CWndPetMiracle* pWndMiracle = (CWndPetMiracle*)g_WndMng.GetWndBase( APP_PET_MIRACLE );
				if(pWndMiracle != NULL)
				{
					CPet* pCPet	= GetPet();
					int nLevel = pCPet->GetLevel();
					pWndMiracle->ReceiveResult(pCPet->GetAvailLevel(nLevel-1), pCPet->GetAvailLevel(nLevel)); 
				}
			}
			break;
	}
}
#endif	// __CLIENT

void CMover::PetRelease( void )
{
#ifdef __CLIENT
	if( m_pet.GetObj() )
	{
		m_pet.GetObj()->Delete();
		m_pet.SetObj( NULL );
	}
	SetPetId( NULL_ID );

#ifndef AISAKA
	PLAYSND("ItemGnCollector.wav");
#endif

#else	// __CLIENT
	CItemElem* pItemElem	= GetPetItem();
	if( !( pItemElem && pItemElem->m_pPet ) )
		return;
	CPetProperty* pProperty	= CPetProperty::GetInstance();
	CPet* pPet	= pItemElem->m_pPet;
	PPETPENALTY pPenalty	= pProperty->GetPenalty( pPet->GetLevel() );
	if( pPenalty )
	{
		if( pPenalty->fExp > 0.0f )
		{
			//Pet ¼ÒÈ¯ ÈÄ ÇØÁ¦ ½Ã D~A·¹º§¿¡¼± °æÇèÄ¡¸¦ ÀÒ°Ô µÇ¸ç,
			// ÃÖ¼Ò 0%¿¡¼­´Â ´õ ÀÌ»ó °¨¼ÒÇÏÁö ¾Ê´Â´Ù. 
			DWORD dwExp	= (DWORD)( 100000 * pPenalty->fExp / 100.0F );
			if( dwExp > pPet->GetExp() )
				dwExp	= pPet->GetExp();
			pPet->SetExp( pPet->GetExp() - dwExp );
		}
		if( pPenalty->wEnergy > 0 )
		{
			// S·¹º§¿¡¼± HP°¡ °¨¼ÒÇÏ¸ç, ÃÖ¼Ò 5P ÀÌÇÏ·Î´Â ´õ ÀÌ»ó °¨¼ÒÇÏÁö ¾Ê´Â´Ù. 
			int nHP	= (int)pPet->GetEnergy();
			int nPenalty	= (int)pPenalty->wEnergy;
			if( nHP < 5 )
				nPenalty	= 0;
			else if( nHP - nPenalty < 5 )
				nPenalty	= nHP - 5;
			pPet->SetEnergy( nHP - (WORD)nPenalty );
		}
		( (CUser*)this )->AddPetState( pItemElem->m_dwObjId, pPet->GetLife(), pPet->GetEnergy(), pPet->GetExp() );
	}

	if( HasPet() )
		RemovePet();
//#if __VER >= 12 // __PET_0519	// RemovePet() ¾ÈÀ¸·Î ÀÌµ¿
//	// ½Ã½ºÅÛ Æê ÇØÁ¦ ½Ã, ½Ã½ºÅÛ Æê °¢¼º È¿°ú Á¦°Å
//	ResetDestParamRandomOptExtension( pItemElem );
//#endif	// __PET_0519

	g_dpDBClient.CalluspPetLog( m_idPlayer, pItemElem->GetSerialNumber(), 0, PETLOGTYPE_RELEASE, pItemElem->m_pPet );
	SetPetId( NULL_ID );
	g_UserMng.AddPetRelease( this );
#endif	// __CLIENT
}

#endif	// __PET_0410

#if __VER >= 12 // __PET_0519
// 11Â÷ ÀÌÀü±îÁö ÇöÀç ¼ÒÈ¯ÁßÀÎ ¸ÔÆê È®ÀÎ ºÒ°¡
// ÀÌ¸¦ °¡´ÉÇÏ°Ô ÇÏ±â À§ÇØ ¸ÔÆê °´Ã¼¿¡ ¾ÆÀÌÅÛ ½Äº°ÀÚ¸¦ Ãß°¡ÇÔ
BOOL CMover::IsUsingEatPet( CItemElem* pItemElem )
{
	if( HasActivatedEatPet() )	// ¼ÒÈ¯ÁßÀÎ ¸ÔÆêÀÌ ÀÖÀ¸¸é
	{
		CMover* pEatPet		= prj.GetMover( GetEatPetId() );	// ¸ÔÆê °´Ã¼¸¦ Ã£¾Æ¼­
		if( IsValidObj( pEatPet ) )
		{
			// ¾ÆÀÌÅÛ ½Äº°ÀÚ°¡ °°À¸¸é ¼ÒÈ¯ÁßÀÎ ¸ÔÆêÀÌ´Ù
			CAIPet* pAIPet	= static_cast<CAIPet*>( pEatPet->m_pAIInterface );
			if( pAIPet && pAIPet->GetPetItemId() == pItemElem->m_dwObjId )
				return TRUE;
#ifdef __NEW_ITEM_VARUNA
			else if ( pItemElem->m_dwObjId == dwBarunaPetItemId )
				return TRUE;
#endif // __NEW_ITEM_VARUNA
		}
	}
	return FALSE;
}
#endif	// __PET_0519

BOOL CMover::IsUsing( CItemElem* pItemElem )
{	// »ç¿ëÁßÀÎ ¾ÆÀÌÅÛÀÎ°¡?
#ifdef __V21FIXES
	if (pItemElem->m_dwObjId == m_objIdVisPet)
		return TRUE;
#endif
#if __VER >= 12 // __PET_0519
	if( IsUsingEatPet( pItemElem ) )	// ¼ÒÈ¯ÁßÀÎ ¸ÔÆêÀÌ¸é
		return TRUE;
#else	// __PET_0519
	if( HasActivatedEatPet() && pItemElem->IsEatPet() )
		return TRUE;
#endif	// __PET_0519

#if __VER >= 9	// __PET_0410
	if( GetPetId() == pItemElem->m_dwObjId )
		return TRUE;

	if( pItemElem->m_dwItemId == II_SYS_SYS_SCR_PET_FEED_POCKET && pItemElem->m_dwKeepTime > 0
		&& HasBuff( BUFF_ITEM, (WORD)( pItemElem->m_dwItemId ) ) && !pItemElem->IsFlag( CItemElem::expired ))
			return TRUE;
#endif	// __PET_0410

#ifdef __SYS_TICKET
	if( pItemElem == GetTicket() )
		return TRUE;
#endif	// __SYS_TICKET

	return FALSE;
}
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ

void	CMover::SetHonorCount(int nIdx , int nCount )
{	
	if( nIdx < 0 || nIdx >= MAX_HONOR_TITLE)
		return;

	if( nCount < INT_MAX )
		m_aHonorTitle[nIdx] = nCount;	
}
void	CMover::SetHonorAdd(int nSmallIdx,int nLargeGroup,int nDefault )
{
#ifdef __WORLDSERVER
	ASSERT( IsPlayer() );
	HonorData*	pHonorData = CTitleManager::Instance()->GetHonorDataByID(nSmallIdx,nLargeGroup);
	if(pHonorData)
	{
		if( nDefault == 0)
			SetHonorCount(pHonorData->nID,m_aHonorTitle[pHonorData->nID] + 1);
		else
			SetHonorCount(pHonorData->nID,nDefault);
		if(pHonorData->nNeed == GetHonorTitle(pHonorData->nID) )
		{
#ifdef __BADGE
			((CUser*)this)->AddBadgeListUpdate();
#endif //__BADGE
			( (CUser*)this )->AddHonorListAck();
			g_dpDBClient.SendLogGetHonorTime(this,pHonorData->nID);
		}

	}

/*
		int nIdx = CTitleManager::Instance()->GetIdx(nSmallIdx,nLargeGroup);
		if( nIdx >= 0)
		{
			SetHonorCount(nIdx,m_aHonorTitle[nIdx] + 1);
			int nNeedCount = CTitleManager::Instance()->GetNeedCount(nSmallIdx,nLargeGroup);
			if( nNeedCount == GetHonorTitle(nIdx) )
			{
				( (CUser*)this )->AddHonorListAck();
				g_dpDBClient.SendLogGetHonorTime(this,nIdx);
			}
		}
*/
#endif	// __WORLDSERVER			
}

void	CMover::CheckHonorStat()
{
#ifdef __WORLDSERVER
	if( m_nHonor < -1 || m_nHonor >= MAX_HONOR_TITLE)
		m_nHonor = -1;

	int nIdx = 0;
	nIdx = CTitleManager::Instance()->GetIdx(JOB_KNIGHT_MASTER, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_KNIGHT_MASTER || m_nJob == JOB_KNIGHT_HERO || m_nJob == JOB_LORDTEMPLER_HERO || m_nJob == JOB_LORDTEMPLER_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_KNIGHT_MASTER || m_nJob == JOB_KNIGHT_HERO || m_nJob == JOB_LORDTEMPLER_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_KNIGHT_MASTER)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_BLADE_MASTER, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_BLADE_MASTER || m_nJob == JOB_BLADE_HERO || m_nJob == JOB_STORMBLADE_HERO || m_nJob == JOB_STORMBLADE_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_BLADE_MASTER || m_nJob == JOB_BLADE_HERO || m_nJob == JOB_STORMBLADE_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_BLADE_MASTER)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_JESTER_MASTER, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_JESTER_MASTER || m_nJob == JOB_JESTER_HERO || m_nJob == JOB_WINDLURKER_HERO || m_nJob == JOB_WINDLURKER_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_JESTER_MASTER || m_nJob == JOB_JESTER_HERO || m_nJob == JOB_WINDLURKER_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_JESTER_MASTER)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_RANGER_MASTER, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_RANGER_MASTER || m_nJob == JOB_RANGER_HERO || m_nJob == JOB_CRACKSHOOTER_HERO || m_nJob == JOB_CRACKSHOOTER_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_RANGER_MASTER || m_nJob == JOB_RANGER_HERO || m_nJob == JOB_CRACKSHOOTER_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_RANGER_MASTER)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_RINGMASTER_MASTER, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_RINGMASTER_MASTER || m_nJob == JOB_RINGMASTER_HERO || m_nJob == JOB_FLORIST_HERO || m_nJob == JOB_FLORIST_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_RINGMASTER_MASTER || m_nJob == JOB_RINGMASTER_HERO || m_nJob == JOB_FLORIST_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_RINGMASTER_MASTER)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_BILLPOSTER_MASTER, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_BILLPOSTER_MASTER || m_nJob == JOB_BILLPOSTER_HERO || m_nJob == JOB_FORCEMASTER_HERO || m_nJob == JOB_FORCEMASTER_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_BILLPOSTER_MASTER || m_nJob == JOB_BILLPOSTER_HERO || m_nJob == JOB_FORCEMASTER_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_BILLPOSTER_MASTER)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_PSYCHIKEEPER_MASTER, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_PSYCHIKEEPER_MASTER || m_nJob == JOB_PSYCHIKEEPER_HERO || m_nJob == JOB_MENTALIST_HERO || m_nJob == JOB_MENTALIST_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_PSYCHIKEEPER_MASTER || m_nJob == JOB_PSYCHIKEEPER_HERO || m_nJob == JOB_MENTALIST_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_PSYCHIKEEPER_MASTER)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_ELEMENTOR_MASTER, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_ELEMENTOR_MASTER || m_nJob == JOB_ELEMENTOR_HERO || m_nJob == JOB_ELEMENTORLORD_HERO || m_nJob == JOB_ELEMENTORLORD_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_ELEMENTOR_MASTER || m_nJob == JOB_ELEMENTOR_HERO || m_nJob == JOB_ELEMENTORLORD_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_ELEMENTOR_MASTER)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);


	nIdx = CTitleManager::Instance()->GetIdx(JOB_KNIGHT_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_KNIGHT_HERO || m_nJob == JOB_LORDTEMPLER_HERO || m_nJob == JOB_LORDTEMPLER_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_KNIGHT_HERO || m_nJob == JOB_LORDTEMPLER_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_KNIGHT_HERO)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_BLADE_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_BLADE_HERO || m_nJob == JOB_STORMBLADE_HERO || m_nJob == JOB_STORMBLADE_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_BLADE_HERO || m_nJob == JOB_STORMBLADE_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_BLADE_HERO)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_JESTER_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_JESTER_HERO || m_nJob == JOB_WINDLURKER_HERO || m_nJob == JOB_WINDLURKER_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_JESTER_HERO || m_nJob == JOB_WINDLURKER_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_JESTER_HERO)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_RANGER_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_RANGER_HERO || m_nJob == JOB_CRACKSHOOTER_HERO || m_nJob == JOB_CRACKSHOOTER_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_RANGER_HERO || m_nJob == JOB_CRACKSHOOTER_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_RANGER_HERO)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_RINGMASTER_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_RINGMASTER_HERO || m_nJob == JOB_FLORIST_HERO || m_nJob == JOB_FLORIST_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_RINGMASTER_HERO || m_nJob == JOB_FLORIST_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_RINGMASTER_HERO)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_BILLPOSTER_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_BILLPOSTER_HERO || m_nJob == JOB_FORCEMASTER_HERO || m_nJob == JOB_FORCEMASTER_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_BILLPOSTER_HERO || m_nJob == JOB_FORCEMASTER_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_BILLPOSTER_HERO)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_PSYCHIKEEPER_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_PSYCHIKEEPER_HERO || m_nJob == JOB_MENTALIST_HERO || m_nJob == JOB_MENTALIST_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_PSYCHIKEEPER_HERO || m_nJob == JOB_MENTALIST_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_PSYCHIKEEPER_HERO)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_ELEMENTOR_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_ELEMENTOR_HERO || m_nJob == JOB_ELEMENTORLORD_HERO || m_nJob == JOB_ELEMENTORLORD_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
	if (m_nJob == JOB_ELEMENTOR_HERO || m_nJob == JOB_ELEMENTORLORD_HERO)
#else // __3RD_LEGEND16
	if (m_nJob == JOB_ELEMENTOR_HERO)
#endif // __3RD_LEGEND16
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

#ifdef __3RD_LEGEND16
	nIdx = CTitleManager::Instance()->GetIdx(JOB_LORDTEMPLER_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_LORDTEMPLER_HERO || m_nJob == JOB_LORDTEMPLER_HERO_ULTIMATE)
#else // __NEWCLASS
	if (m_nJob == JOB_LORDTEMPLER_HERO)
#endif // __NEWCLASS
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_STORMBLADE_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_STORMBLADE_HERO || m_nJob == JOB_STORMBLADE_HERO_ULTIMATE)
#else // __NEWCLASS
	if (m_nJob == JOB_STORMBLADE_HERO)
#endif // __NEWCLASS
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_WINDLURKER_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_WINDLURKER_HERO || m_nJob == JOB_WINDLURKER_HERO_ULTIMATE)
#else // __NEWCLASS
	if (m_nJob == JOB_WINDLURKER_HERO)
#endif // __NEWCLASS
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_CRACKSHOOTER_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_CRACKSHOOTER_HERO || m_nJob == JOB_CRACKSHOOTER_HERO_ULTIMATE)
#else // __NEWCLASS
	if (m_nJob == JOB_CRACKSHOOTER_HERO)
#endif // __NEWCLASS
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_FLORIST_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_FLORIST_HERO || m_nJob == JOB_FLORIST_HERO_ULTIMATE)
#else // __NEWCLASS
	if (m_nJob == JOB_FLORIST_HERO)
#endif // __NEWCLASS
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_FORCEMASTER_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_FORCEMASTER_HERO || m_nJob == JOB_FORCEMASTER_HERO_ULTIMATE)
#else // __NEWCLASS
	if (m_nJob == JOB_FORCEMASTER_HERO)
#endif // __NEWCLASS
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_MENTALIST_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_MENTALIST_HERO || m_nJob == JOB_MENTALIST_HERO_ULTIMATE)
#else // __NEWCLASS
	if (m_nJob == JOB_MENTALIST_HERO)
#endif // __NEWCLASS
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);

	nIdx = CTitleManager::Instance()->GetIdx(JOB_ELEMENTORLORD_HERO, HI_EARN_TITLE);
#ifdef __NEWCLASS
	if (m_nJob == JOB_ELEMENTORLORD_HERO || m_nJob == JOB_ELEMENTORLORD_HERO_ULTIMATE)
#else // __NEWCLASS
	if (m_nJob == JOB_ELEMENTORLORD_HERO)
#endif // __NEWCLASS
	{
		SetHonorCount(nIdx, 1);
	}
	else
		SetHonorCount(nIdx, 0);
#endif // __3RD_LEGEND16

	nIdx = CTitleManager::Instance()->GetIdx(HS_STR, HI_COUNT_CHECK);
	SetHonorCount(nIdx, m_nStr);

	nIdx = CTitleManager::Instance()->GetIdx(HS_STA, HI_COUNT_CHECK);
	SetHonorCount(nIdx, m_nSta);


	nIdx = CTitleManager::Instance()->GetIdx(HS_DEX, HI_COUNT_CHECK);
	SetHonorCount(nIdx, m_nDex);

	nIdx = CTitleManager::Instance()->GetIdx(HS_INT, HI_COUNT_CHECK);
	SetHonorCount(nIdx, m_nInt);

//10	HI_COUNT_CHECK	HS_PVP_POINT01	10	IDS_TITLE_TXT_0011	//ÃÊº¸ ÆÄÀÌÅÍ			//	ÃÊº¸ ÆÄÀÌÅÍ
//11	HI_COUNT_CHECK	HS_PVP_POINT02	100	IDS_TITLE_TXT_0012	//°ß½À ÆÄÀÌÅÍ			//	°ß½À ÆÄÀÌÅÍ
//12	HI_COUNT_CHECK	HS_PVP_POINT03	1000	IDS_TITLE_TXT_0013	//³ë·ÂÇÏ´Â ÆÄÀÌÅÍ			//	³ë·ÂÇÏ´Â ÆÄÀÌÅÍ
//1/3	HI_COUNT_CHECK	HS_PVP_POINT04	4000	IDS_TITLE_TXT_0014	//ÆÐ±âÀÖ´Â ÆÄÀÌÅÍ			//	ÆÐ±âÀÖ´Â ÆÄÀÌÅÍ
//14	HI_COUNT_CHECK	HS_PVP_POINT05	10000	IDS_TITLE_TXT_0015	//¾Ë·ÁÁø ÆÄÀÌÅÍ			//	¾Ë·ÁÁø ÆÄÀÌÅÍ
//15	HI_COUNT_CHECK	HS_PVP_POINT06	20000	IDS_TITLE_TXT_0016	//°­ÇÑ ÆÄÀÌÅÍ			//	°­ÇÑ ÆÄÀÌÅÍ
//16	HI_COUNT_CHECK	HS_PVP_POINT07	50000	IDS_TITLE_TXT_0017	//À¯¸íÇÑ ÆÄÀÌÅÍ			//	À¯¸íÇÑ ÆÄÀÌÅÍ
//17	HI_COUNT_CHECK	HS_PVP_POINT08	1000000	IDS_TITLE_TXT_0018	//ÈÇ¸¢ÇÑ ÆÄÀÌÅÍ			//	ÈÇ¸¢ÇÑ ÆÄÀÌÅÍ
//18	HI_COUNT_CHECK	HS_PVP_POINT09	5000000	IDS_TITLE_TXT_0019	//ÀÎ±â¸¹Àº ÆÄÀÌÅÍ			//	ÀÎ±â¸¹Àº ÆÄÀÌÅÍ
//19	HI_COUNT_CHECK	HS_PVP_POINT10	100000000	IDS_TITLE_TXT_0020	//ÃÖ°­ÀÇ ÆÄÀÌÅÍ			//
	nIdx = CTitleManager::Instance()->GetIdx(HS_PVP_POINT01,HI_COUNT_CHECK);
	SetHonorCount(nIdx,m_nFame);

	nIdx = CTitleManager::Instance()->GetIdx(HS_PVP_POINT02,HI_COUNT_CHECK);
	SetHonorCount(nIdx,m_nFame);

	nIdx = CTitleManager::Instance()->GetIdx(HS_PVP_POINT03,HI_COUNT_CHECK);
	SetHonorCount(nIdx,m_nFame);

	nIdx = CTitleManager::Instance()->GetIdx(HS_PVP_POINT04,HI_COUNT_CHECK);
	SetHonorCount(nIdx,m_nFame);

	nIdx = CTitleManager::Instance()->GetIdx(HS_PVP_POINT05,HI_COUNT_CHECK);
	SetHonorCount(nIdx,m_nFame);

	nIdx = CTitleManager::Instance()->GetIdx(HS_PVP_POINT06,HI_COUNT_CHECK);
	SetHonorCount(nIdx,m_nFame);

	nIdx = CTitleManager::Instance()->GetIdx(HS_PVP_POINT07,HI_COUNT_CHECK);
	SetHonorCount(nIdx,m_nFame);

	nIdx = CTitleManager::Instance()->GetIdx(HS_PVP_POINT08,HI_COUNT_CHECK);
	SetHonorCount(nIdx,m_nFame);

	nIdx = CTitleManager::Instance()->GetIdx(HS_PVP_POINT09,HI_COUNT_CHECK);
	SetHonorCount(nIdx,m_nFame);

	nIdx = CTitleManager::Instance()->GetIdx(HS_PVP_POINT10,HI_COUNT_CHECK);
	SetHonorCount(nIdx,m_nFame);


	nIdx = CTitleManager::Instance()->GetIdx(HS_PK_COUNT,HI_COUNT_CHECK);
	SetHonorCount(nIdx,m_nPKValue);


	nIdx = CTitleManager::Instance()->GetIdx(HS_LORD,HI_EARN_TITLE);
	if( CSLord::Instance()->IsLord( m_idPlayer ) )
		SetHonorCount(nIdx,1);
	else
		SetHonorCount(nIdx,0);


	if (GetHonorTitle(m_nHonor) < CTitleManager::Instance()->GetNeedCount(m_nHonor, -1))
	{
		m_nHonor = -1;
	}

#endif	// __WORLDSERVER
}

void	CMover::CheckHonorTime()
{
#ifdef __WORLDSERVER
	// m_dwHonorCheckTime
	if( m_pActMover->GetActionState() == OBJSTA_COLLECT )	//Ã¤ÁýÁß
	{
		DWORD dwTick = GetTickCount();
		if( ( m_dwHonorCheckTime + 3600000 ) < dwTick )
		{
			m_dwHonorCheckTime = dwTick;
            ((CUser*)this)->SetHonorAdd(HS_COLLECT,HI_ELASPED_TIME);
		}
	}

	if( m_vtInfo.VendorIsVendor() || m_vtInfo.IsVendorOpen() )	//°³ÀÎ»óÁ¡Áß
	{
		DWORD dwTick = GetTickCount();
		if( ( m_dwHonorCheckTime + 3600000 ) < dwTick )
		{
			m_dwHonorCheckTime = dwTick;
            ((CUser*)this)->SetHonorAdd(HS_TRADE,HI_ELASPED_TIME);
		}
	}
#endif	// __WORLDSERVER
}

#endif	// __HONORABLE_TITLE			// ´ÞÀÎ

#if __VER >= 9	//__AI_0509
#ifdef __WORLDSERVER
BOOL CMover::IsReturnToBegin( void )
{
	if( m_pAIInterface )
		return m_pAIInterface->IsReturnToBegin();
	return FALSE;
}
#endif	// __WORLDSERVER

void CMover::SetSpeedFactor( FLOAT fSpeedFactor )
{
	if( fabs( m_fSpeedFactor - fSpeedFactor ) > 0.000001F )
	{
		m_fSpeedFactor	= fSpeedFactor;
#ifdef __WORLDSERVER
		g_UserMng.AddSetSpeedFactor( this, fSpeedFactor );
#endif	// __WORLDSERVER
	}
}
#endif	// __AI_0509

#if __VER >= 11 // __SYS_COLLECTING
void	CMover::ProcessCollecting( void )
{
#ifdef __CLIENT
	CItemElem* pCol		= GetCollector();
	// pCol	= Ã¤Áý±â
	if( pCol == NULL )	
	{
		// Åë»ó »óÅÂA
		g_WndMng.CloseCollecting();
	}
	else if( m_pActMover->GetActionState() == OBJSTA_COLLECT )
	{
		// Ã¤Áý »óÅÂ
		// SFX
		if( ( m_dwFlag & MVRF_COLLECT ) == 0 )
		{
			ItemProp *pHandProp	= GetActiveHandItemProp();
			if( pHandProp->dwSfxObj2 != NULL_ID )
			{
				D3DXVECTOR3 vSrc, vLocal	= D3DXVECTOR3( 0, 0.5f, 0 );
				( (CModelObject *)m_pModel )->GetForcePos( &vLocal, 0, PARTS_RWEAPON, GetMatrixWorld() );
				vSrc	= vLocal;
				CSfx *pSfx	= CreateSfx( D3DDEVICE, pHandProp->dwSfxObj2, vSrc, GetId(), D3DXVECTOR3( 0, 0, 0 ), NULL_ID, -1 );
				if( pSfx )
				{
					pSfx->SetAngle( -GetAngle() + 90.0f );
					//pSfx->SetAngleX(90.0f);
					m_dwFlag	|= MVRF_COLLECT;
				}
			}
			if(g_WndMng.m_pWndCollecting) g_WndMng.m_pWndCollecting->SetButtonCaption(true);
		}	// SFX
		if(g_WndMng.m_pWndCollecting) g_WndMng.m_pWndCollecting->Update();
			if(m_nCltTime < m_nMaxCltTime) ++m_nCltTime;
			else if(m_nCltTime >= m_nMaxCltTime) m_nCltTime = m_nMaxCltTime;
	}
	else
	{
		// Ã¤Áý ´ë±â »óÅÂ
		g_WndMng.OpenCollecting();
		g_WndMng.m_pWndCollecting->SetButtonCaption(false);
		g_WndMng.m_pWndCollecting->Update();
	}
#endif	// __CLIENT
}

void	CMover::StartCollecting( void )
{
	ClearDest();
	m_dwFlag |= MVRF_NOACTION;
	m_dwMode |= DONMOVE_MODE;
	SendActMsg( OBJMSG_STOP );
	SendActMsg( OBJMSG_COLLECT );
#ifdef __CLIENT
	CItemElem*			 pCollector = GetCollector();
	CCollectingProperty* pProperty	= CCollectingProperty::GetInstance();
#ifdef __SECURITY_FIXES
	if (!pProperty)
		return;
#endif // __SECURITY_FIXES
#ifdef __DST_COLLECTOR_TIME
	if (pCollector)
	{
		m_nMaxCltTime = pProperty->GetCool(pCollector->GetAbilityOption()) + 1;
		int nDst = GetParam(DST_COLLECTOR_TIME, 0);

		if (nDst)
			m_nMaxCltTime = (int)(m_nMaxCltTime * (100.f - nDst) / 100.0f);
	}
#else // __DST_COLLECTOR_TIME
	if (pCollector) m_nMaxCltTime = pProperty->GetCool(pCollector->GetAbilityOption()) + 1;
#endif // __DST_COLLECTOR_TIME
	m_nCltTime = 0;
#endif	// __CLIENT
}

void	CMover::StopCollecting( void )
{
	m_dwFlag &= (~MVRF_NOACTION);
	m_dwMode &= (~DONMOVE_MODE);
	m_pActMover->ResetState( OBJSTA_ACTION_ALL );
	m_pActMover->SetMoveState( OBJSTA_STAND );
	m_pActMover->RemoveStateFlag( OBJSTAF_ETC );
	SetMotion( MTI_STAND );
}

CItemElem* CMover::GetCollector( void )
{
	CItemElem* pCol		= GetWeaponItem();
	if( pCol && ( !pCol->IsCollector() || pCol->IsFlag( CItemElem::expired ) ) )
		pCol	= NULL;
	return pCol;
}
#endif	// __SYS_COLLECTING

#if __VER >= 11 // __SYS_POCKET
CItemElem*	CMover::GetItemId2( int nPocket, int nItem, BOOL bExpiration )
{
	if( nPocket < 0 )
		return m_Inventory.GetAtId( nItem );
	return m_Pocket.GetAtId( nPocket, nItem, bExpiration );
}

#if (defined (__BAG_LOOT) && defined (__DROP_LOG)) || (defined (__BAG_LOOT) && defined (__FL_FARM_STAT))
BOOL	CMover::CreateItem2(CItemElem* pItem, int nPocket, BOOL bAddDropLog)
#else
BOOL	CMover::CreateItem2(CItemElem* pItem, int nPocket)
#endif
{
#ifdef __WORLDSERVER
	if( nPocket < 0 )
		return CreateItem( pItem );
#endif	// __WORLDSERVER
#if (defined (__BAG_LOOT) && defined (__DROP_LOG)) || (defined (__BAG_LOOT) && defined (__FL_FARM_STAT))
	return m_Pocket.Add(nPocket, pItem, NULL, bAddDropLog);
#else
	return m_Pocket.Add(nPocket, pItem);
#endif
}

void	CMover::RemoveItem2( int nItem, short nNum, int nPocket )
{
#ifdef __WORLDSERVER
	if( nPocket < 0 )
		RemoveItem( nItem, nNum );
	else
#endif	// __WORLDSERVER
		m_Pocket.RemoveAtId( nPocket, nItem, nNum );
}
#endif	// __SYS_POCKET

#ifdef __SYS_TICKET
CItemElem*	CMover::GetTicket( void )
{
#ifdef __BUFF_1107
	IBuff* pBuff	= m_buffs.GetBuffByIk3( IK3_TICKET );
	if( !pBuff )
		return NULL;
#else	// __BUFF_1107
	LPSKILLINFLUENCE pInfluence		= m_SkillState.GetItemBuf( IK3_TICKET );
	if( !pInfluence )
		return NULL;
#endif	// __BUFF_1107

	CItemElem* pTicket;
	for( DWORD i = 0; i < m_Inventory.m_dwItemMax; i++ )
	{
		pTicket		= m_Inventory.GetAtId( i );
		if( pTicket && pTicket->m_dwKeepTime > 0 && pTicket->GetProp()->dwItemKind3 == IK3_TICKET
#ifdef __BUFF_1107
			&&  pTicket->m_dwItemId == (DWORD)pBuff->GetId()
#else	// __BUFF_1107
			&&  pTicket->m_dwItemId == (DWORD)pInfluence->wID
#endif	// __BUFF_1107
			&& !pTicket->IsFlag( CItemElem::expired ) )
			return pTicket;
	}
	return NULL;
}
#endif	// __SYS_TICKET

BOOL CMover::IsShoutFull( void )
{
	return	( IsSMMode( SM_SHOUT15 ) || IsSMMode( SM_SHOUT30 ) || IsSMMode( SM_SHOUT001 ) );
}

BOOL CMover::IsCommBank( void )
{
	return	( IsSMMode( SM_BANK15 ) || IsSMMode( SM_BANK30 ) || IsSMMode( SM_BANK001 ) );
}

#ifdef __BS_EFFECT_LUA
const char* CMover::GetNameO3D( )
{
	CObject3D* pObj = ((CModelObject*)m_pModel)->GetObject3D( );
	if( !pObj )
	{
		Error( "CMover::GetNameO3D, pObj == NULL" );
		return NULL;
	}

	return pObj->m_szFileName;
}

BOOL CMover::SetDataMTE( const char* alphaTex, const char* eff2ndTex )
{
	// ÁøÂ¥ ½á¾ßÇÒ¶§ È£ÃâµÈ´Ù.
	// ÀÌ¶§ ºñ·Î¼Ò m_pMteData°¡ ÇÒ´çµÈ´Ù.

	CObject3D* pObj = ((CModelObject*)m_pModel)->GetObject3D( );
	if( !pObj )
	{
		Error( "CMover::GetNameO3D, pObj == NULL" );
		return FALSE;
	}

	if( NULL == pObj->m_pMteData )
		pObj->m_pMteData = new CObject3D::MTE_DATA;

	CObject3D::MTE_DATA* pData = pObj->m_pMteData;

	char	szAlphaTexture[MAX_PATH];
	GetFileTitle( alphaTex, szAlphaTexture );
	strcat( szAlphaTexture, "-ef01.tga" );
	
#ifdef __MASQUERADE
	if (g_Option.m_bMasqueradeFiles)
	{
		pData->_pTex[0] = TexturePool::Get()->GetTexture(DIR_SFXTEX_M, std::string(szAlphaTexture));
		pData->_pTex[1] = TexturePool::Get()->GetTexture(DIR_SFXTEX_M, std::string(eff2ndTex));
	}
	else
#endif // __MASQUERADE
	{
		pData->_pTex[0] = TexturePool::Get()->GetTexture(DIR_SFXTEX, std::string(szAlphaTexture));
		pData->_pTex[1] = TexturePool::Get()->GetTexture(DIR_SFXTEX, std::string(eff2ndTex));
	}

	if( NULL == pData->_pTex[ 0 ] || NULL == pData->_pTex[ 1 ] )
	{
		Error( "Failed loading MTE texture %s or %s", szAlphaTexture, eff2ndTex );
		return FALSE;
	}
	
	//ok... now you can use this data
	return TRUE;
}

#endif //__BS_EFFECT_LUA

#if __VER >= 12 // __LORD
int CMover::GetPerinNum( void )
{
	int nPerin	= 0;
	for( int i = 0; i < m_Inventory.GetMax(); i++ )
	{
		CItemElem* pItem	= static_cast<CItemElem*>( GetItemId( i ) );
		if( pItem && pItem->IsPerin() && ::IsUsableItem( pItem ) )
			nPerin	+= pItem->m_nItemNum;
	}
	return nPerin;
}

// ¼ÒÀ¯ÇÏ°íÀÖ´Â Æä¸°°ú Æä³ÄÀÇ ÇÕÀ» ¹ÝÈ¯ÇÑ´Ù.
__int64 CMover::GetTotalGold( void )
{
	return static_cast<__int64>( GetPerinNum() ) * PERIN_VALUE + static_cast<__int64>( GetGold() );
}

#ifdef __WORLDSERVER
int CMover::RemovePerin( int nPerin )
{
	int nRest	= nPerin;
	for( int i = 0; i < m_Inventory.GetMax() && nRest > 0; i++ )
	{
		CItemElem* pItem	= static_cast<CItemElem*>( GetItemId( i ) );
		if( pItem && pItem->IsPerin() && ::IsUsableItem( pItem ) )
		{
			int nRemove		= nRest >= pItem->m_nItemNum? pItem->m_nItemNum: nRest;
			UpdateItem( i, UI_NUM, pItem->m_nItemNum - nRemove );
			nRest	-= nRemove;
		}
	}
	return nPerin - nRest;
}

// iGold¸¸Å­ÀÇ Æä¸°°ú Æä³Ä¸¦ ¼Ò¸ðÇÏ°í ÀÌ¸¦ Å¬¶óÀÌ¾ðÆ® Åëº¸ÇÑ´Ù.
// Ë¬ 2008-10-08: ¼öÁ¤
int CMover::RemoveTotalGold( __int64 iGold )
{
	ASSERT( iGold <= GetTotalGold() );
	int nPerin	= (int)( RemovePerin( (int)( iGold / PERIN_VALUE ) ) );
	__int64 iRest	= iGold - ( static_cast<__int64>( nPerin ) * PERIN_VALUE );
	if( iRest > GetGold() )		// Æä³Ä°¡ ¸ðÀÚ¸£¸é
	{
		RemovePerin( 1 );	// 1¾ï Æä³Ä¸¦ Ãß°¡ »èÁ¦ÇÏ°í,
		iRest	=  -( PERIN_VALUE - iRest );	// '1¾ï - ³ª¸ÓÁö' Æä³Ä¸¦ ´õÇÏµµ·Ï ºÎÈ£¸¦ ¹Ù²Û´Ù.
	}
	AddGold( static_cast<int>( -iRest ), TRUE );
	return nPerin;
}
#endif	// __WORLDSERVER
#endif	// __LORD

#ifdef __WORLDSERVER
void CMover::AddSfxSnd(DWORD dwSfx, DWORD dwSound)
{
	CUser* pUser = ((CUser*)this);
	if (IsValidObj(pUser) && pUser->IsMode(TRANSPARENT_MODE) == 0)
	{
		g_UserMng.AddCreateSfxObj(pUser, dwSfx, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
		pUser->AddPlaySound(dwSound);
	}
}
#endif // __WORLDSERVER

#ifdef __CLIENT
CClientPet::CClientPet()
:
m_pObj( NULL ),
m_nLevelup( 0 )
{
#ifdef __PET_1024
	m_szName[0]		= '\0';
#endif	// __PET_1024
}

CClientPet::~CClientPet()
{
}

#ifdef __PET_1024
void CClientPet::SetName( char * szName )
{
	strncpy( m_szName, szName, MAX_PET_NAME-1 );
	m_szName[MAX_PET_NAME-1]		= '\0';
}
#endif	// __PET_1024
#endif	// __CLIENT

#ifdef __BAG_UPDATE
BOOL CMover::CanBeUsedInBag(ItemProp* pItemProp)
{
	if (pItemProp)
	{
		if (pItemProp->dwParts != NULL_ID)
			return FALSE;

		if (pItemProp->dwItemKind3 == IK3_EGG || pItemProp->dwItemKind3 == IK3_PET)
			return FALSE;

		if (pItemProp->dwItemKind2 == IK2_MATERIAL || pItemProp->dwItemKind3 == IK3_RANDOM_SCROLL)
			return FALSE;

		if (pItemProp->dwItemKind3 == IK3_TICKET)
			return FALSE;

		if (IsNeedTarget(pItemProp))
			return FALSE;

		if (pItemProp->dwItemKind3 == IK3_CREATE_MONSTER)
			return FALSE;

		if (pItemProp->dwItemKind2 == IK2_BLINKWING)
			return FALSE;

		if (pItemProp->dwItemKind2 == IK2_TREASURE)
			return FALSE;

		if (pItemProp->dwItemKind2 == IK2_GEM || pItemProp->dwItemKind3 == IK3_GEM)
			return FALSE;

#if defined (__OFFLINE_VENDOR) || defined (__OFFLINE_VENDORS_V2)
		if (pItemProp->dwItemKind3 == IK3_VENDING)
			return FALSE;
#endif

		if (m_vtInfo.GetOther())
			return FALSE;

		if (m_vtInfo.VendorIsVendor())
			return FALSE;

		return TRUE;

	}

	return FALSE;
}
#endif

#ifdef __MOUNT
#ifdef __CLIENT
void CMover::MountMotion(CModelObject* pModel)
{
	if (m_pMountModel == NULL && m_pMountModel->m_pBone == NULL)
		return;

	MOUNT_ANIMATION* pMount = prj.GetMountAnimation(m_dwMountItemID);
	if (pMount)
	{
		if (m_pMountModel->m_pMotion->m_szName == m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_FLY_GROUND)->second))
		{
			if (m_pMountModel->IsEndFrame())
				g_DPlay.SendUpdateMount(2);
		}
		else if (!IsFly()
			&& (m_pActMover->GetState() & OBJSTA_STAND)
			&& (D3DXVec3LengthSq(&m_pActMover->m_vDelta) <= 0.0001f)
			&& ((m_pMountModel->m_pMotion->m_szName != m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_STAND)->second)
				&& m_pMountModel->m_pMotion->m_szName != m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_IDLE1)->second)
				&& m_pMountModel->m_pMotion->m_szName != m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_IDLE2)->second)
				&& m_pMountModel->m_pMotion->m_szName != m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_FLY_GROUND)->second))
				|| m_pMountModel->IsEndFrame())
			)
		{
			if (xRandom(5000) < 2)
			{
				if (m_eMountState != GROUND_IDLE1)
				{
					CString strMotion = m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_IDLE1)->second);
					assert(strMotion != _T(""));
					m_pMountModel->LoadMotion(strMotion);
					m_pMountModel->SetMotionBlending(TRUE);
					m_pMountModel->SetLoop(ANILOOP_LOOP);
					m_eMountState = GROUND_IDLE1;
				}
			}
			else if (xRandom(2000) < 2)
			{
				if (m_eMountState != GROUND_IDLE2)
				{
					CString strMotion = m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_IDLE2)->second);
					assert(strMotion != _T(""));
					m_pMountModel->LoadMotion(strMotion);
					m_pMountModel->SetMotionBlending(TRUE);
					m_pMountModel->SetLoop(ANILOOP_LOOP);
					m_eMountState = GROUND_IDLE2;
				}
			}
			else
			{
				if (m_eMountState != GROUND_STAND)
				{
					CString strMotion = m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_STAND)->second);
					assert(strMotion != _T(""));
					m_pMountModel->LoadMotion(strMotion);
					m_pMountModel->SetMotionBlending(TRUE);
					m_pMountModel->SetLoop(ANILOOP_LOOP);
					m_eMountState = GROUND_STAND;
				}
			}
		}
		else if (IsFly()
			&& (D3DXVec3LengthSq(&m_pActMover->m_vDelta) <= 0.001f)
			&& ((m_pMountModel->m_pMotion->m_szName != m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_FLY_STAND)->second)
				&& m_pMountModel->m_pMotion->m_szName != m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_FLY_IDLE1)->second)
				&& m_pMountModel->m_pMotion->m_szName != m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_FLY_IDLE2)->second)
				&& m_pMountModel->m_pMotion->m_szName != m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_FLY_GROUND)->second))
				|| m_pMountModel->IsEndFrame())
			)
		{
			if (xRandom(5000) < 2)
			{
				if (m_eMountState != FLY_IDLE1)
				{
					CString strMotion = m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_FLY_IDLE1)->second);
					assert(strMotion != _T(""));
					m_pMountModel->LoadMotion(strMotion);
					m_pMountModel->SetMotionBlending(TRUE);
					m_pMountModel->SetLoop(ANILOOP_LOOP);
					m_eMountState = FLY_IDLE1;
				}
			}
			else if (xRandom(2000) < 2)
			{
				if (m_eMountState != FLY_IDLE2)
				{
					CString strMotion = m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_FLY_IDLE2)->second);
					assert(strMotion != _T(""));
					m_pMountModel->LoadMotion(strMotion);
					m_pMountModel->SetMotionBlending(TRUE);
					m_pMountModel->SetLoop(ANILOOP_LOOP);
					m_eMountState = FLY_IDLE2;
				}
			}
			else
			{
				if (m_eMountState != FLY_STAND)
				{
					CString strMotion = m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_FLY_STAND)->second);
					assert(strMotion != _T(""));
					m_pMountModel->LoadMotion(strMotion);
					m_pMountModel->SetMotionBlending(TRUE);
					m_pMountModel->SetLoop(ANILOOP_LOOP);
					m_eMountState = FLY_STAND;
				}
			}
		}
		else if (IsFly() && m_pActMover->GetStateFlag() & OBJSTAF_ACC && D3DXVec3LengthSq(&m_pActMover->m_vDelta) > 0.001f)
		{
			if (m_eMountState != FLY_WALK)
			{
				CString strMotion = m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_FLY_WALK)->second);
				assert(strMotion != _T(""));
				m_pMountModel->LoadMotion(strMotion);
				m_pMountModel->SetMotionBlending(TRUE);
				m_pMountModel->SetLoop(ANILOOP_LOOP);
				m_eMountState = FLY_WALK;
			}
		}
	}
}
#endif // __CLIENT
#endif // __MOUNT

#ifdef __LNB_ANIMATED_HATS
void CMover::InitializeAnimatedHat(DWORD dwItemId)
{
	ItemProp* pProp = prj.GetItemProp(dwItemId);
	if (!pProp)
		return;

	if (!(pProp->dwItemKind3 == IK3_ANIHAT))
		return;

	CModel* pModel = prj.m_modelMng.LoadModel(D3DDEVICE, OT_ITEM, pProp->dwID);
	SetAnimatedHat((CModelObject*)pModel);
}
#endif

#if defined(__WINGSFX) && defined(__CLIENT) //Aisaka
const void CMover::SetWingSfx(const DWORD dwSfx)
{
	if (m_pSfxWing && dwSfx == NULL_ID) //&& dwSfx == NULL_ID
	{
		g_WorldMng.Get()->RemoveObj(m_pSfxWing);
		m_pSfxWing = nullptr;
	}

	if (dwSfx != NULL_ID)
		m_pSfxWing = CreateSfx(g_Neuz.m_pd3dDevice, dwSfx, GetPos(), GetId(), GetPos(), GetId(), -1);
}
#endif

#ifdef __BATTLEPASS
BOOL CMover::IsBattlePass()
{
	if (CTime(m_szBPEndTime).GetTime() <= CTime::GetCurrentTime().GetTime())
		return FALSE;

	return TRUE;
}

int CMover::BattlePassSize()
{
	int nNum = 0;
	for (map<int, BATTLE_PASS>::iterator i = prj.mapBattPass.begin(); i != prj.mapBattPass.end(); ++i)
	{
		BATTLE_PASS nBattPass = i->second;
		if (nBattPass.nType == m_nBPType)
			nNum++;
	}
	return nNum;
}
#endif // __BATTLEPASS

#ifdef __ADVANCED_ANNOUNCEMENT
CString CMover::GetAuthString()
{
	CString strOut = "";

	if (m_dwAuthorization == AUTH_OWNER)
	{
		strOut = "Founder";
	}
	else if (m_dwAuthorization == AUTH_DEVELOPER)
	{
		strOut = "Administrator";
	}
	else if (m_dwAuthorization == AUTH_ADMINISTRATOR)
	{
		strOut = "GameMaster";
	}
	else if (m_dwAuthorization == AUTH_GAMEMASTER3)
	{
		strOut = "EventMaster";
	}
	else
	{
		strOut = "Test GM";
	}
	return strOut;
}
#endif // __ADVANCED_ANNOUNCEMENT

#ifdef __BADGE
void CMover::SetBadge(const int nBadge)
{
	m_nBadge = nBadge;
}

int CMover::GetBadge() const
{
	return m_nBadge;
}

#ifdef __WORLDSERVER
void CMover::SetBadgeAddType(int Req, int Cond, int Default)
{
	auto& badge = CBadge::GetInstance()->GetBadgesMap();
	if (Default == 0)
	{
		for (auto it = badge.begin(); it != badge.end(); ++it)
		{
			if (it->second.Req == Req && it->second.Condition == Cond)
			{
				if (std::find(GetOwnedBadges().begin(), GetOwnedBadges().end(), it->first) == GetOwnedBadges().end())
				{
					GetOwnedBadges().push_back(it->first);
					((CUser*)this)->AddBadgeListUpdate();
					((CUser*)this)->AddText("New badge unlocked!", COLOR_SUCCESS);
				}
			}
		}
	}
	else
	{
		for (auto it = badge.begin(); it != badge.end(); ++it)
		{
			if (it->second.Req == Req && it->second.Condition == Cond && GetLevel() == Default)
			{
				if (std::find(GetOwnedBadges().begin(), GetOwnedBadges().end(), it->first) == GetOwnedBadges().end())
				{
					GetOwnedBadges().push_back(it->first);
					((CUser*)this)->AddBadgeListUpdate();
					((CUser*)this)->AddText("New badge unlocked!", COLOR_SUCCESS);
				}
			}
		}
	}
}
#endif //__WORLDSERVER
#endif //__BADGE
```
