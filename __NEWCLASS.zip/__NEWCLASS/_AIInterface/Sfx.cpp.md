# Sfx.cpp

Chemin original: `C:\Users\rdiff\Desktop\__NEWCLASS\_AIInterface\Sfx.cpp`
Chemin relatif: `_AIInterface\Sfx.cpp`
Nom du fichier: `Sfx.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `cp1252`

```cpp
#include "stdafx.h"
#include "Sfx.h"
#include "light.h"
#include "defineobj.h"
#include "defineSkill.h"
#include "defineSound.h"
#include "..\_Common\ParticleMng.h"

#ifdef __JOPS_GLOW
#ifdef __CLIENT
#include "resdata.h"
#endif
#endif

#include "dpclient.h"
extern	CDPClient	g_DPlay;

#include "party.h"
extern	CParty g_Party;

#ifndef __VM_0820
MemPooler<CSfxGenNormalDmg01>*	CSfxGenNormalDmg01::m_pPool	= new MemPooler<CSfxGenNormalDmg01>( 128 );
MemPooler<CSfxGenMoveMark>*	CSfxGenMoveMark::m_pPool	= new MemPooler<CSfxGenMoveMark>( 4 );
MemPooler<CSfxGenWaterCircle>*	CSfxGenWaterCircle::m_pPool	= new MemPooler<CSfxGenWaterCircle>( 64 );
MemPooler<CSfxGenRainCircle>*	CSfxGenRainCircle::m_pPool	= new MemPooler<CSfxGenRainCircle>( 64 );
#endif	// __VM_0820
CSfxGenMoveMark* g_pMoveMark=NULL;

//////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////
static int g_nEffect = 0;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ÀÏ¹Ý È¿°úµé 

// ÀÏ¹Ý °ø°ÝÀ¸·Î µ¥¹ÌÁö ÀÔÀ» ¶§ È¿°ú 
CSfxGenNormalDmg01::CSfxGenNormalDmg01()
{
}
CSfxGenNormalDmg01::~CSfxGenNormalDmg01()
{
}
void CSfxGenNormalDmg01::Process()
{
	m_nFrame++; // ÇÑ ÇÁ·¹ÀÓ ÁøÇà½ÃÅ°°í
	if(m_pSfxObj->Process()) // SFXÀÇ ¾Ö´Ï¸ÞÀÌ¼ÇÀ» Ã³¸®ÇØ¼­ SFXÀÇ Àç»ýÀÌ ³¡³µÀ¸¸é
	{
		Delete(); // ÀÚ½ÅÀ» Áö¿î´Ù
	}
	// ÀÌ°ÍÀÌ ProcessÀÇ ±âº». ´Ü¼ø Àç»ý SFX´Â ´ëºÎºÐ ÀÌ ÇüÅÂ¸¦ ÃëÇÑ´Ù.
}
void CSfxGenNormalDmg01::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos = GetPos();		// 2006/6/20 xuzhu
//	m_pSfxObj->m_vPos = GetPos()+D3DXVECTOR3(.0f,1.0f,.0f);
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}
// ÀÏ¹Ý °ø°ÝÀ¸·Î µ¥¹ÌÁö ÀÔÀ» ¶§ È¿°ú 
CSfxGenSuperDmg01::CSfxGenSuperDmg01()
{
}
CSfxGenSuperDmg01::~CSfxGenSuperDmg01()
{
}
void CSfxGenSuperDmg01::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}
	// ¿ª½Ã ´Ü¼ø Àç»ý ProcessÀÌ´Ù.
}
void CSfxGenSuperDmg01::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos = GetPos()+D3DXVECTOR3(.0f,1.0f,.0f);
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// ½ºÅ³·Î µ¥¹ÌÁö ÀÔÀ» ¶§ È¿°ú 
CSfxGenSkillDmg01::CSfxGenSkillDmg01()
{
}
CSfxGenSkillDmg01::~CSfxGenSkillDmg01()
{
}
void CSfxGenSkillDmg01::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxGenSkillDmg01::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos = GetPos()+D3DXVECTOR3(.0f,1.0f,.0f);
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// ¸ó½ºÅÍ°¡ µ¥¹ÌÁö ÀÔÀ» ¶§ È¿°ú 
CSfxGenMonsterDmg01::CSfxGenMonsterDmg01()
{
}
CSfxGenMonsterDmg01::~CSfxGenMonsterDmg01()
{
}
void CSfxGenMonsterDmg01::Process()
{
	m_nFrame++; // ÇÑÇÁ·¹ÀÓ ÁøÇà½ÃÅ°°í
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc ); // ºÙ¾î´Ù´Ò ³ð ID·Î MoverÀÇ Æ÷ÀÎÅÍ¸¦ °®°í¿Â´Ù.
	if(pObjSrc) SetPos(pObjSrc->GetPos()); // ±×³ðÀÌ ÀÖÀ¸¸é ±×³ðÀÇ À§Ä¡·Î ÀÌµ¿½ÃÅ°°í
	if(m_pSfxObj->Process()) // SFXÀÇ ¾Ö´Ï¸ÞÀÌ¼ÇÀ» Ã³¸®ÇØ¼­ SFXÀÇ Àç»ýÀÌ ³¡³µÀ¸¸é
	{
		Delete(); // ÀÚ½ÅÀ» Áö¿î´Ù.
	}
	// ÀÌ°ÍÀÌ Æ¯Á¤ Mover¿¡ ºÙ¾î´Ù´Ï´Â SFXÀÇ Process ±âº»ÇüÀÌ´Ù.
}
void CSfxGenMonsterDmg01::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos = GetPos()+D3DXVECTOR3(.0f,1.0f,.0f);
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// ºÎÈ° È¿°ú 
CSfxGenRestoration01::CSfxGenRestoration01()
{
}
CSfxGenRestoration01::~CSfxGenRestoration01()
{
}
void CSfxGenRestoration01::Process()
{
	m_nFrame++;
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if(pObjSrc) SetPos(pObjSrc->GetPos());
	if(m_pSfxObj->Process())
	{
		Delete();
	}
	// ¿ª½Ã m_idSrc¸¦ µû¶ó´Ù´Ï´Â ProcessÀÌ´Ù.
}
void CSfxGenRestoration01::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate.y=GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// Ä¡·á È¿°ú 
CSfxGenCure::CSfxGenCure()
{
}
CSfxGenCure::~CSfxGenCure()
{
}
void CSfxGenCure::Process()
{
	m_nFrame++;
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if(pObjSrc) SetPos(pObjSrc->GetPos());
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxGenCure::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate.y=GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// È¿·Â Áõ´ë È¿°ú 
CSfxGenIncrease01::CSfxGenIncrease01()
{
}
CSfxGenIncrease01::~CSfxGenIncrease01()
{

}
void CSfxGenIncrease01::Process()
{
	m_nFrame++;
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if(pObjSrc) SetPos(pObjSrc->GetPos());
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxGenIncrease01::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate.y=GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// ·¹º§ ¾÷ È¿°ú 
CSfxGenLevelUp::CSfxGenLevelUp()
{
}
CSfxGenLevelUp::~CSfxGenLevelUp()
{
}
void CSfxGenLevelUp::Process()
{
	m_nFrame++;
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if(pObjSrc) {
		SetPos(pObjSrc->GetPos()+D3DXVECTOR3(.0f,.1f,.0f));
		SetAngle(-pObjSrc->GetAngle()); // µû¶ó´Ù´Ï´Â Process¿¡ °¢µµ±îÁö ÀÏÄ¡½ÃÅ°´Â ºÎºÐÀÌ Ãß°¡µÇ¾ú´Ù.
	}
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxGenLevelUp::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate=D3DXVECTOR3(.0f,GetAngle(),.0f);
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// ±Ø´Ü½ºÅ³ ÀÌÆåÆ® : ½ºÆ®·¹Äª 01
CSfxTroStretching01::CSfxTroStretching01()
{
}
CSfxTroStretching01::~CSfxTroStretching01()
{
}
void CSfxTroStretching01::Process()
{
	m_nFrame++;
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if(pObjSrc) {
		SetPos(pObjSrc->GetPos()+D3DXVECTOR3(.0f,.1f,.0f));
		SetAngle(-pObjSrc->GetAngle()); // µû¶ó´Ù´Ï´Â Process¿¡ °¢µµ±îÁö ÀÏÄ¡½ÃÅ°´Â ºÎºÐÀÌ Ãß°¡µÇ¾ú´Ù.
	}
	if(m_pSfxObj->Process())
	{
		Delete();
		
		if( pObjSrc )
		{
			D3DXVECTOR3 v = pObjSrc->GetPos();
			
			ItemProp* pItemProp = prj.GetPartySkill( ST_STRETCHING );
			
			CSfx* pSfx = CreateSfx(g_Neuz.m_pd3dDevice, pItemProp->dwSfxObj2, v, pObjSrc->GetId(), D3DXVECTOR3(0.0f, 0.0f, 0.0f), NULL_ID, -1);	// ¸Ó¸®À§¿¡ sfx»ý¼º.

		}
		
	}
}

void CSfxTroStretching01::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate=D3DXVECTOR3(.0f,GetAngle(),.0f);
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// ±Ø´Ü½ºÅ³ ÀÌÆåÆ® : ½ºÆ®·¹Äª 02
CSfxTroStretching02::CSfxTroStretching02()
{
}
CSfxTroStretching02::~CSfxTroStretching02()
{
}
void CSfxTroStretching02::Process()
{
	m_nFrame++;
	if( m_nSec == 0 )
	{
		if( m_pSfxObj->Process() )
			Delete();
	}
	else
	{
		if( m_pSfxObj->Process() )
			m_pSfxObj->m_nCurFrame = 0;
		if( m_nSec != -1 )
		{
			if( m_nFrame > ( m_nSec * 60 ) )
				Delete();
		}
	}

	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );

	if(pObjSrc) 
	{
		if( !pObjSrc->m_pActMover->IsSit() || g_Party.m_nModeTime[PARTY_STRETCHING_MODE] == FALSE )
		{
			Delete();
		}
		else
		{
			SetPos(pObjSrc->GetPos()+D3DXVECTOR3(.0f,.1f,.0f));
			SetAngle(-pObjSrc->GetAngle()); // µû¶ó´Ù´Ï´Â Process¿¡ °¢µµ±îÁö ÀÏÄ¡½ÃÅ°´Â ºÎºÐÀÌ Ãß°¡µÇ¾ú´Ù.
		}
	}
	else
		Delete();
}

void CSfxTroStretching02::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate=D3DXVECTOR3(.0f,GetAngle(),.0f);
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// ±Ø´Ü½ºÅ³ ÀÌÆåÆ® : ºí¸´Ã÷~
CSfxTroBlitz::CSfxTroBlitz()
{
}
CSfxTroBlitz::~CSfxTroBlitz()
{
}
void CSfxTroBlitz::Process()
{
	m_nFrame++;
	if( m_nSec == 0 )
	{
		if( m_pSfxObj->Process() )
			Delete();
	}
	else
	{
		if( m_pSfxObj->Process() )
			m_pSfxObj->m_nCurFrame = 0;
		if( m_nSec != -1 )
		{
			if( m_nFrame > ( m_nSec * 60 ) )
				Delete();
		}
	}
}

void CSfxTroBlitz::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );

	if( IsInvalidObj(pObjDest) )	
		return;

	m_pSfxObj->m_vPos = pObjDest->GetPos();
	m_pSfxObj->m_vPos.y += ((pObjDest->m_pModel->GetMaxHeight()*pObjDest->GetScale().y) - (pObjDest->GetScale().y*0.7f));
	
	m_pSfxObj->m_vRotate=D3DXVECTOR3(.0f,GetAngle(),.0f);
	m_pSfxObj->m_vScale = pObjDest->GetScale();
	
	m_pSfxObj->Render( pd3dDevice );
}

// ·Î±×ÀÎ È¿°ú 
CSfxGenLogin::CSfxGenLogin()
{
}
CSfxGenLogin::~CSfxGenLogin()
{
}
void CSfxGenLogin::Process()
{
	m_nFrame++;
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if(pObjSrc) SetPos(pObjSrc->GetPos());
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxGenLogin::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate.y=GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// ¿öÇÁ È¿°ú 
CSfxGenWarp::CSfxGenWarp()
{
}
CSfxGenWarp::~CSfxGenWarp()
{
}
void CSfxGenWarp::Process()
{
	m_nFrame++;
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if(pObjSrc) SetPos(pObjSrc->GetPos());
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxGenWarp::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate.y=GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// ÇÃ·¹ÀÌ¾î Á×À» ¶§ È¿°ú 
CSfxGenPcDie::CSfxGenPcDie()
{
}
CSfxGenPcDie::~CSfxGenPcDie()
{
}
void CSfxGenPcDie::Process()
{
	m_nFrame++;
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if(pObjSrc) SetPos(pObjSrc->GetPos());
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxGenPcDie::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate.y=GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// ¸ó½ºÅÍ ½ºÆù ÇÒ ¶§ È¿°ú 
CSfxGenMonsterSpawn::CSfxGenMonsterSpawn()
{
}
CSfxGenMonsterSpawn::~CSfxGenMonsterSpawn()
{
}
void CSfxGenMonsterSpawn::Process()
{
	m_nFrame++;
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if(pObjSrc) SetPos(pObjSrc->GetPos());
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxGenMonsterSpawn::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate.y=GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// ÀÏ¹Ý °ø°ÝÀ¸·Î µ¥¹ÌÁö ÀÔÀ» ¶§ È¿°ú 
CSfxGenMoveMark::CSfxGenMoveMark()
{
}
CSfxGenMoveMark::~CSfxGenMoveMark()
{
}
void CSfxGenMoveMark::Process()
{
	m_nFrame++;
	g_pMoveMark=this;
	if(m_pSfxObj->Process())
	{
		g_pMoveMark=NULL;
		Delete();
	}
}
void CSfxGenMoveMark::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vPos.y += 0.05f;
	m_pSfxObj->m_vScale = GetScale();

	m_pSfxObj->Render2( pd3dDevice );
}

// ÀÏ¹Ý °ø°ÝÀ¸·Î µ¥¹ÌÁö ÀÔÀ» ¶§ È¿°ú 
CSfxGenWaterCircle::CSfxGenWaterCircle()
{
}
CSfxGenWaterCircle::~CSfxGenWaterCircle()
{
}
void CSfxGenWaterCircle::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxGenWaterCircle::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

CSfxGenRainCircle::CSfxGenRainCircle()
{
}
CSfxGenRainCircle::~CSfxGenRainCircle()
{
}
void CSfxGenRainCircle::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}

	m_pSfxObj->m_vPos = GetPos();
	m_pSfxObj->m_vScale    = GetScale();
}
void CSfxGenRainCircle::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->Render2( pd3dDevice );
}


// ÀÏ¹Ý °ø°ÝÀ¸·Î µ¥¹ÌÁö ÀÔÀ» ¶§ È¿°ú 
CSfxGenWaterCrown::CSfxGenWaterCrown()
{
}
CSfxGenWaterCrown::~CSfxGenWaterCrown()
{
}
void CSfxGenWaterCrown::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxGenWaterCrown::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ¾ÆÀÌÅÛ È¿°úµé 

// °øÁßÀü¿¡¼­ ¹ß»çÇÏ´Â ¿ÏµåÀÇ ¹ß»çÃ¼.
CSfxItemWandAtkAir::CSfxItemWandAtkAir()
{
	m_SfxObj2.SetSfx( "sfx_HitWand01" ); // ¸Â´Â ¼ø°£ÀÇ SFX¸¦ µû·Î ·ÎµùÇÑ´Ù.
	m_bHit = FALSE; // ¾ÆÁ÷ ¾È¸Â¾Ò´Ù.
}
CSfxItemWandAtkAir::~CSfxItemWandAtkAir()
{
}

int CSfxItemWandAtkAir::SetSfx( LPDIRECT3DDEVICE9 pd3dDevice, int nIndex, 
								 D3DXVECTOR3& vPosSrc, OBJID idSrc, D3DXVECTOR3& vPosDest, OBJID idDest, int nSec )
{
	CSfx::SetSfx( pd3dDevice, nIndex, vPosSrc, idSrc, vPosDest, idDest, nSec );		// ±âº»ÃÊ±âÈ­ ¸ÕÀúÇÏ°í.

	CMover* pObjSrc = prj.GetMover( m_idSrc );		// ¹ß»çÃø.
	if( IsInvalidObj(pObjSrc) )		return 0;		// ½ÇÆÐ.
	CMover* pObjDest = prj.GetMover( m_idDest );	// Å¸°ÙÃøÀÇ Æ÷ÀÎÅÍ.
	if( IsInvalidObj(pObjDest) )	return 0;		// ½ÇÆÐ.
	
	// !!!!!!!!!!!! SFX¸¦ SetPosÇÒ¶§ º¹ÀâÇÑ Ã³¸® ÇÏÁö ¾Êµµ·Ï ¹Ù²ÙÀÚ.
	SetPos( pObjSrc->GetPos() + D3DXVECTOR3( 0, 1.0f, 0 ) );		// ¹ß»çÃøÀÇ ÁÂÇ¥¿¡¼­ ¾à°£ À§¿¡¼­ ¹ß»çµÊ.
	m_pSfxObj->m_vPos = GetPos();
	m_vPosDest = pObjDest->GetPos();		// Å¸°ÙÃø Æ÷Áö¼Ç.

	return 1;
}

//
//
//
void CSfxItemWandAtkAir::ShootSfx( float fAngXZ, float fAngY, float fSpeed )
{
	AngleToVector( &m_vDelta, fAngXZ, fAngY, fSpeed );		// ÃÊ±â ¹ß»çÈû.	- ¿Ïµå°¡ ÇâÇÏ°í ÀÖ´Â ¹æÇâÀ¸·Î ½ê°Ô ¹æÃâ.
}

	
void CSfxItemWandAtkAir::Process()
{
	FLOAT	fRadius = 0.6f;		// Å¸°ÙÀÇ ¹Ý°æ.
	CMover* pObjDest = prj.GetMover( m_idDest );		// Å¸°ÙÃøÀÇ Æ÷ÀÎÅÍ.
	if( IsValidObj(pObjDest) )		// ¸¸¾à ¹ß»çÃ¼°¡ ³¯¾Æ°¡´Â Áß¿¡ Å¸°ÙÀÌ ¾ø¾îÁ³´Ù¸é ¸¶Áö¸· ÀÖ¾ú´ø ÁÂÇ¥·Î ³¯¾Æ°¡¼­ ÆÄ±«µÈ´Ù.
	{
		m_vPosDest = pObjDest->GetPos();
		m_vPosDest.y += 1.0f;
		if( pObjDest->IsNPC() )		// ¸÷ÀÇ°æ¿ì Å¸°ÙÀÇ Å©±â¸¦ Á»´õ Å©°Ô ÇÏÀÚ.
			fRadius = 3.0f;
	}
	
	if( m_bHit == FALSE )	// ¾ÆÁ÷ ¾È¸ÂÀº »óÅÂÀÌ¸é
	{ 
		m_pSfxObj->Process(); // SFX ¾Ö´Ï¸ÞÀÌ¼ÇÀ» Ã³¸®ÇÏ°í
		if( m_pSfxObj->m_nCurFrame == 20 ) // ÇöÀç 20ÇÁ·¹ÀÓ±îÁö ÁøÇàÇßÀ¸¸é
		{
			m_pSfxObj->m_nCurFrame = 0; // ¸ñÇ¥Á¡¿¡ ¸ÂÀ»¶§±îÁö ·çÇÁ½ÃÅ°±â À§ÇØ ´Ù½Ã 0ÇÁ·¹ÀÓÀ¸·Î µ¹·Á³õ´Â´Ù.
		}

		// ÇöÀç À§Ä¡¿¡¼­ ¸ñÇ¥¹æÇâÂÊÀ¸·ÎÀÇ º¤ÅÍ ±¸ÇÔ.
		D3DXVECTOR3 vDist = m_vPosDest - GetPos();
		D3DXVECTOR3 vDistXZ = vDist;
		vDistXZ.y = 0;		// XZÆò¸éÀÇ ¼ø¼ö ±æÀÌ¸¦ ±¸ÇÏ±â À§ÇØ.

		FLOAT fAngXZ = D3DXToDegree( atan2( vDist.x, -vDist.z ) );		// ¸ñÇ¥¹æÇâÂÊÀ¸·ÎÀÇ XZ°¢µµ ±¸ÇÔ.
		FLOAT fDistXZ = D3DXVec3Length( &vDistXZ );				// ¸ñÇ¥¹æÇâÂÊÀ¸·ÎÀÇ XZÆò¸é¿¡¼­ÀÇ ±æÀÌ.
		FLOAT fAngH  = D3DXToDegree( atan2( fDistXZ, vDist.y ) );		// ¸ñÇ¥¹æÇâÂÊÀ¸·ÎÀÇ ³ôÀÌ °¢µµ.

		fAngH -= 90.0f;
		fAngH = -fAngH;
		D3DXVECTOR3	vAcc;
		AngleToVector( &vAcc, fAngXZ, fAngH, 0.007f );		// ½Ç½Ã°£À¸·Î ¸ñÇ¥ÂÊÀ¸·Î ÇâÇÏ´Â Èû.
		
		FLOAT fSpeedSq = D3DXVec3LengthSq( &m_vDelta );		// µð¹ö±ë¿ë.  ÇöÀç ¹ß»çÃ¼ÀÇ ¼Óµµ¸¦ »êÃâ.
		if( fSpeedSq < (0.45f * 0.45f) )
		{
			m_vDelta += vAcc;		// ±âÁ¸ °ü¼º¿¡ »õ·Î¿î ÈûÀ» ´õÇÔ.
		}
		m_vDelta *= 0.985f;		// ¸¶ÂûÀ» Áà¼­ ÀÏÁ¤ÀÌ»ó ¼Óµµ°¡ »¡¶óÁöÁö ¾Êµµ·Ï ÇÏÀÚ.
		//m_vDelta *= 0.965f;		// ¸¶ÂûÀ» Áà¼­ ÀÏÁ¤ÀÌ»ó ¼Óµµ°¡ »¡¶óÁöÁö ¾Êµµ·Ï ÇÏÀÚ.
		D3DXVECTOR3 vPos = GetPos();
		vPos += m_vDelta;
		SetPos( vPos );		// ÇöÀç À§Ä¡ °»½Å.

		m_pSfxObj->m_vRotate.y = m_SfxObj2.m_vRotate.y = fAngXZ;	// sfx modelÀÇ °¢µµµµ º¯È­ ½ÃÄÑÁÜ.
		
		if( D3DXVec3LengthSq( &vDist ) < (fRadius * fRadius) )  // ¸ñÇ¥Á¡ÀÇ °Å¸®¿Í xx cmÀÌÇÏÀÎ °æ¿ì¿¡´Â...
		{			
			m_bHit = TRUE; // ¸ÂÀº °É·Î ÆÇ´ÜÇÑ´Ù.
			m_SfxObj2.m_vPos = GetPos();		// ÇöÀç À§Ä¡¿¡¼­ Æø¹ß.
			DamageToTarget(); // ¿©±â¼­ ¸Â´Â¼ø°£Ã³¸®
		}

		if( IsValidObj(pObjDest) )
		{
			if( pObjDest == CMover::GetActiveMover() )	// ³¯ Å¸°ÙÀ¸·Î Àâ°í ³¯¾Æ¿À´Â ³ðÀº »¡°£»ö
				g_ParticleMng.CreateParticle( 0, GetPos(), D3DXVECTOR3(0,0,0), pObjDest->GetPos().y );
			else
				g_ParticleMng.CreateParticle( 1, GetPos(), D3DXVECTOR3(0,0,0), pObjDest->GetPos().y );
			
		}
		
	}
	else 
	{
		if( m_SfxObj2.Process() )		// ¸¶Áö¸·À¸·Î ¸Â´Â ¼ø°£ Ãâ·ÂµÇ´Â SFXÀÇ Àç»ýÀÌ ³¡³ª¸é
		{ 
			Delete(); // ÀÚ½ÅÀ» Áö¿î´Ù.
		}
	}
	m_pSfxObj->m_vPos = GetPos();
	
	m_nFrame++;
	if( m_nFrame >= 60 * 8 )	
	{
		m_bHit = TRUE;
		m_SfxObj2.m_vPos = GetPos();		// ÇöÀç À§Ä¡¿¡¼­ Æø¹ß.
		if( g_pPlayer->IsActiveMover() )
			g_DPlay.SendSfxClear( m_idSfxHit );		// ÀÌ°ÍÀÌ »èÁ¦µÇ¾ú´Ù´Â°É ¼­¹ö¿¡ ¾Ë¸².
	}
}

void CSfxItemWandAtkAir::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	if( m_bHit == FALSE ) 
	{
		m_pSfxObj->Render2( pd3dDevice );
	}
	else 
	{
		if( !g_Option.m_bSFXRenderOff )
			m_SfxObj2.Render( pd3dDevice );
	}
}



CSfxMagicMiAtk1::CSfxMagicMiAtk1()
{
	m_SfxObj2.SetSfx( "sfx_HitWand01" ); // ¸Â´Â ¼ø°£ÀÇ SFX¸¦ µû·Î ·ÎµùÇÑ´Ù.
	m_bHit = FALSE; // ¾ÆÁ÷ ¾È¸Â¾Ò´Ù.
	m_fCenter = 0;
	m_fRadiusXZ = 0.2f;		// µðÆúÆ® 20¼¾Ä¡.
}
CSfxMagicMiAtk1::~CSfxMagicMiAtk1()
{
}


void CSfxMagicMiAtk1::Process()
{
	// ÀÌ°ÍÀº ¸ñÇ¥Á¡±îÁö ³¯¶ó°¡¼­ ¸Â´Â SFXÀÇ ÀÏ¹ÝÀûÀÎ ProcessÀÌ´Ù.
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );
	if( pObjDest ) 
	{
		if( pObjDest->IsDie() )
		{
			Delete();
			return;
		}

		// ¹ß»ç ¸ñÇ¥ÁöÁ¡Àº »ó´ëÀÇ Áß¾Ó.
		float fHeight = fabs(pObjDest->m_pModel->m_vMax.y) / 2.0f;	// ¾ÆÀÌ¹ÙÆ®°°Àº³ÑÀº °øÁß¿¡ ¶°ÀÖ±â¶«¿¡ ¼ø¼ö ³ôÀÌÀÎ Max°ª¸¸ ÃëÇß´Ù.
		fHeight *= pObjDest->GetScale().x;
		m_fCenter = fHeight;	
		
		m_vPosDest = pObjDest->GetPos();		// Å¸°ÙÀÇ À§Ä¡ °»½Å - Å¸°ÙÀÌ °è¼Ó ¿òÁ÷ÀÌ¹Ç·Î...
		m_vPosDest.y += m_fCenter;
		if( m_nFrame == 0 )
		{
			// ¸Ç Ã¹ÇÁ·¹ÀÓ¿¡¼­ °è»ê.
			FLOAT fLenX = fabs(pObjDest->m_pModel->m_vMax.x - pObjDest->m_pModel->m_vMin.x);
			FLOAT fLenZ = fabs(pObjDest->m_pModel->m_vMax.z - pObjDest->m_pModel->m_vMin.z);
			m_fRadiusXZ = ((fLenX + fLenZ) / 2.0f);		// XÅ©±â ZÅ©±â Æò±ÕÀ» ³¿
			m_fRadiusXZ *= pObjDest->GetScale().x;
			m_fRadiusXZ /= 3.0f;	// Á¤È®È÷ ¹ÝÁö¸§À» ¾²Áü¶ó°í ¹ÝÁö¸§(/2)º¸´Ù Á¶±Ý Å©°Ô ¾²ÀÚ 3À» ³ª´®.
		}
	} else
	{
		Delete();
		return;
	}

		
	if( m_bHit == FALSE )		// ¾ÆÁ÷ ¾È¸ÂÀº »óÅÂÀÌ¸é
	{ 
		m_pSfxObj->Process(); // SFX ¾Ö´Ï¸ÞÀÌ¼ÇÀ» Ã³¸®ÇÏ°í
		if( m_pSfxObj->m_nCurFrame == 20 ) // ÇöÀç 20ÇÁ·¹ÀÓ±îÁö ÁøÇàÇßÀ¸¸é
		{
			m_pSfxObj->m_nCurFrame=0; // ¸ñÇ¥Á¡¿¡ ¸ÂÀ»¶§±îÁö ·çÇÁ½ÃÅ°±â À§ÇØ ´Ù½Ã 0ÇÁ·¹ÀÓÀ¸·Î µ¹·Á³õ´Â´Ù.
		}

		D3DXVECTOR3 vPos = GetPos();
		D3DXVECTOR3 vDelta = m_vPosDest - vPos;		// ÇöÀç À§Ä¡¿¡¼­ Å¸°Ù¹æÇâÀ¸·ÎÀÇ º¤ÅÍ.
		D3DXVec3Normalize( &vDelta, &vDelta );		// À¯´Öº¤ÅÍÈ­ - 1¹ÌÅÍÈ­.
		vPos += (vDelta * 0.4f);					// 20¼¾Ä¡·Î ÁÙ¿©¼­ ÇöÀçÀ§Ä¡¿¡ ´õÇÔ.
		
		SetPos( vPos );				// ÇöÀç À§Ä¡ °»½Å.
		m_pSfxObj->m_vPos = vPos;	// SFXModelÀÇ À§Ä¡µµ °»½Å.

		D3DXVECTOR3 vDir      = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
		D3DXVECTOR3 vDestNor  = m_vPosDest - vPos;
		D3DXVECTOR3 vAxis;
		D3DXQUATERNION   qRot;
		
		FLOAT       fTheta;
		D3DXVec3Normalize( &vDestNor, &vDestNor );
		D3DXVec3Cross( &vAxis, &vDir, &vDestNor );
		fTheta = D3DXVec3Dot( &vDir, &vDestNor );
		D3DXQuaternionRotationAxis( &qRot, &vAxis, acosf( fTheta ) );

		D3DXVECTOR3 vYPW;

		QuaternionRotationToYPW( qRot, vYPW );
		m_pSfxObj->m_vRotate.x = m_SfxObj2.m_vRotate.x = D3DXToDegree(vYPW.x);
		m_pSfxObj->m_vRotate.y = m_SfxObj2.m_vRotate.y = D3DXToDegree(vYPW.y);
		m_pSfxObj->m_vRotate.z = m_SfxObj2.m_vRotate.z = D3DXToDegree(vYPW.z);

		vDelta = GetPos() - m_vPosDest;
		if( D3DXVec3LengthSq( &vDelta ) < m_fRadiusXZ * m_fRadiusXZ )		// ¸ñÇ¥Á¡ÀÇ °Å¸®¿Í 20cmÀÌÇÏÀÎ °æ¿ì¿¡´Â...
		{ 
			m_SfxObj2.m_vPos = GetPos();//m_vPosDest;		// Å¸°ÙÀÇ À§Ä¡¿¡ Æø¹ß ÀÌÆåÆ® ÁÂÇ¥.
			m_SfxObj2.m_vPos.y+=1.0f;
			m_bHit = TRUE; // ¸ÂÀº °É·Î ÆÇ´ÜÇÑ´Ù.
		}
	}
	else 
	{
		if( m_SfxObj2.m_nCurFrame == 0 )		// m_SfxObj2´Â ¸Â´Â ¼ø°£ Ãâ·ÂµÇ´Â SFXÀÌ´Ù.
		{ 
			DamageToTarget(); // ¿©±â¼­ ¸Â´Â¼ø°£Ã³¸®
		}
		if( m_SfxObj2.Process() )		// ¸¶Áö¸·À¸·Î ¸Â´Â ¼ø°£ Ãâ·ÂµÇ´Â SFXÀÇ Àç»ýÀÌ ³¡³ª¸é
		{ 
			Delete(); // ÀÚ½ÅÀ» Áö¿î´Ù.
		}
	}
	m_nFrame++;
	if( m_nFrame >= SEC1 * 10 )		// ³Ê¹«¿À·¡ ¦i¾Æ°¡Áö ¾Ê°Ô 10ÃÊÁö³ª¸é ¼Ò¸ê
		Delete();
}
void CSfxMagicMiAtk1::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	if( m_bHit == FALSE ) 
	{
		m_pSfxObj->Render2( pd3dDevice );
	}
	else 
	{
		if( !g_Option.m_bSFXRenderOff )
			m_SfxObj2.Render( pd3dDevice );
	}
}



CSfxItemWandAtk1::CSfxItemWandAtk1()
{
	m_SfxObj2.SetSfx( "sfx_HitWand01" ); // ¸Â´Â ¼ø°£ÀÇ SFX¸¦ µû·Î ·ÎµùÇÑ´Ù.
	m_bHit = FALSE; // ¾ÆÁ÷ ¾È¸Â¾Ò´Ù.
	m_fCenter = 0;
	m_fRadiusXZ = 0.2f;		// µðÆúÆ® 20¼¾Ä¡.
}
CSfxItemWandAtk1::~CSfxItemWandAtk1()
{
}


void CSfxItemWandAtk1::Process()
{
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );
	if( pObjDest ) 
	{
		if( pObjDest->IsDie() )
		{
			Delete();
			return;
		}

		// ¹ß»ç ¸ñÇ¥ÁöÁ¡Àº »ó´ëÀÇ Áß¾Ó.
		float fHeight = fabs(pObjDest->m_pModel->m_vMax.y) / 2.0f;	// ¾ÆÀÌ¹ÙÆ®°°Àº³ÑÀº °øÁß¿¡ ¶°ÀÖ±â¶«¿¡ ¼ø¼ö ³ôÀÌÀÎ Max°ª¸¸ ÃëÇß´Ù.
		fHeight *= pObjDest->GetScale().x;
		m_fCenter = fHeight;	
		
		m_vPosDest = pObjDest->GetPos();		// Å¸°ÙÀÇ À§Ä¡ °»½Å - Å¸°ÙÀÌ °è¼Ó ¿òÁ÷ÀÌ¹Ç·Î...
		m_vPosDest.y += m_fCenter;
		if( m_nFrame == 0 )
		{
			// ¸Ç Ã¹ÇÁ·¹ÀÓ¿¡¼­ °è»ê.
			FLOAT fLenX = fabs(pObjDest->m_pModel->m_vMax.x - pObjDest->m_pModel->m_vMin.x);
			FLOAT fLenZ = fabs(pObjDest->m_pModel->m_vMax.z - pObjDest->m_pModel->m_vMin.z);
			m_fRadiusXZ = ((fLenX + fLenZ) / 2.0f);		// XÅ©±â ZÅ©±â Æò±ÕÀ» ³¿
			m_fRadiusXZ *= pObjDest->GetScale().x;
			m_fRadiusXZ /= 3.0f;	// Á¤È®È÷ ¹ÝÁö¸§À» ¾²Áü¶ó°í ¹ÝÁö¸§(/2)º¸´Ù Á¶±Ý Å©°Ô ¾²ÀÚ 3À» ³ª´®.
		}
	} else
	{
		Delete();
		return;
	}

		
	if( m_bHit == FALSE )		// ¾ÆÁ÷ ¾È¸ÂÀº »óÅÂÀÌ¸é
	{ 
		m_pSfxObj->Process(); // SFX ¾Ö´Ï¸ÞÀÌ¼ÇÀ» Ã³¸®ÇÏ°í
		if( m_pSfxObj->m_nCurFrame == 20 ) // ÇöÀç 20ÇÁ·¹ÀÓ±îÁö ÁøÇàÇßÀ¸¸é
		{
			m_pSfxObj->m_nCurFrame=0; // ¸ñÇ¥Á¡¿¡ ¸ÂÀ»¶§±îÁö ·çÇÁ½ÃÅ°±â À§ÇØ ´Ù½Ã 0ÇÁ·¹ÀÓÀ¸·Î µ¹·Á³õ´Â´Ù.
		}

		D3DXVECTOR3 vPos = GetPos();
		D3DXVECTOR3 vDelta = m_vPosDest - vPos;		// ÇöÀç À§Ä¡¿¡¼­ Å¸°Ù¹æÇâÀ¸·ÎÀÇ º¤ÅÍ.
		D3DXVec3Normalize( &vDelta, &vDelta );		// À¯´Öº¤ÅÍÈ­ - 1¹ÌÅÍÈ­.
		vPos += (vDelta * 0.2f);					// 20¼¾Ä¡·Î ÁÙ¿©¼­ ÇöÀçÀ§Ä¡¿¡ ´õÇÔ.
		
		SetPos( vPos );				// ÇöÀç À§Ä¡ °»½Å.
		m_pSfxObj->m_vPos = vPos;	// SFXModelÀÇ À§Ä¡µµ °»½Å.

		D3DXVECTOR3 vDir      = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
		D3DXVECTOR3 vDestNor  = m_vPosDest - vPos;
		D3DXVECTOR3 vAxis;
		D3DXQUATERNION   qRot;
		
		FLOAT       fTheta;
		D3DXVec3Normalize( &vDestNor, &vDestNor );
		D3DXVec3Cross( &vAxis, &vDir, &vDestNor );
		fTheta = D3DXVec3Dot( &vDir, &vDestNor );
		D3DXQuaternionRotationAxis( &qRot, &vAxis, acosf( fTheta ) );

		D3DXVECTOR3 vYPW;

		QuaternionRotationToYPW( qRot, vYPW );
		m_pSfxObj->m_vRotate.x = m_SfxObj2.m_vRotate.x = D3DXToDegree(vYPW.x);
		m_pSfxObj->m_vRotate.y = m_SfxObj2.m_vRotate.y = D3DXToDegree(vYPW.y);
		m_pSfxObj->m_vRotate.z = m_SfxObj2.m_vRotate.z = D3DXToDegree(vYPW.z);

		vDelta = GetPos() - m_vPosDest;
		if( D3DXVec3LengthSq( &vDelta ) < m_fRadiusXZ * m_fRadiusXZ )		// ¸ñÇ¥Á¡ÀÇ °Å¸®¿Í 20cmÀÌÇÏÀÎ °æ¿ì¿¡´Â...
		{ 
			m_SfxObj2.m_vPos = GetPos();//m_vPosDest;		// Å¸°ÙÀÇ À§Ä¡¿¡ Æø¹ß ÀÌÆåÆ® ÁÂÇ¥.
			m_SfxObj2.m_vPos.y+=1.0f;
			m_bHit = TRUE; // ¸ÂÀº °É·Î ÆÇ´ÜÇÑ´Ù.
		}
	}
	else 
	{
		if( m_SfxObj2.m_nCurFrame == 0 )		// m_SfxObj2´Â ¸Â´Â ¼ø°£ Ãâ·ÂµÇ´Â SFXÀÌ´Ù.
		{ 
			DamageToTarget(); // ¿©±â¼­ ¸Â´Â¼ø°£Ã³¸®
		}
		if( m_SfxObj2.Process() )		// ¸¶Áö¸·À¸·Î ¸Â´Â ¼ø°£ Ãâ·ÂµÇ´Â SFXÀÇ Àç»ýÀÌ ³¡³ª¸é
		{ 
			Delete(); // ÀÚ½ÅÀ» Áö¿î´Ù.
		}
	}
	m_nFrame++;
	if( m_nFrame >= SEC1 * 10 )		// ³Ê¹«¿À·¡ ¦i¾Æ°¡Áö ¾Ê°Ô 10ÃÊÁö³ª¸é ¼Ò¸ê
		Delete();
}
void CSfxItemWandAtk1::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	if( m_bHit == FALSE ) 
	{
		m_pSfxObj->Render2( pd3dDevice );
	}
	else 
	{
		if( !g_Option.m_bSFXRenderOff )
			m_SfxObj2.Render( pd3dDevice );
	}
}


CSfxItemRangeAtk1::CSfxItemRangeAtk1() : CSfxShoot()
{
	m_pTail			= NULL;
}
CSfxItemRangeAtk1::~CSfxItemRangeAtk1()
{
	if( m_pTail )
		g_TailEffectMng.Delete( m_pTail );
	m_pTail = NULL;
}

void CSfxItemRangeAtk1::Process()
{
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );	// À¯µµÅº ÇüÀÌ±â¶§¹®¿¡ Å¸°ÙÀº Ç×»ó ÀÐ¾îºÁ¾ß ÇÑ´Ù.
	if( IsValidObj(pObjDest) )
	{
		m_vPosDest = pObjDest->GetPos() + D3DXVECTOR3( 0, 1.0f, 0 );
	} else
	{
		// ³¯¾Æ°¡´Ù Å¸°ÙÀÌ ¾ø¾îÁ³À¸¸é ¸¶Áö¸·ÁÂÇ¥·Î ³¯¾Æ°¡¼­ ÅÍÁö°Ô.
		Delete();	// this´Â »èÁ¦.
		int a = 0;
	}
	
	if( m_bHit == FALSE ) 
	{
		if( m_pSfxObj->Process() )		// ¾Ö´Ï¸ÞÀÌ¼ÇÀº ·çÇÁ.
		{
			m_pSfxObj->m_nCurFrame = 0;
		}
		D3DXVECTOR3 vPos = GetPos();
		D3DXVECTOR3 vDelta = m_vPosDest - vPos;
		D3DXVec3Normalize( &vDelta, &vDelta );		// Å¸°ÙÂÊ ´ÜÀ§º¤ÅÍ ±¸ÇØ¼­
		vPos += vDelta * 0.7f;			// ±× º¤ÅÍ·Î ¼Óµµ¸¦ °áÁ¤ÇØ¼­ ÁÂÇ¥ ÀÌµ¿.
		m_pSfxObj->m_vPos = vPos;
		SetPos( vPos );
		
		{
			// ¸¶¹ý°´Ã¼ ¹æÇâº¤ÅÍ·Î ¸ðµ¨ ¹æÇâ µ¹¸®±â~~~
			D3DXVECTOR3 vDir      = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
			D3DXVECTOR3 vDestNor  = m_vPosDest - m_pSfxObj->m_vPos;
			D3DXVECTOR3 vAxis;
			D3DXQUATERNION   qRot;
			
			FLOAT       fTheta;
			D3DXVec3Normalize( &vDestNor, &vDestNor );
			D3DXVec3Cross( &vAxis, &vDir, &vDestNor );
			fTheta = D3DXVec3Dot( &vDir, &vDestNor );
			D3DXQuaternionRotationAxis( &qRot, &vAxis, acosf( fTheta ) );
			
			D3DXVECTOR3 vYPW;
			
			QuaternionRotationToYPW( qRot, vYPW );
			m_pSfxObj->m_vRotate.x = m_SfxObj2.m_vRotate.x = D3DXToDegree(vYPW.x);
			m_pSfxObj->m_vRotate.y = m_SfxObj2.m_vRotate.y = D3DXToDegree(vYPW.y);
			m_pSfxObj->m_vRotate.z = m_SfxObj2.m_vRotate.z = D3DXToDegree(vYPW.z);

		}
		
		if( m_pTail )
		{
			if( m_pTail->GetType() != 2 )	// »ý¼ºµÇ¾ú´ø ²¿¸®°í ÀÏ¹Ýº¸µå¿ëÀÌ ¾Æ´Ï¸é 
				m_pTail->ChangeTexture( D3DDEVICE, "etc_Tail2.bmp", 2 );	// ÀÏ¹Ýº¸µå¿ëÀ¸·Î ÅØ½ºÃÄ ±³Ã¼.
		}
		if( m_pTail == NULL )	// ¾ÆÁ÷ ÇÒ´ç ¾ÈµÆÀ¸¸é ÇÒ´çÇÏ°í.
		{
			m_pTail = (CTailEffectBelt*)g_TailEffectMng.AddEffect( g_Neuz.m_pd3dDevice, "etc_Tail2.bmp", 2, 0.35f );
		}
		
		D3DXVECTOR3	vPos1, vPos2;
		FLOAT		fAngXZ = GetAngle();
		FLOAT		fAngH  = GetAngleX();
		
		fAngXZ -= 90.0f;
		if( fAngXZ < 0 )
			fAngXZ += 360.0f;
		AngleToVector( &vPos1, fAngXZ, -fAngH, 0.05f );
		vPos1 += GetPos();
		
		fAngXZ = GetAngle();
		fAngH  = GetAngleX();
		
		fAngXZ += 90.0f;
		if( fAngXZ > 360.0f )
			fAngXZ -= 360.0f;
		AngleToVector( &vPos2, fAngXZ, -fAngH, 0.05f );
		vPos2 += GetPos();

		if( m_pTail )
			m_pTail->CreateTail( vPos1, vPos2 );
		
		vDelta = m_pSfxObj->m_vPos - m_vPosDest;		// ´ë»ó°úÀÇ °Å¸®
		if( D3DXVec3LengthSq( &vDelta ) < 0.4f * 0.4f )		// Æø¹ß °Å¸®±îÁö ´Ù°¡°¡¸é Ãæµ¹.
		{
			if( m_dwSndHit != NULL_ID )
				PLAYSND( m_dwSndHit, &GetPos() );		// »ç¿îµå ÇÃ·¹ÀÌ.
			DamageToTarget();
			// Æø¹ß ¿ÀºêÁ§Æ® »ý¼º.
			if( m_dwSfxHit != NULL_ID )
			{
				CSfx *pSfx = CreateSfx( D3DDEVICE, m_dwSfxHit, GetPos(), m_idSrc, m_vPosDest, m_idDest, 0 );
				if( pSfx )
				{
					pSfx->SetAngle( m_pSfxObj->m_vRotate.y );
				}
			}
			Delete();	// this´Â »èÁ¦.
		}
	}
	m_nFrame ++;

	if( m_nFrame >= SEC1 * 10 )		// ³Ê¹«¿À·¡ ¦i¾Æ°¡Áö ¾Ê°Ô 10ÃÊÁö³ª¸é ¼Ò¸ê
		Delete();	
}
void CSfxItemRangeAtk1::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render2( pd3dDevice );
}

// ¿ä¿ä»ý¼º
D3DXVECTOR3	CSfxItemYoyoAtk::SplineSlerp( D3DXVECTOR3 *v1, D3DXVECTOR3 *v2, D3DXVECTOR3 *v3, D3DXVECTOR3 *v4, float fSlerp )
{
	D3DXVECTOR3		vResult;
	
	float	t = fSlerp;
	float	t2 = t * t;
	float	t3 = t2 * t;
	
	D3DXVECTOR3		m0, m1;
	const float alpha = 0.0f;
	
	m0 = ((1 - alpha) / 2.0f) * 
		((*v2 - *v1) + *v3 - *v2);
	m1 = ((1 - alpha) / 2.0f) *
		((*v3 - *v2) + *v4 - *v3);
	
	vResult = (((2 * t3) - (3 * t2) + 1) * *v2) +
		((t3 - (2 * t2) + t) * m0) + 
		((t3 - t2) * m1) +
		(((-2 * t3) + (3 * t2)) *
		*v3 );
	
	return vResult;
}

#define MAX_DELAY    10
CSfxItemYoyoAtk::CSfxItemYoyoAtk() : CSfxShoot()
{
	m_pTail			= NULL;
	m_nStep			= 0;
	m_nCount        = 0;
	m_nType			= 0;
	m_nDelayCount = 0;
}

CSfxItemYoyoAtk::~CSfxItemYoyoAtk()
{
	if( m_pTail )
		g_TailEffectMng.Delete( m_pTail );
	m_pTail = NULL;
}


void CSfxItemYoyoAtk::MakePath(int nType)
{
	// ±æÀÌ 5¹ÌÅÍ
	m_fMaxLength = 50.0f;
	
	CMover* pObj = (CMover*)prj.GetCtrl( m_idSrc );	

	if( !IsValidObj(pObj) )
	{
		Delete();	// this´Â »èÁ¦.
		return;
	}

	FLOAT fLength;
	
	fLength = D3DXVec3LengthSq( &D3DXVECTOR3(m_vPosDest - GetPos()) );

	if( fLength > 7.0f * 7.0f )  // 7¹ÌÅÍ ÀÌ»ó ¸ø ³¯¶ó°¨
		fLength = 49.0f;

	if( fLength < 3.0f * 3.0f )  // 3¹ÌÅÍº¸´Ù ÀÛÀ¸¸é 2¹ÌÅÍ
		fLength = 12.0f;

	fLength /= 5.0f;

	m_nType = nType;

	///////////////////////////////////////////////////////////////////////////////////////////////
	D3DXVECTOR3		aNewPos[7];

	m_v3SrcPos = GetPos();
	D3DXVECTOR3 vLocal;
	
	// 5¹ÌÅÍ ¾Õ À§Ä¡±¸ÇÔ
	AngleToVectorXZ( &vLocal, 0, fLength );
	aNewPos[0] = vLocal;
	aNewPos[0].y -= 0.2f;
	
	AngleToVectorXZ( &vLocal, 0, fLength+0.5f );
	aNewPos[1] = vLocal;
	aNewPos[1].y -= 0.2f;

	AngleToVectorXZ( &vLocal, 0, fLength+1.0f );
	aNewPos[2] = vLocal;
	aNewPos[2].y -= 0.1f;

	// ³¡Á¡
	AngleToVectorXZ( &vLocal, 0, fLength+1.2f );
	aNewPos[3] = vLocal;

	// µÚµ¹¾Æ°¡±â
	AngleToVectorXZ( &vLocal, 0, fLength+1.0f );
	aNewPos[4] = vLocal;
	aNewPos[4].y += 0.1f;
	
	AngleToVectorXZ( &vLocal, 0, fLength+0.5f );
	aNewPos[5] = vLocal;
	aNewPos[5].y += 0.2f;
	
	AngleToVectorXZ( &vLocal, 0, fLength );
	aNewPos[6] = vLocal;
	aNewPos[6].y += 0.2f;

	D3DXVECTOR3 vSlp;
	int		a, b, c, d;
	int		nMaxVertex = 7;

	m_nMaxSpline = 0;
	for( int i = 0; i < nMaxVertex-1; i ++ )
	{
		// i ~ i+1»çÀÌ¸¦ º¸°£ÇÑ´Ù.  
		a = i - 1;		if( a < 0 )	a = 0;
		b = i;
		c = i+1;
		d = i+2;		if( d >= nMaxVertex )	d = nMaxVertex - 1;
		for( int j = 0; j < MAX_SF_SLERP+1; j ++ )
		{
			if( m_nMaxSpline >= 30 )
			{
				LPCTSTR szErr = Error( "CSfxItemYoyoAtk Spline : ¹üÀ§ ÃÊ°ú %d", m_nMaxSpline );
				ADDERRORMSG( szErr );
				break;
			}
			vSlp = SplineSlerp( &aNewPos[a], &aNewPos[b], &aNewPos[c], &aNewPos[d], (float)j / MAX_SF_SLERP );
			m_aSpline[ m_nMaxSpline ] = vSlp;
			m_nMaxSpline ++;
		}
	}
	///////////////////////////////////////////////////////////////////////////////////////////////
	D3DXVECTOR3 vDir      = D3DXVECTOR3( 0.0f, 0.0f, -1.0f );
	D3DXVECTOR3 vDestNor  = m_vPosDest - GetPos();

	D3DXVECTOR3 vAxis;
	D3DXQUATERNION   qRot;
	
	FLOAT       fTheta;
	D3DXVec3Normalize( &vDestNor, &vDestNor );
	D3DXVec3Cross( &vAxis, &vDir, &vDestNor );
	fTheta = D3DXVec3Dot( &vDir, &vDestNor );
	D3DXQuaternionRotationAxis( &qRot, &vAxis, acosf( fTheta ) );
	
	D3DXMATRIX mRot;
	D3DXMatrixRotationQuaternion( &mRot, &qRot );
	///////////////////////////////////////////////////////////////////////////////////////////////
				
	// ½ºÇÃ¶óÀÎ º¸°£µÈ Á¡µé ¿ùµå º¯È¯
	D3DXVECTOR3 vPosPos    = m_v3SrcPos;
	D3DXMATRIX mScal;
	D3DXMatrixScaling( &mScal, 1.0f, 1.0f, 1.0f );

	for( int i=0; i<m_nMaxSpline; i++ )
	{
		D3DXMATRIX mWorld = mRot * mScal * pObj->GetMatrixTrans();
		mWorld._42 = vPosPos.y;
		D3DXVec3TransformCoord( &m_aSpline[i], &m_aSpline[i], &mWorld );
	}
}

void CSfxItemYoyoAtk::Process()
{
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );	

	if( !IsValidObj(pObjSrc) )
	{
		Delete();	// this´Â »èÁ¦.
		return;
	}
	
	if( m_bHit == FALSE ) 
	{
		if( pObjSrc )
		{
			((CModelObject*)pObjSrc->m_pModel)->SetEffect( m_nType, XE_HIDE ); 
		}

		if( m_nDelayCount )
		{
			m_nDelayCount--;
			return;
		}

		// ³¯¾Æ°¡´Â ´Ü°è
		if( m_nStep == 0 )
		{
			D3DXVECTOR3 vPos   = GetPos();
			D3DXVECTOR3 vDelta = m_aSpline[0] - vPos;
			D3DXVec3Normalize( &vDelta, &vDelta );	
			vPos += vDelta * 0.3f;		
			m_pSfxObj->m_vPos = vPos;
			SetPos( vPos );
			
			FLOAT fLen = D3DXVec3LengthSq( &D3DXVECTOR3(m_aSpline[0] - vPos) );
			if( fLen <= 0.05f )
			{
				m_nStep = 1;
				m_nDelayCount = 6;
			}
		}
		else
		// È¸ÀüÇÏ´Â ´Ü°è
		if( m_nStep == 1 )
		{
			D3DXVECTOR3 vPosPos    = m_aSpline[m_nCount];
			
			m_pSfxObj->m_vPos = vPosPos;
			SetPos( vPosPos );

			m_nCount++;

			if( m_nCount >= m_nMaxSpline )
			{
				m_nStep = 2;
			}
		}
		else
		// µÇµ¹¾Æ ¿À´Â ´Ü°è
		if( m_nStep == 2 )
		{
			D3DXVECTOR3 v3SrcPos;
			CModelObject *pModel = (CModelObject *)pObjSrc->m_pModel;
			pModel->GetHandPos( &v3SrcPos, m_nType, pObjSrc->GetMatrixWorld() );
			
			D3DXVECTOR3 vPos   = GetPos();
			D3DXVECTOR3 vDelta = v3SrcPos - vPos;
			D3DXVec3Normalize( &vDelta, &vDelta );		// Å¸°ÙÂÊ ´ÜÀ§º¤ÅÍ ±¸ÇØ¼­
			vPos += vDelta * 0.4f;			// ±× º¤ÅÍ·Î ¼Óµµ¸¦ °áÁ¤ÇØ¼­ ÁÂÇ¥ ÀÌµ¿.
			m_pSfxObj->m_vPos = vPos;
			SetPos( vPos );

			FLOAT fLen = D3DXVec3LengthSq( &D3DXVECTOR3(v3SrcPos - vPos) );
			if( fLen <= 0.1f )
			{
				if( m_dwSndHit != NULL_ID )
					PLAYSND( m_dwSndHit, &GetPos() );		// »ç¿îµå ÇÃ·¹ÀÌ.

				// Æø¹ß ¿ÀºêÁ§Æ® »ý¼º.
				if( m_dwSfxHit != NULL_ID )
				{
					CSfx *pSfx = CreateSfx( D3DDEVICE, m_dwSfxHit, GetPos(), m_idSrc, m_vPosDest, m_idDest, 0 );
					if( pSfx )
					{
						pSfx->SetAngle( m_pSfxObj->m_vRotate.y );
					}
				}
				Delete();	// this´Â »èÁ¦.
				return;
			}
		}

		if( m_pSfxObj->Process() )		// ¾Ö´Ï¸ÞÀÌ¼ÇÀº ·çÇÁ.
		{
			m_pSfxObj->m_nCurFrame = 0;
		}
		if( m_pTail == NULL )	// ¾ÆÁ÷ ÇÒ´ç ¾ÈµÆÀ¸¸é ÇÒ´çÇÏ°í.
		{
			if( m_pSfxObj->m_pSfxBase->Part(0) )
				m_pTail = (CTailEffectModel*)g_TailEffectMng.AddEffect( g_Neuz.m_pd3dDevice, m_pSfxObj->m_pSfxBase->Part(0)->m_strTex, 100, 30.0f );
		}

		if( m_pTail )
		{
			D3DXMATRIX mWorld;
			D3DXMatrixTranslation( &mWorld, GetPos().x, GetPos().y, GetPos().z );
			m_pTail->CreateTail( &mWorld );
		}
	}
	m_nFrame ++;

	if( m_nFrame >= SEC1 * 5 )		// ³Ê¹«¿À·¡ ¦i¾Æ°¡Áö ¾Ê°Ô 5ÃÊÁö³ª¸é ¼Ò¸ê
		Delete();	
}

void CSfxItemYoyoAtk::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render2( pd3dDevice );
}



// ¾ûÅÍ¸® È­»ì »ý¼ºÇÑ´Ù. ÇÏ³ª´Â ÁøÂ¥~
CSfxItemRangeAtk_JunkBow::CSfxItemRangeAtk_JunkBow() : CSfxShoot()
{
	m_pTail[0]			 = NULL;
	m_pTail[1]			 = NULL;
	m_pTail[2]			 = NULL;
}
CSfxItemRangeAtk_JunkBow::~CSfxItemRangeAtk_JunkBow()
{
	for( int i=0; i<3; i++ )
	{
		if( m_pTail[i] )
			g_TailEffectMng.Delete( m_pTail[i] );

		m_pTail[i] = NULL;
	}
}

void CSfxItemRangeAtk_JunkBow::Process()
{
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );	// À¯µµÅº ÇüÀÌ±â¶§¹®¿¡ Å¸°ÙÀº Ç×»ó ÀÐ¾îºÁ¾ß ÇÑ´Ù.
	if( IsValidObj(pObjDest) )
	{
		m_vPosDest = pObjDest->GetPos() + D3DXVECTOR3( 0, 1.0f, 0 );
	} else
	{
		// ³¯¾Æ°¡´Ù Å¸°ÙÀÌ ¾ø¾îÁ³À¸¸é ¸¶Áö¸·ÁÂÇ¥·Î ³¯¾Æ°¡¼­ ÅÍÁö°Ô.
		Delete();	// this´Â »èÁ¦.
		int a = 0;
	}
	
	if( m_bHit == FALSE ) 
	{
		if( m_pSfxObj->Process() )		// ¾Ö´Ï¸ÞÀÌ¼ÇÀº ·çÇÁ.
		{
			m_pSfxObj->m_nCurFrame = 0;
		}
		D3DXVECTOR3 vPos = GetPos();
		D3DXVECTOR3 vDelta = m_vPosDest - vPos;
		D3DXVec3Normalize( &vDelta, &vDelta );		// Å¸°ÙÂÊ ´ÜÀ§º¤ÅÍ ±¸ÇØ¼­
		vPos += vDelta * 0.7f;			// ±× º¤ÅÍ·Î ¼Óµµ¸¦ °áÁ¤ÇØ¼­ ÁÂÇ¥ ÀÌµ¿.
		m_pSfxObj->m_vPos = vPos;
		SetPos( vPos );
		
		//if( m_bDir )
		{
			// ¸¶¹ý°´Ã¼ ¹æÇâº¤ÅÍ·Î ¸ðµ¨ ¹æÇâ µ¹¸®±â~~~
			D3DXVECTOR3 vDir      = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
			D3DXVECTOR3 vDestNor  = m_vPosDest - m_pSfxObj->m_vPos;
			D3DXVECTOR3 vAxis;
			D3DXQUATERNION   qRot;
			
			FLOAT       fTheta;
			D3DXVec3Normalize( &vDestNor, &vDestNor );
			D3DXVec3Cross( &vAxis, &vDir, &vDestNor );
			fTheta = D3DXVec3Dot( &vDir, &vDestNor );
			D3DXQuaternionRotationAxis( &qRot, &vAxis, acosf( fTheta ) );
			
			D3DXVECTOR3 vYPW;
			
			QuaternionRotationToYPW( qRot, vYPW );
			m_pSfxObj->m_vRotate.x = m_SfxObj2.m_vRotate.x = D3DXToDegree(vYPW.x);
			m_pSfxObj->m_vRotate.y = m_SfxObj2.m_vRotate.y = D3DXToDegree(vYPW.y);
			m_pSfxObj->m_vRotate.z = m_SfxObj2.m_vRotate.z = D3DXToDegree(vYPW.z);

		}
		
		for( int i=0; i<3; i++ )
		{
			if( m_pTail[i] )
			{
				if( m_pTail[i]->GetType() != 2 )	// »ý¼ºµÇ¾ú´ø ²¿¸®°í ÀÏ¹Ýº¸µå¿ëÀÌ ¾Æ´Ï¸é 
					m_pTail[i]->ChangeTexture( D3DDEVICE, "etc_Tail2.bmp", 2 );	// ÀÏ¹Ýº¸µå¿ëÀ¸·Î ÅØ½ºÃÄ ±³Ã¼.
			}
			if( m_pTail[i] == NULL )	// ¾ÆÁ÷ ÇÒ´ç ¾ÈµÆÀ¸¸é ÇÒ´çÇÏ°í.
			{
				m_pTail[i] = (CTailEffectBelt*)g_TailEffectMng.AddEffect( g_Neuz.m_pd3dDevice, "etc_Tail2.bmp", 2, 0.35f );
			}
		}
		
		D3DXVECTOR3	vPos1, vPos2;
		FLOAT		fAngXZ = GetAngle();
		FLOAT		fAngH  = GetAngleX();
		
		fAngXZ -= 90.0f;
		if( fAngXZ < 0 )
			fAngXZ += 360.0f;
		AngleToVector( &vPos1, fAngXZ, -fAngH, 0.05f );
		vPos1 += GetPos();
		
		fAngXZ = GetAngle();
		fAngH  = GetAngleX();
		
		fAngXZ += 90.0f;
		if( fAngXZ > 360.0f )
			fAngXZ -= 360.0f;
		AngleToVector( &vPos2, fAngXZ, -fAngH, 0.05f );
		vPos2 += GetPos();

		vPos1.y -= 0.5f;
		vPos2.y -= 0.5f;
		
		for( int i=0; i<3; i++ )
		{
			if( m_pTail[i] )
			{
				m_pTail[i]->CreateTail( vPos1, vPos2 );
			}

			vPos1.y += 0.5f;
			vPos2.y += 0.5f;
		}
		
		vDelta = m_pSfxObj->m_vPos - m_vPosDest;		// ´ë»ó°úÀÇ °Å¸®
		if( D3DXVec3LengthSq( &vDelta ) < 0.4f * 0.4f )		// Æø¹ß °Å¸®±îÁö ´Ù°¡°¡¸é Ãæµ¹.
		{
			if( m_dwSndHit != NULL_ID )
				PLAYSND( m_dwSndHit, &GetPos() );		// »ç¿îµå ÇÃ·¹ÀÌ.
			DamageToTarget();
			// Æø¹ß ¿ÀºêÁ§Æ® »ý¼º.
			if( m_dwSfxHit != NULL_ID )
			{
				CSfx *pSfx = CreateSfx( D3DDEVICE, m_dwSfxHit, GetPos(), m_idSrc, m_vPosDest, m_idDest, 0 );
				if( pSfx )
				{
					pSfx->SetAngle( m_pSfxObj->m_vRotate.y );
				}
			}
			Delete();	// this´Â »èÁ¦.
		}
	}
	m_nFrame ++;

	if( m_nFrame >= SEC1 * 10 )		// ³Ê¹«¿À·¡ ¦i¾Æ°¡Áö ¾Ê°Ô 10ÃÊÁö³ª¸é ¼Ò¸ê
		Delete();	
}
void CSfxItemRangeAtk_JunkBow::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();

	// ÁÂÇ¥ ¹é¾÷
	D3DXVECTOR3 vPosBackup = m_pSfxObj->m_vPos;
	// ÁøÂ¥ È­»ì
	m_pSfxObj->Render2( pd3dDevice );
	
	// °¡Â¥ 1
	m_pSfxObj->m_vPos.y += 0.5f;
	m_pSfxObj->Render2( pd3dDevice );

	// °¡Â¥ 2
	m_pSfxObj->m_vPos = vPosBackup;
	m_pSfxObj->m_vPos.y -= 0.5f;
	m_pSfxObj->Render2( pd3dDevice );


	// ÁÂÇ¥º¹±¸
	m_pSfxObj->m_vPos = vPosBackup;
	
}


// ¾Æ·¡·Î ¶³¾îÁö´Â È­»ì ÀÌÆåÆ®
CSfxItemRangeAtk1_Allow::CSfxItemRangeAtk1_Allow() : CSfxShoot()
{
	m_nFrame = 0;
	m_fSpeed = xRandomF( 0.7f ) + 0.2f;
}

CSfxItemRangeAtk1_Allow::~CSfxItemRangeAtk1_Allow()
{
}

void CSfxItemRangeAtk1_Allow::Process()
{
	if( m_pSfxObj->Process() )		// ¾Ö´Ï¸ÞÀÌ¼ÇÀº ·çÇÁ.
	{
		m_pSfxObj->m_nCurFrame = 0;
	}

	D3DXVECTOR3 vPos = GetPos();
	D3DXVECTOR3 vDelta = D3DXVECTOR3( 0.0f, -1.0f, 0.0f );
	D3DXVec3Normalize( &vDelta, &vDelta );		// Å¸°ÙÂÊ ´ÜÀ§º¤ÅÍ ±¸ÇØ¼­

	vPos += vDelta * m_fSpeed;			// ±× º¤ÅÍ·Î ¼Óµµ¸¦ °áÁ¤ÇØ¼­ ÁÂÇ¥ ÀÌµ¿.

	CWorld* pWorld = g_WorldMng.Get();
	FLOAT fHeight = pWorld->GetLandHeight_Fast( vPos.x, vPos.z );

	// ¶¥ ³ôÀÌº¸´Ù ³·À¸¸é ¾ÈµÊ
	if( vPos.y < fHeight )
	{
		m_nFrame++;
		vPos.y = fHeight;
		
		CSfx *pSfx = CreateSfx( D3DDEVICE, XI_SKILL_RAG_BOW_ARROWRAIN01, vPos );//, m_idSrc, vPos, m_idDest, 0 );		
		Delete();
	}

	m_pSfxObj->m_vPos = vPos;
		
	SetPos( vPos );
}
void CSfxItemRangeAtk1_Allow::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render2( pd3dDevice );
}

#define MAX_ALLOW		50

// CSfxItemRangeAtk1_Allow»ý¼º °ü¸® - ½ÇÁ¦ »ç¿ëµÇ¾îÁö´Â ºÎºÐ
CSfxItemRangeAtk1_AllowRain::CSfxItemRangeAtk1_AllowRain() : CSfxShoot()
{
	m_nFrame = 0;
	m_nCount = 0;
}

CSfxItemRangeAtk1_AllowRain::~CSfxItemRangeAtk1_AllowRain()
{
}

void CSfxItemRangeAtk1_AllowRain::Process()
{
	D3DXVECTOR3 vPos = GetPos();
	
	CWorld* pWorld = g_WorldMng.Get();
	FLOAT fHeight = pWorld->GetLandHeight_Fast( vPos.x, vPos.z );
	
	// 10¹ÌÅÍÀ§¿¡¼­ ¶³¾î¶ß¸²
	vPos.y = fHeight + xRandomF(2.0f) + 9.0f;

	m_nFrame++;

	if( m_nCount < MAX_ALLOW )
	{
		if( m_nFrame >= SEC1 * 0.07f )
		{
			m_nFrame = 0;
			vPos.x += (xRandomF( 6.0f ) + -3.0f);
			vPos.z += (xRandomF( 6.0f ) + -3.0f);

			CSfx *pSfx = CreateSfx( D3DDEVICE, XI_SKILL_RAG_BOW_ARROWRAIN, vPos, m_idSrc, m_vPosDest, m_idDest, 0 );

			vPos.x += (xRandomF( 6.0f ) + -3.0f);
			vPos.z += (xRandomF( 6.0f ) + -3.0f);
			
			pSfx = CreateSfx( D3DDEVICE, XI_SKILL_RAG_BOW_ARROWRAIN, vPos, m_idSrc, m_vPosDest, m_idDest, 0 );
			m_nCount++;
		}
	}
	else
		Delete();
}
void CSfxItemRangeAtk1_AllowRain::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
}

CSfxItemRangeAtk1_Stone::CSfxItemRangeAtk1_Stone() : CSfxShoot()
{
	m_nFrame = 0;
	m_fSpeed = xRandomF( 0.7f ) + 0.7f;
}

CSfxItemRangeAtk1_Stone::~CSfxItemRangeAtk1_Stone()
{
}

void CSfxItemRangeAtk1_Stone::Process()
{
	if( m_pSfxObj->Process() )		// ¾Ö´Ï¸ÞÀÌ¼ÇÀº ·çÇÁ.
	{
		m_pSfxObj->m_nCurFrame = 0;
	}
	
	D3DXVECTOR3 vPos = GetPos();
	D3DXVECTOR3 vDelta = D3DXVECTOR3( 0.0f, -1.0f, 0.0f );
	D3DXVec3Normalize( &vDelta, &vDelta );		// Å¸°ÙÂÊ ´ÜÀ§º¤ÅÍ ±¸ÇØ¼­
	
	vPos += vDelta * m_fSpeed;			// ±× º¤ÅÍ·Î ¼Óµµ¸¦ °áÁ¤ÇØ¼­ ÁÂÇ¥ ÀÌµ¿.
	
	CWorld* pWorld = g_WorldMng.Get();
	FLOAT fHeight = pWorld->GetLandHeight_Fast( vPos.x, vPos.z );
	
	// ¶¥ ³ôÀÌº¸´Ù ³·À¸¸é ¾ÈµÊ
	if( vPos.y < fHeight+2.5f )
	{
		m_nFrame++;
		vPos.y = fHeight;
		
		CSfx *pSfx = CreateSfx( D3DDEVICE, XI_SKILL_CIRCLE_DUST, vPos );		
		if( pSfx )
		{
			pSfx->SetScale( D3DXVECTOR3( 3.0f, 3.0f, 3.0f ) );					
		}			
		Delete();
	}
	
	m_pSfxObj->m_vPos = vPos;
	
	SetPos( vPos );
}
void CSfxItemRangeAtk1_Stone::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render2( pd3dDevice );
}

#define MAX_STONE		50

// CSfxItemRangeAtk1_Allow»ý¼º °ü¸® - ½ÇÁ¦ »ç¿ëµÇ¾îÁö´Â ºÎºÐ
CSfxItemRangeAtk1_StoneRain::CSfxItemRangeAtk1_StoneRain() : CSfxShoot()
{
	m_nFrame = 0;
	m_nCount = 0;
}

CSfxItemRangeAtk1_StoneRain::~CSfxItemRangeAtk1_StoneRain()
{
}

void CSfxItemRangeAtk1_StoneRain::Process()
{
	D3DXVECTOR3 vPos = GetPos();
	
	CWorld* pWorld = g_WorldMng.Get();
	FLOAT fHeight = pWorld->GetLandHeight_Fast( vPos.x, vPos.z );
	
	// 10¹ÌÅÍÀ§¿¡¼­ ¶³¾î¶ß¸²
	vPos.y = fHeight + xRandomF(2.0f) + 40.0f;
	
	m_nFrame++;
	
	if( m_nCount < MAX_STONE )
	{
		if( m_nFrame >= SEC1 * 0.2f )
		{
			m_nFrame = 0;
			vPos.x += (xRandomF( 40.0f ) + -20.0f);
			vPos.z += (xRandomF( 40.0f ) + -20.0f);
			
			CSfx *pSfx = CreateSfx( D3DDEVICE, XI_SKILL_DROP_DUST, vPos, m_idSrc, m_vPosDest, m_idDest, 0 );
			if( pSfx )
			{
				pSfx->SetScale( D3DXVECTOR3( 8.0f, 8.0f, 8.0f ) );					
			}
			m_nCount++;
		}
	}
	else
		Delete();
}
void CSfxItemRangeAtk1_StoneRain::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
}

//
// ÀÏÁ÷¼±À¸·Î »¸¾î³ª°¡´Â ÇüÅÂÀÇ Àå°Å¸® °ø°Ý
//
CSfxAtkStraight::CSfxAtkStraight()
{
	m_dwExplosion = NULL_ID;
}
CSfxAtkStraight::~CSfxAtkStraight()
{
}

// ¹ß»çÃ¼ÀÇ ÀÌµ¿Áõ°¡·®À» ¼±°è»êÇÔ. 
void CSfxAtkStraight::ShootSfx( float fAngXZ, float fAngH, float fSpeed, DWORD dwExplosion )
{
	m_pSfxObj->m_vPos = GetPos();		// sfx¸ðµ¨ÀÇ À§Ä¡¸¦ ¼¼ÆÃ.
	m_dwExplosion = dwExplosion;

	AngleToVector( &m_vDelta, fAngXZ, fAngH, fSpeed );		// ÀÌµ¿·® vDelta¸¦ ±¸ÇÔ.

	// ¸¶¹ý°´Ã¼ ¹æÇâº¤ÅÍ·Î ¸ðµ¨ ¹æÇâ µ¹¸®±â~~~
	D3DXVECTOR3 vDir      = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
	D3DXVECTOR3 vDestNor  = m_vDelta;//m_vPosDest - GetPos();
	D3DXVECTOR3 vAxis;
	D3DXQUATERNION   qRot;
	
	FLOAT       fTheta;
	D3DXVec3Normalize( &vDestNor, &vDestNor );
	D3DXVec3Cross( &vAxis, &vDir, &vDestNor );
	fTheta = D3DXVec3Dot( &vDir, &vDestNor );
	D3DXQuaternionRotationAxis( &qRot, &vAxis, acosf( fTheta ) );
	
	D3DXVECTOR3 vYPW;
	
	QuaternionRotationToYPW( qRot, vYPW );
	m_pSfxObj->m_vRotate.x = D3DXToDegree(vYPW.x);
	m_pSfxObj->m_vRotate.y = D3DXToDegree(vYPW.y);
	m_pSfxObj->m_vRotate.z = D3DXToDegree(vYPW.z);
	
}
				  
void CSfxAtkStraight::Process()
{
	if( m_pSfxObj->Process() )			// SFX ¾Ö´Ï¸ÞÀÌ¼ÇÀ» Ã³¸®ÇÏ°í
		m_pSfxObj->m_nCurFrame = 0;		// ¸ñÇ¥Á¡¿¡ ¸ÂÀ»¶§±îÁö ·çÇÁ½ÃÅ°±â À§ÇØ ´Ù½Ã 0ÇÁ·¹ÀÓÀ¸·Î µ¹·Á³õ´Â´Ù.
	
	m_pSfxObj->m_vPos += m_vDelta;		// ÁÂÇ¥ ÀÌµ¿.
	SetPos( m_pSfxObj->m_vPos );		// thisµµ ÁÂÇ¥ °°ÀÌ ÀÌµ¿.
	
#if __VER >= 10 // __Y_DRAGON_FIRE	
	#ifdef __CLIENT
		//D3DXVECTOR3 vDir = v3 - v1;
		//D3DXVec3Normalize( &vDir, &vDir );
		D3DXVECTOR3 vTemp = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
		D3DXVECTOR3 vScal = D3DXVECTOR3( 0.3f, 0.3f, 0.3f );
		D3DXVECTOR3 vModelScal = GetScale();

		vScal.x *= vModelScal.x;
		vScal.y *= vModelScal.y;
		vScal.z *= vModelScal.z;

		for( int i = 0; i < 2; i ++ )
		{
			//vTemp = vDir * (xRandomF( 0.2f ) + 0.1f );
			//vTemp *= 0.8f;
			//vTemp.y -= (xRandomF( 0.05f ) + 0.01f );
			
			//extern CPartsFireDragon	g_FireDragon;
			//g_FireDragon.Create( D3DDEVICE, m_pSfxObj->m_vPos, XI_NAT_FIRE01_ADV, vScal, vTemp );
		}
	#endif
#endif //__Y_DRAGON_FIRE

	if( IsRangeObj( m_vPosDest, 0 ) )							// ¸ñÇ¥ÁÂÇ¥¿¡ ´Ù´Ù¸£¸é
	{
		CreateSfx( D3DDEVICE, m_dwExplosion, m_vPosDest );		// Æø¹ß ÀÌÆåÆ®
		Delete();												// ³­ »èÁ¦.
		return;
	}

	m_nFrame++;
	if( m_nFrame > 60 * 3 )
	{
		Delete();
	}
}
void CSfxAtkStraight::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	if( !IsVisible() || ( IsCull() && GetType() != 1 ))
		return;
	if( IsUpdateMatrix() )
		UpdateMatrix();
	
	LPMODELELEM lpModelElem = prj.m_modelMng.GetModelElem( m_dwType, m_dwIndex );
	// ModelÀÌ ¾øÀ¸¸é Ãâ·ÂÇÏÁö ¾ÊÀ½ 
	if( lpModelElem == NULL )
		return;
	
	m_pSfxObj->m_vPos = GetPos();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->m_matScale = m_matScale;
	m_pSfxObj->Render2( pd3dDevice, NULL );
	
}


CSfxItemWandAtk2::CSfxItemWandAtk2()
{
	m_SfxObj2.SetSfx("sfx_HitWand01"); // ¸Â´Â ¼ø°£ÀÇ SFX¸¦ µû·Î ·ÎµùÇÑ´Ù.
	m_bHit=FALSE;
}
CSfxItemWandAtk2::~CSfxItemWandAtk2()
{
}
void CSfxItemWandAtk2::Process()
{
	if(m_nFrame==0) {
		CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
		if(pObjSrc) m_pSfxObj->m_vPos=pObjSrc->GetPos()+D3DXVECTOR3(.0f,1.0f,.0f);
	}
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );
	if(pObjDest) m_SfxObj2.m_vPos=pObjDest->GetPos()+D3DXVECTOR3(.0f,1.0f,.0f);

	if(m_bHit==FALSE) {
		m_pSfxObj->Process();
		if(m_pSfxObj->m_nCurFrame==20)
		{
			m_pSfxObj->m_nCurFrame=0;
		}
		D3DXVECTOR3 vDelta=m_SfxObj2.m_vPos-m_pSfxObj->m_vPos;
		D3DXVec3Normalize(&vDelta,&vDelta);
		m_pSfxObj->m_vPos+=vDelta*.2f;
		SetPos(m_pSfxObj->m_vPos);
		vDelta=m_pSfxObj->m_vPos-m_SfxObj2.m_vPos;
		FLOAT fAngle;
		if(vDelta.z>0) {
			fAngle=(float)(atan(vDelta.x/vDelta.z)*180/3.1415926f)+180;
		}
		else {
			fAngle=(float)(atan(vDelta.x/vDelta.z)*180/3.1415926f);
		}
		m_pSfxObj->m_vRotate.y=m_SfxObj2.m_vRotate.y=fAngle;
		if(D3DXVec3Length(&vDelta)<.2f) {
			m_bHit=TRUE;
		}
	}
	else {
		if(m_SfxObj2.m_nCurFrame==0) {
			// ¿©±â´Ù°¡ ¸Â´Â¼ø°£Ã³¸®
			DamageToTarget();
		}
		if(m_SfxObj2.Process()) {
			Delete();
		}
	}
	m_nFrame++;
}
void CSfxItemWandAtk2::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	if(m_bHit==FALSE) 
	{
		m_pSfxObj->Render( pd3dDevice );
	}
	else 
	{
		if( !g_Option.m_bSFXRenderOff )
			m_SfxObj2.Render( pd3dDevice );
	}
}
CSfxItemWandAtk3::CSfxItemWandAtk3()
{
	m_SfxObj2.SetSfx("sfx_HitWand01"); // ¸Â´Â ¼ø°£ÀÇ SFX¸¦ µû·Î ·ÎµùÇÑ´Ù.
	m_bHit=FALSE;
}
CSfxItemWandAtk3::~CSfxItemWandAtk3()
{
}
void CSfxItemWandAtk3::Process()
{
	if(m_nFrame==0) {
		CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
		if(pObjSrc) m_pSfxObj->m_vPos=pObjSrc->GetPos()+D3DXVECTOR3(.0f,1.0f,.0f);
	}
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );
	if(pObjDest) m_SfxObj2.m_vPos=pObjDest->GetPos()+D3DXVECTOR3(.0f,1.0f,.0f);

	if(m_bHit==FALSE) {
		m_pSfxObj->Process();
		if(m_pSfxObj->m_nCurFrame==20)
		{
			m_pSfxObj->m_nCurFrame=0;
		}
		D3DXVECTOR3 vDelta=m_SfxObj2.m_vPos-m_pSfxObj->m_vPos;
		D3DXVec3Normalize(&vDelta,&vDelta);
		m_pSfxObj->m_vPos+=vDelta*.2f;
		SetPos(m_pSfxObj->m_vPos);
		vDelta=m_pSfxObj->m_vPos-m_SfxObj2.m_vPos;
		FLOAT fAngle;
		if(vDelta.z>0) {
			fAngle=(float)(atan(vDelta.x/vDelta.z)*180/3.1415926f)+180;
		}
		else {
			fAngle=(float)(atan(vDelta.x/vDelta.z)*180/3.1415926f);
		}
		m_pSfxObj->m_vRotate.y=m_SfxObj2.m_vRotate.y=fAngle;
		if(D3DXVec3Length(&vDelta)<.2f) {
			m_bHit=TRUE;
		}
	}
	else {
		if(m_SfxObj2.m_nCurFrame==0) {
			// ¿©±â´Ù°¡ ¸Â´Â¼ø°£Ã³¸®
			DamageToTarget();
		}
		if(m_SfxObj2.Process()) {
			Delete();
		}
	}
	m_nFrame++;
}
void CSfxItemWandAtk3::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	if(m_bHit==FALSE) 
	{
		m_pSfxObj->Render( pd3dDevice );
	}
	else 
	{
		if( !g_Option.m_bSFXRenderOff )
			m_SfxObj2.Render( pd3dDevice );
	}
}
CSfxItemWandAtk4::CSfxItemWandAtk4()
{
	m_SfxObj2.SetSfx("sfx_HitWand01"); // ¸Â´Â ¼ø°£ÀÇ SFX¸¦ µû·Î ·ÎµùÇÑ´Ù.
	m_bHit=FALSE;
}
CSfxItemWandAtk4::~CSfxItemWandAtk4()
{
}
void CSfxItemWandAtk4::Process()
{
	if(m_nFrame==0) {
		CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
		if(pObjSrc) m_pSfxObj->m_vPos=pObjSrc->GetPos()+D3DXVECTOR3(.0f,1.0f,.0f);
	}
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );
	if(pObjDest) m_SfxObj2.m_vPos=pObjDest->GetPos()+D3DXVECTOR3(.0f,1.0f,.0f);

	if(m_bHit==FALSE) {
		m_pSfxObj->Process();
		if(m_pSfxObj->m_nCurFrame==20)
		{
			m_pSfxObj->m_nCurFrame=0;
		}
		D3DXVECTOR3 vDelta=m_SfxObj2.m_vPos-m_pSfxObj->m_vPos;
		D3DXVec3Normalize(&vDelta,&vDelta);
		m_pSfxObj->m_vPos+=vDelta*.2f;
		SetPos(m_pSfxObj->m_vPos);
		vDelta=m_pSfxObj->m_vPos-m_SfxObj2.m_vPos;
		FLOAT fAngle;
		if(vDelta.z>0) {
			fAngle=(float)(atan(vDelta.x/vDelta.z)*180/3.1415926f)+180;
		}
		else {
			fAngle=(float)(atan(vDelta.x/vDelta.z)*180/3.1415926f);
		}
		m_pSfxObj->m_vRotate.y=m_SfxObj2.m_vRotate.y=fAngle;
		if(D3DXVec3Length(&vDelta)<.2f) {
			m_bHit=TRUE;
		}
	}
	else {
		if(m_SfxObj2.m_nCurFrame==0) {
			// ¿©±â´Ù°¡ ¸Â´Â¼ø°£Ã³¸®
			DamageToTarget();
		}
		if(m_SfxObj2.Process()) {
			Delete();
		}
	}
	m_nFrame++;
}
void CSfxItemWandAtk4::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	if(m_bHit==FALSE) 
	{
		m_pSfxObj->Render( pd3dDevice );
	}
	else 
	{
		if( !g_Option.m_bSFXRenderOff )
			m_SfxObj2.Render( pd3dDevice );
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ½ºÅ³ È¿°úµé

// ¹æ¶ûÀÚ ±âº» ½ºÅ³ 1
CSfxSkillVagOverCutter::CSfxSkillVagOverCutter()
{
}
CSfxSkillVagOverCutter::~CSfxSkillVagOverCutter()
{
}
void CSfxSkillVagOverCutter::Process()
{
	m_nFrame++;
	{		
		CMover* pObjDst = (CMover*)prj.GetCtrl( m_idDest );
		CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
		if( pObjDst && pObjSrc ) 
		{
			SetPos( pObjDst->GetPos() + D3DXVECTOR3( .0f, 1.0f, .0f) );
			SetAngle( 180.0f - pObjSrc->GetAngle() ); // ½ÃÀüÀÚÀÇ ¹æÇâ°ú ÀÏÄ¡½ÃÅ²´Ù.
		}
		if( m_pSfxObj->Process() )
			Delete();
	}
}
void CSfxSkillVagOverCutter::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos = GetPos();
	m_pSfxObj->m_vRotate.y = GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}
// ¹æ¶ûÀÚ ±âº» ½ºÅ³ 2
CSfxSkillVagCleanHit::CSfxSkillVagCleanHit()
{
}
CSfxSkillVagCleanHit::~CSfxSkillVagCleanHit()
{
}
void CSfxSkillVagCleanHit::Process()
{
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if( IsValidObj(pObjSrc) ) 
	{
		SetPos( m_vPosDest );		// ¸ñÇ¥ÁöÁ¡¿¡ Ç×»ó ¹ß»ýµÇ¾î ÀÖÀ½.
		SetAngle( 180.0f - pObjSrc->GetAngle() ); // ½ÃÀüÀÚÀÇ ¹æÇâ°ú ÀÏÄ¡½ÃÅ²´Ù.
	}
	if( m_pSfxObj->Process() )		// ¾Ö´Ï¸ÞÀÌ¼ÇÀÌ ³¡³ª¸é ³¡.
		Delete();

	m_nFrame++;
	
}
void CSfxSkillVagCleanHit::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate.y=GetAngle();//+180;
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}


// °íÁ¤ÁÂÇ¥ ±âÁØ sfx
CSfxFixed::CSfxFixed()
{
}
CSfxFixed::~CSfxFixed()
{
}
void CSfxFixed::Process()
{
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if( IsValidObj(pObjSrc) ) 
	{
		SetPos( m_vPosDest );		// ¸ñÇ¥ÁöÁ¡¿¡ Ç×»ó ¹ß»ýµÇ¾î ÀÖÀ½.
	}
	if( m_nSec == 0 )	// 0Àº 1È¸ ÇÃ·¹ÀÌÈÄ Á¾·á.
	{
		if( m_pSfxObj->Process() )		// return true´Â ¾Ö´Ï¸ÞÀÌ¼Ç ³¡.
			Delete();
	}
	else
	{
		// ¹Ýº¹ ¾Ö´Ï¸ÞÀÌ¼Ç
		if( m_pSfxObj->Process() )		
			m_pSfxObj->m_nCurFrame = 0;
		if( m_nSec != -1 )		// ¹«ÇÑ¹Ýº¹(-1)ÀÌ ¾Æ´Ï¸é
		{
			if( m_nFrame > ( m_nSec * 60 ) )	// ½Ã°£ Ã¼Å©¸¦ ÇÑ´Ù.
				Delete();
		}
	}
	
	m_nFrame++;
}

void CSfxFixed::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos = GetPos();
	m_pSfxObj->m_vRotate.y = GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// ¹æ¶ûÀÚ ±âº» ½ºÅ³ 3
CSfxSkillVagBrandish::CSfxSkillVagBrandish()
{
}
CSfxSkillVagBrandish::~CSfxSkillVagBrandish()
{
}
void CSfxSkillVagBrandish::Process()
{
	m_nFrame++;
	{ 
		CMover* pObjDst = (CMover*)prj.GetCtrl( m_idDest );
		if( pObjDst ) 
		{
			SetPos( pObjDst->GetPos() + D3DXVECTOR3( .0f, 1.0f, .0f)  );
			SetAngle( 180.0f - pObjDst->GetAngle() );
		}
		if(m_pSfxObj->Process())
			Delete();
	}
}
void CSfxSkillVagBrandish::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate.y=GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// ¸Ó¼Å³Ê¸® ±âº» ½ºÅ³ 1
CSfxSkillMerKeenWheel::CSfxSkillMerKeenWheel()
{
}
CSfxSkillMerKeenWheel::~CSfxSkillMerKeenWheel()
{
}
void CSfxSkillMerKeenWheel::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxSkillMerKeenWheel::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate.y=GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}
// ¸Ó¼Å³Ê¸® ±âº» ½ºÅ³ 2
CSfxSkillMerSplmash::CSfxSkillMerSplmash()
{
	m_SfxObj2.SetSfx(XI_SKILL_MER_ONE_SPLMASH02);
}
CSfxSkillMerSplmash::~CSfxSkillMerSplmash()
{
}
void CSfxSkillMerSplmash::Process()
{
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if(m_nFrame==0 && pObjSrc) 
	{
		SetPos(pObjSrc->GetPos());
		SetAngle(180.0f-pObjSrc->GetAngle());
	}
	m_pSfxObj->Process();
	if( m_nFrame > 85 ) 
	{
		if( m_SfxObj2.Process() )
		{
			Delete();
		}
	}
	m_nFrame++;
}
void CSfxSkillMerSplmash::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate.y=GetAngle();
	m_SfxObj2.m_vPos=GetPos();
	m_SfxObj2.m_vRotate.y=GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_SfxObj2.m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
	if(m_nFrame>85) 
	{
		if( !g_Option.m_bSFXRenderOff )
			m_SfxObj2.Render( pd3dDevice );
	}
}
// ¸Ó¼Å³Ê¸® ±âº» ½ºÅ³ 3
CSfxSkillMerBlindSide::CSfxSkillMerBlindSide()
{
}
CSfxSkillMerBlindSide::~CSfxSkillMerBlindSide()
{
}
void CSfxSkillMerBlindSide::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxSkillMerBlindSide::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate.y=GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// ¾î½Ã ³ÊÅ¬½ºÅ³
CSfxSkillAssBurstcrack::CSfxSkillAssBurstcrack()
{
}
CSfxSkillAssBurstcrack::~CSfxSkillAssBurstcrack()
{
}
void CSfxSkillAssBurstcrack::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}

	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if( IsValidObj( pObjSrc ) )
	{
		m_pSfxObj->m_vPos = GetPos();
		m_pSfxObj->m_vPos.y += 0.1f;
		m_pSfxObj->m_vRotate.y = 180 - pObjSrc->GetAngle();
		m_pSfxObj->m_vScale    = D3DXVECTOR3( 0.6f, 0.6f, 0.6f );
	}
	else
		Delete();
}
void CSfxSkillAssBurstcrack::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->Render( pd3dDevice );
}

CSfxSkillAssTampinghole::CSfxSkillAssTampinghole()
{
}
CSfxSkillAssTampinghole::~CSfxSkillAssTampinghole()
{
}
void CSfxSkillAssTampinghole::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}

	CMover* pObjSrc  = (CMover*)prj.GetCtrl( m_idSrc );
	
	if( IsValidObj( pObjSrc ) )
	{
		m_pSfxObj->m_vPos = GetPos();
		m_pSfxObj->m_vPos.y += 1.0f;
		
		m_pSfxObj->m_vRotate.y = 180 - pObjSrc->GetAngle();
		
		D3DXMATRIX mRot;
		D3DXVECTOR3 vDir = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
		D3DXMatrixRotationY( &mRot, D3DXToRadian( m_pSfxObj->m_vRotate.y ) );
		D3DXVec3TransformCoord( &vDir, &vDir, &mRot );
		
		D3DXVec3Normalize( &vDir, &vDir );
		
		m_pSfxObj->m_vPos += vDir*1.0f;
	}
	else
		Delete();
}
void CSfxSkillAssTampinghole::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->Render( pd3dDevice );
}

CSfxNpcDirSteam::CSfxNpcDirSteam()
{
	m_fInit = TRUE;
}
CSfxNpcDirSteam::~CSfxNpcDirSteam()
{
}
void CSfxNpcDirSteam::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}

	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );

	D3DXVECTOR3 vDir = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );

	if( IsInvalidObj(pObjDest) )
	{
		Delete();
		return;
	}
	if( IsValidObj( pObjSrc ) )
	{
		MoverProp* pMoverProp = prj.GetMoverProp( pObjSrc->GetIndex() );

		if( pMoverProp == NULL )
			return;

		switch( pMoverProp->dwClass )
		{
			case RANK_LOW:
			case RANK_NORMAL:
			case RANK_CAPTAIN:
			case RANK_BOSS:
#ifdef __GOLDEN_MINE
			case RANK_SPECIAL:
			case RANK_BOSS_SPECIAL:
#endif // __GOLDEN_MINE
				{
					m_pSfxObj->m_vRotate.y = 180 - pObjSrc->GetAngle();
					
					CModelObject *pModel = (CModelObject *)pObjSrc->m_pModel;
					D3DXVECTOR3 v;
					pModel->GetEventPos( &v, 0 );
					D3DXVec3TransformCoord( &m_pSfxObj->m_vPos, &v, &pObjSrc->GetMatrixWorld() );

#ifdef __GOLDEN_MINE
					if (pMoverProp->dwClass == RANK_BOSS || pMoverProp->dwClass == RANK_BOSS_SPECIAL)
#else // __GOLDEN_MINE
					if (pMoverProp->dwClass == RANK_BOSS)
#endif // __GOLDEN_MINE
					{
						m_pSfxObj->m_vScale = D3DXVECTOR3(2.0f, 2.0f, 2.0f);
					}
					else
						m_pSfxObj->m_vScale = D3DXVECTOR3( 1.0f, 1.0f, 1.0f );
				}
				break;
		}
	}
	else
		Delete();
	
	if( m_fInit )
	{
 		vDir                  = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
		D3DXVECTOR3 vDestNor  = pObjDest->GetPos() - m_pSfxObj->m_vPos;
		D3DXVECTOR3 vAxis;
		D3DXQUATERNION   qRot;
		
		FLOAT       fTheta;
		D3DXVec3Normalize( &vDestNor, &vDestNor );
		D3DXVec3Cross( &vAxis, &vDir, &vDestNor );
		fTheta = D3DXVec3Dot( &vDir, &vDestNor );
		D3DXQuaternionRotationAxis( &qRot, &vAxis, acosf( fTheta ) );
		
		D3DXVECTOR3 vYPW;
		QuaternionRotationToYPW( qRot, vYPW );
		
		m_pSfxObj->m_vRotate.x = D3DXToDegree(vYPW.x);
		m_pSfxObj->m_vRotate.y = D3DXToDegree(vYPW.y);
		m_pSfxObj->m_vRotate.z = D3DXToDegree(vYPW.z);
		
		if( m_pSfxObj->m_vRotate.x >= 45.0f )
			m_pSfxObj->m_vRotate.x = 45.0f;
		
		if( m_pSfxObj->m_vRotate.z >= 45.0f )
			m_pSfxObj->m_vRotate.z = 45.0f;
		
		m_fInit = FALSE;
	}
}
void CSfxNpcDirSteam::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->Render2( pd3dDevice );
}


// ¸ÅÁö¼Ç ºÒ ÁÖ¹® ¿Ü±â
CSfxSkillMagFireCasting::CSfxSkillMagFireCasting()
{
}
CSfxSkillMagFireCasting::~CSfxSkillMagFireCasting()
{
}
void CSfxSkillMagFireCasting::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxSkillMagFireCasting::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if( IsValidObj( pObjSrc ) )
	{
		m_pSfxObj->m_vPos = GetPos();
		m_pSfxObj->m_vPos.y += 1.0f;
		m_pSfxObj->m_vRotate.y = 180 - pObjSrc->GetAngle();
		m_pSfxObj->Render( pd3dDevice );
	}
}

#ifdef __3RD_LEGEND16

CSfxSkillCastingFrontDynamic::CSfxSkillCastingFrontDynamic()
{
}
CSfxSkillCastingFrontDynamic::~CSfxSkillCastingFrontDynamic()
{
}
void CSfxSkillCastingFrontDynamic::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxSkillCastingFrontDynamic::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if( IsValidObj( pObjSrc ) )
	{
		m_pSfxObj->m_vPos = GetPos();
		m_pSfxObj->m_vRotate.y = 360 - pObjSrc->GetAngle();
		m_pSfxObj->Render( pd3dDevice );
	}
}

CSfxSkillCastingLSideDynamic::CSfxSkillCastingLSideDynamic()
{
}
CSfxSkillCastingLSideDynamic::~CSfxSkillCastingLSideDynamic()
{
}
void CSfxSkillCastingLSideDynamic::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxSkillCastingLSideDynamic::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
	if( IsValidObj( pObjSrc ) )
	{
		m_pSfxObj->m_vPos = GetPos();
		m_pSfxObj->m_vRotate.y = 90 - pObjSrc->GetAngle();
		m_pSfxObj->Render( pd3dDevice );
	}
}

CSfxSkillAboveTargetDynamic::CSfxSkillAboveTargetDynamic()
{
}
CSfxSkillAboveTargetDynamic::~CSfxSkillAboveTargetDynamic()
{
}
void CSfxSkillAboveTargetDynamic::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxSkillAboveTargetDynamic::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	CMover* pObjDest = prj.GetMover( m_idDest );
	if( IsValidObj( pObjDest ) )
	{
		m_pSfxObj->m_vPos = pObjDest->GetPos();
		m_pSfxObj->m_vPos.y += pObjDest->m_pModel->m_vMax.y * pObjDest->m_pModel->m_pModelElem->m_fScale * 1.2f;//3.0f;
		//m_pSfxObj->m_vPos.y += ((pObjDest->m_pModel->GetMaxHeight()*pObjDest->GetScale().y) - (pObjDest->GetScale().y*0.7f));
		m_pSfxObj->Render( pd3dDevice );
	}
}
#endif // __3RD_LEGEND16

// ¸ÅÁö¼Ç ¹Ù¶÷ ÁÖ¹® ¿Ü±â
CSfxSkillMagWindCasting::CSfxSkillMagWindCasting()
{
}
CSfxSkillMagWindCasting::~CSfxSkillMagWindCasting()
{
}
void CSfxSkillMagWindCasting::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxSkillMagWindCasting::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vPos.y += 0.2f;
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}

// ¸ÅÁö¼Ç ±âº» ½ºÅ³ 1
CSfxSkillMagStrongWind::CSfxSkillMagStrongWind()
{
	m_SfxObj2.SetSfx(XI_SKILL_MAG_WIND_STRONGWIND01_01);		// ¸Â¾ÒÀ»¶§ È¿°ú.
	m_bHit = FALSE;
	m_fAngle = 0;
}
CSfxSkillMagStrongWind::~CSfxSkillMagStrongWind()
{
}
				  
void CSfxSkillMagStrongWind::Process()
{
	if(m_nFrame==0) 
	{
		CMover* pObjSrc = prj.GetMover( m_idSrc );
		if(IsValidObj(pObjSrc)) 
			m_pSfxObj->m_vPos = pObjSrc->GetPos();
	}
	CMover* pObjDest = prj.GetMover( m_idDest );
	if(IsValidObj(pObjDest)) 
		m_SfxObj2.m_vPos = pObjDest->GetPos();

	if( m_bHit == FALSE ) 
	{
		m_pSfxObj->Process();
		if( m_pSfxObj->m_nCurFrame == 60 )
		{
			m_pSfxObj->m_nCurFrame = 30;
		}
		D3DXVECTOR3 vDelta=m_SfxObj2.m_vPos - m_pSfxObj->m_vPos;
		D3DXVec3Normalize( &vDelta, &vDelta );
		m_pSfxObj->m_vPos += vDelta * .2f;
		SetPos( m_pSfxObj->m_vPos );
		vDelta = m_SfxObj2.m_vPos - m_pSfxObj->m_vPos;
		FLOAT fAngle;
		fAngle = atan2( vDelta.x, -vDelta.z );
		fAngle = D3DXToDegree( fAngle );
		m_pSfxObj->m_vRotate.y = m_SfxObj2.m_vRotate.y = fAngle;
		if( D3DXVec3Length(&vDelta) < 0.2f ) 
		{
			PLAYSND( SND_PC_SKILLM_STRONGWIND2, &GetPos() );     
			m_bHit = TRUE;
		} else
			m_fAngle = fAngle;	// else¿¡´Ù ³ÖÀºÀÌÀ¯´Â ³Ê¹« °¡±îÀÌ ºÙ¾úÀ»¶§ÀÇ °¢µµ´Â ¿ÀÂ÷°¡ ÀÖÀ»¼ö ÀÖ±â¶§¹®¿¡..
	}
	else {
		if(m_SfxObj2.m_nCurFrame==0)
		{
			float fDmgPower = 0;
			ItemProp *pSkillProp = prj.GetSkillProp( m_dwSkill );
			if( pSkillProp && pSkillProp->dwDmgShift != NULL_ID )
				fDmgPower = (int)pSkillProp->dwDmgShift * 0.2f;		// Àû´çÇÑ°ªÀ¸·Î º¯È¯ÇØ¼­ »ç¿ë.
			int fAngle = (int)( m_fAngle );
			if( IsValidObj(pObjDest) )	// º¸½º¸÷Àº ¹Ð¸®Áö ¾ÊÀ½.
			{
				if( pObjDest->GetProp()->dwClass == RANK_SUPER || pObjDest->GetProp()->dwClass == RANK_MIDBOSS )
				{
					fAngle = 0;		fDmgPower = 0;
				}
			}
			
			DamageToTarget( 0, (float)( fAngle ), fDmgPower );
			// Å¸°Ù¿¡ ¸ÂÀº¼ø°£ ¸ÂÀº °¢µµ·Î ¿ÜºÎÈû 0.x¸¦ °¡ÇÔ.
			if( IsValidObj(pObjDest) )
			{
				// µ¥¹ÌÁöÇÃ¶óÀÌ Áß¿£ 
					if( (pObjDest->m_pActMover->GetState() & OBJSTA_DMG_FLY_ALL) == 0 )
						AngleToVectorXZ( &pObjDest->m_pActMover->m_vDeltaE, m_fAngle, fDmgPower );	
			}
		}
		if(m_SfxObj2.Process()) {
			Delete();
		}
	}
	m_nFrame++;
}
void CSfxSkillMagStrongWind::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	if(m_bHit==FALSE) 
	{
		m_pSfxObj->Render( pd3dDevice );
	}
	else 
	{
		if( !g_Option.m_bSFXRenderOff )
			m_SfxObj2.Render( pd3dDevice );
	}
}
// ¸ÅÁö¼Ç ±âº» ½ºÅ³ 2
CSfxSkillMagSwordWind::CSfxSkillMagSwordWind()
{
	m_SfxObj2.SetSfx(XI_SKILL_MAG_WIND_SWORDWIND01_01);
	m_bHit=FALSE;
}
CSfxSkillMagSwordWind::~CSfxSkillMagSwordWind()
{
}
void CSfxSkillMagSwordWind::Process()
{
	if(m_nFrame==0) 
	{
		CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
		if(pObjSrc) m_pSfxObj->m_vPos=pObjSrc->GetPos()+D3DXVECTOR3(.0f,0.0f,.0f);
	}
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );
	if(pObjDest) m_SfxObj2.m_vPos=pObjDest->GetPos()+D3DXVECTOR3(.0f,0.0f,.0f);

	if(m_bHit==FALSE) 
	{
		m_pSfxObj->Process();
		if(m_pSfxObj->m_nCurFrame>=30)
		{
			m_pSfxObj->m_nCurFrame=0;
			m_pSfxObj->Process();
		}
		D3DXVECTOR3 vDelta=m_SfxObj2.m_vPos-m_pSfxObj->m_vPos;
		D3DXVec3Normalize(&vDelta,&vDelta);
		m_pSfxObj->m_vPos+=vDelta*.2f;
		SetPos(m_pSfxObj->m_vPos);
		vDelta=m_pSfxObj->m_vPos-m_SfxObj2.m_vPos;

		FLOAT fAngle;
		if(vDelta.z>0) {
			fAngle=(float)(atan(vDelta.x/vDelta.z)*180/3.1415926f)+180;
		}
		else {
			fAngle=(float)(atan(vDelta.x/vDelta.z)*180/3.1415926f);
		}
		m_pSfxObj->m_vRotate.y=m_SfxObj2.m_vRotate.y=fAngle;
		if(D3DXVec3Length(&vDelta)<.4f) 
		{
			PLAYSND( SND_PC_SKILLM_SWORDWIND2, &GetPos() );     
			m_bHit=TRUE;
		}
	}
	else 
	{
		if(m_SfxObj2.m_nCurFrame==0)
			DamageToTarget();
		
		if(m_SfxObj2.Process()) 
			Delete();
	}
	m_nFrame++;
}
void CSfxSkillMagSwordWind::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	if(m_bHit==FALSE) 
	{
		m_pSfxObj->Render( pd3dDevice );
	}
	else 
	{
		if( !g_Option.m_bSFXRenderOff )
			m_SfxObj2.Render( pd3dDevice );
	}
}
// ¸ÅÁö¼Ç ±âº» ½ºÅ³ 3
CSfxSkillMagFireBoomerang::CSfxSkillMagFireBoomerang()
{
	m_SfxObj2.SetSfx( XI_SKILL_MAG_FIRE_BOOMERANG01_01 );
	m_bHit=FALSE;
}
CSfxSkillMagFireBoomerang::~CSfxSkillMagFireBoomerang()
{
}
void CSfxSkillMagFireBoomerang::Process()
{
	if(m_nFrame==0) 
	{
		CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
		if(pObjSrc) m_pSfxObj->m_vPos=pObjSrc->GetPos()+D3DXVECTOR3(.0f,1.0f,.0f);
	}
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );
	if( pObjDest )
	{
		m_SfxObj2.m_vPos = pObjDest->GetPos() + D3DXVECTOR3(.0f,0.3f,.0f);
		m_SfxObj2.m_vScale = D3DXVECTOR3( 2.0f, 2.0f, 2.0f );
	}
	if(m_bHit==FALSE) 
	{
		m_pSfxObj->Process();
		if( m_pSfxObj->m_nCurFrame == 20 )
		{
			m_pSfxObj->m_nCurFrame = 0;
		}
		D3DXVECTOR3 vDelta = m_SfxObj2.m_vPos - m_pSfxObj->m_vPos;
		D3DXVec3Normalize(&vDelta,&vDelta);
		m_pSfxObj->m_vPos+=vDelta*.2f;
		SetPos(m_pSfxObj->m_vPos);
		vDelta=m_pSfxObj->m_vPos - m_SfxObj2.m_vPos;


		D3DXVECTOR3 vDir      = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
		D3DXVECTOR3 vDestNor  = m_SfxObj2.m_vPos-m_pSfxObj->m_vPos;
		D3DXVECTOR3 vAxis;
		D3DXQUATERNION   qRot;
		
		FLOAT       fTheta;
		D3DXVec3Normalize( &vDestNor, &vDestNor );
		D3DXVec3Cross( &vAxis, &vDir, &vDestNor );
		fTheta = D3DXVec3Dot( &vDir, &vDestNor );
		D3DXQuaternionRotationAxis( &qRot, &vAxis, acosf( fTheta ) );
		
		D3DXVECTOR3 vYPW;
		
		QuaternionRotationToYPW( qRot, vYPW );
		m_pSfxObj->m_vRotate.x=m_SfxObj2.m_vRotate.x=D3DXToDegree(vYPW.x);
		m_pSfxObj->m_vRotate.y=m_SfxObj2.m_vRotate.y=D3DXToDegree(vYPW.y);
		m_pSfxObj->m_vRotate.z=m_SfxObj2.m_vRotate.z=D3DXToDegree(vYPW.z);

		if( D3DXVec3Length( &vDelta ) < .2f ) 
		{
			PLAYSND( SND_PC_SKILLM_FIREBOOMERANG2, &GetPos() );
			m_bHit=TRUE;
		}
	}
	else 
	{
		if(m_SfxObj2.m_nCurFrame==0)
			DamageToTarget();
		if(m_SfxObj2.Process()) {
			Delete();
		}
	}
	m_nFrame++;
}
void CSfxSkillMagFireBoomerang::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	if(m_bHit==FALSE) 
	{
		m_pSfxObj->Render2( pd3dDevice );
	}
	else 
	{
		if( !g_Option.m_bSFXRenderOff )
			m_SfxObj2.Render( pd3dDevice );
	}
}
// ¸ÅÁö¼Ç ±âº» ½ºÅ³ 4
CSfxSkillMagFireBomb::CSfxSkillMagFireBomb()
{
}
CSfxSkillMagFireBomb::~CSfxSkillMagFireBomb()
{
}
void CSfxSkillMagFireBomb::Process()
{
	m_nFrame++;
	if(m_pSfxObj->Process())
	{
		Delete();
	}
}
void CSfxSkillMagFireBomb::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vPos=GetPos();
	m_pSfxObj->m_vRotate.y=GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render( pd3dDevice );
}
// ¸ÅÁö¼Ç ±âº» ½ºÅ³ 5
CSfxSkillMagHotAir::CSfxSkillMagHotAir()
{
	m_SfxObj2.SetSfx(XI_SKILL_MAG_FIRE_HOTAIR01_01);		// Å¸°ÙÃø¿¡¼­ Æã ÅÍÁö¸ç È¸ÀüÇÏ´Â È¿°ú
	m_nDmgCnt = 0;
}
CSfxSkillMagHotAir::~CSfxSkillMagHotAir()
{
}
void CSfxSkillMagHotAir::Process()
{
	CMover* pObjSrc = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pObjSrc ) )
	{
		Delete();
		return;
	}
	{
		m_pSfxObj->m_vPos = pObjSrc->GetPos();		// ¹ß»çÃø¿¡¼­ Å¸°ÙÃøÀ¸·Î ³ªÅ¸³ª´Â È¿°ú
		m_pSfxObj->m_vRotate = D3DXVECTOR3(.0f,-pObjSrc->GetAngle(),.0f);
	}
	BOOL res1 = m_pSfxObj->Process();
	CMover* pObjDest = prj.GetMover( m_idDest );
	if( IsInvalidObj( pObjDest ) )
	{
		Delete();
		return;
	}
#ifdef __CLIENT
	#if __VER >= 11 // __MA_VER11_06				// È®À²½ºÅ³ È¿°ú¼öÁ¤ world,neuz
	else
	{
		DWORD dwTmpID =  pObjDest->GetRemoveSfxObj(XI_SKILL_MAG_FIRE_HOTAIR01 );
		if( dwTmpID && m_nFrame > 0)
		{
			Delete();
			return;
		}
	}
	#endif // __MA_VER11_06				// È®À²½ºÅ³ È¿°ú¼öÁ¤ world,neuz
#endif	// __CLIENT

	m_SfxObj2.m_vPos = pObjDest->GetPos();

	ItemProp *pSkillProp = prj.GetSkillProp( m_dwSkill );
	if( pSkillProp == NULL )		// ½ÇÆÐÇÏ¸é °Á¸®ÅÏ.
	{
		Error( "CSfxSkillMagHotAir::Process : ½ºÅ³(%d)ÀÇ ÇÁ·ÎÆÛÆ¼°¡ ¾ø´Ù.", m_dwSkill );
		Delete();
		return;
	}
	AddSkillProp *pAddSkillProp = prj.GetAddSkillProp( pSkillProp->dwSubDefine, m_nMagicPower );	// MagicPower°¡ ·¹º§ 
	if( pAddSkillProp == NULL )
	{
		Error( "CSfxSkillMagHotAir::Process : ½ºÅ³(%d)ÀÇ ¾Öµå ÇÁ·ÎÆÛÆ¼°¡ ¾ø´Ù.", m_dwSkill );
		Delete();
		return;
	}
	
	BOOL bHitFrame = FALSE;
	int	nPainFrame = (int)((pAddSkillProp->dwPainTime / 1000.0f) * SEC1);
	if( (m_nFrame % nPainFrame) == 0 )	// nPainFrame ¸¶´Ù ÇÑ¹ø¾¿ µ¥¹ÌÁö ÁÜ.
	{
		int	nMaxDmgCnt = (pAddSkillProp->dwSkillTime / pAddSkillProp->dwPainTime) + 1;		// ¸î¹ø µ¥¹ÌÁö¸¦ ¸Ô³Ä.
		// Ë¬	2006/11/9	// Ã¹¹øÂ°¸¸ Àü¼Û, ÀÌ ÈÄ Áö¼Ó ÇÇÇØ Ã³¸®
//		DamageToTarget( m_nDmgCnt++, 0, 0, nMaxDmgCnt );
		if( m_nDmgCnt++ == 0 )
			DamageToTarget( m_nDmgCnt, 0, 0, nMaxDmgCnt );
		if( m_nDmgCnt >= nMaxDmgCnt )
			m_idSfxHit = 0;
		PLAYSND( SND_PC_SKILLM_HOTAIR2, &GetPos() );
	}
	BOOL res2 = m_SfxObj2.Process();
	if( res2 )
		m_SfxObj2.m_nCurFrame = 0;
	int nFrameMax = (int)((pAddSkillProp->dwSkillTime / 1000.0f) * SEC1);	// ÃÖ´ë Áö¼Ó½Ã°£(ÇÁ·¹ÀÓ´ÜÀ§).
	if( m_nFrame >= nFrameMax )
	{
		Delete();
	}
	m_nFrame++;
}
void CSfxSkillMagHotAir::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->Render( pd3dDevice );
	m_pSfxObj->m_vScale = GetScale();
	if( !g_Option.m_bSFXRenderOff )
		m_SfxObj2.Render( pd3dDevice );
}



////////////////////////////////////////////////////////////////
void CSfxDuelParty::Process()
{
	CSfx::Process();
	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pMover ) )	// processÁß src ¹«¹ö°¡ ¾ø¾îÁ³À¸¸é ÀÚµ¿ »èÁ¦
	{
		Delete();
		return;
	}

	switch( m_nType )
	{
	case ENEMY_PVP_PARTY:
		{
			// processÁß src¹«¹öÀÇ ±Ø´Üµà¾óÀÌ ³¡³µÀ¸¸é »èÁ¦.
			if( pMover->m_nDuel != 2 || ( pMover->m_nDuel == 2 && ( pMover->m_nDuelState == 300 || pMover->m_nDuelState == 0 ) ) )		
			{
				DeleteSfx( pMover );
			}
			break;
		}
	case ENEMY_WAR:
		{
			if( pMover->m_idWar == 0 )		// processÁß src¹«¹öÀÇ ÀüÀïÀÌ ³¡³µÀ¸¸é ÇØÁ¦.
			{
				DeleteSfx( pMover );
			}
			break;
		}
	case ENEMY_PK:		
		{
			if( !( g_Neuz.m_NeuzEnemy.IsPKing( pMover->GetId() ) ) )
			{
				DeleteSfx( pMover );
			}
			break;
		}
	case ENEMY_PVP:
		{
			if( pMover->m_nDuel != 1 )
			{
				DeleteSfx( pMover );
			}
			break;
		}
	}
}

void CSfxDuelParty::DeleteSfx( CMover* pEnemy )
{
	pEnemy->m_dwFlag &= (~MVRF_WARMARK);
	Delete();
}

void	CSfxDuelParty::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pMover ) )	// processÁß src ¹«¹ö°¡ ¾ø¾îÁ³À¸¸é ÀÚµ¿ »èÁ¦
		return;
			
	if( pMover->HasBuff( BUFF_SKILL, SI_ACR_SUP_DARKILLUSION ) || pMover->IsMode( TRANSPARENT_MODE ) 
#ifdef __NEWCLASS
		|| pMover->HasBuff(BUFF_SKILL, SI_STORM_U_SKILL_02)
#endif // __NEWCLASS
		)
	{
		return;
	}

	CSfx::Render(pd3dDevice);
}



////////////////////////////////////////////////////////////////
CSfxSetItem::~CSfxSetItem() 
{
	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsValidObj( pMover ) )
	{
		pMover->m_dwFlag &= (~MVRF_SETITEMSFX);
	}
}

void CSfxSetItem::Process()
{
	CSfx::Process();
	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pMover ) )	// processÁß src ¹«¹ö°¡ ¾ø¾îÁ³À¸¸é ÀÚµ¿ »èÁ¦
	{
		Delete();
		return;
	}

	int nAbilityOption	= pMover->GetSetItemClient();
	if( nAbilityOption < 3 )
	{
		pMover->m_dwFlag &= (~MVRF_SETITEMSFX);
		Delete();
		return;
	}
}

void	CSfxSetItem::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pMover ) )	// processÁß src ¹«¹ö°¡ ¾ø¾îÁ³À¸¸é ÀÚµ¿ »èÁ¦
		return;
	
	if( ((pMover->IsMode( TRANSPARENT_MODE ) ) == 0) )
		CSfx::Render(pd3dDevice);
}

////////////////////////////////////////////////////////////////
void CSfxCollect::Process()
{
	m_nFrame++;

	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pMover ) )	// processÁß src ¹«¹ö°¡ ¾ø¾îÁ³À¸¸é ÀÚµ¿ »èÁ¦
	{
		Delete();
		return;
	}
	
	D3DXVECTOR3 vPos;
	((CModelObject *)pMover->m_pModel)->GetForcePos( &vPos, 0, PARTS_RWEAPON, pMover->GetMatrixWorld() );
	
	SetPos( vPos );

	if( m_pSfxObj->Process() )
		m_pSfxObj->m_nCurFrame = 0;


	if( m_pSfxObj->m_nCurFrame >= 145 ) // ±¸°£ ¹Ýº¹.
		m_pSfxObj->m_nCurFrame = 30; // ¸ñÇ¥Á¡¿¡ ¸ÂÀ»¶§±îÁö ·çÇÁ½ÃÅ°±â À§ÇØ ´Ù½Ã 0ÇÁ·¹ÀÓÀ¸·Î µ¹·Á³õ´Â´Ù.
	
	// ÇÃ·¹ÀÌ¾îÀÇ »óÅÂ°¡ Ã¤ÁýÀÌ ³¡³µÀ¸¸é 
	if( pMover->m_pActMover->GetActionState() != OBJSTA_COLLECT )
	{
		pMover->m_dwFlag &= (~MVRF_COLLECT);		// SFXÇØÁ¦.
		Delete();		// sfx »èÁ¦.
	}
}

void CSfxCollect::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	if( !IsVisible() || ( IsCull() && GetType() != 1 ))
		return;
	if( IsUpdateMatrix() )
		UpdateMatrix();
	
	LPMODELELEM lpModelElem = prj.m_modelMng.GetModelElem( m_dwType, m_dwIndex );
	// ModelÀÌ ¾øÀ¸¸é Ãâ·ÂÇÏÁö ¾ÊÀ½ 
	if( lpModelElem == NULL )
		return;
	
	m_pSfxObj->m_vPos = GetPos();
	m_pSfxObj->m_vRotate.y = GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->m_matScale = m_matScale;
	m_pSfxObj->Render( pd3dDevice, NULL );
}


////////////////////////////////////////////////////////////////
void CSfxMushmootCharge::Process()
{
	m_nFrame++;
	
	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pMover ) )	// processÁß src ¹«¹ö°¡ ¾ø¾îÁ³À¸¸é ÀÚµ¿ »èÁ¦
	{
		Delete();
		return;
	}
	if( pMover->m_dwFlag & MVRF_HITCONT )		// º¸½º°¡ ·¹ÀÌÀú¸¦ ½î±â ½ÃÀÛÇÏ¸é »èÁ¦ÇÔ.
	{
		Delete();
		return;
	}
	
	D3DXVECTOR3 vPos;
	
	((CModelObject *)pMover->m_pModel)->GetEventPos( &vPos, m_nEventPos );			// ¸¶ºý ÁÂÇ¥.
	D3DXVec3TransformCoord( &vPos, &vPos, pMover->GetMatrixWorldPtr() );	// ¿ùµå°ø°£À¸·Î º¯È¯.
	
	SetPos( vPos );
	SetAngle( -pMover->GetAngle() );
	
	if( m_pSfxObj->Process() )
		m_pSfxObj->m_nCurFrame = 0;
}

void CSfxMushmootCharge::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	if( !IsVisible() || ( IsCull() && GetType() != 1 ))
		return;
	if( IsUpdateMatrix() )
		UpdateMatrix();
	
	LPMODELELEM lpModelElem = prj.m_modelMng.GetModelElem( m_dwType, m_dwIndex );
	// ModelÀÌ ¾øÀ¸¸é Ãâ·ÂÇÏÁö ¾ÊÀ½ 
	if( lpModelElem == NULL )
		return;
	
	m_pSfxObj->m_vPos = GetPos();
	m_pSfxObj->m_vRotate.y = GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->m_matScale = m_matScale;
	m_pSfxObj->Render( pd3dDevice, NULL );
}

////////////////////////////////////////////////////////////////
void CSfxClockWorksCharge::Process()
{
	m_nFrame++;
	
	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pMover ) )	// processÁß src ¹«¹ö°¡ ¾ø¾îÁ³À¸¸é ÀÚµ¿ »èÁ¦
	{
		Delete();
		return;
	}
	if( pMover->m_dwFlag & MVRF_HITCONT )		// º¸½º°¡ ·¹ÀÌÀú¸¦ ½î±â ½ÃÀÛÇÏ¸é »èÁ¦ÇÔ.
	{
		Delete();
		return;
	}
	
	D3DXVECTOR3 vPos;

	((CModelObject *)pMover->m_pModel)->GetEventPos( &vPos, 2 );			// ¸¶ºý ÁÂÇ¥.
	D3DXVec3TransformCoord( &vPos, &vPos, pMover->GetMatrixWorldPtr() );	// ¿ùµå°ø°£À¸·Î º¯È¯.
	
	SetPos( vPos );
	SetAngle( -pMover->GetAngle() );
	
	if( m_pSfxObj->Process() )
		m_pSfxObj->m_nCurFrame = 0;
}

void CSfxClockWorksCharge::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	if( !IsVisible() || ( IsCull() && GetType() != 1 ))
		return;
	if( IsUpdateMatrix() )
		UpdateMatrix();
	
	LPMODELELEM lpModelElem = prj.m_modelMng.GetModelElem( m_dwType, m_dwIndex );
	// ModelÀÌ ¾øÀ¸¸é Ãâ·ÂÇÏÁö ¾ÊÀ½ 
	if( lpModelElem == NULL )
		return;
	
	m_pSfxObj->m_vPos = GetPos();
	m_pSfxObj->m_vRotate.y = GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->m_matScale = m_matScale;
	m_pSfxObj->Render( pd3dDevice, NULL );
}

////////////////////////////////////////////////////////////////
// Å¬¶ô¿öÅ© º¸½º ¿ÞÆÈ¿¡¼­ ¹ß»çÇÒ¶§ ³ª¿À´Â ÀÌÆåÆ®.
void CSfxClockWorksCannon::Process()
{
	m_nFrame++;
	
	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pMover ) )	// processÁß src ¹«¹ö°¡ ¾ø¾îÁ³À¸¸é ÀÚµ¿ »èÁ¦
	{
		Delete();
		return;
	}
	
	D3DXVECTOR3 vPos;
	CModelObject *pModel = (CModelObject *)pMover->m_pModel;
	
	pModel->GetEventPos( &vPos, 1 );			// ¿Þ¼Õ ÁÂÇ¥.
	D3DXVec3TransformCoord( &vPos, &vPos, pMover->GetMatrixWorldPtr() );	// ¿ùµå°ø°£À¸·Î º¯È¯.
	
	D3DXMATRIX mLArm = *(pModel->GetMatrixBone( 9 ));		// 9°¡ L ForeArm
	D3DXMatrixMultiply( &mLArm, pMover->GetMatrixWorldPtr(), &mLArm );
	D3DXQUATERNION qLArm;
	D3DXVECTOR3 vYPW;
	
	D3DXQuaternionRotationMatrix( &qLArm, &mLArm );			// ¿ÞÆÈ ¸ÅÆ®¸¯½º¸¦ ÄõÅÍ´Ï¾ðÀ¸·Î ¹Ù²Þ.
	QuaternionRotationToYPW( qLArm, vYPW );
	vYPW.y += D3DXToRadian( -90.0f );
	m_pSfxObj->m_vRotate.x = D3DXToDegree(vYPW.x);
	m_pSfxObj->m_vRotate.y = D3DXToDegree(vYPW.y);
	m_pSfxObj->m_vRotate.z = D3DXToDegree(vYPW.z);

	SetPos( vPos );
	
	if( m_pSfxObj->Process() )
		Delete();
}

void CSfxClockWorksCannon::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	if( !IsVisible() || ( IsCull() && GetType() != 1 ))
		return;
	if( IsUpdateMatrix() )
		UpdateMatrix();
	
	LPMODELELEM lpModelElem = prj.m_modelMng.GetModelElem( m_dwType, m_dwIndex );
	// ModelÀÌ ¾øÀ¸¸é Ãâ·ÂÇÏÁö ¾ÊÀ½ 
	if( lpModelElem == NULL )
		return;
	
	m_pSfxObj->m_vPos = GetPos();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->m_matScale = m_matScale;
	m_pSfxObj->Render2( pd3dDevice, NULL );
}


///////////////////////////////////////////////////////////////////




// ¸ÅÁö¼Ç Ice Missile
CSfxSkillMagIceMissile::CSfxSkillMagIceMissile()
{
	m_SfxObj2.SetSfx( XI_SKILL_MAG_WATER_ICEMISSILE01_01 );
	m_bHit=FALSE;
}
CSfxSkillMagIceMissile::~CSfxSkillMagIceMissile()
{
}
void CSfxSkillMagIceMissile::Process()
{
	if(m_nFrame==0) 
	{
		CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
		if(pObjSrc) m_pSfxObj->m_vPos=pObjSrc->GetPos()+D3DXVECTOR3(.0f,1.0f,.0f);
	}
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );
	if( pObjDest )
	{
		m_SfxObj2.m_vPos = pObjDest->GetPos() + D3DXVECTOR3(.0f,0.3f,.0f);
		m_SfxObj2.m_vScale = D3DXVECTOR3( 2.0f, 2.0f, 2.0f );
	}
	if(m_bHit==FALSE) 
	{
		if( m_pSfxObj->Process() )
		{
			m_pSfxObj->m_nCurFrame = 0;
		}
		D3DXVECTOR3 vDelta = m_SfxObj2.m_vPos - m_pSfxObj->m_vPos;
		D3DXVec3Normalize(&vDelta,&vDelta);
		m_pSfxObj->m_vPos+=vDelta*.2f;
		SetPos(m_pSfxObj->m_vPos);
		vDelta=m_pSfxObj->m_vPos - m_SfxObj2.m_vPos;
		
	    // ¸¶¹ý°´Ã¼ ¹æÇâº¤ÅÍ·Î ¸ðµ¨ ¹æÇâ µ¹¸®±â~~~
		D3DXVECTOR3 vDir      = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
		D3DXVECTOR3 vDestNor  = m_SfxObj2.m_vPos-m_pSfxObj->m_vPos;
		D3DXVECTOR3 vAxis;
		D3DXQUATERNION   qRot;
		
		FLOAT       fTheta;
		D3DXVec3Normalize( &vDestNor, &vDestNor );
		D3DXVec3Cross( &vAxis, &vDir, &vDestNor );
		fTheta = D3DXVec3Dot( &vDir, &vDestNor );
		D3DXQuaternionRotationAxis( &qRot, &vAxis, acosf( fTheta ) );
		
		D3DXVECTOR3 vYPW;
		
		QuaternionRotationToYPW( qRot, vYPW );
		m_pSfxObj->m_vRotate.x=m_SfxObj2.m_vRotate.x=D3DXToDegree(vYPW.x);
		m_pSfxObj->m_vRotate.y=m_SfxObj2.m_vRotate.y=D3DXToDegree(vYPW.y);
		m_pSfxObj->m_vRotate.z=m_SfxObj2.m_vRotate.z=D3DXToDegree(vYPW.z);

		if( D3DXVec3Length( &vDelta ) < .2f ) 
		{
			PLAYSND( SND_PC_SKILLM_FIREBOOMERANG2, &GetPos() );
			m_bHit=TRUE;
		}
	}
	else 
	{
		if(m_SfxObj2.m_nCurFrame==0)
			DamageToTarget();
		if(m_SfxObj2.Process()) {
			Delete();
		}
	}
	m_nFrame++;
}
void CSfxSkillMagIceMissile::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	if(m_bHit==FALSE) 
	{
		m_pSfxObj->Render2( pd3dDevice );
	}
	else 
	{
		if( !g_Option.m_bSFXRenderOff )
			m_SfxObj2.Render( pd3dDevice );
	}
}


// ¸ÅÁö¼Ç Lightning Ball
CSfxSkillMagLightningBall::CSfxSkillMagLightningBall()
{
	m_SfxObj2.SetSfx( XI_SKILL_MAG_ELECTRICITY_LIGHTINGBALL01_01  );
	m_bHit=FALSE;
}
CSfxSkillMagLightningBall::~CSfxSkillMagLightningBall()
{
}
void CSfxSkillMagLightningBall::Process()
{
	if(m_nFrame==0) 
	{
		CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
		if(pObjSrc) m_pSfxObj->m_vPos=pObjSrc->GetPos()+D3DXVECTOR3(.0f,1.0f,.0f);
	}
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );
	if( pObjDest )
	{
		m_SfxObj2.m_vPos = pObjDest->GetPos() + D3DXVECTOR3(.0f,0.3f,.0f);
		m_SfxObj2.m_vScale = D3DXVECTOR3( 2.0f, 2.0f, 2.0f );
	}
	if(m_bHit==FALSE) 
	{
		if( m_pSfxObj->Process() )
		{
			m_pSfxObj->m_nCurFrame = 0;
		}
		D3DXVECTOR3 vDelta = m_SfxObj2.m_vPos - m_pSfxObj->m_vPos;
		D3DXVec3Normalize(&vDelta,&vDelta);
		m_pSfxObj->m_vPos+=vDelta*.2f;
		SetPos(m_pSfxObj->m_vPos);
		vDelta=m_pSfxObj->m_vPos - m_SfxObj2.m_vPos;
		
		// ¸¶¹ý°´Ã¼ ¹æÇâº¤ÅÍ·Î ¸ðµ¨ ¹æÇâ µ¹¸®±â~~~
		D3DXVECTOR3 vDir      = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
		D3DXVECTOR3 vDestNor  = m_SfxObj2.m_vPos-m_pSfxObj->m_vPos;
		D3DXVECTOR3 vAxis;
		D3DXQUATERNION   qRot;
		
		FLOAT       fTheta;
		D3DXVec3Normalize( &vDestNor, &vDestNor );
		D3DXVec3Cross( &vAxis, &vDir, &vDestNor );
		fTheta = D3DXVec3Dot( &vDir, &vDestNor );
		D3DXQuaternionRotationAxis( &qRot, &vAxis, acosf( fTheta ) );
		
		D3DXVECTOR3 vYPW;
		
		QuaternionRotationToYPW( qRot, vYPW );
		m_pSfxObj->m_vRotate.x=m_SfxObj2.m_vRotate.x=D3DXToDegree(vYPW.x);
		m_pSfxObj->m_vRotate.y=m_SfxObj2.m_vRotate.y=D3DXToDegree(vYPW.y);
		m_pSfxObj->m_vRotate.z=m_SfxObj2.m_vRotate.z=D3DXToDegree(vYPW.z);
		
		if( D3DXVec3Length( &vDelta ) < .2f ) 
		{
			PLAYSND( SND_PC_SKILLM_FIREBOOMERANG2, &GetPos() );
			m_bHit=TRUE;
		}
	}
	else 
	{
		if(m_SfxObj2.m_nCurFrame==0)
			DamageToTarget();
		if(m_SfxObj2.Process()) {
			Delete();
		}
	}
	m_nFrame++;
}
void CSfxSkillMagLightningBall::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	if(m_bHit==FALSE) 
	{
		m_pSfxObj->Render2( pd3dDevice );
	}
	else 
	{
		if( !g_Option.m_bSFXRenderOff )
			m_SfxObj2.Render( pd3dDevice );
	}
}

// ¸ÅÁö¼Ç Spike Stone
CSfxSkillMagSpikeStone::CSfxSkillMagSpikeStone()
{
	m_SfxObj2.SetSfx( XI_SKILL_MAG_EARTH_SPIKESTONE01_01 );
	m_bHit=FALSE;
}
CSfxSkillMagSpikeStone::~CSfxSkillMagSpikeStone()
{
}
void CSfxSkillMagSpikeStone::Process()
{
	if(m_nFrame==0) 
	{
		CMover* pObjSrc = (CMover*)prj.GetCtrl( m_idSrc );
		if(pObjSrc) m_pSfxObj->m_vPos=pObjSrc->GetPos()+D3DXVECTOR3(.0f,1.0f,.0f);
	}
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );
	if( pObjDest )
	{
		m_SfxObj2.m_vPos = pObjDest->GetPos() + D3DXVECTOR3(.0f,0.3f,.0f);
		m_SfxObj2.m_vScale = D3DXVECTOR3( 2.0f, 2.0f, 2.0f );
	}
	if(m_bHit==FALSE) 
	{
		if( m_pSfxObj->Process() )
		{
			m_pSfxObj->m_nCurFrame = 0;
		}
		D3DXVECTOR3 vDelta = m_SfxObj2.m_vPos - m_pSfxObj->m_vPos;
		D3DXVec3Normalize(&vDelta,&vDelta);
		m_pSfxObj->m_vPos+=vDelta*.2f;
		SetPos(m_pSfxObj->m_vPos);
		vDelta=m_pSfxObj->m_vPos - m_SfxObj2.m_vPos;
		
		// ¸¶¹ý°´Ã¼ ¹æÇâº¤ÅÍ·Î ¸ðµ¨ ¹æÇâ µ¹¸®±â~~~
		D3DXVECTOR3 vDir      = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
		D3DXVECTOR3 vDestNor  = m_SfxObj2.m_vPos-m_pSfxObj->m_vPos;
		D3DXVECTOR3 vAxis;
		D3DXQUATERNION   qRot;
		
		FLOAT       fTheta;
		D3DXVec3Normalize( &vDestNor, &vDestNor );
		D3DXVec3Cross( &vAxis, &vDir, &vDestNor );
		fTheta = D3DXVec3Dot( &vDir, &vDestNor );
		D3DXQuaternionRotationAxis( &qRot, &vAxis, acosf( fTheta ) );
		
		D3DXVECTOR3 vYPW;
		
		QuaternionRotationToYPW( qRot, vYPW );
		m_pSfxObj->m_vRotate.x=m_SfxObj2.m_vRotate.x=D3DXToDegree(vYPW.x);
		m_pSfxObj->m_vRotate.y=m_SfxObj2.m_vRotate.y=D3DXToDegree(vYPW.y);
		m_pSfxObj->m_vRotate.z=m_SfxObj2.m_vRotate.z=D3DXToDegree(vYPW.z);
		
		if( D3DXVec3Length( &vDelta ) < .2f ) 
		{
			PLAYSND( SND_PC_SKILLM_FIREBOOMERANG2, &GetPos() );
			m_bHit=TRUE;
		}
	}
	else 
	{
		if(m_SfxObj2.m_nCurFrame==0)
			DamageToTarget();
		if(m_SfxObj2.Process()) {
			Delete();
		}
	}
	m_nFrame++;
}
void CSfxSkillMagSpikeStone::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	if(m_bHit==FALSE) 
	{
		m_pSfxObj->Render2( pd3dDevice );
	}
	else 
	{
		if( !g_Option.m_bSFXRenderOff )
			m_SfxObj2.Render( pd3dDevice );
	}
}

////////////////////////////////////////////////////////////////
void CSfxRotate::Process()
{
	m_nFrame++;
	
	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pMover ) )	// processÁß src ¹«¹ö°¡ ¾ø¾îÁ³À¸¸é ÀÚµ¿ »èÁ¦
	{
		Delete();
		return;
	}
	
	D3DXVECTOR3 vPos;
	CModelObject *pModel = (CModelObject *)pMover->m_pModel;
	pModel->GetEventPos( &vPos, 0 );	// µîµå¸® ÁÂÇ¥
	
	D3DXVec3TransformCoord( &vPos, &vPos, pMover->GetMatrixWorldPtr() );

	SetPos( vPos );
	SetAngle( -pMover->GetAngle() );
	
	if( m_pSfxObj->Process() )
		m_pSfxObj->m_nCurFrame = 0;
	
	if( m_nSec != -1 )		// ¹«ÇÑ¹Ýº¹(-1)ÀÌ ¾Æ´Ï¸é
	{
		if( m_nFrame > ( m_nSec * 60 ) )
			Delete();
	}
}

void CSfxRotate::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	if( !IsVisible() || ( IsCull() && GetType() != 1 ))
		return;
	if( IsUpdateMatrix() )
		UpdateMatrix();
	
	LPMODELELEM lpModelElem = prj.m_modelMng.GetModelElem( m_dwType, m_dwIndex );
	// ModelÀÌ ¾øÀ¸¸é Ãâ·ÂÇÏÁö ¾ÊÀ½ 
	if( lpModelElem == NULL )
		return;
	
	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pMover ) )
		return;

	D3DXVECTOR3 vPos;
	CModelObject *pModel = (CModelObject *)pMover->m_pModel;
	pModel->GetEventPos( &vPos, 0 );	// µîµå¸® ÁÂÇ¥
	
	D3DXVec3TransformCoord( &vPos, &vPos, pMover->GetMatrixWorldPtr() );
	
	SetPos( vPos );
	
	m_pSfxObj->m_vPos = GetPos();
	m_pSfxObj->m_vRotate.y = GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->m_matScale = m_matScale;
	m_pSfxObj->Render( pd3dDevice, NULL );
}


// ³¯¾Æ°¡¼­ ¸Â°í ÅÍÁö´Â ÀÏ¹ÝÀûÀÎ ÀÌÆåÆ®.
CSfxShoot::CSfxShoot()
{
	m_bHit = FALSE;
	m_dwSndHit = NULL_ID;
	m_bDir = FALSE;
	m_fHitScale = 1.0f;
	m_dwSfxHit = NULL_ID;
}
CSfxShoot::~CSfxShoot()
{
	m_bHit = FALSE;
	m_dwSndHit = NULL_ID;
	m_bDir = FALSE;
	m_fHitScale = 1.0f;
	m_dwSfxHit = NULL_ID;
}

// ¸Â¾ÒÀ»¶§ ÀÌÆåÆ® µî·Ï
void CSfxShoot::SetHitSfx( LPCTSTR szFileName, OBJID idSrc, OBJID idDst, FLOAT fScale ) 
{ 
}
void CSfxShoot::SetHitSfx( DWORD dwIndex, OBJID idSrc, OBJID idDst, FLOAT fScale ) 
{ 
}


// ¹æÇâ¼º ÀÖ´Â sfx ÀÎ°¡.
void CSfxShoot::SetDir( BOOL bDir )
{
	m_bDir = bDir;
}



void CSfxShoot::Process()
{
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );	// À¯µµÅº ÇüÀÌ±â¶§¹®¿¡ Å¸°ÙÀº Ç×»ó ÀÐ¾îºÁ¾ß ÇÑ´Ù.
	if( IsValidObj(pObjDest) )
	{
		m_vPosDest = pObjDest->GetPos() + D3DXVECTOR3( 0, 1.0f, 0 );
	}

	if( m_bHit == FALSE ) 
	{
		if( m_pSfxObj->Process() )		// ¾Ö´Ï¸ÞÀÌ¼ÇÀº ·çÇÁ.
		{
			m_pSfxObj->m_nCurFrame = 0;
		}
		D3DXVECTOR3 vDelta = m_vPosDest - m_pSfxObj->m_vPos;
		D3DXVec3Normalize( &vDelta, &vDelta );		// Å¸°ÙÂÊ ´ÜÀ§º¤ÅÍ ±¸ÇØ¼­
		D3DXVECTOR3 vPos = GetPos();
		vPos += vDelta * 0.2f;			// ±× º¤ÅÍ·Î ¼Óµµ¸¦ °áÁ¤ÇØ¼­ ÁÂÇ¥ ÀÌµ¿.
		m_pSfxObj->m_vPos = vPos;
		SetPos( vPos );
		
		if( m_bDir )
		{
			// ¸¶¹ý°´Ã¼ ¹æÇâº¤ÅÍ·Î ¸ðµ¨ ¹æÇâ µ¹¸®±â~~~
			D3DXVECTOR3 vDir      = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
			D3DXVECTOR3 vDestNor  = m_vPosDest - m_pSfxObj->m_vPos;
			D3DXVECTOR3 vAxis;
			D3DXQUATERNION   qRot;
			
			FLOAT       fTheta;
			D3DXVec3Normalize( &vDestNor, &vDestNor );
			D3DXVec3Cross( &vAxis, &vDir, &vDestNor );
			fTheta = D3DXVec3Dot( &vDir, &vDestNor );
			D3DXQuaternionRotationAxis( &qRot, &vAxis, acosf( fTheta ) );
			
			D3DXVECTOR3 vYPW;
			
			QuaternionRotationToYPW( qRot, vYPW );
			m_pSfxObj->m_vRotate.x = /*m_SfxObj2.m_vRotate.x = */D3DXToDegree(vYPW.x);
			m_pSfxObj->m_vRotate.y = /*m_SfxObj2.m_vRotate.y = */D3DXToDegree(vYPW.y);
			m_pSfxObj->m_vRotate.z = /*m_SfxObj2.m_vRotate.z = */D3DXToDegree(vYPW.z);
		}
		
		vDelta = m_pSfxObj->m_vPos - m_vPosDest;		// ´ë»ó°úÀÇ °Å¸®
		if( D3DXVec3LengthSq( &vDelta ) < 0.2f * 0.2f )		// Æø¹ß °Å¸®±îÁö ´Ù°¡°¡¸é Ãæµ¹.
		{
			if( m_dwSndHit != NULL_ID )
				PLAYSND( m_dwSndHit, &GetPos() );		// »ç¿îµå ÇÃ·¹ÀÌ.
			DamageToTarget();
			// Æø¹ß ¿ÀºêÁ§Æ® »ý¼º.
			if( m_dwSfxHit != NULL_ID )
			{
				CSfx *pSfx = CreateSfx( D3DDEVICE, m_dwSfxHit, GetPos(), m_idSrc, m_vPosDest, m_idDest, 0 );
				if( pSfx )
				{
					pSfx->SetAngle( m_pSfxObj->m_vRotate.y );
				}
			}
			Delete();	// this´Â »èÁ¦.
		}
	}
	m_nFrame ++;
}
void CSfxShoot::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->Render2( pd3dDevice );
}


// ¶¥¹Ù´Ú¿¡ ºÙ¾î¼­ ³¯¾Æ°¡´Â ÀÌÆåÆ®.
CSfxShootWave::CSfxShootWave()
{
	m_bHit = FALSE;
	m_dwSndHit = NULL_ID;
	m_bDir = FALSE;
	m_fHitScale = 1.0f;
	memset( m_vTail, 0, sizeof(m_vTail) );
	memset( m_nTailFrame, 0, sizeof(m_nTailFrame) );
}
CSfxShootWave::~CSfxShootWave()
{
	m_bHit = FALSE;
	m_dwSndHit = NULL_ID;
	m_bDir = FALSE;
	m_fHitScale = 1.0f;
	memset( m_vTail, 0, sizeof(m_vTail) );
	memset( m_nTailFrame, 0, sizeof(m_nTailFrame) );
}

// ¸Â¾ÒÀ»¶§ ÀÌÆåÆ® µî·Ï
void CSfxShootWave::SetHitSfx( LPCTSTR szFileName, OBJID idSrc, OBJID idDst, FLOAT fScale ) 
{ 
	m_SfxObj2.SetSfx( szFileName );		// ¸Â°í ÅÍÁú¶§ ÀÌÆåÆ® ·Îµù.

	m_fHitScale = fScale;
}
void CSfxShootWave::SetHitSfx( DWORD dwIndex, OBJID idSrc, OBJID idDst, FLOAT fScale ) 
{ 
	m_SfxObj2.SetSfx( dwIndex );		// ¸Â°í ÅÍÁú¶§ ÀÌÆåÆ® ·Îµù.
	
	m_fHitScale = fScale;
}

// ¹æÇâ¼º ÀÖ´Â sfx ÀÎ°¡.
void CSfxShootWave::SetDir( BOOL bDir )
{
	m_bDir = bDir;
}



void CSfxShootWave::Process()
{
	CMover* pObjDest = (CMover*)prj.GetCtrl( m_idDest );
	if( IsValidObj(pObjDest) )
	{
		m_SfxObj2.m_vPos = pObjDest->GetPos();
		m_SfxObj2.m_vScale = D3DXVECTOR3( m_fHitScale, m_fHitScale, m_fHitScale );			// Å©±â´Â fHitScale¹è
	} else
	{
		// ³¯¾Æ°¡´Ù Å¸°ÙÀÌ ¾ø¾îÁ³À¸¸é ¸¶Áö¸·ÁÂÇ¥·Î ³¯¾Æ°¡¼­ ÅÍÁö°Ô.
	}

	if( (m_nFrame & 3) == 0 )
	{
		for( int i = MAX_SHOOTWAVE_TAIL-1; i > 0; i -- )
		{
			m_vTail[i] = m_vTail[i-1];	// µÚ·Î ÇÑÄ­¾¿ ¹Î´Ù.
			m_nTailFrame[i] = m_nTailFrame[i-1];
			m_nTailFrame[i]++;
			if( m_nTailFrame[i] >= 56 )
			{
				m_vTail[i].x = m_vTail[i].y = m_vTail[i].z = 0;
				m_nTailFrame[i] = 0;
			}
		}
		m_vTail[0] = GetPos();
		m_nTailFrame[0] = 0;
	}

	if( m_pSfxObj->Process() )		// ¾Ö´Ï¸ÞÀÌ¼ÇÀº ·çÇÁ.
	{
		m_pSfxObj->m_nCurFrame = 0;
	}
	
	if( m_bHit == FALSE ) 
	{
		D3DXVECTOR3 vDelta = m_SfxObj2.m_vPos - m_pSfxObj->m_vPos;
		D3DXVec3Normalize( &vDelta, &vDelta );		// Å¸°ÙÂÊ ´ÜÀ§º¤ÅÍ ±¸ÇØ¼­
		D3DXVECTOR3 vPos = GetPos(), vTemp;

		CWorld *pWorld = GetWorld();
		if( pWorld == NULL )	
		{
			Delete();
			return;
		}
		vPos += vDelta * 0.25f;			// ±× º¤ÅÍ·Î ¼Óµµ¸¦ °áÁ¤ÇØ¼­ ÁÂÇ¥ ÀÌµ¿.
		vTemp = vPos;
		vTemp.y += 1.5f;
		FLOAT y = pWorld->GetUnderHeight( vTemp );	// ¹Ù´ÚÀ» µû¶ó¼­ °¡°Ô,...
		vPos.y = y;
		vPos.y	= m_SfxObj2.m_vPos.y;		// Ë¬
		m_pSfxObj->m_vPos = vPos;
		SetPos( vPos );
		
		if( m_bDir )
		{
			// ¸¶¹ý°´Ã¼ ¹æÇâº¤ÅÍ·Î ¸ðµ¨ ¹æÇâ µ¹¸®±â~~~
			D3DXVECTOR3 vDir      = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
			D3DXVECTOR3 vDestNor  = m_pSfxObj->m_vPos - m_SfxObj2.m_vPos;
			D3DXVECTOR3 vAxis;
			D3DXQUATERNION   qRot;
			
			FLOAT       fTheta;
			D3DXVec3Normalize( &vDestNor, &vDestNor );
			D3DXVec3Cross( &vAxis, &vDir, &vDestNor );
			fTheta = D3DXVec3Dot( &vDir, &vDestNor );
			D3DXQuaternionRotationAxis( &qRot, &vAxis, acosf( fTheta ) );
			
			D3DXVECTOR3 vYPW;
			
			QuaternionRotationToYPW( qRot, vYPW );
			m_pSfxObj->m_vRotate.x = m_SfxObj2.m_vRotate.x = D3DXToDegree(vYPW.x);
			m_pSfxObj->m_vRotate.y = m_SfxObj2.m_vRotate.y = D3DXToDegree(vYPW.y);
			m_pSfxObj->m_vRotate.z = m_SfxObj2.m_vRotate.z = D3DXToDegree(vYPW.z);
		}
		
		vDelta = m_pSfxObj->m_vPos - m_SfxObj2.m_vPos;		// ´ë»ó°úÀÇ °Å¸®
		if( D3DXVec3LengthSq( &vDelta ) < 0.4f * 0.4f )		// Æø¹ß °Å¸®±îÁö ´Ù°¡°¡¸é Ãæµ¹.
		{
			if( m_dwSndHit != NULL_ID )
				PLAYSND( m_dwSndHit, &GetPos() );		// »ç¿îµå ÇÃ·¹ÀÌ.
			m_bHit = TRUE;
			DamageToTarget();
		}
	}
	else 
	{
		if( m_SfxObj2.Process() )		// ¾Ö´Ï¸ÞÀÌ¼Ç ´Ù ³¡³µÀ¸¸é Á¾·á.
			Delete();
	}
	m_nFrame ++;
}
void CSfxShootWave::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	m_pSfxObj->m_vScale = GetScale();
	int nFrame = m_pSfxObj->m_nCurFrame;

	for( int i = 0; i < MAX_SHOOTWAVE_TAIL; i ++ )
	{
		if( m_vTail[i].x )
		{
			m_pSfxObj->m_vPos = m_vTail[i];
			m_pSfxObj->Render2( pd3dDevice );
		}
	}
	
	if( m_bHit == FALSE ) 
	{
		m_pSfxObj->m_vPos = GetPos();
		m_pSfxObj->Render2( pd3dDevice );
	}
	else 
	{
		if( !g_Option.m_bSFXRenderOff )
			m_SfxObj2.Render( pd3dDevice );
	}
}

////////////////////////////////////////////////////////////////
// ¹«¹öÀÇ Æ¯Á¤ ÆÄÃ÷¿¡ ¸µÅ©µÇ´Â Sfx
void CSfxPartsLink::Process()
{
	m_nFrame++;
	
	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pMover ) )	// processÁß src ¹«¹ö°¡ ¾ø¾îÁ³À¸¸é ÀÚµ¿ »èÁ¦
	{
		Delete();
		return;
	}
	
	D3DXVECTOR3 vPos;

	CModelObject *pModel = (CModelObject *)pMover->m_pModel;
	if( m_nPartsLink == 0 )		// ¿À¸¥¼Õ
	{
		pModel->GetHandPos( &vPos, PARTS_RWEAPON, pMover->GetMatrixWorld() );		// ¿À¸¥¼Õ ÁÖ¸Ô ¿ùµåÁÂÇ¥ ±¸ÇÔ.
	} else
	{
		pModel->GetHandPos( &vPos, PARTS_LWEAPON, pMover->GetMatrixWorld() );
	}
	
	SetPos( vPos );
	
	if( m_pSfxObj->Process() )
	{
		m_bEndFrame = TRUE;
	}
}

void CSfxPartsLink::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	if( !IsVisible() || ( IsCull() && GetType() != 1 ))
		return;
	if( IsUpdateMatrix() )
		UpdateMatrix();
	
	LPMODELELEM lpModelElem = prj.m_modelMng.GetModelElem( m_dwType, m_dwIndex );
	// ModelÀÌ ¾øÀ¸¸é Ãâ·ÂÇÏÁö ¾ÊÀ½ 
	if( lpModelElem == NULL )
		return;
	
	m_pSfxObj->m_vPos = GetPos();
	m_pSfxObj->m_vRotate.y = GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->m_matScale = m_matScale;
	m_pSfxObj->Render( pd3dDevice, NULL );
}



void CSfxPartsLinkBlade::Process() // ºí·¹ÀÌµå ÆÄÃ÷ÀÌÆåÆ®´Â ¹Ð¸® ½ºÅ³³¡³ª¸é ¼Ò¸ê
{
	CSfxPartsLink::Process();

	CMover *pMover = prj.GetMover( m_idSrc );
	
	// ¹Ð¸®½ºÅ³ µ¿ÀÛ ³¡³ª¸é ÇØÁ¦.
	if( pMover && (pMover->m_pActMover->GetState() & OBJSTA_ATK_ALL) != OBJSTA_ATK_MELEESKILL )
	{
		Delete();		// sfx »èÁ¦.
	}
}

void CSfxPartsLinkJst::Process() // Á¦½ºÅÍ ÆÄÃ÷ÀÌÆåÆ®´Â ³¡ÇÁ·¹ÀÓÀÌ¸é ¼Ò¸ê
{
	CSfxPartsLink::Process();
	
	if( m_bEndFrame )
	{
		Delete();		// sfx »èÁ¦.
	}
}

////////////////////////////////////////////////////////////////
// ¾ÆÅ©·Î¹î ¹«¹öÀÇ Æ¯Á¤ ÆÄÃ÷¿¡ ¸µÅ©µÇ´Â Sfx
void CSfxAllowPartsLink::Process()
{
	m_nFrame++;
	
	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pMover ) )	// processÁß src ¹«¹ö°¡ ¾ø¾îÁ³À¸¸é ÀÚµ¿ »èÁ¦
	{
		Delete();
		return;
	}
	
	D3DXVECTOR3 vPos;
	
	CModelObject *pModel = (CModelObject *)pMover->m_pModel;
	if( m_nPartsLink == 0 )		// ¿À¸¥¼Õ
	{
		pModel->GetHandPos( &vPos, PARTS_RWEAPON, pMover->GetMatrixWorld() );		// ¿À¸¥¼Õ ÁÖ¸Ô ¿ùµåÁÂÇ¥ ±¸ÇÔ.
	} else
	{
		pModel->GetHandPos( &vPos, PARTS_LWEAPON, pMover->GetMatrixWorld() );
	}
	
	SetPos( vPos );
	
	if( m_pSfxObj->Process() )
		Delete();
}

void CSfxAllowPartsLink::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	if( !IsVisible() || ( IsCull() && GetType() != 1 ))
		return;
	if( IsUpdateMatrix() )
		UpdateMatrix();
	
	LPMODELELEM lpModelElem = prj.m_modelMng.GetModelElem( m_dwType, m_dwIndex );
	// ModelÀÌ ¾øÀ¸¸é Ãâ·ÂÇÏÁö ¾ÊÀ½ 
	if( lpModelElem == NULL )
		return;

	m_pSfxObj->m_vPos = GetPos();
	m_pSfxObj->m_vRotate.y = GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->m_matScale = m_matScale;
	m_pSfxObj->Render( pd3dDevice, NULL );
}

void CSfxReady::Process()
{
	CSfx::Process();

	CMover *pSrc = prj.GetMover( m_idSrc );		// ½ÃÀüÀÚ¿¡°Ô ¹ßµ¿.
	if( IsValidObj( pSrc ) )
	{
		if( pSrc->IsStateMode( STATE_BASEMOTION_MODE ) == FALSE )	// ½ÃÀüµ¿ÀÛ ³¡³µÀ¸¸é 
			Delete();		// »èÁ¦.
	} else
		Delete();		// ½ÃÀüÀÚ°¡ »ç¶óÁ®µµ »èÁ¦.
}


CSfxPartsLinkShoulder::CSfxPartsLinkShoulder():m_nOldAbilityOption(0), m_v3Offset(D3DXVECTOR3( 0.0f, 0.0f, 0.0f ))
{
#ifdef __SFX_OPT
	SetSkill(FALSE);
#endif
}
CSfxPartsLinkShoulder::~CSfxPartsLinkShoulder() 
{
	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsValidObj( pMover ) )
	{
		pMover->m_dwFlag &= (~MVRF_SETITEMSFX);
	}
}

void CSfxPartsLinkShoulder::Process()
{
	CSfx::Process();

	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pMover ) )	// processÁß src ¹«¹ö°¡ ¾ø¾îÁ³À¸¸é ÀÚµ¿ »èÁ¦
	{
		Delete();
		return;
	}
#ifdef __JOPS_GLOW
	int nAbilityOption = pMover->GetSetItemClient();
	if (nAbilityOption < 3 ||
		nAbilityOption != m_nOldAbilityOption ||
		m_iGlowBody != pMover->m_iGlowBody ||
		m_iGlowHandLeft != pMover->m_iGlowHandLeft ||
		m_iGlowHandRight != pMover->m_iGlowHandRight ||
		m_iGlowArmLeft != pMover->m_iGlowArmLeft ||
		m_iGlowArmRight != pMover->m_iGlowArmRight ||
		m_iGlowLegLeft != pMover->m_iGlowLegLeft ||
		m_iGlowLegRight != pMover->m_iGlowLegRight)
	{
		pMover->m_dwFlag &= (~MVRF_SETITEMSFX);
		Delete();

		return;
	}
#else
	int nAbilityOption = pMover->GetSetItemClient();
	if (nAbilityOption < 3 || nAbilityOption != m_nOldAbilityOption)
	{
		pMover->m_dwFlag &= (~MVRF_SETITEMSFX);
		Delete();
		return;
	}
#endif
}

void	CSfxPartsLinkShoulder::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	CMover *pMover = prj.GetMover( m_idSrc );
#ifdef __GAMEGUARD
	if (IsInvalidObj(pMover))
		return;
#endif // __GAMEGUARD
	if( pMover->IsActiveMover() && CWorld::m_nZoomLevel != 0 )
		return;

#ifdef __QUIZ
#ifdef __GAMEGUARD
	if (pMover->GetWorld())
#endif // __GAMEGUARD
	{
		if (pMover->GetWorld()->GetID() == WI_WORLD_QUIZ && pMover->IsPlayer() == TRUE && pMover->IsDisguise() == TRUE)
			return;
	}
#endif // __QUIZ
	
	D3DXVECTOR3 vVel = D3DXVECTOR3( 0.0f, 0.04f, 0.0f );
	D3DXVECTOR3 vPos;
	D3DXMATRIX  mPartMatrix;
	
	CModelObject *pModel = (CModelObject *)pMover->m_pModel;

	if( m_nPartsLink == 0 )		// ¿À¸¥ ¾î±ú
	{
		D3DXMatrixMultiply( &mPartMatrix, (pModel->GetMatrixBone(15)), &(pMover->GetMatrixWorld()) );
	} 
	else
	if( m_nPartsLink == 1 )		// ¿Þ ¾î±ú
	{
		D3DXMatrixMultiply( &mPartMatrix, (pModel->GetMatrixBone(11)), &(pMover->GetMatrixWorld()) );
	}
	else
	if( m_nPartsLink == 2 )    // ¿À¸¥ ÆÈ²ÞÄ¡
	{
		D3DXMatrixMultiply( &mPartMatrix, (pModel->GetMatrixBone(16)), &(pMover->GetMatrixWorld()) );
	}
	else
	if( m_nPartsLink == 3 )	   // ¿Þ ÆÈ²ÞÄ¡
	{
		D3DXMatrixMultiply( &mPartMatrix, (pModel->GetMatrixBone(12)), &(pMover->GetMatrixWorld()) );
	}
	else
	if( m_nPartsLink == 4 )   // ¿À¸¥ÂÊ¾î±ú + ÆÈ²ÞÄ¡ º¸°£
	{
		D3DXMATRIX  mMatrix1;
		D3DXMATRIX  mMatrix2;

		D3DXMatrixMultiply( &mMatrix1, (pModel->GetMatrixBone(15)), &(pMover->GetMatrixWorld()) );
		D3DXMatrixMultiply( &mMatrix2, (pModel->GetMatrixBone(16)), &(pMover->GetMatrixWorld()) );

		D3DXVECTOR3 vPos1 = D3DXVECTOR3( mMatrix1._41, mMatrix1._42, mMatrix1._43 );
		D3DXVECTOR3 vPos2 = D3DXVECTOR3( mMatrix2._41, mMatrix2._42, mMatrix2._43 );

		D3DXVECTOR3 vPos3;
		D3DXVec3Lerp( &vPos3, &vPos1, &vPos2, 0.6f );

		mPartMatrix = mMatrix1;
		mPartMatrix._41 = vPos3.x; 
		mPartMatrix._42 = vPos3.y; 
		mPartMatrix._43 = vPos3.z; 
	}
	else
	if( m_nPartsLink == 5 )   // ¿ÞÂÊ¾î±ú + ÆÈ²ÞÄ¡ º¸°£
	{
		D3DXMATRIX  mMatrix1;
		D3DXMATRIX  mMatrix2;
		
		D3DXMatrixMultiply( &mMatrix1, (pModel->GetMatrixBone(11)), &(pMover->GetMatrixWorld()) );
		D3DXMatrixMultiply( &mMatrix2, (pModel->GetMatrixBone(12)), &(pMover->GetMatrixWorld()) );
		
		D3DXVECTOR3 vPos1 = D3DXVECTOR3( mMatrix1._41, mMatrix1._42, mMatrix1._43 );
		D3DXVECTOR3 vPos2 = D3DXVECTOR3( mMatrix2._41, mMatrix2._42, mMatrix2._43 );
		
		D3DXVECTOR3 vPos3;
		D3DXVec3Lerp( &vPos3, &vPos1, &vPos2, 0.6f );
		
		mPartMatrix = mMatrix1;
		mPartMatrix._41 = vPos3.x; 
		mPartMatrix._42 = vPos3.y; 
		mPartMatrix._43 = vPos3.z; 
	}
	else
	if( m_nPartsLink == 6 )    // ¸ö Áß°£
	{
		D3DXMatrixMultiply( &mPartMatrix, (pModel->GetMatrixBone(2)), &(pMover->GetMatrixWorld()) );
	}
	else
	if( m_nPartsLink == 7 )	   // ¸ö ¾Æ·¡
	{
		D3DXMatrixMultiply( &mPartMatrix, (pModel->GetMatrixBone(3)), &(pMover->GetMatrixWorld()) );
	}
	else
	if( m_nPartsLink == 8 )    // ¿À¸¥¼Õ
	{
		D3DXMatrixMultiply( &mPartMatrix, pModel->GetMatrixBone(pModel->GetRHandIdx()), &(pMover->GetMatrixWorld()) );
	}
	else
	if( m_nPartsLink == 9 )	   // ¿Þ¼Õ
	{
		D3DXMatrixMultiply( &mPartMatrix, pModel->GetMatrixBone(pModel->GetLHandIdx()), &(pMover->GetMatrixWorld()) );
	}
	else
	if( m_nPartsLink == 26 )	   // ¿Þ¼Õ
	{
		D3DXMatrixMultiply( &mPartMatrix, pModel->GetMatrixBone(m_nPartsLink), &(pMover->GetMatrixWorld()) );
	}
	else
	if( m_nPartsLink == 29 )	   // ¿Þ¼Õ
	{
		D3DXMatrixMultiply( &mPartMatrix, pModel->GetMatrixBone(m_nPartsLink), &(pMover->GetMatrixWorld()) );
	}
		
			
	vPos.x = mPartMatrix._41;
	vPos.y = mPartMatrix._42-0.05f;
	vPos.z = mPartMatrix._43;

	vPos -= m_v3Offset;
#ifdef __JOPS_GLOW
	if (pMover->m_dwGlowColor)
		m_dwColor = pMover->m_dwGlowColor;
#endif
	SetPos( vPos );

	if( IsInvalidObj( pMover ) )	// processÁß src ¹«¹ö°¡ ¾ø¾îÁ³À¸¸é ÀÚµ¿ »èÁ¦
		return;
	if( ((pMover->IsMode( TRANSPARENT_MODE ) ) == 0) )
		CSfx::Render(pd3dDevice);
}

#if __VER >= 12 // __ITEMCREATEMON_S0602
CSfxCursor::CSfxCursor()
{
}
CSfxCursor::~CSfxCursor()
{
}
void CSfxCursor::Process()
{
	SetPos( g_Neuz.m_vCursorPos );		// ¸¶¿ì½º ÁÂÇ¥
	m_pSfxObj->Process();

	if( m_nSec != 0 )	// 0Àº 1È¸ ÇÃ·¹ÀÌÈÄ Á¾·á.
	{
		// ¹Ýº¹ ¾Ö´Ï¸ÞÀÌ¼Ç
		if( m_pSfxObj->Process() )		
			m_pSfxObj->m_nCurFrame = 0;
	}

	if (g_Neuz.m_pCreateMonItem == NULL)
		Delete();
}
#endif // __ITEMCREATEMON_S0602


CSfxLinkMover::CSfxLinkMover( )
{
}

CSfxLinkMover::~CSfxLinkMover( )
{
}

void CSfxLinkMover::Process( )
{
	m_nFrame++;
	
	CMover* pMover = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pMover ) )	// processÁß src ¹«¹ö°¡ ¾ø¾îÁ³À¸¸é ÀÚµ¿ »èÁ¦
	{
		Delete();
		return;
	}
	
	D3DXVECTOR3 vPos = pMover->GetPos( );
	
	SetPos( vPos );
	
	if( m_pSfxObj->Process() )
	{
		m_pSfxObj->m_nCurFrame = 0;
	}
}

void CSfxLinkMover::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	if( !IsVisible() || ( IsCull() && GetType() != 1 ))
		return;
#ifdef __HIDEPETS
	if (g_Option.m_OffPets)
		return;
#endif //__HIDEPETS
	if( IsUpdateMatrix() )
		UpdateMatrix();
	
	LPMODELELEM lpModelElem = prj.m_modelMng.GetModelElem( m_dwType, m_dwIndex );
	// ModelÀÌ ¾øÀ¸¸é Ãâ·ÂÇÏÁö ¾ÊÀ½ 
	if( lpModelElem == NULL )
		return;

	CMover *pMover = prj.GetMover( m_idSrc );
	if( IsInvalidObj( pMover ) )
		return;

	D3DXVECTOR3 vPos( 0.0f, 0.0f, 0.0f );
//	CModelObject *pModel = (CModelObject *)pMover->m_pModel;
//	pModel->GetEventPos( &vPos, 0 );	// µîµå¸® ÁÂÇ¥
	
	D3DXVec3TransformCoord( &vPos, &vPos, pMover->GetMatrixWorldPtr() );
	
	SetPos( vPos );

	m_pSfxObj->m_vPos = GetPos();
	m_pSfxObj->m_vRotate.y = GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->m_matScale = m_matScale;
	m_pSfxObj->Render( pd3dDevice, NULL );
}

#ifdef __WINGSFX
void CSfxWings::Process()
{
	m_nFrame++;
	CMover* pMover = prj.GetMover(m_idSrc);
	if (IsInvalidObj(pMover))
	{
		Delete();
		return;
	}

	/*if (pMover->m_bWingSfx == false)
	{
	Delete();
	return;
	}*/

	D3DXVECTOR3 vPos;
	CModelObject* pModel = (CModelObject*)pMover->m_pModel;
	pModel->GetEventPos(&vPos, 0);

	D3DXVec3TransformCoord(&vPos, &vPos, pMover->GetMatrixWorldPtr());

	SetPos(vPos);
	SetAngle(-pMover->GetAngle());

	if (m_pSfxObj->Process())
		m_pSfxObj->m_nCurFrame = 0;

	if (m_nSec != -1)
	{
		if (m_nFrame > (m_nSec * 60))
			Delete();
	}
}

void CSfxWings::Render(LPDIRECT3DDEVICE9 pd3dDevice)
{
	if (!IsVisible() || (IsCull() && GetType() != 1))
		return;
	if (IsUpdateMatrix())
		UpdateMatrix();

	LPMODELELEM lpModelElem = prj.m_modelMng.GetModelElem(m_dwType, m_dwIndex);
	if (lpModelElem == nullptr)
		return;

	CMover* pMover = prj.GetMover(m_idSrc);
	if (IsInvalidObj(pMover))
		return;

	if (!pMover->IsOptionRenderMask() || pMover->HasBuff(BUFF_SKILL, SI_ACR_SUP_DARKILLUSION) || pMover->IsMode(TRANSPARENT_MODE))
	{
		return;
	}
	D3DXVECTOR3 vPos;
	CModelObject* pModel = (CModelObject*)pMover->m_pModel;
	pModel->GetEventPos(&vPos, 0);

	D3DXVec3TransformCoord(&vPos, &vPos, pMover->GetMatrixWorldPtr());

	SetPos(vPos);

	m_pSfxObj->m_vPos = GetPos();
	m_pSfxObj->m_vRotate.y = GetAngle();
	m_pSfxObj->m_vScale = GetScale();
	m_pSfxObj->m_matScale = m_matScale;
	m_pSfxObj->Render(pd3dDevice, nullptr);
}
#endif
```
