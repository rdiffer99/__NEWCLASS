# MoverEquip.cpp

Chemin original: `C:\Users\rdiff\Desktop\__NEWCLASS\_AIInterface\MoverEquip.cpp`
Chemin relatif: `_AIInterface\MoverEquip.cpp`
Nom du fichier: `MoverEquip.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "stdafx.h"
#include "defineText.h"
#include "defineSkill.h"
#include "defineSound.h"
#include "defineItem.h"
#include "ModelObject.h"
#include "authorization.h"
#include "CreateObj.h"
#include "lang.h"
#include "party.h"
#include "guild.h"
#include "guildwar.h"

#ifdef __CLIENT
	#include "DPClient.h"
	#include "DialogMsg.h"
	extern	CDPClient	g_DPlay;
	#include "GuildRender.h"
#else	// __CLIENT
	#include "User.h"
	#include "WorldMng.h"
	#include "DPSrvr.h"
	#include "DPCoreClient.h"
	#include "dpdatabaseclient.h"
	#include "ItemScript.h"

	extern	CUserMng			g_UserMng;
	extern	CWorldMng			g_WorldMng;
	extern	CDPSrvr				g_DPSrvr;
	extern	CDPDatabaseClient	g_dpDBClient;
	extern	CDPCoreClient		g_DPCoreClient;
#endif	// __CLIENT

#if __VER >= 11 // __SYS_COLLECTING
#include "accessory.h"
#endif	// __SYS_COLLECTING

extern	CPartyMng		g_PartyMng;
extern	CGuildMng		g_GuildMng;
extern	CGuildWarMng	g_GuildWarMng;


BYTE  nMaleHairColor[10][3] = { 
	{ 144,  99,  101 },
	{ 100, 107, 125 },
	{ 158,119,109 },
	{ 199,156,100 },
	{ 100,123,117 },
	{ 100,100,100 },
	{ 100,100,100 },
	{ 100,100,100 },
	{ 100,100,100 },
	{ 100,100,100 } 
};

BYTE  nFeMaleHairColor[10][3] = { 
	{ 250,250,90 },
	{ 250,250,90 },
	{ 147,118,103 },
	{ 150, 100, 85 },
	{ 213,130,100 },
	{ 100,100,100 },
	{ 100,100,100 },
	{ 100,100,100 },
	{ 100,100,100 },
	{ 100,100,100 } 
};

#define TEX_PART_HAIR( nSex )  ( nSex == SEX_MALE ? _T( "Part_maleHair01.dds"  ) : _T( "Part_femaleHair01.dds"  ) )
#define TEX_PART_UPPER( nSex ) ( nSex == SEX_MALE ? _T( "Part_maleUpper01.dds" ) : _T( "Part_femaleUpper01.dds" ) )
#define TEX_PART_LOWER( nSex ) ( nSex == SEX_MALE ? _T( "Part_maleLower01.dds" ) : _T( "Part_femaleLower01.dds" ) )

#define PARTSMESH_HAIR( nSex )  ( nSex == SEX_MALE ? _T( "Part_maleHair%02d.o3d" ) : _T( "Part_femaleHair%02d.o3d" ) )
#define PARTSMESH_HEAD( nSex )  ( nSex == SEX_MALE ? _T( "Part_maleHead%02d.o3d" ) : _T( "Part_femaleHead%02d.o3d" ) )
#define PARTSMESH_UPPER( nSex ) ( nSex == SEX_MALE ? _T( "Part_maleUpper.o3d"    ) : _T( "Part_femaleUpper.o3d"    ) )
#define PARTSMESH_LOWER( nSex ) ( nSex == SEX_MALE ? _T( "Part_maleLower.o3d"    ) : _T( "Part_femaleLower.o3d"    ) )
#define PARTSMESH_HAND( nSex )  ( nSex == SEX_MALE ? _T( "Part_maleHand.o3d"     ) : _T( "Part_femaleHand.o3d"     ) )
#define PARTSMESH_FOOT( nSex )  ( nSex == SEX_MALE ? _T( "Part_maleFoot.o3d"     ) : _T( "Part_femaleFoot.o3d"     ) )

#define PARTSTEX_HAIR( nSex )  ( nSex == SEX_MALE ? _T( "Part_maleHair%02d.dds"  ) : _T( "Part_femaleHair%02d.dds"  ) )
#define PARTSTEX_UPPER( nSex ) ( nSex == SEX_MALE ? _T( "Part_maleUpper%02d.dds" ) : _T( "Part_femaleUpper%02d.dds" ) )
#define PARTSTEX_LOWER( nSex ) ( nSex == SEX_MALE ? _T( "Part_maleLower%02d.dds" ) : _T( "Part_femaleLower%02d.dds" ) )
#define PARTSTEX_HAND( nSex )  ( nSex == SEX_MALE ? _T( "Part_maleHand.dds"      ) : _T( "Part_femaleHand.dds"      ) )
#define PARTSTEX_FOOT( nSex )  ( nSex == SEX_MALE ? _T( "Part_maleFoot.dds"      ) : _T( "Part_femaleFoot.dds"      ) )

int GetSelfDST( BYTE type )
{
	switch( type )
	{
		case SAI79::FIRE:
			return DST_RESIST_FIRE;
		case SAI79::WATER:
			return DST_RESIST_WATER;
		case SAI79::WIND:
			return DST_RESIST_WIND; 
		case SAI79::ELECTRICITY:
			return DST_RESIST_ELECTRICITY;
		case SAI79::EARTH:
			return DST_RESIST_EARTH;
	}
	return DST_RESIST_FIRE;
}

int GetStrongDST( BYTE type )
{
	switch( type )
	{
		case SAI79::FIRE:
			return DST_RESIST_WIND;
		case SAI79::WATER:
			return DST_RESIST_FIRE;
		case SAI79::WIND:
			return DST_RESIST_EARTH;
		case SAI79::ELECTRICITY:
			return DST_RESIST_WATER;
		case SAI79::EARTH:
			return DST_RESIST_ELECTRICITY;
	}
	return DST_RESIST_FIRE;
}

int GetWeakDST( BYTE type )
{
	switch( type )
	{
		case SAI79::FIRE:
			return DST_RESIST_WATER;
		case SAI79::WATER:
			return DST_RESIST_ELECTRICITY;
		case SAI79::WIND:
			return DST_RESIST_FIRE;
		case SAI79::ELECTRICITY:
			return DST_RESIST_EARTH;
		case SAI79::EARTH:
			return DST_RESIST_WIND;
	}
	return DST_RESIST_FIRE;
}

// ¸Ó¸®Ä«¶ô ¸ð¾ç°ú »ö ¹Ù²Ù±â  
void CMover::SetHair( int nHair )
{
	if( nHair >= 0 && nHair < MAX_HAIR )
	{
		m_dwHairMesh = nHair;
		CModelObject* pModel = (CModelObject*)m_pModel;
		TCHAR lpszTemp[ 64 ];
		// Hair
		_stprintf( lpszTemp, PARTSMESH_HAIR( GetSex() ), m_dwHairMesh + 1 );
		pModel->LoadElement( lpszTemp, PARTS_HAIR );
		_stprintf( lpszTemp, PARTSTEX_HAIR( GetSex() ), 0 /*nHairColor*/ + 1 );
		pModel->ChangeTexture( PARTS_HAIR, TEX_PART_HAIR( GetSex() ), lpszTemp );
	}
}

void  CMover::SetHairColor( FLOAT r, FLOAT g, FLOAT b )
{ 
#ifndef __Y_HAIR_BUG_FIX	
	if( ( r == 1.0f && g == 1.0f && b == 1.0f ) || 
		( fabs( r - 1.0f ) < 0.001f && fabs( g - 1.0f ) < 0.001f && fabs( b - 1.0f ) < 0.001f ) )
	{
		if( GetSex() == SEX_MALE )
		{
			m_fHairColorR = (nMaleHairColor[m_dwHairMesh][0])/255.f;
			m_fHairColorG = (nMaleHairColor[m_dwHairMesh][1])/255.f;
			m_fHairColorB = (nMaleHairColor[m_dwHairMesh][2])/255.f;
		}
		else
		{
			m_fHairColorR = (nFeMaleHairColor[m_dwHairMesh][0])/255.f;
			m_fHairColorG = (nFeMaleHairColor[m_dwHairMesh][1])/255.f;
			m_fHairColorB = (nFeMaleHairColor[m_dwHairMesh][2])/255.f;
		}
	}
	else
#endif //__Y_HAIR_BUG_FIX
	{
#ifdef __Y_HAIR_BUG_FIX
		m_fHairColorR = ( r < 0.0f ) ? 0.0f : r;
		m_fHairColorG = ( g < 0.0f ) ? 0.0f : g;
		m_fHairColorB = ( b < 0.0f ) ? 0.0f : b;
#else //__Y_HAIR_BUG_FIX
		m_fHairColorR = ( r < 0.3f ) ? 0.3f : r;
		m_fHairColorG = ( g < 0.3f ) ? 0.3f : g;
		m_fHairColorB = ( b < 0.3f ) ? 0.3f : b;
#endif //__Y_HAIR_BUG_FIX
	}
	
	m_dwHairColor = D3DCOLOR_COLORVALUE( m_fHairColorR, m_fHairColorG, m_fHairColorB, 1.0f );
}


void CMover::SetHairColor( DWORD dwHairColor )
{
	m_dwHairColor = dwHairColor;
	m_fHairColorR = ((dwHairColor>>16) & 0xff) / 255.f;
	m_fHairColorG = ((dwHairColor>>8) & 0xff)  / 255.f;
	m_fHairColorB = ((dwHairColor) & 0xff)     / 255.f;

#ifndef __Y_HAIR_BUG_FIX
	if( ( m_fHairColorR == 1.0f && m_fHairColorG == 1.0f && m_fHairColorB == 1.0f ) || 
		( fabs( m_fHairColorR - 1.0f ) < 0.001f && fabs( m_fHairColorG - 1.0f ) < 0.001f && fabs( m_fHairColorB - 1.0f ) < 0.001f ) )
	{
		if( GetSex() == SEX_MALE )
		{
			m_fHairColorR = (nMaleHairColor[m_dwHairMesh][0])/255.f;
			m_fHairColorG = (nMaleHairColor[m_dwHairMesh][1])/255.f;
			m_fHairColorB = (nMaleHairColor[m_dwHairMesh][2])/255.f;
		}
		else
		{
			m_fHairColorR = (nFeMaleHairColor[m_dwHairMesh][0])/255.f;
			m_fHairColorG = (nFeMaleHairColor[m_dwHairMesh][1])/255.f;
			m_fHairColorB = (nFeMaleHairColor[m_dwHairMesh][2])/255.f;
		}

	}
#endif //__Y_HAIR_BUG_FIX

	m_dwHairColor = D3DCOLOR_COLORVALUE( m_fHairColorR, m_fHairColorG, m_fHairColorB, 1.0f );
}

// Ç¥Á¤ ¹Ù²Ù±â 
void CMover::SetHead( int nHead )
{
	if( nHead < MAX_HEAD )
	{
		m_dwHeadMesh = nHead;
		CModelObject* pModel = (CModelObject*)m_pModel;
		TCHAR lpszTemp[ 64 ];
		// Hair
		_stprintf( lpszTemp, PARTSMESH_HEAD( GetSex() ), m_dwHeadMesh + 1 );
		pModel->LoadElement( lpszTemp, PARTS_HEAD );
	}
}
void CMover::SetSkinSet( int nSkinSet )
{
	if( nSkinSet < 2 )
	{
		m_dwSkinSet = nSkinSet;
#ifdef __CLIENT
		UpdateParts();
#endif
	}
}


// ÀÌ ÇÔ¼ö´Â ÀüÃ¼ ÀÇ»óÀ» »õ·Î ¿Ï¼ºÇÏµµ·Ï ÇÑ´Ù.
// º¸Åë ÀÌ ÇÔ¼ö´Â Ã³À½¿¡ Ä³¸¯ÅÍ¸¦ »ý¼ºÇÒ ¶§ ÇÑ¹ø È£ÃâÇÑ´Ù.
void CMover::UpdateParts( BOOL bFakeParts )
{
	UpdateParts( GetSex(), m_dwSkinSet, m_dwFace, m_dwHairMesh, m_dwHeadMesh, 
		m_aEquipInfo, (CModelObject*)m_pModel, bFakeParts ? NULL : &m_Inventory, GetProp()->bIfParts, this );
	((CModelObject*)m_pModel)->RestoreDeviceObjects();
	UpdateBoundBox();
	UpdateParam();
}

#ifdef __TABBED_INV
ItemProp* GetInventoryProp(PEQUIP_INFO pEquipInfo, CInventoryContainer< CItemElem  >* pInventory, int nParts)
{
	CItemElem* pItemElem = NULL;
	ItemProp* pItemProp = NULL;

	if (pInventory == NULL) // fake only
	{
		if (pEquipInfo[nParts].dwId != NULL_ID)
			pItemProp = prj.GetItemProp(pEquipInfo[nParts].dwId);
	}
	else
	{
		pItemElem = pInventory->GetEquip(nParts);
		if (pItemElem)
			pItemProp = pItemElem->GetProp();
	}

	return pItemProp;
}
#endif // __TABBED_INV

#ifdef __TABBED_INV
void CMover::UpdateParts(int nSex, int nSkinSet, int nFace, int nHairMesh, int nHeadMesh, PEQUIP_INFO pEquipInfo, CModelObject* pModel, CInventoryContainer< CItemElem  >* pInventory, BOOL bIfParts, CMover* pMover)
#else // __TABBED_INV
void CMover::UpdateParts(int nSex, int nSkinSet, int nFace, int nHairMesh, int nHeadMesh, PEQUIP_INFO pEquipInfo, CModelObject* pModel, CItemContainer< CItemElem  >* pInventory, BOOL bIfParts, CMover* pMover)
#endif // __TABBED_INV
{
	if( pModel == NULL )
	{
		LPCTSTR szErr = Error( "CMover::UpdateParts : pModel is NULL" );
		ADDERRORMSG( szErr );
		return;
	}
	// ±âº» ºÎÀ§(¼Ó»ì, Çì¾î, µîµî)À» ¼¼ÆÃÇÑ´Ù.
	//LPSKINSET lpSkinset = prj.m_PartsMng.GetSkinSet( nSex, nSkinSet );
	//LPCTSTR lpHair = prj.m_PartsMng.GetHairMeshName( nSex, nHairMesh );
	TCHAR lpszTemp[ 64 ];
	if( bIfParts )
	{
		// Hair
		_stprintf( lpszTemp, PARTSMESH_HAIR( nSex ), nHairMesh + 1 );
		pModel->LoadElement( lpszTemp, PARTS_HAIR );
		// Head
		_stprintf( lpszTemp, PARTSMESH_HEAD( nSex ), nHeadMesh + 1 );
		pModel->LoadElement( lpszTemp, PARTS_HEAD );
	}
	// ¸ÕÀú ÀÍ½ºÅ©·ç½Ãºê ¿ÀºêÁ§Æ®¸¦ TakeOffÇÑ´Ù.
	BOOL abExclusiveParts[ MAX_HUMAN_PARTS ];
	ZeroMemory( abExclusiveParts, sizeof( abExclusiveParts ) );
	for( int i = 0; i < MAX_HUMAN_PARTS; i++ )
	{
		if( i == PARTS_HAIR || i == PARTS_HEAD  )//|| i == PARTS_CAP || i == PARTS_HAND || i == PARTS_FOOT )
			continue;
		DWORD dwParts = -1;
		CItemElem* pItemElem = NULL;
		ItemProp* pItemProp = NULL;
		// ÇÁ·ÎÆÛÆ¼ ²¨³¿
		pItemProp = GetInventoryProp( pEquipInfo, pInventory, i );
		if( pItemProp )
		{
			if( pInventory )
			{
				CItemElem* pItemElem	= pInventory->GetAt( i + pInventory->GetSize() );
				if( pItemElem->IsFlag( CItemElem::expired ) )
					pItemProp	= NULL;
			}
			else
			{
				if( pEquipInfo[i].byFlag & CItemElem::expired )
					pItemProp	= NULL;
			}
		}

		// ÀÍ½ºÅ¬·ç½Ãºê°¡ ÀÖÀ»¶§
		if( pItemProp && pItemProp->dwExclusive != NULL_ID )
		{
			pModel->TakeOffParts( pItemProp->dwExclusive );	// ÀÍ½ºÅ¬·ç½Ãºê¸¦ Á¦°Å
			abExclusiveParts[ pItemProp->dwExclusive ] = TRUE;		// ÀÍ½ºÅ¬·ç½Ãºê µÈ³ÑÀ» ±â¾ï.
		}
	}
	// ÀåÂøºÎÀ§¸¦ ¼¼ÆÃÇÑ´Ù.
	for( int i = 0; i < MAX_HUMAN_PARTS; i++ )
	{
		if( i == PARTS_HAIR || i == PARTS_HEAD  )//|| i == PARTS_CAP || i == PARTS_HAND || i == PARTS_FOOT )
			continue;
		DWORD dwParts = -1;
		CItemElem* pItemElem = NULL;
		ItemProp* pItemProp = NULL;
		if( pInventory == NULL ) // fake only
		{
			if( pEquipInfo[i].dwId != NULL_ID ) 
			{
				if( ( pEquipInfo[i].byFlag & CItemElem::expired ) != CItemElem::expired )
				{
#ifdef __LOOKCHANGE
					if( pEquipInfo[i].dwLook != NULL_ID )
						pItemProp = prj.GetItemProp( pEquipInfo[i].dwLook );
					else
#endif
					{
					pItemProp	= prj.GetItemProp( pEquipInfo[i].dwId );
			}
		}
			}
		}
		else
		{
			pItemElem = pInventory->GetEquip( i );//AtId( padwEquipment[ i ] );
			if( pItemElem )
			{
				if( !pItemElem->IsFlag( CItemElem::expired ) )
				{
#ifdef __LOOKCHANGE
					if( pItemElem->IsChangedLook() )
						pItemProp = prj.GetItemProp(pItemElem->GetLook());
					else
#endif
					{
					pItemProp = pItemElem->GetProp();
			}
		}
			}
		}
		
#ifdef __LOOKCHANGE		
		TCHAR szPartsName[ 128 ];
#else
		TCHAR szPartsName[ 64 ];
#endif

		// °¢ ÆÄÃ÷ÀÇ o3d¸¦ ·Îµù.
		if( pItemProp )
		{
			if( pItemProp->bPartsFile == TRUE )
				prj.m_modelMng.MakePartsName( szPartsName, _T( "part" ), pItemProp->dwID, nSex );
			else
				prj.m_modelMng.MakeModelName( szPartsName, OT_ITEM, pItemProp->dwID );

#ifdef __WINGSFX
			if (pItemProp->dwItemKind3 != IK3_WINGSFX)
#endif //__WINGSFX
			{
				if (bIfParts || (i == PARTS_RWEAPON || i == PARTS_LWEAPON || i == PARTS_SHIELD))
				{
#ifdef __LNB_ANIMATED_HATS
					if (pItemProp->dwItemKind3 == IK3_ANIHAT)
					{
						if (pMover)
							pMover->InitializeAnimatedHat(pItemProp->dwID);

						int nIdx = pModel->GetPartsIdx(PARTS_HAT);
						pModel->Destroy(nIdx);
					}
					else
#endif //__LNB_ANIMATED_HATS
#ifdef __ANI_WING
						if (pItemProp->dwItemKind3 == IK3_ANI_WING)
						{
							memset(szPartsName, 0, sizeof(szPartsName));

							int nIdx = pModel->GetPartsIdx(PARTS_MASK);
							pModel->Destroy(nIdx);
						}
						else
#endif //__ANI_WING
						{
							pModel->LoadElement(szPartsName, i /*pItemProp->dwParts*/);
						}
				}
			}
		}


		if( abExclusiveParts[ i ] == FALSE )
		{
			switch( i )
			{
			case PARTS_RWEAPON: 
				// º¯½Å Ä³¸¯ÅÍ´Â ÀåÂø ¹«±â¸¦ º¼ ¼ö ¾ø°Ô ÇÏÀÚ(ÆÄÃ÷ ÀåÂø¸¸ ¸øÇÔ. ¼öÄ¡ °è»êÀº Àû¿ëµÊ)
				if( pItemProp && ( pMover == NULL || ( pMover && pMover->IsDisguise() == FALSE ) ) )
				{
					switch( pItemProp->dwItemKind3 )
					{
					case IK3_KNUCKLEHAMMER:
						((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetRArmIdx() );
						break;

					case IK3_BOW:
						((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetLHandIdx() );
						break;
#ifndef __ONEHANDYOYO
					case IK3_YOYO:
						((CModelObject*)pModel)->SetParent(PARTS_RWEAPON, ((CModelObject*)pModel)->GetRHandIdx());
						pModel->LoadElement(szPartsName, PARTS_LWEAPON);
						((CModelObject*)pModel)->SetParent(PARTS_LWEAPON, ((CModelObject*)pModel)->GetLHandIdx());
						break;
#endif // __ONEHANDYOYO
					default:
						((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetRHandIdx() );
					}
//					if( pItemProp->dwItemKind3 == IK3_KNUCKLEHAMMER )
//						((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetRArmIdx() );
//					else
//						((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetRHandIdx() );
				}
				else 
					pModel->TakeOffParts( i );
				break;
			case PARTS_LWEAPON: 
				// º¯½Å Ä³¸¯ÅÍ´Â ÀåÂø ¹«±â¸¦ º¼ ¼ö ¾ø°Ô ÇÏÀÚ(ÆÄÃ÷ ÀåÂø¸¸ ¸øÇÔ. ¼öÄ¡ °è»êÀº Àû¿ëµÊ)
				if( pItemProp && ( pMover == NULL || ( pMover && pMover->IsDisguise() == FALSE ) ) )
				{
					((CModelObject*)pModel)->SetParent( PARTS_LWEAPON, ((CModelObject*)pModel)->GetLHandIdx() );
				}
				else 
					pModel->TakeOffParts( i );
				break;
			case PARTS_SHIELD: 
				// º¯½Å Ä³¸¯ÅÍ´Â ÀåÂø ¹«±â¸¦ º¼ ¼ö ¾ø°Ô ÇÏÀÚ(ÆÄÃ÷ ÀåÂø¸¸ ¸øÇÔ. ¼öÄ¡ °è»êÀº Àû¿ëµÊ)
				if( pItemProp && ( pMover == NULL || ( pMover && pMover->IsDisguise() == FALSE ) ) )
					((CModelObject*)pModel)->SetParent( PARTS_SHIELD, ((CModelObject*)pModel)->GetLArmIdx() );
				else 
					pModel->TakeOffParts( i );
				break;
			case PARTS_UPPER_BODY:
				if( bIfParts )
					if( pItemProp == NULL )	
						pModel->LoadElement( PARTSMESH_UPPER( nSex ), PARTS_UPPER_BODY );
				break;
			case PARTS_LOWER_BODY:
				if( bIfParts )
					if( pItemProp == NULL ) 
						pModel->LoadElement( PARTSMESH_LOWER( nSex ), PARTS_LOWER_BODY );
				break;
			case PARTS_HAND:
				if( bIfParts )
					if( pItemProp == NULL ) 
						pModel->LoadElement( PARTSMESH_HAND( nSex ), PARTS_HAND );
				break;
			case PARTS_FOOT:
				if( bIfParts )
					if( pItemProp == NULL ) 
						pModel->LoadElement( PARTSMESH_FOOT( nSex ), PARTS_FOOT );
				break;
#ifdef __LNB_ANIMATED_HATS
			case PARTS_HAT:
			{
				if (bIfParts)
				{
					if (pItemProp == NULL)
					{
						pModel->TakeOffParts(i);
						if (pMover)
							pMover->SetAnimatedHat(nullptr);
					}
				}
			}
			break;
#endif
			default:
				if( bIfParts )
				{
					if( pItemProp == NULL ) 
						pModel->TakeOffParts( i );
				}

			}
		}
	}
} 
// Àåºñ¸¦ ÀåÂøÇÑ´Ù. ¿©±â¼­ ÀÇ»ó ±³Ã¼ ÀÛ¾÷À» ÇØÁØ´Ù.
// nOptionÀº Fake¾ÆÀÌÅÛ ÀåÂø¶§¸¸ ¾²ÀÎ´Ù. - xuzhu -
#ifdef __TABBED_INV
BOOL CMover::DoEquip(int nSex, int nSkinSet,
	CItemElem* pItemElem, int nPart, const EQUIP_INFO& rEquipInfo, CInventoryContainer< CItemElem  >* pInventory,
	PEQUIP_INFO pEquipInfo, CModelObject* pModel, BOOL bEquip, CMover* pMover)
#else // __TABBED_INV
BOOL CMover::DoEquip(int nSex, int nSkinSet,
	CItemElem* pItemElem, int nPart, const EQUIP_INFO& rEquipInfo, CItemContainer< CItemElem  >* pInventory,
	PEQUIP_INFO pEquipInfo, CModelObject* pModel, BOOL bEquip, CMover* pMover)
#endif // __TABBED_INV
{
	ItemProp* pItemProp = pItemElem ? pItemElem->GetProp() : prj.GetItemProp( rEquipInfo.dwId );
	DWORD dwIndex = pItemElem ? pItemElem->m_dwObjIndex : 0;
	DWORD dwParts = pItemProp->dwParts;
	BOOL bIfParts = pMover ? pMover->GetProp()->bIfParts : 0;
	TCHAR lpszTemp[ 64 ];
	BOOL bFake = (pInventory == NULL) ? TRUE : FALSE;
#ifdef __SECURITY_FIXES
	if( dwParts == NULL_ID || ( nPart == -1 &&  dwParts != PARTS_RIDE && dwParts != PARTS_RING2 && dwParts != PARTS_EARRING2) )
		return FALSE;
#else // __SECURITY_FIXES
	if( dwParts == NULL_ID )
		return FALSE;
#endif// __SECURITY_FIXES

	// ¹ÝÁö/±Í°ÉÀÌ ¹þÀ»¶§ Ã³¸®.
#ifdef __ANI_WING
	if (pItemProp && dwParts == PARTS_MASK)
	{
		if (bEquip && pItemProp->dwItemKind3 == IK3_ANI_WING)
		{
			CModel* pModel = prj.m_modelMng.LoadModel(D3DDEVICE, OT_ITEM, pItemProp->dwID);

			CModelObject* pModelObject = (CModelObject*)pModel;
			CString strMotion = pModelObject->GetMotionFileName(_T("stand"));
			assert(strMotion != _T(""));
			pModelObject->LoadMotion(strMotion);
			pMover->SetMaskWing(pModel);
		}
		else
			pMover->SetMaskWing(NULL);
	}
#endif
	if( !bEquip )
	{
		if( dwParts == PARTS_RING1 || dwParts == PARTS_EARRING1
#ifdef __SHARDS
			|| dwParts == PARTS_LRUNE
#endif // __SHARDS
		)
		{
			CItemElem *pItemElemTemp;
			
			if( pInventory )
			{
				pItemElemTemp = (CItemElem*)pInventory->GetEquip( dwParts );
				if( pItemElemTemp != pItemElem )
					dwParts = pItemProp->dwPartsub;
			}
		}
#ifdef __LNB_ANIMATED_HATS
		else if (dwParts == PARTS_HAT)
			if (pMover)
				pMover->SetAnimatedHat(nullptr);
#endif
	}
	// ½ÖÄ®(ÀÌµµ·ù) Ã³¸®.
	if( pItemProp && pItemProp->dwHanded == HD_ONE && pItemProp->dwParts == PARTS_RWEAPON )	// ¿øÇÚµå ¹«±â¸¦ Â÷·Á°í ÇÏ´Â°¡?
	{
		if( bEquip )
		{
			// µðÆúÆ®´Â ÀåÂøÀ§Ä¡ ¿À¸¥¼Õ
			// ¿Þ¼Õ¿¡ ¹«±â°¡ °¡¾ßÇÏ´Â »óÈ²À» °Ë»ç
			ItemProp *pProp = pMover->GetEquipItemProp( pInventory, pEquipInfo, PARTS_RWEAPON );
#ifdef __NEWCLASS
			if (pMover->GetJob() == JOB_BLADE || pMover->GetJob() == JOB_BLADE_MASTER || pMover->GetJob() == JOB_BLADE_HERO || pMover->GetJob() == JOB_STORMBLADE_HERO || pMover->GetJob() == JOB_STORMBLADE_HERO_ULTIMATE)
#elif defined (__3RD_LEGEND16)
			if (pMover->GetJob() == JOB_BLADE || pMover->GetJob() == JOB_BLADE_MASTER || pMover->GetJob() == JOB_BLADE_HERO || pMover->GetJob() == JOB_STORMBLADE_HERO)
#else // __3RD_LEGEND16
#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			if (pMover->GetJob() == JOB_BLADE || pMover->GetJob() == JOB_BLADE_MASTER || pMover->GetJob() == JOB_BLADE_HERO)	// ½ÖÄ®¼Ó¼º
#else // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			if (pMover->GetJob() == JOB_BLADE)	// ½ÖÄ®¼Ó¼º
#endif	// __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#endif // __3RD_LEGEND16
			{
				if( pItemProp->dwID != II_WEA_KNU_ISHOFIST )
				{
					if( pProp && pProp->dwHanded == HD_ONE )	// ¿À¸¥¼Õ¿¡ ¹«±â°¡ ÀÖ³Ä? ±× ¹«±â°¡ ¿øÇÚµå³Ä
					{
						if( pMover->GetEquipItemProp( pInventory, pEquipInfo, PARTS_SHIELD ) == NULL )	//¿Þ¼Õ¿¡ ¹æÆÐ¾ø³Ä?
							dwParts = PARTS_LWEAPON;		// ÀåÂøÀ§Ä¡¸¦ ¿Þ¼ÕÀ¸·Î ¹Ù²Þ
					} 
				}
			}
#ifdef __ONEHANDYOYO
			else if (pMover->GetJob() == JOB_ACROBAT || JOB_JESTER || JOB_JESTER_MASTER || JOB_JESTER_HERO
#ifdef __3RD_LEGEND16
				|| JOB_WINDLURKER_HERO
#endif // __3RD_LEGEND16
#ifdef __4TH_JOBS
				|| JOB_WINDLURKER_HERO_ULTIMATE
#endif // __4TH_JOBS
				)
			{
				if ((pProp && pProp->dwHanded == HD_ONE && pProp->dwItemKind3 == IK3_YOYO)
					&& (pMover->GetEquipItemProp(pInventory, pEquipInfo, PARTS_SHIELD) == NULL)
					)
				{
					dwParts = PARTS_LWEAPON;
				}
			}
#endif // __ONEHANDYOYO
			if( pProp && pProp->dwItemKind3 == IK3_YOYO )		// ¿À¸¥¼Õ¿¡ ¹«±â°¡ ¿ä¿ä¿´À¸¸é
				pModel->TakeOffParts( PARTS_LWEAPON );			// ¿Þ¼Õ¿¡ ¿ä¿ä¸ðµ¨µµ »èÁ¦ÇÔ. ¿À¸¥¼Õ¸ðµ¨Àº ¹Ø¿¡¼­ ÀÚµ¿À¸·Î 
			
		} 
		else
		{
			// ÇØÁ¦½Ãµµ.
			if( nPart >= 0  )		// ÆÄÃ÷¸¦ Á÷Á¢ ÁöÁ¤ÇßÀ»¶§¸¸
				dwParts = nPart;	// ÇØÁ¦ÇÏ¶ó°í ÇÑ ºÎÀ§¸¦ ÇØÁ¦½ÃÅ²´Ù.
		}
	} // ½ÖÄ® Ã³¸®.
	
#ifndef __WORLDSERVER	// <<<< ¿ùµå¿¡¼­ Ã³¸®¾ÈÇÏ¸é ¸Þ¸ð¸® ¸®Å© ³ªÁö ¾Ê³ª? -xuzhu-
	((CModelObject*)pModel)->TakeOffParts( dwParts );	
#endif

#ifndef __ONEHANDYOYO
	if (pItemProp && pItemProp->dwItemKind3 == IK3_YOYO)	// ¹þÀ¸·Á´ø ¹«±â°¡ ¿ä¿ä¿´À¸¸é
		pModel->TakeOffParts(PARTS_LWEAPON);		// ¿Þ¼Õ¿¡ ÀÖ´ø ¿ä¿ä¸ðµ¨µµ ¾ø¾ÖÁØ´Ù.
#endif // __ONEHANDYOYO

	if( bEquip )	// ÀåÂøÇÏ·Á ÇÒ¶§¸¸...
	{
#ifdef __LNB_ANIMATED_HATS
		if (pItemProp->dwParts == PARTS_HAT)
			if (pMover)
				pMover->SetAnimatedHat(nullptr);
#endif
		ItemProp *pHandItemProp	= NULL;
		ItemProp *pLHandItemProp = NULL;

		// µé°íÀÖ´Â ¹«±â ÇÁ·ÎÆÛÆ¼ ²¨³¿.
		pHandItemProp = pMover->GetEquipItemProp( pInventory, pEquipInfo, PARTS_RWEAPON );		// ¿À¸¥¼Õ ¹«±â ÇÁ·ÎÆÛÆ¼.
		pLHandItemProp = pMover->GetEquipItemProp( pInventory, pEquipInfo, PARTS_LWEAPON );		// ¿Þ¼Õ ¹«±â ÇÁ·ÎÆÛÆ¼.
		
#ifdef __2HANDED_SHIELD
		// 조건검사.
		if (pItemProp->dwItemKind3 == IK3_SHIELD)	// 방패류를 착용하려 했을때
		{
			if (pHandItemProp && pHandItemProp->dwHanded == HD_TWO)		// 손에 쥐고 있는게 투핸드면.
			{
				if (pHandItemProp->dwItemJob != JOB_KNIGHT &&
					pHandItemProp->dwItemJob != JOB_KNIGHT_MASTER &&
					pHandItemProp->dwItemJob != JOB_KNIGHT_HERO &&
					pHandItemProp->dwItemJob != JOB_LORDTEMPLER_HERO &&
					pHandItemProp->dwItemJob != JOB_LORDTEMPLER_HERO_ULTIMATE &&
					pHandItemProp->dwItemJob != JOB_RINGMASTER &&
					pHandItemProp->dwItemJob != JOB_RINGMASTER_MASTER &&
					pHandItemProp->dwItemJob != JOB_RINGMASTER_HERO &&
					pHandItemProp->dwItemJob != JOB_FLORIST_HERO &&
					pHandItemProp->dwItemJob != JOB_FLORIST_HERO_ULTIMATE &&
					pHandItemProp->dwItemJob != JOB_ELEMENTOR &&
					pHandItemProp->dwItemJob != JOB_ELEMENTOR_MASTER &&
					pHandItemProp->dwItemJob != JOB_ELEMENTOR_HERO &&
					pHandItemProp->dwItemJob != JOB_ELEMENTORLORD_HERO &&
					pHandItemProp->dwItemJob != JOB_ELEMENTORLORD_HERO_ULTIMATE &&
					pHandItemProp->dwItemJob != JOB_RANGER &&
					pHandItemProp->dwItemJob != JOB_RANGER_MASTER &&
					pHandItemProp->dwItemJob != JOB_RANGER_HERO &&
					pHandItemProp->dwItemJob != JOB_CRACKSHOOTER_HERO &&
					pHandItemProp->dwItemJob != JOB_CRACKSHOOTER_HERO_ULTIMATE &&
					pHandItemProp->dwItemJob != JOB_JESTER &&
					pHandItemProp->dwItemJob != JOB_JESTER_MASTER &&
					pHandItemProp->dwItemJob != JOB_JESTER_HERO &&
					pHandItemProp->dwItemJob != JOB_WINDLURKER_HERO &&
					pHandItemProp->dwItemJob != JOB_WINDLURKER_HERO_ULTIMATE
					)
				{
					if (pInventory)
					{
						CItemElem* pItemElemOld = pInventory->GetEquip(PARTS_RWEAPON);

						if (pInventory->UnEquip(PARTS_RWEAPON) == FALSE)
							return FALSE;
#ifdef __WORLDSERVER
						// 투핸드 무기벗김
						if (pItemElemOld)
						{
							ItemProp* pOldItemProp = pItemElemOld->GetProp();
							pMover->ResetDestParamEquip(pOldItemProp, pItemElemOld);
							g_UserMng.AddDoEquip(pMover, -1, pItemElemOld, FALSE);
						}
#if __VER >= 9 // __ULTIMATE
						prj.m_UltimateWeapon.SetDestParamUltimate(pMover, pItemElemOld, FALSE, PARTS_RWEAPON);
#endif // __ULTIMATE
#endif // worldserver
						if (pEquipInfo)
							pEquipInfo[PARTS_RWEAPON].dwId = NULL_ID;
					}
					else
					{
						if (pEquipInfo)
							pEquipInfo[PARTS_RWEAPON].dwId = NULL_ID;
				}
					pModel->TakeOffParts(PARTS_RWEAPON);
					if (pHandItemProp->dwItemKind3 == IK3_YOYO)	// 들고 있던 무기가 요요였으면
						pModel->TakeOffParts(PARTS_LWEAPON);		// 왼손에 있던 요요모델도 없애준다.
			}
		}
			else
				if (pLHandItemProp && pLHandItemProp->dwParts == PARTS_RWEAPON)	// 왼손에 무기가 쥐어져있으면. 왼손에 드는 무기도 PARTS이름은 모두 RWEAPON이다.
				{
					if (pLHandItemProp->dwItemJob != JOB_KNIGHT &&
						pLHandItemProp->dwItemJob != JOB_KNIGHT_MASTER &&
						pLHandItemProp->dwItemJob != JOB_KNIGHT_HERO &&
						pLHandItemProp->dwItemJob != JOB_LORDTEMPLER_HERO &&
						pLHandItemProp->dwItemJob != JOB_LORDTEMPLER_HERO_ULTIMATE &&
						pLHandItemProp->dwItemJob != JOB_RINGMASTER &&
						pLHandItemProp->dwItemJob != JOB_RINGMASTER_MASTER &&
						pLHandItemProp->dwItemJob != JOB_RINGMASTER_HERO &&
						pLHandItemProp->dwItemJob != JOB_FLORIST_HERO &&
						pLHandItemProp->dwItemJob != JOB_FLORIST_HERO_ULTIMATE &&
						pLHandItemProp->dwItemJob != JOB_ELEMENTOR &&
						pLHandItemProp->dwItemJob != JOB_ELEMENTOR_MASTER &&
						pLHandItemProp->dwItemJob != JOB_ELEMENTOR_HERO &&
						pLHandItemProp->dwItemJob != JOB_ELEMENTORLORD_HERO &&
						pLHandItemProp->dwItemJob != JOB_ELEMENTORLORD_HERO_ULTIMATE &&
						pLHandItemProp->dwItemJob != JOB_RANGER &&
						pLHandItemProp->dwItemJob != JOB_RANGER_MASTER &&
						pLHandItemProp->dwItemJob != JOB_RANGER_HERO &&
						pLHandItemProp->dwItemJob != JOB_CRACKSHOOTER_HERO &&
						pLHandItemProp->dwItemJob != JOB_CRACKSHOOTER_HERO_ULTIMATE &&
						pLHandItemProp->dwItemJob != JOB_JESTER &&
						pLHandItemProp->dwItemJob != JOB_JESTER_MASTER &&
						pLHandItemProp->dwItemJob != JOB_JESTER_HERO &&
						pLHandItemProp->dwItemJob != JOB_WINDLURKER_HERO &&
						pLHandItemProp->dwItemJob != JOB_WINDLURKER_HERO_ULTIMATE
						)
					{
						if (pInventory)
						{
							CItemElem* pItemElemOld = pInventory->GetEquip(PARTS_LWEAPON);

							if (pInventory->UnEquip(PARTS_LWEAPON) == FALSE)
								return FALSE;
#ifdef __WORLDSERVER
							// 왼손 무기벗김
							if (pItemElemOld)
							{
								ItemProp* pOldItemProp = pItemElemOld->GetProp();
#ifndef 	__BLADELWEAPON0608	//	9th 블레이드 양손에 무기를 착용 시 추가 옵션은 오른손에 들고 있는 무기의 것만 적용이 되도록 수정
								pMover->ResetDestParamEquip(pOldItemProp, pItemElemOld);
#endif	//__BLADELWEAPON0608	//	9th 블레이드 양손에 무기를 착용 시 추가 옵션은 오른손에 들고 있는 무기의 것만 적용이 되도록 수정
								g_UserMng.AddDoEquip(pMover, PARTS_LWEAPON, pItemElemOld, FALSE);
						}
#endif // worldserver
							if (pEquipInfo)
								pEquipInfo[PARTS_LWEAPON].dwId = NULL_ID;
					}
						else
						{
							if (pEquipInfo)
								pEquipInfo[PARTS_LWEAPON].dwId = NULL_ID;
						}
						pModel->TakeOffParts(PARTS_LWEAPON);
					}
				}

		} // IK3_SHIELD

		if (pItemProp->dwHanded == HD_TWO)		// 장착하려는 무기가 투핸드 였을때
		{
			if (pHandItemProp && pHandItemProp->dwItemKind3 == IK3_YOYO)	// 들고 있던 무기가 요요였으면
				pModel->TakeOffParts(PARTS_LWEAPON);		// 왼손에 있던 요요모델도 없애준다.

			if (pItemProp->dwItemJob != JOB_KNIGHT &&
				pItemProp->dwItemJob != JOB_KNIGHT_MASTER &&
				pItemProp->dwItemJob != JOB_KNIGHT_HERO &&
				pItemProp->dwItemJob != JOB_LORDTEMPLER_HERO &&
				pItemProp->dwItemJob != JOB_LORDTEMPLER_HERO_ULTIMATE &&
				pItemProp->dwItemJob != JOB_RINGMASTER &&
				pItemProp->dwItemJob != JOB_RINGMASTER_MASTER &&
				pItemProp->dwItemJob != JOB_RINGMASTER_HERO &&
				pItemProp->dwItemJob != JOB_FLORIST_HERO &&
				pItemProp->dwItemJob != JOB_FLORIST_HERO_ULTIMATE &&
				pItemProp->dwItemJob != JOB_ELEMENTOR &&
				pItemProp->dwItemJob != JOB_ELEMENTOR_MASTER &&
				pItemProp->dwItemJob != JOB_ELEMENTOR_HERO &&
				pItemProp->dwItemJob != JOB_ELEMENTORLORD_HERO &&
				pItemProp->dwItemJob != JOB_ELEMENTORLORD_HERO_ULTIMATE &&
				pItemProp->dwItemJob != JOB_RANGER &&
				pItemProp->dwItemJob != JOB_RANGER_MASTER &&
				pItemProp->dwItemJob != JOB_RANGER_HERO &&
				pItemProp->dwItemJob != JOB_CRACKSHOOTER_HERO &&
				pItemProp->dwItemJob != JOB_CRACKSHOOTER_HERO_ULTIMATE &&
				pItemProp->dwItemJob != JOB_JESTER &&
				pItemProp->dwItemJob != JOB_JESTER_MASTER &&
				pItemProp->dwItemJob != JOB_JESTER_HERO &&
				pItemProp->dwItemJob != JOB_WINDLURKER_HERO &&
				pItemProp->dwItemJob != JOB_WINDLURKER_HERO_ULTIMATE
				)
			{
				if (pInventory == NULL)
				{
					if (pEquipInfo[PARTS_SHIELD].dwId != NULL_ID)		// 방패가 있었는가 검사해서 있으면 벗김.
					{
						pModel->TakeOffParts(PARTS_SHIELD);
						if (pEquipInfo)
							pEquipInfo[PARTS_SHIELD].dwId = NULL_ID;
					}
					if (pEquipInfo[PARTS_RWEAPON].dwId != NULL_ID)		// 무기가 있었는가 검사해서 벗김.
					{
						pModel->TakeOffParts(PARTS_RWEAPON);
						if (pEquipInfo)
							pEquipInfo[PARTS_RWEAPON].dwId = NULL_ID;
					}
				}
				else
				{
					CItemElem* pItemElemOld = pInventory->GetEquip(PARTS_SHIELD);
					if (pItemElemOld)
					{
						if (pInventory->UnEquip(PARTS_SHIELD) == FALSE)	// 방패 벗김
							return FALSE;	// 인벤이 꽉차면 걍 취


#ifdef __WORLDSERVER
						if (pItemElemOld)	// 기존장비가 있었다면
						{
							ItemProp* pOldItemProp = pItemElemOld->GetProp();
							pMover->ResetDestParamEquip(pOldItemProp, pItemElemOld);
							g_UserMng.AddDoEquip(pMover, -1, pItemElemOld, FALSE);
						}
#endif
						pModel->TakeOffParts(PARTS_SHIELD);
						if (pEquipInfo)
							pEquipInfo[PARTS_SHIELD].dwId = NULL_ID;
					}

					pItemElemOld = pInventory->GetEquip(PARTS_RWEAPON);
					if (pInventory->GetEquip(PARTS_RWEAPON))
					{
						if (pInventory->UnEquip(PARTS_RWEAPON) == FALSE)	// 무기벗김
							return FALSE;	// 인벤이 꽉차면 걍 취소
#ifdef __WORLDSERVER
						if (pItemElemOld)	// 기존장비가 있었다면
						{
							ItemProp* pOldItemProp = pItemElemOld->GetProp();
							pMover->ResetDestParamEquip(pOldItemProp, pItemElemOld);
							g_UserMng.AddDoEquip(pMover, -1, pItemElemOld, FALSE);
						}
#if __VER >= 9 // __ULTIMATE
						prj.m_UltimateWeapon.SetDestParamUltimate(pMover, pItemElemOld, FALSE, PARTS_RWEAPON);
#endif // __ULTIMATE
#endif // __WORLDSERVER
						pModel->TakeOffParts(PARTS_RWEAPON);
						if (pEquipInfo)
							pEquipInfo[PARTS_RWEAPON].dwId = NULL_ID;
					}
				}
			}
				} // HD_TWO
	} // bEquip == TRUE
#else	 //__2HANDED_SHIELD
		// Á¶°Ç°Ë»ç.
		if (pItemProp->dwItemKind3 == IK3_SHIELD)	// ¹æÆÐ·ù¸¦ Âø¿ëÇÏ·Á ÇßÀ»¶§
		{
			if (pHandItemProp && pHandItemProp->dwHanded == HD_TWO)		// ¼Õ¿¡ Áã°í ÀÖ´Â°Ô ÅõÇÚµå¸é.
			{
				if (pInventory)
				{
					CItemElem* pItemElemOld = pInventory->GetEquip(PARTS_RWEAPON);
					if (pInventory->UnEquip(PARTS_RWEAPON) == FALSE)
						return FALSE;
#ifdef __WORLDSERVER
					// ÅõÇÚµå ¹«±â¹þ±è
					if (pItemElemOld)
					{
						ItemProp* pOldItemProp = pItemElemOld->GetProp();
						pMover->ResetDestParamEquip(pOldItemProp, pItemElemOld);
						g_UserMng.AddDoEquip(pMover, -1, pItemElemOld, FALSE);
					}
#if __VER >= 9 // __ULTIMATE
					prj.m_UltimateWeapon.SetDestParamUltimate(pMover, pItemElemOld, FALSE, PARTS_RWEAPON);
#endif // __ULTIMATE
#endif // worldserver
					if (pEquipInfo)
						pEquipInfo[PARTS_RWEAPON].dwId = NULL_ID;
				}
				else
				{
					if (pEquipInfo)
						pEquipInfo[PARTS_RWEAPON].dwId = NULL_ID;
				}
				pModel->TakeOffParts(PARTS_RWEAPON);
				if (pHandItemProp->dwItemKind3 == IK3_YOYO)	// µé°í ÀÖ´ø ¹«±â°¡ ¿ä¿ä¿´À¸¸é
					pModel->TakeOffParts(PARTS_LWEAPON);		// ¿Þ¼Õ¿¡ ÀÖ´ø ¿ä¿ä¸ðµ¨µµ ¾ø¾ÖÁØ´Ù.
			}
			else
				if (pLHandItemProp && pLHandItemProp->dwParts == PARTS_RWEAPON)	// ¿Þ¼Õ¿¡ ¹«±â°¡ Áã¾îÁ®ÀÖÀ¸¸é. ¿Þ¼Õ¿¡ µå´Â ¹«±âµµ PARTSÀÌ¸§Àº ¸ðµÎ RWEAPONÀÌ´Ù.
				{
					if (pInventory)
					{
						CItemElem* pItemElemOld = pInventory->GetEquip(PARTS_LWEAPON);
						if (pInventory->UnEquip(PARTS_LWEAPON) == FALSE)
							return FALSE;
#ifdef __WORLDSERVER
						// ¿Þ¼Õ ¹«±â¹þ±è
						if (pItemElemOld)
						{
							ItemProp* pOldItemProp = pItemElemOld->GetProp();
#ifndef 	__BLADELWEAPON0608	//	9th ºí·¹ÀÌµå ¾ç¼Õ¿¡ ¹«±â¸¦ Âø¿ë ½Ã Ãß°¡ ¿É¼ÇÀº ¿À¸¥¼Õ¿¡ µé°í ÀÖ´Â ¹«±âÀÇ °Í¸¸ Àû¿ëÀÌ µÇµµ·Ï ¼öÁ¤
							pMover->ResetDestParamEquip(pOldItemProp, pItemElemOld);
#endif	//__BLADELWEAPON0608	//	9th ºí·¹ÀÌµå ¾ç¼Õ¿¡ ¹«±â¸¦ Âø¿ë ½Ã Ãß°¡ ¿É¼ÇÀº ¿À¸¥¼Õ¿¡ µé°í ÀÖ´Â ¹«±âÀÇ °Í¸¸ Àû¿ëÀÌ µÇµµ·Ï ¼öÁ¤
							g_UserMng.AddDoEquip(pMover, PARTS_LWEAPON, pItemElemOld, FALSE);
						}
#endif // worldserver
						if (pEquipInfo)
							pEquipInfo[PARTS_LWEAPON].dwId = NULL_ID;
					}
					else
					{
						if (pEquipInfo)
							pEquipInfo[PARTS_LWEAPON].dwId = NULL_ID;
					}
					pModel->TakeOffParts(PARTS_LWEAPON);
				}
		} // IK3_SHIELD
		if (pItemProp->dwHanded == HD_TWO)		// ÀåÂøÇÏ·Á´Â ¹«±â°¡ ÅõÇÚµå ¿´À»¶§
		{
			if (pHandItemProp && pHandItemProp->dwItemKind3 == IK3_YOYO)	// µé°í ÀÖ´ø ¹«±â°¡ ¿ä¿ä¿´À¸¸é
				pModel->TakeOffParts(PARTS_LWEAPON);		// ¿Þ¼Õ¿¡ ÀÖ´ø ¿ä¿ä¸ðµ¨µµ ¾ø¾ÖÁØ´Ù.
			if (pInventory == NULL)
			{
				if (pEquipInfo[PARTS_SHIELD].dwId != NULL_ID)		// ¹æÆÐ°¡ ÀÖ¾ú´Â°¡ °Ë»çÇØ¼­ ÀÖÀ¸¸é ¹þ±è.
				{
					pModel->TakeOffParts(PARTS_SHIELD);
					if (pEquipInfo)
						pEquipInfo[PARTS_SHIELD].dwId = NULL_ID;
				}
				if (pEquipInfo[PARTS_RWEAPON].dwId != NULL_ID)		// ¹«±â°¡ ÀÖ¾ú´Â°¡ °Ë»çÇØ¼­ ¹þ±è.
				{
					pModel->TakeOffParts(PARTS_RWEAPON);
					if (pEquipInfo)
						pEquipInfo[PARTS_RWEAPON].dwId = NULL_ID;
				}
			}
			else
			{
				CItemElem* pItemElemOld = pInventory->GetEquip(PARTS_SHIELD);
				if (pItemElemOld)
				{
					if (pInventory->UnEquip(PARTS_SHIELD) == FALSE)	// ¹æÆÐ ¹þ±è
						return FALSE;	// ÀÎº¥ÀÌ ²ËÂ÷¸é °Á Ãë¼Ò
#ifdef __WORLDSERVER
					if (pItemElemOld)	// ±âÁ¸Àåºñ°¡ ÀÖ¾ú´Ù¸é
					{
						ItemProp* pOldItemProp = pItemElemOld->GetProp();
						pMover->ResetDestParamEquip(pOldItemProp, pItemElemOld);
						g_UserMng.AddDoEquip(pMover, -1, pItemElemOld, FALSE);
					}
#endif
					pModel->TakeOffParts(PARTS_SHIELD);
					if (pEquipInfo)
						pEquipInfo[PARTS_SHIELD].dwId = NULL_ID;
				}

				pItemElemOld = pInventory->GetEquip(PARTS_RWEAPON);
				if (pInventory->GetEquip(PARTS_RWEAPON))
				{
					if (pInventory->UnEquip(PARTS_RWEAPON) == FALSE)	// ¹«±â¹þ±è
						return FALSE;	// ÀÎº¥ÀÌ ²ËÂ÷¸é °Á Ãë¼Ò
#ifdef __WORLDSERVER
					if (pItemElemOld)	// ±âÁ¸Àåºñ°¡ ÀÖ¾ú´Ù¸é
					{
						ItemProp* pOldItemProp = pItemElemOld->GetProp();
						pMover->ResetDestParamEquip(pOldItemProp, pItemElemOld);
						g_UserMng.AddDoEquip(pMover, -1, pItemElemOld, FALSE);
					}
#if __VER >= 9 // __ULTIMATE
					prj.m_UltimateWeapon.SetDestParamUltimate(pMover, pItemElemOld, FALSE, PARTS_RWEAPON);
#endif // __ULTIMATE
#endif // __WORLDSERVER
					pModel->TakeOffParts(PARTS_RWEAPON);
					if (pEquipInfo)
						pEquipInfo[PARTS_RWEAPON].dwId = NULL_ID;
				}
			}
		} // HD_TWO
	} // bEquip == TRUE
#endif //__2HANDED_SHIELD

	if( bEquip )
	{
		if( pInventory == NULL )
		{
			// ÀÍ½ºÅ©·ç½Ãºê ¾ÆÀÌÅÛ Á¦°Å 
			if( pItemProp->dwExclusive != NULL_ID )
			{
				pModel->TakeOffParts( pItemProp->dwExclusive );
				if( pEquipInfo )
					pEquipInfo[pItemProp->dwExclusive].dwId		= NULL_ID;
			}
			// ÆäÀÌÅ© ÀåÂø 
			if( pEquipInfo )
				memcpy( &pEquipInfo[dwParts], &rEquipInfo, sizeof(EQUIP_INFO) );
		}
		else
		{
			// ÀÍ½ºÅ©·ç½Ãºê ¾ÆÀÌÅÛ Á¦°Å 
			if( pItemProp->dwExclusive != NULL_ID )
			{
				CItemElem* pExclusive	= pInventory->GetEquip( pItemProp->dwExclusive );
				if( pExclusive )
				{
					if( pInventory->UnEquip( pItemProp->dwExclusive ) == FALSE )
						return FALSE;
#ifdef __WORLDSERVER
					ItemProp *pProp	= pExclusive->GetProp();
					pMover->ResetDestParamEquip( pProp, pExclusive );
					g_UserMng.AddDoEquip( pMover, -1, pExclusive, FALSE );
#endif	// __WORLDSERVER

				}
				pModel->TakeOffParts( pItemProp->dwExclusive );

			}

			// ±âÁ¸ Àåºñ Á¦°Å 
			if( dwParts == PARTS_RING1 || dwParts == PARTS_EARRING1 
#ifdef __SHARDS
				|| dwParts == PARTS_LRUNE
#endif // __SHARDS
				)
			{
				DWORD dwElem1 = NULL_ID, dwElem2 = NULL_ID;
				CItemElem* pItemElemTemp1 = (CItemElem*)pInventory->GetEquip( dwParts );
				CItemElem* pItemElemTemp2 = (CItemElem*)pInventory->GetEquip( dwParts + 1 );
				if( pItemElemTemp1 ) dwElem1 = pItemElemTemp1->m_dwItemId;
				if( pItemElemTemp2 ) dwElem2 = pItemElemTemp2->m_dwItemId;
				if( dwElem1 != NULL_ID && dwElem2 == NULL_ID )
					dwParts = pItemProp->dwPartsub;
			}
			CItemElem *pItemElemOld = pInventory->GetEquip( dwParts );
			if( pItemElemOld )
			{
				if( pInventory->UnEquip( dwParts ) == FALSE )
					return FALSE;
#ifdef __WORLDSERVER
				ItemProp *pOldItemProp = pItemElemOld->GetProp();
#ifdef 	__BLADELWEAPON0608	//	9th ºí·¹ÀÌµå ¾ç¼Õ¿¡ ¹«±â¸¦ Âø¿ë ½Ã Ãß°¡ ¿É¼ÇÀº ¿À¸¥¼Õ¿¡ µé°í ÀÖ´Â ¹«±âÀÇ °Í¸¸ Àû¿ëÀÌ µÇµµ·Ï ¼öÁ¤
				if(dwParts != PARTS_LWEAPON )
#endif	//__BLADELWEAPON0608	//	9th ºí·¹ÀÌµå ¾ç¼Õ¿¡ ¹«±â¸¦ Âø¿ë ½Ã Ãß°¡ ¿É¼ÇÀº ¿À¸¥¼Õ¿¡ µé°í ÀÖ´Â ¹«±âÀÇ °Í¸¸ Àû¿ëÀÌ µÇµµ·Ï ¼öÁ¤
					pMover->ResetDestParamEquip( pOldItemProp, pItemElemOld );					
				if( pItemElemOld->m_nResistSMItemId != 0 )	// À¯·áÈ­ ¾ÆÀÌÅÛÀÌ ™VÆÃµÇ¾î ÀÖ´Ù¸é
					((CUser* )pMover)->DoSMItemUnEquip( pItemElemOld, dwParts );
#if __VER >= 9 // __ULTIMATE
				prj.m_UltimateWeapon.SetDestParamUltimate( pMover, pItemElemOld, FALSE, dwParts );
#endif // __ULTIMATE
#endif // worldserver
				
			}
			// »õ Àåºñ ÀåÂø 
			if( TRUE == pInventory->DoEquip( dwIndex, /*MAX_INVENTORY +*/ dwParts ) )
			{
				if( pEquipInfo )
				{
					pEquipInfo[dwParts].dwId	= pItemElem->m_dwObjId;
					pEquipInfo[dwParts].nOption = pItemElem->GetAttrOption();
#ifdef __SWITCH_GLOW_OLDNEW
					pEquipInfo[dwParts].bGlowOld = pItemElem->m_bGlowOld;
#endif // __SWITCH_GLOW_OLDNEW
				}

#ifdef __WORLDSERVER
				if( pItemElem && pItemElem->m_nResistSMItemId != 0 ) // À¯·áÈ­ ¾ÆÀÌÅÛÀÌ ™VÆÃµÇ¾î ÀÖ´Ù¸é
				{
					((CUser* )pMover)->DoSMItemEquip( pItemElem, dwParts );
				}
#if __VER >= 9 // __ULTIMATE
				prj.m_UltimateWeapon.SetDestParamUltimate( pMover, pItemElem, TRUE, dwParts );
#endif // __ULTIMATE
#endif // __WORLDSERVER
			}
			else
			{
				WriteError( "%s %d", __FILE__, __LINE__ );
				return FALSE;
			}
		} // not Fake

#ifndef __WORLDSERVER
#ifdef __LOOKCHANGE		
		TCHAR szPartsName[ 128 ];
#else
		TCHAR szPartsName[ 64 ];
#endif		
		
#ifdef __LOOKCHANGE
		DWORD dwLook = ( pItemElem ? pItemElem->GetLook() : rEquipInfo.dwLook );
		if( dwLook != NULL_ID )
		{
			ItemProp *pProp = prj.GetItemProp( dwLook );
			if( pProp )
			{
				if( pProp->bPartsFile == TRUE )
#ifdef __ANI_WING
					if (pProp->dwItemKind3 == IK3_ANI_WING)
						return TRUE;
					else
#endif
					prj.m_modelMng.MakePartsName( szPartsName, _T( "part" ), pProp->dwID, nSex );
				else
					prj.m_modelMng.MakeModelName( szPartsName, OT_ITEM, pProp->dwID );
			}
		}
		else
#endif
		{
		if( pItemProp->bPartsFile == TRUE )
#ifdef __ANI_WING
			if (pItemProp->dwItemKind3 == IK3_ANI_WING)
				return TRUE;
			else
#endif	
			prj.m_modelMng.MakePartsName( szPartsName, _T( "part" ), pItemProp->dwID, nSex );
		else
			prj.m_modelMng.MakeModelName( szPartsName, OT_ITEM, pItemProp->dwID );
			//prj.m_modelMng.MakePartsName( szPartsName, _T( "item" ), pItemProp->dwID );
		}
		switch( dwParts )
		{
		case PARTS_RWEAPON: 
			// º¯½Å Ä³¸¯ÅÍ´Â ÀåÂø ¹«±â¸¦ º¼ ¼ö ¾ø°Ô ÇÏÀÚ(ÆÄÃ÷ ÀåÂø¸¸ ¸øÇÔ. ¼öÄ¡ °è»êÀº Àû¿ëµÊ)
			if( pMover == NULL || ( pMover && pMover->IsDisguise() == FALSE ) )
			{
				((CModelObject*)pModel)->LoadElement( szPartsName, dwParts );
				switch( pItemProp->dwItemKind3 )
				{
				case IK3_KNUCKLEHAMMER:
					((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetRArmIdx() );
					break;
				case IK3_BOW:
					((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetLHandIdx() );
					break;
#ifndef __ONEHANDYOYO
				case IK3_YOYO:
					((CModelObject*)pModel)->SetParent(PARTS_RWEAPON, ((CModelObject*)pModel)->GetRHandIdx());
					((CModelObject*)pModel)->LoadElement(szPartsName, PARTS_LWEAPON);
					((CModelObject*)pModel)->SetParent(PARTS_LWEAPON, ((CModelObject*)pModel)->GetLHandIdx());
					break;
#endif // __ONEHANDYOYO
				default:
					((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetRHandIdx() );
				}
	//			if( pItemProp->dwItemKind3 == IK3_KNUCKLEHAMMER )
	//				((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetRArmIdx() );
	//			else
	//				((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetRHandIdx() );
			}
			break;
		case PARTS_LWEAPON: 
			// º¯½Å Ä³¸¯ÅÍ´Â ÀåÂø ¹«±â¸¦ º¼ ¼ö ¾ø°Ô ÇÏÀÚ(ÆÄÃ÷ ÀåÂø¸¸ ¸øÇÔ. ¼öÄ¡ °è»êÀº Àû¿ëµÊ)
			if( pMover == NULL || ( pMover && pMover->IsDisguise() == FALSE ) )
			{
				((CModelObject*)pModel)->LoadElement( szPartsName, dwParts );
				((CModelObject*)pModel)->SetParent( PARTS_LWEAPON, ((CModelObject*)pModel)->GetLHandIdx() );
			}
			break;
		case PARTS_SHIELD: 
			// º¯½Å Ä³¸¯ÅÍ´Â ÀåÂø ¹«±â¸¦ º¼ ¼ö ¾ø°Ô ÇÏÀÚ(ÆÄÃ÷ ÀåÂø¸¸ ¸øÇÔ. ¼öÄ¡ °è»êÀº Àû¿ëµÊ)
			if( pMover == NULL || ( pMover && pMover->IsDisguise() == FALSE ) )
			{
				((CModelObject*)pModel)->LoadElement( szPartsName, dwParts );
				((CModelObject*)pModel)->SetParent( PARTS_SHIELD, ((CModelObject*)pModel)->GetLArmIdx() );
			}
			break;
		case PARTS_UPPER_BODY:
			if( bIfParts )
			{
				((CModelObject*)pModel)->LoadElement( szPartsName, dwParts );
				_stprintf( lpszTemp, PARTSTEX_UPPER( nSex ), nSkinSet + 1 );
				pModel->ChangeTexture( PARTS_UPPER_BODY, TEX_PART_UPPER( nSex ), lpszTemp );
			}
			break;
		case PARTS_LOWER_BODY:
			if( bIfParts )
			{
				{
					((CModelObject*)pModel)->LoadElement( szPartsName, dwParts );
					_stprintf( lpszTemp, PARTSTEX_LOWER( nSex ), nSkinSet + 1 );
					pModel->ChangeTexture( PARTS_LOWER_BODY, TEX_PART_LOWER( nSex ), lpszTemp );
				}
			}
			break;
#ifdef __LNB_ANIMATED_HATS
		case PARTS_HAT:
			if (pItemProp->dwItemKind3 == IK3_ANIHAT)
			{
				//Load
				if (pMover)
					pMover->InitializeAnimatedHat(pItemProp->dwID);

			}
			else
				((CModelObject*)pModel)->LoadElement(szPartsName, dwParts);
			break;
#endif
		default:
#ifdef __WINGSFX
			if (bIfParts && pItemProp->dwItemKind3 != IK3_WINGSFX)
#else //__WINGSFX
			if (bIfParts)
#endif //__WINGSFX
				((CModelObject*)pModel)->LoadElement( szPartsName, dwParts );
			break;

		}

#ifdef __CLIENT
#if __VER >= 15 // __BS_FIXED_EQUIPMOTION
		if( PARTS_LWEAPON == dwParts || PARTS_RWEAPON == dwParts || PARTS_SHIELD == dwParts )
			pMover->SetMotion( MTI_STAND, ANILOOP_1PLAY , MOP_NO_TRANS );

#endif //__BS_FIXED_EQUIPMOTION
#endif //__CLIENT
		
#endif // not WorldServer
	} // ÀåÂø.
	else
	// Å»Âø.
	{
		if( bIfParts )
		{
			if( pItemProp->dwExclusive != NULL_ID )
			{
				switch( pItemProp->dwExclusive )
				{
				case PARTS_UPPER_BODY:
					pModel->LoadElement( PARTSMESH_UPPER( nSex ), PARTS_UPPER_BODY );
					_stprintf( lpszTemp, PARTSTEX_UPPER( nSex ), nSkinSet + 1 );
					pModel->ChangeTexture( PARTS_UPPER_BODY, TEX_PART_UPPER( nSex ), lpszTemp );
					break;
				case PARTS_LOWER_BODY:
					{

						ItemProp* pItemPropEquip = NULL;
						if( pItemProp->dwParts == PARTS_CLOTH )
						{
							pItemPropEquip = pMover->GetEquipItemProp( pInventory, pEquipInfo, PARTS_UPPER_BODY );
						}
						else
						{
							pItemPropEquip = pMover->GetEquipItemProp( pInventory, pEquipInfo, PARTS_CLOTH );
						}

						if( pItemPropEquip == NULL )
						{
							pModel->LoadElement( PARTSMESH_LOWER( nSex ), PARTS_LOWER_BODY );
							_stprintf( lpszTemp, PARTSTEX_LOWER( nSex ), nSkinSet + 1 );
							pModel->ChangeTexture( PARTS_LOWER_BODY, TEX_PART_LOWER( nSex ), lpszTemp );
						}					
					}					
					break;
				case PARTS_HAND:
					pModel->LoadElement( PARTSMESH_HAND( nSex ), PARTS_HAND );
					break;
				case PARTS_FOOT:
					pModel->LoadElement( PARTSMESH_FOOT( nSex ), PARTS_FOOT );
					break;
				}
			}
		}
		if( pInventory && pInventory->GetEquip( dwParts ) )
		{
			if( pInventory->UnEquip( dwParts ) == FALSE )
			{
#ifdef __WORLDSERVER
				if( TRUE == pMover->IsPlayer() )
					( (CUser*)pMover )->AddDefinedText(TID_GAME_LACKSPACE, "" );
#endif	// __WORLDSERVER				
				return FALSE;
			}

#ifdef __WORLDSERVER
#if __VER >= 9 // __ULTIMATE
			prj.m_UltimateWeapon.SetDestParamUltimate( pMover, pItemElem, FALSE, dwParts );
#endif // __ULTIMATE
			if( pItemElem && pItemElem->m_nResistSMItemId != 0 )	// À¯·áÈ­ ¾ÆÀÌÅÛÀÌ ™VÆÃµÇ¾î ÀÖ´Ù¸é
			{
				((CUser* )pMover)->DoSMItemUnEquip( pItemElem, dwParts );
			}
#endif // __WORLDSERVER
		}

		if( pEquipInfo )
		{
			pEquipInfo[dwParts].dwId	= NULL_ID;
			pEquipInfo[dwParts].nOption		= 0;
			pEquipInfo[dwParts].byFlag	= 0;
#ifdef __SWITCH_GLOW_OLDNEW
			pEquipInfo[dwParts].bGlowOld = FALSE;
#endif // __SWITCH_GLOW_OLDNEW
		}

#ifndef __WORLDSERVER
		if( bIfParts )
		{
			switch( dwParts )
			{
			case PARTS_UPPER_BODY:
				pModel->LoadElement( PARTSMESH_UPPER( nSex ), PARTS_UPPER_BODY );
				_stprintf( lpszTemp, PARTSTEX_UPPER( nSex ), nSkinSet + 1 );
				pModel->ChangeTexture( PARTS_UPPER_BODY, TEX_PART_UPPER( nSex ), lpszTemp );
				break;
			case PARTS_LOWER_BODY:
				pModel->LoadElement( PARTSMESH_LOWER( nSex ), PARTS_LOWER_BODY );
				_stprintf( lpszTemp, PARTSTEX_LOWER( nSex ), nSkinSet + 1 );
				pModel->ChangeTexture( PARTS_LOWER_BODY, TEX_PART_LOWER( nSex ), lpszTemp );
				break;
			case PARTS_HAND:
				pModel->LoadElement( PARTSMESH_HAND( nSex ), PARTS_HAND );
				break;
			case PARTS_FOOT:
				pModel->LoadElement( PARTSMESH_FOOT( nSex ), PARTS_FOOT );
				break;
			}
		}
#endif

#ifdef __CLIENT
#if __VER >= 15 // __BS_FIXED_EQUIPMOTION
		if( PARTS_LWEAPON == dwParts || PARTS_RWEAPON == dwParts || PARTS_SHIELD == dwParts )
			pMover->SetMotion( MTI_STAND, ANILOOP_1PLAY , MOP_FIXED );
#endif //__BS_FIXED_EQUIPMOTION
#endif //__CLIENT

	} // Å»Âø


	// ¹þ±æ¶§
	if( bEquip == FALSE )
	{
		// À§¿¡¼­ ¿À¸¥¼Õ ¹«±â¸¦ ÇØÁ¦ Çß¾ú´Ù. 
		if( nPart == PARTS_RWEAPON )
		{
			if( pInventory )
			{
				CItemElem* pItemLeft = pInventory->GetEquip( PARTS_LWEAPON );
				if( pItemLeft )	// ¿Þ¼Õ¿¡ ¹«±â°¡ ³²¾ÆÀÖ´Ù.
				{
					//¿À¸¥¼ÕÀ¸·Î ¿Å°ÜÁÜ.
					#ifdef __WORLDSERVER
					if( pMover->IsSMMode( SM_RESIST_ATTACK_LEFT ) )
					{
						pMover->m_nAttackResistRight = pMover->m_nAttackResistLeft;
						pMover->m_nAttackResistLeft = 0xff;
						DWORD dwSMTime = pMover->m_dwSMTime[SM_RESIST_ATTACK_LEFT];
						pMover->SetSMMode( SM_RESIST_ATTACK_LEFT, 1 );
						pMover->SetSMMode( SM_RESIST_ATTACK_RIGHT, dwSMTime );
						((CUser*)pMover)->AddResistSMMode( pMover->m_nAttackResistLeft, pMover->m_nAttackResistRight, pMover->m_nDefenseResist );
					}
					#endif // __WORLDSERVER
					
					int nInvenSize = pInventory->GetSize();
					pInventory->Swap( nInvenSize + PARTS_LWEAPON, nInvenSize + PARTS_RWEAPON );	
#ifdef __WORLDSERVER			
#if __VER >= 9 // __ULTIMATE
					prj.m_UltimateWeapon.SetDestParamUltimate( pMover, pItemLeft, TRUE, PARTS_RWEAPON );
#endif // __ULTIMATE
#endif // __WORLDSERVER

				#ifdef __CLIENT
					((CModelObject*)pModel)->MovePart( PARTS_RWEAPON, PARTS_LWEAPON );
					((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetRHandIdx() );
				#endif //__CLIENT
				}
			}
			else
			{	// fake
				if( pEquipInfo )
				{
					if( pEquipInfo[PARTS_LWEAPON].dwId != NULL_ID )
					{
						memcpy( &pEquipInfo[PARTS_RWEAPON], &pEquipInfo[PARTS_LWEAPON], sizeof(EQUIP_INFO) );
						pEquipInfo[PARTS_LWEAPON].dwId	= NULL_ID;
						pEquipInfo[PARTS_LWEAPON].nOption	= 0;
						pEquipInfo[PARTS_LWEAPON].byFlag	= 0;
#ifdef __LOOKCHANGE
						pEquipInfo[PARTS_LWEAPON].dwLook = NULL_ID;
#endif
#ifdef __SWITCH_GLOW_OLDNEW
						pEquipInfo[PARTS_LWEAPON].bGlowOld = FALSE;
#endif // __SWITCH_GLOW_OLDNEW
#ifdef __CLIENT
						((CModelObject*)pModel)->MovePart( PARTS_RWEAPON, PARTS_LWEAPON );
						((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetRHandIdx() );
#endif	// __CLIENT
					}
				}
			}
		}
	}

#ifdef __CLIENT
	D3DXVECTOR3 vPos = pMover->GetPos();
				
	if( bEquip )
	{
		if( pItemProp )
		{
			if( pItemProp->dwItemKind1 == IK1_WEAPON )
			{
				PLAYSND( SND_INF_EQUIPWEAPON, &vPos );
			}
			else
			if( pItemProp->dwItemKind1 == IK1_GENERAL && pItemProp->dwItemKind2 == IK2_JEWELRY )
			{
				PLAYSND( SND_INF_EQUIPACCESSORY, &vPos );
			}
			else
			if( pItemProp->dwItemKind1 == IK1_ARMOR && pItemProp->dwItemKind2 == IK2_CLOTH )
			{
				PLAYSND( SND_INF_EQUIPCLOTH, &vPos );
			}
			else
			if( pItemProp->dwItemKind1 == IK1_ARMOR && pItemProp->dwItemKind2 == IK2_ARMOR 
				|| pItemProp->dwItemKind2 == IK2_ARMORETC )
			{
				PLAYSND( SND_INF_EQUIPARMOR, &vPos );
			}	
#ifdef __SHARDS
			else
				if (pItemProp->dwItemKind1 == IK1_GENERAL && pItemProp->dwItemKind2 == IK2_RUNE)
				{
					PLAYSND("ItemDropDing.wav", &vPos);
				}
#endif // __SHARDS
		}
	}
	else
	{
		PLAYSND( SND_INF_INVENTORYDROP, &vPos );		
	}
#endif //__CLIENT

	return TRUE;
}

#if 0
//{{AFX
// static DoEquipÀÇ »õ¹öÀü.
BOOL CMover::DoEquip( CItemElem* pItemElem, DWORD dwItemIndex, int nOption, CItemContainer< CItemElem  >* pInventory, 
					  LPDWORD padwEquipment, CModelObject* pModel, BOOL bEquip, CMover *pMover ) 
{
	ItemProp* pItemProp = pItemElem ? pItemElem->GetProp() : prj.GetItemProp( dwItemIndex );
	DWORD dwIndex = pItemElem ? pItemElem->m_dwObjIndex : 0;
	DWORD dwParts = pItemProp->dwParts;
	BOOL bIfParts = pMover ? pMover->GetProp()->bIfParts : 0;
	TCHAR lpszTemp[ 64 ];
	BOOL bFake = (pInventory == NULL) ? TRUE : FALSE;
	if( dwParts == NULL_ID )
		return FALSE;

	// ¹ÝÁö/±Í°ÉÀÌ ¹þÀ»¶§ Ã³¸®.
	if( !bEquip )
	{
		if( dwParts == PARTS_RING1 || dwParts == PARTS_EARRING1 
#ifdef __SHARDS
			|| dwParts == PARTS_LRUNE
#endif // __SHARDS
			)
		{
			CItemElem *pItemElemTemp;
			
			if( pInventory )
			{
				pItemElemTemp = (CItemElem*)pInventory->GetEquip( dwParts );
				if( pItemElemTemp != pItemElem )
					dwParts = pItemProp->dwPartsub;
			}
		}
	}

	if( bEquip )
	{
		// ½ÖÄ®(ÀÌµµ·ù) Ã³¸®.
		if( pItemProp && pItemProp->dwHanded == HD_ONE && pItemProp->dwParts == PARTS_RWEAPON )	// ¿øÇÚµå ¹«±â¸¦ Â÷·Á°í ÇÏ´Â°¡?
		{
			// µðÆúÆ®´Â ÀåÂøÀ§Ä¡ ¿À¸¥¼Õ
 #ifdef __XUZHU
			//if( Á÷¾÷ÀÌ ºí·¹ÀÌµå³Ä? )	// ½ÖÄ®¼Ó¼º
 #else
			if( 0 /*Á÷¾÷ÀÌ ºí·¹ÀÌµå³Ä?*/ )	// ½ÖÄ®¼Ó¼º
 #endif
			{
				if( pMover->GetEquipItemProp( bFake, PARTS_RWEAPON ) )	// ¿À¸¥¼Õ¿¡ ¹«±â°¡ ÀÖ³Ä?
				{
					if( pMover->GetEquipItemProp( bFake, PARTS_SHIELD ) == NULL )	//¿Þ¼Õ¿¡ ¹æÆÐ¾ø³Ä?
						dwParts = PARTS_LWEAPON;		// ÀåÂøÀ§Ä¡¸¦ ¿Þ¼ÕÀ¸·Î ¹Ù²Þ
				} 
			}
		}
	} else
	{
		// ÇØÁ¦.
		CItemElem *pLHandElem = pInventory->Get&Equip( PARTS_LWEAPON );
		if( pItemElem == pLHandElem )	// ¿Þ¼Õ¿¡ ÀåÂøÇÑ °Í°ú ÇØÁ¦ÇÏ·Á°í ¿äÃ»ÇÑ ¾ÆÀÌÅÛÀÌ °°À»¶§.
			dwParts = PARTS_LWEAPON;	// ÆÄÃ÷ ÀÌ¸§À» ÀÌ°É·Î ¹Ù²ãÁÖÀÚ.
	}

	
#ifndef __WORLDSERVER
	((CModelObject*)pModel)->TakeOffParts( dwParts );
#endif

	if( bEquip )	// ÀåÂøÇÏ·Á ÇÒ¶§¸¸...
	{
		ItemProp *pHandItemProp	= NULL;
		ItemProp *pLHandItemProp = NULL;

		// µé°íÀÖ´Â ¹«±â ÇÁ·ÎÆÛÆ¼ ²¨³¿.
		if( pInventory == NULL )
		{
			if( padwEquipment[PARTS_RWEAPON] != NULL_ID )
				pHandItemProp = prj.GetItemProp( padwEquipment[PARTS_RWEAPON] );
		} else
		{
			CItemElem *pItemElem = pInventory->GetEquip( PARTS_RWEAPON );		
			if( pItemElem )
				pHandItemProp = pItemElem->GetProp();
		}

		if( pInventory == NULL )
		{
			if( padwEquipment[PARTS_LWEAPON] != NULL_ID )
				pLHandItemProp = prj.GetItemProp( padwEquipment[PARTS_LWEAPON] );
		} else
		{
			CItemElem *pItemElem = pInventory->GetEquip( PARTS_LWEAPON );		
			if( pItemElem )
				pLHandItemProp = pItemElem->GetProp();
		}
		
		// Á¶°Ç°Ë»ç.
		if( pItemProp->dwItemKind3 == IK3_SHIELD )	// ¹æÆÐ·ù¸¦ Âø¿ëÇÏ·Á ÇßÀ»¶§
		{
			if( pHandItemProp )
			{
				if( pHandItemProp->dwHanded == HD_TWO )		// ¼Õ¿¡ Áã°í ÀÖ´Â°Ô ÅõÇÚµå¸é.
				{
//					pModel->TakeOffParts( PARTS_RWEAPON );	// ½ÇÆÐÇÒ ¼ö ÀÖÀ¸¹Ç·Î ¾Æ·¡·Î ÀÌµ¿
					if( pInventory )
					{
						CItemElem *pItemElemOld = pInventory->GetEquip( PARTS_RWEAPON );
						if( pInventory->UnEquip( PARTS_RWEAPON ) == FALSE )	
							return FALSE;
//							ASSERT( 0 );
#ifdef __WORLDSERVER
						// ÅõÇÚµå ¹«±â¹þ±è
						if( pItemElemOld )
						{
							ItemProp *pOldItemProp = pItemElemOld->GetProp();
							pMover->ResetDestParamEquip( pOldItemProp, pItemElemOld );
							g_UserMng.AddDoEquip( pMover, pItemElemOld->m_dwObjId, pItemElemOld->m_dwItemId, pItemElemOld->GetAttrOption(), (BYTE)FALSE );
						}
#endif // worldserver
						if( padwEquipment ) padwEquipment[ PARTS_RWEAPON ] = NULL_ID;
					} else
					{
						if( padwEquipment )
							padwEquipment[ PARTS_RWEAPON ] = NULL_ID;
					}
					pModel->TakeOffParts( PARTS_RWEAPON );
				}
				else
				if( pLHandItemProp && pLHandItemProp->dwParts == PARTS_RWEAPON )	// ¿Þ¼Õ¿¡ ¹«±â°¡ Áã¾îÁ®ÀÖÀ¸¸é. ¿Þ¼Õ¿¡ µå´Â ¹«±âµµ PARTSÀÌ¸§Àº ¸ðµÎ RWEAPONÀÌ´Ù.
				{
					if( pInventory )
					{
						CItemElem *pItemElemOld = pInventory->GetEquip( PARTS_LWEAPON );
						if( pInventory->UnEquip( PARTS_LWEAPON ) == FALSE )	
							return FALSE;
 #ifdef __WORLDSERVER
						// ¿Þ¼Õ ¹«±â¹þ±è
						if( pItemElemOld )
						{
							ItemProp *pOldItemProp = pItemElemOld->GetProp();
							pMover->ResetDestParamEquip( pOldItemProp, pItemElemOld );
							g_UserMng.AddDoEquip( pMover, pItemElemOld->m_dwObjId, pItemElemOld->m_dwItemId, pItemElemOld->GetAttrOption(), (BYTE)FALSE );
						}
 #endif // worldserver
						
						if( padwEquipment ) padwEquipment[ PARTS_LWEAPON ] = NULL_ID;
					} else
					{
						if( padwEquipment )
							padwEquipment[ PARTS_LWEAPON ] = NULL_ID;
					}
					pModel->TakeOffParts( PARTS_LWEAPON );
				}
			}
		}
		if( pItemProp->dwHanded == HD_TWO )		// ÀåÂøÇÏ·Á´Â ¹«±â°¡ ÅõÇÚµå ¿´À»¶§
		{
			if( pInventory == NULL )
			{
				if( padwEquipment[ PARTS_SHIELD ] != NULL_ID )		// ¹æÆÐ°¡ ÀÖ¾ú´Â°¡ °Ë»çÇØ¼­ ÀÖÀ¸¸é ¹þ±è.
				{
					pModel->TakeOffParts( PARTS_SHIELD );
					if( padwEquipment )
						padwEquipment[ PARTS_SHIELD ] = NULL_ID;
				}
				if( padwEquipment[ PARTS_RWEAPON ] != NULL_ID )		// ¹«±â°¡ ÀÖ¾ú´Â°¡ °Ë»çÇØ¼­ ¹þ±è.
				{
					pModel->TakeOffParts( PARTS_RWEAPON );
					if( padwEquipment )
						padwEquipment[ PARTS_RWEAPON ] = NULL_ID;
				}
			}
			else
			{
				CItemElem *pItemElemOld = pInventory->GetEquip( PARTS_SHIELD );
				if( pItemElemOld )
				{
					if( pInventory->UnEquip( PARTS_SHIELD ) == FALSE )	// ¹æÆÐ ¹þ±è
						return FALSE;	// ÀÎº¥ÀÌ ²ËÂ÷¸é °Á Ãë¼Ò
#ifdef __WORLDSERVER
					if( pItemElemOld )	// ±âÁ¸Àåºñ°¡ ÀÖ¾ú´Ù¸é
					{
						ItemProp *pOldItemProp = pItemElemOld->GetProp();
						
						pMover->ResetDestParamEquip( pOldItemProp, pItemElemOld );

						g_UserMng.AddDoEquip( pMover, pItemElemOld->m_dwObjId, pItemElemOld->m_dwItemId, pItemElemOld->GetAttrOption(), (BYTE)FALSE );
					}
#endif
					pModel->TakeOffParts( PARTS_SHIELD );
					if( padwEquipment ) padwEquipment[ PARTS_SHIELD ] = NULL_ID;
				}
				
				pItemElemOld = pInventory->GetEquip( PARTS_RWEAPON );
				if( pInventory->GetEquip( PARTS_RWEAPON ) )
				{
					if( pInventory->UnEquip( PARTS_RWEAPON ) == FALSE )	// ¹«±â¹þ±è
						return FALSE;	// ÀÎº¥ÀÌ ²ËÂ÷¸é °Á Ãë¼Ò
#ifdef __WORLDSERVER
					if( pItemElemOld )	// ±âÁ¸Àåºñ°¡ ÀÖ¾ú´Ù¸é
					{
						ItemProp *pOldItemProp = pItemElemOld->GetProp();
						
						pMover->ResetDestParamEquip( pOldItemProp, pItemElemOld );

						g_UserMng.AddDoEquip( pMover, pItemElemOld->m_dwObjId, pItemElemOld->m_dwItemId, pItemElemOld->GetAttrOption(), (BYTE)FALSE );
					}
#endif
					pModel->TakeOffParts( PARTS_RWEAPON );
					if( padwEquipment ) padwEquipment[ PARTS_RWEAPON ] = NULL_ID;
				}
			}
		}
	}

	if( bEquip )
	{
		if( pInventory == NULL )
		{
			// ÀÍ½ºÅ©·ç½Ãºê ¾ÆÀÌÅÛ Á¦°Å 
			if( pItemProp->dwExclusive != NULL_ID )
			{
				pModel->TakeOffParts( pItemProp->dwExclusive );
				if( padwEquipment )
					padwEquipment[ pItemProp->dwExclusive ] = NULL_ID;
			}
			// ÆäÀÌÅ© ÀåÂø 
			if( padwEquipment )
			{
				padwEquipment[ dwParts ] = dwItemIndex;
			}
		}
		else
		{
			// ÀÍ½ºÅ©·ç½Ãºê ¾ÆÀÌÅÛ Á¦°Å 
			if( pItemProp->dwExclusive != NULL_ID )
			{
				//if( pInventory->GetAt( MAX_INVENTORY + pItemProp->dwExclusive ) )
				if( pInventory->GetEquip( pItemProp->dwExclusive ) )
					if( pInventory->UnEquip( pItemProp->dwExclusive ) == FALSE )
						return FALSE;
					//if( pInventory->UnEquip( MAX_INVENTORY + pItemProp->dwExclusive ) == FALSE )
//						ASSERT( 0 );
				pModel->TakeOffParts( pItemProp->dwExclusive );
			}
			// ±âÁ¸ Àåºñ Á¦°Å 
			//if( pInventory->GetAt( MAX_INVENTORY + dwParts ) )
			if( bEquip )
			{
				if( dwParts == PARTS_RING1 || dwParts == PARTS_EARRING1
#ifdef __SHARDS
					|| dwParts == PARTS_LRUNE
#endif // __SHARDS
					)
				{
					DWORD dwElem1 = NULL_ID, dwElem2 = NULL_ID;
					CItemElem* pItemElemTemp1 = (CItemElem*)pInventory->GetEquip( dwParts );
					CItemElem* pItemElemTemp2 = (CItemElem*)pInventory->GetEquip( dwParts + 1 );
					if( pItemElemTemp1 ) dwElem1 = pItemElemTemp1->m_dwItemId;
					if( pItemElemTemp2 ) dwElem2 = pItemElemTemp2->m_dwItemId;
					if( dwElem1 != NULL_ID && dwElem2 == NULL_ID )
						dwParts = pItemProp->dwPartsub;
				}
			}

			CItemElem *pItemElemOld = pInventory->GetEquip( dwParts );
			
			if( pItemElemOld )
			{
				//if( pInventory->UnEquip(MAX_INVENTORY + dwParts ) == FALSE )
				if( pInventory->UnEquip( dwParts ) == FALSE )
					return FALSE;
#ifdef __WORLDSERVER
				if( pItemElemOld )	// ±âÁ¸Àåºñ°¡ ÀÖ¾ú´Ù¸é
				{
					ItemProp *pOldItemProp = pItemElemOld->GetProp();

					pMover->ResetDestParamEquip( pOldItemProp, pItemElemOld );					
				}
#endif // worldserver
				
			}
			// »õ Àåºñ ÀåÂø 
			if( TRUE == pInventory->DoEquip( dwIndex, /*MAX_INVENTORY +*/ dwParts ) )
			{
				if( padwEquipment )
					padwEquipment[ dwParts ] = pItemElem->m_dwObjId;
			}
			else
			{
				WriteError( "%s %d", __FILE__, __LINE__ );
				return FALSE;
			}
		}

#ifndef __WORLDSERVER
#ifdef __LOOKCHANGE		
		TCHAR szPartsName[ 128 ];
#else
		TCHAR szPartsName[ 64 ];
#endif	

		if( pItemProp->bPartsFile == TRUE )
			prj.m_modelMng.MakePartsName( szPartsName, _T( "part" ), pItemProp->dwID, nSex );
		else
			prj.m_modelMng.MakeModelName( szPartsName, OT_ITEM, pItemProp->dwID );
			//prj.m_modelMng.MakePartsName( szPartsName, _T( "item" ), pItemProp->dwID );
		switch( dwParts )
		{
		case PARTS_RWEAPON: 
			((CModelObject*)pModel)->LoadElement( szPartsName, dwParts );
			switch( pItemProp->dwItemKind3 )
			{
			case IK3_KNUCKLEHAMMER:
				((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetRArmIdx() );
				break;
			case IK3_BOW:
				((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetLHandIdx() );
				break;
			case IK3_YOYO:
				((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetRHandIdx() );
				((CModelObject*)pModel)->LoadElement( szPartsName, PARTS_LWEAPON );
				((CModelObject*)pModel)->SetParent( PARTS_LWEAPON, ((CModelObject*)pModel)->GetLHandIdx() );
				break;
			default:
				((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetRHandIdx() );
			}
//			if( pItemProp->dwItemKind3 == IK3_KNUCKLEHAMMER )
//				((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetRArmIdx() );
//			else
//				((CModelObject*)pModel)->SetParent( PARTS_RWEAPON, ((CModelObject*)pModel)->GetRHandIdx() );
			break;
		case PARTS_LWEAPON: 
			((CModelObject*)pModel)->LoadElement( szPartsName, dwParts );
			((CModelObject*)pModel)->SetParent( PARTS_LWEAPON, ((CModelObject*)pModel)->GetLHandIdx() );
			break;
		case PARTS_SHIELD: 
			((CModelObject*)pModel)->LoadElement( szPartsName, dwParts );
			((CModelObject*)pModel)->SetParent( PARTS_SHIELD, ((CModelObject*)pModel)->GetLArmIdx() );
			break;
		case PARTS_UPPER_BODY:
			if( bIfParts )
			{
				((CModelObject*)pModel)->LoadElement( szPartsName, dwParts );
				_stprintf( lpszTemp, PARTSTEX_UPPER( nSex ), nSkinSet + 1 );
				pModel->ChangeTexture( PARTS_UPPER_BODY, TEX_PART_UPPER( nSex ), lpszTemp );
			}
			break;
		case PARTS_LOWER_BODY:
			if( bIfParts )
			{
				((CModelObject*)pModel)->LoadElement( szPartsName, dwParts );
				_stprintf( lpszTemp, PARTSTEX_LOWER( nSex ), nSkinSet + 1 );
				pModel->ChangeTexture( PARTS_LOWER_BODY, TEX_PART_LOWER( nSex ), lpszTemp );
			}
			break;
		default:
#ifdef __WINGSFX
			if (bIfParts && pItemProp->dwItemKind3 != IK3_WINGSFX)
#else
			if (bIfParts)
#endif
				((CModelObject*)pModel)->LoadElement( szPartsName, dwParts );
			break;
		}
#endif // not WorldServer
	} // ÀåÂø.
	else
	// Å»Âø.
	{
		if( bIfParts )
		{
			if( pItemProp->dwExclusive != NULL_ID )
			{
				switch( pItemProp->dwExclusive )
				{
				case PARTS_UPPER_BODY:
					pModel->LoadElement( PARTSMESH_UPPER( nSex ), PARTS_UPPER_BODY );
					_stprintf( lpszTemp, PARTSTEX_UPPER( nSex ), nSkinSet + 1 );
					pModel->ChangeTexture( PARTS_UPPER_BODY, TEX_PART_UPPER( nSex ), lpszTemp );
					break;
				case PARTS_LOWER_BODY:
					pModel->LoadElement( PARTSMESH_LOWER( nSex ), PARTS_LOWER_BODY );
					_stprintf( lpszTemp, PARTSTEX_LOWER( nSex ), nSkinSet + 1 );
					pModel->ChangeTexture( PARTS_LOWER_BODY, TEX_PART_LOWER( nSex ), lpszTemp );
					break;
				case PARTS_HAND:
					pModel->LoadElement( PARTSMESH_HAND( nSex ), PARTS_HAND );
					break;
				case PARTS_FOOT:
					pModel->LoadElement( PARTSMESH_FOOT( nSex ), PARTS_FOOT );
					break;
				}
			}
		}
		//if( pInventory && pInventory->GetAt( MAX_INVENTORY + dwParts ) )
		if( pInventory && pInventory->GetEquip( dwParts ) )
		{
			//if( pInventory->UnEquip( MAX_INVENTORY + dwParts ) == FALSE )
			if( pInventory->UnEquip( dwParts ) == FALSE )
			{
#ifdef __WORLDSERVER
				if( TRUE == pMover->IsPlayer() )
					( (CUser*)pMover )->AddDefinedText(TID_GAME_LACKSPACE, "" );
#endif	// __WORLDSERVER				
				return FALSE;
			}
		}
		
		if( padwEquipment ) 
		{
			padwEquipment[ dwParts ] = NULL_ID;
			paEquipOption[ dwParts ] = 0;
		}

#ifndef __WORLDSERVER
		if( bIfParts )
		{
			switch( dwParts )
			{
			case PARTS_UPPER_BODY:
				pModel->LoadElement( PARTSMESH_UPPER( nSex ), PARTS_UPPER_BODY );
				_stprintf( lpszTemp, PARTSTEX_UPPER( nSex ), nSkinSet + 1 );
				pModel->ChangeTexture( PARTS_UPPER_BODY, TEX_PART_UPPER( nSex ), lpszTemp );
				break;
			case PARTS_LOWER_BODY:
				pModel->LoadElement( PARTSMESH_LOWER( nSex ), PARTS_LOWER_BODY );
				_stprintf( lpszTemp, PARTSTEX_LOWER( nSex ), nSkinSet + 1 );
				pModel->ChangeTexture( PARTS_LOWER_BODY, TEX_PART_LOWER( nSex ), lpszTemp );
				break;
			case PARTS_HAND:
				pModel->LoadElement( PARTSMESH_HAND( nSex ), PARTS_HAND );
				break;
			case PARTS_FOOT:
				pModel->LoadElement( PARTSMESH_FOOT( nSex ), PARTS_FOOT );
				break;
			}
		}
#endif
	} // Å»Âø
	return TRUE;
}
//}}AFX
#endif // 0


// ÀåÂø °¡´ÉÇÑ°¡¸¦ °Ë»ç.
#if __VER >= 11 // __SYS_IDENTIFY
BOOL CMover::IsEquipAble( CItemElem* pItem,BOOL bIgnoreLevel )
#else	// __SYS_IDENTIFY
BOOL CMover::IsEquipAble( ItemProp *pItemProp, OBJID dwObjid ,BOOL bIgnoreLevel )
#endif	// __SYS_IDENTIFY
{
#if __VER >= 11 // __SYS_IDENTIFY
	if( !pItem )
		return FALSE;
	ItemProp* pItemProp	= pItem->GetProp();
	OBJID dwObjid	= pItem->m_dwObjId;
#endif	// __SYS_IDENTIFY
#ifdef __SECURITY_FIXES
	if (!pItemProp)
		return FALSE;

	if (pItem->IsFlag(CItemElem::expired))
		return FALSE;
#endif // __SECURITY_FIXES
	// ºøÀÚ·ç·ù °Ë»ç.
	if( pItemProp->dwParts == PARTS_RIDE )
	{
		int nLimitLv = pItemProp->dwFlightLimit;
		if( nLimitLv == NULL_ID )
			nLimitLv = 1;
#ifdef __NOLIMIT_RIDE_ITEM
		if( pItemProp->dwID == II_RID_RID_STI_MAGIC01 )
			nLimitLv = 0;
#endif // __NOLIMIT_RIDE_ITEM
		
		CWorld* pWorld = GetWorld();
		if( pWorld )
		{
			int nAttr	= pWorld->GetHeightAttribute( GetPos().x, GetPos().z );
			
			if( GetFlightLv() < nLimitLv )		// ºñÇà·¹º§ÀÌ ¾ÈµÇ¸é ¸øÅº´Ù.
			{
#ifdef __WORLDSERVER
				if( TRUE == IsPlayer() )
					( (CUser*)this )->AddDefinedText( TID_GAME_USEAIRCRAFT, "" );	// Àá½Ã¸¸ ±â´Ù·ÁÁÖ¼¼¿ä.
#else // __WORLDSERVER
				g_WndMng.PutString( prj.GetText( TID_GAME_USEAIRCRAFT ), NULL, prj.GetTextColor( TID_GAME_USEAIRCRAFT ) );
#endif // __WORLDSERVER
				return FALSE;
			}
			
			if( !pWorld->m_bFly )
			{
#ifdef __WORLDSERVER
				( (CUser*)this )->AddDefinedText( TID_ERROR_NOFLY, "" );	// ºñÇà±ÝÁö±¸¿ªÀÔ´Ï´Ù.
#else // __WORLDSERVER
				g_WndMng.PutString( prj.GetText( TID_ERROR_NOFLY ), NULL, prj.GetTextColor( TID_ERROR_NOFLY ) );
#endif // __WORLDSERVER
				return FALSE;
			}

			if( HasBuffByIk3( IK3_TEXT_DISGUISE ) )
			{
#ifdef __WORLDSERVER
				( (CUser*)this )->AddDefinedText( TID_QUEST_DISQUISE_NOTFLY, "" );	// º¯½ÅÁß¿¡´Â ºñÇàÀ» ÇÒ¼ö ¾ø½À´Ï´Ù
#else // __WORLDSERVER
				g_WndMng.PutString( prj.GetText( TID_QUEST_DISQUISE_NOTFLY ), NULL, prj.GetTextColor( TID_QUEST_DISQUISE_NOTFLY ) );
#endif // __WORLDSERVER
				return FALSE;
			}
			
			// ÀåÂø ÀÌÀü¿¡ °Ë»çÇÏ¿©¾ß ÇÑ´Ù.
			if( nAttr == HATTR_NOFLY )		// ºñÇà±ÝÁö±¸¿ª¿¡¼± ¸øÅº´Ù.
				return FALSE;
			
		#ifdef __WORLDSERVER
#ifndef __MOUNT
			if (m_pActMover->IsState(OBJSTA_STAND) == FALSE)
				return FALSE;
#endif // __MOUNT
		#endif 
		}

#if __VER >= 8 // __S8_PK
#ifdef __WORLDSERVER
		if( IsChaotic() )
		{
			CHAO_PROPENSITY Propensity = prj.GetPropensityPenalty( GetPKPropensity() );
			if( !Propensity.nFly )
			{
				((CUser*)this)->AddDefinedText( TID_GAME_CHAOTIC_NOT_FLY );
				return FALSE;
			}
		}
#endif // __WORLDSERVER
#endif // __VER >= 8 // __S8_PK

#if __VER >= 9	// __PET_0410
#ifdef __WORLDSERVER
		if( HasActivatedEatPet() || HasActivatedSystemPet() )	// ÆêÀÌ ¼ÒÈ¯µÈ »óÅÂ¶ó¸é ºñÇà ºÒ°¡
		{
			( (CUser*)this )->AddDefinedText( TID_GAME_CANNOT_FLY_WITH_PET );
			return FALSE;
		}
#endif	// __WORLDSERVER
#endif	// __PET_0410
	}

	// ¹«±â·ù°¡ ¾Æ´Ñ°Í(¹æ¾î±¸)´Â ¼ºº°À» È®ÀÎÇÑ´Ù.
	{
		// ¼ºº° È®ÀÎ( ¹«±â´Â ºüÁü )
		if( pItemProp->dwItemSex != NULL_ID && pItemProp->dwItemSex != GetSex() )
		{
#ifdef __WORLDSERVER
			if( TRUE == IsPlayer() )
				( (CUser*)this )->AddDefinedText( TID_GAME_WRONGSEX, "\"%s\"", pItemProp->szName );
#endif	// __WORLDSERVER
			return FALSE;
		} // ¼ºº°
	}// ¹«±â
#ifdef __GAMEMASTER
	if (IsAuthHigher(AUTH_GAMEMASTER3))
		return TRUE;
#endif // __GAMEMASTER	
	// ¹æ¾î±¸ ÀÔÀ»¶§ Á÷¾÷È®ÀÎ.
	if( pItemProp->dwItemKind1 != IK1_WEAPON )
	{
		if( pItemProp->dwItemJob != NULL_ID && FALSE == IsInteriorityJob( pItemProp->dwItemJob ) ) {
#ifdef __WORLDSERVER
			if( TRUE == IsPlayer() )
				( (CUser*)this )->AddDefinedText( TID_GAME_WRONGJOB, "\"%s\"", pItemProp->szName );
#endif	// __WORLDSERVER
			return FALSE;
		}
	}

	// ¾ÆÀÌÅÛ ÇÊ¿äÁ÷¾÷°Ë»ç.
	if( pItemProp->dwItemKind1 == IK1_WEAPON )		// ¹«±â·ù¸¦ ÀåÂøÇÏ·ÁÇÒ¶§
	{
		if( pItemProp->dwItemJob != NULL_ID && FALSE == IsInteriorityJob( pItemProp->dwItemJob ) )	// ¾ÆÀÌÅÛ¿¡ ÇÊ¿äÁ÷¾÷ÀÌ ÁöÁ¤µÇ¾î ÀÖ°í
		{
#ifdef __WORLDSERVER
			if( TRUE == IsPlayer() )
				( (CUser*)this )->AddDefinedText( TID_GAME_WRONGJOB, "\"%s\"", pItemProp->szName );
#endif	// __WORLDSERVER
			return FALSE;
		}
	}

	if( !g_eLocal.GetState( EVE_SCHOOL ) && !bIgnoreLevel )
	{

		// ¾ÆÀÌÅÛ ÇÊ¿ä·¹º§ °Ë»ç.
		if( pItemProp->dwLimitLevel1 != 0xffffffff )	// ÇÊ¿ä·¹º§ÀÌ ÁöÁ¤µÇ¾î ÀÖ°í
		{
#if __VER >= 14 // __NEW_ITEM_LIMIT_LEVEL
			if( pItem->IsLimitLevel( this ) )	// ·¹º§ÀÌ ¾ÈµÇ¸é ¸øÂü.
#else // __NEW_ITEM_LIMIT_LEVEL
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#if __VER >= 11 // __SYS_IDENTIFY
#ifdef __NEWCLASS
			if (m_nLevel < pItem->GetLimitLevel() && !IsMaster() && !IsHero() && !IsLegendHero() && !IsLegendHeroUltimate())	// ·¹º§ÀÌ ¾ÈµÇ¸é ¸øÂü.		
#elif defined (__3RD_LEGEND16)
			if (m_nLevel < pItem->GetLimitLevel() && !IsMaster() && !IsHero() && !IsLegendHero())	// ·¹º§ÀÌ ¾ÈµÇ¸é ¸øÂü.		
#else // __3RD_LEGEND16
			if (m_nLevel < pItem->GetLimitLevel() && !IsMaster() && !IsHero())	// ·¹º§ÀÌ ¾ÈµÇ¸é ¸øÂü.				
#endif // __3RD_LEGEND16			
#else	// __SYS_IDENTIFY
#ifdef __NEWCLASS
			if ((m_nLevel < pItemProp->dwLimitLevel1) && !IsMaster() && !IsHero() && !IsLegendHero() && !IsLegendHeroUltimate())	// ·¹º§ÀÌ ¾ÈµÇ¸é ¸øÂü.				
#elif defined (__3RD_LEGEND16)
			if ((m_nLevel < pItemProp->dwLimitLevel1) && !IsMaster() && !IsHero() && !IsLegendHero())	// ·¹º§ÀÌ ¾ÈµÇ¸é ¸øÂü.				
#else // __3RD_LEGEND16
			if ((m_nLevel < pItemProp->dwLimitLevel1) && !IsMaster() && !IsHero())	// ·¹º§ÀÌ ¾ÈµÇ¸é ¸øÂü.				
#endif // __3RD_LEGEND16		
#endif	// __SYS_IDENTIFY
#else //__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			if( m_nLevel < pItemProp->dwLimitLevel1 )	// ¾ÆÀÌÅÛÀ» Âû ·¹º§ÀÌ ¾ÈµÇ¾úÀ¸¸é ¸øÂü.
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#endif // __NEW_ITEM_LIMIT_LEVEL
			{
#	ifdef __WORLDSERVER
				if( TRUE == IsPlayer() )
				{
#if __VER >= 11 // __SYS_IDENTIFY
					( (CUser*)this )->AddDefinedText( TID_GAME_REQLEVEL, "\"%d\"", pItem->GetLimitLevel() );
#else	// __SYS_IDENTIFY
					( (CUser*)this )->AddDefinedText( TID_GAME_REQLEVEL, "\"%d\"", pItemProp->dwLimitLevel1 );
#endif	// __SYS_IDENTIFY
				}
#	endif	// __WORLDSERVER
				return FALSE;
			}
		}
		// º¸¼®·ù¸¦ ÀåÂø
		if( pItemProp->dwItemKind2 == IK2_JEWELRY
#ifdef __SHARDS
			|| pItemProp->dwItemKind2 == IK2_RUNE
#endif // __SHARDS
			)
		{
			if( pItemProp->dwLimitLevel1 != 0xffffffff )	// Á¦ÇÑ·¹º§ÀÌ °É·ÁÀÖ°í
			{
#if __VER >= 14 // __NEW_ITEM_LIMIT_LEVEL
				if( pItem->IsLimitLevel( this ) )	// ·¹º§ÀÌ ¾ÈµÇ¸é ¸øÂü.
#else // __NEW_ITEM_LIMIT_LEVEL
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#if __VER >= 11 // __SYS_IDENTIFY
				if( m_nLevel < pItem->GetLimitLevel() && !IsMaster() && !IsHero()  )	// ·¹º§ÀÌ ¾ÈµÇ¸é ¸øÂü.				
#else	// __SYS_IDENTIFY
				if( ( m_nLevel < pItemProp->dwLimitLevel1 ) && !IsMaster() && !IsHero()  )	// ·¹º§ÀÌ ¾ÈµÇ¸é ¸øÂü.				
#endif	// __SYS_IDENTIFY
#else //__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
				if( m_nLevel < pItemProp->dwLimitLevel1 )	// ·¹º§ÀÌ ¾ÈµÇ¸é ¸øÂü.
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#endif // __NEW_ITEM_LIMIT_LEVEL
				{
#	ifdef __WORLDSERVER
					if( TRUE == IsPlayer() )
					{
#if __VER >= 11 // __SYS_IDENTIFY
						( (CUser*)this )->AddDefinedText( TID_GAME_REQLEVEL, "\"%d\"", pItem->GetLimitLevel() );
#else	// __SYS_IDENTIFY
						( (CUser*)this )->AddDefinedText( TID_GAME_REQLEVEL, "\"%d\"", pItemProp->dwLimitLevel1 );
#endif	// __SYS_IDENTIFY
					}
#	endif	// __WORLDSERVER
					return FALSE;
				}
			}
		}

	}
#if __VER < 8 // __S8_PK
	//Ä«¿À¿ë ¾ÆÀÌÅÛÀ» ¼±ÇÑÀÚ°¡ ÀåÂøÇÒ ¼ö ¾ø´Ù.
	if( (pItemProp->nEvildoing < 0) && IsChaotic() == FALSE )
	{
	#ifdef __WORLDSERVER
		if( IsPlayer() )
			( (CUser*)this )->AddDefinedText( TID_PK_ITEM_MESSAGE1 , "" );	// Ä«¿À ¾ÆÀÌÅÛÀº Ä«¿À»óÅÂ¿¡¼­¸¸...
	#endif	// __WORLDSERVER
			
		return FALSE;
	}
#endif // __VER < 8 // __S8_PK

	ItemProp *pHandItemProp	= NULL;
	
	// µé°íÀÖ´Â ¹«±â ÇÁ·ÎÆÛÆ¼ ²¨³¿.
	CItemElem *pItemElem = m_Inventory.GetEquip( PARTS_RWEAPON );		
	if( pItemElem )
		pHandItemProp = pItemElem->GetProp();

	// È­»ìÀ» Âø¿ëÇÏ·Á ÇßÀ»¶§ º¸¿ìÀÏ¶§¸¸ Âø¿ëµÅ¾ß ÇÔ
#ifdef __CROSSBOW
	if( pItemProp->dwItemKind3 == IK3_ARROW && ( pHandItemProp == NULL || ( pHandItemProp->dwItemKind3 != IK3_BOW && pHandItemProp->dwItemKind3 != IK3_CROSSBOW ) ))
		return FALSE;		
	if( pItemProp->dwItemKind3 == IK3_CROSSARROW && ( pHandItemProp == NULL || pHandItemProp->dwItemKind3 != IK3_CROSSBOW ))
		return FALSE;
#else // __CROSSBOW
	if( pItemProp->dwItemKind3 == IK3_ARROW && ( pHandItemProp == NULL || pHandItemProp->dwItemKind3 != IK3_BOW ) )
		return FALSE;	
#endif // __CROSSBOW
	return TRUE;
}

//
//
// pItemElemÀÌ ¹þ´Â°Ô °¡´ÉÇÑ°¡¸¦ °Ë»ç.
BOOL CMover::IsUnEquipAble( ItemProp *pItemProp )
{
	if( pItemProp->dwParts == PARTS_RIDE )
	{
		if( m_pActMover->IsSit() )	// ºøÀÚ·ç´Â ¾ÉÀº »óÅÂ¿¡¼­´Â Å»Âø ±ÝÁö
			return FALSE;

		if( GetWorld() )	// RedoEquip¿¡¼­ ºÒ·¶À»¶§ NULLÀÎ°æ¿ì ÀÖÀ½. NULLÀÌ¸é °Á ¹þ±è
		{
			int nAttr = GetWorld()->GetHeightAttribute( GetPos().x, GetPos().z );		// ÀÌµ¿ÇÒ À§Ä¡ÀÇ ¼Ó¼º ÀÐÀ½.
			// ºñÇà±ÝÁö or °È±â±ÝÁö or ÀÌµ¿±ÝÁö Áö¿ª¿¡¼­ ´Â ¸ø³»¸².
			if( (nAttr == HATTR_NOFLY || nAttr == HATTR_NOWALK || nAttr == HATTR_NOMOVE ) )		
				return FALSE;
		}
	}

	if( g_eLocal.GetState( EVE_SCHOOL ) && pItemProp->dwItemKind3 == IK3_CLOAK )
		return FALSE;
	
	return TRUE;
}

//
//
// Á¤»óÀûÀÎ ¾ÆÀÌÅÛ ÀåÂø, Å»Âø 
BOOL CMover::DoEquip( CItemElem* pItemElem, BOOL bEquip, int nPart )
{
#ifdef __SECURITY_FIXES
	if (!pItemElem || !pItemElem->GetProp())
		return FALSE;
#endif // __SECURITY_FIXES
	ItemProp* pItemProp = pItemElem->GetProp();
	
	if( IsDie() )	// Á×Àº »óÅÂ¿¡¼­´Â Àå/Å»Âø ±ÝÁö
	{
		return FALSE;
	}

	if( bEquip )
	{
		if( pItemProp->dwParts == PARTS_RIDE && m_Inventory.GetEquip( PARTS_RIDE ) )
			return FALSE;
		if( pItemProp->dwParts == PARTS_RIDE && pItemElem && pItemElem->IsFlag( CItemElem::expired ) )
			return FALSE;
#if __VER >= 11 // __SYS_IDENTIFY
		if( IsEquipAble( pItemElem ) == FALSE )
			return FALSE;
#else	// __SYS_IDENTIFY
		if( IsEquipAble( pItemProp, pItemElem->m_dwObjId ) == FALSE )
			return FALSE;
#endif	// __SYS_IDENTIFY
	}
	else
	{
		if( IsUnEquipAble( pItemProp ) == FALSE )
			return FALSE;
	}

	EQUIP_INFO equipInfo;
	equipInfo.dwId	= pItemElem->m_dwItemId;
	equipInfo.nOption	= pItemElem->GetAttrOption();
	equipInfo.byFlag	= pItemElem->m_byFlag;
	BOOL bResult = DoEquip( GetSex(), m_dwSkinSet, pItemElem, nPart, equipInfo, &m_Inventory, m_aEquipInfo, (CModelObject*)m_pModel, bEquip, this );
		
	if( !bResult )	// 2004/04/27
		return FALSE;

#ifndef __CLIENT
	if( bEquip )
	{
#ifdef 	__BLADELWEAPON0608	//	9th ºí·¹ÀÌµå ¾ç¼Õ¿¡ ¹«±â¸¦ Âø¿ë ½Ã Ãß°¡ ¿É¼ÇÀº ¿À¸¥¼Õ¿¡ µé°í ÀÖ´Â ¹«±âÀÇ °Í¸¸ Àû¿ëÀÌ µÇµµ·Ï ¼öÁ¤
		if( (pItemElem->m_dwObjIndex - m_Inventory.GetSize() ) != PARTS_LWEAPON  )	// equiped item
#endif	//__BLADELWEAPON0608	//	9th ºí·¹ÀÌµå ¾ç¼Õ¿¡ ¹«±â¸¦ Âø¿ë ½Ã Ãß°¡ ¿É¼ÇÀº ¿À¸¥¼Õ¿¡ µé°í ÀÖ´Â ¹«±âÀÇ °Í¸¸ Àû¿ëÀÌ µÇµµ·Ï ¼öÁ¤
			SetDestParamEquip( pItemProp, pItemElem );		// ÀåÂøÇÑ ÀåºñÀÇ DestParam¼³Á¤
#if __VER >= 14 // __EQUIP_BIND
		if( ( pItemProp->dwFlag & IP_FLAG_EQUIP_BIND ) && !pItemElem->IsFlag( CItemElem::binds ) )
		{
			pItemElem->SetFlag( CItemElem::binds );
			UpdateItem( (BYTE)( pItemElem->m_dwObjId ), UI_FLAG, MAKELONG( pItemElem->m_dwObjIndex, pItemElem->m_byFlag ) );
		}

#endif // __EQUIP_BIND
#ifdef __WINGSFX
		if (pItemProp->dwItemKind3 == IK3_WINGSFX)
		{
#ifdef __LOOKCHANGE					
			if (pItemElem && pItemElem->IsChangedLook())
			{
				ItemProp* pItemProp2 = prj.GetItemProp(pItemElem->GetLook());
				if (pItemProp2)
					SetWingSfx(pItemProp2->dwSfxObj2);
			}
			else
#endif //__LOOKCHANGE		
			{
				SetWingSfx(pItemProp->dwSfxObj2);
			}
			g_UserMng.AddChangeWingSfx(this);
		}
#endif //__WINGSFX
	}
	else
	if( bEquip == FALSE )
	{
#ifdef 	__BLADELWEAPON0608	//	9th ºí·¹ÀÌµå ¾ç¼Õ¿¡ ¹«±â¸¦ Âø¿ë ½Ã Ãß°¡ ¿É¼ÇÀº ¿À¸¥¼Õ¿¡ µé°í ÀÖ´Â ¹«±âÀÇ °Í¸¸ Àû¿ëÀÌ µÇµµ·Ï ¼öÁ¤
		if( (pItemElem->m_dwObjIndex - m_Inventory.GetSize() ) != PARTS_LWEAPON  )	// equiped item
#endif	//__BLADELWEAPON0608	//	9th ºí·¹ÀÌµå ¾ç¼Õ¿¡ ¹«±â¸¦ Âø¿ë ½Ã Ãß°¡ ¿É¼ÇÀº ¿À¸¥¼Õ¿¡ µé°í ÀÖ´Â ¹«±âÀÇ °Í¸¸ Àû¿ëÀÌ µÇµµ·Ï ¼öÁ¤
			ResetDestParamEquip( pItemProp, pItemElem );	// ÇØÁ¦ÇÏ´Â ÀåºñÀÇ DestParam¸®¼Â
		
		if( pItemProp->dwItemKind1 == IK1_WEAPON ) 
		{
			if( m_pActMover->IsStateFlag( OBJSTAF_COMBAT ) )
				SendActMsg( OBJMSG_MODE_PEACE );
		}
#ifdef __WINGSFX
		if (pItemProp->dwItemKind3 == IK3_WINGSFX)
		{
			SetWingSfx(NULL_ID);
			g_UserMng.AddChangeWingSfx(this);
		}
#endif

	}
#endif	// __CLIENT
#ifdef __ANI_WING
	if (pItemProp->dwParts == PARTS_MASK)
	{
		if (bEquip && pItemProp->dwItemKind3 == IK3_ANI_WING)
		{
			CModel* pModel = prj.m_modelMng.LoadModel(D3DDEVICE, OT_ITEM, pItemProp->dwID);

			CModelObject* pModelObject = (CModelObject*)pModel;
			CString strMotion = pModelObject->GetMotionFileName(_T("stand"));
			assert(strMotion != _T(""));
			pModelObject->LoadMotion(strMotion);
			SetMaskWing(pModel);
		}
		else
			SetMaskWing(NULL);
	}
#endif
	if( pItemProp->dwParts == PARTS_RIDE )
	{
		if( bEquip )
		{
#ifdef __CLIENT	
			if (IsPlayer())
			{
#ifdef __GAMEGUARD
				PlayMusic(BGM_TH_FLYING);
				if (g_WndMng.m_pWndWorld->m_bFirstFlying == FALSE)
					g_WndMng.m_pWndWorld->m_bFirstFlying = TRUE;
#else // __GAMEGUARD
				if (g_WndMng.m_pWndWorld->m_bFirstFlying == FALSE)
				{
					PlayMusic(BGM_TH_FLYING);
					g_WndMng.m_pWndWorld->m_bFirstFlying = TRUE;
				}
				else
				{
					PlayMusic(BGM_EV_LIGHTWING);
				}
#endif // __GAMEGUARD
				g_WndMng.m_bAutoRun = FALSE;
			}
#endif//__CLIENT			
#ifdef __MOUNT
			if (pItemProp->dwItemKind3 != IK3_MOUNT)
#endif // __MOUNT
			{
				SendActMsg(OBJMSG_MODE_FLY, pItemProp->dwID, 0, 1);
			}
#ifdef __MOUNT
			else
			{
				MOUNT_ANIMATION* pMount = prj.GetMountAnimation(pItemProp->dwID);
				if (pMount && (pMount->mType == MOUNT_WALK || pMount->mType == MOUNT_WALK_FLY || pMount->mType == MOUNT_FLY))
					SendActMsg(OBJMSG_MOUNT_GROUND_STAND, pItemProp->dwID, 0, 1);
				else
					SendActMsg(OBJMSG_MODE_FLY, pItemProp->dwID, 0, 1);
			}
#endif // __MOUNT
		}
		else
		{
			SendActMsg( OBJMSG_MODE_GROUND, 0, 0, 1 );
#ifdef __MOUNT
			SetRide(NULL);
			SetMount(NULL);
#endif // __MOUNT
		}
		ClearDest();	// 2004/04/30
		ClearDestAngle();
		memset( &m_CorrAction, 0, sizeof(CORR_ACTION) );
	}
#ifdef __LNB_ANIMATED_HATS
	else if (pItemProp->dwItemKind3 == IK3_ANIHAT)
	{
		if (bEquip)
			InitializeAnimatedHat(pItemProp->dwID);
		else
			SetAnimatedHat(nullptr);
	}
#endif
	// ¸ÁÅä ÀÔÀ»¶§ Ã³¸®.
	if( bEquip )
	{
		if( pItemProp->dwID == II_ARM_S_CLO_CLO_BLANK )		// ±æµåÀü¿ë ¹ÎÂ¥ ¸ÁÅä.
		{
			m_idGuildCloak = pItemElem->m_idGuild;			// ¸ÁÅä¿¡ ¹ÚÇôÀÖ´ø ±æµå¾ÆÀÌµð¸¦ ¹ÞÀ½.
#ifdef __XCLOAK
			m_pCloakTexture = g_GuildTexture.LoadGuildTexture( pItemElem->m_idGuild );
#endif
		} 
		else
		{
#ifdef __XCLOAK
			m_pCloakTexture = NULL;
			m_idGuildCloak = 0;			// ¸ÁÅä¿¡ ¹ÚÇôÀÖ´ø ±æµå¾ÆÀÌµð¸¦ ¹ÞÀ½.
#endif
		}
	}

	UpdateBoundBox();
	UpdateParam();

	return bResult;
}


#ifdef __CLIENT
// ÀåÂø½Ã dwItemIndex¸¸À» »ç¿ëÇÏ´Â ÀÌ Method´Â Fake ¾ÆÀÌÅÛÀ» À§ÇØ »ç¿ë 
// pModel¿¡ °ªÀÌ ÀÖ´Â °æ¿ì´Â Á» Æ¯º°ÇÑ °æ¿ì´Ù. ±× °æ¿ì´Â ÀåÂø/Å»Âø ÈÄ¿¡µµ ³»ºÎ ÀåÂø¿¡ °üÇÑ ¼¼ÆÃ¿¡ º¯°æÀÌ ¾ø°Ô µÈ´Ù.
BOOL CMover::DoFakeEquip( const EQUIP_INFO & rEquipInfo, BOOL bEquip, int nPart, CModelObject* pModel )
{
	BOOL bResult;
	if( pModel )
		bResult	= CMover::DoEquip( GetSex(), m_dwSkinSet, NULL, nPart, rEquipInfo, NULL, m_aEquipInfo, (CModelObject*)pModel, bEquip, this );
	else
		bResult = CMover::DoEquip( GetSex(), m_dwSkinSet, NULL, nPart, rEquipInfo, NULL, m_aEquipInfo, (CModelObject*)m_pModel, bEquip, this );

	if( !bResult )	// 2004/04/27
	{
		// Error( "DoFakeEquip() return FALSE" );
		return FALSE;
	}

	UpdateBoundBox();
	UpdateParam();

	ItemProp* pProp = prj.GetItemProp( rEquipInfo.dwId );
#ifndef __CLIENT
	if( pProp && pProp->dwItemKind1 >= IK2_WEAPON_DIRECT && pProp->dwItemKind1 <= IK2_WEAPON_MAGIC )
	{
		if( bEquip ) {
			if( !m_pActMover->IsStateFlag( OBJSTAF_COMBAT ) )
				SendActMsg( OBJMSG_MODE_COMBAT );
		}
		else {
			if( m_pActMover->IsStateFlag( OBJSTAF_COMBAT ) )
				SendActMsg( OBJMSG_MODE_PEACE );
		}
	}
#endif	// __CLIENT
	
	
	if( pProp->dwParts == PARTS_RIDE )
	{
		if( bEquip )
		{
#ifdef __MOUNT
			if (pProp->dwItemKind3 != IK3_MOUNT)
#endif // __MOUNT
			{
				SendActMsg(OBJMSG_MODE_FLY, pProp->dwID, 0, 1);
			}
#ifdef __MOUNT
			else
			{
				MOUNT_ANIMATION* pMount = prj.GetMountAnimation(pProp->dwID);
				if (pMount && (pMount->mType == MOUNT_WALK || pMount->mType == MOUNT_WALK_FLY || pMount->mType == MOUNT_FLY))
					SendActMsg(OBJMSG_MOUNT_GROUND_STAND, pProp->dwID, 0, 1);
				else
					SendActMsg(OBJMSG_MODE_FLY, pProp->dwID, 0, 1);
			}
#endif // __MOUNT
			ClearDest();
		}
		else
		{
			SendActMsg( OBJMSG_MODE_GROUND, 0, 0, 1 );
#ifdef __MOUNT
			SetRide(NULL);
			SetMount(NULL);
#endif // __MOUNT
			ClearDest();
		}
	}
	// ¸ÁÅä ÀÔÀ»¶§ Ã³¸®.
	if( bEquip )
	{
		if( pProp->dwID == II_ARM_S_CLO_CLO_BLANK )		// ±æµåÀü¿ë ¹ÎÂ¥ ¸ÁÅä.
		{
#ifdef __XCLOAK
			m_pCloakTexture = g_GuildTexture.LoadGuildTexture( m_idGuildCloak );
#endif
		} else
		{
#ifdef __XCLOAK
			m_pCloakTexture = NULL;
#endif
		}
	}

	return bResult;
}
#endif // CLIENT

void CMover::RedoEquip( BOOL fFakeParts, BOOL bDestParam )
{
	CItemElem* pItemElem = NULL;
	ItemProp* pItemProp	= NULL;
	BOOL bEquip;

	// ÀåÂøµÉ ¾ÆÀÌÅÛÀÇ ¼± Ã³¸® 
	for( int i = 0; i < MAX_HUMAN_PARTS; i++ )
	{
		bEquip	= fFakeParts? ( m_aEquipInfo[i].dwId != NULL_ID ) : ( m_Inventory.GetEquip( i ) != NULL );
		if( bEquip )
		{
			pItemElem = NULL;			pItemProp = NULL;
			
			// ÀåÂøµÈ ¾ÆÀÌÅÛÀÇ ÇÁ·ÎÆÛÆ¼ ²¨³¿.
			if( !fFakeParts )	// ÁøÂ¥ Àåºñ³Ä.
			{
				pItemElem	= m_Inventory.GetEquip( i );
				if( NULL != pItemElem )
					pItemProp	= pItemElem->GetProp();	

#ifdef __WORLDSERVER
#ifdef __TESTSERVER
				if( pItemProp )
				{
					if( pItemProp->dwParts == i || pItemProp->dwPartsub == i || 
						( pItemProp->dwParts == PARTS_RWEAPON && i == PARTS_LWEAPON ) )
					{
					}
					else
					{
						WriteError( "PARTS//%s//%d", GetName(), i );
						CItemElem itemElem;
						itemElem	= *pItemElem;
						RemoveItemId( pItemElem->m_dwObjId );
						AddItem( &itemElem );
						continue;
					}
				}
#endif	// __TESTSERVER
#endif	// __WORLDSERVER
#if defined(__WINGSFX) && defined(__WORLDSERVER)
				if (pItemProp)
				{
					if (pItemProp->dwItemKind3 == IK3_WINGSFX)
					{
#ifdef __LOOKCHANGE					
						if (pItemElem && pItemElem->IsChangedLook())
						{
							ItemProp* pItemProp2 = prj.GetItemProp(pItemElem->GetLook());
							if (pItemProp2)
								SetWingSfx(pItemProp2->dwSfxObj2);
						}
						else
#endif	
						{
							SetWingSfx(pItemProp->dwSfxObj2);
						}
						g_UserMng.AddChangeWingSfx(this);
					}
				}
#endif
			}
			else
			{
				pItemProp	= prj.GetItemProp( m_aEquipInfo[i].dwId );
			}

			
				
			if( ( pItemProp != NULL && pItemProp->dwID > 0 && 
				( pItemProp->dwParts == i || pItemProp->dwPartsub == i || 
				  (pItemProp->dwParts == PARTS_RWEAPON && i == PARTS_LWEAPON) )		// RWEAPONÀº LWEAPON°ú °°Àº°ÍÀ¸·Î Ä£´Ù.
				) &&
				( fFakeParts || m_Inventory.IsEquip( pItemElem->m_dwObjId ) ) )
			{
				// ºøÀÚ·ç¸¦ ÀåÂøÇÒ²«µ¥
				if( i == PARTS_RIDE )
				{
					if( FALSE == m_pActMover->IsFly() )	// ºñÇàÁßÀÌ ¾Æ´Ï¸é
					{
#ifdef __MOUNT
						if (pItemProp->dwItemKind3 != IK3_MOUNT)
#endif // __MOUNT
//						WriteLog( "RedoEquip(): OBJSTAF_FLY" );
						{
							SendActMsg(OBJMSG_MODE_FLY, pItemProp->dwID, 0, 1);	// ºñÇà¸ðµå·Î ÀüÈ¯
						}
#ifdef __MOUNT
						else
						{
							MOUNT_ANIMATION* pMount = prj.GetMountAnimation(pItemProp->dwID);
							if (pMount && (pMount->mType == MOUNT_WALK || pMount->mType == MOUNT_WALK_FLY || pMount->mType == MOUNT_FLY))
								SendActMsg(OBJMSG_MOUNT_GROUND_STAND, pItemProp->dwID, 0, 1);
							else
								SendActMsg(OBJMSG_MODE_FLY, pItemProp->dwID, 0, 1);
						}
#endif // __MOUNT
					}
					if (m_dwRideItemIdx == 0
#ifdef __MOUNT
						&& pItemProp->dwItemKind3 != IK3_MOUNT
#endif // __MOUNT
						)	// ºøÀÚ·ç ID°¡ ¾øÀ¸¸é
					{
//						WriteLog( "RedoEquip(): m_dwRideItemIdx	= pItemProp->dwID" );
						m_dwRideItemIdx	= pItemProp->dwID;	// °ª º¸Á¤.
					}
#ifdef __MOUNT
					if (pItemProp->dwItemKind3 == IK3_MOUNT && m_dwMountItemID == 0)
					{
						m_dwMountItemID = pItemProp->dwID;
					}
#endif // __MOUNT
				} 
#ifdef __ANI_WING
				if (i == PARTS_MASK)
				{
					if (pItemProp->dwItemKind3 == IK3_ANI_WING)
					{
						CModel* pModel = prj.m_modelMng.LoadModel(D3DDEVICE, OT_ITEM, pItemProp->dwID);

						CModelObject* pModelObject = (CModelObject*)pModel;
						CString strMotion = pModelObject->GetMotionFileName(_T("stand"));
						assert(strMotion != _T(""));
						pModelObject->LoadMotion(strMotion);
						SetMaskWing(pModel);
				}
					else
						m_pMask = NULL;
			}
#endif
				if( pItemProp->dwID == II_ARM_S_CLO_CLO_BLANK )		// ±æµåÀü¿ë ¹ÎÂ¥ ¸ÁÅä.
				{
					if( pItemElem )		// ¼­¹ö / Å¬¶ó(¾×Æ¼ºê¹«¹ö)
						m_idGuildCloak = pItemElem->m_idGuild;
 #ifdef __XCLOAK
					m_pCloakTexture = g_GuildTexture.LoadGuildTexture( m_idGuildCloak );
 #endif
				}
				if( pItemElem )
					m_aEquipInfo[i].nOption	= pItemElem->GetAttrOption();

				if( bDestParam )
				{
#ifdef 	__BLADELWEAPON0608	//	9th ºí·¹ÀÌµå ¾ç¼Õ¿¡ ¹«±â¸¦ Âø¿ë ½Ã Ãß°¡ ¿É¼ÇÀº ¿À¸¥¼Õ¿¡ µé°í ÀÖ´Â ¹«±âÀÇ °Í¸¸ Àû¿ëÀÌ µÇµµ·Ï ¼öÁ¤
					if( i != PARTS_LWEAPON )	// equiped item
#endif	//__BLADELWEAPON0608	//	9th ºí·¹ÀÌµå ¾ç¼Õ¿¡ ¹«±â¸¦ Âø¿ë ½Ã Ãß°¡ ¿É¼ÇÀº ¿À¸¥¼Õ¿¡ µé°í ÀÖ´Â ¹«±âÀÇ °Í¸¸ Àû¿ëÀÌ µÇµµ·Ï ¼öÁ¤
						SetDestParamEquip( pItemProp, pItemElem, TRUE );
#if __VER >= 9 // __ULTIMATE
					if( i == PARTS_RWEAPON )
						prj.m_UltimateWeapon.SetDestParamUltimate( this, pItemElem, TRUE, PARTS_RWEAPON );
#endif // __ULTIMATE
				}
			}
			else
			{
				//WriteLog( "RedoEquip(): Illegal dwParts, %s, %d", m_szName, i );
				m_aEquipInfo[i].dwId	= NULL_ID;
			}
		}
		else 
		{	// ÀåÂøµÉ°Ô ¾øÀ½.
			if( i == PARTS_RIDE )	// ºøÀÚ·ç°¡ ÀåÂøµÇ¾î ÀÖÁö ¾ÊÀºµ¥
			{
				if( m_pActMover->IsFly() )	// ºñÇàÁßÀÌ´Ù.
				{
//					WriteLog( "RedoEquip(): OBJSTAF_GROUND" );
					SendActMsg( OBJMSG_MODE_GROUND, 0, 0, 1 );	// ±×·¯¸é Áö»ó¸ðµå·Î º¯È¯ ½ÃÄÑ¾ßÁö.
				}
				if( m_dwRideItemIdx != 0 )		// ºøÀÚ·ç ÀÎµ¦½ºµµ 0ÀÌ¾î¾ß ÇÏ´Âµ¥ ¹º°¡ ÀÖ´Ù.
				{
//					WriteLog( "RedoEquip(): m_dwRideItemIdx	= 0" );
					m_dwRideItemIdx		= 0;	// ±×·¯¸é 0À¸·Î Å¬¸®¾î.
				}
#ifdef __MOUNT
				if (m_pActMover->IsUseMount())
					SendActMsg(OBJMSG_MODE_GROUND, 0, 0, 1);

				if (m_dwMountItemID != 0)
					m_dwMountItemID = 0;
#endif // __MOUNT
				if( m_Inventory.GetEquip( i ) )
				{
//					WriteLog( "RedoEquip(): pRide is not null" );
					m_Inventory.UnEquip( i );
				}
			}
		}
	}


	pItemElem	= m_Inventory.GetEquip( PARTS_RWEAPON );		// À§¿¡ ·çÇÁ¿¡¼­ ¸ðµçÆÄÃ÷¸¦ ÀÌ·¸°Ô ÀÏ°ýÀûÀ¸·Î ³Ö¾îµµ µÉµí ½Í´Ù.
	if( pItemElem )
	{
		m_aEquipInfo[PARTS_RWEAPON].nOption	= pItemElem->GetAttrOption();
	}
	pItemElem	= m_Inventory.GetEquip( PARTS_LWEAPON );
	if( pItemElem )
	{
		m_aEquipInfo[PARTS_LWEAPON].nOption	= pItemElem->GetAttrOption();
	}

	// ¾ÆÀÌÅÛÀÌ ½ÇÁ¦ ÀåÂø.
	UpdateParts( fFakeParts );

#ifdef __WORLDSERVER
	InvalidEquipOff( fFakeParts );		// ÀåÂøµÇ¾î¼³ ¾ÈµÉ Àåºñ°¡ ÀåÂøµÇ¾î ÀÖ´Ù¸é ¹þ±è
#endif

	if( bDestParam )
	{
		int nAbilityOption	= GetSetItem();
		if( nAbilityOption > 0 )
			SetSetItemAvail( nAbilityOption );

		
		SetDestParamSetItem( NULL );
	}
}

// ÀåÂøµÇ¾î¼³ ¾ÈµÉ Àåºñ°¡ ÀåÂøµÇ¾î ÀÖ´Ù¸é ¹þ±è
int	CMover::InvalidEquipOff( BOOL bFakeParts )
{
	CItemElem* pItemElem = NULL;
	ItemProp* pItemProp	= NULL;
	int		i;

	for( i = 0; i < MAX_HUMAN_PARTS; i ++ )
	{
		pItemElem = NULL;		
		pItemProp = NULL;

		// ÀåÂøµÈ ¾ÆÀÌÅÛÀÇ ÇÁ·ÎÆÛÆ¼ ²¨³¿.
		if( bFakeParts )	// Fake Àåºñ
		{
			if( m_aEquipInfo[i].dwId	== NULL_ID )	continue;
			pItemProp	= prj.GetItemProp( m_aEquipInfo[i].dwId );
		}
		else
		{
			pItemElem = m_Inventory.GetEquip( i );
			if( pItemElem )
				pItemProp  = pItemElem->GetProp();	
		}

		if( pItemProp == NULL )	
			continue;	// ÇÁ·ÎÆÛÆ¼ ¾øÀ¸¸é ½ÇÆÐ.

#if __VER >= 8 // __S8_PK
#if __VER >= 11 // __SYS_IDENTIFY
		if( IsEquipAble( pItemElem,TRUE ) == FALSE )	// ÀåÂøÇÒ ¼ö ¾ø´Â ¾ÆÀÌÅÛÀÌ´Ù.
#else	// __SYS_IDENTIFY
		if( IsEquipAble( pItemProp, pItemElem->m_dwObjId, TRUE ) == FALSE )	// ÀåÂøÇÒ ¼ö ¾ø´Â ¾ÆÀÌÅÛÀÌ´Ù.
#endif	// __SYS_IDENTIFY
#else	// __S8_PK
		if( IsEquipAble( pItemProp, pItemElem->m_dwObjId) == FALSE )	// ÀåÂøÇÒ ¼ö ¾ø´Â ¾ÆÀÌÅÛÀÌ´Ù.
#endif	// __S8_PK
		{
			if( pItemElem )
			{
				if( DoEquip( pItemElem, FALSE ) == FALSE )		// ¹þ±è.
				{
				#ifdef __WORLDSERVER
					// ¹þ±â´Âµ¥ ½ÇÆÐÇÔ. ÀÎº¥ÀÌ ²ËÃ¡´Ù°Å³ª ±âÅ¸µîµî ÀÌÀ¯
					#ifndef _DEBUG
						//Error( "Invalid Equipment Removed : %s", GetName() );
					#endif
				#endif
				}
			} 
		}
	} // for
	
	return FALSE;
}

void CMover::SetDestParamEquip( ItemProp* pItemProp, CItemElem* pItemElem, BOOL bIgnoreSetItem )
{
	if( pItemElem && pItemElem->IsFlag( CItemElem::expired ) )
		return;
#ifdef __WEAPON_RARITY
	BOOL bAdd = TRUE;
	if (pItemElem)
	{
		WeaponRarity* nWeaponRarity = prj.m_nWeaponRarity.GetAt(pItemElem->GetWeaponRarity());
		if (nWeaponRarity && pItemElem->GetWeaponRarity() > 0)
		{
			bAdd = FALSE;
			float fFactor = nWeaponRarity->m_fStatsRate;
#if __VER >= 19
			for (int i = 0; i < 6; i++)
#elif defined(__PROP_0827)
			for (int i = 0; i < 3; i++)
#else // __VER >= 19
			for (int i = 0; i < 2; i++)
#endif // __VER >= 19
			{
				if (pItemProp->dwDestParam[i] != -1)
					SetDestParam(pItemElem->GetProp()->dwDestParam[i], (int)((pItemElem->GetProp()->nAdjParamVal[i]) * fFactor), NULL_CHGPARAM);
			}
		}
	}
#endif // __WEAPON_RARITY
#ifdef __WORLDSERVER
	RunItemScript( this, pItemProp->dwID, ITEM_OP_EQUIP, NULL );
#endif // __WORLDSERVER
#ifdef __WEAPON_RARITY
	if (bAdd)
#endif // __WEAPON_RARITY
	{
	if( pItemProp->dwDestParam[0] != -1 )
		SetDestParam( 0, pItemProp, 1 );
	if( pItemProp->dwDestParam[1] != -1 )
		SetDestParam( 1, pItemProp );
#ifdef __PROP_0827
	if( pItemProp->dwDestParam[2] != -1 )
		SetDestParam( 2, pItemProp );
#endif	// __PROP_0827
#if __VER >= 19
		if (pItemProp->dwDestParam[3] != -1)
			SetDestParam(3, pItemProp);
		if (pItemProp->dwDestParam[4] != -1)
			SetDestParam(4, pItemProp);
		if (pItemProp->dwDestParam[5] != -1)
			SetDestParam(5, pItemProp);
#endif
	}
	
	// ¿ø¼Òº° ¼Ó¼ºÀÌ ºÙÀº ¾ÆÀÌÅÛÀÏ°æ¿ì ¼¼ÆÃÇÔ.
	
	// ¹æ¾î±¸ÀÌ°í ¼Ó¼º¿É¼Ç°ªÀÌ ÀÖÀ¸¸é...
	if( pItemElem && pItemElem->m_nResistAbilityOption && pItemElem->GetProp()->dwItemKind1 == IK1_ARMOR )
	{
		if( pItemElem->m_bItemResist != SAI79::NO_PROP )
		{
			int nStrong = GetStrongDST( pItemElem->m_bItemResist );
			int nWeak   = GetWeakDST( pItemElem->m_bItemResist );

			SetDestParam( nWeak,  -pItemElem->m_nResistAbilityOption*2, NULL_CHGPARAM );
			SetDestParam( nStrong, pItemElem->m_nResistAbilityOption*2, NULL_CHGPARAM );
		}
	}
	else
	{
		if( pItemProp->nItemResistElecricity )
			SetDestParam( DST_RESIST_ELECTRICITY, pItemProp->nItemResistElecricity, NULL_CHGPARAM );
		if( pItemProp->nItemResistFire )
			SetDestParam( DST_RESIST_FIRE, pItemProp->nItemResistFire, NULL_CHGPARAM );
		if( pItemProp->nItemResistWind )
			SetDestParam( DST_RESIST_WIND, pItemProp->nItemResistWind, NULL_CHGPARAM );
		if( pItemProp->nItemResistWater )
			SetDestParam( DST_RESIST_WATER, pItemProp->nItemResistWater, NULL_CHGPARAM );
		if( pItemProp->nItemResistEarth )
			SetDestParam( DST_RESIST_EARTH, pItemProp->nItemResistEarth, NULL_CHGPARAM );
	}

#if __VER >= 11 // __SYS_COLLECTING
	CAccessoryProperty* pProperty	= CAccessoryProperty::GetInstance();
	if( pItemElem && pItemElem->IsAccessory() )		// ¾×¼¼¼­¸®
	{
		vector<SINGLE_DST>* pDst	= pProperty->GetDst( pItemElem->m_dwItemId, pItemElem->GetAbilityOption() );
		for( DWORD i = 0; i < pDst->size(); i++ )
			SetDestParam( (*pDst)[i].nDst, (*pDst)[i].nAdj, NULL_CHGPARAM );
	}
#endif	// __SYS_COLLECTING

#ifdef __WORLDSERVER
#ifdef __DST_GIFTBOX
	if( pItemProp->dwDestParam[0] == DST_GIFTBOX || pItemProp->dwDestParam[1] == DST_GIFTBOX || pItemProp->dwDestParam[2] == DST_GIFTBOX )
		static_cast<CUser*>( this )->AddBuff( BUFF_EQUIP, (WORD)( pItemProp->dwID ), 1, 999999999 );
#endif // __DST_GIFTBOX
#endif // __WORLDSERVER

	if( !bIgnoreSetItem )
	{
		if( pItemElem )
		{
			int nAbilityOption	= GetSetItem( pItemElem );
			if( nAbilityOption > 0 )
				SetSetItemAvail( nAbilityOption );
			SetDestParamSetItem( pItemElem );
		}
	}

	if( pItemElem && !pItemElem->IsFlag( CItemElem::expired ) )
	{
		DestParamPiercingAvail( pItemElem, TRUE );
		SetDestParamRandomOpt( pItemElem );
	}
}

void CMover::ResetDestParamEquip( ItemProp* pItemProp, CItemElem* pItemElem )
{
	if( pItemElem && pItemElem->IsFlag( CItemElem::expired ) )
		return;
#ifdef __WEAPON_RARITY
	BOOL bAdd = TRUE;
	if (pItemElem)
	{
		WeaponRarity* nWeaponRarity = prj.m_nWeaponRarity.GetAt(pItemElem->GetWeaponRarity());
		if (nWeaponRarity && pItemElem->GetWeaponRarity() > 0)
		{
			bAdd = FALSE;
			float fFactor = nWeaponRarity->m_fStatsRate;
#if __VER >= 19
			for (int i = 0; i < 6; i++)
#elif defined(__PROP_0827)
			for (int i = 0; i < 3; i++)
#else // __VER >= 19
			for (int i = 0; i < 2; i++)
#endif // __VER >= 19
			{
				if (pItemProp->dwDestParam[i] != -1)
					ResetDestParam(pItemElem->GetProp()->dwDestParam[i], (int)((pItemElem->GetProp()->nAdjParamVal[i]) * fFactor));
			}
		}
	}
#endif // __WEAPON_RARITY
#ifdef __WORLDSERVER
	RunItemScript( this, pItemProp->dwID, ITEM_OP_UNEQUIP, NULL );
#endif // __WORLDSERVER
#ifdef __WEAPON_RARITY
	if (bAdd)
#endif // __WEAPON_RARITY
	{
	if( pItemProp->dwDestParam1 != -1 )
		ResetDestParam( pItemProp->dwDestParam1, pItemProp->nAdjParamVal1 );
	if( pItemProp->dwDestParam2 != -1 )
		ResetDestParam( pItemProp->dwDestParam2, pItemProp->nAdjParamVal2 );
#ifdef __PROP_0827
	if( pItemProp->dwDestParam3 != -1 )
		ResetDestParam( pItemProp->dwDestParam3, pItemProp->nAdjParamVal3 );
#endif	// __PROP_0827
#if __VER >= 19
		if (pItemProp->dwDestParam4 != -1)
			ResetDestParam(pItemProp->dwDestParam4, pItemProp->nAdjParamVal4);
		if (pItemProp->dwDestParam5 != -1)
			ResetDestParam(pItemProp->dwDestParam5, pItemProp->nAdjParamVal5);
		if (pItemProp->dwDestParam6 != -1)
			ResetDestParam(pItemProp->dwDestParam6, pItemProp->nAdjParamVal6);
#endif
	}
	
	if( pItemElem && pItemElem->m_nResistAbilityOption && pItemElem->GetProp()->dwItemKind1 == IK1_ARMOR )
	{
		if( pItemElem->m_bItemResist != SAI79::NO_PROP )
		{
			int nSelf   = GetSelfDST( pItemElem->m_bItemResist );
			int nStrong = GetStrongDST( pItemElem->m_bItemResist );
			int nWeak   = GetWeakDST( pItemElem->m_bItemResist );

			if( ::GetLanguage() == LANG_THA )			
			{
				float fResult = ((float)pItemElem->m_nResistAbilityOption+1.2f) * (0.7f+(float)(pItemElem->m_nResistAbilityOption*0.01f));
				int nResult = (int)( fResult * fResult );

				ResetDestParam( nSelf,   nResult );
				ResetDestParam( nWeak,  -nResult/2 );
				ResetDestParam( nStrong, nResult/2 );
			}
			else
			{
				ResetDestParam( nWeak,  -pItemElem->m_nResistAbilityOption*2 );
				ResetDestParam( nStrong, pItemElem->m_nResistAbilityOption*2 );
			}
		}
	} 
	else
	{	
		if( pItemProp->nItemResistElecricity )
			ResetDestParam( DST_RESIST_ELECTRICITY, pItemProp->nItemResistElecricity);
		if( pItemProp->nItemResistFire )
			ResetDestParam( DST_RESIST_FIRE, pItemProp->nItemResistFire );
		if( pItemProp->nItemResistWind )
			ResetDestParam( DST_RESIST_WIND, pItemProp->nItemResistWind );
		if( pItemProp->nItemResistWater )
			ResetDestParam( DST_RESIST_WATER, pItemProp->nItemResistWater );
		if( pItemProp->nItemResistEarth )
			ResetDestParam( DST_RESIST_EARTH, pItemProp->nItemResistEarth );
	}

	if( pItemElem )
	{
#if __VER >= 11 // __SYS_COLLECTING
		CAccessoryProperty* pProperty	= CAccessoryProperty::GetInstance();
		if( pItemElem->IsAccessory() )		// ¾×¼¼¼­¸®
		{
			vector<SINGLE_DST>* pDst	= pProperty->GetDst( pItemElem->m_dwItemId, pItemElem->GetAbilityOption() );
			for( DWORD i = 0; i < pDst->size(); i++ )
				ResetDestParam( (*pDst)[i].nDst, (*pDst)[i].nAdj );
		}
#endif	// __SYS_COLLECTING

#ifdef __WORLDSERVER
#ifdef __DST_GIFTBOX
		if( pItemProp->dwDestParam[0] == DST_GIFTBOX || pItemProp->dwDestParam[1] == DST_GIFTBOX || pItemProp->dwDestParam[2] == DST_GIFTBOX )
		{
			((CUser*)this)->RemoveBuff( BUFF_EQUIP, (WORD)( pItemProp->dwID ) );
		}
#endif // __DST_GIFTBOX
#endif // __WORLDSERVER

		int nAbilityOption	= GetSetItem( pItemElem );
		if( nAbilityOption > 0 )
			ResetSetItemAvail( nAbilityOption );
		DestParamPiercingAvail( pItemElem, FALSE );
		ResetDestParamSetItem( pItemElem );
		ResetDestParamRandomOpt( pItemElem );
	}
}


// µ·È¹µæ 	
void CMover::PickupGold( int nGold, BOOL bDropMob )
{
	ASSERT( nGold > 0 );
	if( nGold <= 0 )
	{
		Error( "%s PickupGold - %d", GetName(), nGold );
		return;
	}

#ifdef __WORLDSERVER
	CParty *pParty	= g_PartyMng.GetParty( m_idparty );
	if( pParty && pParty->IsMember( m_idPlayer ) && bDropMob )	// ÆÄÆ¼°¡ ÀÖ°í ¸÷ÀÌ ¶³±º µ·¸¸ ºÐ¹èµÈ´Ù.
	{
		// ÆÄÆ¼°¡ ÀÖ´Â »óÅÂ¿¡¼­ µ·À» ÁýÀ¸·Á¸é µ·ÀÌ ºÐ¹èµÈ´Ù.
		// ¸ó½ºÅÍ°¡ µå·ÓÇÑµ·¸¸ ºÐ¹èµÇ¾î¾ß ÇÑ´Ù.
		int nNumInsideMember = 1;		// µ· ÁÝ´Â»ç¶÷ Áß½ÉÀ¸·Î ¹Ý°æ xx¹ÌÅÍ ÀÌ³»ÀÖ´Â»ç¶÷ÀÌ ¸î¸íÀÌ³ª µÇ´ÂÁö °Ë»ç. 
		CUser *pListMember[MAX_PTMEMBER_SIZE];
		int	nMaxListMember = 0;
		CUser* pMember	= NULL;
		int i;
//		float fDist;
		D3DXVECTOR3	vDist;

		// µ·ÁÝ´Â»ç¶÷ ¹Ý°æ¾È¿¡ µå´Â ¸â¹öµé¸¸ Ãß·Á³½´Ù.
		memset( pListMember, 0, sizeof(pListMember) );
		for( i = 0; i < pParty->m_nSizeofMember; i++ )
		{
			pMember	= g_UserMng.GetUserByPlayerID( pParty->m_aMember[i].m_uPlayerId );
			/*
			if( IsValidObj( pMember ) )
			{
				vDist = pMember->GetPos() - GetPos();
				fDist = D3DXVec3LengthSq( &vDist );		// µ· ÁÝ´Â»ç¶÷°ú ¸â¹ö°£ÀÇ °Å¸®.
				if( fDist < 32.0f * 32.0f )				// xx¹ÌÅÍº¸´Ù ÀÛÀ¸¸é
				{
					pListMember[ nMaxListMember++ ] = pMember;
				}
			}
			*/ //2009.01.21 // ¹Ý°æ °Ë»ç¿¡ ·¹ÀÌ¾î Ãß°¡
			if( IsValidArea( pMember, 32.0f ) )
				pListMember[ nMaxListMember++ ] = pMember;
		}

		if( nMaxListMember > 0 )
		{
			int nShare = nGold / nMaxListMember;		// ¸â¹ö °¢°¢ÀÇ ¸ò
			int nRest  = nGold % nMaxListMember;		// ³ª´©°í³­ ÈÄ ³ª¸ÓÁö.
			if( nShare )	// ¸òÀÌ ÀÖÀ»¶§.
			{
				for( i = 0; i < nMaxListMember; i++ )
				{
					pMember = pListMember[i];
					pMember->PickupGoldCore( nShare );
				}
			}

			// ³ª¸ÓÁö´Â ·£´ýÀ¸·Î ÇÑ»ç¶÷ÀÌ °¡Áü.
			if( nRest )
			{
				pMember = pListMember[ random(nMaxListMember) ];	
				pMember->PickupGoldCore( nRest );
			}
		}
		else
		{
			FILEOUT( "..\\PartyError.txt", "party pick money error:%s %d %d", GetName(), pParty->m_nSizeofMember, nMaxListMember );
			for( i = 0; i < pParty->m_nSizeofMember; i ++ )
			{
				pMember		= g_UserMng.GetUserByPlayerID( pParty->m_aMember[i].m_uPlayerId );
				if( IsValidObj( pMember ) )
				{
					FILEOUT( "..\\PartyError.txt", "%d %s", i, pMember->GetName() );
				}
			}
		}
	} 
	else
#endif // WORLDSERVER	
	{
		// ÆÄÆ¼ ¾øÀ»¶§
		PickupGoldCore( nGold );
	}
}


void CMover::PickupGoldCore( int nGold )
{
	if( AddGold( nGold ) == FALSE )
		return;

#ifdef __WORLDSERVER
	if( IsPlayer() )
	{
		((CUser*)this)->AddGoldText( nGold );
		if( nGold >= 500 )
		{
			LogItemInfo aLogItem;
			aLogItem.Action = "R";
			aLogItem.SendName = "GROUND";
			aLogItem.RecvName = GetName();
			aLogItem.WorldId = GetWorld()->GetID();
			aLogItem.Gold = GetGold() - nGold;
			aLogItem.Gold2 = GetGold();
			//aLogItem.ItemName = "SEED";
			_stprintf( aLogItem.szItemName, "%d", II_GOLD_SEED1 );
			aLogItem.itemNumber = nGold;
			g_DPSrvr.OnLogItem( aLogItem );
		}										
	}
#endif	// __WORLDSERVER
}


#ifdef __WORLDSERVER
// µ·À» ¶¥¿¡ ¶³±º´Ù.  bPK - PK´çÇÑ °æ¿ì 
CItem* CMover::DropGold( DWORD dwGold, const D3DXVECTOR3& vPos, BOOL bPK )
{
	if( IsDropableState( bPK ) == FALSE )
		return NULL;

	CWorld *pWorld = GetWorld();

	int nGold	= (int)dwGold;
	if( nGold > 0 && nGold <= (int)GetGold() )
	{
		if( nGold >= 500 )
		{
			LogItemInfo aLogItem;
			aLogItem.Action = "D";
			aLogItem.SendName = GetName();
			aLogItem.RecvName = "GROUND";	// ¶¥¿¡ ¹ö¸°°Í
			aLogItem.WorldId = pWorld->GetID();
			aLogItem.Gold = GetGold();
			aLogItem.Gold2 = GetGold() - nGold;
			//aLogItem.ItemName = "SEED";
			_stprintf( aLogItem.szItemName, "%d", II_GOLD_SEED1 );
			aLogItem.itemNumber = nGold;
			g_DPSrvr.OnLogItem( aLogItem );
		}

		AddGold( -nGold );

		CItemElem* pItemElem	= new CItemElem;
		
		if( nGold <= (int)prj.GetItemProp( II_GOLD_SEED1 )->dwAbilityMax )
			pItemElem->m_dwItemId	= II_GOLD_SEED1;
		else if( nGold <= (int)prj.GetItemProp( II_GOLD_SEED2 )->dwAbilityMax )
			pItemElem->m_dwItemId	= II_GOLD_SEED2;
		else if( nGold <= (int)prj.GetItemProp( II_GOLD_SEED3 )->dwAbilityMax )
			pItemElem->m_dwItemId	= II_GOLD_SEED3;
		else
			pItemElem->m_dwItemId	= II_GOLD_SEED4;

		pItemElem->m_nItemNum	= (short)nGold;				// __NPP_050308 ÀÌÈÄ¿¡´Â »ç¿ëÇÏÁö ¾ÊÀ» °Í
		pItemElem->m_nHitPoint  = nGold;					// intÇüÀ¸·Î µ·À» ¹ö¸®°Ô ÇÏ±â À§ÇØ¼­ ÀÌ º¯¼ö¸¦ »ç¿ë 

		CItem* pItem	= new CItem;
		pItem->m_pItemBase	= pItemElem;
		pItem->SetIndex( D3DDEVICE, pItemElem->m_dwItemId );
		pItem->SetPos( vPos );
		pItem->SetAngle( (float)xRandom( 360 ) );
		pItem->m_dwDropTime		= timeGetTime();	
		pWorld->ADDOBJ( pItem, TRUE, GetLayer() );
		return pItem;
	}
	
	return NULL;
}
#endif // __WORLDSERVER

/*
#ifdef __NEWITEM0624
BOOL CMover::RemoveEquipedItem( int nParts )
{
	CItemElem* pItemElem	= GetEquipItem( nParts );
	if( pItemElem )
	{
#ifdef __WORLDSERVER
		ItemProp* pItemProp		= pItemElem->GetProp();
		ResetDestParamEquip( pItemProp, pItemElem );
		( (CModelObject*)m_pModel )->TakeOffParts( nParts );
		UpdateBoundBox();
		UpdateParam();
		g_UserMng.AddRemoveItemAtId( this, pItemElem->m_dwObjId );
#endif	// __WORLDSERVER
		m_Inventory.RemoveAtId( pItemElem->m_dwObjId );
		return TRUE;
	}
	return FALSE;
}

#ifdef __WORLDSERVER
BOOL CMover::DropEquipedItem( int nParts )
{
	if( !GetWorld() )
		return FALSE;

	CItemElem* pItemElem	= GetEquipItem( nParts );
	if( pItemElem )
	{
		ItemProp* pItemProp		= pItemElem->GetProp();
		ResetDestParamEquip( pItemProp, pItemElem );
		CItem* pItem	= new CItem;
		pItem->m_pItemBase	= new CItemElem;
		*pItem->m_pItemBase		= *pItemElem;
		pItem->SetIndex( D3DDEVICE, pItemElem->m_dwItemId );
		pItem->SetPos( GetPos() );
		pItem->SetAngle( xRandom( 360 ) );
		GetWorld()->AddObj( pItem, TRUE );
		g_UserMng.AddRemoveItemAtId( this, pItemElem->m_dwObjId );
		m_Inventory.RemoveAtId( pItemElem->m_dwObjId );
		return TRUE;
	}
	return FALSE;
}
#endif	// __WORLDSERVER
#endif	// __NEWITEM0624
*/


#ifdef __CLIENT
BOOL CMover::GetEquipFlag( int nParts, BYTE* pbyFlag )
{
	if( IsActiveMover() )
	{
		CItemElem* pItemElem	= GetEquipItem( nParts );
		if( pItemElem )
		{
			*pbyFlag	= pItemElem->m_byFlag;
			return TRUE;
		}
		return FALSE;
	}
	else
	{
		if( nParts < 0 || nParts >= MAX_HUMAN_PARTS )
			return FALSE;

		if( m_aEquipInfo[nParts].dwId != NULL_ID )
		{
			*pbyFlag	= m_aEquipInfo[nParts].byFlag;
			return TRUE;
		}
		return FALSE;
	}
}
#endif	// __CLIENT


// Àåºñ¸¦ Àå/Å»ÂøÇÑ´Ù.
// pItemElem - ÀåÂø/Å»Âø ÇÒ ¾ÆÀÌÅÛ
// bEquip - TRUE ÀåÂø
// nPart - ÆÄÃ÷¹øÈ£ 
void CMover::EquipItem( CItemElem *pItemElem, BOOL bEquip, int nPart )
{
	if( m_pActMover && m_pActMover->IsActAttack() )
		return;

	if( DoEquip( pItemElem, bEquip, nPart ) )
	{
	#ifdef __WORLDSERVER
		g_UserMng.AddDoEquip( this, nPart, pItemElem, bEquip );
		if( pItemElem->GetProp()->dwParts == PARTS_RIDE && pItemElem->GetProp()->dwItemJob == JOB_VAGRANT && bEquip == FALSE )
//			( ( pItemElem->m_dwItemId == II_RID_RID_BOR_EVEINSHOVER || pItemElem->m_dwItemId == II_RID_RID_BOR_LADOLF ) && bEquip == FALSE )
			RemoveItem( (BYTE)( pItemElem->m_dwObjId ), pItemElem->m_nItemNum );
	#endif // __WORLDSERVER
	}
}

// Å» °Í¿¡¼­ ³»¸°´Ù.
void CMover::UnequipRide()
{
	if( IsPlayer() )
	{
		CItemElem* pItemElem = GetEquipItem( PARTS_RIDE );
		if( pItemElem )
			EquipItem( pItemElem, FALSE, -1 );	// -1 ÆÄÃ÷¹øÈ£ 
#ifdef __MOUNT
		SetRide(NULL);
		SetMount(NULL);
#endif // __MOUNT
	}
}


// Àåºñ¾ÆÀÌÅÛÀ» »ç¿ëÇÑ´Ù.( ÀåÂø -> Å»Âø, Å»Âø -> ÀåÂø )
// ÁÖÀÇ: pItemElemÀº IsUsableItemÀ¸·Î °Ë»çµÈ »óÅÂ¶ó°í °¡Á¤ÇÑ´Ù.
BOOL CMover::DoUseEquipmentItem( CItemElem* pItemElem, DWORD dwId, int nPart )
{ 
#ifdef __WORLDSERVER
	BOOL bEquip	= !m_Inventory.IsEquip( dwId );	// equip
	if( bEquip && IsItemRedyTime( pItemElem->GetProp(), pItemElem->m_dwObjId, TRUE ) == FALSE )
		return FALSE;

	// chipi_090731 - Å¬¶óÀÌ¾ðÆ® º¯Á¶½Ã ¹®Á¦ ¹ß»ý
	ItemProp* pItemProp = pItemElem->GetProp();
	if( !pItemProp )
		return FALSE;
		
#ifdef __GAMEGUARD
	if (pItemProp->dwParts != nPart && nPart >= 0)
#else // __GAMEGUARD
	if (pItemProp->dwParts != nPart && nPart != -1)
#endif // __GAMEGUARD
	{
		CItemElem* pTempElem = m_Inventory.GetAt( MAX_INVENTORY + nPart );
		if( !pTempElem || pTempElem->GetProp()->dwParts != pItemProp->dwParts )
			return FALSE;
	}
	// END chipi_090731 - Å¬¶óÀÌ¾ðÆ® º¯Á¶½Ã ¹®Á¦ ¹ß»ý

	EquipItem( pItemElem, bEquip, nPart );

#ifdef __GAMEGUARD
#ifdef __NO_HP_DMG_LIMIT
	long long nHitPoint = GetHitPoint();
	long long nMaxHitPoint = GetMaxHitPoint();
#else
	int nHitPoint = GetHitPoint();
	int nMaxHitPoint = GetMaxHitPoint();
#endif
	int nManaPoint = GetManaPoint();
	int nMaxManaPoint = GetMaxManaPoint();
	int nFatiguePoint = GetFatiguePoint();
	int nMaxFatiguePoint = GetMaxFatiguePoint();

	if (nHitPoint > nMaxHitPoint)
		SetPointParam(DST_HP, nMaxHitPoint);
	if (nManaPoint > nMaxManaPoint)
		SetPointParam(DST_MP, nMaxManaPoint);
	if (nFatiguePoint > nMaxFatiguePoint)
		SetPointParam(DST_FP, nMaxFatiguePoint);
#endif // __GAMEGUARD
#endif // __WORLDSERVER

	return TRUE;
}

void CMover::ClearEquipInfo()
{
	memset( m_aEquipInfo, 0, sizeof(EQUIP_INFO) * MAX_HUMAN_PARTS );
	for( int i = 0; i < MAX_HUMAN_PARTS; i++ )
		m_aEquipInfo[i].dwId = NULL_ID;
}
```
