# Ctrl.cpp

Chemin original: `C:\Users\rdiff\Desktop\__NEWCLASS\_AIInterface\Ctrl.cpp`
Chemin relatif: `_AIInterface\Ctrl.cpp`
Nom du fichier: `Ctrl.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `cp1252`

```cpp
// Ctrl.cpp: implementation of the CCtrl class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "defineSkill.h"
#include "defineObj.h"
#include "defineText.h"
#include "ResData.h"
#ifdef __WORLDSERVER
#include "CtrlObjs.h"
#endif
#include "Ship.h"

#ifdef __CLIENT
#include "DPClient.h"
extern	CDPClient	g_DPlay;
#endif  

#ifdef __WORLDSERVER
#include "user.h"
#include "dpcoreclient.h"
#include "dpsrvr.h"

#ifdef __WORLDSERVER
 extern	CUserMng	g_UserMng;
 extern	CDPCoreClient	g_DPCoreClient;
 extern	CDPSrvr		g_DPSrvr;
 #include "Party.h"
 extern	CPartyMng	g_PartyMng;
 #include "dpDatabaseClient.h"
 extern	CDPDatabaseClient	g_dpDBClient;
#endif // Worldserver
#endif

#include "commonctrl.h"

extern map< string, DWORD > g_MapStrToObjId;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCtrl::CCtrl()
{
	m_dwType = OT_CTRL;
	m_objid	 = NULL_ID;

#ifdef __WORLDSERVER
	m_lRespawn	= -1;
	m_nRespawnType = 0;

	memset( m_nOldCenter, 0, sizeof(int) * MAX_LINKLEVEL );
#endif	// __WORLDSERVER

	m_pIAObjLink = NULL;
	D3DXMatrixIdentity( &m_mInvTM );
}

CCtrl::~CCtrl()
{
#ifdef __WORLDSERVER
	if( IsVirtual() )
		return;

	RemoveItFromView();
#endif	// __WORLDSERVER

	RemoveItFromGlobalId();
}

void CCtrl::Process()
{
	CObj::Process();
#ifdef __WORLDSERVER
	ProcessDeleteRespawn();
#endif
}

void CCtrl::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	CObj::Render( pd3dDevice );
}

BOOL CCtrl::Read( CFileIO* pFile )
{
	return CObj::Read( pFile );
}
// this°¡ pIA¿¡ ¸µÅ©µÇ¾ú´Ù.
// pIA°¡ NULLÀÌ¸é ¸µÅ©ÇØÁ¦.
void CCtrl::SetIAObjLink( CShip *pIA )
{
	if( pIA != NULL )	// IA¿¡ ¸µÅ©½ÃÄÑ¾ß ÇÒ¶§...
	{
		if( m_pIAObjLink != pIA )				// ±âÁ¸¿¡ ¸µÅ©¶û ´Ù¸¥¸µÅ©°¡ µÉ¶§¸¸...
			if( pIA->FindCtrl( GetId() ) == NULL )			// pIA¿¡ ÀÌ¹Ì this°¡ µî·ÏµÇ¾ú´ÂÁö º¸°í...
				pIA->AddCtrl( GetId() );			// IA¿ÀºêÁ§Æ®¿¡ this¸¦ µî·Ï½ÃÅ´.
	} else
	{
		if( m_pIAObjLink )
			m_pIAObjLink->RemoveCtrl( GetId() );
	}

	m_pIAObjLink = pIA;
}

void CCtrl::AddItToGlobalId()
{
	prj.m_objmap.Add( this );

	if( OT_MOVER == GetType() && ( (CMover*)this )->IsPlayer() )
	{
		bool bResult = prj.m_idPlayerToUserPtr.insert( make_pair( ( (CMover*)this )->m_idPlayer, (CMover*)this ) ).second;
		if( bResult == false )
			Error("AddItToGlobalId id:%d duplicated.", ((CMover*)this)->m_idPlayer );
	}

#ifdef __WORLDSERVER	
	if( GetType() == OT_CTRL )
	{
		CCommonCtrl* pCommonCtrl = (CCommonCtrl*)this;
		if( pCommonCtrl->m_CtrlElem.m_strCtrlKey[0] != '\0' )
			g_MapStrToObjId.insert( map< string, DWORD >::value_type(pCommonCtrl->m_CtrlElem.m_strCtrlKey, pCommonCtrl->GetId() ) );
	}
#endif // __WORLDSERVER
}

void CCtrl::RemoveItFromGlobalId()
{
	if( m_objid == NULL_ID )	
		return;

	prj.m_objmap.RemoveKey( m_objid );

	if( OT_MOVER == GetType() && ( (CMover*)this )->IsPlayer() && ( (CMover*)this )->m_idPlayer != (u_long)0xffffffff )
		prj.m_idPlayerToUserPtr.erase( ( (CMover*)this )->m_idPlayer );

#ifdef __WORLDSERVER	
	if( GetType() == OT_CTRL )
	{
		CCommonCtrl* pCommonCtrl = (CCommonCtrl*)this;
		if( pCommonCtrl->m_CtrlElem.m_strCtrlKey[0] != '\0' )
			g_MapStrToObjId.erase( pCommonCtrl->m_CtrlElem.m_strCtrlKey );
	}
#endif // __WORLDSERVER
}

#ifdef __WORLDSERVER

BOOL CCtrl::ProcessDeleteRespawn()
{
	// ¸®½ºÆùÀÌ RemoveÀÌ¸é »èÁ¦ ¸í·É 
#ifdef __LAYER_1021
	CRespawnInfo* pRespawnInfo = GetWorld()->m_respawner.GetRespawnInfo( GetRespawn(), m_nRespawnType, GetLayer() );
#else	// __LAYER_1021
	CRespawnInfo* pRespawnInfo = GetWorld()->m_respawner.GetRespawnInfo( GetRespawn(), m_nRespawnType );
#endif	// __LAYER_1021
	if( pRespawnInfo && pRespawnInfo->m_bRemove )
	{
		Delete();
		return TRUE;
	}
	return FALSE;
}

void CCtrl::RemoveItFromView( BOOL bRemoveall )
{
	if( !GetWorld() )	
		return;

	CUser* pUser;
	if( GetType() == OT_MOVER && ( (CMover*)this )->IsPlayer() )
	{
		map<DWORD, CUser* >::iterator it = m_2pc.begin();
		while( it != m_2pc.end() )
		{
			pUser = it->second;
			if( pUser != this && pUser->PCRemoveKey( GetId() ) )
				pUser->AddRemoveObj( GetId() );
			++it;
		}

		if( bRemoveall )
			m_2pc.clear();
	}
	else
	{
		map<DWORD, CUser* >::iterator it = m_2pc.begin();
		while( it != m_2pc.end() )
		{
			pUser = it->second;
			if( pUser->NPCRemoveKey( GetId() ) )
				pUser->AddRemoveObj( GetId() );
			++it;
		}

		if( bRemoveall )
			m_2pc.clear();
	}

}

BOOL CCtrl::IsNearPC( CUser* pUser )
{
	return IsNearPC( pUser->GetId() );
}

BOOL CCtrl::IsNearPC( OBJID objid )
{
	map<DWORD, CUser* >::iterator it = m_2pc.find( objid );
	return ( it != m_2pc.end() ) ;
}

#endif	// __WORLDSERVER

BOOL	CCtrl::GetSkillProp( ItemProp **ppSkillProp, AddSkillProp **ppAddSkillProp, int nSkill, DWORD dwLevel, LPCTSTR szErr )
{
	ItemProp* pSkillProp = prj.GetSkillProp( nSkill );	// UseSkill¿¡¼­ »ç¿ëÇÑ ½ºÅ³ÀÇ ÇÁ·ÎÆÛÆ¼ ²¨³¿
	if( pSkillProp == NULL )
	{
		Error( "%s : %d. ½ºÅ³(%d)ÀÇ ÇÁ·ÎÆÛÆ¼°¡ ¾ø´Ù.", szErr, GetIndex(), nSkill );
		return FALSE;
	}
	
	
	AddSkillProp *pAddSkillProp	= prj.GetAddSkillProp( pSkillProp->dwSubDefine, dwLevel );
	if( pAddSkillProp == NULL )
	{
		Error( "%s : %d. Add½ºÅ³(%d) Lv%dÀÇ ÇÁ·ÎÆÛÆ¼°¡ ¾ø´Ù.", szErr, GetIndex(), nSkill, dwLevel );
		return FALSE;
	}

	if( pAddSkillProp->dwName != pSkillProp->dwID )
		Error( "%s : %d. Add½ºÅ³(%d) AddSkill->dwName°ú Skill->dwID°¡ ´Ù¸£´Ù.", szErr, GetIndex(), nSkill );
	
	*ppSkillProp = pSkillProp;
	*ppAddSkillProp = pAddSkillProp;
	
	return TRUE;
}


// vPos¸¦ Áß½ÉÀ¸·Î ÁÖº¯¿¡ È¿°ú¸¦ Àû¿ëÇÑ´Ù.
// ------------------------------------------
// Æ®·¦ÀÌ ¾µ¼öµµ ÀÖ°í. ¸ó½ºÅÍ°¡¾µ¼öµµÀÖ´Ù(¹ð), ÁÖÀÎ°øÀÌ ½ºÅ³·Î »ç¿ëÇÒ¼öµµ ÀÖ´Ù.
// È¿°ú´Â ¹Ýµå½Ã SkillPropÀ» ¸¸µé¾î¼­ ±× ¾ÆÀÌµð¸¦ ³Ñ°Ü¾ß ÇÑ´Ù.
//
// °æ¿ì¿¡µû¶ó pAddSkillPropÀº NULLÀÏ¼öµµ ÀÖ´Ù.  ¾ÆÀÌÅÛ¿¡¼­ »ç¿ëÇÒ¼öµµ ÀÖ±â¶§¹®. ¾ÆÀÌÅÛÀº ¾Öµå½ºÅ³ÇÁ·ÓÀÌ ¾ø´Ù.
// pCenter : ±¤¿ª Áö¼Ó½ºÅ³ÀÇ Å¸°Ù. NULLÀÏ¼öµµ ÀÖ´Ù
#if __VER >= 8 // __S8_PK
void	CCtrl::ApplySkillRegion( const D3DXVECTOR3 &vPos, int nApplyType, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp, bool bIgnoreProb, BOOL bOnlyDmg, CCtrl* pCenter, BOOL bControl )
#else // __VER >= 8 // __S8_PK
void	CCtrl::ApplySkillRegion( const D3DXVECTOR3 &vPos, int nApplyType, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp, bool bIgnoreProb, BOOL bOnlyDmg, CCtrl* pCenter )
#endif // __VER >= 8 // __S8_PK
{
#ifdef __WORLDSERVER
	int nRange	= 4;	// 4m
	CObj* pObj;
	CCtrl *pSrc = this;
	D3DXVECTOR3 vDist;

	if( pSkillProp == NULL )
		Error( "CCtrl::ApplySkillRegion : pSkillProp == NULL A:%d-%d", pSrc->GetType(), pSrc->GetIndex() );

	FLOAT fRange = 4.0f;
	if( pAddSkillProp )										// ¾Öµå½ºÅ³ÀÌ ÀÖÀ¸¸é °Å±â¼­ ²¨³¿
	{
		fRange = (float)pAddSkillProp->dwSkillRange;
		if( pAddSkillProp->dwSkillRange == NULL_ID )
			Error( "°æ°í : ½ºÅ³ %dÀÇ dwSkillRange°¡ ÁöÁ¤µÇÁö ¾ÊÀ½", pAddSkillProp->dwID );
	}
	else
	{
		fRange = (float)pSkillProp->_dwSkillRange;			// ¾øÀ¸¸é ½ºÅ³ÇÁ·ÎÆÛÆ¼¿¡¼­ ²¨³¿.
		if( pSkillProp->_dwSkillRange == NULL_ID )
			Error( "°æ°í : ½ºÅ³ %dÀÇ dwSkillRange°¡ ÁöÁ¤µÇÁö ¾ÊÀ½", pSkillProp->dwID );
	}

	if( fRange <= 4.0f )		nRange = 4;
	else if( fRange <= 8.0f )	nRange = 8;
	else if( fRange <= 16.0f )	nRange = 16;
	else						nRange = 32;

	if( fRange <= 0 )	// ¹üÀ§°¡ 0ÀÌ°Å³ª À½¼öÀÏ¼ö´Â ¾ø´Ù.
		Error( "CCtrl::ApplySkillRegion : D:%d A:%d-%d %d %f", GetIndex(), pSrc->GetType(), pSrc->GetIndex(), pSkillProp->dwID, fRange );

	BOOL	bApply = FALSE;
	BOOL	bTarget = TRUE;

	//------------ Àû¿ë´ë»óÀÌ ÇÃ·¹ÀÌ¾îÀÎ°¡ 
	if( nApplyType & OBJTYPE_PLAYER )	
	{
		FOR_LINKMAP( GetWorld(), vPos, pObj, nRange, CObj::linkPlayer, GetLayer() )
		{
			bApply = FALSE;	// ÀÏ´Ü FALSE·Î ÃÊ±âÈ­

			if( pObj->GetType() != OT_MOVER )
				Error( "ApplySkillRegion : pObj°¡ MOVER°¡ ¾Æ´Ï´Ù %d", pObj->GetType() );

			if( pSrc->GetType() == OT_MOVER )		// °ø°ÝÀÚ°¡ ¹«¹ö³Ä.
			{
				CMover *pAttacker = (CMover *)pSrc;
				if( pAttacker->IsPlayer() )			// °ø°ÝÀÚ°¡ ÇÃ·¹ÀÌ¾î³Ä
				{
					bApply = TRUE;
#if __VER >= 8 // __S8_PK
					CMover *pDefender = (CMover *)pObj;
					if( pDefender->IsPlayer() )
					{
						if( pCenter )
							bTarget = (pCenter == pDefender);
						else
							bTarget = FALSE;

						if( bControl == FALSE && pAttacker->GetHitType( pDefender, bTarget, FALSE ) == HITTYPE_PK )
							bApply = FALSE;
//	#ifdef	__JHMA_VER_8_5_2			 // 8.5Â÷ µà¾óÁßÀÎ µÎ±¸·ìÀÌ ¿¬°üµÇÁö¾Ê°Ô ¼öÁ¤  World
						else if( pAttacker->m_nDuel == 1 && pDefender->m_nDuel == 1 && pAttacker->GetHitType( pDefender, bTarget, FALSE ) != HITTYPE_PVP )
							bApply = FALSE;
//	#endif // __JHMA_VER_8_5_1	
					}
#endif // __VER >= 8 // __S8_PK
				} else
				{	// °ø°ÝÀÚ°¡ ¸ó½ºÅÍ¸é
					bApply = TRUE;		// 
				}
			} else
			{	// °ø°ÝÀÚ°¡ ¹«¹ö°¡ ¾Æ´Ï´Ù.
				bApply = TRUE;
			}

			if( bApply )
			{
				if( pObj != pSrc )		// ¾îÅÂÄ¿´Â °Ë»ö´ë»ó¿¡¼­ Á¦¿Ü.
				{
					if( pObj->IsRangeObj( vPos, fRange ) )	// vCenter + fRange¿Í pObjÀÇ ½ºÇÇ¾î°¡ Ãæµ¹Çß´À³Ä
					{
						CMover *pTarget = (CMover *)pObj;		// <- ¿©±ä ¹«Á¶°Ç pObj´Â ÇÃ·¹ÀÌ¾î¹Ç·Î ÇØµµµÊ.
					
						if( pCenter )
							bTarget = (pCenter == pTarget);
						else
							bTarget = FALSE;

						if( IsValidObj( pTarget ) && pTarget->IsLive() )
						{
							pTarget->ApplySkill( pSrc, pSkillProp, pAddSkillProp, bIgnoreProb, 0, bOnlyDmg, bTarget );		// ´ë»ó¿¡°Ô È¿°ú¸¦ Àû¿ëÇÔ.
						}
					}
				}
				
				bApply = FALSE;	// ´ÙÀ½ ·çÇÁ¸¦ À§ÇØ¼­ ÃÊ±âÈ­.
			} // bApply
		}
		END_LINKMAP
	} // OBJTYPE_PLAYER

	// Àû¿ë´ë»óÀÌ ¸ó½ºÅÍ/ÄÁÆ®·Ñ ÀÎ°¡.
	if( nApplyType & (OBJTYPE_MONSTER | OBJTYPE_CTRL) )
	{
		FOR_LINKMAP( GetWorld(), vPos, pObj, nRange, CObj::linkDynamic, GetLayer() )	// linkDynamicÀ» ¾´´Ù
		{
			bApply = FALSE;
			if( pObj->GetType() == OT_MOVER )				// ´ë»óÀÌ ¹«¹ö¸é.
			{
				CMover *pTarget = (CMover *)pObj;
				if( pTarget->IsPeaceful() == FALSE )		// NPC°¡ ¾Æ´Ñ°æ¿ì¸¸ Àû¿ë
					bApply = TRUE;
#if __VER >= 8 //	#ifdef	__JHMA_VER_8_5_1			 // 8.5Â÷ °æºñº´ ¹üÀ§½ºÅ³ °ø°ÝÈ¿°ú ºÒ°¡·Î ¼öÁ¤ World
				CMover *pAttacker = (CMover *)pSrc;
				if( pAttacker->IsPlayer() && pAttacker->IsChaotic() == FALSE && pTarget->GetProp()->dwClass == RANK_GUARD )
					bApply = FALSE;
#endif //	#endif // __JHMA_VER_8_5_1			 // 8.5Â÷ °æºñº´ ¹üÀ§½ºÅ³ °ø°ÝÈ¿°ú ºÒ°¡·Î ¼öÁ¤ World
			} else
			// ´ë»óÀÌ ÄÁÆ®·ÑÀÌ¸é.
			if( pObj->GetType() == OT_CTRL )
			{
				if( pSrc->GetType() == OT_MOVER )			// °ø°ÝÀÚ°¡ ¹«¹öÀÏ¶§¸¸ Àû¿ë. ÄÁÆ®·ÑÀÌ ÄÁÆ®·Ñ¿¡°Ô ¿µÇâÀ» ÁÙ¼ø ¾ø´Ù.
					bApply = TRUE;							
			}

			if( bApply )
			{
				if( pObj != pSrc )		// °ø°ÝÀÚ´Â °Ë»ç´ë»ó¿¡¼­ Á¦¿Ü.
				{
					if( pObj->IsRangeObj( vPos, fRange ) )	// vCenter + fRange¿Í pObjÀÇ ½ºÇÇ¾î°¡ Ãæµ¹Çß´À³Ä
					{
						if( pObj->GetType() == OT_MOVER )	// Å¸°ÙÀÌ ¹«¹ö³Ä?
						{
							if( IsValidObj( pObj ) && ((CMover *)pObj)->IsLive() )		// Å¸°ÙÀÌ ¹«¹ö¸é »ì¾ÆÀÖ´ÂÁö °Ë»ç.
								((CCtrl*)pObj)->ApplySkill( pSrc, pSkillProp, pAddSkillProp, bIgnoreProb, 0, bOnlyDmg );		// ´ë»ó¿¡°Ô È¿°ú¸¦ Àû¿ëÇÔ.
						} else
						{
							// Å¸°ÙÀÌ ¹«¹ö°¡ ¾Æ´Ï³Ä?
							((CCtrl*)pObj)->ApplySkill( pSrc, pSkillProp, pAddSkillProp, bIgnoreProb, 0, bOnlyDmg );		// ´ë»ó¿¡°Ô È¿°ú¸¦ Àû¿ëÇÔ.
						}
					}
				}
			} // bApply
		}
		END_LINKMAP
	}
		
#endif // WORLDSERVER		
} // ApplySkillRegion()


// this¸¦ Áß½ÉÀ¸·Î ÁÖº¯¿¡ È¿°ú¸¦ Àû¿ëÇÑ´Ù.
// ------------------------------------------
// Æ®·¦ÀÌ ¾µ¼öµµ ÀÖ°í. ¸ó½ºÅÍ°¡¾µ¼öµµÀÖ´Ù(¹ð), ÁÖÀÎ°øÀÌ ½ºÅ³·Î »ç¿ëÇÒ¼öµµ ÀÖ´Ù.
// È¿°ú´Â ¹Ýµå½Ã SkillPropÀ» ¸¸µé¾î¼­ ±× ¾ÆÀÌµð¸¦ ³Ñ°Ü¾ß ÇÑ´Ù.
//
// °æ¿ì¿¡µû¶ó pAddSkillPropÀº NULLÀÏ¼öµµ ÀÖ´Ù.  ¾ÆÀÌÅÛ¿¡¼­ »ç¿ëÇÒ¼öµµ ÀÖ±â¶§¹®. ¾ÆÀÌÅÛÀº ¾Öµå½ºÅ³ÇÁ·ÓÀÌ ¾ø´Ù.
// fRangeCustom¿¡ °ªÀÌ ÀÖÀ»°æ¿ì¿¡´Â ÇÁ·ÎÆÛÆ¼ nRange°ªÀ» ¹«½ÃÇÏ°í fRangeCustomÀ¸·Î ¹Ù²ï´Ù.
#if __VER >= 8 // __S8_PK
void	CCtrl::ApplySkillAround( CCtrl *pSrc, int nApplyType, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp, bool bIgnoreProb, BOOL bOnlyDmg, FLOAT fRangeCustom, BOOL bControl )
#else // __VER >= 8 // __S8_PK
void	CCtrl::ApplySkillAround( CCtrl *pSrc, int nApplyType, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp, bool bIgnoreProb, BOOL bOnlyDmg, FLOAT fRangeCustom )
#endif // __VER >= 8 // __S8_PK
{
#ifdef __WORLDSERVER
	int nRange	= 4;	// 4m
	CObj* pObj;
	D3DXVECTOR3 vPos = GetPos();
	D3DXVECTOR3 vDist;

	if( pSkillProp == NULL )
		Error( "CCtrl::ApplySkillAround : pSkillProp == NULL D:%d A:%d-%d", GetIndex(), pSrc->GetType(), pSrc->GetIndex() );

	FLOAT fRange = 4.0f;
	if( pAddSkillProp )										// ¾Öµå½ºÅ³ÀÌ ÀÖÀ¸¸é °Å±â¼­ ²¨³¿
		fRange = (float)pAddSkillProp->dwSkillRange;
	else
		fRange = (float)pSkillProp->_dwSkillRange;			// ¾øÀ¸¸é ½ºÅ³ÇÁ·ÎÆÛÆ¼¿¡¼­ ²¨³¿.

	if( fRange <= 4.0f )		nRange = 4;
	else if( fRange <= 8.0f )	nRange = 8;
	else if( fRange <= 16.0f )	nRange = 16;
	else						nRange = 32;

	if( fRangeCustom != 0.0f )
	{
		fRange = fRangeCustom;
	}

	FLOAT fTargetRatio = 0.0f;
	if( pSkillProp->dwSpellRegion == SRO_REGION )	// REGION¼Ó¼ºÀÏ¶© Å¸°Ùµµ µ¥¹ÌÁö¸¦ ¸ÔÀ½.
		fTargetRatio = 1.0f;

	if( fRange <= 0 )	// ¹üÀ§°¡ 0ÀÌ°Å³ª À½¼öÀÏ¼ö´Â ¾ø´Ù.
		Error( "CCtrl::ApplySkillAround : D:%d A:%d-%d %d %f", GetIndex(), pSrc->GetType(), pSrc->GetIndex(), pSkillProp->dwID, fRange );

	BOOL	bApply = FALSE;
	BOOL	bTarget = FALSE;

	//------------ Àû¿ë´ë»óÀÌ ÇÃ·¹ÀÌ¾îÀÎ°¡ 
	if( nApplyType & OBJTYPE_PLAYER )	
	{
		FOR_LINKMAP( GetWorld(), vPos, pObj, nRange, CObj::linkPlayer, GetLayer() )
		{
			bApply = FALSE;	// ÀÏ´Ü FALSE·Î ÃÊ±âÈ­

			if( pObj->GetType() != OT_MOVER )
				Error( "ApplySkillAround : pObj°¡ MOVER°¡ ¾Æ´Ï´Ù %d", pObj->GetType() );

			if( pSrc->GetType() == OT_MOVER )		// °ø°ÝÀÚ°¡ ¹«¹ö³Ä.
			{
				CMover *pAttacker = (CMover *)pSrc;
				if( pAttacker->IsPlayer() )			// °ø°ÝÀÚ°¡ ÇÃ·¹ÀÌ¾î³Ä
				{
					bApply	= TRUE;
#if __VER >= 8 // __S8_PK
					CMover *pDefender = (CMover *)pObj;
					if( pDefender->IsPlayer() )
					{
						bTarget = (this == pDefender);
						
						if( bControl == FALSE && pAttacker->GetHitType( pDefender, bTarget, FALSE ) == HITTYPE_PK )
							bApply = FALSE;
//	#ifdef	__JHMA_VER_8_5_2			 // 8.5Â÷ µà¾óÁßÀÎ µÎ±¸·ìÀÌ ¿¬°üµÇÁö¾Ê°Ô ¼öÁ¤  World
						else if( pAttacker->m_nDuel == 1 && pDefender->m_nDuel == 1 && pAttacker->GetHitType( pDefender, bTarget, FALSE ) != HITTYPE_PVP )
							bApply = FALSE;
//	#endif // __JHMA_VER_8_5_1	

					}
#endif // __VER >= 8 // __S8_PK
				} else
				{	// °ø°ÝÀÚ°¡ ¸ó½ºÅÍ¸é
					bApply = TRUE;		// 
				}
			} else
			{	// °ø°ÝÀÚ°¡ ¹«¹ö°¡ ¾Æ´Ï´Ù.
				bApply = TRUE;
			}

			if( bApply )
			{
				if( pObj->IsRangeObj( this, fRange ) )	// this(Center)ÀÇ ½ºÇÇ¾î¿Í pObjÀÇ ½ºÇÇ¾î°¡ Ãæµ¹Çß´À³Ä
				{
					if( pObj == this && fTargetRatio == 0.0f )	// Å¸°Ùµ¥¹ÌÁö ºñÀ²ÀÌ 0ÀÌ¸é ÀÚ±âÀÚ½Å(Å¸°Ù)Àº µ¥¹ÌÁö¸¦ ÁÖÁö¾ÊÀ½.
					{
					} else
					{
						if( pObj != pSrc )		// ¾îÅÂÄ¿´Â °Ë»ö´ë»ó¿¡¼­ Á¦¿Ü.
						{
							CMover *pTarget = (CMover *)pObj;		// <- ¿©±ä ¹«Á¶°Ç pObj´Â ÇÃ·¹ÀÌ¾î¹Ç·Î ÇØµµµÊ.
							bTarget = (this == pTarget);
							if( IsValidObj( pTarget ) && pTarget->IsLive() )
								pTarget->ApplySkill( pSrc, pSkillProp, pAddSkillProp, bIgnoreProb, 0, bOnlyDmg, bTarget );		// ´ë»ó¿¡°Ô È¿°ú¸¦ Àû¿ëÇÔ.
						}
					}
				}
				
				bApply = FALSE;	// ´ÙÀ½ ·çÇÁ¸¦ À§ÇØ¼­ ÃÊ±âÈ­.
			} // bApply
		}
		END_LINKMAP
	} // OBJTYPE_PLAYER

	// Àû¿ë´ë»óÀÌ ¸ó½ºÅÍ/ÄÁÆ®·Ñ ÀÎ°¡.
	if( nApplyType & (OBJTYPE_MONSTER | OBJTYPE_CTRL) )
	{
		FOR_LINKMAP( GetWorld(), vPos, pObj, nRange, CObj::linkDynamic, GetLayer() )	// linkDynamicÀ» ¾´´Ù
		{
			bApply = FALSE;
			if( pObj->GetType() == OT_MOVER )				// ´ë»óÀÌ ¹«¹ö¸é.
			{
				CMover *pTarget = (CMover *)pObj;
				if( pTarget->IsPeaceful() == FALSE )		// NPC°¡ ¾Æ´Ñ°æ¿ì¸¸ Àû¿ë
					bApply = TRUE;
#if __VER >= 8 //	#ifdef	__JHMA_VER_8_5_1			 // 8.5Â÷ °æºñº´ ¹üÀ§½ºÅ³ °ø°ÝÈ¿°ú ºÒ°¡·Î ¼öÁ¤ World
				CMover *pAttacker = (CMover *)pSrc;
				if( pAttacker->IsPlayer() && pAttacker->IsChaotic() == FALSE && pTarget->GetProp()->dwClass == RANK_GUARD )
					bApply = FALSE;
#endif //	#endif // __JHMA_VER_8_5_1			 // 8.5Â÷ °æºñº´ ¹üÀ§½ºÅ³ °ø°ÝÈ¿°ú ºÒ°¡·Î ¼öÁ¤ World
			} else
			// ´ë»óÀÌ ÄÁÆ®·ÑÀÌ¸é.
			if( pObj->GetType() == OT_CTRL )
			{
				if( pSrc->GetType() == OT_MOVER )			// °ø°ÝÀÚ°¡ ¹«¹öÀÏ¶§¸¸ Àû¿ë. ÄÁÆ®·ÑÀÌ ÄÁÆ®·Ñ¿¡°Ô ¿µÇâÀ» ÁÙ¼ø ¾ø´Ù.
					bApply = TRUE;							
			}

			if( bApply )
			{
				if( pObj->IsRangeObj( this, fRange ) )	// this(Center)ÀÇ ½ºÇÇ¾î¿Í pObjÀÇ ½ºÇÇ¾î°¡ Ãæµ¹Çß´À³Ä
				{
					if( pObj == this && fTargetRatio == 0.0f )	// Å¸°Ùµ¥¹ÌÁö ºñÀ²ÀÌ 0ÀÌ¸é ÀÚ±âÀÚ½Å(Å¸°Ù)Àº µ¥¹ÌÁö¸¦ ÁÖÁö¾ÊÀ½.
					{
					} else
					{
						if( pObj != pSrc )		// °ø°ÝÀÚ´Â °Ë»ç´ë»ó¿¡¼­ Á¦¿Ü.
						{
							if( pObj->GetType() == OT_MOVER )	// Å¸°ÙÀÌ ¹«¹ö³Ä?
							{
								if( IsValidObj( pObj ) && ((CMover *)pObj)->IsLive() )		// Å¸°ÙÀÌ ¹«¹ö¸é »ì¾ÆÀÖ´ÂÁö °Ë»ç.
									((CCtrl*)pObj)->ApplySkill( pSrc, pSkillProp, pAddSkillProp, bIgnoreProb, 0, bOnlyDmg );		// ´ë»ó¿¡°Ô È¿°ú¸¦ Àû¿ëÇÔ.
							} else
							{
								// Å¸°ÙÀÌ ¹«¹ö°¡ ¾Æ´Ï³Ä?
								((CCtrl*)pObj)->ApplySkill( pSrc, pSkillProp, pAddSkillProp, bIgnoreProb, 0, bOnlyDmg );		// ´ë»ó¿¡°Ô È¿°ú¸¦ Àû¿ëÇÔ.
							}
						}
					}
				}
			} // bApply
		}
		END_LINKMAP
	}
		
#endif // WORLDSERVER		
} // ApplySkillAround()

// 
// Æø, ³ôÀÌ, ±æÀÌ¸¦ ¼³Á¤ÇÏ¿© À°¸éÃ¼ ÇüÅÂÀÇ µ¥¹ÌÁö ¿µ¿ªÀ» »ý¼º.
// nDmgType : AF_???
// nApplyType : OBJTYPE_PLAYER , MONSTER
// nAttackID : ½ºÅ³ÀÌ³ª ¾ÆÀÌÅÛ ID
// fWidth, fHeight, fDepth : Æø, ³ôÀÌ, ±æÀÌ.
// this == Attacker
#if __VER >= 8 // __S8_PK
void	CCtrl::ApplySkillLine( int nApplyType, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp, float fWidth, float fHeight, float fDepth, bool bIgnoreProb, BOOL bControl )
#else // __VER >= 8 // __S8_PK
void	CCtrl::ApplySkillLine( int nApplyType, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp, float fWidth, float fHeight, float fDepth, bool bIgnoreProb )
#endif // __VER >= 8 // __S8_PK
{
#ifdef __WORLDSERVER
	int nRange	= 4;	// 4m
	CObj* pObj;
	D3DXVECTOR3 vPos = GetPos();
	D3DXVECTOR3 vDist;

	if( pSkillProp == NULL )
		Error( "CCtrl::ApplySkillLine : pSkillProp == NULL %d", GetIndex() );
	
	// µ¥¹ÌÁö ¿µ¿ª Local AABB.
	D3DXVECTOR3 vMin1 = D3DXVECTOR3( -fWidth / 2.0f, -fHeight / 2.0f, -fDepth );
	D3DXVECTOR3 vMax1 = D3DXVECTOR3(  fWidth / 2.0f,  fHeight / 2.0f, 0 );

	D3DXMATRIX mInv;		// °ø°ÝÀÚÃø ¿ùµå¿ªÇà·Ä
	D3DXMATRIX m1, m2, m3;
	D3DXMatrixRotationY( &m1, D3DXToRadian( -GetAngle() ) );
	D3DXMatrixTranslation( &m2, GetPos().x, GetPos().y, GetPos().z );
	D3DXMatrixMultiply( &m3, &m1, &m2 );	// world = rot * trans
	
	D3DXMatrixInverse( &mInv, NULL, &m3 );		// °ø°ÝÀÚÀÇ ¿ªÇà·Ä ¸¸µë.

	// Å¸°ÙÀÇ ÁÂÇ¥¸¦ °ø°ÝÀÚÃø ±âÁØÀ¸·Î ¿ªº¯È¯ ÇÑ°Í.
	D3DXVECTOR3 vDestLocal;

	// ÀÏ¹ÝÀûÀ¸·Î fDepth°¡ °¡Àå ±æ±â¶§¹®¿¡ °Ë»ç ¿µ¿ªÀº fDepth·Î Çß´Ù. 
	if( fDepth <= 4.0f )		nRange = 4;
	else if( fDepth <= 8.0f )	nRange = 8;
	else if( fDepth <= 16.0f )	nRange = 16;
	else						nRange = 32;
	
	if( fDepth <= 0 )	// ¹üÀ§°¡ 0ÀÌ°Å³ª À½¼öÀÏ¼ö´Â ¾ø´Ù.
		Error( "CCtrl::ApplySkillLine : %d %d", GetIndex(), fDepth );

	
	BOOL	bApply = FALSE;
	BOOL	bTarget = FALSE;

	if( nApplyType & OBJTYPE_PLAYER )	// Àû¿ë´ë»óÀÌ ÇÃ·¹ÀÌ¾îÀÎ°¡ 
	{
		FOR_LINKMAP( GetWorld(), vPos, pObj, nRange, CObj::linkPlayer, GetLayer() )
		{
			bApply = FALSE;	// ½ÃÀÛÀº FALSE

			if( pObj->GetType() != OT_MOVER )
				Error( "ApplySkillLine : pObj°¡ MOVER°¡ ¾Æ´Ï´Ù %d", pObj->GetType() );

			if( GetType() == OT_MOVER )		// °ø°ÝÀÚ°¡ ¹«¹ö³Ä.
			{
				CMover *pAttacker = (CMover *)this;
				if( pAttacker->IsPlayer() )			// °ø°ÝÀÚ°¡ ÇÃ·¹ÀÌ¾î³Ä
				{
					bApply = TRUE;
#if __VER >= 8 // __S8_PK
					CMover *pDefender = (CMover *)pObj;
					if( pDefender->IsPlayer() )
					{
						if( bControl == FALSE && pAttacker->GetHitType( pDefender, bTarget, FALSE ) == HITTYPE_PK )
							bApply = FALSE;
//	#ifdef	__JHMA_VER_8_5_2			 // 8.5Â÷ µà¾óÁßÀÎ µÎ±¸·ìÀÌ ¿¬°üµÇÁö¾Ê°Ô ¼öÁ¤  World
						else if( pAttacker->m_nDuel == 1 && pDefender->m_nDuel == 1 && pAttacker->GetHitType( pDefender, bTarget, FALSE ) != HITTYPE_PVP )
							bApply = FALSE;
//	#endif // __JHMA_VER_8_5_1	
					}
#endif // __VER >= 8 // __S8_PK
				} else
				{
					// °ø°ÝÀÚ°¡ ¸ó½ºÅÍ¸é
					bApply = TRUE;		// 
				}
			} else
			{
				// °ø°ÝÀÚ°¡ ¹«¹ö°¡ ¾Æ´Ï´Ù.
				bApply = TRUE;
			}
			
			if( bApply && pObj != this )		// this´Â °ø°Ý´ë»ó¿¡¼­ Á¦¿Ü.
			{
				CMover *pTarget = (CMover *)pObj;
				if( IsValidObj( pTarget ) && pTarget->IsLive() )
				{
					// Å¸°ÙÃø ÁÂÇ¥¸¦ ¿ªº¯È¯.
					D3DXVec3TransformCoord( &vDestLocal, &pTarget->GetPos(), &mInv );
					// Å¸°ÙÃø AABB
					D3DXVECTOR3 vMin2 = vDestLocal + pTarget->m_pModel->m_vMin;
					D3DXVECTOR3 vMax2 = vDestLocal + pTarget->m_pModel->m_vMax;
					if( ::IsTouchAABB( vMin1, vMax1, vMin2, vMax2 ) )		// AABBÃæµ¹°Ë»ç.
					{
						pTarget->ApplySkill( this, pSkillProp, pAddSkillProp, bIgnoreProb, 0, FALSE, bTarget );		// bTarget Å¸°ÙÀÌ ¾øÀ¸¹Ç·Î FALSE·Î ³ÖÀ½. PK½Ã ¼±»§À» Ä¥¼ö¾øÀ½
					}
				}
			} // bApply
		}
		END_LINKMAP
	}

	// Àû¿ë´ë»óÀÌ ¸ó½ºÅÍÀÎ°¡.
	if( nApplyType & (OBJTYPE_MONSTER | OBJTYPE_CTRL) )
	{
		FOR_LINKMAP( GetWorld(), vPos, pObj, nRange, CObj::linkDynamic, GetLayer() )
		{
			bApply = FALSE;
			if( pObj->GetType() == OT_MOVER )				// ´ë»óÀÌ ¹«¹ö¸é.
			{
				CMover *pTarget = (CMover *)pObj;
				if( pTarget->IsPeaceful() == FALSE )		// NPC°¡ ¾Æ´Ñ°æ¿ì¸¸ Àû¿ë
					bApply = TRUE;
#if __VER >= 8 //	#ifdef	__JHMA_VER_8_5_1			 // 8.5Â÷ °æºñº´ ¹üÀ§½ºÅ³ °ø°ÝÈ¿°ú ºÒ°¡·Î ¼öÁ¤ World
				CMover *pAttacker = (CMover *)this;
				if( pAttacker->IsPlayer() && pAttacker->IsChaotic() == FALSE && pTarget->GetProp()->dwClass == RANK_GUARD )
					bApply = FALSE;
#endif //	#endif // __JHMA_VER_8_5_1			 // 8.5Â÷ °æºñº´ ¹üÀ§½ºÅ³ °ø°ÝÈ¿°ú ºÒ°¡·Î ¼öÁ¤ World
			} else
			// ´ë»óÀÌ ÄÁÆ®·ÑÀÌ¸é
			if( pObj->GetType() == OT_CTRL )
			{
				if( GetType() == OT_MOVER )			// °ø°ÝÀÚ°¡ ¹«¹öÀÏ¶§¸¸ Àû¿ë. ÄÁÆ®·ÑÀÌ ÄÁÆ®·Ñ¿¡°Ô ¿µÇâÀ» ÁÙ¼ø ¾ø´Ù.
					bApply = TRUE;							
			}
			
			
			if( bApply )
			{
				if( pObj->GetType() == OT_MOVER )
				{
					CMover *pTarget = (CMover *)pObj;

					if( IsValidObj( pTarget ) && pTarget->IsLive() )
					{
						// Å¸°ÙÃø ÁÂÇ¥¸¦ ¿ªº¯È¯.
						D3DXVec3TransformCoord( &vDestLocal, &pTarget->GetPos(), &mInv );
						// Å¸°ÙÃø AABB
						D3DXVECTOR3 vMin2 = vDestLocal + pTarget->m_pModel->m_vMin;
						D3DXVECTOR3 vMax2 = vDestLocal + pTarget->m_pModel->m_vMax;
						if( ::IsTouchAABB( vMin1, vMax1, vMin2, vMax2 ) )		// AABBÃæµ¹°Ë»ç.
						{
							((CCtrl*)pObj)->ApplySkill( this, pSkillProp, pAddSkillProp, bIgnoreProb );		// ´ë»ó¿¡°Ô È¿°ú¸¦ Àû¿ëÇÔ.
						}
					}
				} else
					((CCtrl*)pObj)->ApplySkill( this, pSkillProp, pAddSkillProp, bIgnoreProb );		// ´ë»ó¿¡°Ô È¿°ú¸¦ Àû¿ëÇÔ.
			}
		}
		END_LINKMAP
	}
		
#endif // WORLDSERVER		
} // ApplySkillLine()

//
// idParty ±Ø´Ü´ë»ó ¹üÀ§ È¿°ú.
//
int		CCtrl::ApplySkillAroundTroupe( u_long idParty, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp, bool bIgnoreProb )
{
	BOOL bRet = FALSE;
#ifdef __WORLDSERVER
	if( GetType() != OT_MOVER )		return bRet;	// ¹«¹ö°¡ ¾Æ´Ñ°Ô ±Ø´Ü½ºÅ³À» ½èÀ»¸® ¾ø´Ù.
	if( ((CMover *)this)->IsPlayer() == FALSE )		return bRet;	// ÇÃ·¹ÀÌ¾î°¡ ¾Æ´Ñ°Ô ±Ø´Ü½ºÅ³À» ½èÀ»¸® ¾ø´Ù.

	CParty *pParty	= g_PartyMng.GetParty( idParty );
	if( pParty )
	{
		int i;
		CUser *pMember;
		D3DXVECTOR3	vDist;
		float	fDist;
		float	fMaxDistSq = (float)pAddSkillProp->dwSkillRange;
		fMaxDistSq *= fMaxDistSq;
		FLOAT fTargetRatio = 0.0f;
		if( pSkillProp->dwSpellRegion == SRO_REGION )
			fTargetRatio = 1.0f;
		for( i = 0; i < pParty->m_nSizeofMember; i++ )
		{
			pMember	= g_UserMng.GetUserByPlayerID( pParty->m_aMember[i].m_uPlayerId );
			if( IsValidObj( pMember ) && !pMember->IsDie()
				&& GetWorld() && pMember->GetWorld() && GetWorld()->GetID() == pMember->GetWorld()->GetID()
				&& GetLayer() == pMember->GetLayer() )	// mirchang_100217 ¹üÀ§ °Ë»ç ¿À·ù ¼öÁ¤
			{
				if( pMember == this && fTargetRatio == 0.0f )	// Å¸°Ùµ¥¹ÌÁö ºñÀ²ÀÌ 0ÀÌ¸é ÀÚ±âÀÚ½Å(Å¸°Ù)Àº µ¥¹ÌÁö¸¦ ÁÖÁö¾ÊÀ½.
				{
				} else
				{
					vDist = pMember->GetPos() - GetPos();
					fDist = D3DXVec3LengthSq( &vDist );			// ÆÄÆ¼ ¸â¹ö¿Í ½ÃÀüÀÚ¿ÍÀÇ °Å¸®.
					if( fDist < fMaxDistSq )					// xx¹ÌÅÍº¸´Ù ÀÛÀ¸¸é
					{
						pMember->ApplySkill( this, pSkillProp, pAddSkillProp, bIgnoreProb );	// ¸â¹ö °¢°¢¿¡°Ô È¿°ú Àû¿ë.
						bRet = TRUE;
					}
				}
			}
		}
	}
#endif // WorldServer
	return bRet;
} // ApplySkillAroundTroupe

//
// ApplySkill ³»ºÎ¿¡¼­ ½ºÅ³ÀÇ ÇÏµåÄÚµù Ã³¸®ºÎ.
// this : Target
// pSrc : ½ÃÀüÀÚ.
//
BOOL CCtrl::ApplySkillHardCoding( CCtrl *pSrc, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp )
{
#ifdef __WORLDSERVER
	switch( pSkillProp->dwID )
	{
	case SI_ASS_HEAL_RESURRECTION:		// ºÎÈ°
#ifdef __NEWCLASS
	case SI_MENTA_U_SKILL_03:
#endif // __NEWCLASS
		if( GetType() == OT_MOVER )
		{
			CMover *pTarget = (CMover *)this;
			if( pTarget->IsPlayer() && pTarget->IsDie() )	// ÇÃ·¹ÀÌ¾îÀÌ°í Å¸°ÙÀÌ Á×¾îÀÖÀ»¶§
			{
				if( pTarget->m_pActMover->GetDmgState() == OBJSTA_RESURRECTION )
				{
					return FALSE;		// ÀÌ¹Ì ºÎÈ°ÁßÀÎ »ç¶÷¿¡°Ô ¾´°Å¶ó¸é Ãë¼Ò.
				} else
				{
					g_dpDBClient.SendLogLevelUp( pTarget, 10 );	// ºÎÈ° ½ºÅ³ ·Î±×

					if( ((CUser *)this)->m_Resurrection_Data.bUseing != TRUE )
					{
						((CUser *)this)->AddResurrectionMessage();
					
						((CUser *)this)->m_Resurrection_Data.bUseing        = TRUE;
						((CUser *)this)->m_Resurrection_Data.dwPlayerID     = ((CMover*)pSrc)->m_idPlayer;
						((CUser *)this)->m_Resurrection_Data.pSkillProp     = pSkillProp;
						((CUser *)this)->m_Resurrection_Data.pAddSkillProp  = pAddSkillProp;
					}

					break;
				}

				// ºÎÈ°¶§ DST_RECOVERY_EXP°¡ ÀÖÀ¸¸é °âÄ¡°¡ Á¶±Ý ±ðÀÓ.
				if( pAddSkillProp->dwDestParam2 == DST_RECOVERY_EXP )
					pTarget->SubDieDecExp(TRUE, pAddSkillProp->nAdjParamVal2 );	// ºÎÈ°ÀÌ µÇ¸é¼­ °âÄ¡°¡ Á¶±Ý ±ðÀÓ.
			}
		}
		break;
	} // switch
#endif // WorldServer
	return TRUE;
}

#ifdef __CLIENT
void CCtrl::CreateYoyoSkill( CSfx* pSfx, CCtrl *pTarget, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp )
{
	ItemProp* pItemProp = ((CMover *)this)->GetActiveHandItemProp();
	
	if(pItemProp)
	{
		D3DXVECTOR3 vPos;
		D3DXVECTOR3 vLocal;
		D3DXVECTOR3 vPosSrc   = GetPos() + D3DXVECTOR3( 0.0f, 1.0f, 0.0f ); // ¹ß»ç ÁöÁ¡À» ÀÓÀÇ·Î ¿Ã·ÁÁØ´Ù. ¶«»§ 
		D3DXVECTOR3 vPosDest  = pTarget->GetPos() + D3DXVECTOR3( 0.0f, 1.0f, 0.0f ); // ¸ñÇ¥ ÁöÁ¡À» ÀÓÀÇ·Î ¿Ã·ÁÁØ´Ù. ¶«»§ 
		
		CModelObject *pModel = (CModelObject *)m_pModel;
		
		int nSkill = pSkillProp->dwID;
		
		switch( nSkill )
		{
		case SI_ACR_SUP_SLOWSTEP:
		case SI_JST_YOYO_HITOFPENYA:
		case SI_JST_YOYO_VATALSTAB:
			{
				pModel->GetHandPos( &vPos, PARTS_RWEAPON, GetMatrixWorld() );
				pSfx = CreateSfxYoYo( D3DDEVICE, pItemProp->dwSfxObj2, vPos, GetId(), vPosDest );	
				((CSfxItemYoyoAtk*)pSfx)->MakePath(PARTS_RWEAPON);
			}
			break;
		case SI_ACR_YOYO_DEADLYSWING:
		case SI_ACR_YOYO_CROSSLINE:
			{
				pModel->GetHandPos( &vPos, PARTS_RWEAPON, GetMatrixWorld() );
				pSfx = CreateSfxYoYo( D3DDEVICE, pItemProp->dwSfxObj2, vPos, GetId(), vPosDest );	
				((CSfxItemYoyoAtk*)pSfx)->MakePath(PARTS_RWEAPON);

				pModel->GetHandPos( &vPos, PARTS_LWEAPON, GetMatrixWorld() );
				pSfx = CreateSfxYoYo( D3DDEVICE, pItemProp->dwSfxObj2, vPos, GetId(), vPosDest );	
				((CSfxItemYoyoAtk*)pSfx)->MakePath(PARTS_LWEAPON);
			}
			break;							
		}
	}

}
#endif //__CLIENT

//
// ½ºÅ³À» ½èÀ»¶§ Å¬¶ó¿¡¼­ »ý¼ºÇØ¾ßÇÒ sfx Ã³¸®
//
void CCtrl::CreateSkillSfx( CCtrl *pTarget, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp )
{
#ifdef __CLIENT
		
	{
		// ¹ß»çÃ¼ ÇüÅÂ°¡ ¾Æ´Ï´Ù.
		CSfx *pSfx = NULL;
		if( (int)pAddSkillProp->dwSkillTime > 0 )	// Áö¼Ó½Ã°£ÀÌ ÀÖ´Â ½ºÅ³Àº
		{
			if( pSkillProp->dwSfxObj4 == NULL_ID )		// ÀÌÆåÀÌ À¯ÁöµÇ´Â ½ºÅ³ÀÌ ¾Æ´Ò°æ¿ì¿¡¸¸.
			{
				if( pSkillProp->dwExeTarget == EXT_MELEEATK )
				{
					D3DXVECTOR3 vLocal;
					
					if( pSkillProp->dwLinkKind == IK3_YOYO )
					{
						vLocal = pTarget->GetPos();
						vLocal.y += 1.0f;
					}
					else
					{
						AngleToVectorXZ( &vLocal, GetAngle(), 1.3f );	// ¶§¸®´Â¹æÇâ 1¹ÌÅÍ¾Õ.
						vLocal += GetPos();
						vLocal.y += 1.0f;
					}

					pSfx = CreateSfx( D3DDEVICE, pSkillProp->dwSfxObj3, GetPos(), GetId(), vLocal, pTarget->GetId(), 0 );
					
					if( pSkillProp->dwSfxObj5 != NULL_ID )		// ½ÃÀüÀÚ¿¡°Ô ¹ß»ý
						pSfx = CreateSfx( D3DDEVICE, pSkillProp->dwSfxObj5, GetPos(), GetId(), this->GetPos(), this->GetId(), 0 );  // 5¹ø ÀÌÆåÆ®¸¦ Ãâ·ÂÇÔ.
				} else
				{
					if( pSkillProp->dwSfxObj3 != NULL_ID )		// Å¸°Ù¿¡°Ô ¹ß»ý
						pSfx = CreateSfx( D3DDEVICE, pSkillProp->dwSfxObj3, GetPos(), GetId(), pTarget->GetPos(), pTarget->GetId(), 0 );  // 3¹ø ÀÌÆåÆ®¸¦ Ãâ·ÂÇÔ.
					if( pSkillProp->dwSfxObj5 != NULL_ID )		// ½ÃÀüÀÚ¿¡°Ô ¹ß»ý
						pSfx = CreateSfx( D3DDEVICE, pSkillProp->dwSfxObj5, GetPos(), GetId(), this->GetPos(), this->GetId(), 0 );  // 5¹ø ÀÌÆåÆ®¸¦ Ãâ·ÂÇÔ.
				}

				if( pSkillProp->dwLinkKind == IK3_YOYO )  //¿ä¿ä´Â ¾ÆÀÌÅÛÇÁ·ÎÆÛÆ¼ÂüÁ¶ÇÏ¿© ÀÌÆåÆ® »ý¼º(¿¹¿ÜÃ³¸®)
				{
				#ifdef __CLIENT
					CreateYoyoSkill( pSfx, pTarget, pSkillProp, pAddSkillProp );
				#endif
				}
			} else
			{
				if( GetType() == OT_MOVER )
				{
					if( pSkillProp->dwSkillType == NULL_ID )	// NULL_ID¸é ¾ÆÀÌÅÛµé
					{
						if( ((CMover *)this)->HasBuff( BUFF_ITEM, (WORD)( pSkillProp->dwID ) ) == FALSE )	// ÀÌ¹Ì ½ÇÇàµÇ°í ÀÖÁö ¾ÊÀ»¶§¸¸ ÀÌÆå Ãâ·Â
							CreateSfx( D3DDEVICE, pSkillProp->dwSfxObj4, this->GetPos(), this->GetId(), pTarget->GetPos(), pTarget->GetId(), (int)(pAddSkillProp->dwSkillTime / 1000.0f) );
					} else
					{
						// ÀÌ¹Ì ½ÇÇàµÇ°í ÀÖÁö ¾ÊÀ»¶§¸¸ ÀÌÆå Ãâ·Â
						if( ((CMover *)this)->HasBuff( BUFF_SKILL, (WORD)( pSkillProp->dwID ) ) == FALSE
							&& pSkillProp->dwID != SI_MER_SHIELD_PROTECTION && pSkillProp->dwID != SI_MER_SHIELD_PANBARRIER )	// 091022 mirchang - ¿©±â¼­ ¸ÕÀú »ý¼º ÈÄ IBuff.Process¿¡¼­ sfx¸¦ ´Ù½Ã »ý¼ºÇÏ´Â ¹®Á¦ ¹ß»ý. ¶«»§.
							CreateSfx( D3DDEVICE, pSkillProp->dwSfxObj4, this->GetPos(), this->GetId(), pTarget->GetPos(), pTarget->GetId(), (int)(pAddSkillProp->dwSkillTime / 1000.0f) );
					}
				}
			}
		} else
		{	// Áö¼Ó½Ã°£ ¾ø´Â ½ºÅ³
			if( pSkillProp->dwExeTarget == EXT_MELEEATK )	// ±ÙÁ¢°ø°Ý ½ºÅ³ÀÇ Å¸°Ý ÀÌÆåÆ®.
			{
				if( pSkillProp->dwSfxObj3 != NULL_ID )	
				{
					D3DXVECTOR3 vLocal;

					if( pSkillProp->dwLinkKind == IK3_YOYO )
					{
						vLocal = pTarget->GetPos();
						vLocal.y += 1.0f;
					}
					else
					{
						AngleToVectorXZ( &vLocal, GetAngle(), 1.3f );	// ¶§¸®´Â¹æÇâ 1¹ÌÅÍ¾Õ.
						vLocal += GetPos();		// GetPos()¸¦ this¿¡¼­ pTargetÀ¸·Î ¹Ù²å´Ù. 2006/6/20 xuzhu.
						vLocal.y += 1.0f;
					}

					pSfx = CreateSfx( D3DDEVICE, pSkillProp->dwSfxObj3, vLocal, GetId(), vLocal, pTarget->GetId(), 0 );	// 2006/6/20 xuzhu °¡ ¹Ù²Þ.
				}
			} else
			{
				if( pSkillProp->dwSfxObj3 != NULL_ID )
				{
					D3DXVECTOR3 vPos = pTarget->GetPos();
					vPos.y += 1.0f;
					pSfx = CreateSfx( D3DDEVICE, pSkillProp->dwSfxObj3, GetPos(), GetId(), vPos, pTarget->GetId(), 0 );
				}
			}

			if( pSkillProp->dwLinkKind == IK3_YOYO )  //¿ä¿ä´Â ¾ÆÀÌÅÛÇÁ·ÎÆÛÆ¼ÂüÁ¶ÇÏ¿© ÀÌÆåÆ® »ý¼º(¿¹¿ÜÃ³¸®)
			{
			#ifdef __CLIENT
				CreateYoyoSkill( pSfx, pTarget, pSkillProp, pAddSkillProp );
			#endif
			}
			else
			if( pSkillProp->dwSfxObj5 != NULL_ID )		// ½ÃÀüÀÚ¿¡°Ô ¹ß»ý
				pSfx = CreateSfx( D3DDEVICE, pSkillProp->dwSfxObj5, GetPos(), GetId(), this->GetPos(), this->GetId(), 0 );  // 5¹ø ÀÌÆåÆ®´Â ½ÃÀüÀÚ ÀÚ½Å¿¡°Ô Ãâ·Â
		}
		if( pSfx )
		{
			D3DXVECTOR3 vPos = GetPos();
			PLAYSND( pSkillProp->dwSndAttack1, &vPos );		// ¹ß»ç È¿°úÀ½.
		}
			
		//dwSkillRange
		if( pSkillProp->dwID == SI_GEN_FLASH && pSfx )
		{
			FLOAT fRange = 1.5f;
			pSfx->SetScale(  D3DXVECTOR3(fRange, fRange, fRange) );
		}
	}
	
#endif // Client
} // CreateSkillSfx


// ApplySkill ³»ºÎ¿¡¼­ µ¥¹ÌÁö ÁÖ´ÂºÎºÐ¸¸ ºüÁü.
#ifdef __NO_HP_DMG_LIMIT
long long CCtrl::ApplyDamage(CCtrl* pSrc, ItemProp* pSkillProp, AddSkillProp* pAddSkillProp, int nParam, BOOL bTarget)
#else
int		CCtrl::ApplyDamage(CCtrl* pSrc, ItemProp* pSkillProp, AddSkillProp* pAddSkillProp, int nParam, BOOL bTarget)
#endif 
{
#ifdef __NO_HP_DMG_LIMIT
	long long nDamage = 0;
#else
	int nDamage = 0;
#endif
	// µ¥¹ÌÁö·ù ½ºÅ³ÀÇ µ¥¹ÌÁö Àü´Þ.
	switch( pSkillProp->dwExeTarget )
	{
	case EXT_MELEEATK:		// ±ÙÁ¢½ºÅ³µ¥¹ÌÁö°ø°Ý
	case EXT_MAGICATK:			// Áï½Ã¸¶¹ýµ¥¹ÌÁö°ø°Ý
	case EXT_MAGICATKSHOT:
		{
			if( pSkillProp->dwID == SI_MAG_FIRE_HOTAIR )	// ÇÖ¿¡¾î ¶«»§Ã³¸®.
			{
				nDamage = SendDamage( AF_MAGICSKILL, pSrc->GetId(), nParam, bTarget );
			} else
			{
				int nAtkFlag = 0;
				if( pSkillProp->dwSkillType == KT_MAGIC )
					nAtkFlag = AF_MAGICSKILL;
				else
					nAtkFlag = AF_MELEESKILL;
				
				if( pSkillProp->dwComboStyle == CT_FINISH )		nDamage = SendDamageForce( nAtkFlag, pSrc->GetId(), (pSkillProp->dwID << 16) | pAddSkillProp->dwSkillLvl, bTarget );
				else											nDamage = SendDamage( nAtkFlag, pSrc->GetId(), (pSkillProp->dwID << 16) | pAddSkillProp->dwSkillLvl, bTarget );
			}
		}
		break;
	}

	return nDamage;
}

// Àû¿ë°¡´ÉÇÑ ½ºÅ³ÀÌ³Ä?
BOOL CCtrl::IsPossibleApplySkill( CCtrl *pSrc, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp )
{
	return TRUE;
}

// pSkillPropÀ» this¿¡ Àû¿ëÇÑ´Ù.  µ¥¹ÌÁö°¡ µÉ¼öµµ ÀÖ°í. »óÅÂº¯È­°¡ µÉ¼öµµÀÖ´Ù.
// pSrc´Â ½ÃÀüÀÚ(È¤Àº ¾îÅÂÄ¿)
// pAddSkillPropÀº NULLÀÏ¼öµµ ÀÖÀ½À» ÁÖÀÇ.
void	CCtrl::ApplySkill( CCtrl *pSrc, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp, bool bIgnoreProb, int nParam, BOOL bOnlyDmg, BOOL bTarget )
{
#ifdef __PK_PVP_SKILL_REGION
	if( pSrc->GetType() == OT_MOVER && GetType() == OT_MOVER )
	{
		if( ((CMover *)pSrc)->IsPlayer() && ((CMover *)this)->IsPlayer() && pSkillProp->dwSkillType != NULL_ID )
		{
			DWORD dwPKRegionAttr = ((CMover *)this)->GetPKPVPRegionAttr();
			int nAttackerPK = ((CMover *)pSrc)->IsPKPVPInspectionBase( dwPKRegionAttr, FALSE );
			int nDefenDerPK = ((CMover *)this)->IsPKPVPInspectionBase( dwPKRegionAttr, FALSE );
			if( nAttackerPK == 1 || nDefenDerPK == 1 )
			{
				if( pSkillProp->nEvildoing < 0 )
				{
					CMover* pAttacker = (CMover*)pSrc;
					CMover* pDefender = (CMover*)this;
					if( !(pAttacker->IsPVPTarget( pDefender ) || 
						pAttacker->IsWarTarget( pDefender ) ||
						pAttacker->IsGuildCombatTarget( pDefender )
#ifdef __JEFF_11_4
						|| pAttacker->IsArenaTarget( pDefender )
#endif	// __JEFF_11_4
#ifdef __DEATH_MATCH
						|| pAttacker->IsSiegeTarget(pDefender)
#endif // __DEATH_MATCH
						) )
							return;
					
					//if( !((CMover *)pSrc)->IsPVPTarget((CMover *)this) )
					//	return;
				}
			}
		}
	}
#endif // __PK_PVP_SKILL_REGION

	if( IsPossibleApplySkill( pSrc, pSkillProp, pAddSkillProp ) == FALSE )
		return;

#ifdef __MINES_BOMBS	
	//Apply ContPain & Bomb Active Skills
	if (pSkillProp->tmContinuousPain != NULL_ID || (pAddSkillProp && pAddSkillProp->dwBombMine != NULL_ID))
	{
		if (pSkillProp->dwActiveSkill != NULL_ID)
			pSrc->DoActiveSkill(pSkillProp->dwActiveSkill, 1, this, false, false);
}
#endif __MINES_BOMBS	

#ifdef __NO_HP_DMG_LIMIT
	long long nDamage = ApplyDamage(pSrc, pSkillProp, pAddSkillProp, nParam, bTarget);
#else
	int nDamage = ApplyDamage(pSrc, pSkillProp, pAddSkillProp, nParam, bTarget);
#endif
	if( bOnlyDmg == TRUE )		
		return;

#if __VER >= 10	// __AI_0711

	if( GetType() == OT_MOVER )
	{
		if( ( (CMover*)this )->IsRank( RANK_MIDBOSS ) )
		{
			// ¸é¿ª ÀÌÆåÆ®
			return;
		}
	}
#endif	// __AI_0711

#if defined(__WORLDSERVER)
	if( this != pSrc && pSrc->GetType() == OT_MOVER && GetType() == OT_MOVER )		// ±¤¿ª µð¹öÇÁ Áß Å¸°ÙÀÌ¾Æ´Ï¸é skip
	{
		if( ((CMover *)this)->IsDie() == FALSE )
		{
#if __VER >= 8 // __S8_PK
			if( pSkillProp->nEvildoing < 0 )													// ³ª»Û¸¶¹ýÀº
				if( ((CMover *)pSrc)->GetHitType2(((CMover *)this), bTarget, FALSE ) == HITTYPE_FAIL )  	// ÆòÈ­ÀûÀÎ»ó´ë¿¡°Ô
					return;																			// Àû¿ë¾ÈµÊ
#ifdef __JEFF_11_4
			CWorld* pWorld	= pSrc->GetWorld();
#ifdef __GAMEMASTER
			if (pWorld && pWorld->IsArena() == FALSE && !((CMover*)pSrc)->IsAuthHigher(AUTH_GAMEMASTER3))		// ¾Æ·¹³ª°¡ ¾Æ´Ï¸é,
#else // __GAMEMASTER
			if (pWorld && pWorld->IsArena() == FALSE)		// ¾Æ·¹³ª°¡ ¾Æ´Ï¸é,
#endif // __GAMEMASTER
#endif	// __JEFF_11_4
			{
				if( pSkillProp->nEvildoing > 0 )													// ÁÁÀº ¸¶¹ýÀº
					if( ((CMover *)pSrc)->GetHitType2(((CMover *)this), bTarget, TRUE ) != HITTYPE_FAIL )  	// Àû´ëÀûÀÎ»ó´ë¿¡°Ô
						return;																			// Àû¿ë¾ÈµÊ
			}
#else // __VER >= 8 // __S8_PK
			if( pSkillProp->nEvildoing < 0 )													// ³ª»Û¸¶¹ýÀº
				if( ((CMover *)pSrc)->GetHitType2(((CMover *)this), bTarget ) == HITTYPE_FAIL )  	// ÆòÈ­ÀûÀÎ»ó´ë¿¡°Ô
					return;																			// Àû¿ë¾ÈµÊ
			if( pSkillProp->nEvildoing > 0 )													// ÁÁÀº ¸¶¹ýÀº
				if( ((CMover *)pSrc)->GetHitType2(((CMover *)this), bTarget ) != HITTYPE_FAIL )  	// Àû´ëÀûÀÎ»ó´ë¿¡°Ô
					return;																			// Àû¿ë¾ÈµÊ
#endif // __VER >= 8 // __S8_PK
		}
		else
		{
			if( pSkillProp->dwExeTarget != EXT_MAGICATKSHOT )
				if( pSkillProp->dwSfxObj2 != NULL_ID )
					g_UserMng.AddCreateSfxObj( this, pSkillProp->dwSfxObj2 );
			
			if( pSkillProp->nEvildoing < 0 )
				return;
		}
	}
#ifdef __INSTANCE_AGGRO_SYSTEM
	CreateAggro( pSrc, pSkillProp, pAddSkillProp );
#endif // __INSTANCE_AGGRO_SYSTEM
#endif //defined(__WORLDSERVER)

	int nProb	= pSkillProp->nProbability;
	if( pAddSkillProp )
	{
		nProb	= pAddSkillProp->nProbability;
#if __VER >= 9	// __SKILL_0706
		BOOL bPVP	= ( pSrc->GetType() == OT_MOVER && ( (CMover *)pSrc )->IsPlayer() && GetType() == OT_MOVER && ( (CMover *)this )->IsPlayer() );
		if( bPVP )
			nProb	= pAddSkillProp->nProbabilityPVP;
#endif	// __SKILL_0706
	}

	if( bIgnoreProb )	// È®·ü¹«½Ã¿ÉÀÌ ÀÖÀ¸¸é ¹«Á¶°Ç 100%
		nProb = NULL_ID;
	
	if( nProb == NULL_ID || (int)( xRandom(100) ) < nProb  )		// Àû¿ë È®·ü, =·Î µÇ¾î ÀÖÀ¸¸é 100% Àû¿ë
	{
		if( GetType() == OT_MOVER )		// Å¸°ÙÀÌ ¹«¹öÀÏ¶§¸¸ Áö¼Ó½Ã°£ Ã³¸®
		{
			int nSkillTime = 0;
			if( pAddSkillProp )		
				nSkillTime = (int)pAddSkillProp->dwSkillTime;
			else					
				nSkillTime = (int)pSkillProp->dwSkillTime;

			BOOL bNew = TRUE;	// ½ºÅ³ÀÌ Ã· Àû¿ëµÆ´Â°¡.
#if __VER >= 8 //__Y_FLAG_SKILL_BUFF
			if( nSkillTime >= 0 )	// Áö¼Ó½Ã°£ÀÌ ÀÖ´Â ½ºÅ³(ÇÁ·ÎÅØ¼Ç µî)
#else //__Y_FLAG_SKILL_BUFF
			if( nSkillTime > 0 )	// Áö¼Ó½Ã°£ÀÌ ÀÖ´Â ½ºÅ³(ÇÁ·ÎÅØ¼Ç µî)					
#endif //__Y_FLAG_SKILL_BUFF
			{
				DWORD dwTime1 = 0, dwTime2 = 0;
				if( pSkillProp->dwReferTarget1 == RT_TIME || pSkillProp->dwReferTarget2 == RT_TIME )
				{
					if( pSrc->GetType() == OT_MOVER )		// ½ÃÀüÀÚ°¡ ¹«¹öÀÏ¶§¸¸.
						((CMover *)pSrc)->SubReferTime( &dwTime1, &dwTime2, pSkillProp, pAddSkillProp );
				}

				WORD wType;
				if( pSkillProp->dwSkillType == NULL_ID )	
					wType = BUFF_ITEM;
				else										
					wType = BUFF_SKILL;

				// pTargetÀº this°¡ µÉ¼öµµÀÖ°í Å¸ÀÎÀÌ µÉ¼öµµ ÀÖ´Ù.
			#if defined(__WORLDSERVER)
				int nLevel = 0;
				if( pAddSkillProp )		
					nLevel = pAddSkillProp->dwSkillLvl;
				else					
					nLevel = 0;

				// dwSkillTimeÀÌ ½ºÅ³ÀÚÃ¼ÀÇ Áö¼Ó½Ã°£À¸·Îµµ ¾²ÀÌ°í ºÎ°¡È¿°úÀÇ Áö¼Ó½Ã°£À¸·Îµµ ¾²ÀÌ±â¶§¹®¿¡ ÀÌ·±±¸Á¶´Â ¸ÂÁö ¾Ê´Ù
				// ÀÌ´ë·Î¶ó¸é ¹ö´×ÇÊµåµµ ¹öÇÁÃ³·³ °É·Á¹ö¸°´Ù.
				// bNew = ((CMover *)this)->m_SkillState.Set( wType, pSkillProp->dwID, nLevel, nSkillTime + (int)dwTime1 + (int)dwTime2 );	
				if( pSkillProp->dwID == SI_ELE_FIRE_BURINGFIELD )
					bNew = FALSE;	//  ¹ö´×ÇÊµå´Â ¿¹¿ÜÃ³¸® 
				else
#ifdef __PVPDEBUFSKILL
					bNew	= static_cast<CMover*>( this )->AddBuff( wType, (WORD)( pSkillProp->dwID ), nLevel, nSkillTime + (int)dwTime1 + (int)dwTime2, pSrc->GetId() );
#else // __PVPDEBUFSKILL
					bNew = ((CMover *)this)->m_SkillState.Set( wType, pSkillProp->dwID, nLevel, nSkillTime + (int)dwTime1 + (int)dwTime2 );	
#endif // __PVPDEBUFSKILL

				
			#elif defined(__CLIENT)
				bNew = ((CMover *)this)->HasBuff( wType, (WORD)( pSkillProp->dwID ) ) ? FALSE : TRUE;
			#endif // Client
			}
			
			// ÃÖÃÊ Àû¿ëµÈ ½ºÅ³¿¡¸¸
			if( bNew )	// ÀÌ¹Ì °É·ÁÀÖ´Â »óÅÂ¿¡¼­ ¶Ç ¾²¸é bNew´Â FALSE°¡ µÈ´Ù.
			{
			#ifdef __WORLDSERVER
				// ½ºÅ³Áß ¿¹¿ÜÃ³¸® ÇØ¾ßÇÒ°ÍÀ» Ã³¸®ÇÔ.
				if( ApplySkillHardCoding( pSrc, pSkillProp, pAddSkillProp ) == FALSE )
					return;

				// ºÎÈ°½ºÅ³¼ÂÆÃÀÌ µÇ¾îÀÖ´Ù¸é ¾Æ·§°Íµé ¹«½Ã
				if( ((CMover *)this)->m_Resurrection_Data.bUseing )
					return;

				// µ¥¹ÌÁöµµ ÁÖ¸é¼­ ÆÄ¶ó¸ÞÅÍµµ º¯ÇÏ´Â ½ºÅ³ÀÌ ÀÖ±â¶«¿¡ µ¥¹ÌÁö¶û µû·Î Ã³¸®.
				switch( pSkillProp->dwExeTarget )
				{
				case EXT_SELFCHGPARAMET:		// ½ÃÀüÀÚ ÀÚ½Å.
					if( pSrc->GetType() == OT_MOVER )	// Å¸°Ù(¿©±â¼± Å¸°ÙÀÌ ½ÃÀüÀÚ)ÀÌ ¹«¹öÀÏ¶§¸¸...
						((CMover *)pSrc)->ApplyParam( (CMover *)pSrc, pSkillProp, pAddSkillProp, TRUE, nDamage );
					break;
				case EXT_OBJCHGPARAMET:
				case EXT_MAGIC:
				case EXT_ANOTHER:
				case EXT_ANOTHERWITH:
				default:
					if( this->GetType() == OT_MOVER )	// Å¸°ÙÀÌ ¹«¹öÀÏ¶§¸¸.
						((CMover *)this)->ApplyParam( (CMover *)pSrc, pSkillProp, pAddSkillProp, TRUE , nDamage );
					break;
				}

				if( this->GetType() == OT_MOVER )
				{
					// ¹Ð¸®´Â ¾çÀÌ ÀÖ´Â°¡?
					CMover *pTarget = (CMover *)this;
					DWORD dwDmgShift;
					if( pAddSkillProp )
						dwDmgShift = pAddSkillProp->dwDmgShift;
					else
						dwDmgShift = pSkillProp->dwDmgShift;

					if( dwDmgShift != NULL_ID && pTarget->GetProp()->dwClass != RANK_SUPER && pTarget->GetProp()->dwClass != RANK_MIDBOSS )
					{
						FLOAT fAngle = GetDegree( pTarget->GetPos(), pSrc->GetPos() );	// ½ÃÀüÀÚ¿Í Å¸°ÙÀÇ °¢µµ¸¦ ±¸ÇÔ
						AngleToVectorXZ( &pTarget->m_pActMover->m_vDeltaE, fAngle, 0.85f );
						g_UserMng.AddPushPower( pTarget, pTarget->GetPos(), pTarget->GetAngle(), fAngle, 0.85f );
					}
					
					// »ó´ë¹æÀ» ²ø¾î´ç±ä´Ù
					if( pSkillProp->dwID == SI_ACR_YOYO_PULLING
#ifdef __3RD_LEGEND16	
						|| pSkillProp->dwID == SI_LOD_SUP_PULLING
#endif // __3RD_LEGEND16
						)
					{
						if( pAddSkillProp && pAddSkillProp->nDestData1[2] != NULL_ID )
						{
							// ´ç°ÜÁú °Å¸®
							FLOAT fPullingLen = (FLOAT)pAddSkillProp->nDestData1[2] * 0.001f; 
							
							// Å¸°Ù°úÀÇ °Å¸®
							D3DXVECTOR3 v3Len = pTarget->GetPos() - pSrc->GetPos();
							FLOAT fTotalLen = D3DXVec3LengthSq( &v3Len ) * 0.1f;
							{
								if( fTotalLen > ((CMover*)this)->GetAttackRange( AR_HRANGE ) )
									fTotalLen = ((CMover*)this)->GetAttackRange( AR_HRANGE );

								// °Å¸®¿¡ µû¶ó ´ó°ÜÁö´Â ÈûÀÌ ´Ù¸£°Ô Àû¿ëµÊ
								FLOAT fDest = fTotalLen / ((CMover*)this)->GetAttackRange( AR_HRANGE );
								{
									// ½ÇÁ¦¶¯°ÜÁú °Å¸® °è»ê
									FLOAT fAngle = GetDegree( pTarget->GetPos(), pSrc->GetPos() );	// ½ÃÀüÀÚ¿Í Å¸°ÙÀÇ °¢µµ¸¦ ±¸ÇÔ
									AngleToVectorXZ( &pTarget->m_pActMover->m_vDeltaE, fAngle, fPullingLen * -fDest);
									g_UserMng.AddPushPower( pTarget, pTarget->GetPos(), pTarget->GetAngle(), fAngle, fPullingLen * -fDest );
								}
							}
						}
					}
				}
			#endif // __WORLDSERVER
			} // if( bNew )

		#ifdef __WORLDSERVER
			if( pSkillProp->dwID == SI_GEN_FLASH && GetType() == OT_MOVER && ((CMover *)this)->IsPlayer() )
			{
				((CUser *)this)->AddCommonSkill( pSkillProp->dwID, pAddSkillProp->dwSkillLvl );
			}
		#endif // __WORLDSERVER
		
		}	// this == OT_MOVER
	}	// if( nProb == NULL_ID || xRandom(100) < nProb  )
#ifdef __WORLDSERVER
	#if __VER >= 11 // __MA_VER11_06				// È®À²½ºÅ³ È¿°ú¼öÁ¤ world,neuz
	else
	{
		if(pSkillProp->dwID == SI_PSY_HERO_STONE )
			g_UserMng.AddRemoveSfxObj( this, pSkillProp->dwSfxObj4 );
	}
	#endif // __MA_VER11_06				// È®À²½ºÅ³ È¿°ú¼öÁ¤ world,neuz
#endif	//__WORLDSERVER
	#ifdef __WORLDSERVER
		switch( pSkillProp->dwSpellRegion )
		{
#ifdef __YDEBUG
		case SRO_DIRECT:
#endif //__YDEBUG
		case SRO_AROUND:
		case SRO_REGION:	// ¹üÀ§°ø°ÝÀÏ¶© ¿©±â¼­ Å¸°Ùµé °¢°¢¿¡ sfxobj3¸¦ »Ñ·ÁÁÜ.
			if( pSkillProp->dwExeTarget != EXT_MAGICATKSHOT )
				if( pSkillProp->dwSfxObj2 != NULL_ID )
					g_UserMng.AddCreateSfxObj( this, pSkillProp->dwSfxObj2 );
			break;
		}

		// ¿¹¿ÜÃ³¸®: °­Å»½ºÅ³ - Æä³Ä¸¦ ÈÉÄ¡¸é¼­ µ¥¹ÌÁö¸¦ ÁØ´Ù
		if( pSkillProp->dwID == SI_ACR_YOYO_SNITCH )
		{
			// pSrc - °ø°ÝÀÚ ÇÃ·¹ÀÌ¾î, this - ÇÇ°ø°ÝÀÚ ¸ó½ºÅÍ 
			// ÇÇ°ø°ÝÀÚ ÀÜ¾×ÀÌ 0ÀÌ ¾Æ´Ï¸é °­Å» ÇÑ´Ù.
			CUser* pUser = (CUser*)pSrc;
			CUser* pDest = (CUser*)this;
			if( pDest->GetType() == OT_MOVER && pDest->GetGold() > 0 )
			{
				int nPlus = (pDest->GetLevel()*20) - (pUser->GetLevel()*10);
				
				if( pUser->GetLevel() <= 20 )
				{
				}
				else
				if( pUser->GetLevel() <= 30 )
				{
					nPlus	= (int)( nPlus * 0.7f );
				}
				else
				if( pUser->GetLevel() <= 40 )
				{
					nPlus	= (int)( nPlus * 0.5f );
				}
				else
				{
					nPlus	= (int)( nPlus * 0.3f );
				}
		
				if( nPlus > 0 )
				{				
					nPlus = min( nPlus, pDest->GetGold() );		// ÇÇ°ø°ÝÀÚ µ· º¸´Ù´Â ¸¹Áö ¾Ê°Ô 
					pUser->AddGold( nPlus );
					pDest->AddGold( -nPlus );

					pUser->AddGoldText( nPlus );
				}
			}		
		}
	#endif	//__WORLDSERVER
} // ApplySkill
#ifdef __INSTANCE_AGGRO_SYSTEM
#ifdef __WORLDSERVER
void	CCtrl::CreateAggro( CCtrl *pSrc, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp )
{
	int nRange	= 48;	// scan range
	float fDistSq;

	CMover *pMover = (CMover *)pSrc; // Player
	CMover *pTarget = (CMover *)this; // target
	CMover *pCastTarget; // Monster
	MoverProp *pTargetProp = pTarget->GetProp();

	CObj* pObj;
	D3DXVECTOR3 vPos = pMover->GetPos();
	D3DXVECTOR3 vDist;

	if( pMover->IsPlayer() && pTarget != pMover ) // only player can generate aggro
	{
		if( pSkillProp->IsAlwaysAggro() )
			pTarget->PostAIMsg( AIMSG_DAMAGE, pMover->GetId(), 0, 1 );
		else
		if( pSkillProp->IsDebuff() && !pTarget->IsPlayer() && pTarget->GetProp()->dwAI >= AII_AGGRO_NORMAL )
			pTarget->PostAIMsg( AIMSG_DAMAGE, pMover->GetId(), pSkillProp->dwID, 2 );
        else
		if( pSkillProp->IsHeal() && pTarget->IsPlayer() )
		{
			FOR_LINKMAP( GetWorld(), vPos, pObj, nRange, CObj::linkDynamic, GetLayer() ) // get everyone in range
			{ 
				if( pObj->GetType() == OT_MOVER && ((CMover *)pObj)->IsPeaceful() == FALSE && !((CMover *)pObj)->IsPlayer() ) // is mover, not npc and not player
				{
					vDist = pTarget->GetPos() - vPos;
					fDistSq = D3DXVec3LengthSq( &vDist );
					if( fDistSq < 48.0f * 48.0f )
					{
						pCastTarget = (CMover *)pObj;
						MoverProp *pCastTargetProp = pCastTarget->GetProp();
						if ( pCastTargetProp->dwAI >= AII_AGGRO_NORMAL ) // is instance monster
						{
							if( IsValidObj( (CObj*)pCastTarget ) && pCastTarget->IsLive() )
							{
								pCastTarget->PostAIMsg( AIMSG_SKILLSUPPORT, pMover->GetId(), pSkillProp->dwID, pTarget->GetId() );
							}
						}
					}
				}
			}
			END_LINKMAP
		}else
		if( pSkillProp->IsBuff() && pTarget->IsPlayer() )
		{
			FOR_LINKMAP( GetWorld(), vPos, pObj, nRange, CObj::linkDynamic, GetLayer() ) // get everyone in range
			{ 
				if( pObj->GetType() == OT_MOVER && ((CMover *)pObj)->IsPeaceful() == FALSE && !((CMover *)pObj)->IsPlayer() ) // is mover, not npc and not player
				{
					vDist = pTarget->GetPos() - vPos;
					fDistSq = D3DXVec3LengthSq( &vDist );
					if( fDistSq < 48.0f * 48.0f )
					{
						pCastTarget = (CMover *)pObj;
						MoverProp *pCastTargetProp = pCastTarget->GetProp();
						if ( pCastTargetProp->dwAI >= AII_AGGRO_NORMAL ) // is instance monster
						{
							if( IsValidObj( (CObj*)pCastTarget ) && pCastTarget->IsLive() )
							{
								pCastTarget->PostAIMsg( AIMSG_SKILLSUPPORT, pMover->GetId(), pSkillProp->dwID, pTarget->GetId() );
							}
						}
					}
				}
			}
			END_LINKMAP
		}
	}
}
#endif // __WORLDSERVER
#endif // __INSTANCE_AGGRO_SYSTEM

// ¹ß»çÇüÅÂÀÇ ½ºÅ³ÀÇ ¹ß»çÃ¼¸¦ »ý¼ºÇÏ´Â ºÎºÐ
// ÀÌ ¹ß»çÃ¼°¡ Å¸°Ù¿¡°Ô ¸Â¾ÒÀ»¶§ DoApplySkill()ÀÌ ¹ßµ¿µÈ´Ù.
int		CCtrl::ShootSkill( CCtrl *pTarget, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp )
{
#ifdef __CLIENT
	// ¹ß»çÇüÅÂ°¡ ¾Æ´Ï¸é ¸®ÅÏ
	if( pSkillProp->dwExeTarget != EXT_MAGICATKSHOT 
		&& pSkillProp->dwExeTarget != EXT_MAGICSHOT 
		)	// ¹ß»çÃ¼ sfx »ý¼º.
		return 0;

	DWORD dwShootObj;
	{
		dwShootObj = pSkillProp->dwSfxObj2;
	}

	if( dwShootObj != NULL_ID )
	{
		D3DXVECTOR3 vPos = GetPos();
		
		if( ((CMover*)this)->IsPlayer() )		
		{
			// º¸¿ì¿¡¼­ ³ª°¡´Â È­»ìÀº ¸î°¡Áö ¼ÂÆÃÀ» ÇØÁÖÀÚ
			if( pSkillProp->dwLinkKind == IK3_BOW )
			{
				// È­»ìÀº ¿Þ¼Õ¿¡ ¿¬°á...
				CModelObject *pModel = (CModelObject *)m_pModel;
				pModel->GetHandPos( &vPos, PARTS_LWEAPON, GetMatrixWorld() );		// ÁÖ¸Ô ¿ùµåÁÂÇ¥ ±¸ÇÔ		
				vPos.y -=	1.0f;
			}
		}
		
		CSfxShoot *pShootSfx = CreateShootSfx( D3DDEVICE, dwShootObj, vPos, GetId(), D3DXVECTOR3(0,0,0), pTarget->GetId() );
		if( pShootSfx )
		{		
			D3DXVECTOR3 vPos = GetPos();
			PLAYSND( pSkillProp->dwSndAttack1, &vPos );		// ¹ß»ç È¿°úÀ½.
			
			if( GetType() == OT_MOVER )
			{
				if( ((CMover *)this)->IsActiveMover() )		// g_pPlayer°¡ ½ò¶§¸¸ »ý¼ºÇØ¼­ Àü¼Û.
				{
					int idSfxHit = ++(((CMover *)this)->m_idSfxHit);	// Å¬¶ó¿¡¼­ ¹ß»çÃ¼°¡ »ý¼ºµÈ Áï½Ã ID¸¦ ¸¸µé°í ±×°ÍÀ» ¼­¹ö·Î º¸³¿.
					int		nMaxDmgCnt = 1;
					if( pSkillProp->tmContinuousPain != NULL_ID )		// Áö¼Ó½ºÅ³ÀÌ ÀÖ´Â µ¥¹ÌÁö ÇüÅÂ¸é
						nMaxDmgCnt = (pAddSkillProp->dwSkillTime / pAddSkillProp->dwPainTime) + 1;		// ¸î¹ø µ¥¹ÌÁö¸¦ ¸Ô³Ä.
					
					if( pSkillProp->dwSkillType == KT_SKILL )
						g_DPlay.SendSfxID( pTarget->GetId(), idSfxHit, AF_MELEESKILL, NULL_ID, nMaxDmgCnt );
					else
						g_DPlay.SendSfxID( pTarget->GetId(), idSfxHit, AF_MAGICSKILL, NULL_ID, nMaxDmgCnt );
					pShootSfx->m_idSfxHit	= idSfxHit;
				}
			}
			pShootSfx->SetSkill( pSkillProp->dwID );
			pShootSfx->m_nMagicPower	= pAddSkillProp->dwSkillLvl;	// ½ºÅ³·¹º§Àº MagicPowerº¯¼ö·Î °°ÀÌ½áµµ µÉ°Å °°´Ù.
			pShootSfx->m_dwSfxHit = pSkillProp->dwSfxObj3;	// Æø¹ß ÀÌÆåÆ® µî·Ï.

		}
		// Áö¼Ó½Ã°£µ¿¾È ÀÌÆåÆ®µµ À¯ÁöµÇ¾î¾ß ÇÏ´Â°ÍÀº CSkillInfluence::Process()¿¡¼­ Ã³¸®ÇÑ´Ù.
	} else
		Error( "ShootSkill MAGICATKSHOT : %s dwSfxObj2°¡ ÁöÁ¤µÇÁö ¾ÊÀ½", pSkillProp->szName );
#endif // CLIENT
	return 1;
}


// ¹üÀ§Àû¿ë½Ã Å¸°ÙÀÇ Á¾·ù¿¡ µû¶ó ÁÖº¯ Å¸°ÙÀÇ Á¾·ù¸¦ ¼±ÅÃÇÔ.
int		CCtrl::TargetSelecter( CCtrl *pTarget )
{
	int nApplyType = 0;
	CCtrl *pSrc = this;

	if( pTarget->GetType() == OT_MOVER )	// Å¸°ÙÀÌ ¹«¹öÀÏ¶§
	{
		nApplyType = OBJTYPE_PLAYER | OBJTYPE_MONSTER;	// ÁÖÀ§ ÇÃ·¹ÀÌ¾îµé/¸ó½ºÅÍ¿¡°Ô Àû¿ë
	}
	else
	{
		// Å¸°ÙÀÌ ÄÁÆ®·ÑÀÏ¶©
		if( pSrc->GetType() == OT_MOVER )	// °ø°ÝÀÚ°¡ ¹«¹ö³Ä
		{
			if( ((CMover *)pSrc)->IsPlayer() )		// °ø°ÝÀÚ°¡ ÇÃ·¹ÀÌ¾î¸é
				nApplyType = OBJTYPE_PLAYER | OBJTYPE_CTRL | OBJTYPE_MONSTER;	// ÁÖÀ§ ¸ó½ºÅÍ¿Í ÄÁÆ®·Ñ¿¡°Ô Àû¿ë.
		}
		else
		{	// °ø°ÝÀÚ°¡ ÄÁÆ®·ÑÀÌ³Ä
			nApplyType = OBJTYPE_PLAYER;	// ÇÃ·¹ÀÌ¾î¿¡°Ô Àû¿ë
		}
	}

	return nApplyType;
}

#if __VER >= 8 // __S8_PK
int		CCtrl::DoApplySkill( CCtrl *pTarget, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp, bool bIgnoreProb, int nParam, BOOL bOnlyDmg, BOOL bControl )
#else // __VER >= 8 // __S8_PK
int		CCtrl::DoApplySkill( CCtrl *pTarget, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp, bool bIgnoreProb, int nParam, BOOL bOnlyDmg )
#endif // __VER >= 8 // __S8_PK
{
#if __VER >= 8 // __S8_PK
	int nResult = DoApplySkillEx( pTarget, pSkillProp, pAddSkillProp, bIgnoreProb, nParam, bOnlyDmg, bControl );
#else // __VER >= 8 // __S8_PK
	int nResult = DoApplySkillEx( pTarget, pSkillProp, pAddSkillProp, bIgnoreProb, nParam, bOnlyDmg );
#endif // __VER >= 8 // __S8_PK
	if( nResult == 1 )
	{
	#if defined(__WORLDSERVER)	
		if( this != pTarget && GetType() == OT_MOVER && pTarget->GetType() == OT_MOVER )
		{
			if( pSkillProp->nEvildoing < 0 )	// ³ª»Û¸¶¹ýÀ» ¾²¸é °ø°Ý°ú °°´Ù°í °£ÁÖÇÑ´Ù. 
				((CMover*)pTarget)->OnAttacked( (CMover*)this, 0, TRUE, 0 );	// TRUE´Â Å¸°ÙÀÌ´Ù.
		}
	#endif 
	}

	return nResult;
}

// 
// ÁöÁ¤µÈ ½ºÅ³ÀÇ È¿°ú¸¦ pTarget¿¡°Ô Àû¿ëÇÑ´Ù.
// ÁöÁ¤¹üÀ§¿¡ µû¶ó¼­ pTargetÀ» Áß½ÉÀ¸·Î ´Ù¸¥ target¿¡µµ Àû¿ëµÈ´Ù.
// ÀÌ°ÍÀ» »ç¿ëÇÏ´Â ÁÖÃ¼´Â »ç¶÷ÀÌ ¾Æ´Ò¼öµµ ÀÖ´Ù
// ¿©±â¼­´Â SpellRegion¿¡ µû¶ó Àû¿ë´ë»óÀ» ºÐ·ù¸¸ ÇÏ°í ½ÇÁ¦ È¿°úÀû¿ëÀº
// ApplySkill¿¡¼­ Ã³¸®ÇÑ´Ù.
// bOnlyDmg : ¿ÀÁ÷ µ¥¹ÌÁöÀû¿ë½ÃÅ°´Â°Í¸¸ ÇÑ´Ù.  ±¤¿ª Áö¼Óµ¥¹ÌÁö°³Ã¼¿¡¼­ »ç¿ëÇÔ.
#if __VER >= 8 // __S8_PK
int		CCtrl::DoApplySkillEx( CCtrl *pTarget, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp, bool bIgnoreProb, int nParam, BOOL bOnlyDmg, BOOL bControl )
#else // __VER >= 8 // __S8_PK
int		CCtrl::DoApplySkillEx( CCtrl *pTarget, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp, bool bIgnoreProb, int nParam, BOOL bOnlyDmg )
#endif // __VER >= 8 // __S8_PK
{
	int		nRet = 1;
	CCtrl	*pSrc = this;

	switch( pSkillProp->dwSpellRegion )
	{
	case SRO_AROUND:	// ´ë»ó 0% ÁÖÀ§ 100%
	case SRO_REGION:	// ´ë»ó 100% ÁÖÀ§ 100%
		{
#if __VER >= 10 //  __LEGEND
			if( pSkillProp->dwExeTarget != EXT_TROUPE && pSkillProp->dwExeTarget != EXT_TROUPEWITH )	// ±Ø´Ü´ë»óÀÌ ¾Æ´Ò¶§.
#else // __VER >= 10 //  __LEGEND
			if( pSkillProp->dwExeTarget != EXT_TROUPE )	// ±Ø´Ü´ë»óÀÌ ¾Æ´Ò¶§.
#endif // __VER >= 10 // __LEGEND
			{
				int nApplyType = 0;
				nApplyType = pSrc->TargetSelecter( pTarget );
#if __VER >= 8 // __S8_PK
				pTarget->ApplySkillAround( this, nApplyType, pSkillProp, pAddSkillProp, bIgnoreProb, bOnlyDmg, 0.0f, bControl );
#else // __VER >= 8 // __S8_PK
				pTarget->ApplySkillAround( this, nApplyType, pSkillProp, pAddSkillProp, bIgnoreProb, bOnlyDmg );
#endif // __VER >= 8 // __S8_PK
#ifdef __NEWCLASS
				if (pSkillProp->dwID == SI_FLORI_U_SKILL_02)
					pSrc->ApplySkill(this, pSkillProp, pAddSkillProp, TRUE);
#endif // __NEWCLASS
			}
#if __VER >= 10 //  __LEGEND
			else if( pSkillProp->dwExeTarget == EXT_TROUPEWITH )	// ±Ø´Ü´ë»óÀÌ ¾Æ´Ò¶§
			{
				// ±Ø´Ü ´ë»ó ¹üÀ§ È¿°ú.
				if( GetType() == OT_MOVER )
				{
					if( ((CMover *)this)->IsPlayer() )
					{
						if( pAddSkillProp )
						{
#ifndef __3RD_LEGEND16
							int ntmpProb	= pAddSkillProp->nProbability;
							if( (int)( xRandom(100) ) < ntmpProb )
							{
#endif // __3RD_LEGEND16
								if( ApplySkillAroundTroupe( ((CMover *)this)->m_idparty, pSkillProp, pAddSkillProp, TRUE ) == FALSE )// ¸â¹ö °¢°¢¿¡°Ô È¿°ú Àû¿ë.
								{
									pSrc->ApplySkill( this, pSkillProp, pAddSkillProp, TRUE );	
								}
#ifndef __3RD_LEGEND16
							}
#endif // __3RD_LEGEND16
						}
					}
				}
			}			
#endif // __VER >= 10 // __LEGEND
			else
			{
				// ±Ø´Ü ´ë»ó ¹üÀ§ È¿°ú.
				if( GetType() == OT_MOVER )
				{
					if( ((CMover *)this)->IsPlayer() )
					{
						if( ApplySkillAroundTroupe( ((CMover *)this)->m_idparty, pSkillProp, pAddSkillProp, bIgnoreProb ) == FALSE )
							return 0;  // »ç¿ë½ÇÆÐ.
					}
				}
			}
#ifdef __WORLDSERVER
			// chipi - ¹üÀ§ ctrl »ý¼º ½ºÅ³·Î ÀÎÇØ µà¾ó Á¾·á ÈÄ Ä«¿ÀµÇ´Â Çö»ó ¼öÁ¤
			if( pSkillProp->tmContinuousPain != NULL_ID && !(((CMover*)pTarget)->IsPlayer() && ((CMover*)pTarget)->m_nDead) )	// Áö¼Óµ¥¹ÌÁö ÇüÅÂ³Ä?
			//if( pSkillProp->tmContinuousPain != NULL_ID )
			{
				CContDamageCtrl *pDmgCtrl = new CContDamageCtrl;	// Áö¼Óµ¥¹ÌÁö¸¦ ÁÖ´Â °¡»ó¿ÀºêÁ§Æ® »ý¼º - ¸Þ¸ð¸®Ç®¸µ Ã³¸® ÇÒ°Í
				if( pDmgCtrl )
				{
					pDmgCtrl->m_pSkillProp = pSkillProp;
					pDmgCtrl->m_pAddSkillProp = pAddSkillProp;
					pDmgCtrl->m_idSrc = pSrc->GetId();
					pDmgCtrl->m_idTarget = pTarget->GetId();
					pDmgCtrl->SetPos( pTarget->GetPos() );		// Áß½ÉÀÌ µÇ´Â Å¸°ÙÀÇ ÁÂÇ¥·Î...
#if __VER >= 8 // __S8_PK
					pDmgCtrl->m_bControl = bControl;
#endif // __VER >= 8 // __S8_PK
					// chipi - ¹üÀ§ ctrl »ý¼º ½ºÅ³·Î ÀÎÇØ µà¾ó Á¾·á ÈÄ Ä«¿ÀµÇ´Â Çö»ó ¼öÁ¤
					if( ((CMover*)pSrc)->IsPVPTarget( ((CMover*)pTarget) ) )
						pDmgCtrl->m_bDuelTarget = TRUE;

					GetWorld()->ADDOBJ( pDmgCtrl, FALSE, GetLayer() );
				}
			}
#endif
		}
		break;
	case SRO_LINE:		// this¸¦ Áß½ÉÀ¸·Î m_fAngle¶óÀÎ.
		{
			int nApplyType = 0;
			nApplyType = pSrc->TargetSelecter( pTarget );
#if __VER >= 8 // __S8_PK
			ApplySkillLine( nApplyType, pSkillProp, pAddSkillProp, 2.5f, 2.5f, (float)pAddSkillProp->dwSkillRange, bIgnoreProb, bControl );
#else // __VER >= 8 // __S8_PK
			ApplySkillLine( nApplyType, pSkillProp, pAddSkillProp, 2.5f, 2.5f, (float)pAddSkillProp->dwSkillRange, bIgnoreProb );
#endif // __VER >= 8 // __S8_PK
		}
		break;
	case SRO_DIRECT:	// ´ë»ó ÇÏ³ª¿¡¸¸ Àû¿ë
	default:
		if( pSkillProp->dwID != SI_PSY_PSY_PSYCHICWALL )		// »çÀÌÅ±¿ùÀº Ã³¸® ¾ÈÇÔ.
			pTarget->ApplySkill( this, pSkillProp, pAddSkillProp, bIgnoreProb, nParam );
		break;
	} 

#ifdef __WORLDSERVER		
	// ½ÎÀÌÅ±¿ùÀÇ º®À» ¸¸µé¾î³¿.
	if( pSkillProp->dwID == SI_PSY_PSY_PSYCHICWALL )
	{
		BOOL bCreate = FALSE;
		int i = 0;
		if( GetType() == OT_MOVER )
		{
			if( ((CMover *)this)->IsPlayer() )
			{
				CUser *pUser = (CUser *)this;
				for( i = 0; i < 2; i ++ )		// ÇÑ¹ø¿¡ 2°³ÀÌ»ó »ý¼ºµÇÁö ¾Ê°ÔÇÔ.
				{
					if( pUser->m_pWall[i] == NULL )
					{
						CObj *pObj = CreateObj( D3DDEVICE, OT_CTRL, CI_PSYCHICWALL );		// º® ÄÁÆ®·Ñ »ý¼º.
						if( pObj )
						{
							pObj->SetPos( this->GetPos() );
							pObj->SetAngle( -GetAngle() );
							((CCommonCtrl *)pObj)->m_pSkillProp = pSkillProp;
							((CCommonCtrl *)pObj)->m_pAddSkillProp = pAddSkillProp;
							((CCommonCtrl *)pObj)->m_idAttacker = GetId();
							((CCommonCtrl *)pObj)->m_bControl = bControl;

							GetWorld()->ADDOBJ( pObj, TRUE, GetLayer() );
							pUser->m_pWall[i] = pObj;
							bCreate = TRUE;
							break;
						}
					}
				}
			}
		}
		if( bCreate == FALSE )	// »ý¼º¸øÇßÀ¸¸é
			nRet = 0;			// ½ÇÆÐ ¸®ÅÏ

	}

	if (pSrc->GetType() == OT_MOVER)
	{
		// ¸ðµç ½ºÅ³»ç¿ë½Ã ´ÙÅ©ÀÏ·çÁ¯»óÅÂÀÌ¸é ÇØÁ¦ÇÑ´Ù!!~
#ifdef __GAMEGUARD
		D3DXVECTOR3 v3Len = GetPos() - pSrc->GetPos();
		FLOAT fTotalLen = D3DXVec3LengthSq(&v3Len);

		if (fTotalLen > ((CMover*)pSrc)->GetAttackRange(pSkillProp->dwAttackRange))
			return 0;

		if (this != pSrc && pSrc->GetType() == OT_MOVER && ((CMover*)pSrc)->IsPlayer())
		{
			float fX = GetPos().x - pSrc->GetPos().x;
			float fZ = GetPos().z - pSrc->GetPos().z;
			if (fX > 1.0f && fZ > 1.0f)
			{
				D3DXVECTOR3 v3Lenn = D3DXVECTOR3(fX, 0.0f, fZ);
				float fTotalLenn = D3DXVec3LengthSq(&v3Lenn);

				fTotalLenn -= GetRadiusXZ();
				fTotalLenn -= pSrc->GetRadiusXZ();

				float fAttRange = ((CMover*)pSrc)->GetAttackRange(pSkillProp->dwAttackRange);
				if (fAttRange && fTotalLenn < fAttRange)
					return 0;
			}
		}
#endif // __GAMEGUARD
		// ¸ðµç ½ºÅ³»ç¿ë½Ã ´ÙÅ©ÀÏ·çÁ¯»óÅÂÀÌ¸é ÇØÁ¦ÇÑ´Ù!!~
		if( pSkillProp->dwID != SI_ACR_SUP_DARKILLUSION )
		{
			if( ((CMover *)pSrc)->HasBuff( BUFF_SKILL, SI_ACR_SUP_DARKILLUSION ) )
			{
				((CMover *)pSrc)->SetDarkCover( FALSE );
				((CMover *)pSrc)->RemoveBuff( BUFF_SKILL, SI_ACR_SUP_DARKILLUSION );		// ÇØÁ¦.
			}
		}
#ifdef __NEWCLASS
		if (pSkillProp->dwID != SI_STORM_U_SKILL_02)
		{
			if (((CMover*)pSrc)->HasBuff(BUFF_SKILL, SI_STORM_U_SKILL_02))
			{
				((CMover*)pSrc)->SetDarkCover(FALSE);
				((CMover*)pSrc)->RemoveBuff(BUFF_SKILL, SI_STORM_U_SKILL_02);		// ÇØÁ¦.
			}
		}
#endif // __NEWCLASS
		// Á¦½ºÅÍ ¹öÇÁ´Â Æ¯Á¤ ¹öÇÁ°¡ ÀÖÀ¸¸é ÇØÁ¦ÇÏ°í °É¾î¾ßÇÔ
		if( pSkillProp->dwID == SI_JST_SUP_POISON )
		{
			((CMover *)pSrc)->RemoveBuff( BUFF_SKILL, SI_JST_SUP_BLEEDING );
			((CMover *)pSrc)->RemoveBuff( BUFF_SKILL, SI_JST_SUP_ABSORB );
		}
		else
		if( pSkillProp->dwID == SI_JST_SUP_BLEEDING )
		{
			((CMover *)pSrc)->RemoveBuff( BUFF_SKILL, SI_JST_SUP_POISON );
			((CMover *)pSrc)->RemoveBuff( BUFF_SKILL, SI_JST_SUP_ABSORB );
		}
		else		
		if( pSkillProp->dwID == SI_JST_SUP_ABSORB )
		{
			((CMover *)pSrc)->RemoveBuff( BUFF_SKILL, SI_JST_SUP_BLEEDING );
			((CMover *)pSrc)->RemoveBuff( BUFF_SKILL, SI_JST_SUP_POISON );
		}
#ifdef __NEWCLASS
		else
			if (pSkillProp->dwID == SI_LORDT_U_SKILL_01)
			{
				((CMover*)pSrc)->RemoveBuff(BUFF_SKILL, SI_LORDT_U_SKILL_02);
				((CMover*)pSrc)->RemoveBuff(BUFF_SKILL, SI_LORDT_U_SKILL_03);
			}
			else
				if (pSkillProp->dwID == SI_LORDT_U_SKILL_02)
				{
					((CMover*)pSrc)->RemoveBuff(BUFF_SKILL, SI_LORDT_U_SKILL_01);
					((CMover*)pSrc)->RemoveBuff(BUFF_SKILL, SI_LORDT_U_SKILL_03);
				}
				else
					if (pSkillProp->dwID == SI_LORDT_U_SKILL_03)
					{
						((CMover*)pSrc)->RemoveBuff(BUFF_SKILL, SI_LORDT_U_SKILL_01);
						((CMover*)pSrc)->RemoveBuff(BUFF_SKILL, SI_LORDT_U_SKILL_02);
					}
#endif // __NEWCLASS
	}	
#endif // WorldServer
	
	// ½ºÅ³¿¡ ÇÊ¿äÇÑ sfx¸¦ »ý¼º.
	CreateSkillSfx( pTarget, pSkillProp, pAddSkillProp );
	
	// 2Â÷ ½ºÅ³ ¹ßµ¿. ActiveSkill
	if( pSkillProp->dwActiveSkill != NULL_ID )
	{
		if( pSkillProp->dwActiveSkillRate == NULL_ID || xRandom(100) <= pSkillProp->dwActiveSkillRate )	// ¹ßµ¿È®·ü¿¡ °É·È´Â°¡.
#if __VER >= 8 // __S8_PK
			pSrc->DoActiveSkill( pSkillProp->dwActiveSkill, 1, pTarget, false, bControl );		// dwActiveSkill Lv1ÀÌ ¹ßµ¿µÊ.
#else // __VER >= 8 // __S8_PK
			pSrc->DoActiveSkill( pSkillProp->dwActiveSkill, 1, pTarget );		// dwActiveSkill Lv1ÀÌ ¹ßµ¿µÊ.
#endif // __VER >= 8 // __S8_PK
			
	}

	return nRet;
}

// nLevelÀÇ dwSkillÀÌ pTargetÀ» ÇâÇÏ¿© ¹ßµ¿µÊ.  ¾îÅÂÄ¿´Â this
// bIgnoreProbÀÌ TRUEÀÌ¸é ³»ºÎ¿¡¼­ È®·ü°è»êÀ» ¹«½ÃÇÏ°í 100% ½ÇÇàµÇ°Ô ÇÑ´Ù.
#if __VER >= 8 // __S8_PK
void CCtrl::DoActiveSkill( DWORD dwSkill, int nLevel, CCtrl *pTarget, bool bIgnoreProb, BOOL bControl )
#else // __VER >= 8 // __S8_PK
void CCtrl::DoActiveSkill( DWORD dwSkill, int nLevel, CCtrl *pTarget, bool bIgnoreProb )
#endif // __VER >= 8 // __S8_PK
{
#ifdef __GAMEGUARD
	if (!pTarget)
		return;
#endif // __GAMEGUARD
	ItemProp *pSkillProp;
	AddSkillProp *pAddSkillProp;
	GetSkillProp( &pSkillProp, &pAddSkillProp, dwSkill, nLevel, "DoActiveSkill" );
	
	int nRet;
	if( pSkillProp->dwExeTarget == EXT_MAGICATKSHOT || 
		pSkillProp->dwExeTarget == EXT_MAGICSHOT )		// ½î´Â ÇüÅÂ¸é sfx¸¸ ¹ß»ý
		nRet = ShootSkill( pTarget, pSkillProp, pAddSkillProp );
	else
	{
#if __VER >= 8 // __S8_PK
		nRet = DoApplySkill( pTarget, pSkillProp, pAddSkillProp, bIgnoreProb, 0, FALSE, bControl );
#else // __VER >= 8 // __S8_PK
		nRet = DoApplySkill( pTarget, pSkillProp, pAddSkillProp, bIgnoreProb );
#endif // __VER >= 8 // __S8_PK
 #ifdef __WORLDSERVER		
		g_UserMng.AddDoApplySkill( this, pTarget->GetId(), dwSkill, nLevel );
 #endif
	}
}

#ifdef __GUILD_BUFF
void CCtrl::DoAddBuff(DWORD dwSkill, int nLevel, CCtrl* pTarget)
{
	ItemProp* pSkillProp;
	AddSkillProp* pAddSkillProp;
	GetSkillProp(&pSkillProp, &pAddSkillProp, dwSkill, nLevel, "DoActiveSkill");
	if (pAddSkillProp)
	{
		DoApplySkill(pTarget, pSkillProp, pAddSkillProp, 0, 0, FALSE, 0);
#ifdef __WORLDSERVER       
		g_UserMng.AddDoApplySkill(this, pTarget->GetId(), dwSkill, nLevel);
#endif
	}
}
#endif// __GUILD_BUFF 

#ifdef __BUFF_PANG_UPDATE
void CCtrl::DoAddBuff2(DWORD dwSkill, int nLevel, int nTime, CCtrl* pTarget)
{
	if (pTarget)
	{
		ItemProp* pSkillProp;
		AddSkillProp* pAddSkillProp;
		GetSkillProp(&pSkillProp, &pAddSkillProp, dwSkill, nLevel, "DoActiveSkill");

		if (pAddSkillProp)
		{
			DWORD dwSkillTime2 = pAddSkillProp->dwSkillTime;
			if (nTime && nTime > 0)
			{
				nTime *= 1000;
				pAddSkillProp->dwSkillTime = nTime;
			}
			DoApplySkill(pTarget, pSkillProp, pAddSkillProp, 0, 0, FALSE, 0);
#ifdef __WORLDSERVER        
			g_UserMng.AddDoApplySkill(this, pTarget->GetId(), dwSkill, nLevel);
#endif // __WORLDSERVER
			pAddSkillProp->dwSkillTime = dwSkillTime2;
		}
	}
}
#endif // __BUFF_PANG_UPDATE

#ifdef	__MALEVOLENT_CP
void CCtrl::DoBuff(DWORD dwSkill, int nLevel, CCtrl* pTarget)
{
	ItemProp* pSkillProp;
	AddSkillProp* pAddSkillProp;
	GetSkillProp(&pSkillProp, &pAddSkillProp, dwSkill, nLevel, "DoActiveSkill");
	if (pAddSkillProp->dwSkillTime > 1000)
		pAddSkillProp->dwSkillTime = 9999999;

	DoApplySkill(pTarget, pSkillProp, pAddSkillProp, 0, 0, FALSE, 0);
}
#endif	//__MALEVOLENT_CP
```
