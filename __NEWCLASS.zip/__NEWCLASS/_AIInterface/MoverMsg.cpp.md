# MoverMsg.cpp

Chemin original: `C:\Users\rdiff\Desktop\__NEWCLASS\_AIInterface\MoverMsg.cpp`
Chemin relatif: `_AIInterface\MoverMsg.cpp`
Nom du fichier: `MoverMsg.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `cp1252`

```cpp
#include "stdafx.h"
#include "defineSkill.h"
#include "defineText.h"
#ifdef __CLIENT
#include "AppDefine.h"
#endif

#include "ModelObject.h"

#ifdef __CLIENT
#include "DPClient.h"
extern	CDPClient	g_DPlay;
#else	// __CLIENT
#ifdef __WORLDSERVER
#include "User.h"
#include "WorldMng.h"
#include "DPSrvr.h"
#include "DPCoreClient.h"
extern	CUserMng	g_UserMng;
extern	CWorldMng	g_WorldMng;
extern	CDPSrvr		g_DPSrvr;
extern	CDPCoreClient	g_DPCoreClient;
#endif	// __WORLDSERVER
#endif	// __CLIENT

#include "ship.h"


/*--------------------------------------------------------------------------------------------------------


											Mover act command


----------------------------------------------------------------------------------------------------------*/

void	CMover::SetCmd( OBJACT cmd, int nParam1, int nParam2, int nParam3 )
{
	m_oaCmd = cmd;
	m_nCParam[0] = nParam1;		// ¸í·É ÆÄ¶ó¸ÞÅÍ.
	m_nCParam[1] = nParam2;
	m_nCParam[2] = nParam3;
}

//
// fRange = µµ´Þ¹üÀ§.  µðÆúÆ®´Â 0.0fÀº »ó´ë¹æÀÇ ¹Ý°æ±îÁö ºÙ´Â°Å´Ù.
void CMover::SetDestObj( OBJID objid, float fRange, BOOL bSend )
{
#ifdef __WORLDSERVER
	if( FALSE == IsPlayer() && m_idDest != objid )
		m_nCorr	= -1;
#else	// __WORLDSERVER
	if( bSend && IsActiveMover() && m_idDest != objid )
	{
#ifdef __BS_ADJUST_SYNC
		CMover* pTarget = prj.GetMover( m_idDest );
		if( pTarget )
		{
			if( pTarget->IsPlayer( ) )
				g_DPlay.SendPlayerBehavior();	// »õ·Î¿î Obj·Î ÀÌµ¿ÇÒ°æ¿ì µ¿±âÈ­ ÇÑ¹ø ¸ÂÃçÁÖ°í....
		}
#endif
		g_DPlay.SendPlayerDestObj( objid, fRange );
		m_nCorr	= -1;
	}
#endif	// not __WORLDSERVER

	m_idDest	    = objid;
	m_fArrivalRange = fRange;
	ClearDestPos();

#ifdef __WORLDSERVER
	// ¼­¹ö¿¡¼­ SetDestObj¸¦ ½ÇÇàÇÏ¸é Å¬¶óµé¿¡°Ô º¸³»ÁÖ´Â°Ô ¾ø¾î¼­ ÀÌ°É ³ÖÀ½.
	if( bSend )
		g_UserMng.AddMoverSetDestObj( this, objid, fRange, FALSE );
#endif	// __WORLDSERVER

#ifdef __CLIENT
	m_oaCmd = OBJACT_NONE;		// CMD_ ½Ã¸®Áî¸¦ °ÅÄ¡Áö ¾Ê°í ÀÌ°Í¸¸ È£ÃâµÇ´Â °æ¿ì´Â Cmd¸¦ ÇØÁ¦½ÃÅ°ÀÚ.
#endif // Client

//	if( IsPlayer() )
//		TRACE( "SetDestObj %08x\n", objid );
}

//
//
void CMover::SetDestPos( const D3DXVECTOR3 & vDestPos, bool bForward, BOOL fTransfer )
{
	m_vDestPos	= vDestPos;
	
#ifdef __BS_ADJUST_SYNC
	m_bForward	= true;				//sun
#else
	m_bForward	= bForward;
#endif

	D3DXVECTOR3	vDir = GetPos() - m_vDestPos;

	m_bPositiveX = ( vDir.x > 0.0f );
	m_bPositiveZ = ( vDir.z > 0.0f );
	
	ClearDestObj();

#ifdef __CLIENT
	if( IsActiveMover() && fTransfer ) 
	{
		g_DPlay.PutPlayerDestPos( vDestPos, bForward );
	}
#endif
}

// IA¿ÀºêÁ§Æ® À§·Î ÀÌµ¿Å¬¸¯À» ÇßÀ»¶§....
#ifdef __IAOBJ0622
void CMover::SetDestPos( CShip *pIAObj, const D3DXVECTOR3 &vDestPos )
{
	m_pIADestPos = pIAObj;
	
	D3DXMATRIX mTrans, mInvIA, mLocal;
	D3DXMatrixTranslation( &mTrans, vDestPos.x, vDestPos.y, vDestPos.z );		// ¿ùµåÁÂÇ¥¸¦ ¸ÅÆ®¸¯½º·Î º¯È¯
	D3DXMatrixInverse( &mInvIA, NULL, pIAObj->GetMatrixWorldPtr() );			// IAObjÀÇ ¿ªÇà·Ä.
	D3DXMatrixMultiply( &mLocal, &mTrans, GetIAObjLink()->GetInvTM() );	// IA¿ÀºêÁ§Æ®·ÎºÎÅÍÀÇ ·ÎÄÃ Çà·Ä.

	D3DXVECTOR3 vLocal;
	vLocal.x = mLocal._41;
	vLocal.y = mLocal._42;
	vLocal.z = mLocal._43;
	
	SetDestPos( vLocal, true, FALSE );	// do not transfer

#ifdef __CLIENT
	if( IsActiveMover() )
	{
		g_DPlay.PutPlayerDestPos( vLocal, true, 0, pIAObj->GetId() );
	}
#endif	// __CLIENT
}
#endif	// __IAOBJ0622

FLOAT	CMover::GetAttackRange( DWORD dwAttackRange )
{
	float fAttRange = 0.0f;
	switch( dwAttackRange )
	{
	case AR_SHORT:	fAttRange = 2.0f;	break;
	case AR_LONG:	fAttRange = 3.0f;		break;
	case AR_FAR:	fAttRange = 4.0f;		break;
	case AR_RANGE:	fAttRange = 10.0f;		break;
	case AR_WAND:	fAttRange = 15.0f;		break;
	case AR_HRANGE: fAttRange = 6.0f;	break;
#if __VER >= 10 // __LEGEND		//10Â÷ Àü½Â ¸¶½ºÅÍ½ºÅ³
	case AR_HWAND:	fAttRange = 18.0f;		break;
#endif //__LEGEND		//10Â÷ Àü½Â ¸¶½ºÅÍ½ºÅ³
	default:		fAttRange = 0.0f;		break;
	}
#if __VER >= 10 // __LEGEND		//10Â÷ Àü½Â ¸¶½ºÅÍ½ºÅ³
	int  nTmpATR = GetParam( DST_HAWKEYE_RATE, 0 );
#ifdef __GAMEGUARD
	int nJob = GetJob();
	BOOL bRanger = FALSE;
	if (nJob == JOB_RANGER || nJob == JOB_RANGER_MASTER || nJob == JOB_RANGER_HERO || nJob == JOB_CRACKSHOOTER_HERO)
		bRanger = TRUE;

	if ((nTmpATR > 0 && nTmpATR <= 80) && bRanger)
#else // __GAMEGUARD
	if (nTmpATR > 0)
#endif // __GAMEGUARD
	{
		nTmpATR += 100;
		fAttRange =  fAttRange * nTmpATR / 100;
	}
#endif //__LEGEND		//10Â÷ Àü½Â ¸¶½ºÅÍ½ºÅ³

	return fAttRange;
}

//
// ¿ÜºÎ¿¡¼­ UseSkillÀ» ¸í·ÉÇÒ¶© ÀÌ°ÍÀ¸·Î È£ÃâÇÏÀÚ.
// sutType : ½ºÅ³À» »ç¿ëÇÒ¶§ ½ºÅ³Å¥¿¡¼­ ¿¬Å¸·Î »ç¿ëÇÑ°Ç°¡ ÀÏ¹ÝÀûÀÎ »ç¿ëÀ» ÇÑ°Ç°¡.c
//
int	CMover::CMD_SetUseSkill( OBJID idTarget, int nSkillIdx, SKILLUSETYPE sutType )
{
	m_oaCmd = OBJACT_NONE;
	TRACE( "CMD_SetUseSkill( " );
	if( m_pActMover->IsFly() )	return 0;				// ºñÇàÁß¿£ ½ºÅ³»ç¿ë ±ÝÁö.
#ifdef __MOUNT
	if (m_pActMover->IsUseMount()) return 0;
#endif // __MOUNT
	if( m_pActMover->IsActAttack() )	return 0;
	if( m_pActMover->IsActJump() )	return 0;			// Á¡ÇÁÁß¿£ »ç¿ë±ÝÁö.
	if( m_pActMover->GetState() & OBJSTA_DMG_FLY_ALL )		return 0;	// µ¥¹ÌÁö ÇÃ¶óÀÌÁß¿£ ½ºÅ³»ç¿ë±ÝÁö.
	if( IsDie() )	return 0;		// Á×¾úÀ»¶§ »ç¿ë±ÝÁö.

	LPSKILL pSkill	= GetSkill( 0, nSkillIdx );		// this°¡ °¡Áø ½ºÅ³Áß nIdx¿¡ ÇØ´çÇÏ´Â ½ºÅ³À» ²¨³½´Ù.
	if( pSkill == NULL )
	{
		Error( "CMD_SetUseSkill : %s skill(%d) not found", m_szName, nSkillIdx );
		return 0;	// 
	}

	ItemProp* pSkillProp = pSkill->GetProp();
	if( pSkillProp == NULL )		// JobSkill ¸®½ºÆ®¿¡¼­ ²¨³½ ½ºÅ³ÀÇ ÇÁ·ÎÆÛÆ¼¸¦ ²¨³¿.
	{
		Error( "CMD_SetUseSkill : %s. skill(%d) property not found", m_szName, pSkill->dwSkill );
		return 0;	// 
	}
	
	if( IsPlayer() && IsStateMode( STATE_BASEMOTION_MODE ) )	// ½ÃÀüÁß(ÁØºñ½Ã°£)ÀÏ¶© »ç¿ë±ÝÁö.
	{
	#ifdef __CLIENT
		g_DPlay.SendStateModeCancel( STATE_BASEMOTION_MODE, STATEMODE_BASEMOTION_CANCEL );
	#endif 
		return 0;		
	}

	// µµ´Þ¹üÀ§ - ¾ó¸¶³ª °¡±îÀÌ ±ÙÁ¢ÇØ¾ßÇÏ´Â°¡. ¹ÌÅÍ´ÜÀ§
	float	fArrivalRange = 0.0f;		
	fArrivalRange = GetAttackRange( pSkillProp->dwAttackRange );
	
	switch( pSkillProp->dwUseChance )
	{
	case WUI_NOW:	// Å¸°ÙÆÃ°ú »ó°ü¾øÀÌ ÀÚ±âÀÚ½Å¿¡°Ô ¾²´Â ¹æ½Ä.
		idTarget = GetId();
		break;
	case WUI_TARGETINGOBJ:	// ¼¿·ºÆ® µÇ¾î ÀÖ´Â Å¸°Ù¿¡°Ô »ç¿ë.
		{
#ifdef __CLIENT
		CObj *pFocusObj = GetWorld()->GetObjFocus();
		if( pFocusObj && pFocusObj->GetType() == OT_MOVER )
			idTarget = ((CMover*)pFocusObj)->GetId();
#else
		if( IsPlayer() )
			idTarget = ((CUser *)this)->m_idSetTarget;
#endif // __CLIENT
		}

		break;
#ifdef __CLIENT
	case WUI_TARGETCURSORPTZ:
		{
			idTarget = GetId();
			
			CRect rect;
			D3DXVECTOR3 vPos;
			CWndWorld* pWndWorld;
			
			pWndWorld = (CWndWorld*)g_WndMng.GetWndBase( APP_WORLD );

			rect = pWndWorld->GetClientRect();

			if( GetWorld()->ClientPointToVector( NULL, rect, pWndWorld->GetMousePoint(), &GetWorld()->m_matProj, &GetWorld()->GetCamera()->m_matView, &vPos, TRUE ) )
			{
#ifdef __SKILL0517
				AddSkillProp* pAddSkillProp = prj.GetAddSkillProp( pSkillProp->dwSubDefine, GetSkillLevel( pSkill ) );		// UseSkill¿¡¼­ »ç¿ëÇÑ ½ºÅ³ÀÇ ÇÁ·ÎÆÛÆ¼ ²¨³¿
#else	// __SKILL0517
				AddSkillProp* pAddSkillProp = prj.GetAddSkillProp( pSkillProp->dwSubDefine, pSkill->dwLevel );		// UseSkill¿¡¼­ »ç¿ëÇÑ ½ºÅ³ÀÇ ÇÁ·ÎÆÛÆ¼ ²¨³¿
#endif	// __SKILL0517
				if( pAddSkillProp == NULL )
				{
					Error( "CMover::OnMagicSkill : %s. add½ºÅ³(%d)ÀÇ ÇÁ·ÎÆÛÆ¼°¡ ¾ø´Ù.", m_szName, nSkillIdx );
					return 0;	// property not found
				}
				
				FLOAT	fDist;
				FLOAT	fMaxDistSq;
				D3DXVECTOR3	vDist;
				fMaxDistSq  = (float)pAddSkillProp->dwSkillRange;
				fMaxDistSq *= fMaxDistSq;
				vDist = vPos - GetPos();
				fDist = D3DXVec3LengthSq( &vDist );	

				SetAngle( GetDegree(vPos, GetPos()) );		// ¸ñÇ¥ÂÊÀ¸·Î ¸öÀ» µ¹¸².
				
				// ÅÚ·¹Æ÷Æ® ÇÒ À§Ä¡°¡ ¸Ö°æ¿ì ÇöÁ¦ ½ºÅ³¿¡ ÇØ´çÇÏ´Â °Å¸®·Î ¹Ù²ãÁØ´Ù
				if( fDist > fMaxDistSq )
				{
					FLOAT fLength;
					D3DXVECTOR3 vDirNor;
					D3DXVec3Normalize( &vDirNor, &vDist );
					fLength = (float)pAddSkillProp->dwSkillRange;
					float y = vPos.y;
					vPos = GetPos() + (vDirNor * fLength);
					vPos.y	= y;

					// ½ºÅ³¿¡ ÇØ´çÇÏ´Â °Å¸®·Î ¹Ù²Û°÷ÀÌ ¸ø°¡´Â Áö¿ªÀÌ¶ó¸é °¥¼ö ÀÖ´Â Áö¿ªÀ» °Ë»çÇÑ´Ù.
					int nAttr = GetWorld()->GetHeightAttribute( vPos.x, vPos.z );

					if( nAttr != HATTR_NONE ) 
					{
						while( nAttr != HATTR_NONE )
						{
							if( nAttr == HATTR_NOFLY )
								break;
							
							fLength -= 1.0f; // 1¹ÌÅÍ¾¿ ÁÙ¿©°¡¸ç °è»êÇÑ´Ù.
							vPos  = GetPos() + (vDirNor * fLength);
							nAttr = GetWorld()->GetHeightAttribute( vPos.x, vPos.z );

							// Ä³¸¯ÅÍÀÇ ¾Õ µÚ·Î ÀÌµ¿ºÒ°¡ ÀÏ °æ¿ì µÞÂÊÀÌ ÀÌµ¿ºÒ°¡ ÇØÁ¦ µÉ¶§ ±îÁö °è¼Ó °è»êÇÏ¿© ÀÌµ¿½ÃÅ´
							// ±×·¯¹Ç·Î ÅÚ·¹Æ÷Æ® ½ºÅ³ ¹üÀ§¸¦ ³Ñ¾î¼³ °æ¿ì ¿ø·¡ ÀÚ¸®·Î ÅÚ·¹Æ÷Æ® ÇÏµµ·Ï Ã³¸®
							D3DXVECTOR3 vTemp = vPos - GetPos();
							float fTemp = D3DXVec3LengthSq( &vTemp );
							if(fTemp > fMaxDistSq)
							{
								vPos = GetPos();
								break;
							}
						}
						
						// ÇÑ¹ø´õ ÁÙ¿©ÁÜ
						fLength -= 1.0f; 
						vPos = GetPos() + (vDirNor * fLength);

						// ÁÙÀÎ °÷ÀÌ ÀÌµ¿ºÒ°¡ Áö¿ªÀÏ ¼ö ÀÖ´Ù.
						nAttr = GetWorld()->GetHeightAttribute( vPos.x, vPos.z );
						if( nAttr != HATTR_NONE )
						{
							vPos = GetPos();
						}
					}
				}
				else // ÅÚ·¹Æ÷Æ® ÇÒ À§Ä¡°¡ ÇØ´ç½ºÅ³ °Å¸®º¸´Ù ÀÛÀ»°æ¿ì
				{
					int nAttr = GetWorld()->GetHeightAttribute( vPos.x, vPos.z );

					FLOAT fLength;
					D3DXVECTOR3 vDirNor;
					D3DXVec3Normalize( &vDirNor, &vDist );
					fLength = 0.0f;

					while( nAttr != HATTR_NONE )
					{
						if( nAttr == HATTR_NOFLY )
							break;

						fLength -= 1.0f;
						vPos = GetPos() + (vDirNor * fLength);
						
						nAttr = GetWorld()->GetHeightAttribute( vPos.x, vPos.z );

						// Ä³¸¯ÅÍÀÇ ¾Õ µÚ·Î ÀÌµ¿ºÒ°¡ ÀÏ °æ¿ì µÞÂÊÀÌ ÀÌµ¿ºÒ°¡ ÇØÁ¦ µÉ¶§ ±îÁö °è¼Ó °è»êÇÏ¿© ÀÌµ¿½ÃÅ´
						// ±×·¯¹Ç·Î ÅÚ·¹Æ÷Æ® ½ºÅ³ ¹üÀ§¸¦ ³Ñ¾î¼³ °æ¿ì ¿ø·¡ ÀÚ¸®·Î ÅÚ·¹Æ÷Æ® ÇÏµµ·Ï Ã³¸®
						D3DXVECTOR3 vTemp = vPos - GetPos();
						float fTemp = D3DXVec3LengthSq( &vTemp );
						if(fTemp > fMaxDistSq)
						{
							vPos = GetPos();
							break;
						}
					}
				}

				if( IsActiveMover() && g_eLocal.GetState( EVE_SCHOOL ) )	// ÇÐ±³ÀÌº¥¼·ÀÌ¸é.
				{
					D3DXVECTOR3 v1, v2;
					v1 = GetPos();	v1.y += 0.1f;
					v2 = vPos;		v2.y += 0.1f;
					if( GetWorld()->IntersectObjLine( NULL, v1, v2, FALSE, FALSE ) )	// ÅÚ·¹Æ÷Æ®´Â ¶óÀÎÃ¼Å©ÇÔ.
					{
						g_WndMng.PutString( prj.GetText(TID_GAME_NOMOVING), NULL, prj.GetTextColor(TID_GAME_NOMOVING) );
						g_WndMng.m_pWndWorld->SetNextSkill( NEXTSKILL_NONE );
						return 0;
					}
				}

				pWndWorld->m_vTelePos = vPos;
			}
			else
			{
				g_WndMng.m_pWndWorld->SetNextSkill( NEXTSKILL_NONE );
				g_WndMng.PutString( prj.GetText(TID_GAME_NOMOVING), NULL, prj.GetTextColor(TID_GAME_NOMOVING) );
				return 0;
			}
		}
		break;
#endif // __CLIENT
	}

	// Å¸ÀÎ¿¡°Ô ¾²´Â°æ¿ì¿¡¸¸ °Ë»ç...
	if( idTarget != GetId() )		
	{
		CMover *pTarget = prj.GetMover( idTarget );
		if( IsValidObj(pTarget) )
		{
			if( pSkillProp->nEvildoing < 0 )	// ³ª»Û ½ºÅ³Àº 
				if( IsAttackAble(pTarget) == FALSE )	// °ø°ÝÇã¿ëÀÌ µÇÁö ¾ÊÀ¸¸é »ç¿ëÇÒ ¼ö ¾øÀ½.
					return 0;
				
#ifdef __NEWCLASS
			if (pSkill->dwSkill == SI_ASS_HEAL_RESURRECTION
				|| pSkill->dwSkill == SI_MENTA_U_SKILL_03)	// ºÎÈ°À» »ç¿ëÇßÀ»¶§
#else // __NEWCLASS
			if (pSkill->dwSkill == SI_ASS_HEAL_RESURRECTION)	// ºÎÈ°À» »ç¿ëÇßÀ»¶§
#endif // __NEWCLASS
			{
				if( pTarget->IsNPC() || pTarget->IsDie() == FALSE )		// »ó´ë°¡ NPC°Å³ª »ó´ë°¡ Á×¾îÀÖÁö ¾Ê´Ù¸é Ãë¼Ò
					return 0;
			} else
			{
				if( pTarget->IsDie() )		// ºÎÈ°ÀÌ ¾Æ´Ñ ½ºÅ³À» »ç¿ëÇßÀ»¶§ »ó´ë°¡ Á×¾îÀÖÀ¸¸é »ç¿ë¾ÈµÊ.
					return 0;
			}
		}
	}

	// Å¸°Ù ±ÙÁ¢ ¹æ½Ä.
	switch( pSkillProp->dwExeTarget )
	{
	case EXT_SELFCHGPARAMET:	// ½ÃÀüÀÚ ÀÚ½Å¿¡°Ô »ç¿ëÇÏ´Â Á¾·ù
		idTarget = GetId();		// Å¸°ÙÀ» ÀÚ±âÀÚ½ÅÀ¸·Î ¼³Á¤.
		SetDestObj( idTarget, fArrivalRange, TRUE );		// ÀÌµ¿ÇÒ ¸ñÇ¥¹°À» idTargetÀ¸·Î ¼³Á¤. << ÀÌ°Ô ¿Ö ÇÊ¿äÇÏÁö? ¤Ñ.¤Ñ?
		break;
	case EXT_MAGICATKSHOT:
	case EXT_MAGICATK:			// ¿ø°Å¸®¿¡¼­ ¸¶¹ýÀ¸·Î Å¸°ÙÀ» °ø°Ý
	case EXT_MAGICSHOT:
		if( idTarget == NULL_ID )	return 0;			// Å¸°ÙÀÌ ¾ø°Å³ª À¯È¿ÇÏÁö ¾ÊÀ¸¸é ½ÇÆÐ.
		SetDestObj( idTarget, fArrivalRange, TRUE );		// ÀÌµ¿ÇÒ ¸ñÇ¥¹°À» idTargetÀ¸·Î ¼³Á¤. ´Ù°¡°¡´Â ¹üÀ§´Â fArrivalRange°ªÀ¸·Î..
		break;
	case EXT_ANOTHERWITH:		// ³ª È¤Àº ´Ù¸¥»ç¶÷¿¡°Ô ½ÃÀü
		if( idTarget == NULL_ID )	// Å¸°ÙÀÌ ÀâÇôÀÖÁö ¾ÊÀ¸¸é
			idTarget = GetId();		// ÀÚ½ÅÀ» Å¸°ÙÀ¸·Î ÀâÀ½
		SetDestObj( idTarget, fArrivalRange, TRUE );		// ÀÌµ¿ÇÒ ¸ñÇ¥¹°À» idTargetÀ¸·Î ¼³Á¤.
		break;
	case EXT_AROUNDATK:			// ³» ÁÖÀ§ÀûµéÀ» ´ë»ó.
		idTarget = GetId();		// Å¸°ÙÀ» ÀÚ±âÀÚ½ÅÀ¸·Î ¼³Á¤.
		SetDestObj( idTarget, fArrivalRange, TRUE );		// ÀÌµ¿ÇÒ ¸ñÇ¥¹°À» idTargetÀ¸·Î ¼³Á¤.
		break;
	case EXT_OBJCHGPARAMET:		// Å¸ÀÎ¿¡°Ô »ç¿ë
	default:	// ±×¿Ü´Â ¸ðµÎ ±ÙÁ¢ÇÏÀÚ.
		if( idTarget == NULL_ID )	return 0;			// Å¸°ÙÀÌ ¾ø°Å³ª À¯È¿ÇÏÁö ¾ÊÀ¸¸é ½ÇÆÐ.
		SetDestObj( idTarget, fArrivalRange, TRUE );		// ÀÌµ¿ÇÒ ¸ñÇ¥¹°À» idTargetÀ¸·Î ¼³Á¤.
		break;
	}
	
	ClearActParam();
	SetCmd( OBJACT_USESKILL, nSkillIdx, idTarget, sutType );		// »çÁ¤°Å¸®°¡ µÇ¾úÀ»¶§ ½ÇÇàÇÒ ¸í·É ¼ÂÆÃ.
	TRACE( "\n)CMD_SetUseSkill\n" );

	return 1;
}

class CWndWorld;

void	CMover::CMD_SetMeleeAttack( OBJID idTarget, FLOAT fRange )
{
	ItemProp *pProp = GetActiveHandItemProp();
	if( pProp->dwItemKind2 == IK2_TOOLS )			// ÅøÀ» µé°í¼± °ø°Ý¸øÇÑ´Ù,.
		return;

	if( m_pActMover->IsActAttack() )	
		return;
	if( IsDie() )	
		return;										// Á×¾úÀ»¶§ »ç¿ë±ÝÁö.

	// ¿ä¿ä´Â ¹Ð¸®¾îÅÃÀÌ±ä ÇÏ³ª ¾à°£ °Å¸®¸¦ µÎ°í °ø°ÝÇÑ´Ù.( ÇÁ·ÎÆÛÆ¼ ÂüÁ¶ÇÔ )
#ifdef __GAMEGUARD
	if (pProp->dwItemKind3 == IK3_YOYO && IsInteriorityJob(JOB_ACROBAT))
#else // __GAMEGUARD
	if (pProp->dwItemKind3 == IK3_YOYO)
#endif // __GAMEGUARD
	{
		fRange = GetAttackRange(pProp->dwAttackRange);
	}
	
#ifdef __CLIENT
	ClearActParam();
	SetDestObj( idTarget, fRange );		// ÀÌµ¿ÇÒ ¸ñÇ¥¹°À» idTargetÀ¸·Î ¼³Á¤.
	SetCmd( OBJACT_MELEE_ATTACK, idTarget );		// »çÁ¤°Å¸®°¡ µÇ¾úÀ»¶§ ½ÇÇàÇÒ ¸í·É ¼ÂÆÃ.
#elif defined(__WORLDSERVER)
#ifdef __TRAFIC_1222
	if( GetDestId() == idTarget )
		return;
#endif	// __TRAFIC_1222
	SetDestObj( idTarget, fRange );		// ÀÌµ¿ÇÒ ¸ñÇ¥¹°À» idTargetÀ¸·Î ¼³Á¤.
	g_UserMng.AddMoverSetDestObj( this, idTarget, fRange );
#endif // WORLDSERVER
}

/*
void	CMover::CMD_SetCollect( CObj *pObj )
{
	if( IsInvalidObj( pObj ) )	return;
	if( pObj->GetType() != OT_MOVER )	return;
	if( m_pActMover->IsActAttack() )	return;
	if( m_pActMover->IsActJump() )		return;
	if( m_pActMover->IsActDamage() )		return;
	if( IsDie() )	return;		// Á×¾úÀ»¶§ »ç¿ë±ÝÁö.
	
	CMover *pTarget = (CMover *)pObj;
	ClearActParam();
	SetDestObj( pTarget->GetId(), 3.0f );		// ÀÌµ¿ÇÒ ¸ñÇ¥¹°À» idTargetÀ¸·Î ¼³Á¤.
	SetCmd( OBJACT_COLLECT, pTarget->GetId() );		// »çÁ¤°Å¸®°¡ µÇ¾úÀ»¶§ ½ÇÇàÇÒ ¸í·É ¼ÂÆÃ.
}
*/
//
//
//
void	CMover::CMD_SetRangeAttack( OBJID idTarget, int nPower )
{
	TRACE("CMD_SetRangeAttack(%d, %d)\n", idTarget, nPower );

	if( m_pActMover->IsActAttack() )		// ÀÌ¹Ì ¾îÅÃÁßÀÌ¸é Ãë¼Ò.
		return;

	if( IsDie() )	
		return;								// Á×¾úÀ»¶§ »ç¿ë±ÝÁö.
	
	ItemProp *pItemProp = GetActiveHandItemProp();
	if( pItemProp == NULL )		
		return;
#ifdef __CROSSBOW	
	if( pItemProp->dwItemKind3 != IK3_BOW &&  pItemProp->dwItemKind3 != IK3_CROSSBOW )	// µé°íÀÖ´Â ¹«±â°¡ º¸¿ì°¡ ¾Æ´Ï¸é ¿¡·¯
		return;
#else // __CROSSBOW
	if( pItemProp->dwItemKind3 != IK3_BOW )
		return;
#endif // __CROSSBOW

	if( IsBullet( pItemProp ) == FALSE )
		return;
	
	ClearActParam();
	SetDestObj( idTarget, GetAttackRange( pItemProp->dwAttackRange ), TRUE );		// ÀÌµ¿ÇÒ ¸ñÇ¥¹°(idTarget)°ú ±× °Å¸®¸¦ ¼³Á¤ 
	SetCmd( OBJACT_RANGE_ATTACK, idTarget, nPower, 0 );		// »çÁ¤°Å¸®°¡ µÇ¾úÀ»¶§ ½ÇÇàÇÒ ¸í·É ¼ÂÆÃ.
}

void	CMover::CMD_SetMagicAttack( OBJID idTarget, int nMagicPower )
{
	TRACE("CMD_SetMagicAttack(%d, %d)\n", idTarget, nMagicPower );

	if( m_pActMover->IsActAttack() )		// ÀÌ¹Ì ¾îÅÃÁßÀÌ¸é Ãë¼Ò.
		return;
	if( IsDie() )	return;		// Á×¾úÀ»¶§ »ç¿ë±ÝÁö.
	
	// ¼Õ¿¡ µé°í ÀÖ´Â ¿ÏµåÀÇ ÇÁ·ÎÆÛÆ¼ ²¨³¿
	// »çÁ¤°Å¸® °è»êÇÔ
	ItemProp *pItemProp = GetActiveHandItemProp();
	if( pItemProp == NULL )		return;

	if( pItemProp->dwItemKind3 != IK3_WAND /*&& pItemProp->dwItemKind3 != IK3_STAFF*/ )	//Staff->ata2k	// µé°íÀÖ´Â ¹«±â°¡ ¿Ïµå°¡ ¾Æ´Ï¸é Ãë¼Ò
		return;
	
	// µµ´Þ¹üÀ§ - ¾ó¸¶³ª °¡±îÀÌ ±ÙÁ¢ÇØ¾ßÇÏ´Â°¡. ¹ÌÅÍ´ÜÀ§
	float	fArrivalRange = GetAttackRange( AR_WAND );
	
	ClearActParam();
	SetDestObj( idTarget, fArrivalRange );		// ÀÌµ¿ÇÒ ¸ñÇ¥¹°À» idTargetÀ¸·Î ¼³Á¤.
	SetCmd( OBJACT_MAGIC_ATTACK, idTarget, nMagicPower );		// »çÁ¤°Å¸®°¡ µÇ¾úÀ»¶§ ½ÇÇàÇÒ ¸í·É ¼ÂÆÃ.
}

// vPosÀ§Ä¡·Î ÀÌµ¿¸í·É
void	CMover::CMD_SetMoveToPos( const D3DXVECTOR3 &vPos )
{
	SetDestPos( vPos );
}

// idObjÀ§Ä¡·Î ÀÌµ¿
void	CMover::CMD_SetMoveToObj( OBJID idObj )
{
	SetDestObj( idObj );
}

void	CMover::CMD_SetUseItem( CCtrl *pCtrl )
{
	ClearActParam();
	if( m_pActMover->IsFly() )
		SetDestObj( pCtrl, 20.0f );
	else
		SetDestObj( pCtrl );
	SetCmd( OBJACT_USEITEM );		// »çÁ¤°Å¸®°¡ µÇ¾úÀ»¶§ ½ÇÇàÇÒ ¸í·É ¼ÂÆÃ.
}



/*--------------------------------------------------------------------------------------------------------


											Mover act parameter
											

----------------------------------------------------------------------------------------------------------*/

void	CMover::SetActParam( OBJACT act, int nParam1, int nParam2, int nParam3 )
{
	m_oaAct = act;				
	m_nAParam[0] = nParam1;		// ¸í·É ÆÄ¶ó¸ÞÅÍ.
	m_nAParam[1] = nParam2;
	m_nAParam[2] = nParam3;
}


```
