# SakuraFeatures.h

Chemin original: `C:\Users\rdiff\Desktop\__NEWCLASS\_AIInterface\SakuraFeatures.h`
Chemin relatif: `_AIInterface\SakuraFeatures.h`
Nom du fichier: `SakuraFeatures.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#pragma once//#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&# Sakura Flyff Source %#&%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

#define NEUZ_TEST	TRUE							//| Config : TRUE = Local | FALSE = Live				[Ok]
#define NEUZ_TITLE	NEUZ_TEST == TRUE ? "FlyFF" : "Sakura Flyff Rev: 2.0" //| Config : Neuz Window Title	[Ok]
#define NEUZ_IPSET	NEUZ_TEST == TRUE ? "127.0.0.1" : "123.123.123.123"	  //| Config : Server IP			[Ok]
#define NEUZ_BHASH	NEUZ_TEST == TRUE ? "" : "sunkist"					  //| Config : Neuz Boot Hash		[Ok]
#define NEUZ_CPORT		"54705"						//| Config : Neuz Connect Port							[Ok]
#define NEUZ_PHASH		"kikugalanet"				//| Config : Neuz Password Hash							[Ok]
#define NEUZ_MSGVR		"20240612"					//| Config : Neuz Version								[Ok]
#define QUICK_LOGIN		"SakuraLogs"				//| Config : Quick Login Feature						[Ok]

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#% Server Settings %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

#define MAX_REBIRTH				1000000				//| Setting : Max Player Rebirths						[Ok]
#define	MULTIPLE_ITEM_PICKER	7.0f				//| Setting : Distance of Multi Pickup					[Ok]
#define	PERFECT_EATPET			13579				//| Setting : Perfect Pet Scroll						[Ok]
#define NEW_PET					1					//| Setting : Ultimate Pet Eggs							[Ok]
#define CUSTOM_HP_BAR			1					//| Setting : Custom HP bar (0 = No %, 1 = animated %)	[Ok]
#define PET_SPEED				7.0					//| Setting : Pet Run Speed								[Ok]
#define	MAX_SPEED				200					//| Setting : Maximum Speed Buff						[Ok]
#define	MAX_GIFT_BOX			6					//| Setting : Maximum Gift Box							[Ok]
#define	COUPLE_RATE				50					//| Setting : Experience Boost Couples					[Ok]
#define	GUILD_RATE				50					//| Setting : Experience Boost Guilds					[Ok]
#define	PETS_RATE				50					//| Setting : Experience Boost Pets						[Ok]
#define PICKUP_PET_RANGE		25					//| Setting : Range the pickup pet walks to items		[OK]
#define	MAX_FISH_BY_IP			15					//| Setting : Max Number of Fisherman by IP				[Ok]
#define MAX_LORD_EVENT			5					//| Setting : Max lord events at the same time			[Ok]

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&# Sakura Features %#&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

#define	__REBIRTH									//| Unlimited Rebirth System w/ Item Milestones			[Ok]
#define __REBIRTH_COUNT								//| Rebirth Counter in (H)								[Ok]
#define __REBIRTH_REQ								//| Rebirth Requirements to enter dungeons.				[Ok]
#define __FARM_BOT									//| UGH its a AI System									[Ok]
#define __PLAYER_LORDEVENT							//| Allow Players To Do Lord Events						[Ok]
#define __NO_HP_DMG_LIMIT							//| Removes HP/DMG Limits								[Ok]
#define __NO_STAT_LIMIT								//| Removed 65000 Stat limit.							[Ok]
#define	__NEWCLASS									//| New Classes											[Ok]
#define __AUTO_STATS								//| Select one stat to automatically upped on level up	[OK]
#define __CLASS_CHANGE_SCROLL						//| Scroll of Class Change (4th Class)					[Ok]
#define __Discord									//| New Discord Integration								[Ok]
#define __WEAPON_RARITY								//| Weapon / Armor Rarity System						[Ok]
#define	__AUTO_MAX_SKILL							//| Automatic skill increase							[Ok]
#define __DPSMETER_RYU								//| Player Damage Calculator							[Ok]
#define	__SHARDS									//| Rune System											[Ok]
#define	__VIP										//| VIP Premium System									[Ok]
#define __MALEVOLENT_CP								//| Ingame Player Control Panel							[Ok]
#define __INGAME_NEWS								//| View Server Updates from Website ingame				[Ok]
#define __CLASS_RELIC								//| Stat Boosting Relics (Poster Slot)					[Ok]
#define __AFK_REWARD_SYSTEM							//| Premium Reward for being afk.						[Ok]
#define __AFK_VENDING_TIME							//| Timer for vending reward							[Ok]
#define	__AFK_VENDING_REWARD						//| Premium Reward for being afk.						[Ok]
#define __APP_TELEPORTER							//| Teleporter Feature									[Ok]
#define __HIDE_COAT									//| Hides fashion items from view.						[Ok]
#define	__BLING_BLING								//| Reflection on Weapons								[Ok]
#define __CHAT_TEAM_COLOR							//| Changes the display/color of staff chats.           [Ok]
#define	__ITEM_CONVERTER							//| Buy powerups from inventory							[Ok]
#define	__MODS_MANAGER								//| Mode manager										[Ok]
#define	__REMOVE_SKILL_BUFF							//| Remove Buff System									[Ok]
#define __EMOTICON_CHAT								//| Emoticons in chat.									[Ok]
#define	__NEW_BUFF_FORMAT							//| Buff Icons are Circles w/Option						[Ok]
#define __HIDE_POWER_UPS							//| Hide powerups option								[Ok]
#define	__DROP_LOG									//| Shows drops in list on left							[Ok]
#define	__PET_FILTER								//| Advanced Petfilter									[Ok]
#define __WELCOME_MESSAGE							//| Adds a Welcome Message in chat						[Ok]
#define __NAV_TIME									//| Ingame Clock synced with your system time.			[Ok]
#define __NEW_CHANGE_JOB							//| New Automatic Job Change							[Ok]
#define	__NEW_COLOR_CHANGE							//| Hair color when creating the character.				[Ok]
#define __CREATE_CHAR_WITH_JOB						//| Create character with 1st job						[Ok]
#define	__SAVE_HIDE_PW								//| Password save + Show								[Ok]
#define	__LOGIN_CAPS								//| Caps Lock at login window							[Ok]
#define __SHOW_ALL_STATS							//| Show all stats on Inventory/Character				[Ok]
#define __WALLPAPER									//| Cycling random image at login						[Ok]
#define	__MESSENGER_CTRL_EXTENTED					//| Adds more right click commands for admins			[Ok]
#define __LNB_ANIMATED_HATS							//| Animated Hats										[Ok]
#define	__PARTYLIST_MESSENGER						//| Adds Party Player list to messenger					[Ok]
#define __GUILD_BUFF 								//| Improved Guild Buffs with Perins					[Ok]
#define	__BUFF_SERVER								//| Buffs for everyone									[Ok]
#define __FL_SORT_PARTY_MEMBERS                     //| Ability to sort party members.						[Ok]
#define __FL_PARTY_ASSISTANTS_V2                    //| Ability to choose a Party Assistant.				[Ok]
#define __FL_RENAMEPARTY                            //| Ability to rename the party							[Ok]
#define __FL_NEW_GUILD_PERM							//| Ability to choose a Guild Assistant.				[Ok]
#define __FL_LAST_SEEN_NEW							//| Last Seen Feature									[Ok]
#define __FL_NEWCUR									//| Animated & changeable cursors						[Ok]
#define __FL_UPDATE_TASKBAR							//| Moves menu to center like taskbar.                  [Ok]
#define __FL_SAVE_MESSAGES					        //| Save all private messages while client is active	[Ok]
#define __FL_QOL_UPDATE1							//| QoL Update #1 (Lord, Couple, Guild, Party)
#define __FL_SMOOTH_STATUS							//| Smooth Status Window								[OK]
#define	__MMFFCOUPLE								//| MM / FF couples										[Ok]
#define __BAG_UPDATE								//| Use items (power-ups/beads/scrolls etc) from bag	[Ok]
#define __BAG_LOOT									//| Collect loot from mobs and collector to bag			[Ok]
#define __JOPS_GLOW									//| Improved Aura Change System							[Ok]
#define	__ADDSHOPITEM								//| Function AddShopItem NPC							[Ok]
#define __VENDOR_UPDATE								//| Vendors Update										[Ok]
#define __HIDEPETS									//| Adds option to hide pets and disable targeting.     [Ok]
#define __ignoreNpcDialogue							//| Option to ignore the npc dialogue boxes				[Ok]
#define	__BETTER_POCKET								//| Larger inventory bags								[Ok]
#define	__WIKIPEDIA_JOB								//| Wikipedia (Classes)									[Ok]
#define	__WIKIPEDIA_MONSTER							//| Wikipedia (Monsters)(GM)							[Ok]
#define	__MONSTER_INFORMATION						//| Wikipedia (Monsters)(Player)						[Ok]			
#define	__AUTO_PERIN_CONVERTER						//| Automatic Perin Convertor Inventory					[Ok]
#define __NEWINVENTORYBUTTONS						//| Backpack/Character/Zoom in Inventory				[Ok]
#define __MULTI_CREATE_ITEM							//|	Create multiple items with Wiki spawner				[Ok]
#define	__PARTY_FIND								//| Party Finder System									[Ok]
#define __ULTIMATE_GEMSLOT_UPGRADE					//| 10 Jewel Slots on Weapons.							[Ok]
#define	__UPGRADE									//| Application to improve objects						[Ok]
#define	__MODEL_VIEW								//| Model Viewer										[Ok]
#define __ITEM_COUNT_TOOLTIP						//| Quantity of item in description						[Ok]
#define	__PLAYER_LIST								//| List of Connected Players							[Ok]
#define	__SWITCH_GLOW_OLDNEW						//| Switch Weapon Glow Old/New							[Ok]
#define __NO_PET_LIFE								//| Pets dont have lives								[Ok]
#define	__CANDY_CRUSH								//| Candy Crush System									[Ok]
#define __ANI_WING									//| Animated WingMask									[Ok]
#define	__WINGSFX									//| Item mask with SFX									[Ok]
#define __MOUNT										//| Land/Air Mount System								[Ok]
#define	__AWAKE_WINDOW								//| Window for awakenings								[Ok]
#define	__REMOVE_CMM								//| Possibility of removing Durable Objects			 	[Ok]
#define	__TRAILS									//| Player Move Trail.									[Ok]
#define __WEAK_STRONG								//| Shows what element monsters are weakest.			[Ok]
#define	__RECYCLE									//| Recycling System									[Ok]
#define __GUILD_COLOR								//| Guild Level Color System							[Ok]
#define __AUTO_REMOVE_PET							//| Automatically removes pets when flying				[Ok]
#define	__CSHOUTSCR									//| Scroll of Color Shout								[Ok]
#define	__NO_GUILD_DELAY							//| No cooldown to change guild							[Ok]
#define	__COLLECT_SPEED_SCROLL						//| Speed of Collector									[Ok]
#define __STACKABLE_ITEM							//| Stackable Consumables								[Ok]
#define	__VOICE_LINES								//| Japanese Voices										[Ok]
#define	__REMOVE_BUFF_TIME							//| Fixed buff 1 hour which is reset				    [Ok]
#define	__EXTENDED_SALE_SYSTEM						//| Perin Currency in Private Vendors					[Ok]
#define	__VAGA_ICON									//| Buff Bonus based on Levels							[Ok]
#define	__QUICK_SELL								//| Rapid Sell Blue Items								[Ok]
#define	__NEWS_DIAMOND								//| Choice of Jewel Stat								[Ok]
#define	__USER_OWN_TITLE							//| Personal Titles										[Ok]
#define	__RECOVER_RATE								//| Removed HP limit for regeneration					[Ok]
#define	__BUFF_PANG_UPDATE							//| Allows you to obtain buffs according to the class	[Ok]
#define	__TRADE_FASHION_PET							//| Exchange Blessed Fashion/Pets						[Ok]
#define __MOVE_LIKE_OFFI							//| Move like official									[Ok]
#define __ENEMY_SYSTEM								//| Shows Enemy guild on Siege.							[Ok]
#define __AWAKE_MASK								//| Blessings Available for Masks						[Ok]
#define __SHUFFLE_DROP								//| Shuffle drop index to randomize	order				[Ok]
#define __RM_HERO_SKILL								//| Changes rm hero skill to fast assist/rm buff		[Ok]
#define __SOLO_PARTY_EXP							//| Solo party leveling									[Ok]
#define __AROUND_BUFF								//| Around Buff command for Staff						[Ok]
#define __PARTY_LOCATION							//| Location in Party Window							[Ok]
#define	__CHANGE_HOT_KEY							//| Change HotKeys										[Ok]
#define __COOLDOWNOFF								//| Disable cooldown for action slots					[Ok]
#define	__PERM_EXTRABAGS							//| Permanent extra bags for free.						[Ok]
#define __LDE_SMELTWND								//| Better Updated Safe Upgrade							[Ok]
#define __WIKI_ITEMS_V2						        //| Item Wiki with more filters							[Ok]
#define	__SYS_WORLDBOSS								//|	WorldBoss.xml - Bosses last 1 hour					[Ok]
#define	__ONEHANDYOYO								//| Can use 2 YoYos										[Ok]
#define	__EATPET_STATS								//| Stats on Pickup Pets								[Ok]
#define __2HANDED_SHIELD                            //| Shield on two handed classes.                       [Ok]
#define	__AWAKE_JEWELRY                             //| Jewelry Awakening.                                  [Ok]
#define __ADVANCED_MAIL								//| Fast collect/delete mail							[Ok]
#define __PET_COLLISION								//| Removed pet collisons from World Objects			[Ok]
#define __FTOOL										//| Ftool System										[Ok]
#define __PET_EXP									//| Pet Experience Increase								[Ok]
#define	__GOLDEN_MINE								//| Addition of the Gold Mine							[Ok]
#define	__PET_AUTO_LEVEL_UP							//| Auto Level Pets										[Ok]
#define	__MOONBEAM									//| Moon Beam skill										[Ok]
#define __WRITING_SAY								//| Display of "Is writing" in mp						[Ok]
#define __COLLECT_EXTRA								//| Fishing System										[Ok]
#define __VICIOUS_SUMMONER							//| Summons a friend to cheer you on.					[Ok]
#define	__MONSTER_RAID								//| Automatic Invasion System							[Ok]
#define	__MONSTER_CLASH								//| Evento misto de PvP e PvM.
#define __BADGE
#define __BADGE_HONOR_COMBINE

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#% UI/Graphic Updates %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

#define	__MULTIPLE_THEME							//| UI Changer in game options							[Ok]
#define __FLYFF_ULTRAHD								//| Support for 1080p, 1440p, 4k Resolution		        [Ok]
#define	__BLOOM_QUALITY								//| Bloom Quality										[Ok]
#define	__ALIASING									//| Anti Aliasing										[Ok]
#define	__ANISOTROPIC								//| Anisotropic Filtering								[Ok]
#define	__ENHENCE_TERRAIN_RENDER					//| Terrain Render Fix									[Ok]
#define	__YENV										//| Bump Filter											[Ok]
#define	__YENV_WITHOUT_BUMP							//| No Bump Filter										[Ok]
#define	__TEXT_EDITS								//| New text font/style for item count					[Ok]
#define __TRANS_CHAT								//| Transparent chat feature							[Ok]
#define __NEW_NIGHT									//| New Night System									[Ok]
#define __AddTextColored							//| Adds MMI_ Text Color.								[Ok]
#define	__ENGINE_UPGRADE							//| Small Game Engine Upgrades							[Ok]
#define	__MT_RENDERING								//| Multi Threaded Rendering							[Ok]
#define	__OPTIMIZE									//| Graphic Optimizations								[Ok]
#define	__MOD_OBJARR								//| Load more objects at once							[Ok]
#define	__RENDERLINE_FIX							//| Remder Line Fix										[Ok]
#define	__DMG_SPACE									//| Damage Spaces										[Ok]
#define	__TABBED_INV								//| Tabbed Inventory (search tab sort)					[Ok]
#define __INVENTORY_POINTER							//| Inventory Pointers									[Ok]
#define __LOOT_BEACON								//| Shows light beacons on rare items.					[Ok]
#define __LOOT_TEXT									//| Ground Items Text Overlay							[Ok]
#define __LOGIN_VIDEO								//| Login Video											[Ok]
#define	__NAME_COLOR								//| Change Player Name Color							[Ok]
#define	__NAME_FONT									//| Change Player Name Font								[Ok]
#define	__RESIZE_CHARACTER							//| Resize Your Character								[Ok]
#define	__SFX_SHIELDS								//| SFX on shields										[Ok]
#define __SPLASH_SCREEN								//| Splash screen when loading neuz						[Ok]
#define __BETTER_SKILL_TOOLTIP						//| Better Skill Tooltip System							[Ok]
#define __VENDING_RENDER							//| Changed positioning of vendor title bar rendering	[Ok]
#define __MASQUERADE								//| Updated Textures and Terrain						[Ok]
#define __ADVANCED_ANNOUNCEMENT						//| Announcement BG IMG									[Ok]
#define __STAFF_CONNECT								//| Staff Connect Message								[Ok]
#define __SYSTEM_INDIVIDUAL							//| System Shout for Individual Users					[Ok]
#define __BETTER_MODEL_CACHE						//| Better Model Caching								[Ok]
#define __AEGON_TEX_LOAD							//| Improved texture loading							[Ok]
#define __SystemMessage_MaxUpgrade					//| Outputs a message on max +							[Ok]
#define __VIEW_SETEFFECT							//| Shows set effect with Shift + Hover Item			[Ok]
#define __LOGOUT_CHAR_SELECT						//| logout to char select option						[OK]
#define __AEGON_APNG

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%& Fixes / Security #%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

#define	__LDE_LSTBOX_FIX							//| Fix - lag within listboxes.							[Ok]
#define	__LDE_LORDNME_FIX							//| Fix - lord name display.							[Ok]
#define	__AISAKA_TASKBAR_FIX						//| Fix - Centers taskbar #.							[Ok]
#define __FL_PARTY_ASSISTANTS_V2_FIX				//| Fix - From Florist									[Ok]
#define __FIX_REMOVESFX								//| Fix - Fixes SFX not removing when logged out.		[Ok]
#define	__KIA_GOALDATA_FIX							//| Fix - Fixes quest arrow bug.						[Ok]
#define	__FIX_TEXTUREBUG							//| Fix - Missing Texture Crash							[Ok]
#define __FL_AIO_05_02_21							//| Fix - AiO improvements/fixes						[Ok]
#define __FL_FIX_LINKMAP_LEVEL						//| Experimental fix
#define	__PAUSE_MUSIC_FIX							//| Fix - Disable Rendering/Music						[Ok]
#define	__FIX_SETFST								//| Fix - New Frame Skip								[Ok]
#define	__NO_COMMAND_LIMITATION						//| Fix - No Command Limitation for Admins				[Ok]
#define	__SHADOW_FIX								//| Fix - Shadow Memory Fix								[Ok]
#define	__ARROW_FIX									//| Fix - Rangers first shot fix						[Ok]
#define	__FIX_HOUSING_CRASH							//| Fix - Furniture Crash								[Ok]
#define	__PMA_FIX_ATKMSG							//| Fix - Monster Attack Messages						[Ok]
#define __POSI_BUG_FIX						    	//| Fix - Player Position 								[Ok]
#define __POSI_BUG_FIX_2							//| Fix - Position Bugfix.								[Ok]
#define	__FIX_RANGER_ROLLER							//| Fix - Sliding Ranger 								[Ok]
#define	__DECREASE_SNAPSHOTLATENCY					//| Fix - Decrease Client Latency						[Ok]
#define	__NO_QUAKE									//| Fix - Quakes caused by doors can be glitchy			[Ok]
#define __FIXES_CUSTOM_V5							//| Fix - Various Server Fixes							[Ok]
#define __WEAPON_RARITY_CRASH_FIX					//| Fix - Fixes weapon drop rarity crash				[Ok]
#define __FIX_TELEPORT								//| Fix - Fixes Crash On Teleport						[Ok]
#define __CHAT_SCROLL_FIX							//| Fix - PC Messages to scroll							[Ok]
#define	__WINGSFXFIX								//| Fix - SFX Wings										[Ok]
#define __NAVIGATOR_RENDER_BUG_FIX					//| Fix - Navigator Render Bug Fixed					[Ok]
#define __PARTYDISBAND_FIX							//| Fix - Party disbanded in 10 min if all offline		[Ok]
#define __BAGTPFIX									//| Fix - Safe Delete Bag								[Ok]
#define __LOGOUTFIX									//| Fix - Logout Fixed									[Ok]
#define __FIX_GENDER_NPC							//| Fix - Fixed a bug on wrong serializing from Sex		[Ok]
#define __FIXES_PARTY								//| Fix - Fixes party disband on disconnect				[Ok]
#define __YOYO_FIX									//| Fix - Fixed a bug where YoYo throws wrong model		[Ok]
#define __AEGON_FIXES								//| Fix - Fixes from titanium							[Ok]
#define __FIX_CRASH_PET								//| Fix - Raised Pets will no longer crash you			[Ok]
#define __FIX_SRLZ_STATS					        //| Fix - Serialize some DST world->client				[Ok]
#define __NO_DELETE_MSG_CHAT						//| Fix - Chat Messsages Dont Disappear When Inactive	[Ok]
#define __FL_FIX_MEMORY_LEAKS				        //| Some code to prevent possible client memory leaks
#define __IMPROVEGFX0112							//| Fix
#define __BOW_DAMAGE								//| Fix
#define	__FIX_CHEAT									//| Security - Blocks some cheat programs               [Ok]
#define	__ANGEL_CREATION_FIX						//| Security - Dupe using angel creation				[Ok]
#define __GAMEGUARD									//| Security - Security Changes							[Ok]
#define __GAMEMASTER								//| Security - Limit GM Access							[Ok]
#define	__STAT_SYNC									//| Security - Syncs stats with server					[Ok]
#define	__PORT_CHANGE								//| Security - Changes Servers Ports					[Ok]
#define __RANDOM_TITLE								//| Security - Changes Neuz Title to rprevent Hooking   [Ok]
#define __FIX_ANIMATE_MODEL

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&# z0mbies L18.2 VS22 #%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

#define	__NO_GUIDESYSTEM							//: V18 - Removal of the annoying guide pang.			[Ok]
#define	__CHARACTER_TAG								//: V18 - Custom coloring tags for npc's.				[Ok]
#define	__FIX_STAT_BUFF								//| V18 - Fixes some issues present with spec_item.		[Ok]
#define __LOOKCHANGE								//| V18 - Model Transmutation like on retail.			[Ok]
#define	__LOOKCHANGE_PET							//| V18 - Pet Model Change								[Ok]
#define __LOOKCHANGE_TOOLTIP						//| V18 - Adds picture of item instead of tooltip.		[Ok]
#define __RANDOMOPTION_RETRY						//| V18 - Scroll of Awakening Augmentation.				[Ok]
#define __SLEEPING_FIX								//| V18 - Fixes the stun/sleeping bug.					[Ok]
#define	__SPEEDY_NEUZ								//| V18 - Fastest launch time.							[Ok]
#define __SYS_SCR_CANCELLATION						//| V18 - Scroll of Unbinding.							[Ok]
#define	__SYS_SCR_NEWACTIVITION						//| V18 - Enhanced Activition.							[Ok]
#define __SYS_SCR_NOR_SMELTING01					//| V18 - Scroll of Weapon Smelting (S).				[Ok]
#define __SYS_SCR_NOR_SMELTING02					//| V18 - Scroll of Weapon Smelting (V).				[Ok]
#define	__SYS_SCR_NOR_SMELTING03					//| V18 - Scroll of Weapon Smelting (P).				[Ok]
#define __SYS_SCR_PARTYPOINTFREE					//| V18 - Scroll of Party Amplification.				[Ok]
#define __SYS_SCR_PARTYSPEEDLEVELUP					//| V18 - Scroll of Party Growth.						[Ok]
#define __SYS_SYS_ARMOREFFECTCHANGE					//| V18 - Aura (7 days / 15 days).						[Ok]
#define __SYS_SYS_ITEMMODELRETURN					//| V18 - Revert Transmutation Scroll.					[Ok]
#define __TREASUREBOX								//| V18 - Retail like treasure box system.				[Ok]
#define	__MAP_TORCH_SYSTEM							//| V18 - Torch System									[Ok]

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%& Version 19 %#&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

#define	__MARKET_TELEPORT_V19						//| V19 - Market Teleport								[Ok]
#define __NAVIGATOR_V19								//| V19 - Minimap										[Ok]
#define __WINDOW_TITLE								//| V19 - Name of player in Neuz Title					[Ok]
#define __NEW_EXCHANGE_V19							//| V19 - Exchange Window w/Arrows						[Ok]
#define __NEW_QUEST_EMOTICON						//| V19 - New icons for quest on minimap				[Ok]
#define	__NEW_TASKBAR_V19							//| V19 - New Round Taskbar.							[Ok]
#define	__Y_INTERFACE_VER3							//| V19 - New numbers on taskbar						[Ok]
#define __OPTION_EX									//| V19 - New options menu								[Ok]

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%& Version 20 %#&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

#define __INVENTORY_SORTING							//| V20 - Inventory Sorting								[Ok]
#define __ADDMENU2									//| V20 - Add text to mmi in character.inc.				[Ok]

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%& Version 21 %#&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

#define __LEVELUP_SFX								//| V21 - level up sfx.									[Ok]
#define __PREMIUM_BATTERY							//| V21 - seperate collecting batteries.				[Ok]
#define	__SKILL_BUFF								//| V21 - Increases Buff Count/Size						[Ok]
#define __GM_COMMANDS								//| V21.2 - Adds 2 commands from v21.2.					[Ok]
#define __GUILD_WINNER_BUFF							//| V21.2 - Buffs upon playing Siege					[Ok]
#define __V21FIXES									//| V21.2 - A few fixes from v21.2						[Ok]

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#% New Awake DST &#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

#define __DST_CHANCEDROP_GOLD						//| DST_CHANCEDROP & DST_GOLDDROP						[OK]
#define __DST_COOLTIME_DUNGEON						//| DST_COOLTIME_DUNGEON_REDUCED						[OK]
#define __DST_PET_EXPERIENCE						//| DST_PET_EXPERIENCE									[OK]
#define __MIKSIK_NEWSTAT							//| DST_HEALING_AMP										[Ok]

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#% UI Changer &#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

// isSakuraTheme									//| Sakura Theme
// isCustomTheme									//| Malevolent Theme
// isClassicTheme									//| Flyff Classic Theme
// isBlueTheme										//| Sword Theme
// isGreenTheme										//| Forest Theme
// isRedTheme										//| Classic Red Theme
// isClassicBlueTheme								//| Classic Blue Theme
// isGoldTheme										//| Flyff Gold Theme
// isDragonCrossTheme								//| Flyff Blue Theme
// isGoldRedTheme									//| Flyff Red Theme

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#% DEATHMATCH NPC #%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

//#define	__DEATH_MATCH							//| PVP FFA System										[Need DB]
//#define	DEATH_MATCH_COST		25000000		//| Setting : Price to join Deathmatch					[Need DB]

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#% NAMESPACE AISAKA &#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

#define AISAKA										//| Small Edits											[Ok]

enum { ENCHANT_TIME = 2 };

#include <limits>
#include <random>
#if _HAS_CXX17
#include <optional>
#endif
#ifdef _tsRandom
#include <mutex>
#endif
namespace aisaka
{
	//remove windefs
#ifdef max
#undef max
#endif
#ifdef min
#undef min
#endif
	//todo: 5head template versions
	enum flowFlag : unsigned char
	{
		ff_under = 1 << 0,
		ff_over = 1 << 1,
		ff_downcast = 1 << 2,
		ff_NegUpcast = 1 << 3
	};
	//typename only needed pre-c++17 before std::enable_if
	template <typename Ret = unsigned long, typename A = Ret, typename B = Ret>
	typename std::enable_if<std::is_integral<Ret>::value, bool>::type checkMul(A a, B b, flowFlag&& ft = static_cast<flowFlag>(ff_over | ff_downcast | ff_NegUpcast))
	{
		static_assert((std::is_integral<A>::value || std::is_floating_point<A>::value) && (std::is_integral<B>::value || std::is_floating_point<B>::value) && std::is_integral<Ret>::value, "incorrect types");
		if (!std::numeric_limits<Ret>::is_signed)
		{
			if (ft & ff_NegUpcast) // because return result is unsigned, sometimes you dont want to signed * unsigned
				if (a < std::numeric_limits<Ret>::min() || b < std::numeric_limits<Ret>::min())
					return false;

			if (ft & ff_downcast) // values for ret have been downcasted meaning innapropriate mul unless wanted.
				if (static_cast<unsigned long long>(static_cast<Ret>(a)) != static_cast<unsigned long long>(a) || static_cast<unsigned long long>(static_cast<Ret>(b)) != static_cast<unsigned long long>(b))
					return true;

			if (a == 0 || b == 0)
				return false;

			return static_cast<Ret>(a) > std::numeric_limits<Ret>::max() / static_cast<Ret>(b);
		}
		if (ft & ff_NegUpcast) // in this case it refers to overjumping max int from a ulong -> would overflow to neg int
			if (a > std::numeric_limits<Ret>::max() || b > std::numeric_limits<Ret>::max())
				return true;

		if (ft & ff_downcast) // values for ret have been downcasted meaning innapropriate mul unless wanted.
			if (static_cast<long long>(static_cast<Ret>(a)) != static_cast<long long>(a) || static_cast<long long>(static_cast<Ret>(b)) != static_cast<long long>(b))
				return true;

		if (a == 0 || b == 0)
			return false;

		return static_cast<Ret>(a) > std::numeric_limits<Ret>::max() / static_cast<Ret>(b);
	}
	template <typename Ret = unsigned long, typename A, typename B>
	typename std::enable_if<std::numeric_limits<Ret>::is_integer, std::pair<Ret, bool>>::type eMul(A a, B b, flowFlag&& ft = static_cast<flowFlag>(ff_over | ff_downcast | ff_NegUpcast))
	{
		return make_pair(static_cast<Ret>(a) * static_cast<Ret>(b), checkMul<>(a, b, std::move(ft)));
	}
	template <typename Ret = unsigned long, typename A = Ret, typename B = Ret>
	typename std::enable_if<std::is_integral<Ret>::value, bool>::type checkAdd(A a, B b, flowFlag&& ft = static_cast<flowFlag>(ff_over | ff_downcast | ff_NegUpcast))
	{
		static_assert((std::is_integral<A>::value || std::is_floating_point<A>::value) && (std::is_integral<B>::value || std::is_floating_point<B>::value) && std::is_integral<Ret>::value, "incorrect types");
		if (!std::numeric_limits<Ret>::is_signed)
		{
			if (ft & ff_NegUpcast)
				if (a < std::numeric_limits<Ret>::min() || b < std::numeric_limits<Ret>::min())
					return false;

			if (ft & ff_downcast)
				if (static_cast<unsigned long long>(static_cast<Ret>(a)) != static_cast<unsigned long long>(a) || static_cast<unsigned long long>(static_cast<Ret>(b)) != static_cast<unsigned long long>(b))
					return true;

			if (a == 0 || b == 0)
				return false;

			return std::numeric_limits<Ret>::max() - static_cast<Ret>(a) < static_cast<Ret>(b);
		}
		if (ft & ff_NegUpcast)
			if (a > std::numeric_limits<Ret>::max() || b > std::numeric_limits<Ret>::max())
				return true;

		if (ft & ff_downcast)
			if (static_cast<long long>(static_cast<Ret>(a)) != static_cast<long long>(a) || static_cast<long long>(static_cast<Ret>(b)) != static_cast<long long>(b))
				return true;

		if (a == 0 || b == 0)
			return false;
		return std::numeric_limits<Ret>::max() - static_cast<Ret>(a) < static_cast<Ret>(b);
	}
	template <typename R = unsigned long, typename A, typename B>
	typename std::enable_if<std::numeric_limits<R>::is_integer, std::pair<R, bool>>::type eAdd(A a, B b, flowFlag&& ft = static_cast<flowFlag>(ff_over | ff_downcast | ff_NegUpcast))
	{
		return make_pair(static_cast<R>(a) + static_cast<R>(b), checkAdd<>(a, b, std::move(ft)));
	}
	template<typename Ret = long long, typename A = Ret, typename B = Ret, typename D = Ret> typename std::enable_if<std::is_floating_point<Ret>::value || std::is_integral<Ret>::value, Ret>::type mulDiv(A a, B b, D d)
	{
		static_assert((std::is_integral<A>::value || std::is_floating_point<A>::value) && (std::is_integral<B>::value || std::is_floating_point<B>::value) && (std::is_integral<D>::value || std::is_floating_point<D>::value) && (std::is_integral<Ret>::value || std::is_floating_point<Ret>::value), "incorrect types");
		return std::is_floating_point<Ret>::value ? static_cast<Ret>(static_cast<double>(a) * static_cast<double>(b) / static_cast<double>(d)) : static_cast<Ret>(static_cast<long long>(a) * static_cast<long long>(b) / static_cast<long long>(d));
	}

	namespace random
	{
#if _WIN64
		static std::mt19937_64 gen(std::mt19937_64::default_seed);
#else
		static std::mt19937 gen(std::mt19937_64::default_seed);
#endif

#ifdef _tsRandom
		inline std::mutex random_mutex;
#endif
#if (_HAS_CXX17) 
		template<class T = unsigned long> typename std::enable_if<std::is_floating_point<T>::value || std::is_integral<T>::value, T>::type rand(std::optional<T> min = std::nullopt, std::optional<T> max = std::nullopt)
		{
			static_assert(std::is_integral<T>::value || std::is_floating_point<T>::value, "not numeric");
#ifdef _tsRandom
			std::scoped_lock<std::mutex> lck(random_mutex);
#endif
			if constexpr (std::is_integral<T>::value)
			{
				const std::uniform_int_distribution dis(min.value_or(std::numeric_limits<T>::min()), max.value_or(std::numeric_limits<T>::max()));
				return dis(gen);
			}
			else
			{
				const std::uniform_real_distribution dis(min.value_or(std::numeric_limits<T>::min()), max.value_or(std::numeric_limits<T>::max()));
				return dis(gen);
			}
		}
#else
		template<class T> typename std::enable_if<std::is_floating_point<T>::value, T>::type static rand(T min = std::numeric_limits<T>::min(), T max = std::numeric_limits<T>::max())
		{
			static_assert(std::is_floating_point<T>::value, "not numeric");
#ifdef _tsRandom
			std::scoped_lock<std::mutex> lck(random_mutex);
#endif
			const std::uniform_real_distribution<T> dis(min, max);
			return dis(gen);
		}
		template<class T> typename std::enable_if<std::is_integral<T>::value, T>::type static rand(T min = std::numeric_limits<T>::min(), T max = std::numeric_limits<T>::max())
		{
			static_assert(std::is_integral<T>::value, "not numeric");
#ifdef _tsRandom
			std::scoped_lock<std::mutex> lck(random_mutex);
#endif
			const std::uniform_int_distribution<T> dis(min, max);
			return dis(gen);
		}
#endif
	}

	//reapply windefs
#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif
}
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&# In Development &#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

//#define __RECORD_BOOK
//#define __WHEEL_OF_FORTUNE						//| Wheel of fortune
//#define __MONSTER_HUNTING							//| Monster Hunting System like Universe.				[In Development - Partially Coded]
//#define __VENDING_NPC								//| Offline Vendors										[In Development - Not Coded Yet]
//#define __PLAYERS_MENU							//| Additional menus on characters						[In Development - Crashes Opening Menu]
//#define __FLY_COUPON								//| V19 - Flyff Coupon Shop								[In Development - Not Coded Yet]
//#define __SHOPPING_CART							//| V19 - New Vendor System								[In Development - Needs Changes for __VENDOR_UPDATE]
//#define __MORE_PLAYERS							//| LOL? for trolls.									[Not in Development - Just for lulz]

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#% Disabled SYS %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#

//#define __MODEL_ANIMATE_FIX						//| Fix - Incorrect frame loading of animations			[Bug - Disabled due to models deciding they want to render at 1 fps]
//#define __MODEL_NPC_VIEW							//| Model NPC Preview									[OK - Disabled cause weird]
//#define __INVENTORY_168							//| V18 - Inventory has 168 slots of space.				[Ok - Disabled for tabs]
//#define __CRITICAL_AWAKE							//| Add a different color for max awakes				[Ok - Disabled Pending Color Change]
//#define __REBIRTH_EXP								//| Reduces Exp per Rebirth								[Ok - Disabled cause players lazy asfk]

//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%& End of File %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
//|][: ~ %&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#%&#
```
