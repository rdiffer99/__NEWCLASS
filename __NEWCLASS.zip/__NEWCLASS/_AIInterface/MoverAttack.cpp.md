# MoverAttack.cpp

Chemin original: `C:\Users\rdiff\Desktop\__NEWCLASS\_AIInterface\MoverAttack.cpp`
Chemin relatif: `_AIInterface\MoverAttack.cpp`
Nom du fichier: `MoverAttack.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `cp1252`

```cpp
#include "stdafx.h"
#include "defineSound.h"
#include "defineText.h"
#include "resdata.h"
#include "defineObj.h"
#include "Party.h"
#ifdef __CLIENT			
	#include "Dialogmsg.h"
#endif

#include "eveschool.h"
#include "Mover.h"
#include "defineskill.h"

#ifdef __WORLDSERVER
	#include "user.h"
	#include "dpcoreclient.h"
	#include "dpdatabaseclient.h"
	#include "DPSrvr.h"
	#include "AttackArbiter.h"

	extern	CDPSrvr		g_DPSrvr;
	extern	CUserMng			g_UserMng;
	extern	CDPCoreClient		g_DPCoreClient;
	extern	CDPDatabaseClient	g_dpDBClient;
	extern	CDPCoreClient		g_DPCoreClient;

	#include "eveschool.h"
	extern	CGuildCombat	g_GuildCombatMng;
#if __VER >= 13 // __EXT_ENCHANT
	#include "ItemUpgrade.h"
#endif // __EXT_ENCHANT
#endif	// __WORLDSERVER

extern	CPartyMng				g_PartyMng;


const int MIN_HR = 20;


//////////////////////////////////////////////////////////////////////////
// ENUM
//////////////////////////////////////////////////////////////////////////

/*
		cell input[2];
		cell result;

		amx_ctof( input[0] ) = (float)GetStr();
		amx_ctof( input[1] ) = (float)GetLevel();

		Call_AMX( SCRIPT_GETDAMAGEBASE, &result, 2, input );		
		nDamage = (int)amx_ctof( result );
*/
enum 
{
	SCRIPT_GETATTACKRESULT,
	SCRIPT_GETCRITICALPROBABILITY,
	SCRIPT_GETDAMAGEBASE,
	SCRIPT_ISBLOCKING,
	SCRIPT_CALCDEFENSE,
};

//////////////////////////////////////////////////////////////////////////
// GLOBAL FUNCTION
//////////////////////////////////////////////////////////////////////////

// °ø¼Ó °¡ÁßÄ¡¸¦ ±¸ÇÑ´Ù. n - °¡ÁßÄ¡¸¦ ±¸ÇÏ±â À§ÇÑ Áß°£ °è»ê°ª 
float GetAttackSpeedPlusValue( int n )
{
	const int MAX_ATTACK_SPEED_PLUSVALUE = 18;

	int nIndex = n / 10;
	nIndex = max( nIndex, 0 );
	nIndex = min( nIndex, (MAX_ATTACK_SPEED_PLUSVALUE-1) );

	float fPlusValue[MAX_ATTACK_SPEED_PLUSVALUE] = {
		0.08f, 0.16f, 0.24f, 0.32f,	0.40f,
		0.48f, 0.56f, 0.64f, 0.72f,	0.80f,
		0.88f, 0.96f, 1.04f, 1.12f,	1.20f,
		1.30f, 1.38f, 1.50f
	};

	return fPlusValue[nIndex];
}

// ÃæÀü·¹º§¿¡ ÀÇÇÑ °ø°Ý·Â ÁõÆø°ªÀ» ¾ò´Â´Ù.
float GetChargeMultiplier( int nLevel )
{
	//TRACE("GetChargeMultiplier(%d)\n", nLevel );
	ASSERT( nLevel <= 4 );

	static float factors[5] = { 1.0f, 1.2f, 1.5f, 1.8f, 2.2f };
	if( 0 <= nLevel && nLevel <= 4 )
		return factors[ nLevel ];

	return 1.0f;
}

// ÃæÀü·¹º§( nLevel )¿¡ ÀÇÇÑ ¿Ïµå°ø°Ý·Â ÁõÆø°ªÀ» ¾ò´Â´Ù.
float GetWandATKMultiplier( int nLevel )
{
	switch( nLevel )  
	{
	case 0:	return 0.6f;	
	case 1:	return 0.8f;
	case 2: return 1.05f;
	case 3: return 1.1f;
	case 4: return 1.3f;
	}
	return 1.0f;
}

//////////////////////////////////////////////////////////////////////////
// CMover ATTACK RELATED MEMBER FUNCTIONS
//////////////////////////////////////////////////////////////////////////
int GetWeaponPlusDamage( int nDamage, BOOL bRandom, ItemProp* pItemProp , int nOption )
{
	return 0; // ¹æ¾î·Â ¹«½Ã°¡ ¾Æ´Ï¶ó °ø°Ý·ÂÀ» ³ôÀÌ´Â ¹æÇâÀ¸·Î ¼öÁ¤µÇ¾úÀ½ 
}


// µé°íÀÖ´Â ¹«±âÀÇ ¿É¼Ç¿¡ ÀÇÇÑ Ãß°¡ µ¥¹ÌÁö¸¦ ±¸ÇÑ´Ù. ( bRandom = TRUE )
int CMover::GetWeaponPlusDamage( int nDamage, BOOL bRandom )
{
	int nPlus = 0;
	CItemElem* pWeapon = GetWeaponItem();
	if( pWeapon )
	{
		int nOption = pWeapon->GetAbilityOption();	
		if( nOption > 10 )
			return nPlus;
		
		ItemProp* pItemProp = GetActiveHandItemProp();
		return ::GetWeaponPlusDamage( nDamage, bRandom, pItemProp, nOption ); 
	}
	return nPlus;
}

// °ø°Ý¿¡ ÀÇÇØ¼­ ³¯¾Æ°¥ ¼ö ÀÖ´Â°¡?
BOOL CMover::CanFlyByAttack() //Knockback
{
		return FALSE;
}
#ifdef __SHOW_ALL_STATS
int CMover::GetSpeedDepla()
{
	int nSpeedDepla;

	nSpeedDepla = GetParam(DST_SPEED, 0);	// Å©¸®Æ¼ÄÃ È®·üÀ» ³ô¿©ÁÖ´Â ½ºÅ³°ü·Ã 

	return nSpeedDepla;
}

int CMover::GetCriticalRate()
{
	int nCriticalRate;

	nCriticalRate = GetParam(DST_CRITICAL_BONUS, 0);	// Å©¸®Æ¼ÄÃ È®·üÀ» ³ô¿©ÁÖ´Â ½ºÅ³°ü·Ã 

	return nCriticalRate;
}

int CMover::GetSpellCastSpeed()
{
	int nSpellCastSpeed;

	nSpellCastSpeed = GetParam(DST_SPELL_RATE, 0);	// Å©¸®Æ¼ÄÃ È®·üÀ» ³ô¿©ÁÖ´Â ½ºÅ³°ü·Ã 

	return nSpellCastSpeed;
}

int CMover::GetReflectDamage()
{
	int nReflectDamage;

	nReflectDamage = GetParam(DST_REFLECT_DAMAGE, 0);	// Å©¸®Æ¼ÄÃ È®·üÀ» ³ô¿©ÁÖ´Â ½ºÅ³°ü·Ã 

	return nReflectDamage;
}

int CMover::GetHitRate()
{
	int nHitRate;

	nHitRate = GetParam(DST_ADJ_HITRATE, 0);	// Å©¸®Æ¼ÄÃ È®·üÀ» ³ô¿©ÁÖ´Â ½ºÅ³°ü·Ã 

	return nHitRate;
}

int CMover::GetBlockmelee()
{
	int nBlockmelee;

	nBlockmelee = GetParam(DST_BLOCK_MELEE, 0);	// Å©¸®Æ¼ÄÃ È®·üÀ» ³ô¿©ÁÖ´Â ½ºÅ³°ü·Ã 
#ifdef __JEFF_11
	if (nBlockmelee < 0)
		nBlockmelee = 0;
	if (nBlockmelee > 96)
		nBlockmelee = 96;
#endif	// __JEFF_11
	return nBlockmelee;
}

int CMover::GetBlockRange()
{
	int nBlockRange;

	nBlockRange = GetParam(DST_BLOCK_RANGE, 0);	// Å©¸®Æ¼ÄÃ È®·üÀ» ³ô¿©ÁÖ´Â ½ºÅ³°ü·Ã 
#ifdef __JEFF_11
	if (nBlockRange < 0)
		nBlockRange = 0;
	if (nBlockRange > 96)
		nBlockRange = 96;
#endif	// __JEFF_11
	return nBlockRange;
}

int CMover::GetEsquiveRate()
{
	int nEsquiveRate;
	nEsquiveRate = (int)((GetDex() * 0.5));
	nEsquiveRate = GetParam(DST_PARRY, 0);	// Å©¸®Æ¼ÄÃ È®·üÀ» ³ô¿©ÁÖ´Â ½ºÅ³°ü·Ã 
#ifdef __JEFF_11
	if (nEsquiveRate < 0)
		nEsquiveRate = 0;
#endif	// __JEFF_11
	return nEsquiveRate;
}
#endif //__SHOW_ALL_STATS
// °ø¼ÓÀ» ±¸ÇÑ´Ù.
float CMover::GetAttackSpeed()
{
	float fSpeed = 1.0f;
	float fItem = 1.0f;

	ItemProp* pWeaponProp = GetActiveHandItemProp();
	if( pWeaponProp )
		fItem = pWeaponProp->fAttackSpeed;

	JobProp* pProperty = prj.GetJobProp( GetJob() ); 
	ASSERT( pProperty );

	// A = int( Ä³¸¯ÅÍÀÇ °ø¼Ó + ( ¹«±âÀÇ °ø¼Ó * ( 4 * µ¦½º + ( ·¹º§ / 8 ) ) ) - 3 )
	// °ø°Ý¼Óµµ = ( ( 50 / 200 - A ) / 2 ) + °¡ÁßÄ¡ 
	int A = int( pProperty->fAttackSpeed + ( fItem * ( 4.0f * GetDex() + GetLevel() / 8.0f ) ) - 3.0f );
//	TRACE( "A =%d\n", A );
	if( 187.5f <= A )
		A	= (int)( 187.5f );
	fSpeed = ( ( 50.0f / (200.f - A) ) / 2.0f ) + GetAttackSpeedPlusValue( A );

	float fDstParam = GetParam( DST_ATTACKSPEED, 0 ) / 1000.0f;
	fSpeed += fDstParam;
	
	if( 0 < GetParam( DST_ATTACKSPEED_RATE, 0 ) )
		fSpeed = fSpeed + ( fSpeed * GetParam( DST_ATTACKSPEED_RATE, 0 ) / 100 );
	
	if( fSpeed < 0.1f )
		fSpeed = 0.1f;
	if( fSpeed > 2.0f )
		fSpeed = 2.0f;
	//TRACE( "%f\n", fSpeed );
#ifdef __NEWCLASS
	if (HasBuff(BUFF_SKILL, SI_STORM_U_SKILL_01))
		return 2.5f;
#endif // __NEWCLASS
	return fSpeed;
}

float CMover::GetCastingAniSpeed( void )
{
	float fSpeed	= 1.0F + GetParam( DST_SPELL_RATE, 0 ) / 100.0F;
	if( fSpeed < 0.1f )
		fSpeed = 0.1f;
	if( fSpeed > 2.0f )
		fSpeed = 2.0f;
#ifdef __MAX_INCANTE
#ifdef __GAMEMASTER
	if (fSpeed > __MAX_INCANTE && this->m_dwAuthorization < AUTH_GAMEMASTER3)
#else // __GAMEMASTER
	if (fSpeed > __MAX_INCANTE)
#endif // __GAMEMASTER
	{
		fSpeed = __MAX_INCANTE;
	}
#endif // __MAX_INCANTE
	return fSpeed;
}

int CMover::GetCastingTime( int nCastingTime )
{
	int nTime	= nCastingTime - nCastingTime * GetParam( DST_SPELL_RATE, 0 ) / 100;
#ifdef __JEFF_11
	if( nTime < 0 )
		nTime	= 0;
#endif	// __JEFF_11
	return nTime;
}

// ¾ÆÀÌÅÛ¿¡ÀÇÇÑ ¹æ¾î·Â ¾ò±â 
// bRandom: TRUE  - random °ªÀ¸·Î ¾ò±â 
//          FALSE - Æò±Õ°ªÀ¸·Î defense°ª ¾ò±â 
int CMover::GetDefenseByItem( BOOL bRandom )
{
	int nValue = m_nDefenseMax - m_nDefenseMin;
	if( bRandom )
		return m_nDefenseMin + ( nValue > 0 ? xRandom( nValue ) : 0 );
	else
		return m_nDefenseMin + ( nValue / 2 );
}

int	CMover::GetShowDefense( BOOL bRandom )
{
	ATTACK_INFO info;
	memset( &info, 0x00, sizeof(info) );
	info.dwAtkFlags = AF_GENERIC;

	return CalcDefense( &info, FALSE );   // FALSE - ¹æ¾î ÃÖ´ë/ÃÖ¼ÒÀÇ Æò±Õ°ªÀ» ¾ò°Ú´Ù.      
}

// Hit rating
int CMover::GetHR()
{
	if( IsPlayer() )
		return GetDex();
	else
		return GetProp()->dwHR;
}

BOOL CMover::GetAttackResult( CMover* pDefender, DWORD dwOption )
{
	if( m_dwMode & ONEKILL_MODE )
		return TRUE;
#ifdef __EVENTLUA_SPAWN
	if( IsPlayer() && pDefender->IsNPC() && prj.m_EventLua.IsEventSpawnMonster( pDefender->GetIndex() ) )
		return TRUE;
#endif // __EVENTLUA_SPAWN

	int nHitRate = 0;
	int nHR = GetHR();

	if( IsNPC() && pDefender->IsPlayer() )
	{
		nHitRate = (int)( ((nHR*1.5f) / (float)(nHR + pDefender->GetParrying())) * 2.0f *
			(GetLevel()*0.5f / (float)(GetLevel() + pDefender->GetLevel() * 0.3f )) * 100.0f );
	}
	else if( IsPlayer() && pDefender->IsNPC() )	// Player VS Monster
	{
		nHitRate = (int)(  ((nHR*1.6f) / (float)(nHR + pDefender->GetParrying())) * 1.5f * 
				   (GetLevel()*1.2f / (float)(GetLevel() + pDefender->GetLevel())) * 100.0f );

	}
	else
	{
#if __VER <= 9    // 	__PVPDEMAGE0608	//	9th PVP DEMAGE edit 
		nHitRate = (int)( ((nHR*1.6f) / (float)(nHR + pDefender->GetParrying())) * 1.2f * 0.6f * 100.0f );
#else //__PVPDEMAGE0608	//	9th PVP DEMAGE edit 
		nHitRate = (int)( ((nHR*1.6f) / (float)(nHR + pDefender->GetParrying())) * 1.2f * 
				   (GetLevel()*1.2f / (float)(GetLevel() + pDefender->GetLevel())) * 100.0f );
#endif	//__PVPDEMAGE0608	//	9th PVP DEMAGE edit 
	}
	nHitRate += GetAdjHitRate();

	if( nHitRate > 96 )
		nHitRate = 96;
	else if( nHitRate < MIN_HR )
		nHitRate = MIN_HR;

	return ( (int)( xRandom( 100 ) ) < nHitRate );
}

// ¹«±âÀÇ Ãß°¡ °ø°Ý·Â¸¦ ±¸ÇÑ´Ù.
int CMover::GetPlusWeaponATK( DWORD dwWeaponType )
{
	int nATK = 0;
	switch( dwWeaponType )
	{
	case WT_MELEE_SWD:	
		nATK = GetParam( DST_SWD_DMG, 0 );		
		break;
	case WT_MELEE_AXE:	
		nATK = GetParam( DST_AXE_DMG, 0 );		
		break;
	case WT_MELEE_KNUCKLE:
		nATK = GetParam( DST_KNUCKLE_DMG, 0 );		
		break;
	case WT_MELEE_YOYO:				// ¿ä¿ä 
		nATK = GetParam( DST_YOY_DMG, 0 );		
		break;
	case WT_RANGE_BOW:				// º¸¿ì 
		nATK = GetParam( DST_BOW_DMG, 0 );		
		break;
	}
#if __VER >= 10 // __LEGEND		//10Â÷ Àü½Â ¸¶½ºÅÍ½ºÅ³
	if(IsDualWeapon() == TRUE )
		nATK += GetParam( DST_ONEHANDMASTER_DMG, 0 );
	else
	{
		switch( dwWeaponType )
		{
		case WT_MELEE_KNUCKLE:
			nATK += GetParam( DST_KNUCKLEMASTER_DMG, 0 );
			break;
		case WT_MELEE_YOYO:				// ¿ä¿ä 
			nATK += GetParam( DST_YOYOMASTER_DMG, 0 );
			break;
		case WT_RANGE_BOW:				// º¸¿ì 
			nATK += GetParam( DST_BOWMASTER_DMG, 0 );
			break;
		case WT_MELEE_SWD:	
		case WT_MELEE_AXE:	
			nATK += GetParam( DST_TWOHANDMASTER_DMG, 0 );
			break;
		}
	}
#endif //__LEGEND		//10Â÷ Àü½Â ¸¶½ºÅÍ½ºÅ³

	return nATK;
}



// Á÷¾÷¿¡ µû¸¥ factor¸¦ ±¸ÇÑ´Ù.
float CMover::GetJobPropFactor( JOB_PROP_TYPE type )
{
	if( IsPlayer() == FALSE )
		return 1.0f;

	JobProp* pProperty = prj.GetJobProp( GetJob() ); 
	ASSERT( pProperty );

	switch( type )
	{
	case JOB_PROP_SWD:
		return pProperty->fMeleeSWD;
	case JOB_PROP_AXE:	
		return pProperty->fMeleeAXE;
	case JOB_PROP_STAFF:
		return pProperty->fMeleeSTAFF;
	case JOB_PROP_STICK:
		return pProperty->fMeleeSTICK;
	case JOB_PROP_KNUCKLE:
		return pProperty->fMeleeKNUCKLE;
	case JOB_PROP_WAND:
		return pProperty->fMagicWAND;
	case JOB_PROP_YOYO:
		return pProperty->fMeleeYOYO;
	case JOB_PROP_BLOCKING:
		return pProperty->fBlocking;
	case JOB_PROP_CRITICAL:
		return pProperty->fCritical;	
	// TODO ³ª¸ÓÁö 
	default:
		ASSERT( 0 );
		return 1.0f;
	}
}

// ¹«±âÀÇ °ø°Ý·Â¸¦ ±¸ÇÑ´Ù.
int CMover::GetWeaponATK( DWORD dwWeaponType )
{
	int nATK = 0;
	switch( dwWeaponType )
	{
	case WT_MELEE_SWD:
		nATK = (int)( float(( GetStr() - 12 ) * GetJobPropFactor(JOB_PROP_SWD)) + (float(GetLevel() * 1.1f)) );
		break;
	case WT_MELEE_AXE:
		nATK = (int)( float(( GetStr() - 12 ) * GetJobPropFactor(JOB_PROP_AXE)) + (float(GetLevel() * 1.2f)) );
		break;
	case WT_MELEE_STAFF:
		nATK = (int)( float(( GetStr() - 10 ) * GetJobPropFactor(JOB_PROP_STAFF)) + (float(GetLevel() * 1.1f)) );
		break;
	case WT_MELEE_STICK:
		nATK = (int)( float(( GetStr() - 10 ) * GetJobPropFactor(JOB_PROP_STICK)) + (float(GetLevel() * 1.3f)) );
		break;
	case WT_MELEE_KNUCKLE:
		nATK = (int)( float( (GetStr() - 10 ) * GetJobPropFactor(JOB_PROP_KNUCKLE)) + (float(GetLevel() * 1.2f)) );
		break;
	case WT_MAGIC_WAND:
		nATK = (int)( ( GetInt() - 10 ) * GetJobPropFactor(JOB_PROP_WAND) + GetLevel() * 1.2f );
		break;
	case WT_MELEE_YOYO:
//#ifdef __VER7
//		nATK = float(( GetDex() - 12 ) * GetJobPropFactor(JOB_PROP_YOYO)) + (float(GetLevel() * 1.1f));
//#else
		nATK = (int)( float(( GetStr() - 12 ) * GetJobPropFactor(JOB_PROP_YOYO)) + (float(GetLevel() * 1.1f)) );
//#endif
		break;
	case WT_RANGE_BOW:
		nATK = (int)((((GetDex() - 14) * 5.0f + (GetLevel() * 1.3f) + (GetStr() * 0.2f)) * 0.7f));       // __BOW_DAMAGE default is 4.0f boosted to 5.0f multiplier
		break;
	}

	nATK += GetPlusWeaponATK( dwWeaponType );	// ¹«±âÀÇ Ãß°¡ °ø°Ý·Â¸¦ ±¸ÇÑ´Ù.
	return nATK;
}


// °ø°Ý·ÂMin,Max¸¦ ±¸ÇÑ´Ù.
#ifdef __NO_HP_DMG_LIMIT
void CMover::GetHitMinMax(long long* pnMin, long long* pnMax, ATTACK_INFO* pInfo)
#else
void CMover::GetHitMinMax(int* pnMin, int* pnMax, ATTACK_INFO* pInfo)
#endif
{
	int nParts = PARTS_RWEAPON;
	if( pInfo )
		nParts  = pInfo->nParts;

	*pnMin = 0;
	*pnMax = 0;

	if( IsInvalidObj(this) )	
		return;

	if( IsPlayer() )
	{
		ItemProp* pItemProp = GetActiveHandItemProp( nParts );
		if( pItemProp == NULL )
			return;

		*pnMin = pItemProp->dwAbilityMin * 2;
		*pnMax = pItemProp->dwAbilityMax * 2;

		*pnMin = GetParam( DST_ABILITY_MIN, *pnMin );
		*pnMax = GetParam( DST_ABILITY_MAX, *pnMax );

		int nPlus = GetWeaponATK( pItemProp->dwWeaponType ) + GetParam( DST_CHR_DMG, 0 );
		*pnMin += nPlus;
		*pnMax += nPlus;

		CItemElem *pWeapon = GetWeaponItem( nParts );
		if( pWeapon && pWeapon->GetProp() )
		{
			float f = GetItemMultiplier( pWeapon );
#ifdef __NO_HP_DMG_LIMIT
			* pnMin = (long long)(*pnMin * f);
			*pnMax = (long long)(*pnMax * f);
#else
			* pnMin = (int)(*pnMin * f);
			*pnMax = (int)(*pnMax * f);
#endif
		}

		if( pWeapon )
		{
			int nOption = pWeapon->GetAbilityOption();
			if( nOption > 0 )
			{
				int nValue = (int)( pow( (float)( nOption ), 1.5f ) );

				*pnMin += nValue;
				*pnMax += nValue;
			}
#ifdef __WEAPON_RARITY
			WeaponRarity* nWeaponRarity = prj.m_nWeaponRarity.GetAt(pWeapon->GetWeaponRarity());
			if (nWeaponRarity && pWeapon->GetWeaponRarity() > 0)
			{
#ifdef __NO_HP_DMG_LIMIT
				* pnMin = (long long)(*pnMin * nWeaponRarity->m_fAttackRate);
				*pnMax = (long long)(*pnMax * nWeaponRarity->m_fAttackRate);
#else
				* pnMin = (int)(*pnMin * nWeaponRarity->m_fAttackRate);
				*pnMax = (int)(*pnMax * nWeaponRarity->m_fAttackRate);
#endif
			}
#endif // __WEAPON_RARITY
		}
	} 
	else
	{
		MoverProp* pMoverProp = GetProp();
		*pnMin = pMoverProp->dwAtkMin;
		*pnMax = pMoverProp->dwAtkMax;

#ifdef __NO_HP_DMG_LIMIT
		* pnMin += GetParam(DST_ABILITY_MIN, 0) + GetParam(DST_CHR_DMG, 0);
		*pnMax += GetParam(DST_ABILITY_MAX, 0) + GetParam(DST_CHR_DMG, 0);
#else
		* pnMin = GetParam(DST_ABILITY_MIN, *pnMin);
		*pnMax = GetParam(DST_ABILITY_MAX, *pnMax);

		*pnMin = GetParam(DST_CHR_DMG, *pnMin);
		*pnMax = GetParam(DST_CHR_DMG, *pnMax);
#endif			
		
		DWORD dwAtk = pMoverProp->dwAtk1;
		if( pInfo )
		{
#ifdef __NO_HP_DMG_LIMIT
			const unsigned long long dwValue = pInfo->nParam >> 16;
#else
			DWORD dwValue = pInfo->nParam >> 16;
#endif
			if( dwValue != 0 && dwValue != NULL_ID )
				dwAtk = dwValue;
		}
	
		if( dwAtk != NULL_ID )		// µé°íÀÖ´Â ¹«±â°¡ ÀÖÀ»¶© ±× ¹«±âÀÇ min,max °ª±îÁö ´õÇÑ´Ù.
		{
			ItemProp* pItemProp = prj.GetItemProp( dwAtk );
			if( pItemProp )
			{
				*pnMin += pItemProp->dwAbilityMin;
				*pnMax += pItemProp->dwAbilityMax;
			}
		}
	}
}

// ¹æ¾î·ÂÁõÆø°ªÀ» ¾ò´Â´Ù.    this´Â ¹æ¾îÀÚ
float CMover::GetDEFMultiplier( ATTACK_INFO* pInfo )
{
	float fFactor = 1.0f;
	if( IsNPC() )
	{
	#ifdef __S1108_BACK_END_SYSTEM
		 fFactor *= GetProp()->m_fDefence_Rate;
	#endif //	__S1108_BACK_END_SYSTEM
	}

	// ¾Æ¸Ó Æä³ÊÆ®·¹ÀÌÆ®´Â ¸Â´Â¼ø°£ ¹æ¾î·ÂÀ» 50%·Î °è»ê.
	if( pInfo->GetSkill() == SI_BLD_DOUBLE_ARMORPENETRATE )	
		fFactor *= 0.5f;

//	fFactor		*= (  ( 100.0f + (float)GetParam( DST_ADJDEF_RATE, 0 ) ) / 100.0f ) ;		// ÃÖÁ¾ ¹ÝÈ¯µÈ ¹æ¾î·Â °ª¿¡ ¹æ¾î·Â »ó½Â ºñÀ²À» °öÇÑ´Ù.
	fFactor		*= (  1.0f + (float)GetParam( DST_ADJDEF_RATE, 0 ) / 100.0f ) ;		// ÃÖÁ¾ ¹ÝÈ¯µÈ ¹æ¾î·Â °ª¿¡ ¹æ¾î·Â »ó½Â ºñÀ²À» °öÇÑ´Ù.

	return fFactor;
}

// ¹æ¾î·ÂÀ» °è»êÇÑ´Ù.
#ifdef __NO_HP_DMG_LIMIT
long long CMover::CalcDefense(ATTACK_INFO* pInfo, BOOL bRandom)
#else
int CMover::CalcDefense(ATTACK_INFO* pInfo, BOOL bRandom)
#endif
{
#ifdef __NO_HP_DMG_LIMIT
	long long nDefense = (CalcDefenseCore(pInfo->pAttacker, pInfo->dwAtkFlags, bRandom)) * GetDEFMultiplier(pInfo);
#else
	int nDefense = CalcDefenseCore(pInfo->pAttacker, pInfo->dwAtkFlags, bRandom);
	nDefense = (int)(nDefense * GetDEFMultiplier(pInfo));
#endif
#if __VER >= 9 && defined(__WORLDSERVER) // __EVENTLUA_ATKDEF
	if( IsPlayer() )
		nDefense += prj.m_EventLua.GetDefensePower();
#endif // __EVENTLUA_ATKDEF
	return nDefense;
}

// ¸ó½ºÅÍ ¹æ¾î·ÂÀ» °è»êÇÑ´Ù. ( generic°ú magicskillÀº °è»êµÊ )
#ifdef __NO_HP_DMG_LIMIT
long long CMover::CalcDefenseNPC(CMover* pAttacker, DWORD dwAtkFlags)
#else
int CMover::CalcDefenseNPC(CMover* pAttacker, DWORD dwAtkFlags)
#endif
{
#ifdef __NO_HP_DMG_LIMIT
	double fDefense = 0.0f;
#else
	float	fDefense = 0.0f;
#endif
	
	MoverProp* pProp = GetProp();
	if( dwAtkFlags & AF_MAGIC ) 
	{
		fDefense = pProp->dwResisMgic / 7.0f + 1;
	}
	else
	{
		ASSERT( (dwAtkFlags & AF_MELEESKILL) == AF_MELEESKILL );
		fDefense = pProp->dwNaturalArmor / 7.0f + 1;
	}

#ifdef __NO_HP_DMG_LIMIT
	return (long long)fDefense;
#else
	return (int)fDefense;
#endif
}

// ÇÃ·¹ÀÌ¾î ¹æ¾î·ÂÀ» °è»êÇÑ´Ù. ( generic, magicskillÀº »óÀ§¿¡¼­ °è»êµÊ )
#ifdef __NO_HP_DMG_LIMIT
long long CMover::CalcDefensePlayer(CMover* pAttacker, DWORD dwAtkFlags)
#else
int CMover::CalcDefensePlayer(CMover* pAttacker, DWORD dwAtkFlags)
#endif
{	
	int nDefense = 0;
	if( pAttacker->IsPlayer() )		// ÇÃ·¹ÀÌ¾î °ø°Ý 
	{			
		if( dwAtkFlags & AF_MAGIC )  
		{
#ifdef __NO_HP_DMG_LIMIT
			nDefense = (long long)(double((GetInt() * 9.04f) + (GetLevel() * 35.98f)));
#else
			nDefense = (int)(float((GetInt() * 9.04f) + (GetLevel() * 35.98f)));
#endif
		}
		else
		{
#ifdef __NO_HP_DMG_LIMIT
			long long nDEF = GetDefenseByItem() + GetParam(DST_ADJDEF, 0);
			nDefense = (long long)((double(nDEF * 2.3f) + (float(GetLevel() + (GetSta() / 2) + GetDex()) / 2.8f) - 4 + GetLevel() * 2));
#else
			int nDEF = GetDefenseByItem() + GetParam(DST_ADJDEF, 0);
			nDefense = (int)((float(nDEF * 2.3f) + (float(GetLevel() + (GetSta() / 2) + GetDex()) / 2.8f) - 4 + GetLevel() * 2));
#endif
		}
	}
	else							// ¸÷°ø°Ý
	{		
#ifdef __NO_HP_DMG_LIMIT
		nDefense = (long long)(((GetDefenseByItem() / 4 + GetParam(DST_ADJDEF, 0)) +
			(double(GetLevel() + (GetSta() / 2) + GetDex()) / 2.8f) - 4 + GetLevel() * 2));
#else
		nDefense = (int)(((GetDefenseByItem() / 4 + GetParam(DST_ADJDEF, 0)) +
			(float(GetLevel() + (GetSta() / 2) + GetDex()) / 2.8f) - 4 + GetLevel() * 2));
#endif
	}
#ifdef __JEFF_11
	if( nDefense < 0 )
		nDefense	= 0;
#endif	// __JEFF_11
	return nDefense;
}

// CalcDefense¿¡¼­ È£ÃâµÇ´Â subÇÔ¼ö 
#ifdef __NO_HP_DMG_LIMIT
long long CMover::CalcDefenseCore(CMover* pAttacker, DWORD dwAtkFlags, BOOL bRandom)
#else
int CMover::CalcDefenseCore(CMover* pAttacker, DWORD dwAtkFlags, BOOL bRandom)
#endif
{
	if( dwAtkFlags & AF_MAGICSKILL )		// ¿¹¿ÜÃ³¸®:¼Ó¼º ¸ÅÁ÷½ºÅ³ÀÇ ¹æ¾î·ÂÀ» ±¸ÇÑ´Ù.
		return GetResistMagic();

	BOOL bGeneric = (dwAtkFlags & AF_GENERIC);
	if( IsPlayer() && pAttacker && pAttacker->IsPlayer() )
		bGeneric = TRUE;

	if( bGeneric )		
	{
		float fFactor = 1.0f;
		if( IsPlayer() )
		{
			JobProp* pProperty = prj.GetJobProp( GetJob() ); 
			assert( pProperty );
			fFactor = pProperty->fFactorDef;
		}
#ifdef __NO_HP_DMG_LIMIT
		long long nDefense = (long long)(((((GetLevel() * 2) + (GetSta() / 2)) / 2.8f) - 4) + ((GetSta() - 14) * fFactor));
#else
		int nDefense = (int)(((((GetLevel() * 2) + (GetSta() / 2)) / 2.8f) - 4) + ((GetSta() - 14) * fFactor));
#endif
		nDefense += (GetDefenseByItem( bRandom ) / 4);	// ¾ÆÀÌÅÛ¿¡ ÀÇÇÑ µðÆæ½º   
		nDefense += GetParam( DST_ADJDEF, 0 );	// µðÆæ½º ¼öÁ¤Ä¡°¡ ÀÖ´Ù¸é ±×°ÍÀ» ´õÇÔ.
#ifdef __JEFF_11
		if( nDefense < 0 )
			nDefense	= 0;
#endif	// __JEFF_11
		return nDefense;
	}

	if( IsNPC() )
		return CalcDefenseNPC( pAttacker, dwAtkFlags );
	else
		return CalcDefensePlayer( pAttacker, dwAtkFlags );
}

/////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////
int CMover::GetCriticalProb( void )
{
	int nProb;
	nProb = (GetDex() / 10);
	nProb	= (int)( nProb *  GetJobPropFactor( JOB_PROP_CRITICAL ) );
	nProb = GetParam( DST_CHR_CHANCECRITICAL, nProb );	// Å©¸®Æ¼ÄÃ È®·üÀ» ³ô¿©ÁÖ´Â ½ºÅ³°ü·Ã 
#ifdef __JEFF_11
	if( nProb < 0 )
		nProb	= 0;
#endif	// __JEFF_11
	
	if( IsPlayer() )
	{
		if( m_idparty && (m_dwFlag & MVRF_CRITICAL) )	// ÆÄÆ¼ && 1È¸ Å©¸®Æ¼ÄÃ ¹ßµ¿?
		{
#ifdef __WORLDSERVER
			CParty* pParty = g_PartyMng.GetParty( m_idparty );
			if( pParty && pParty->IsMember( m_idPlayer ) )
				nProb += (pParty->m_nSizeofMember / 2);	
#else // __WORLDSERVER
			if( g_Party.IsMember( m_idPlayer ) )
				nProb += (g_Party.m_nSizeofMember / 2);	
#endif // __WORLDSERVER			
			m_dwFlag &= (~MVRF_CRITICAL);
		}

#if __VER < 9 // __S_9_ADD
		if( IsAfterDeath() )							// Á×À½ ÀÌÈÄ »óÅÂ¶ó¸é?
			nProb += CRITICAL_AFTER_DEATH;
		
		int nHitPercent = GetHitPointPercent( 100 );
		if( nHitPercent < CRITICAL_BERSERK_HP )			// HP°¡ MAX´ëºñ 30% ¹Ì¸¸? 
		{
			// CRITICAL_BERSERK_HP : nHitPercent = CRITICAL_BERSERK_PROB : x
			// 30 : 15 = 20 : x
			nProb += CRITICAL_BERSERK_PROB - ( nHitPercent * CRITICAL_BERSERK_PROB / CRITICAL_BERSERK_HP );
		}
#endif // __S_9_ADD
	}
	return nProb;
}

#ifdef __WORLDSERVER

#ifdef __NO_HP_DMG_LIMIT
long long CMover::CalcLinkAttackDamage(long long nDamage)
#else
int CMover::CalcLinkAttackDamage(int nDamage)
#endif
{
#ifdef __NO_HP_DMG_LIMIT
	long long nAdd = 0;
#else
	int nAdd = 0;
#endif
	if( IsPlayer() && m_idparty && nDamage > 0 ) // ³»°¡ ÆÄÆ¼¿¡ Âü¿© ¿©ºÎ
	{
		CParty* pParty = g_PartyMng.GetParty( m_idparty );
		if( pParty && pParty->IsMember( m_idPlayer ) )
		{
			// ¼øÈ¸±Ø´ÜÀÌ¸ç ¸µÅ©¾îÅÃÁßÀÌ¸ç ´ÜÀå¸¸ µ¥¹ÌÁö¸¦ ³ô¿©ÁØ´Ù
#ifdef __GAMEGUARD
			if (pParty->m_nKindTroup == 1 && pParty->m_nModeTime[PARTY_LINKATTACK_MODE])
#else // __GAMEGUARD
			if (pParty->m_nKindTroup == 1 && pParty->m_nModeTime[PARTY_LINKATTACK_MODE] && pParty->IsLeader(m_idPlayer))
#endif // __GAMEGUARD
			{
				int nJoinMember = 0; // Âü¿©ÇÑ ´Ü¿ø¼ö
				CUser* pLeader = (CUser*)this;
				CUser* pMemberUser;
				
				float fDist;
				D3DXVECTOR3	vDist;
#if __VER >= 12 // __PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
				if( pParty->m_nModeTime[PARTY_PARSKILL_MODE] )
				{
					nJoinMember = pParty->m_nSizeofMember;
				}
				else
				{
					for( int i = 0 ; i < pParty->m_nSizeofMember ; i++ )
					{
						pMemberUser = g_UserMng.GetUserByPlayerID( pParty->m_aMember[i].m_uPlayerId );
						if( IsValidObj( (CObj*)pMemberUser )/* && pLeader->IsNearPC( pMemberUser ) && pMemberUser->IsOrigin()*/ )
						{
							if( pLeader->m_idSetTarget == pMemberUser->m_idSetTarget
								&& ( pLeader->m_idSetTarget != NULL_ID && pMemberUser->m_idSetTarget != NULL_ID ) )
							{
								vDist = pMemberUser->GetPos() - GetPos();
								fDist = D3DXVec3LengthSq( &vDist );		// ¾ÆÀÌÅÛ ÁÝ´Â»ç¶÷°ú ¸â¹ö°£ÀÇ °Å¸®.
								if( fDist < 255.0f * 255.0f )		// xx¹ÌÅÍº¸´Ù ÀÛÀ¸¸é
									nJoinMember++; // Âü¿©ÇÑ ´Ü¿ø¼ö										
							}
						}
					}
				}
#else	//__PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
				for( int i = 0 ; i < pParty->m_nSizeofMember ; i++ )
				{
					pMemberUser = g_UserMng.GetUserByPlayerID( pParty->m_aMember[i].m_uPlayerId );
					if( IsValidObj( (CObj*)pMemberUser )/* && pLeader->IsNearPC( pMemberUser ) && pMemberUser->IsOrigin()*/ )
					{
						if( pLeader->m_idSetTarget == pMemberUser->m_idSetTarget
							&& ( pLeader->m_idSetTarget != NULL_ID && pMemberUser->m_idSetTarget != NULL_ID ) )
						{
							if( pLeader->IsSMMode( SM_PARTYSKILL1 ) || pLeader->IsSMMode( SM_PARTYSKILL15 ) || pLeader->IsSMMode( SM_PARTYSKILL30 ) )	// ¿©±â¼­ À¯·á ¾ÆÀÌÅÛ »ç¿ëÁßÀÎÁö È®ÀÎ
								nJoinMember++; // Âü¿©ÇÑ ´Ü¿ø¼ö										
							else
							{
								vDist = pMemberUser->GetPos() - GetPos();
								fDist = D3DXVec3LengthSq( &vDist );		// ¾ÆÀÌÅÛ ÁÝ´Â»ç¶÷°ú ¸â¹ö°£ÀÇ °Å¸®.
								if( fDist < 255.0f * 255.0f )		// xx¹ÌÅÍº¸´Ù ÀÛÀ¸¸é
									nJoinMember++; // Âü¿©ÇÑ ´Ü¿ø¼ö										
							}
						}
					}
				}
#endif //__PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
				nAdd = ( nDamage * nJoinMember / 10 ); 
			}
		}
	}
	return nAdd;
}

// Å©¸®Æ¼ÄÃ °ø°ÝÀÎ°¡?
BOOL CMover::IsCriticalAttack( CMover* pDefender, DWORD dwAtkFlags )
{
	if( IsSkillAttack( dwAtkFlags ) )	// ½ºÅ³ÀÌ¸é critical ¾øÀ½ 
		return FALSE;

	return ( (int)( xRandom(100) ) < GetCriticalProb() );		
}

float CMover::GetBlockFactor( CMover* pAttacker, ATTACK_INFO* pInfo )
{
	if( IsPlayer() )
	{
		int r = xRandom( 80 );
		if( r <= 5 )
			return 1.0f;	// Blocking ½ÇÆÐ
		if( r >= 75 )
			return 0.1f;	// 10À¸·Î ³ª´«´Ù.

		float fBlockA = GetLevel() / ( (GetLevel()+pAttacker->GetLevel())*15.0f );
		float fBlockB = (GetDex()+pAttacker->GetDex()+2) * ( (GetDex()-pAttacker->GetDex()) / 800.0f );
		if( fBlockB > 10.0f )
			fBlockB = 10.0f;
		float fAdd = fBlockA + fBlockB;
		if( fAdd < 0.0f )
			fAdd = 0.0f;
		
		if( pInfo->IsRangeAttack() )	// ¿ø°Å¸®ÆòÅ¸ÀÏ¶§´Â 
			fAdd += GetParam( DST_BLOCK_RANGE, 0 );		// ¿ø°Å¸®ºí·°À² º¸Á¤Ä¡¸¦ °¡Á®´Ù ¾¸
		else
			fAdd += GetParam( DST_BLOCK_MELEE, 0 );		// ¿ø°Å¸®°¡ ¾Æ´Ò¶© ±Ù°Å¸® ºí·°À²º¸Á¤Ä¡¸¦ °¡Á®´Ù ¾¸
		
		int nBR = (int)( ( GetDex() / 8.0f ) * GetJobPropFactor( JOB_PROP_BLOCKING ) + fAdd );
		if( nBR < 0 )
			nBR = 0; 

		if ( nBR > r )		// RÀÌ 6 ~ 74»çÀÌÀÇ °ªÀÌ¸é ->  BR > RÀÎ °æ¿ì Blocking ¼º°ø
			return 0.0f;
	}
	else
	{
		int r = xRandom( 100 );
	
		if( r <= 5 )			// RÀÌ 0 ~ 5ÀÇ °ªÀÌ¸é Blocking ½ÇÆÐ
			return 1.0f;
		if( r >= 95 )			// RÀÌ 95 ~ 100ÀÇ °ªÀÌ¸é Blocking ¼º°ø
			return 0.1f;

		int	nBR = (int)( ( GetParrying() - GetLevel() ) * 0.5f );  // GetParrying == ER
		if( nBR < 0 )
			nBR = 0; 

		if ( nBR > r )		// RÀÌ 6 ~ 94»çÀÌÀÇ °ªÀÌ¸é ->  BR > RÀÎ °æ¿ì Blocking ¼º°ø
			return 0.2f;	// 5·Î ³ª´«´Ù.
	}
	return 1.0f;
}

BOOL CMover::IsBlocking( CMover* pAttacker )
{
	int r = xRandom( 100 );
	
	if( r <= 5 )			// RÀÌ 0 ~ 5ÀÇ °ªÀÌ¸é Blocking ½ÇÆÐ
		return FALSE;
	if( r >= 95 )			// RÀÌ 95 ~ 100ÀÇ °ªÀÌ¸é Blocking ¼º°ø
		return TRUE;

	//¸ó½ºÅÍ Br = (¸ó½ºÅÍER - ¸ó½ºÅÍLV)*0.5
	//ÇÃ·¹ÀÌ¾î BR = ((Ä³¸¯ÅÍDex - 30) / (2 * Lv)) + (¨ç + ¨è)
	int nBR = 0;

	if( IsPlayer() )
	{
		// ¨ç : ¹æÆÐÀÇ ºí·Ï ¼öÄ¡
		// ¨è : ¾ÆÀÌÅÛ°ú ½ºÅ³ Ãß°¡Ä¡ÀÇ ÇÕ(Á¤¼ö, ¾ÆÀÌÅÛ¿¡ ºí·ÏÅ· °ªÀÌ Á¤¼ö·Î ´õÇØÁø´Ù.)
		CItemElem* pShield = GetEquipItem( PARTS_SHIELD );	
		if( pShield )
		{
			nBR = ( GetDex() - 30 ) / ( 2 * GetLevel() );
			ItemProp* pProp = pShield->GetProp();
			nBR += pProp->dwblockRating;

			//ÃÖ¼Ò 2¿¡¼­ ÃÖ´ë65 »çÀÌÀÇ °ªÀ» °¡Áø´Ù
			if( nBR < 2 )
				nBR = 2;
			else if( nBR > 65 )
				nBR = 65;
		}
		else
			nBR = 0;
	}
	else
	{
		nBR = (int)( ( GetParrying() - GetLevel() ) * 0.5f );  // GetParrying == ER
		if( nBR < 0 )
			nBR = 0; 
	}

	return ( nBR > r );		// RÀÌ 6 ~ 94»çÀÌÀÇ °ªÀÌ¸é ->  BR > RÀÎ °æ¿ì Blocking ¼º°ø
}

// this -> attacker
// ½ºÇÇ¸´¹ã(SI_PSY_PSY_SPRITBOMB) 
// ÀÚ½ÅÀÇ MP°¡ 90% ÀÌ»ó ÀÏ°æ¿ì °ø°Ý·ÂÀÇ 1.5¹è
// ÀÚ½ÅÀÇ MP°¡ 50% ÀÌ»óÀÏ°æ¿ì °ø°Ý·ÂÀÇ 1.2¹è
// ÀÚ½ÅÀÇ MP°¡ 50% ¹Ì¸¸ÀÏ °æ¿ì ±âº» µ¥¹ÌÁö
float CMover::GetDamageMultiplier( ATTACK_INFO* pInfo )
{
	float factor = 1.0f;
	int nSkill = pInfo->GetSkill(); 

	ItemProp* pSkillProp = NULL;
	AddSkillProp* pAddSkillProp = NULL;
	DWORD	dwProbability	= 0;

	if( nSkill )
	{
		pSkillProp	= prj.GetSkillProp( nSkill );		// ½ºÅ³ÀÇ ÇÁ·ÎÆÛÆ¼²¨³¿
		if( pSkillProp )
		{
			pAddSkillProp	= prj.GetAddSkillProp( pSkillProp->dwSubDefine, pInfo->GetSkillLevel() );
			if( pAddSkillProp )
			{
				dwProbability	= pAddSkillProp->nProbability;
#if __VER >= 9	// __SKILL_0706
				if( pInfo->pAttacker->IsPlayer() && pInfo->pDefender->IsPlayer() )
					dwProbability	= pAddSkillProp->nProbabilityPVP;
#endif	// __SKILL_0706
				if( pAddSkillProp->nSkillCount > 0 )	//  ¹ß»çÃ¼ °³¼ö°¡ ÀÖ´Â°Ç
					factor	/= (float)pAddSkillProp->nSkillCount;	// ¹ß»çÃ¼ °³¼ö¸¸Å­ µ¥¹ÌÁö¸¦ ³ª´²¼­ ÁÜ.
			}
		}
	}

	// ½ÎÀÌ·±Æ®¼¦ÀÌ¸é µ¥¹ÌÁö 2¹è, ´ÙÅ©ÀÏ·çÁ¯»óÅÂÀÌ¸é ÇØÁ¦ÇÑ´Ù.
	if( HasBuff( BUFF_SKILL, SI_ACR_SUP_DARKILLUSION ) )
	{
		switch( nSkill )
		{
		case SI_JST_YOYO_BACKSTAB:   //ÃÖ´ë 2¹è
		case SI_JST_YOYO_VATALSTAB:  //ÃÖ´ë 4¹è
		case SI_ACR_BOW_SILENTSHOT:
			{
				factor *= 1.4f;
				break;
			}
		}
	}

	switch( nSkill )
	{
	case SI_JST_YOYO_VATALSTAB:
		if( xRandom( 100 ) < dwProbability )
			factor *= 2.0f;
		break;		
	case SI_ACR_BOW_AIMEDSHOT:
		if( xRandom( 100 ) < dwProbability )
			factor = 4.0f; // Tom: factor 4 is way better, else the shot just suxx!
		break;		
	case SI_ACR_BOW_JUNKBOW:		// ¾ûÅÍ¸® È­»ìÀº È®·ü·Î µ¥¹ÌÁö¸¦ ÁØ´Ù.
		if( xRandom( 100 ) > dwProbability )
			factor = 0.0f;
		break;		
 	case SI_JST_YOYO_HITOFPENYA:
		factor	*= ( pAddSkillProp->nDestData1[0] / 100.0f );
		break;	
#ifdef __MOONBEAM
	case SI_RIN_MOONBEAM: //triggers x2 dmg
		if (xRandom(100) > 90)
			factor *= 2.0f;
		break;
#endif // __MOONBEAM
	}
	
	if (nSkill == SI_PSY_PSY_SPRITBOMB)
	{
		float fPercent = (float)GetManaPointPercent();
		if (fPercent > 100.0f)
		{
			fPercent = 100.0f;
		}
		else if (fPercent < 10.0f) 
		{
			fPercent = 10.0f;
		}
		factor = factor * 1.5f * (fPercent / 100.0f);
	}

	if( IsNPC() )	// ¹ö¼­Ä¿AI°¡ ÀÖ´Ù.
	{
		int nBerserkHP = GetProp()->m_nBerserkHP;
		if( nBerserkHP > 0 && GetHitPointPercent( 100 ) <= nBerserkHP )
			factor *= GetProp()->m_fBerserkDmgMul;
	}
	else
	{
		if( pInfo->pDefender->IsPlayer() )		// ÇÃ·¹ÀÌ¾î¿Í ÇÃ·¹ÀÌ¾îÀÇ °ø°ÝÀº µ¥¹ÌÁö °¨¼Ò 
			factor *= 0.60f;

		if( pInfo->nParts == PARTS_LWEAPON )	// ¿Þ¼ÕÀº °ø°Ý·ÂÀÌ 75ÇÁ·Î·Î 
			factor *= 0.75f;
	}

	if( pInfo->pAttacker->IsPlayer() )
		if( pInfo->pDefender->GetAdjParam( DST_CHRSTATE ) & CHS_DOUBLE )		// ´õºíµ¥¹ÌÁö »óÅÂ °É·È´Ù
			factor *= 2.0f;

	int nDelta = pInfo->pDefender->GetLevel() - pInfo->pAttacker->GetLevel(); 	

	// ¿¹¿ÜÃ³¸®: Å¬¶ô¿öÅ©¿Í °æºñº´Àº ·¹º§Â÷ Æä³ÎÆ¼ skip
	if( pInfo->pAttacker->IsNPC() )
	{
		DWORD dwClass = pInfo->pAttacker->GetProp()->dwClass;
		switch( dwClass )
		{
		case RANK_GUARD:
		case RANK_SUPER:
//		case RANK_MIDBOSS:		Áß°£º¸½ºµéÀº ·¹º§Â÷ Æä³ÎÆ¼°¡ ÀÖ´Â°Ô ¸ÂÁö ¾Ê³ª ½Í´Ù.
			nDelta = 0;
			break;
		}
	}

	if( nDelta > 0 )
	{
#if __VER >= 9    // 	__PVPDEMAGE0608	//	9th PVP DEMAGE edit 
		if( pInfo->pAttacker->IsNPC() || pInfo->pDefender->IsNPC() )
		{
			const int MAX_OVER_ATK = 16;
			nDelta = min( nDelta, (MAX_OVER_ATK-1) ); 
			
			const double pi = 3.1415926535;
			double radian = ( pi * nDelta ) / (float)(MAX_OVER_ATK * 2);
			factor *= (float)cos( radian );
		}
#else //__PVPDEMAGE0608	//	9th PVP DEMAGE edit 
		if( pInfo->pAttacker->IsPlayer() && pInfo->pDefender->IsPlayer()/* && GetWorld()->GetID() == WI_WORLD_GUILDWAR */)	// ±æµå´ëÀü¸ÊÀÎ°¡? && PVPÀÎ°¡?
		{
			nDelta = min( nDelta, 25 ); 
			factor *= 25.0f / (25.0f + nDelta*2);
		}
		else
		{
			const int MAX_OVER_ATK = 16;
			nDelta = min( nDelta, (MAX_OVER_ATK-1) ); 
			
			const double pi = 3.1415926535;
			double radian = ( pi * nDelta ) / (float)(MAX_OVER_ATK * 2);
			factor *= (float)cos( radian );
		}
#endif	//__PVPDEMAGE0608	//	9th PVP DEMAGE edit 
	}

	return factor;
}





// ÀÏ¹Ý(AF_MAGICSKILL¸¦ Á¦¿ÜÇÑ) ¼Ó¼ºµ¥¹ÌÁö¸¦ °è»êÇÑ´Ù.
#ifdef __NO_HP_DMG_LIMIT 
long long CMover::CalcPropDamage(CMover* pDefender, DWORD dwAtkFlags)
#else
int CMover::CalcPropDamage(CMover* pDefender, DWORD dwAtkFlags)
#endif
{
#ifdef __NO_HP_DMG_LIMIT
	long long nAdd = 0;
	SAI79::ePropType type = SAI79::NO_PROP;
	long long nATK = 0;

#else
	int nAdd = 0;
	SAI79::ePropType type = SAI79::NO_PROP;
	int nATK = 0;
#endif

	if( IsNPC() )	// °ø°ÝÀÚ°¡ NPCÀÏ °æ¿ì	
	{			
		type = GetProp()->eElementType;
		nATK = GetProp()->wElementAtk; 
	}
	else		    // °ø°ÝÀÚ°¡ ÇÃ·¹ÀÌ¾îÀÏ °æ¿ì
	{		
		CItemElem* pItemElem = GetWeaponItem();
		if( pItemElem && pItemElem->m_bItemResist != SAI79::NO_PROP )
		{
			type = (SAI79::ePropType)pItemElem->m_bItemResist;
			nATK = pItemElem->m_nResistAbilityOption;
		
			if( ::GetLanguage() == LANG_THA )
			{
				float fResult = ((float)nATK+3.5f)*(0.5f+((float)nATK*0.01f));
				int nResult;
				nResult = (int)( fResult*fResult );
				nATK    = nResult;
			}
			else
				nATK *= 4;

			nATK += GetAdjParam( DST_CHR_WEAEATKCHANGE );
		}
		else
		{
			ItemProp* pProp = GetActiveHandItemProp();
			type = pProp->eItemType;
			nATK = pProp->wItemEatk; 
		}
	}

	if( type != SAI79::NO_PROP )	// ¼Ó¼º°ø°Ý ?
	{
#ifdef __NO_HP_DMG_LIMIT
		nAdd = (long long)(nATK * (1.0 - (double)pDefender->GetResist(type)));
#else
		nAdd = (int)(nATK * (1.0f - pDefender->GetResist(type)));
#endif
	}
	return nAdd;
}


// AF_MAGICSKILL ¼Ó¼ºµ¥¹ÌÁö¸¦ °è»êÇÑ´Ù.
#ifdef __NO_HP_DMG_LIMIT
long long CMover::GetMagicSkillPower(ATTACK_INFO* pInfo)
#else
int CMover::GetMagicSkillPower(ATTACK_INFO* pInfo)
#endif
{
	CMover* pDefender = pInfo->pDefender; 
	int nSkill = pInfo->GetSkill();
#ifdef __NO_HP_DMG_LIMIT
	long long nATK = GetMeleeSkillPower(pInfo) + GetParam(DST_ADDMAGIC, 0);
#else
	int nATK = GetMeleeSkillPower(pInfo);
	nATK = GetParam(DST_ADDMAGIC, nATK);		// Ãß°¡¸¶¹ý·Â ¼öÁ¤Ä¡.
#endif

	ItemProp* pSkillProp = prj.GetSkillProp( nSkill );		// ½ºÅ³ÀÇ ÇÁ·ÎÆÛÆ¼²¨³¿
	if( !pSkillProp )
		return nATK;

#ifdef __NO_HP_DMG_LIMIT
	switch (pSkillProp->dwSpellType)
	{
	case ST_FIRE: nATK += nATK * GetParam(DST_MASTRY_FIRE, 0) / 100.0f; break;
	case ST_WATER: nATK += nATK * GetParam(DST_MASTRY_WATER, 0) / 100.0f; break;
	case ST_ELECTRICITY: nATK += nATK * GetParam(DST_MASTRY_ELECTRICITY, 0) / 100.0f; break;
	case ST_WIND: nATK += nATK * GetParam(DST_MASTRY_WIND, 0) / 100.0f; break;
	case ST_EARTH: nATK += nATK * GetParam(DST_MASTRY_EARTH, 0) / 100.0f; break;
	}
#else
	float fRatio = 0.0f;
	switch (pSkillProp->dwSpellType)
	{
	case ST_FIRE:
		fRatio = GetParam(DST_MASTRY_FIRE, 0) / 100.0f;
		nATK = (int)(nATK + (nATK * fRatio));
		break;
	case ST_WATER:
		fRatio = GetParam(DST_MASTRY_WATER, 0) / 100.0f;
		nATK = (int)(nATK + (nATK * fRatio));
		break;
	case ST_ELECTRICITY:
		fRatio = GetParam(DST_MASTRY_ELECTRICITY, 0) / 100.0f;
		nATK = (int)(nATK + (nATK * fRatio));
		break;
	case ST_WIND:
		fRatio = GetParam(DST_MASTRY_WIND, 0) / 100.0f;
		nATK = (int)(nATK + (nATK * fRatio));
		break;
	case ST_EARTH:
		fRatio = GetParam(DST_MASTRY_EARTH, 0) / 100.0f;
		nATK = (int)(nATK + (nATK * fRatio));
		break;
	}
#endif
	return nATK;
}


float CMover::GetMagicSkillFactor( CMover* pDefender, SAI79::ePropType skillType )
{
	SAI79::ePropType itemType;
	CItemElem* pWeapon	= GetWeaponItem();
	if( pWeapon && pWeapon->m_bItemResist != SAI79::NO_PROP )
		itemType = (SAI79::ePropType)pWeapon->m_bItemResist;	// Á¦·Ã¼Ó¼º 
	else
	{
		ItemProp* pItemProp = GetActiveHandItemProp();
		if( pItemProp ) 
			itemType = pItemProp->eItemType;					// ¾ÆÀÌÅÛ ¼Ó¼º
		else
			return 1.0f;
	}

	if( skillType == itemType )
	{
		return 1.1f;
	}
	else if( ( skillType == 1 && itemType == 2 ) || 
		     ( skillType == 2 && itemType == 3 ) ||
			 ( skillType == 3 && itemType == 5 ) || 
			 ( skillType == 5 && itemType == 4 ) ||
			 ( skillType == 4 && itemType == 1 ) )		
	{
		return 0.9f;
	}
	else
		return 1.0f;
}

#ifdef __NO_HP_DMG_LIMIT
long long CMover::PostCalcMagicSkill(long long nATK, ATTACK_INFO* pInfo)
#else
int CMover::PostCalcMagicSkill(int nATK, ATTACK_INFO* pInfo)
#endif
{
	CMover*				pDefender = pInfo->pDefender;
	int					nSkill = pInfo->GetSkill();
	int					nDelta = pDefender->GetLevel() - GetLevel();
	SAI79::ePropType	skillType = SAI79::NO_PROP;
	ItemProp* pSkillProp = prj.GetSkillProp( nSkill );
	if( !pSkillProp )
		return 0;
	else
		skillType = pSkillProp->eItemType;
	
#ifdef __NO_HP_DMG_LIMIT
	double a, b;
#else
	float a, b;
#endif
#if __VER >= 9    // 	__PVPDEMAGE0608	//	9th PVP DEMAGE edit 
	if( IsNPC() || pDefender->IsNPC() )
		b = 1.0f + (int)( nDelta / 0.05f );
	else
		b = 1.0f;
#else //__PVPDEMAGE0608	//	9th PVP DEMAGE edit 
	b = 1.0f + (int)( nDelta / 0.05f );
#endif	//__PVPDEMAGE0608	//	9th PVP DEMAGE edit 

	if( b <= 0.0f )							
		b = 0.0f;

#ifdef __NO_HP_DMG_LIMIT
	long long nDEF = pDefender->CalcDefense(pInfo);
#else
	int nDEF = pDefender->CalcDefense(pInfo);
#endif
#if __VER >= 10    // 	__LEGEND
	if( pInfo->dwAtkFlags & AF_MAGICSKILL )		// ¿¹¿ÜÃ³¸®:¼Ó¼º ¸ÅÁ÷½ºÅ³ÀÇ ¹æ¾î·ÂÀ» ±¸ÇÑ´Ù.
		nATK = nATK - nATK * pDefender->GetParam( DST_RESIST_MAGIC_RATE, 0 ) / 100 ;
#endif	//__LEGEND
	a = ( nATK-nDEF ) * (1.0f - pDefender->GetResist(skillType) );

#ifdef __NO_HP_DMG_LIMIT
	return	((long long)((long long)a * GetMagicSkillFactor(pDefender, skillType)));
#else
	return	((int)((int)a * GetMagicSkillFactor(pDefender, skillType)));
#endif
}

// ¼ø¼ö°ø°Ý·ÂÀ» ÁõÆøÇÑ´Ù.
float CMover::GetATKMultiplier( CMover* pDefender, DWORD dwAtkFlags )
{
	float fMultiplier = 1.0f;

	int nParam = GetParam( DST_ATKPOWER_RATE, 0 );		// °ø°Ý·Â Áõ°¡ ¼öÁ¤Ä¡
	FLOAT fRate = 1.0f + (nParam / 100.0f);
	fMultiplier *= fRate;

	int nDstDmg = 0;
	if( IsPlayer() )
	{
		if( IsSMMode( SM_ATTACK_UP1 ) || IsSMMode( SM_ATTACK_UP ) )
			fMultiplier *= 1.2f;
#if __VER >= 9 // __ULTIMATE
		if( pDefender->IsPlayer() )
			nDstDmg = GetParam( DST_PVP_DMG, 0 );
		else
			nDstDmg = GetParam( DST_MONSTER_DMG, 0 );
#endif // __ULTIMATE
	}
	else
	{
	#ifdef __S1108_BACK_END_SYSTEM
		fMultiplier *= ( prj.m_fMonsterHitRate * GetProp()->m_fAttackPower_Rate );
	#else 
		fMultiplier *= prj.m_fMonsterHitRate;
	#endif 
	}

#if __VER >= 9 // __ULTIMATE
	if( 0 < nDstDmg )
		fMultiplier += (fMultiplier * nDstDmg / 100.0f);
#endif // __ULTIMATE

	return fMultiplier;
}

// ¼Ó¼ºÀÇ °ø°Ý Ãß°¡ÆÛ¼¾Æ®¸¦±¸ÇÑ´Ù.
int CMover::GetPropATKPlus( int nParts )
{
	int nPlusATK = 0;
	
	switch( nParts )
	{
	case PARTS_RWEAPON:
		if( m_nAttackResistRight != 255 )
			nPlusATK = 20;
		break;
	case PARTS_LWEAPON:
		if( m_nAttackResistLeft != 255 )
			nPlusATK = 20;
		break;
	}
	return nPlusATK;
}

// ¼Ó¼ºÀÇ ¹æ¾î Ãß°¡ÆÛ¼¾Æ®¸¦±¸ÇÑ´Ù.
int CMover::GetPropDEFPlus()
{
	int nPlusDEF = 0;
	if( m_nDefenseResist != 255 )
		nPlusDEF = 20;
	return nPlusDEF;
}

// GetHitPowerÇÔ¼ö¿¡¼­ »ç¿ëÇÒ ATK, DEFÀÇ Áõ°¨ Factor¸¦ ±¸ÇÑ´Ù.
void CMover::GetDamagePropertyFactor( CMover* pDefender, int* pnATKFactor, int* pnDEFFactor, int nParts )
{
#if __VER >= 14 // __EXT_ATTRIBUTE
	*pnATKFactor = 10000;	// 14Â÷ ºÎÅÍ´Â n/10000 factor·Î º¯°æ
	*pnDEFFactor = 10000;	// 14Â÷ ºÎÅÍ´Â n/10000 factor·Î º¯°æ
#else // __EXT_ATTRIBUTE
	*pnATKFactor = 100;		// ¼Ó¼º Àû¿ëÀÌ ¾øÀ¸¸é ATK¸¦ 100% ±×´ë·Î »ç¿ë 
	*pnDEFFactor = 100;		// ¼Ó¼º Àû¿ëÀÌ ¾øÀ¸¸é DEF¸¦ 100% ±×´ë·Î »ç¿ë 
#endif // __EXT_ATTRIBUTE

	SAI79::ePropType atkType, defType; 
	int atkLevel, defLevel, nPlusATK, nPlusDEF;
	atkType = defType = SAI79::NO_PROP;
#if __VER >= 14 // __EXT_ATTRIBUTE
	atkLevel = defLevel = 0;
#else // __EXT_ATTRIBUTE
	atkLevel = defLevel = 1;
#endif // __EXT_ATTRIBUTE
	nPlusATK = nPlusDEF = 0;

	if( IsPlayer() )
	{
		CItemElem* pItemElem = GetWeaponItem( nParts );
		if( pItemElem && pItemElem->m_bItemResist != SAI79::NO_PROP )
		{
			atkType = (SAI79::ePropType)pItemElem->m_bItemResist;
			atkLevel = pItemElem->m_nResistAbilityOption + GetAdjParam( DST_CHR_WEAEATKCHANGE );
		}
		else
		{
			ItemProp* pProp = GetActiveHandItemProp( nParts );
			atkType = pProp->eItemType;
		}	

		nPlusATK = GetPropATKPlus( nParts );
	}
	else
	{
		atkType = GetProp()->eElementType;
#if __VER >= 14 // __EXT_ATTRIBUTE
		atkLevel = GetProp()->wElementAtk;
#endif // __EXT_ATTRIBUTE
	}

#if __VER < 14 // __EXT_ATTRIBUTE
	if( atkType == SAI79::NO_PROP )
		return;
#endif // __EXT_ATTRIBUTE

	if( pDefender->IsPlayer() )
	{
		CItemElem* pItemElem = pDefender->GetEquipItem( PARTS_UPPER_BODY );	//½´Æ®ÀÇ ¼Ó¼ºÀ» ±¸ÇÑ´Ù.
		if( pItemElem )
		{
			defType = (SAI79::ePropType)pItemElem->m_bItemResist;
			defLevel = pItemElem->m_nResistAbilityOption;
		}

		nPlusDEF = GetPropDEFPlus();
	}
	else
	{
		defType = pDefender->GetProp()->eElementType;
#if __VER >= 14 // __EXT_ATTRIBUTE
		defLevel = pDefender->GetProp()->wElementAtk;
#endif // __EXT_ATTRIBUTE
	}

#if __VER >= 14 // __EXT_ATTRIBUTE
	if( atkType == SAI79::NO_PROP && defType == SAI79::NO_PROP )
		return;
#else // __EXT_ATTRIBUTE
	if( defType == SAI79::NO_PROP )
		return;
#endif // __EXT_ATTRIBUTE

	// ¼Ó¼ºENUMÀ» ÀÎµ¦½º·Î °®´Â Å×ÀÌºí 
	static int table[SAI79::END_PROP][SAI79::END_PROP] = {
		{0, 0, 0, 0, 0, 0}, // ¼Ó¼º¾øÀ½ 
		{0, 1, 2, 0, 3, 0},	// ºÒ   ¼Ó¼º
		{0, 3, 1, 2, 0, 0},	// ¹°   ¼Ó¼º
		{0, 0, 3, 1, 0, 2},	// Àü±â ¼Ó¼º
		{0, 2, 0, 0, 1, 3},	// ¹Ù¶÷ ¼Ó¼º
		{0, 0, 0, 3, 2, 1}	// ¶¥   ¼Ó¼º			
	};

	int result = table[ atkType ][ defType ];
#if __VER >= 14 // __EXT_ATTRIBUTE
	int nFactor = 0, nLevel = 0;
	switch( result )
	{
		case 0 : // »ó¼º ¾øÀ½
		case 1 : // °°À½
			{
				if( atkLevel > 0 && defLevel == 0 )
					nFactor += CItemUpgrade::GetInstance()->GetAttributeDamageFactor( atkLevel );
				else if( atkLevel == 0 && defLevel > 0 )
					nFactor -= CItemUpgrade::GetInstance()->GetAttributeDefenseFactor( defLevel - 3 );	// ¹æ¾î·Â
				else if( atkLevel > 0 && defLevel > 0 )
					nLevel = atkLevel - defLevel;
				break;
			}

		case 2 : // ¹æ¾îÀÚ ¿ì¼º
				nLevel = ( atkLevel - 5 ) - defLevel;
				break;
		
		case 3 : // °ø°ÝÀÚ ¿ì¼º
				nLevel = atkLevel - ( defLevel > 5 ? defLevel - 5 : 0 );
				if( nLevel > 0 )
					nFactor += CItemUpgrade::GetInstance()->GetAttributeAddAtkDmgFactor( nLevel ); // ¼Ó¼º°ü°è º¸Á¤Ä¡
				break;
	}
	
	if( nLevel != 0 )
		nFactor += ( nLevel > 0 )	?	CItemUpgrade::GetInstance()->GetAttributeDamageFactor( nLevel )
									:	-( CItemUpgrade::GetInstance()->GetAttributeDefenseFactor( -nLevel ) );	// ¹æ¾î·Â
	*pnATKFactor += nFactor;
	*pnDEFFactor += nFactor;
#else // __EXT_ATTRIBUTE	
	switch( result )
	{
	case 1:				//30% MISS
#if __VER < 13 // __EXT_ENCHANT
		if( xRandom( 100 ) < 30 )
			*pnATKFactor = 0;
#endif // __EXT_ENCHANT
		break;
	case 2:				//°ø°ÝÀÚ ¿­¼º
#if __VER >= 13 // __EXT_ENCHANT
		*pnATKFactor -= CItemUpgrade::GetInstance()->GetAttributeDamageFactor( defLevel );
		*pnDEFFactor -= CItemUpgrade::GetInstance()->GetAttributeDamageFactor( defLevel );
#else // __EXT_ENCHANT
		*pnATKFactor -= (atkLevel + 10 );
		*pnDEFFactor += (defLevel + 5 + nPlusDEF );
#endif // __EXT_ENCHANT
		break;
	case 3:				//°ø°ÝÀÚ ¿ì¼º 
#if __VER >= 13 // __EXT_ENCHANT
		*pnATKFactor += CItemUpgrade::GetInstance()->GetAttributeDamageFactor( atkLevel );
		*pnDEFFactor += CItemUpgrade::GetInstance()->GetAttributeDamageFactor( atkLevel );
#else // __EXT_ENCHANT
		*pnATKFactor += (atkLevel + 10 + nPlusATK );
		*pnDEFFactor -= (defLevel + 5 );
#endif // __EXT_ENCHANT
		break;
	}
#endif // __EXT_ATTRIBUTE
}

// ÀÏ¹Ý °ø°Ý µ¥¹ÌÁö¸¦ ±¸ÇÑ´Ù.
#ifdef __NO_HP_DMG_LIMIT
long long CMover::GetHitPower(ATTACK_INFO* pInfo)
#else
int CMover::GetHitPower(ATTACK_INFO* pInfo)
#endif
{
#ifdef __NO_HP_DMG_LIMIT
	long long nMin, nMax;
	int nATKFactor;
	long long nATK;
#else
	int nMin, nMax, nATKFactor, nATK;
#endif
	GetDamagePropertyFactor( pInfo->pDefender, &nATKFactor, &pInfo->nDEFFactor, pInfo->nParts );

#ifdef __NO_HP_DMG_LIMIT
	GetHitMinMax(&nMin, &nMax, pInfo);
#else
	GetHitMinMax(&nMin, &nMax, pInfo);
#endif

	if( IsCriticalAttack( pInfo->pDefender, pInfo->dwAtkFlags ) )
	{
		pInfo->dwAtkFlags |= AF_CRITICAL;

		float fMin = 1.1f;
		float fMax = 1.4f;
		if( GetLevel() > pInfo->pDefender->GetLevel() )  
		{
#if __VER >= 9    // 	__PVPDEMAGE0608	//	9th PVP DEMAGE edit 
			if( pInfo->pDefender->IsNPC() )
#endif	//__PVPDEMAGE0608	//	9th PVP DEMAGE edit 
			{
				fMin = 1.2f;
				fMax = 2.0f;
			}
			if( IsNPC() )
			{
				fMin = 1.4f;
				fMax = 1.8f;
			}
		}


		float fCriticalBonus	= 1 + (float)GetParam( DST_CRITICAL_BONUS, 0  ) / 100.0F;
#ifdef __JEFF_11
		if( fCriticalBonus < 0.1F )
			fCriticalBonus	= 0.1F;
#endif	// __JEFF_11
#ifdef __NO_HP_DMG_LIMIT //crit bonus
		nMin = (long long)(nMin * fMin * fCriticalBonus);
		nMax = (long long)(nMax * fMax * fCriticalBonus);
#else
		nMin = (int)(nMin * fMin * fCriticalBonus);
		nMax = (int)(nMax * fMax * fCriticalBonus);
#endif

#if __VER >= 9		// 	__FLYBYATTACK0608	//	9th FlyByAttack edit
		BOOL bFlyByAttack = xRandom(100) < 15;
		ItemProp* pItemProp = GetActiveHandItemProp();			//¿ä¿ä°ø°ÝÀÌ³ª ¹Ý»ç·ù´Â ³¯¸®Áö ¾ÊÀ½ 
		if( pItemProp && pItemProp->dwWeaponType == WT_MELEE_YOYO || (pInfo->dwAtkFlags & AF_FORCE) )
			bFlyByAttack = FALSE;
		if(pInfo->pDefender->IsPlayer() )
			bFlyByAttack = FALSE;

		if( pInfo->pDefender->CanFlyByAttack() && bFlyByAttack )
			pInfo->dwAtkFlags |= AF_FLYING;
#else //__FLYBYATTACK0608	//	9th FlyByAttack edit
		BOOL bFlyByAttack = xRandom(100) < 30;
		ItemProp* pItemProp = GetActiveHandItemProp();			//¿ä¿ä°ø°ÝÀÌ³ª ¹Ý»ç·ù´Â ³¯¸®Áö ¾ÊÀ½ 
		if( pItemProp && pItemProp->dwWeaponType == WT_MELEE_YOYO || (pInfo->dwAtkFlags & AF_FORCE) )
			bFlyByAttack = FALSE;
		if( pInfo->pDefender->CanFlyByAttack() && bFlyByAttack )
			pInfo->dwAtkFlags |= AF_FLYING;
#endif	//__FLYBYATTACK0608	//	9th FlyByAttack edit
	}		

#ifdef __NO_HP_DMG_LIMIT
	nATK = aisaka::random::rand<long long>(nMin, nMax);						// °ø°Ý·Â¿¡ ·£´ýÀû¿ë  
	nATK = aisaka::mulDiv(nATK, nATKFactor, 10000);				// 14Â÷ ºÎÅÍ´Â n/10000 °ªÀ¸·Î º¯°æ
#else
	nATK = xRandom(nMin, nMax);						// °ø°Ý·Â¿¡ ·£´ýÀû¿ë  
#if __VER >= 14 // __EXT_ATTRIBUTE
	nATK = MulDiv(nATK, nATKFactor, 10000);				// 14Â÷ ºÎÅÍ´Â n/10000 °ªÀ¸·Î º¯°æ
#else // __EXT_ATTRIBUTE
	nATK = MulDiv(nATK, nATKFactor, 100);				// ¼Ó¼º »ó¼º¿¡ÀÇÇÑ ÆÑÅÍ¸¦ °öÇÑ´Ù. nATKFactor 0-100»çÀÌÀÇ ÆÛ¼¾Æ®°ª  
#endif // __EXT_ATTRIBUTE
#endif
#ifdef __NO_HP_DMG_LIMIT
	if (pInfo->IsRangeAttack())						// ÇÃ·¹ÀÌ¾îÀÇ ¿ø°Å¸® °ø°ÝÀÇ °æ¿ì 
		nATK = (nATK * GetChargeMultiplier(pInfo->GetChargeLevel()));		// ÃæÀü·¹º§¿¡ ÀÇÇÑ ÁõÆøÃ³¸® 
#else
	if (pInfo->IsRangeAttack())						// ÇÃ·¹ÀÌ¾îÀÇ ¿ø°Å¸® °ø°ÝÀÇ °æ¿ì 
		nATK = (int)(nATK * GetChargeMultiplier(pInfo->GetChargeLevel()));		// ÃæÀü·¹º§¿¡ ÀÇÇÑ ÁõÆøÃ³¸® 
#endif

//	TRACE("nMin:%d nMax:%d nATK:%d nATKFactor:%d\n", nMin, nMax, nATK, nATKFactor ); 
	return nATK;
}

#ifdef __NO_HP_DMG_LIMIT
long long CMover::PostCalcGeneric(long long nATK, ATTACK_INFO* pInfo)
#else
int CMover::PostCalcGeneric(int nATK, ATTACK_INFO* pInfo)
#endif
{
#ifdef __NO_HP_DMG_LIMIT
	long long nDEF = pInfo->pDefender->CalcDefense(pInfo);
	nDEF = aisaka::mulDiv(nDEF, pInfo->nDEFFactor, 10000);	// 14Â÷ºÎÅÍ n/10000À¸·Î º¯°æ
#else
	int nDEF = pInfo->pDefender->CalcDefense(pInfo);
#if __VER >= 14 // __EXT_ATTRIBUTE
	nDEF = MulDiv(nDEF, pInfo->nDEFFactor, 10000);	// 14Â÷ºÎÅÍ n/10000À¸·Î º¯°æ
#else // __EXT_ATTRIBUTE
	nDEF = MulDiv(nDEF, pInfo->nDEFFactor, 100);
#endif // __EXT_ATTRIBUTE
#endif

#ifdef __NO_HP_DMG_LIMIT
	long long nDamage = nATK - nDEF;
#else
	int nDamage = nATK - nDEF;
#endif
	if( nDamage > 0 )
	{
		float fBlock = pInfo->pDefender->GetBlockFactor( this, pInfo );
		if( fBlock < 1.0f )
		{
			pInfo->dwAtkFlags |= AF_BLOCKING;
#ifdef __NO_HP_DMG_LIMIT
			nDamage = (long long)(nDamage * fBlock);
#else
			nDamage = (int)(nDamage * fBlock);
#endif
		}
	}
	else
	{
		nDamage = 0;
	}

	// NPCÀÇ °æ¿ì ÃÖ¼Ò µ¥¹ÌÁö°¡ µé¾î°¡°Ô ÇÑ´Ù.
	if( pInfo->pAttacker->IsNPC() && pInfo->pDefender->IsPlayer() )	
	{
#ifdef __NO_HP_DMG_LIMIT
		long long nMin = max(0ll, nATK * 0.1f);	// ¸ó½ºÅÍ °ø°Ý·ÂÀÇ 10% µ¥¹ÌÁö°¡ ¹«Á¶°Ç µé¾î°¥ ¼ö ÀÖ°Ô ÇØ ÁØ´Ù.
#else
		int nMin = (int)(max(0, nATK * 0.1f));	// ¸ó½ºÅÍ °ø°Ý·ÂÀÇ 10% µ¥¹ÌÁö°¡ ¹«Á¶°Ç µé¾î°¥ ¼ö ÀÖ°Ô ÇØ ÁØ´Ù.
#endif
		nDamage = max( nDamage, nMin );
	}

	nDamage += GetWeaponPlusDamage( nDamage );	// ÀÎÃ¾Æ® ¿É¼Ç µ¥¹ÌÁö( ¹æ¾î·Â ¹«°ü ) 
	if( nDamage == 0 )
	{
		pInfo->dwAtkFlags &= ~AF_CRITICAL;
		pInfo->dwAtkFlags &= ~AF_FLYING;
	}
	return nDamage;
}

#ifdef __NO_HP_DMG_LIMIT
long long CMover::GetMeleeSkillPower(ATTACK_INFO* pInfo)
#else
int	CMover::GetMeleeSkillPower(ATTACK_INFO* pInfo)
#endif
{
	int nSkill = pInfo->GetSkill();
	int nSkillLv = pInfo->GetSkillLevel();
	//int(¹«±âÀÇAbilityMinMax * (±â¼úÀÇAbilityMinMax + 10) / 6 + ¹«±âÀÇAbilityMinMax)
	ItemProp* pItemProp = GetActiveHandItemProp();			// µé°íÀÖ´Â ¹«±âÀÇ ÇÁ·ÎÆÛÆ¼ ²¨³¿
	ItemProp* pSkillProp = prj.GetSkillProp( nSkill );		// ½ºÅ³ÀÇ ÇÁ·ÎÆÛÆ¼²¨³¿
	if( !pItemProp || !pSkillProp )
	{
		Error( "CMover::GetMeleeSkillPower() - nSkill : %d, Name : %s, Item : %d",
			nSkill, pInfo->pAttacker ? pInfo->pAttacker->GetName() : "xxx", pItemProp ? pItemProp->dwID : 0 );
		return 1;
	}
	AddSkillProp* pAddSkillProp = prj.GetAddSkillProp( pSkillProp->dwSubDefine, nSkillLv );
	if( !pAddSkillProp )
		return 1;

	CItemElem *pWeapon = GetWeaponItem();		// ¼Õ¿¡µç ¾ÆÀÌÅÛÀÇ Æ÷ÀÎÅÍ.
#ifdef __NO_HP_DMG_LIMIT
	long long nMin, nMax;
#else
	int nMin, nMax;
#endif
	GetItemATKPower( &nMin, &nMax, pItemProp, pWeapon ); 

#ifdef __NO_HP_DMG_LIMIT
	long long nReferStat = 0, nReferStat1 = 0, nReferStat2 = 0;
#else
	int   nReferStat = 0, nReferStat1 = 0, nReferStat2 = 0;
#endif
	switch(pSkillProp->dwReferStat1)
	{
	case DST_STR:		nReferStat1 = GetStr();		break;
	case DST_DEX:		nReferStat1 = GetDex();		break;
	case DST_INT:		nReferStat1 = GetInt();		break;
	case DST_STA:		nReferStat1 = GetSta();		break;
	}
	switch(pSkillProp->dwReferStat2)
	{
	case DST_STR:		nReferStat2 = GetStr();		break;
	case DST_DEX:		nReferStat2 = GetDex();		break;
	case DST_INT:		nReferStat2 = GetInt();		break;
	case DST_STA:		nReferStat2 = GetSta();		break;
	}
	
	if( pSkillProp->dwReferTarget1 == RT_ATTACK )
		if( pSkillProp->dwReferValue1 != NULL_ID )
#ifdef __NO_HP_DMG_LIMIT
			nReferStat1 = ((((long long)pSkillProp->dwReferValue1 / 10.0f) * nReferStat1) + ((long long)pAddSkillProp->dwSkillLvl * FLOAT(nReferStat1 / 50.0f)));
#else
			nReferStat1 = (int)(((pSkillProp->dwReferValue1 / 10.0f) * nReferStat1) + (pAddSkillProp->dwSkillLvl * FLOAT(nReferStat1 / 50.0f)));
#endif

	if( pSkillProp->dwReferTarget2 == RT_ATTACK )
		if( pSkillProp->dwReferValue2 != NULL_ID )
			nReferStat2 = (int)( ((pSkillProp->dwReferValue2/10.0f)*nReferStat2) + (pAddSkillProp->dwSkillLvl * FLOAT(nReferStat2/50.0f)) );

	nReferStat = nReferStat1 + nReferStat2;
#ifdef __NO_HP_DMG_LIMIT
	double fPowerMin, fPowerMax;
#else
	float fPowerMin, fPowerMax;
#endif

	DWORD dwSkillAbilityMin	= pAddSkillProp->dwAbilityMin;
	DWORD dwSkillAbilityMax	= pAddSkillProp->dwAbilityMax;
#if __VER >= 9	// __SKILL_0706
	if( pInfo->pAttacker->IsPlayer() && pInfo->pDefender->IsPlayer() )
	{
		dwSkillAbilityMin	= pAddSkillProp->dwAbilityMinPVP;
		dwSkillAbilityMax	= pAddSkillProp->dwAbilityMaxPVP;
	}	
#endif	// __SKILL_0706

	if( pWeapon )
	{
#ifdef __NO_HP_DMG_LIMIT
		fPowerMin = (double)((((long long)nMin + ((long long)dwSkillAbilityMin + pWeapon->GetProp()->nAddSkillMin) * 5ll + nReferStat - 20ll) * (16ll + nSkillLv) / 13ll));
		fPowerMax = (double)((((long long)nMax + ((long long)dwSkillAbilityMax + pWeapon->GetProp()->nAddSkillMax) * 5ll + nReferStat - 20ll) * (16ll + nSkillLv) / 13ll));
#else
		fPowerMin = (float)(((nMin + ((int)dwSkillAbilityMin + pWeapon->GetProp()->nAddSkillMin) * 5 + nReferStat - 20) * (16 + nSkillLv) / 13));
		fPowerMax = (float)(((nMax + ((int)dwSkillAbilityMax + pWeapon->GetProp()->nAddSkillMax) * 5 + nReferStat - 20) * (16 + nSkillLv) / 13));
#endif
	}
	else
	{
#ifdef __NO_HP_DMG_LIMIT
		fPowerMin = (double)((((long long)nMin + (long long)dwSkillAbilityMin * 5ll + nReferStat - 20ll) * (16ll + nSkillLv) / 13ll));
		fPowerMax = (double)((((long long)nMax + (long long)dwSkillAbilityMax * 5ll + nReferStat - 20ll) * (16ll + nSkillLv) / 13ll));
#else
		fPowerMin = (float)(((nMin + (int)dwSkillAbilityMin * 5 + nReferStat - 20) * (16 + nSkillLv) / 13));
		fPowerMax = (float)(((nMax + (int)dwSkillAbilityMax * 5 + nReferStat - 20) * (16 + nSkillLv) / 13));
#endif
	}

	int nWeaponDamage = GetPlusWeaponATK( pItemProp->dwWeaponType );

#ifdef __NO_HP_DMG_LIMIT
	fPowerMin = (double)(GetParam(DST_CHR_DMG, (long long)(fPowerMin)) + nWeaponDamage);
	fPowerMax = (double)(GetParam(DST_CHR_DMG, (long long)(fPowerMax)) + nWeaponDamage);
	return (fPowerMax - fPowerMin) + 1 <= 0 ? static_cast<long long>(fPowerMin) : static_cast<long long>(aisaka::random::rand<double>(fPowerMin, fPowerMax));
#else
	fPowerMin = (float)(GetParam(DST_CHR_DMG, (int)(fPowerMin)) + nWeaponDamage);
	fPowerMax = (float)(GetParam(DST_CHR_DMG, (int)(fPowerMax)) + nWeaponDamage);
	float fMinMax = (fPowerMax - fPowerMin) + 1;
	if (fMinMax <= 0)
		fMinMax = 1;
	float fPower = (float)(fPowerMin + xRandom((DWORD)(fMinMax)));
	return (int)fPower;
#endif
}

//
// ¿Ïµå(¸ÅÁ÷)°ø°Ý µ¥¹ÌÁö°è»ê.
//
#ifdef __NO_HP_DMG_LIMIT
long long CMover::GetMagicHitPower(int nChargeLevel)
#else
int CMover::GetMagicHitPower(int nChargeLevel)
#endif
{
	ItemProp* pItemProp = GetActiveHandItemProp();			// µé°íÀÖ´Â ¹«±âÀÇ ÇÁ·ÎÆÛÆ¼ ²¨³¿
	CItemElem *pWeapon = GetWeaponItem();		// ¼Õ¿¡µç ¾ÆÀÌÅÛÀÇ Æ÷ÀÎÅÍ.

#ifdef __NO_HP_DMG_LIMIT
	long long nMin, nMax;
#else
	int nMin, nMax;
#endif
	GetItemATKPower( &nMin, &nMax, pItemProp, pWeapon ); 

	int nATK = GetWeaponATK( WT_MAGIC_WAND );
	nMin += nATK;
	nMax += nATK;

	int nDamage = xRandom( nMin, nMax );
	nDamage += GetParam( DST_CHR_DMG, 0 );
	nDamage	= (int)( nDamage * GetWandATKMultiplier( nChargeLevel ) );
	return nDamage;
}





// µðÆæ½º, Æä¸®, Å©¸®Æ¼ÄÃÀ» Àû¿ëÇÑ´Ù.
// nATK : °ø°ÝÀÚÀÇ °ø°Ý·Â
// nDamage : ÃÖÁ¾ µ¥¹ÌÁö = °ø°Ý·Â - ¹æ¾î·Â
#ifdef __NO_HP_DMG_LIMIT
long long CMover::ApplyDPC(long long nATK, ATTACK_INFO* pInfo)
#else
int CMover::ApplyDPC(int nATK, ATTACK_INFO* pInfo)
#endif
{	
#ifdef __NO_HP_DMG_LIMIT
	long long nDamage;
#else
	int nDamage;
#endif
	if( pInfo->CanIgnoreDEF() )
		nDamage = nATK;
	else
	{
#ifdef __NO_HP_DMG_LIMIT
		long long nDefense = CalcDefense(pInfo);
#else
		int nDefense = CalcDefense(pInfo);
#endif
		nDamage = nATK - nDefense;
	}

	if( nDamage < 0 )	
		nDamage = 0;

	// Å©¸®Æ¼ÄÃ Ã³¸®.
	if( pInfo->pAttacker->IsCriticalAttack( this, pInfo->dwAtkFlags ) )		
	{
		pInfo->dwAtkFlags |= AF_CRITICAL;

		int nChargeLevel = pInfo->GetChargeLevel();		// ¿ÏµåÃæÀü·®	
		if( (pInfo->pAttacker->m_pActMover->GetState() & OBJSTA_ATK4) || 
			nChargeLevel == MAX_CHARGE_LEVEL )	// 4ÆÐÅÏ°ø°Ý¿¡ ¹ß»ýÇÑ Å©¸®Æ¼ÄÃ.
		{
#ifdef __NO_HP_DMG_LIMIT
			nDamage = nDamage * 2.6;
#else
			nDamage = (int)(nDamage * 2.6f);
#endif
			if( CanFlyByAttack() && xRandom(100) < 50 )
				pInfo->dwAtkFlags |= AF_FLYING;
		}
		else
		{
#ifdef __NO_HP_DMG_LIMIT
			nDamage = nDamage * 2.3;
#else
			nDamage = (int)(nDamage * 2.3f);
#endif
			if( CanFlyByAttack() && xRandom(100) < 30 )
				pInfo->dwAtkFlags |= AF_FLYING;
		}
#ifdef __FIXES_CUSTOM_V5
		float fCriticalBonus = 1 + (float)pInfo->pAttacker->GetParam(DST_CRITICAL_BONUS, 0) / 100.0f;
#else
		float fCriticalBonus = 1 + (float)GetParam(DST_CRITICAL_BONUS, 0) / 100.0F;
#endif
#ifdef __JEFF_11
		if( fCriticalBonus < 0.1F )
			fCriticalBonus	= 0.1F;
#endif	// __JEFF_11
#ifdef __NO_HP_DMG_LIMIT
		nDamage = nDamage * (double)fCriticalBonus;
#else
		nDamage = (int)(nDamage * fCriticalBonus);
#endif
	}
	return nDamage;
}


void CMover::ReSetDuelTime( CMover* pAttacker, CMover* pDefender )
{
	if( pDefender->m_nDuel == 1 && pAttacker->m_nDuel == 1 
		&& pDefender->m_idDuelOther == pAttacker->GetId() && pAttacker->m_idDuelOther == pDefender->GetId() )
	{
		pDefender->m_dwTickEndDuel = ::timeGetTime() + NEXT_TICK_ENDDUEL;
		pAttacker->m_dwTickEndDuel = ::timeGetTime() + NEXT_TICK_ENDDUEL;
	}
	else if( pDefender->m_nDuel == 2 && pAttacker->m_nDuel == 2 
		&& pDefender->m_idDuelParty == pAttacker->m_idparty && pAttacker->m_idDuelParty == pDefender->m_idparty )
	{
		CMover* pLeader;
		CParty* pParty	= g_PartyMng.GetParty( pDefender->m_idparty );
		
		if( pParty )
		{
			pLeader = pParty->GetLeader();
			if( IsValidObj( pLeader ) )
				pLeader->m_dwTickEndDuel = ::timeGetTime() + NEXT_TICK_ENDDUEL;
		}
		
		CParty* pParty2		= g_PartyMng.GetParty( pAttacker->m_idDuelParty );
		if( pParty2 )
		{
			pLeader = pParty2->GetLeader();
			if( IsValidObj( pLeader ) )
				pLeader->m_dwTickEndDuel = ::timeGetTime() + NEXT_TICK_ENDDUEL;
		}
	}
}

// °ø°ÝÀÚ°¡ º¯°æµÇ¸é °æÇèÄ¡ Áö±Þ·üÀ» º¯°æ
void CMover::ChangeExpRatio( CMover* pAttacker, CMover* pDefender )
{
	BOOL bDiffer = FALSE;
	if( pDefender->m_idAttacker != pAttacker->GetId() )	// °ø°ÝÀÚ°¡ º¯°æµÇ¸é?
	{
		if( pAttacker->m_idparty )	// ³¯ Ä£³ðÀÌ ÆÄÆ¼°¡ ÀÖ´Â°¡.
		{
			CMover *pLastAttacker = prj.GetMover( pDefender->m_idAttacker );
			if( IsValidObj( (CObj*)pLastAttacker ) && pLastAttacker->m_idparty != pAttacker->m_idparty )	// ´Ù¸¥ÆÄÆ¼°¡ ÃÆÀ¸¸é Áö±Þ·ü ¹Ù²Þ.
				bDiffer = TRUE;
		} else
			bDiffer = TRUE;			// ³¯ ¸¶Áö¸·À¸·Î ÃÆ´ø³ðÀÌ ÆÄÆ¼°¡ ¾øÀ¸¸é Áö±Þ·ü ¹Ù²Þ.
	}
	
	if( bDiffer )	// ´Ù¸¥ »ó´ë(ÆÄÆ¼µµ ´Ù¸¥)°¡ ÃÆÀ¸¸é Áö±Þ·üÀ» º¯°æ 
	{
		if( pDefender->GetProp()->dwClass != RANK_SUPER )		// º¸½º¸÷ÀÏ°æ¿ì ÀÌ Àû¿ëÀ» ¹ÞÁö ¾ÊÀ½.
#ifdef __NO_HP_DMG_LIMIT
			pDefender->m_fExpRatio = (double)pDefender->GetHitPoint() / pDefender->GetMaxHitPoint();
#else
			pDefender->m_fExpRatio = (float)pDefender->GetHitPoint() / pDefender->GetMaxHitPoint();
#endif
	}
}

// ½ºÅ³ÀÌ³ª ¹°¸®Àû °ø°ÝÀ» ´çÇÒ °æ¿ì 
#ifdef __NO_HP_DMG_LIMIT
void CMover::OnAttacked(CMover* pAttacker, long long nDamage, BOOL bTarget, int nReflect)
#else
void CMover::OnAttacked(CMover* pAttacker, int nDamage, BOOL bTarget, int nReflect)
#endif
{
	CMover* pDefender = this;
	if( pDefender == pAttacker )
	{
//		ASSERT( FALSE );	// ÀÏ´Ü Çö ±âÈ¹¿¡¼­ ÀÚ½ÅÀ» °ø°ÝÇÏ´Â °æ¿ì´Â ¾ø´Ù. 
		return;
	}

	BOOL bAddEnemy = TRUE;
	DWORD dwLast = 0;

	HITTYPE type = pAttacker->GetHitType( pDefender, bTarget, nReflect );
	if( type == HITTYPE_PVP || type == HITTYPE_WAR || type == HITTYPE_SCHOOL
#ifdef __JEFF_11_4
		|| type == HITTYPE_ARENA
#endif	// __JEFF_11_4
		)
		bAddEnemy = FALSE;
	
	if( bAddEnemy )		// TODO_raiders: HITTYPE_PK¿Í HITTYPE_GENERICÀÎ °æ¿ì·Î ¼öÁ¤ÇØ¾ß ÇÔ  
	{
		dwLast = pDefender->AddEnemy( pAttacker->GetId(), nDamage );
		pAttacker->AddEnemy( pDefender->GetId(), 0 );
	}

	switch( type )
	{
	case HITTYPE_PK:
		{
#if __VER >= 8 // __S8_PK
			if( nReflect )
				break;
			
			if( pAttacker->IsChaotic() || pDefender->IsChaotic() )
				break;

#ifdef __JEFF_11_4
			CWorld* pWorld	= pDefender->GetWorld();
			if( pWorld && pWorld->IsArena() )
				break;
#endif	// __JEFF_11_4

			if( pDefender->IsPKPink() )
				pAttacker->SetPKPink( GetTickCount() + SEC(prj.m_PKSetting.nReadyAttack) );
			else
				pAttacker->SetPKPink( GetTickCount() + SEC(prj.m_PKSetting.nGeneralAttack) );
			g_UserMng.AddPKPink( pAttacker, 1 );
#else // __VER >= 8 // __S8_PK
			// PK¼¼¼ÇÀ» ½ÃÀÛÇÏ±â À§ÇØ¼­ ÇÃ·¹ÀÌ¾î°£ÀÇ Àû´ë°ü°è ½ÃÀÛÀ» º¸³½´Ù.
			((CUser*)pAttacker)->UpdatePlayerEnemy( ADD_PLAYER_ENEMY, pDefender->GetId() );
			((CUser*)pDefender)->UpdatePlayerEnemy( ADD_PLAYER_ENEMY, pAttacker->GetId() );
			// Ã¹ PK½ÃµµÀÌ¸é ½½·ÎÅÍ Æ÷ÀÎÆ®¸¦ °¨¼ÒÇÑ´Ù. 
			if( dwLast == 0 || (GetTickCount() - dwLast) > MIN(1) )		//Ã¹Å¸ or ¼¼¼ÇÀÌ 1ºÐÀ» Áö³µ´Â°¡?
			{
				pAttacker->ChangeSlaughter( CHANGE_SLAUGHTER_ATTACK, pDefender );
			}
#endif // __VER >= 8 // __S8_PK
		}
		break;
	case HITTYPE_PVP:
		pAttacker->ReSetDuelTime( pAttacker, pDefender );
		break;
	}

	if( pAttacker->IsPlayer() && pDefender->IsNPC() )		
	{
#ifdef __ATTACKER_TRACKING		
		if (nDamage > 0)
		{
#ifdef __FACTION_PVP_SYSTEM
			if (pDefender->GetIndex() == MI_GUARDIAN_STATUE || pDefender->GetIndex() == MI_RAIDER_STATUE)
			{
				CString message;
				if (pDefender->m_dbLastMessageSent == 0 || GetTickCount() > (pDefender->m_dbLastMessageSent + SEC(15)))
				{
					if (pDefender->GetIndex() == MI_GUARDIAN_STATUE)
						message.Format("The Guardian Statue is under attack! HP left: %d%%", pDefender->GetHitPointPercent());
					else
						message.Format("The Raiders Statue is under attack! HP left: %d%%", pDefender->GetHitPointPercent());

					g_DPCoreClient.SendWorldChatMessage(message, 0xffff8000);
					pDefender->m_dbLastMessageSent = GetTickCount();
				}
			}
#endif
			//For all m_bIPBasedDrops we track attacks.
			if (pDefender->GetPropA()->m_bIPBasedDrops)
			{
				BOOL newAttacker = TRUE;
				for (int i = 0; i < pDefender->m_vRecentAttackers.size(); i++)
				{
					if (pAttacker->m_idPlayer == pDefender->m_vRecentAttackers[i].m_idAttacker)
					{
						newAttacker = FALSE;
						int damageNow = pDefender->m_vRecentAttackers[i].totalDamageDealt;
						int damageNew = damageNow + nDamage;
						pDefender->m_vRecentAttackers[i].totalDamageDealt = damageNew;

						g_UserMng.TrackMoverAttackers(pDefender, pAttacker->m_idPlayer, damageNew, 0, FALSE);
						pDefender->m_dbLastAttackReceived = GetTickCount();
					}
				}

				if (newAttacker == TRUE)
				{
					ATTACKER_DATA data;
					data.totalDamageDealt = nDamage;
					data.m_idAttacker = pAttacker->m_idPlayer;
					data.initialTimeTick = (time_t)(CTime::GetCurrentTime().GetTime());
					pDefender->m_vRecentAttackers.push_back(data);

					g_UserMng.TrackMoverAttackers(pDefender, pAttacker->m_idPlayer, nDamage, data.initialTimeTick, TRUE);
					pDefender->m_dbLastAttackReceived = GetTickCount();
				}
			}
		}
#endif //__ATTACKER_TRACKING
		if( pDefender->m_idAttacker != NULL_ID )			// ´©±º°¡°¡ ÇÑ¹ø Ä£°Ç°¡?
		{
			if( nDamage > 0 )
				ChangeExpRatio( pAttacker, pDefender );		 
		}
		else
		{
			((CUser *)pAttacker)->AddCorrReq( pDefender );	// °ø°ÝÀÚÀ¯Àú¿¡°Ô ¸÷ ÁÂÇ¥ÇÑ¹ø º¸Á¤.
		}
		pDefender->m_idAttacker = pAttacker->GetId();		// ÇÇ°ÝÀÚ´Â °ø°ÝÀÚ¸¦ ±â¾ï 
	}
	pAttacker->m_idLastHitMover = pDefender->GetId();		// PK½Ã ¾ÆÀÌÅÛ ±Ç¸®Ã³¸®¸¦ À§ÇØ¼­ ±â¾ïÇØµÒ ( NPP¿¡¼­ »ç¿ëÇÏÁö ¾ÊÀ½ )
}



// ÁÁÀº ¹öÇÁÀÏ¶§¸¸ ¿©±â µé¾î¿È
// return HITTYPE_GENERICÀÌ¸é ¾Èµå·¯°¨
#if __VER >= 8 // __S8_PK
HITTYPE	CMover::GetHitType2( CMover* pMover, BOOL bTarget, BOOL bGood )
#else // __VER >= 8 // __S8_PK
HITTYPE	CMover::GetHitType2( CMover* pMover, BOOL bTarget )
#endif // __VER >= 8 // __S8_PK
{
	if( !IsValidObj( (CObj*)this ) || !IsValidObj( (CObj*)pMover ) )
		return HITTYPE_GENERIC;
	if( IsDie() || pMover->IsDie() )					// Á×Àº»óÅÂ
		return HITTYPE_FAIL;
	if( m_nDead || pMover->m_nDead )					// Á×ÀºÈÄ ¹«Àû»óÅÂ
		return HITTYPE_GENERIC;

	if( IsPlayer() && pMover->IsPlayer() )
	{
#if __VER < 8 // 8Â÷ µà¾ó 061226 ma
		if( !g_eLocal.GetState( EVE_18 ) )
			return HITTYPE_FAIL;
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma

		if( m_pActMover->IsFly() || pMover->m_pActMover->IsFly() )	// °øÁß¿¡ ÀÖÀ¸¸é ºÒ°¡ 
			return HITTYPE_FAIL;
		if( IsPVPTarget( pMover ) )
			return HITTYPE_PVP;
		if( IsWarTarget( pMover ) )
			return HITTYPE_WAR;
		if( IsSchoolTarget( pMover ) )
			return HITTYPE_SCHOOL;
		if( IsGuildCombatTarget( pMover ) )
			return HITTYPE_GUILDCOMBAT;
#ifdef __JEFF_11_4
		if( IsArenaTarget( pMover ) )
			return HITTYPE_ARENA;
#endif	// __JEFF_11_4
#ifdef __DEATH_MATCH
		if (IsSiegeTarget(pMover))
			return HITTYPE_ARENA;
#endif // __DEATH_MATCH
#ifdef __WORLDSERVER_MENU
		if (g_eLocal.GetState(EVE_PK) && CDPSrvr::GetInstance()->m_bPk == TRUE)
#else // __WORLDSERVER_MENU
		if (g_eLocal.GetState(EVE_PK))
#endif // __WORLDSERVER_MENU
		{
#ifdef __DEATH_MATCH
			if (GetWorld()->m_dwWorldID != WI_WORLD_DEATH_MATCH)
#endif // __DEATH_MATCH
			{
#if __VER >= 8 // __S8_PK
				if (bGood)		// ¼±ÇÑ ¸¶¹ýÀÌ¸é ¸ðµÎ µé¾î°¡°Ô ÇÏÀÚ
					return HITTYPE_FAIL;
				else if (GetLevel() <= prj.m_PKSetting.nLimitLevel || pMover->GetLevel() <= prj.m_PKSetting.nLimitLevel)
					return HITTYPE_FAIL;
				return HITTYPE_PK;
#else // __VER >= 8 // __S8_PK
				DWORD dwLast;
				GetEnemyHit(pMover->GetId(), &dwLast);
				if (dwLast == 0 || (GetTickCount() - dwLast) > MIN(1))		//PK¼¼¼Ç °Ë»ç 
					return HITTYPE_FAIL;
				else
					return HITTYPE_PK;
#endif // __VER >= 8 // __S8_PK
			}
		}
		else
		{
			return HITTYPE_FAIL;
		}
	}
	else
	{
		return HITTYPE_GENERIC;		// NPC¿¡°Ô´Â ÁÁÀº ¹öÇÁ¸¦ ÁÙ¼ö ¾ø´Ù.
	}
#ifdef __GAMEGUARD
	return HITTYPE_FAIL;
#endif // __GAMEGUARD
}

// this - °ø°ÝÀÚ, pMover - ¹æ¾îÀÚ  
HITTYPE	CMover::GetHitType( CMover* pMover, BOOL bTarget, int nReflect )
{
	if( !IsValidObj( (CObj*)this ) || !IsValidObj( (CObj*)pMover ) )
		return HITTYPE_FAIL;
	if( IsDie() || pMover->IsDie() )					// Á×Àº»óÅÂ
		return HITTYPE_FAIL;
	if( m_nDead || pMover->m_nDead )					// Á×ÀºÈÄ ¹«Àû»óÅÂ
		return HITTYPE_FAIL;

#if __VER >= 9	//__AI_0509
	// ÀÚ±â ÀÚ½ÅÀ» °ø°ÝÇÏ´Â °æ¿ì°¡ ¾Æ´Ô
	// µð¹öÇÁ »óÅÂ¿¡¼­ Àç·Î±×ÀÎ ÇÏ¸é °ø°ÝÀÚ ´ë½Å ÀÚ½ÅÀÌ °ø°ÝÀÚ·Î ¼³Á¤µÊ.
	if( this == pMover )	
		return HITTYPE_GENERIC;
#endif	// __AI_0509

	if( IsPlayer() && pMover->IsPlayer() )
	{
		if( IsGuildCombatTarget( pMover ) )
			return HITTYPE_GUILDCOMBAT;

#if __VER < 8 // 8Â÷ µà¾ó 061226 ma
		if( !g_eLocal.GetState( EVE_18 ) )
			return HITTYPE_FAIL;
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma		

		if( m_pActMover->IsFly() || pMover->m_pActMover->IsFly() )	// °øÁß¿¡ ÀÖÀ¸¸é ºÒ°¡ 
			return HITTYPE_FAIL;
		if( IsPVPTarget( pMover ) )
			return HITTYPE_PVP;
		if( IsWarTarget( pMover ) )
			return HITTYPE_WAR;
		if( IsSchoolTarget( pMover ) )
			return HITTYPE_SCHOOL;

#ifdef __JEFF_11_4
		if( IsArenaTarget( pMover ) )
			return HITTYPE_ARENA;
#endif	// __JEFF_11_4

#ifdef __DEATH_MATCH
		if (IsSiegeTarget(pMover))
			return HITTYPE_ARENA;
#endif // __DEATH_MATCH

		DWORD dwAttr	= GetPKPVPRegionAttr();		
		if( dwAttr == RA_SAFETY || dwAttr != pMover->GetPKPVPRegionAttr() )
			return HITTYPE_FAIL;
#if __VER < 8 // __S8_PK
		if( m_idparty > 0 && m_idparty == pMover->m_idparty )	
			return HITTYPE_FAIL;
		if( m_idGuild > 0 && m_idGuild == pMover->m_idGuild )
			return HITTYPE_FAIL;
#endif // __VER < 8 // __S8_PK


		if( IsBaseJob() || pMover->IsBaseJob() )
			return HITTYPE_FAIL;
		if( g_eLocal.GetState( EVE_GUILDWAR ) )			// ±æµåÀü »óÅÂ¿¡¼­´Â PKºÒ°¡ 
		{
			if( m_idWar > 0 || pMover->m_idWar > 0 )	
				return HITTYPE_FAIL;
		}
		
#ifdef __WORLDSERVER_MENU
		if (g_eLocal.GetState(EVE_PK) && CDPSrvr::GetInstance()->m_bPk == TRUE)
#else // __WORLDSERVER_MENU
		if (g_eLocal.GetState(EVE_PK))
#endif // __WORLDSERVER_MENU
		{
#ifdef __DEATH_MATCH
			if (GetWorld()->m_dwWorldID != WI_WORLD_DEATH_MATCH)
#endif // __DEATH_MATCH
			{
#if __VER >= 8 // __S8_PK
				if (GetLevel() <= prj.m_PKSetting.nLimitLevel || pMover->GetLevel() <= prj.m_PKSetting.nLimitLevel)
					return HITTYPE_FAIL;
#else // __VER >= 8 // __S8_PK
				if (pMover->IsChaotic())						// Ä«¿À        - PK°¡´É 
					return HITTYPE_PK;
				if (GetTickCount() >= m_dwPKTargetLimit)		// PK¼±°øºÒ°¡½Ã°£µ¿¾È¿¡´Â ¼±°øÀÌ ¾ÈµÊ  
				{
					if (bTarget)								// Å¸ÄÏÀ¯Àú    - PK°¡´É 
						return HITTYPE_PK;
				}

				DWORD dwLast;
				GetEnemyHit(pMover->GetId(), &dwLast);
				if (dwLast == 0 || (GetTickCount() - dwLast) > MIN(1))		//PK¼¼¼Ç °Ë»ç 
					return HITTYPE_FAIL;
#endif // __VER >= 8 // __S8_PK
				return HITTYPE_PK;
			}
		}
		else
		{
			return HITTYPE_FAIL;
		}
	}
	else
	{
		if( IsNPC() && GetProp()->dwClass == RANK_GUARD )			// ¿¹¿ÜÃ³¸®: °æºñº´Àº °øÁß¿¡ ÀÖ´Â ³à¼®µµ °ø°Ý°¡´É 
			return HITTYPE_GENERIC;
	
		if( pMover->IsNPC() && IsAttackAbleNPC( pMover ) == FALSE )	// bKillable, IsPeaceful, RANK_GUARD¸¦ °Ë»ç 
			return HITTYPE_FAIL;

		//TODO: IsFly()·Î ÅëÇÕ 
		bool bAttackerFly = ( IsNPC() && IsFlyingNPC() ) || ( IsPlayer() && IsFly() );
		bool bDefenderFly = ( pMover->IsNPC() && pMover->IsFlyingNPC() ) || ( pMover->IsPlayer() && pMover->IsFly() );


#ifdef __JHMA_VER_8_6     // 8Â÷ ¸ó½ºÅÍ°¡ Àú°øºñÇàÀ¯Àú¸¦ °ø°Ý°¡´ÉÇÏ°ÔÇÔ   World
	
		if( bAttackerFly != bDefenderFly && bAttackerFly )
			return HITTYPE_FAIL;

#else	// __VER >= 8  

		if( bAttackerFly != bDefenderFly )
			return HITTYPE_FAIL;

#endif	// __VER >= 8  


		return HITTYPE_GENERIC;
	}
#ifdef __GAMEGUARD
	return HITTYPE_FAIL;
#endif // __GAMEGUARD
}
#endif // __WORLDSERVER

BOOL CMover::IsPVPTarget( CMover* pMover )
{	
	BOOL bResult = FALSE;
	if( m_idDuelOther != NULL_ID && m_idDuelOther == pMover->GetId() )
		bResult = TRUE;

	if( 0 < m_idDuelParty && m_idDuelParty == pMover->m_idparty )
		bResult = TRUE;

	if( bResult && ( m_nDuelState == 1 || pMover->m_nDuelState == 1 ) )
		return TRUE;

	return FALSE;
}

#ifdef __JEFF_11_4
BOOL	CMover::IsArenaTarget( CMover* pMover )
{
	CWorld* pWorld	= GetWorld();
	if( pWorld && pWorld->IsArena() )
	{
		int dx	= (int)( pMover->GetPos().x - 490 );
		int dy	= (int)( pMover->GetPos().z - 507 );
		int d	= dx * dx + dy * dy;
		if( d > 1246 )
			return FALSE;
		dx	= (int)( GetPos().x - 490 );
		dy	= (int)( GetPos().z - 507 );
		d	= dx * dx + dy * dy;
		if( d > 1246 )
			return FALSE;
		return TRUE;
	}
	return FALSE;
}
#endif	// __JEFF_11_4

BOOL CMover::IsWarTarget( CMover* pMover )
{
	if( g_eLocal.GetState( EVE_GUILDWAR ) == 1 )
	{
		if( m_idWar > 0 && m_idWar == pMover->m_idWar && m_idGuild != pMover->m_idGuild )
			return TRUE;
	}
	return FALSE;
}

#ifdef __DEATH_MATCH
BOOL CMover::IsSiegeTarget(CMover* pMover)
{
	if (GetWorld()->m_dwWorldID != WI_WORLD_DEATH_MATCH)
		return FALSE;

	if (g_War.GetState() <= -1)
		return FALSE;

	if (GetSiegeFightState() != TRUE)
		return FALSE;

	return TRUE;
}
#endif // __DEATH_MATCH

BOOL CMover::IsSchoolTarget( CMover* pMover )
{
	return( g_eLocal.GetState( EVE_SCHOOL_BATTLE ) == SBS_START2 );		// '/sbstart2'
}

BOOL CMover::IsGuildCombatTarget( CMover* pMover )
{
#ifdef __WORLDSERVER
	if( g_GuildCombatMng.m_nGCState != CGuildCombat::WAR_WAR_STATE
#if __VER >= 11 // __GUILD_COMBAT_1TO1
		&& g_GuildCombat1to1Mng.m_nState != g_GuildCombat1to1Mng.GC1TO1_WAR
#endif // __GUILD_COMBAT_1TO1
		)
		return FALSE;
#endif // __WORLDSERVER
	
	if( m_nGuildCombatState != 1 || pMover->m_nGuildCombatState != 1 )
		return FALSE;

	if( m_idGuild == pMover->m_idGuild )
		return FALSE;

	return TRUE;
}

// ¸Â´Â ¸ð¼ÇÀ» ÃëÇÑ´Ù.
void CMover::SetDamagedMotion( CMover* pAttacker, DWORD dwAtkFlags )
{
	if((m_pActMover->GetState() & OBJSTA_DMG_FLY_ALL))			// µ¥¹ÌÁöÇÃ¶óÀ×ÀÌ ¾Æ´Ò¶§¸¸ ¾Æ·¡ Ã³¸®.
		return;

	m_pActMover->ResetState( OBJSTA_JUMP_ALL );
	if( dwAtkFlags & AF_FLYING )									// ¸Â°í ³¯¾Æ°¡¾ß ÇÏ´Â°¡?
	{
		if( (m_pActMover->GetState() != OBJSTA_STUN) )
		{			
			m_pActMover->SetState( OBJSTA_DMG_ALL, OBJSTA_DMG_FLY );
			SetMotion( MTI_DMGFLY, ANILOOP_CONT );
			if( pAttacker )
			{ 
				pAttacker->SendActMsg( OBJMSG_STOP );					// ÇÃ¶óÀ×´Ù¿îÀÌ ÀÏ¾î³µÀ»¶§ ¾îÅÂÄ¿´Â ÀÏ´Ü ¼¼¿ìÀÚ.
				m_pActMover->DoDamageFly( pAttacker->GetAngle(), 145.0f, 0.18f );	// ¾îÅÂÄ¿°¡ º¸´ÂÂÊÀ¸·Î ³¯·Áº¸³¿.
			}
		}
	} 
	else
		m_pActMover->SetState( OBJSTA_DMG_ALL, OBJSTA_DMG );
	
#if __VER >= 10 // __LEGEND
	DWORD	dwTmpTick = GetTickCount();
	int	nTmpSkillID = m_pActMover->GetCastingSKillID();
	if (m_pActMover->GetCastingEndTick() > dwTmpTick && (nTmpSkillID == SI_KNT_HERO_DRAWING
#ifndef __RM_HERO_SKILL
		|| nTmpSkillID == SI_RIG_HERO_RETURN
#endif
		))
	{
		m_pActMover->SetCastingEndTick(0);
		m_pActMover->ClearState();				// »óÅÂ Å¬¸®¾îÇÏ°í ´Ù½Ã ¸ÂÃã.
	}
#endif  //#if __VER >= 10 // __LEGEND

	if( m_pActMover->IsActJump() || m_pActMover->IsActAttack() )	// Á¡ÇÁÁß or °ø°ÝÁß ¿£ µ¥¹ÌÁö ¸ð¼Ç ¾È³¿.
		return;
	if( m_pActMover->IsAction() )		// ÀÏ¹Ý¾×¼Ç ÁßÀÌ¸é µ¥¹ÌÁö ¸ð¼Ç ¾È³¿.
		return;

	m_dwMotion = -1;
	if( m_pActMover->IsFly() )
	{
		ItemProp* pItemProp = prj.GetItemProp( m_dwRideItemIdx );
		if( pItemProp )
			SetMotion( pItemProp->dwUseMotion + MTA_FDMG1, ANILOOP_1PLAY, MOP_FIXED | MOP_NO_TRANS );
	}
	else
	{
		SetMotion( MTI_DMG1 + random( 2 ), ANILOOP_1PLAY );
	}
}


// ¾ÆÀÌÅÛÀÇ È¿´É °öÇÏ±â ÆÑÅÍ¸¦ ±¸ÇÑ´Ù.
float CMover::GetItemMultiplier( CItemElem* pItemElem )
{
#if __VER < 8 // __S8_PK
	if( IsChaotic() == FALSE && (pItemElem->GetProp()->nEvildoing < 0) )
		return 0.0f;	// ¼±ÇÑÀÚ°¡ Ä«¿À ¾ÆÀÌÅÛÀ» »ç¿ëÇÏ¸é È¿´ÉÀÌ ¾ø´Ù.
#endif // __VER < 8 // __S8_PK

	if( pItemElem->IsFlag( CItemElem::expired ) )
		return 0.0f;

	ItemProp* pItemProp = pItemElem->GetProp();
	ASSERT( pItemProp );

#if __VER >= 11 // __REMOVE_ENDURANCE
	float fValue = 1.0f;
#else // __REMOVE_ENDURANCE
	float fValue = CMover::GetItemEnduranceInfluence( ( pItemElem->m_nHitPoint * 100 ) / pItemProp->dwEndurance );
#endif // __REMOVE_ENDURANCE
	
	// Ë¬ - 2007-08-27
	int nOption		= pItemElem->GetAbilityOption();
	if( pItemProp->dwReferStat1 == WEAPON_ULTIMATE )
		nOption	= 10;

	if( nOption )
	{
		int nValue = prj.GetExpUpItem( pItemProp->dwItemKind3, nOption );
		nValue += 100;
		fValue = fValue * nValue / 100.0f;		// Á¦·Ã¼öÄ¡°¡ °öÇØÁø´Ù.
	}
	return fValue;
}

#ifdef __NO_HP_DMG_LIMIT
void CMover::GetItemATKPower(long long* pnMin, long long* pnMax, ItemProp* pItemProp, CItemElem* pWeapon)
#else
void CMover::GetItemATKPower(int* pnMin, int* pnMax, ItemProp* pItemProp, CItemElem* pWeapon)
#endif
{
	float f	= 1.0f;
	int nOption, nAdd;
	nAdd = nOption = 0;

	if( pWeapon )
		nOption = pWeapon->GetAbilityOption();	// Á¦·Ã¼öÄ¡ 

	if( nOption > 0 )
		nAdd = (int)( pow( (float)( nOption ), 1.5f ) );

	if( pWeapon )
	{
		f = GetItemMultiplier( pWeapon );
#if __VER < 11 // __REMOVE_ENDURANCE
		if( pWeapon->m_nRepairNumber >= 100 )
			nAdd += prj.GetExpUpItem( pItemProp->dwItemKind3, 1 );
#endif // __REMOVE_ENDURANCE
	}
	*pnMin	= (int)( GetItemAbilityMin( pItemProp->dwID ) * f ) + nAdd;
	*pnMax	= (int) ( GetItemAbilityMax( pItemProp->dwID ) * f ) + nAdd;
}


int CMover::GetReqMp( int nReqMp )
{
	if( nReqMp == 9999999 )
		return nReqMp;

	return nReqMp - nReqMp * GetParam( DST_MP_DEC_RATE, 0 ) / 100;
}

int CMover::GetReqFp( int nReqFp )
{
	if( nReqFp == 9999999 )
		return nReqFp;

	return nReqFp - nReqFp * GetParam( DST_FP_DEC_RATE, 0 ) / 100;
}

float CMover::GetResist( SAI79::ePropType type )	
{ 
	if( SAI79::NO_PROP == type )
		return 0.0f;

	int n;
	switch( type )
	{
	case SAI79::FIRE:
		n = DST_RESIST_FIRE;
		break;
	case SAI79::WATER:
		n = DST_RESIST_WATER;
		break;
	case SAI79::ELECTRICITY:
		n = DST_RESIST_ELECTRICITY;
		break;
	case SAI79::WIND:
		n = DST_RESIST_WIND;
		break;
	case SAI79::EARTH:
		n = DST_RESIST_EARTH;
		break;
	}

	return GetResistSpell( n ) / 100.0f;
}

#if __VER >= 8 // __S8_PK
void CMover::OnAttackSFX( OBJID	idTarget, int nMagicPower, DWORD dwSkill, int nDmgCnt, float	fDmgAngle, float fDmgPower,  DWORD dwAtkFlags, BOOL bControl )
#else // __VER >= 8 // __S8_PK
void CMover::OnAttackSFX( OBJID	idTarget, int nMagicPower, DWORD dwSkill, int nDmgCnt, float	fDmgAngle, float fDmgPower,  DWORD dwAtkFlags )
#endif // __VER >= 8 // __S8_PK
{
#ifdef __WORLDSERVER
//	if( dwSkill == SI_MAG_FIRE_HOTAIR )		// Ë¬	// 06-10-23
//		return;

#if __VER >= 8 // __S8_PK
	SFXHIT_INFO si	= 
		{ idTarget, nMagicPower, dwSkill, nDmgCnt, fDmgAngle, fDmgPower, dwAtkFlags, bControl };
#else // __VER >= 8 // __S8_PK
	SFXHIT_INFO si	= 
		{ idTarget, nMagicPower, dwSkill, nDmgCnt, fDmgAngle, fDmgPower, dwAtkFlags };
#endif // __VER >= 8 // __S8_PK
	AddSFXInfo( idTarget, si );
#endif
}

#ifdef __WORLDSERVER
int CMover::GetSFXCount( OBJID idTarget )
{ 
	map<OBJID, queue<SFXHIT_COUNT> >::iterator it = m_mapSFXCount.find( idTarget );
	if( it != m_mapSFXCount.end() )
		return it->second.size();
	return 0;
}

void CMover::IncSFXCount( OBJID idTarget, DWORD dwSkill )
{
	map<OBJID, queue<SFXHIT_COUNT> >::iterator it = m_mapSFXCount.find( idTarget );
	if( it != m_mapSFXCount.end() )
	{
		queue<SFXHIT_COUNT> &q	= it->second;
		SFXHIT_COUNT c	= {	dwSkill, GetTickCount()	};
		q.push( c );
	}
	else
	{
		queue<SFXHIT_COUNT> q;
		SFXHIT_COUNT c	= {	dwSkill, GetTickCount()	};
		q.push( c );
		m_mapSFXCount.insert( map<OBJID, queue<SFXHIT_COUNT> >::value_type( idTarget, q ) );
	}
}

void CMover::AddSFXInfo( OBJID idTarget, SFXHIT_INFO& info )
{
	info.dwTickCount	= GetTickCount();

	map<OBJID, queue<SFXHIT_INFO> >::iterator it = m_mapSFXInfo.find( idTarget );
	if( it != m_mapSFXInfo.end() )
	{		
		queue<SFXHIT_INFO> &q = it->second;
		q.push( info );
	}
	else
	{
		queue<SFXHIT_INFO> q;
		q.push( info );
		m_mapSFXInfo.insert( map<OBJID, queue<SFXHIT_INFO> >::value_type( idTarget, q ) );
	}
}

void CMover::ClearSFX( OBJID idTarget )
{
	m_mapSFXInfo.erase( idTarget );
	m_mapSFXCount.erase( idTarget );
}

void CMover::RemoveSFX( OBJID idTarget, int id, BOOL bForce, DWORD dwSkill )
{
	if( idTarget != NULL_ID )
	{
		CMover* pTarget	= prj.GetMover( idTarget );
		if( IsValidObj( pTarget	) )
			IncSFXCount( idTarget, dwSkill ); 
		else
			ClearSFX( idTarget );
	}
}


BOOL AttackBySFX( CMover* pAttacker, SFXHIT_INFO & info )
{
	CMover* pTarget	= prj.GetMover( info.idTarget );
	if( IsInvalidObj( pTarget ) )
		return FALSE;

	int	nParam = pTarget->m_pActMover->MakeParamDamage( info.nMagicPower, (int)info.dwSkill, info.nDmgCnt );
	if( pTarget->IsLive() == FALSE )
		return FALSE;

	//¸ó½ºÅÍ°¡ ¿ø°Å¸® ¹ß»çÃ¼¸¦ °æ¿ìµµ °ø°Ý¼º°ø·üÀ» Àû¿ëÇÏ¿© °è»êÇÑ´Ù.
	if( info.dwAtkFlags & AF_GENERIC )
	{						
		if( pAttacker->GetAttackResult( pTarget, 0 ) == FALSE )
			info.dwAtkFlags = AF_MISS;
	}

	if( !g_eLocal.GetState( EVE_STEAL ) && pAttacker->IsSteal( pTarget ) )
			return TRUE;

	if( IsSkillAttack( info.dwAtkFlags ) )
	{
		// ½ºÅ³ È¿°ú¸¦ Àû¿ë.(³»ºÎ¿¡ µ¥¹ÌÁöµµ Æ÷ÇÔµÇ¾î ÀÖ´Ù)
		LPSKILL pSkill = pAttacker->GetSkill( info.dwSkill );		// °ø°ÝÀÚÀÇ ½ºÅ³·¹º§À» ¾Ë±â À§ÇØ...
		if( pSkill )
		{
			ItemProp *pSkillProp;
			AddSkillProp *pAddSkillProp;
		#ifdef __SKILL0517
			BOOL bSuccess	= pAttacker->GetSkillProp( &pSkillProp, &pAddSkillProp, info.dwSkill, pAttacker->GetSkillLevel( pSkill ), "OnSfxHit" );
		#else	// __SKILL0517
			BOOL bSuccess	= pAttacker->GetSkillProp( &pSkillProp, &pAddSkillProp, info.dwSkill, pSkill->dwLevel, "OnSfxHit" );
		#endif	// __SKILL0517
			if( bSuccess )
#if __VER >= 8 // __S8_PK
				pAttacker->DoApplySkill( pTarget, pSkillProp, pAddSkillProp, false, nParam, FALSE, info.bControl );
#else // __VER >= 8 // __S8_PK
				pAttacker->DoApplySkill( pTarget, pSkillProp, pAddSkillProp, false, nParam );
#endif // __VER >= 8 // __S8_PK
		} 
		else
			Error( "OnSfxHit : skill=%d¸¦ °¡ÁöÁö ¾ÊÀ½", info.dwSkill );
	} 
	else
		pTarget->m_pActMover->SendDamage( info.dwAtkFlags, pAttacker->GetId(), nParam );

	if( info.fDmgPower )	// ¹Ð¸®´Â ¼Ó¼ºÀÌ ÀÖ´Â°Å¸é.
		AngleToVectorXZ( &pTarget->m_pActMover->m_vDeltaE, info.fDmgAngle, info.fDmgPower );   

	if( pTarget->IsLive() == FALSE )	// À§ °ø°ÝÀÇ °á°ú·Î ´ë»óÀÌ »ç¸Á ÇÏ¿´´Ù.
		return FALSE;

	return TRUE;
}
#endif
```
