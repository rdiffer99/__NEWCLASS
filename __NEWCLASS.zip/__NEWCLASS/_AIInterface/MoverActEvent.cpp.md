# MoverActEvent.cpp

Chemin original: `C:\Users\rdiff\Desktop\__NEWCLASS\_AIInterface\MoverActEvent.cpp`
Chemin relatif: `_AIInterface\MoverActEvent.cpp`
Nom du fichier: `MoverActEvent.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `cp1252`

```cpp
#include "stdafx.h"
#include "defineText.h"
#include "defineObj.h"
#include "defineSkill.h"
#include "Ship.h"
#include "ModelObject.h"
#include "CreateObj.h"
#ifdef __WORLDSERVER
#ifdef __NEW_BOSSMECHANICS
#include "define.h"
#include "CtrlObjs.h"
#endif //__NEW_BOSSMECHANICS
#endif //__WORLDSERVER
//#include "ModelGlobal.h"


#ifdef __CLIENT
	#include "AppDefine.h"
	#include "defineSound.h"
	#include "Sfx.h"
	#include "DPClient.h"
	#include "..\_Common\ParticleMng.h"
#else	// __CLIENT
	#include "User.h"
	#include "WorldMng.h"
	#include "DPSrvr.h"
	#include "DPCoreClient.h"
	#include "dpdatabaseclient.h"
	#include "..\_AIInterface\AIInterface.h"
	#include "Party.h"
#endif	// not __CLIENT

#ifdef __EVENT_MONSTER
	#include "EventMonster.h"
#endif // __EVENT_MONSTER



#ifdef __CLIENT
	extern	CDPClient			g_DPlay;
#else	// __CLIENT
	extern	CUserMng			g_UserMng;
	extern	CWorldMng			g_WorldMng;
	extern	CDPSrvr				g_DPSrvr;
	extern	CDPDatabaseClient	g_dpDBClient;
	extern	CDPCoreClient		g_DPCoreClient;
	extern	CPartyMng			g_PartyMng;
#endif	// not __CLIENT

BOOL IsLootSendText( ItemProp* pItemProp )
{
	if( pItemProp == NULL )
		return FALSE;

	if( pItemProp->dwItemKind1 == IK1_GOLD    ||
		pItemProp->dwItemKind1 == IK1_GENERAL ||
		pItemProp->dwItemKind1 == IK1_SYSTEM  ||
		pItemProp->dwItemKind1 == IK1_RIDE        )
		return FALSE;

	return TRUE;
}

/*--------------------------------------------------------------------------------------------------------


											Action Event Handler
										   ----------------------
						CActionMover³»¿¡¼­ µ¿ÀÛ¿¡ °ü·ÃµÈ ÀÌº¥Æ®°¡ ¹ß»ýÇÏ¸é È£ÃâµÇ´Â ÇÔ¼ö±º


----------------------------------------------------------------------------------------------------------*/

//
// ½ºÅ³ ¸ð¼ÇÀÌ ÀÛµ¿ÇÏ´Ù Å¸°Ý ÇÁ·¹ÀÓÀÌ µÇ¸é ÀÌ ÇÔ¼ö¸¦ È£ÃâÇÔ 
// ±ÙÁ¢Àü ½ºÅ³.    
//
BOOL CMover::OnMeleeSkill( int nType, int nCount )
{
	if( m_oaAct != OBJACT_USESKILL )	
		return FALSE;	// ½ºÅ³»ç¿ëÈÄ Å¸Á¡ÀÌ µÇ±âÀü¿¡ ´Ù¸¥ ¸í·ÉÀ¸·Î ¹Ù²ï°æ¿ì. ÀÌ·±»óÈ²ÀÌ ¿Í¼± ¾ÈµÈ´Ù.
	int		nSkill = GetActParam( 0 );
	OBJID	idTarget = GetActParam( 1 );
	DWORD	dwLevel	= GetActParam( 3 );
#if __VER >= 8 // __S8_PK
	BOOL	bControl = GetActParam( 4 );
#endif // __VER >= 8 // __S8_PK

	ItemProp* pSkillProp;
	AddSkillProp* pAddSkillProp;

	// ½ºÅ³ÇÁ·ÎÆÛÆ¼ °¡Á®¿È.
	GetSkillProp( &pSkillProp, &pAddSkillProp, nSkill, dwLevel, "OnMeleeSkill" );

	// .Å¸°Ù¿¡°Ô ½ºÅ³È¿°ú(µ¥¹ÌÁö°°Àº..)¸¦ ÁØ´Ù.
	CMover* pFocusObj = prj.GetMover( idTarget );		// Å¸°Ù¹«¹öÆ÷ÀÎÅÍ¸¦ ¾ò¾î³¿.
	if( IsInvalidObj( pFocusObj ) )	
		return FALSE;

#if defined(__CLIENT)
	CModelObject* pModel =(CModelObject*)m_pModel;
	if( pModel )
	{
		pModel->m_SparkInfo.m_bUsed  = TRUE;
		pModel->m_SparkInfo.m_v3Color.x = 2.0f;
		pModel->m_SparkInfo.m_v3Color.y = 2.0f;
		pModel->m_SparkInfo.m_v3Color.z = 2.0f;
		pModel->m_SparkInfo.m_nCnt = 0;
		pModel->m_SparkInfo.m_fLerp= 1.0f;
		
		D3DXVECTOR3 vDir;
		if( pFocusObj == this )
			vDir = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
		else
			vDir = GetPos() - pFocusObj->GetPos();

		D3DXVec3Normalize( &pModel->m_SparkInfo.m_v3SparkDir, &vDir );
	}
#endif //defined(__CLIENT) 

#ifdef __NO_HP_DMG_LIMIT
	long long nDamage = 0;
#else
	int nDamage = 0;
#endif

	// ½î´Â ÇüÅÂ¸¸ sfx¹ß»ý.
	if( pSkillProp->dwExeTarget == EXT_MAGICATKSHOT || pSkillProp->dwExeTarget == EXT_MAGICSHOT	)	
	{
#ifdef __WORLDSERVER
		int nMaxDmgCnt	= 1;
		if( pSkillProp->tmContinuousPain != NULL_ID )
			nMaxDmgCnt	= ( pAddSkillProp->dwSkillTime / pAddSkillProp->dwPainTime ) + 1;
		float fDmgPower = 0;
		if( pSkillProp->dwDmgShift != NULL_ID )
			fDmgPower	= (int)pSkillProp->dwDmgShift * 0.2f;
//		for( int nDmgCnt = 0; nDmgCnt < nMaxDmgCnt; nDmgCnt++ )
#if __VER >= 8 // __S8_PK
			OnAttackSFX( pFocusObj->GetId(), pAddSkillProp->dwSkillLvl, pSkillProp->dwID, 0, GetAngle(), fDmgPower, ( pSkillProp->dwSkillType == KT_SKILL? AF_MELEESKILL: AF_MAGICSKILL ), bControl );
#else // __VER >= 8 // __S8_PK
			OnAttackSFX( pFocusObj->GetId(), pAddSkillProp->dwSkillLvl, pSkillProp->dwID, 0, GetAngle(), fDmgPower, ( pSkillProp->dwSkillType == KT_SKILL? AF_MELEESKILL: AF_MAGICSKILL ) );
#endif // __VER >= 8 // __S8_PK
#endif	// __WORLDSERVER
		nDamage = ShootSkill( pFocusObj, pSkillProp, pAddSkillProp );		// ¼­¹ö¿¡¼± ÀÌºÎºÐÀº ½ÇÇà¾ÈµÈ´Ù.
	}
	else
	{
		// Àû¿ë¹üÀ§ Ã³¸®. ³»ºÎ¿¡¼­ ApplySkill()À» È£Ãâ.
#if __VER >= 8 // __S8_PK
		nDamage = DoApplySkill( pFocusObj, pSkillProp, pAddSkillProp, false, 0, FALSE, bControl );
#else // __VER >= 8 // __S8_PK
		nDamage = DoApplySkill( pFocusObj, pSkillProp, pAddSkillProp );
#endif // __VER >= 8 // __S8_PK
	}
	TRACE( "OnMeleeSkill%s, ", pSkillProp->szName );

	if( nDamage && nCount == 0 )		// ¿¬¼ÓÅ¸Á¡ÀÏ°æ¿ì Ã¹¹øÂ° Å¸Á¡¿¡¸¸ Àû¿ë
	{
		// ÄðÅ¸ÀÓ ½Ã°£ Àû¿ë - Å¬¶ó ¼­¹ö µ¿½Ã¿¡ µ¹¾Æ°£´Ù
#ifdef __CLIENT
		if( IsActiveMover() )
#endif
		{
#if __VER >= 9	// __SKILL_0706
			if( pAddSkillProp->dwCooldown != 0xFFFFFFFF )	// ÄðÅ¸ÀÓÀÌ ÀÖ´Â ½ºÅ³ÀÇ °æ¿ì
				SetCoolTime( pAddSkillProp, "OnMeleeSkill" );
#else	// __SKILL_0706
			if( pSkillProp->dwSkillReady != 0xffffffff )	// ÄðÅ¸ÀÓÀÌ ÀÖ´Â ½ºÅ³ÀÇ °æ¿ì
				SetCoolTime( pSkillProp, "OnMeleeSkill" );
#endif	// __SKILL_0706
		}
	}
	return TRUE;
} 


// RT_TIMEÀ» ¾²´Â ½ºÅ³µéÀÇ ½ºÅ³ ½Ã°£À» °è»ê.
void	CMover::SubReferTime( DWORD *pTime1, DWORD *pTime2, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp )
{
	DWORD dwTime1 = 0, dwTime2 = 0;

	if( pSkillProp->dwReferTarget1 == RT_TIME )
	{
		switch( pSkillProp->dwReferStat1 )
		{
		case DST_STA:	dwTime1 = GetSta();		break;
		case DST_DEX:	dwTime1 = GetDex();		break;
		case DST_INT:	dwTime1 = GetInt();		break;
		}
		
		dwTime1 = (DWORD)( ((pSkillProp->dwReferValue1/10.0f)*dwTime1) + (pAddSkillProp->dwSkillLvl * FLOAT(dwTime1/50.0f)) );
	}
	
	if( pSkillProp->dwReferTarget2 == RT_TIME )
	{
		switch( pSkillProp->dwReferStat2 )
		{
		case DST_STA:	dwTime2 = GetSta();		break;
		case DST_DEX:	dwTime2 = GetDex();		break;
		case DST_INT:	dwTime2 = GetInt();		break;
		}
		
		dwTime2 = (DWORD)( ((pSkillProp->dwReferValue2/10.0f)*dwTime2) + (pAddSkillProp->dwSkillLvl * FLOAT(dwTime2/50.0f)) );
	}

	*pTime1 = dwTime1;
	*pTime2 = dwTime2;
}

//
// this¿¡°Ô ÆÄ¶ó¸ÞÅÍ¸¦ Àû¿ëÇÑ´Ù.
// SetDestParamÀ» ÀÏ°ýÀûÀ¸·Î ÇÏ´Â ºÎºÐ.
// m_SkillState.Serialize()ÈÄ¿¡µµ ÀÌ°Ô ¼öÇàµÈ´Ù.
// pSrc´Â ½ÃÀüÀÚ.
#ifdef __NO_HP_DMG_LIMIT
BOOL	CMover::ApplyParam(CCtrl* pSrc, ItemProp* pSkillProp, AddSkillProp* pAddSkillProp, BOOL bSend, long long nDamage)
#else
BOOL	CMover::ApplyParam(CCtrl* pSrc, ItemProp* pSkillProp, AddSkillProp* pAddSkillProp, BOOL bSend, int nDamage)
#endif
{
	int		i;
	CMover *pTarget = (CMover *)this;

	DWORD	dwDestParam, dwSkillTime, dwPainTime, dwAbilityMin;
	int		nAdjParam, nChgParam;
	int		nDestData[3];

#if __VER >= 9	// __SKILL_0706
	BOOL bPVP	= pSrc->GetType() == OT_MOVER && ( (CMover*)pSrc )->IsPlayer() && IsPlayer();
#endif	// __SKILL_0706

#ifdef __FIX_STAT_BUFF
#if __VER >= 19
	for (int i = 0; i < 6; i++)
#else
	for (int i = 0; i < 3; i++)
#endif
#else
	for (int i = 0; i < 2; i++)
#endif
	{
		if( pAddSkillProp )
		{
#ifdef __FIX_STAT_BUFF
			if (i > 1)
				break;

			if (pAddSkillProp->dwDestParam[i] == NULL_ID && pAddSkillProp->nAdjParamVal[i] == NULL_ID)
				continue;
#endif
			dwDestParam = pAddSkillProp->dwDestParam[i];
			dwSkillTime = pAddSkillProp->dwSkillTime;
			dwPainTime = pAddSkillProp->dwPainTime;
#if __VER >= 9	// __SKILL_0706
			dwAbilityMin	= bPVP? pAddSkillProp->dwAbilityMinPVP: pAddSkillProp->dwAbilityMin;
#else	// __SKILL_0706
			dwAbilityMin	= pAddSkillProp->dwAbilityMin;
#endif	// __SKILL_0706
			nAdjParam	= pAddSkillProp->nAdjParamVal[i];
			nChgParam	= (int)pAddSkillProp->dwChgParamVal[i];
			nDestData[0] = pAddSkillProp->nDestData1[0];
			nDestData[1] = pAddSkillProp->nDestData1[1];
			nDestData[2] = pAddSkillProp->nDestData1[2];
		}
		else
		{	
			dwDestParam = pSkillProp->dwDestParam[i];
			dwSkillTime = pSkillProp->dwSkillTime;
			dwPainTime  = pSkillProp->tmContinuousPain;
			dwAbilityMin = pSkillProp->dwAbilityMin;
			nAdjParam	= pSkillProp->nAdjParamVal[i];
			nChgParam	= (int)pSkillProp->dwChgParamVal[i];
			nDestData[0] = pSkillProp->nDestData1[0];
			nDestData[1] = pSkillProp->nDestData1[1];
			nDestData[2] = pSkillProp->nDestData1[2];
		}
		// destParam 1
		switch( dwDestParam )
		{
		case NULL_ID:
			break;
		case DST_CHRSTATE:		// »óÅÂ º¯°æ
			if( nAdjParam & CHS_INVISIBILITY )	// ´ÙÅ©ÀÏ·ç¼Ç»óÅÂ·Î...
			{
				if( pTarget->SetDarkCover( TRUE, dwSkillTime ) == FALSE )
					return FALSE;
				pTarget->m_wDarkCover = 0;		
			}
			else
#ifdef __SLEEPING_FIX
				if (nAdjParam & CHS_STUN || nAdjParam & CHS_SLEEPING)
#else
				if( nAdjParam & CHS_STUN )
#endif
			{
				if( pTarget->SetStun( TRUE, dwSkillTime ) == FALSE )
					return FALSE;
				// ÀÏ´Ü ¶«»§. 
				// ½ºÅÏÀÌ °É¸®´Â°Ç µÎ°¡Áö ·çÆ®°¡ ÀÖ´Âµ¥
				// 1. ½ºÅ³¿¡ ¸Â¾ÒÀ»¶§.
				// 2. ½ºÅÏ¾ÆÀÌÅÛ¿¡ ¸Â¾ÒÀ»¶§
				// 3. ±âÅ¸ »óÈ²(Æ®·¦°°Àº..)
				// ½ºÅ³À» »ç¿ëÇØ¼­ ½ºÅÏÀÌ °É¸°°Ç SkillInflu¿¡¼­ Ã³¸®ÇØ¼­
				// ÇØÁ¦±îÁö ½ÃÄÑÁÖ±â¶«¿¡ m_wStunCnt¿¡ °ªÀÌ µé¾î°¡¸é µÎ±ºµ¥¼­ ÇØÁ¦¸¦ ½ÃÅ°°Ô µÈ´Ù.
				// ¾ÆÀÌÅÛ¿¡ ÀÇÇØ ½ºÅÏÀÌ °É¸°°Ç SkillInflu¿¡¼­ Ã³¸®¸¦ ¾ÈÇÏ¹Ç·Î m_wStunCnt°¡ ÇÊ¿äÇÏ´Ù.
				// ÀÌ°÷Àº ½ºÅ³¿¡ ÀÇÇØ¼­ µé¾î¿À´Â °÷ÀÌ±â ¶§¹®.
				// ±¸Á¶°¡ Àß¸ø¼³°èµÆ´Ù.  ½ºÅ³Áß½ÉÀÌ ¾Æ´Ï°í »óÅÂÁß½ÉÀ¸·Î Ã³¸®°¡ µÆ¾î¾ß Çß´Ù.
				pTarget->m_wStunCnt = 0;		
			} else
			if( nAdjParam & CHS_POISON )	// µ¶»óÅÂ·Î..
			{
				if( pTarget->SetPoison( TRUE, pSrc->GetId(), dwSkillTime, dwPainTime, nDestData[0] ) == FALSE )	// nDestData[0] Æ½´ç µé¾î°¡´Â µ¥¹ÌÁö
					return FALSE;
				pTarget->m_wPoisonCnt = 0;		// ½ºÅÏÀÌ¶û °°Àº ÀÌÀ¯
			} else
			if( nAdjParam & CHS_DARK )	// ¾ÏÈæ»óÅÂ
			{
				if( pTarget->SetDark( TRUE, dwSkillTime, nDestData[1] ) == FALSE )		// nDestData1[1] : ¸íÁß·ü ¼öÁ¤Ä¡.
					return FALSE;
				pTarget->m_wDarkCnt = 0;		// ½ºÅÏÀÌ¶û °°Àº ÀÌÀ¯
			} else

			if( nAdjParam & CHS_BLEEDING )	// ÃâÇ÷»óÅÂ·Î..
			{
				if( nDestData[0] < 0 )
					nDestData[0]	= nDamage / 5;
				if( pTarget->SetBleeding( TRUE, pSrc->GetId(), dwSkillTime, dwPainTime, nDestData[0] ) == FALSE )
					return FALSE;
				pTarget->m_wBleedingCnt = 0;		// ½ºÅÏÀÌ¶û °°Àº ÀÌÀ¯
			} else
			{
				// ´Ù¸¥ »óÅÂµéÀº °Á ¼¼ÆÃÇÔ.
				BOOL bAble = TRUE;
				if( (nAdjParam & CHS_SLOW) && pTarget->GetProp()->dwClass == RANK_MIDBOSS )		// ½½·Î¿ì»óÅÂ¸¦ Áß°£º¸½º¿¡°Ô °É·Á°í Çß´Ù¸é.
					bAble = FALSE;		// ¸é¿ª.
				if( bAble )
					pTarget->SetDestParam( dwDestParam, nAdjParam, NULL_CHGPARAM, TRUE );
			}
			break;

		case DST_CHR_STEALHP: 			// HPÈí¼ö.  ÈíÇ÷Àº DST_·Î ÇÏ±â°¡ Á» ¾ÈÁÁ´Ù.
			{
#ifdef __NO_HP_DMG_LIMIT // LifeSteal
			long long nStealHP = (long long)(nDamage * ((long long)(double)(nAdjParam / 100.0)));
#else
			int nStealHP = (int)(nDamage * (nAdjParam / 100.0f));	// ½ÇÁ¦°¡°ÝÇÑ µ¥¹ÌÁö¿¡¼­ Èí¼öÇÒ¾çÀ» Á¤ÇÔ.
#endif
				if( pSrc->GetType() == OT_MOVER )
					((CMover *)pSrc)->SetDestParam( DST_HP, nStealHP, NULL_CHGPARAM );		// ½ÃÀüÀÚ HP·Î Èí¼ö.
			}
			break;
		case DST_CHR_STEALHP_IMM: 			// ÁöÁ¤µÈ¾çÀÇ HPÈí¼ö.  
			{
				if( GetType() == OT_MOVER )
				{
#ifdef __NO_HP_DMG_LIMIT // LifeSteal
					long long nHP = GetHitPoint();		// ¹æ¾îÀÚÀÇ hp
					long long nStealHP = nAdjParam;	// Èí¼öÇØ¾ßÇÒ hp
#else
					int nHP = GetHitPoint();		// ¹æ¾îÀÚÀÇ hp
					int nStealHP = nAdjParam;	// Èí¼öÇØ¾ßÇÒ hp
#endif
					if( nHP < nStealHP )	// ÇÇ¸¦ »Ì¾Æ¿Í¾ßÇÏ´Âµ¥ ³²ÀºÇÇ°¡ ´õ ÀûÀ¸¸é.
						nStealHP = nHP;		// ³²ÀºÇÇ¸¸Å­ »Ì¾Æ¿È
					//SetDestParam( DST_HP, -nStealHP, 0 );		// ÇÇ¸¦ »¯±è.
					if( pSrc->GetType() == OT_MOVER )
					{
//   						((CMover*)this)->m_pActMover->SendDamage( AF_FORCE,		// Å¸°ÙÀº µ¥¹ÌÁöÀÔ°í
//   													      GetId(), 
//  														  nStealHP );
						// chipi_080303 ¹ö±× ¼öÁ¤ - ¸ó½ºÅÍ°¡ ÀÚ±â ÀÚ½ÅÀ» Å¸°ÙÀ¸·Î ¼³Á¤ÇÏ´Â ¹®Á¦
 						((CMover*)this)->m_pActMover->SendDamage( AF_FORCE,		// Å¸°ÙÀº µ¥¹ÌÁöÀÔ°í
  														  ((CMover*)pSrc)->GetId(), 
 														  nStealHP );


						((CMover *)pSrc)->SetDestParam( DST_HP, nStealHP, NULL_CHGPARAM, TRUE  );		// °ø°ÝÀÚ HP·Î Èí¼ö.
					}
				}
			}
			break;

		case DST_CURECHR:		// »óÅÂ ÇØÁ¦
			pTarget->RemoveDebuff( nAdjParam );
			break;

		case DST_CLEARBUFF:		// ´ë»óÀÇ ¹öÇÁ¸¦ ÆÄ±«.
			if( nAdjParam == NULL_ID )
			{
				pTarget->RemoveBuffAll();
			}
			else
			{
				for( int i = 0; i < nAdjParam; i ++ )
					pTarget->RemoveBuffOne();
			}
			break;
		case DST_CHR_CHANCESTUN:	// adj:È®·ü		data1:½ºÅ³
		case DST_CHR_CHANCEPOISON:	// adj:È®·ü		data1:½ºÅ³
		case DST_CHR_CHANCEDARK:	// adj:È®·ü		data1:½ºÅ³
		case DST_CHR_CHANCEBLEEDING:// adj:È®·ü		data1:½ºÅ³
		case DST_CHR_CHANCESTEALHP:	// adj:È®·ü		data1:½ºÅ³
			pTarget->SetDestParam( dwDestParam, nAdjParam, nChgParam, TRUE );
			break;
			
#ifdef __WORLDSERVER
		case DST_HP:	// Èú¸µ.
			if( pAddSkillProp )
			{
				if( pSkillProp->dwReferTarget1 == RT_HEAL || pSkillProp->dwReferTarget2 == RT_HEAL )
				{
#ifdef __NO_HP_DMG_LIMIT
					unsigned long long dwHp1 = 0, dwHp2 = 0;
#else
					DWORD dwHp1 = 0, dwHp2 = 0;
#endif
					
					if( pSrc->GetType() == OT_MOVER )	// ½ÃÀüÀÚ°¡ »ç¶÷ÀÏ¶§¸¸ ½ºÅÈ¿¡ ÀÇÇÑ ¿µÇâ
					{
						if( pSkillProp->dwReferTarget1 == RT_HEAL )
						{
							switch( pSkillProp->dwReferStat1 )
							{
							case DST_STA:		dwHp1 = ((CMover *)pSrc)->GetSta();			break;
							case DST_DEX:		dwHp1 = ((CMover *)pSrc)->GetDex();			break;
							case DST_INT:		dwHp1 = ((CMover *)pSrc)->GetInt();			break;
							}
#ifdef __NO_HP_DMG_LIMIT
							dwHp1 = (unsigned long long)(((pSkillProp->dwReferValue1 / 10.0f) * dwHp1) + (pAddSkillProp->dwSkillLvl * FLOAT(dwHp1 / 50.0f)));
#else
							dwHp1 = (DWORD)(((pSkillProp->dwReferValue1 / 10.0f) * dwHp1) + (pAddSkillProp->dwSkillLvl * FLOAT(dwHp1 / 50.0f)));
#endif
						}
						
						if( pSkillProp->dwReferTarget2 == RT_HEAL )
						{
							switch( pSkillProp->dwReferStat2 )
							{
							case DST_STA:		dwHp2 = ((CMover *)pSrc)->GetSta();			break;
							case DST_DEX:		dwHp2 = ((CMover *)pSrc)->GetDex();			break;
							case DST_INT:		dwHp2 = ((CMover *)pSrc)->GetInt();			break;
							}
#ifdef __NO_HP_DMG_LIMIT
							dwHp2 = (unsigned long long)(((pSkillProp->dwReferValue2 / 10.0f) * dwHp2) + (pAddSkillProp->dwSkillLvl * FLOAT(dwHp2 / 50.0f)));
#else
							dwHp2 = (DWORD)(((pSkillProp->dwReferValue2 / 10.0f) * dwHp2) + (pAddSkillProp->dwSkillLvl * FLOAT(dwHp2 / 50.0f)));
#endif
						}
					}
					
					// Áõ°¡µÉ HP·®.
#ifdef __NO_HP_DMG_LIMIT
					long long nIncHP = pAddSkillProp->nAdjParamVal1 + dwHp1 + dwHp2;
#else
					int nIncHP = pAddSkillProp->nAdjParamVal1 + dwHp1 + dwHp2;
#endif
					// Èú¸µ°è¿­ ½ºÅ³À» ½è³Ä?
					if( (pAddSkillProp->dwDestParam1 == DST_HP || pAddSkillProp->dwDestParam2 == DST_HP) && nIncHP > 0 )
					{
#ifdef __MIKSIK_NEWSTAT
						nIncHP = (long long)(((float)nIncHP) * (GetParam(DST_HEALING_AMP, 100) / 100.0F));
#endif //__MIKSIK_NEWSTAT
						if( pSrc->GetType() == OT_MOVER )
							if( ((CMover *)pSrc)->IsPlayer() )	// ½ÃÀüÀÚ°¡ ÇÃ·¹ÀÌ¾îÀÏ¶§
								if( pTarget->GetMaxHitPoint() > pTarget->GetHitPoint() + nIncHP )		// Å¸°ÙÀÌ ¿À¹öÈú µÆ³Ä?
									((CUser *)pSrc)->m_nOverHeal = PROCESS_COUNT * 30;				// ½ÃÀüÀÚ´Â 30ÃÊ°£ ¿À¹öÈú »óÅÂ. 
					}
					
					// Èú½ÃÀÛ.
					pTarget->SetDestParam( pAddSkillProp->dwDestParam1, nIncHP, pAddSkillProp->dwChgParamVal1, TRUE );
					
				}
			}
			break;
#endif // WorldServer
#ifdef __BARUNA_PIERCING
#ifdef __WORLDSERVER
		case DST_HEAL_HP_RATE:
			{
#ifdef __NO_HP_DMG_LIMIT
			__int64 nIncHp = (((CMover*)pSrc)->GetMaxHitPoint() / 10000) * pAddSkillProp->nAdjParamVal1;
#else
			int nIncHp = (((CMover*)pSrc)->GetMaxHitPoint() / 10000) * pAddSkillProp->nAdjParamVal1;
#endif
				((CMover*)pSrc)->SetDestParam( DST_HP, nIncHp, pAddSkillProp->dwChgParamVal1, TRUE);
			}
			break;
		case DST_HEAL_FP_RATE:
			{
				int nIncFp = (((CMover*)pSrc)->GetMaxFatiguePoint() * 10000 ) / pAddSkillProp->nAdjParamVal1;
				((CMover*)pSrc)->SetDestParam( DST_FP, nIncFp, pAddSkillProp->dwChgParamVal1, TRUE);
			}
			break;
		case DST_HEAL_MP_RATE:
			{
				int nIncMp = (((CMover*)pSrc)->GetMaxManaPoint() * 10000 ) / pAddSkillProp->nAdjParamVal1;
				((CMover*)pSrc)->SetDestParam( DST_MP, nIncMp, pAddSkillProp->dwChgParamVal1, TRUE);
			}
			break;
		case DST_FORCE_DAMAGE_SAFE_HP_RATE:
			{
				//if( pAddSkillProp->nAdjParamVal1 == 0 )
				//{
				//	((CMover*)pSrc)->DoDie( pSrc);	
				//}
				//else
				//{
//					int nDecHp = ((((CMover*)pSrc)->GetMaxHitPoint() * pAddSkillProp->nAdjParamVal1 ) / 10000);
//					if( ((CMover*)pSrc)->GetHitPointPercent() >= nDecHP )
//						((CMover*)pSrc)->SetDestParam( DST_HP, nDecHp, pAddSkillProp->dwChgParamVal1, TRUE);
				//}
				pTarget->SendDamage( AF_FORCE, ((CMover*)pSrc)->GetId(), 
					( pTarget->GetMaxHitPoint() / 10000 ) * pAddSkillProp->nAdjParamVal1 ) ;
			}
			break;
		case DST_FORCE_DAMAGE_VALUE:
			for ( int i = 0; i <= MAX_BARUNA_DOT; i++ )
			{
				if( m_dwForceAttackerID[i] == 0 )
				{
					m_dwForceDamageCnt[i] =  (short)( ( pAddSkillProp->dwSkillTime / 1000.0f) * PROCESS_COUNT );
					m_dwForceDamageDamage[i] = (short)pAddSkillProp->nAdjParamVal1;
					m_dwForceDamageUnit[i] = pAddSkillProp->dwPainTime;
					m_dwForceAttackerID[i] = pSrc->GetId();
					//m_adjParamAry[DST_FORCE_DAMAGE_VALUE]	+= pAddSkillProp->nAdjParamVal1;
					pTarget->SetDestParam( dwDestParam, nAdjParam, nChgParam, bSend );
					break;
				}
			}
#endif // __WORLDSERVER
#endif // __BARUNA_PIERCING
		case DST_SPEED:
			{
				MoverProp *pMoverProp = pTarget->GetProp();
				if( pMoverProp )
				{
					if( pMoverProp->dwClass != RANK_MIDBOSS		// MIDBOSS¸¸ ¾Æ´Ï¸é ´Ù °É¸².
#if __VER >= 12 // __SECRET_ROOM
						&& pMoverProp->dwClass != RANK_SUPER	// 12Â÷ ºÎÅÍ´Â SUPERµµ ¾È°É¸°´Ù.
#endif // __SECRET_ROOM
						)		
						pTarget->SetDestParam( dwDestParam, nAdjParam, nChgParam, bSend );
				}
			}
			break;
		default: // ±×¿Ü DST_´Â ÀÏ¹ÝÀûÀÎ ·çÆ¾À» Åº´Ù.
			// ÀÏ¹Ý DST_Ã³¸®
			pTarget->SetDestParam( dwDestParam, nAdjParam, nChgParam, bSend );
			break;
		}
	}

	return TRUE;
}


BOOL	CMover::GetSkillProp( ItemProp **ppSkillProp, AddSkillProp **ppAddSkillProp, int nSkill, DWORD dwLevel, LPCTSTR szErr )
{
	char szStr[256] = {0, };
	sprintf( szStr, "%s-%s", m_szName, szErr );

	return CCtrl::GetSkillProp( ppSkillProp, ppAddSkillProp, nSkill, dwLevel, szStr );
}


// ÄðÅ¸ÀÓ ½ÃÀÛ!
#if __VER >= 9	// __SKILL_0706
void	CMover::SetCoolTime( AddSkillProp* pAddSkillProp, LPCTSTR szCall )
{
	int nIdx	= GetSkillIdx( pAddSkillProp->dwName );		// ½ºÅ³¸®½ºÆ® ÀÎµ¦½º¸¦ Ã£À½.
	
	if( nIdx < 0 || nIdx >= MAX_SKILL_JOB )
		Error( "szCall SetCoolTime : %d %d½ºÅ³À» Ã£À» ¼ö ¾øÀ½ %s", nIdx, pAddSkillProp->dwName, GetName() );
	else
		m_tmReUseDelay[ nIdx ] = pAddSkillProp->dwCooldown + timeGetTime();		// 1/1000´ÜÀ§
}
#else	// __SKILL_0706
void	CMover::SetCoolTime( ItemProp *pSkillProp, LPCTSTR szCall )
{
	int nIdx = GetSkillIdx( pSkillProp->dwID );		// ½ºÅ³¸®½ºÆ® ÀÎµ¦½º¸¦ Ã£À½.
	
	if( nIdx < 0 || nIdx >= MAX_SKILL_JOB )
		Error( "szCall SetCoolTime : %d %d½ºÅ³À» Ã£À» ¼ö ¾øÀ½ %s", nIdx, pSkillProp->dwID, GetName() );
	else
		m_tmReUseDelay[ nIdx ] = pSkillProp->dwSkillReady + timeGetTime();	// 1/1000´ÜÀ§
}
#endif	// __SKILL_0706
//
//	¸¶¹ý ½ºÅ³ÀÇ Å¸Á¡¶§ È£Ãâ.
//  nCount ¿öÅÍº¼ÀÇ °æ¿ì ¿©·¯¹ø È£ÃâÀÌ µÇ±â¶§¹®¿¡ nCount==0 ÀÇ °æ¿ì¸¸ °æÇèÄ¡°¡ ¿Ã¶ó°£´Ù.
//
BOOL CMover::OnMagicSkill( int nType, int nCount )
{
	if( m_oaAct != OBJACT_USESKILL )	
		return FALSE;	// ½ºÅ³»ç¿ëÈÄ Å¸Á¡ÀÌ µÇ±âÀü¿¡ ´Ù¸¥ ¸í·ÉÀ¸·Î ¹Ù²ï°æ¿ì. ÀÌ·±»óÈ²ÀÌ ¿Í¼± ¾ÈµÈ´Ù.

	int			nSkill = GetActParam(0);
	OBJID		idTarget = GetActParam(1);
	DWORD		dwLevel = GetActParam( 3 );
#if __VER >= 8 // __S8_PK
	BOOL	bControl = GetActParam( 4 );
#endif // __VER >= 8 // __S8_PK

	ItemProp*	pSkillProp = NULL;
	AddSkillProp* pAddSkillProp = NULL;
	LPSKILL		pSkill	= NULL;
	
	BOOL bRet = GetSkillProp( &pSkillProp, &pAddSkillProp, nSkill, dwLevel, "CMover::OnMagicSkill" );
	if( bRet == FALSE )
	{
		Error( "OnMagicSkill : ½ºÅ³ÇÁ·ÓÀÐ±â ½ÇÆÐÇÔ. ÇöÀçÁøÇàÁßÀÎ Motion=%d %d", m_dwMotion, dwLevel );
		return FALSE;
	}
	
	CMover* pFocusObj = prj.GetMover( idTarget );		// Å¸°Ù¹«¹öÆ÷ÀÎÅÍ¸¦ ¾ò¾î³¿.
	if( IsInvalidObj( pFocusObj ) )		
		return FALSE;

	if( pSkillProp->dwID == SI_ASS_HEAL_HEALING )	// Èú¸µ »ó´ë°¡ Á×¾úÀ¸¸é Ãë¼Ò
	{
		if( pFocusObj->IsDie() )
			return FALSE;
	}

	BOOL bSuccess = FALSE;
	BOOL bShoot	= pSkillProp->dwExeTarget == EXT_MAGICATKSHOT  || pSkillProp->dwExeTarget == EXT_MAGICSHOT;
	if( bShoot )	// ½î´Â ÇüÅÂ¸¸ sfx¹ß»ý.
	{
#ifdef __WORLDSERVER
		int nMaxDmgCnt	= 1;
		if( pSkillProp->tmContinuousPain != NULL_ID )
			nMaxDmgCnt	= ( pAddSkillProp->dwSkillTime / pAddSkillProp->dwPainTime ) + 1;
		float fDmgPower = 0;
		if( pSkillProp->dwDmgShift != NULL_ID )
			fDmgPower	= (int)pSkillProp->dwDmgShift * 0.2f;
//		for( int nDmgCnt = 0; nDmgCnt < nMaxDmgCnt; nDmgCnt++ )
#if __VER >= 8 // __S8_PK
			OnAttackSFX( pFocusObj->GetId(), pAddSkillProp->dwSkillLvl, pSkillProp->dwID, 0, GetAngle(), fDmgPower, ( pSkillProp->dwSkillType == KT_SKILL? AF_MELEESKILL: AF_MAGICSKILL ), bControl );
#else // __VER >= 8 // __S8_PK
			OnAttackSFX( pFocusObj->GetId(), pAddSkillProp->dwSkillLvl, pSkillProp->dwID, 0, GetAngle(), fDmgPower, ( pSkillProp->dwSkillType == KT_SKILL? AF_MELEESKILL: AF_MAGICSKILL ) );
#endif // __VER >= 8 // __S8_PK
#endif	// __WORLDSERVER
		bSuccess = ShootSkill( pFocusObj, pSkillProp, pAddSkillProp );		// ¼­¹ö¿¡¼± ÀÌºÎºÐÀº ½ÇÇà¾ÈµÈ´Ù.
	}
	else
	{
		// Àû¿ë¹üÀ§ Ã³¸®. ³»ºÎ¿¡¼­ ApplySkill()À» È£Ãâ.
#if __VER >= 8 // __S8_PK
#ifdef __NO_HP_DMG_LIMIT
		long long nDamage = DoApplySkill(pFocusObj, pSkillProp, pAddSkillProp, false, 0, FALSE, bControl);
#else
		int nDamage = DoApplySkill(pFocusObj, pSkillProp, pAddSkillProp, false, 0, FALSE, bControl);
#endif
#else // __VER >= 8 // __S8_PK
		int nDamage = DoApplySkill( pFocusObj, pSkillProp, pAddSkillProp );
#endif // __VER >= 8 // __S8_PK
		if( nDamage == 0 )
			return FALSE;
#ifdef __NO_HP_DMG_LIMIT 
		bSuccess = nDamage > 0;
#else
		bSuccess = (BOOL)nDamage;
#endif

	#ifdef __CLIENT	
		if( pSkillProp->dwID == SI_MAG_MAG_BLINKPOOL )
		{
			CWndWorld* pWndWorld = (CWndWorld*)g_WndMng.GetWndBase( APP_WORLD );
			
			if( IsActiveMover() )
			{
				D3DXVECTOR3 vStart;
				D3DXVECTOR3 vEnd;

				vStart = GetPos();		vStart.y += 1.0f;
				vEnd = pWndWorld->m_vTelePos;
				
				CWorld *pWorld = GetWorld();
				
				if( pWorld->IntersectObjLine( NULL, vStart, vEnd, FALSE, FALSE ) )
				{
					g_WndMng.m_pWndWorld->SetNextSkill( NEXTSKILL_NONE );
					g_WndMng.PutString( prj.GetText( TID_GAME_BLOCKTARGETING ), NULL, prj.GetTextColor( TID_GAME_BLOCKTARGETING ) );
					return FALSE;
				}
			
				g_DPlay.SendTeleSkill( GetId(), pWndWorld->m_vTelePos );
			}
		}
	#endif // Client		
	}
	
	if( bSuccess )	// ½ºÅ³»ç¿ë ½ÇÆÐÇÏ¸é ¸¶³ª¾È±ðÀÓ. / °æÇèÄ¡ ¾È¿À¸§.
	{
	#ifdef __WORLDSERVER
		// ¹ß»çÇÑ ¼ø°£¿¡ ¸¶³ªµîÀ» ±ï´Â´Ù.
		int nReqMp = GetReqMp( pAddSkillProp->nReqMp );

		#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if(nReqMp != 9999999)
		#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		{
			if( pAddSkillProp->nSkillCount > 1 )
				nReqMp /= pAddSkillProp->nSkillCount;
			IncManaPoint( -nReqMp );
			if( pAddSkillProp->nReqFp != NULL_ID )
				IncFatiguePoint( -GetReqFp( pAddSkillProp->nReqFp ) );
		}
		
		#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			if( pSkillProp->dwID == SI_RIG_HERO_RETURN )
			{
#ifdef __RM_HERO_SKILL
				if (IsValidObj(pFocusObj) && pFocusObj->IsPlayer())
				{
					vector<DWORD> vBuffs;
					vBuffs.push_back(SI_ASS_HEAL_PATIENCE);
					vBuffs.push_back(SI_ASS_CHEER_HEAPUP);
					vBuffs.push_back(SI_ASS_CHEER_CANNONBALL);
					vBuffs.push_back(SI_ASS_CHEER_MENTALSIGN);
					vBuffs.push_back(SI_ASS_CHEER_BEEFUP);
					vBuffs.push_back(SI_ASS_CHEER_QUICKSTEP);
					vBuffs.push_back(SI_ASS_CHEER_CATSREFLEX);
					vBuffs.push_back(SI_ASS_CHEER_ACCURACY);
					vBuffs.push_back(SI_ASS_CHEER_HASTE);

					vBuffs.push_back(SI_RIN_SUP_PROTECT);
					vBuffs.push_back(SI_RIN_SUP_HOLYGUARD);
					vBuffs.push_back(SI_RIN_SUP_SPIRITUREFORTUNE);
					vBuffs.push_back(SI_RIN_SQU_GEBURAHTIPHRETH);


					for (int i = 0; i < vBuffs.size(); i++)
					{
						ItemProp* pSkillProp = prj.GetSkillProp(vBuffs[i]);
						if (pSkillProp)
						{
							AddSkillProp* pAddSkillProp = prj.GetAddSkillProp(pSkillProp->dwSubDefine + pSkillProp->dwExpertMax - 1);
							if (pAddSkillProp)
							{
								DoApplySkill(pFocusObj, pSkillProp, pAddSkillProp, false, 0, 0, 0);
								g_UserMng.AddDoApplySkill(this, pFocusObj->GetId(), vBuffs[i], pSkillProp->dwExpertMax);
							}
						}
					}
				}
#else
				REPLACE_TYPE type = REPLACE_NORMAL;

				PRegionElem pRgnElem = NULL;
				CWorld* pWorld = GetWorld();
				if (!pWorld)
					return FALSE;

				if (IsChaotic())
				{
#if __VER >= 8 // __S8_PK
					if (pWorld->GetID() != pWorld->m_dwIdWorldRevival && pWorld->m_dwIdWorldRevival != 0)
						pRgnElem = g_WorldMng.GetRevivalPosChao(pWorld->m_dwIdWorldRevival, pWorld->m_szKeyRevival);
					if (NULL == pRgnElem)	// Find near revival pos
						pRgnElem = g_WorldMng.GetNearRevivalPosChao(pWorld->GetID(), GetPos());
#else // __VER >= 8 // __S8_PK
					pRgnElem = g_WorldMng.GetNearRevivalPosChao(pWorld->GetID(), GetPos());
#endif // __VER >= 8 // __S8_PK
				}
				else

				{
					if (pWorld->GetID() != pWorld->m_dwIdWorldRevival && pWorld->m_dwIdWorldRevival != 0)
						pRgnElem = g_WorldMng.GetRevivalPos(pWorld->m_dwIdWorldRevival, pWorld->m_szKeyRevival);
					if (NULL == pRgnElem)	// Find near revival pos
						pRgnElem = g_WorldMng.GetNearRevivalPos(pWorld->GetID(), GetPos());
				}
				if (NULL != pRgnElem)
					REPLACE(g_uIdofMulti, pRgnElem->m_dwWorldId, pRgnElem->m_vPos, type, nRevivalLayer);
				else
					REPLACE(g_uIdofMulti, pWorld->GetID(), GetPos(), type, nDefaultLayer);
#endif
			}
			if (pSkillProp->dwID == SI_KNT_HERO_DRAWING)
			{
#ifdef __GAMEGUARD
				if (!pFocusObj->GetWorld() || !GetWorld())
					return FALSE;
				if (pFocusObj->GetWorld()->GetID() != GetWorld()->GetID())
					return FALSE;
#endif // __GAMEGUARD
				D3DXVECTOR3 vSrc = GetPos();
				FLOAT		fAngle = GetDegree(pFocusObj->GetPos(), GetPos());	// ½ÃÀüÀÚ¿Í Å¸°ÙÀÇ °¢µµ¸¦ ±¸ÇÔ
				//vSrc.x -= 1.0f;
				//vSrc.z -= 1.0f;

				pFocusObj->SetPos(vSrc);
				g_UserMng.AddSetPos(pFocusObj, vSrc);
				g_UserMng.AddPushPower(pFocusObj, pFocusObj->GetPos(), pFocusObj->GetAngle(), fAngle, 0.2f);
				pFocusObj->ClearDestObj();
				//				pFocusObj->SetPosChanged( TRUE );
	}
#ifdef __3RD_LEGEND16
			if (pSkillProp->dwID == SI_LOD_SUP_PULLING)
			{
				D3DXVECTOR3 vSrc = GetPos();
				FLOAT fAngle = GetDegree(pFocusObj->GetPos(), GetPos());

				pFocusObj->SetPos(vSrc);
				g_UserMng.AddSetPos(pFocusObj, vSrc);
				g_UserMng.AddPushPower(pFocusObj, pFocusObj->GetPos(), pFocusObj->GetAngle(), fAngle, 0.2f);
				pFocusObj->ClearDestObj();
			}
#endif // __3RD_LEGEND16
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	#endif // WORLDSERVER

		// ÄðÅ¸ÀÓ ½Ã°£ Àû¿ë - Å¬¶ó ¼­¹ö µ¿½Ã¿¡ µ¹¾Æ°£´Ù
	#ifdef __CLIENT
		if( IsActiveMover() && nCount == 0 )		// ¿¬¼ÓÅ¸Á¡ÀÏ°æ¿ì Ã¹¹øÂ° Å¸Á¡¿¡¸¸ Àû¿ë
	#endif // __CLIENT
#if __VER >= 9	// __SKILL_0706
		if( pAddSkillProp->dwCooldown != 0xFFFFFFFF )
			SetCoolTime( pAddSkillProp, "OnMagicSkill" );
#else	// __SKILL_0706
		if( pSkillProp->dwSkillReady != 0xffffffff )	// ÄðÅ¸ÀÓÀÌ ÀÖ´Â ½ºÅ³ÀÇ °æ¿ì
			SetCoolTime( pSkillProp, "OnMagicSkill" );
#endif	// __SKILL_0706
	} // bSuccess

#if defined(__CLIENT)
	CModelObject* pModel = (CModelObject*)m_pModel;
	if( pModel )
	{
		pModel->m_SparkInfo.m_bUsed  = TRUE;
		pModel->m_SparkInfo.m_v3Color.x = 2.0f;
		pModel->m_SparkInfo.m_v3Color.y = 2.0f;
		pModel->m_SparkInfo.m_v3Color.z = 2.0f;
		pModel->m_SparkInfo.m_nCnt = 0;
		pModel->m_SparkInfo.m_fLerp= 1.0f;
		
		AngleToVectorXZ( &pModel->m_SparkInfo.m_v3SparkDir, GetAngle(), -1.0f );
	}
#endif //defined(__CLIENT)

	return TRUE;
} // OnMagicSkill


//
//	Àå°Å¸®¹«±â°¡ ¹ß»çµÇ´Â ½ÃÁ¡¿¡ ¹ß»ýÇÏ´Â ÀÌº¥Æ®
//
BOOL	CMover::OnAttackRange()
{
	int		idTarget = GetActParam( 0 );
	DWORD	dwItemID = GetActParam( 1 );		// »ç¿ëÇÒ ¾ÆÀÌÅÛ ¾ÆÀÌµð (playerÀÌ¸é ÃæÀü·¹º§)
	int		idSfxHit = GetActParam( 2 );		// ¸ó½ºÅÍ°¡ »ç¿ëÇÑ°ÍÀÌ¸é ¿©±â¿¡ ¼­¹ö·ÎºÎÅÍ ¹ÞÀº°ªÀÌ µé¾îÀÖ´Ù.
#if __VER >= 8 // __S8_PK
	BOOL	bControl = FALSE;
#endif // __VER >= 8 // __S8_PK

	CMover* pHit = prj.GetMover( idTarget );	// Å¸°ÙÀÇ Æ÷ÀÎÅÍ¸¦ ¾ò¾î³¿.
	if( IsInvalidObj(pHit) )	
		return FALSE;							// Å¬¸¯ÇßÀ»´ç½Ã´Â ÀÖ¾úÀ¸³ª ¹ß»çµÇ±âÀü¿¡ »èÁ¦µÇ¾ú´Ù.
	
	ItemProp *pItemProp = NULL;
	if( IsPlayer() )
		pItemProp = GetActiveHandItemProp();		// ÀÌ·±°æ¿ì´Â °Á ¼Õ¿¡ µç ¹«±â(È¤Àº ±âº»¾ÆÀÌÅÛ)
	else 
	{
		if( dwItemID == NULL_ID || dwItemID == 0 )	
			pItemProp = GetActiveHandItemProp();		// ÀÌ·±°æ¿ì´Â °Á ¼Õ¿¡ µç ¹«±â(È¤Àº ±âº»¾ÆÀÌÅÛ)
		else
			pItemProp = prj.GetItemProp( dwItemID );	// Á÷Á¢ ¾ÆÀÌÅÛÀ» ÁöÁ¤ÇÑ °æ¿ì´Â ±×°É·Î °ø°ÝÇÔ(¸ó½ºÅÍ°¡ ÁÖ·Î »ç¿ëÇÔ)
	}

	if( pItemProp == NULL )
		return FALSE;

#ifdef __WORLDSERVER
#if __VER >= 12 // __MONSTER_SKILL
	if( IsNPC() )
		CMonsterSkill::GetInstance()->ApplySkill( this, pHit, ATK_RANGE );
#endif // __MONSTER_SKILL
#endif // __WORLDSERVER

	DWORD dwSfxObj = pItemProp->dwSfxObj2;
	
	D3DXVECTOR3 vPosDest = pHit->GetPos() + D3DXVECTOR3( 0.0f, 1.0f, 0.0f ); // ¹ß»ç ÁöÁ¡À» ÀÓÀÇ·Î ¿Ã·ÁÁØ´Ù. ¶«»§ 
	D3DXVECTOR3 vPosSrc  = GetPos() + D3DXVECTOR3( 0.0f, 1.0f, 0.0f ); // ¹ß»ç ÁöÁ¡À» ÀÓÀÇ·Î ¿Ã·ÁÁØ´Ù. ¶«»§ 

#ifdef __CLIENT		
	CSfx* pSfx = NULL;
#endif
	// ¾ÆÅ©·Î¹îÀº ÀÌÆåÆ® Ãâ·ÂÀÌ Ç×»ó ¿Þ¼Õ¿¡...
	if( IsPlayer() )		
	{
		ItemProp *pItemElem = GetActiveHandItemProp( PARTS_BULLET );  // È­»ì¾ÆÀÌÅÛÀ» ÂüÁ¶·Î È­»ìÀÌÆåÆ® »ý¼º
		if( pItemElem && pItemElem->dwSfxObj2 != NULL_ID )
		{
		#ifdef __CLIENT
			if( IsActiveMover() )
				pSfx = CreateSfxArrow( pItemElem->dwSfxObj2, pItemProp->dwSfxObj3, vPosDest, idTarget );
		#endif //__CLIENT

		#ifdef __WORLDSERVER
			g_UserMng.AddCreateSfxAllow( this, pItemElem->dwSfxObj2, pItemProp->dwSfxObj3, vPosDest, idTarget );
		#endif //__WORLDSERVER
		}
	}
	else
	{
		if( dwSfxObj == NULL_ID )	
			return FALSE;
	#ifdef __CLIENT		
		pSfx = CreateSfx( D3DDEVICE, dwSfxObj, vPosSrc,GetId(), vPosDest ,idTarget );
	#endif
	}

	DWORD dwAtkFlags = AF_GENERIC;
	if( IsPlayer() )
		dwAtkFlags |= AF_RANGE;

#ifdef __WORLDSERVER
#if __VER >= 8 // __S8_PK
	OnAttackSFX( pHit->GetId(), ( IsPlayer()? dwItemID: 0 ), NULL_ID, 0, 0, 0, dwAtkFlags, bControl );
#else // __VER >= 8 // __S8_PK
	OnAttackSFX( pHit->GetId(), ( IsPlayer()? dwItemID: 0 ), NULL_ID, 0, 0, 0, dwAtkFlags );
#endif // __VER >= 8 // __S8_PK
#endif	// __WORLDSERVER

#ifdef __CLIENT
	if( pSfx )
	{
		if( IsActiveMover() )		
		{
			idSfxHit = ++m_idSfxHit; 	// Å¬¶ó¿¡¼­ ¹ß»çÃ¼°¡ »ý¼ºµÈ Áï½Ã ID¸¦ ¸¸µé°í ±×°ÍÀ» ¼­¹ö·Î º¸³¿.
			g_DPlay.SendSfxID( idTarget, idSfxHit, dwAtkFlags );
			pSfx->m_idSfxHit	= idSfxHit;
			pSfx->m_nMagicPower = IsPlayer() ? dwItemID : 0;		// ÃæÀü·¹º§µµ ³Ö¾îÁØ´Ù.
		}
		// ½ð³ðÀÌ g_pPlayer°Å³ª / ½ð³ðÀº ¸÷ÀÌ°í ¸Â´Â³ðÀÌ g_pPlayer¸é
		if( IsActiveMover() || (IsNPC() && pHit->IsActiveMover()) )
			pSfx->m_idSfxHit	= idSfxHit;		// id¸¦ µî·ÏÇÔ
	}
#endif //__CLIENT
	return TRUE;
}


//
//	¿Ïµå(¸ÅÁ÷)¾îÅÃÀÌ ¹ß»çµÇ´Â ½ÃÁ¡¿¡ ¹ß»ýÇÏ´Â ÀÌº¥Æ®.
//	
BOOL	CMover::OnAttackMagic()
{
	int		idTarget = GetActParam( 0 );
	int		nMagicPower = GetActParam( 1 );
#if __VER >= 8 // __S8_PK
	BOOL	bControl = GetActParam( 4 );
#endif // __VER >= 8 // __S8_PK

	CMover* pHit = prj.GetMover( idTarget );	// Å¸°ÙÀÇ Æ÷ÀÎÅÍ¸¦ ¾ò¾î³¿.

	if( IsInvalidObj(pHit) )	
		return FALSE;		// Å¬¸¯ÇßÀ»´ç½Ã´Â ÀÖ¾úÀ¸³ª ¹ß»çµÇ±âÀü¿¡ »èÁ¦µÇ¾ú´Ù.

#ifdef __WORLDSERVER
#if __VER >= 8 // __S8_PK
	OnAttackSFX( pHit->GetId(), nMagicPower, NULL_ID, 0, 0, 0, AF_MAGIC, bControl );
#else // __VER >= 8 // __S8_PK
	OnAttackSFX( pHit->GetId(), nMagicPower, NULL_ID, 0, 0, 0, AF_MAGIC );
#endif // __VER >= 8 // __S8_PK
#else	// __WORLDSERVER
	DWORD dwWeaponId;

	if( IsActiveMover() ) 
	{
		CItemElem* pWeapon = GetWeaponItem();
		if( pWeapon == NULL )	return FALSE;
		dwWeaponId	= pWeapon->m_dwItemId;
	}
	else 
	{
		dwWeaponId	= m_aEquipInfo[PARTS_RWEAPON].dwId;
		if( dwWeaponId == NULL )	return FALSE;
	}

#if __VER < 11 // __REMOVE_ENDURANCE
	if( IsActiveMover() )
	{
		CItemElem* pWeapon = GetWeaponItem();
		ItemProp* pItemProp		= pWeapon->GetProp();
		if( pItemProp )
			if( ( ( pWeapon->m_nHitPoint * 100 ) / pItemProp->dwEndurance ) == 0 )
				g_WndMng.PutString( prj.GetText( TID_GAME_WASTEENDURANCE ), NULL, prj.GetTextColor( TID_GAME_WASTEENDURANCE ) );
	}
#endif // __REMOVE_ENDURANCE

	D3DXVECTOR3 vPosDest = pHit->GetPos(); 
	// ¹ß»ç ¸ñÇ¥ÁöÁ¡Àº »ó´ëÀÇ Áß¾Ó.
	float fHeight = fabs(pHit->m_pModel->m_vMax.y) / 2.0f;	// ¾ÆÀÌ¹ÙÆ®°°Àº³ÑÀº °øÁß¿¡ ¶°ÀÖ±â¶«¿¡ ¼ø¼ö ³ôÀÌÀÎ Max°ª¸¸ ÃëÇß´Ù.
	fHeight *= pHit->GetScale().x;
	vPosDest.y += fHeight;	

	D3DXVECTOR3 vPosSrc = GetPos() + D3DXVECTOR3( 0.0f, 1.0f, 0.0f ); // ¹ß»ç ÁöÁ¡À» ÀÓÀÇ·Î ¿Ã·ÁÁØ´Ù. ¶«»§ 

	ItemProp *pHandItemProp = GetActiveHandItemProp( PARTS_RWEAPON );
	CSfx* pSfx = NULL;
	if( m_pActMover->IsFly() )
	{
		pSfx = CreateSfx( D3DDEVICE, XI_FIR_WAND02, vPosSrc, GetId(), vPosDest, idTarget );
		if( pSfx )
			pSfx->ShootSfx( GetAngle(), -GetAngleX(), 0.75f );		 
	} 
	else
	{
		DWORD dwSfxObj2 = XI_FIR_WAND01;
		if( pHandItemProp )
			dwSfxObj2 = pHandItemProp->dwSfxObj2;

		pSfx = CreateSfx( D3DDEVICE, dwSfxObj2, vPosSrc,GetId(), vPosDest ,idTarget );
		if( pSfx )
		{
			switch(nMagicPower) 
			{
			case 1:		pSfx->SetScale( D3DXVECTOR3( 1.2f, 1.2f, 1.2f ) );	break;
			case 2:		pSfx->SetScale( D3DXVECTOR3( 1.7f, 1.7f, 1.7f ) );	break;
			case 3:
			case 4:		pSfx->SetScale( D3DXVECTOR3( 2.5f, 2.5f, 2.5f ) );	break;
			}
			((CSfxItemWandAtk1 *)pSfx)->m_fCenter = fHeight;		
		}
	}

	if( pSfx )
	{
		if( IsActiveMover() )		// g_pPlayer¸¸ ¾Æ·¡ÁþÀ» ÇÏ°Ô ÇÑ´Ù.
		{
			int idSfxHit = ++m_idSfxHit;			// Å¬¶ó¿¡¼­ ¹ß»çÃ¼°¡ »ý¼ºµÈ Áï½Ã ID¸¦ ¸¸µé°í ±×°ÍÀ» ¼­¹ö·Î º¸³¿.
			g_DPlay.SendSfxID( idTarget, idSfxHit, AF_MAGIC );
			pSfx->m_idSfxHit	= idSfxHit;
			pSfx->m_nMagicPower = nMagicPower;		// ÃæÀü·¹º§µµ ³Ö¾îÁØ´Ù.
		}
	}


	CModelObject* pModel = (CModelObject*)m_pModel;
	if( pModel )
	{
		pModel->m_SparkInfo.m_bUsed  = TRUE;
		pModel->m_SparkInfo.m_v3Color.x = 2.0f;
		pModel->m_SparkInfo.m_v3Color.y = 2.0f;
		pModel->m_SparkInfo.m_v3Color.z = 2.0f;
		pModel->m_SparkInfo.m_nCnt = 0;
		pModel->m_SparkInfo.m_fLerp= 1.0f;
		
		AngleToVectorXZ( &pModel->m_SparkInfo.m_v3SparkDir, GetAngle(), -1.0f );
	}
#endif // __WORLDSERVER
	return TRUE;
}

void	CMover::OnAttackMelee_ClockWorks( DWORD dwState, CMover *pHitObj )
{
	int		nItemID = GetActParam( 1 );	// »ç¿ëÇÒ ¾ÆÀÌÅÛ ¾ÆÀÌµð

#ifdef __WORLDSERVER
	UpdateMatrix();		// ¸öÃ¼ÀÇ Æ¯Á¤ºÎÀ§¿¡¼­ ³ª´Â µ¥¹ÌÁö¸¦ Ã³¸®ÇÏ±â À§ÇØ¼± ¼­¹ö¿¡¼­µµ ¸ÅÆ®¸¯½º¸¦ °»½ÅÇØ¾ßÇÑ´Ù.
	CModelObject *pModel = (CModelObject *)m_pModel;
	pModel->UpdateMatrixBone();		// ¼­¹ö¿¡¼­´Â º»¾Ö´Ï¸ÞÀÌ¼ÇÀ» ÇÏÁö ¾ÊÀ¸¹Ç·Î GetEventPos()¸¦ »ç¿ëÇÒ ÀÏÀÌ ÀÖÀ»¶© ¾÷µ¥ÀÌÆ®¸¦ ÇØÁà¾ß ÇÑ´Ù.
#endif // WorldServer
	
	switch( dwState )
	{
	case OBJSTA_ATK1:		// Ä®·Î ³»·ÁÄ¡±â
		{
			D3DXVECTOR3 vPos;
			CModelObject *pModel = (CModelObject *)m_pModel;
			pModel->GetEventPos( &vPos, 0 );
			D3DXVec3TransformCoord( &vPos, &vPos, GetMatrixWorldPtr() );

			OnDamage( nItemID, dwState, NULL, &vPos );		// ÀÌÆåÆ®°¡ ¹ß»ýÇÏ´Â À§Ä¡¿¡ µ¥¹ÌÁö¸¦ ÁÖ°í
#ifdef __CLIENT
			GetWorld()->m_pCamera->SetQuake( 15, 0.5f );
			CSfx *pSfx = CreateSfx( D3DDEVICE, XI_NPCSP1DIRFIRESP, vPos );	// ÀÌÆåÆ®¸¦ ¹ß»ý - ¼­¹ö¿¡¼± »ý¼º ¾ÈµÊ.
			if( pSfx )
				pSfx->SetAngle( -GetAngle() );
#endif 
		}
		break;
	case OBJSTA_ATK2:		// Æ÷½î±â
		{
			D3DXVECTOR3 vPos;
			CModelObject *pModel = (CModelObject *)m_pModel;
			pModel->GetEventPos( &vPos, 1 );	// ¿Þ¼Õ Áý°Ô¹ß À§Ä¡.
			D3DXVec3TransformCoord( &vPos, &vPos, GetMatrixWorldPtr() );
#ifdef __CLIENT
			CSfx *pSfx = CreateSfx( D3DDEVICE, XI_NPCSP1DIRCANNON, vPos, GetId() );	// ¹ß»çÀÌÆåÆ®.
			if( pSfx )
			{
				pSfx->SetAngle( -GetAngle() );
				pSfx->SetScale( D3DXVECTOR3(4.0f, 4.0f, 4.0f) );
			}
#endif
			CMover *pTarget = pHitObj;
			if( IsValidObj(pTarget) )
			{
				OnDamage( nItemID, dwState, NULL, &pTarget->GetPos() );		// Å¸°ÙÀÇ ÁÂÇ¥¸¦ Áß½ÉÀ¸·Î µ¥¹ÌÁö¸¦ ÁÜ.
#ifdef __CLIENT
				pSfx = CreateSfx( D3DDEVICE, XI_NPCSP1RANBALL, vPos, GetId(), pTarget->GetPos(), pTarget->GetId(), -1 );		// Æ÷Åº
				if( pSfx )
				{
					pSfx->SetScale( D3DXVECTOR3(4.0f, 4.0f, 4.0f) );
					{
						FLOAT fAngXZ, fAngH;
						D3DXVECTOR3 vDist = pTarget->GetPos() - vPos;
						xGetDegree( &fAngXZ, &fAngH, vDist );		// ¸ñÇ¥¿ÍÀÇ °¢µµ±¸ÇÔ.
						((CSfxAtkStraight *)pSfx)->ShootSfx( fAngXZ, -fAngH, 2.0f, XI_NPCSP1RANBOOM );		// ³¯¾Æ°¡´Â ¹æÇâ ¼³Á¤.
					}
				}
#endif
			}
		}
		break;
	case OBJSTA_ATK3:
#ifdef __CLIENT
		GetWorld()->m_pCamera->SetQuake( 30, 0.7f );
#endif
		break;
	case OBJSTA_ATK4:	// ¹ß·Î ¹â±â.
		{
			D3DXVECTOR3 vPos;

			vPos = GetPos();
			DWORD dwFlag = AF_GENERIC;
			if( xRandom(100) < 15 )
				dwFlag |= AF_FLYING;
			OnDamage( nItemID, dwState, NULL, &vPos, dwFlag );		// µ¥¹ÌÁö´Â ¸öÁß½ÉÀ» ±âÁØÀ¸·Î ÇÑ´Ù.

			CModelObject *pModel = (CModelObject *)m_pModel;
			pModel->GetEventPos( &vPos, 3 );
			D3DXVec3TransformCoord( &vPos, &vPos, GetMatrixWorldPtr() );

#ifdef __CLIENT
			GetWorld()->m_pCamera->SetQuake( 60, 1.5f );

			CSfx *pSfx = CreateSfx( D3DDEVICE, XI_NPCSP1DIRCIRCLE, vPos );
			if( pSfx )
				pSfx->SetScale( D3DXVECTOR3(2.0f, 2.0f, 2.0f) );
			pModel->GetEventPos( &vPos, 4 );
			D3DXVec3TransformCoord( &vPos, &vPos, GetMatrixWorldPtr() );

			pSfx = CreateSfx( D3DDEVICE, XI_NPCSP1DIRCIRCLE, vPos );
			if( pSfx )
				pSfx->SetScale( D3DXVECTOR3(2.0f, 2.0f, 2.0f) );
#endif
		}
		break;
	}
}

#ifdef __WORLDSERVER
#ifdef __NEW_BOSSMECHANICS
void CMover::CreateKarvanAttack1(DWORD skillID, OBJID idTarget)
{
	//SI_KARVAN_METEORDOWN_1
	//Finds randomly up to 10 players and sends a line of 6 attacks in their direction.
	CObj* pObj;
	BOOL bApply = FALSE;
	D3DXVECTOR3 vPos = GetPos();
	int nRange = 24;
	float fRange = 24.0f;

	int attackSent = 0;

	vector<D3DXVECTOR3> attackPositions;

	FOR_LINKMAP(GetWorld(), vPos, pObj, nRange, CObj::linkPlayer, GetLayer())
	{
		bApply = FALSE;
		if (IsValidObj(pObj) && pObj->GetType() == OT_MOVER)
		{
			if (attackSent < 10)
			{
				CMover* pTargetSplash = (CMover*)pObj;
				if (pTargetSplash->IsPlayer())
					bApply = TRUE;

				if (bApply && pObj->IsRangeObj(this, fRange))
				{
					if (pTargetSplash != this && pTargetSplash->IsLive() && xRandom(100) > 50)
					{
						D3DXVECTOR3 start = GetPos();
						D3DXVECTOR3 end = pTargetSplash->GetPos();

						if (end.x > start.x)
							end.x += 12;
						else
							end.x -= 12;

						if (end.z > start.z)
							end.z += 12;
						else
							end.z -= 12;

						float attackAmount = 6.0f;
						float xDifference = abs(start.x - end.x);
						float zDifference = abs(start.z - end.z);
						float xStepSize = (xDifference / attackAmount);
						float zStepSize = (zDifference / attackAmount);

						for (int i = 0; i < (int)attackAmount; i++)
						{
							D3DXVECTOR3 attackPos = start;

							if (attackPos.x > end.x)
								attackPos.x -= (xStepSize * (i + 1));
							else
								attackPos.x += (xStepSize * (i + 1));

							if (attackPos.z > end.z)
								attackPos.z -= (zStepSize * (i + 1));
							else
								attackPos.z += (zStepSize * (i + 1));

							attackPositions.push_back(attackPos);
						}

						CreateStorm(skillID, attackPositions, GetPos(), pTargetSplash->GetId(), 1, 500);
						attackSent++;

						attackPositions.clear();
					}
				}
			}
			else
				return;
		}
	}
	END_LINKMAP



}
void CMover::CreateKarvanAttack2(DWORD skillID, OBJID idTarget)
{
	//SI_KARVAN_FIREPULSE
	//Creates 5 Rows of Attacks going forward from its position.
	vector<D3DXVECTOR3> startPositions;
	D3DXVECTOR3 startPos = GetPos();

	CMover* pHit = prj.GetMover(idTarget);
	if (IsValidObj(pHit))
		startPos = pHit->GetPos();

	startPositions.push_back(startPos);

	startPos.z -= 8;
	startPositions.push_back(startPos);

	startPos.z -= 8;
	startPositions.push_back(startPos);

	startPos.z += 16;
	startPos.z += 8;
	startPositions.push_back(startPos);

	startPos.z += 8;
	startPositions.push_back(startPos);

	vector<D3DXVECTOR3> attacksList;
	for (int i = 0; i < 5; i++)
	{
		D3DXVECTOR3 destPos = startPositions[i];
		destPos.x += 45;
		attacksList = CreateCycle(startPositions[i], destPos, 16, 8);
		CreateStorm(skillID, attacksList, GetPos(), idTarget, 1, 1000);
		attacksList.clear();
	}
}
void CMover::CreateKarvanAttack3(DWORD skillID, OBJID idTarget)
{
	//Find all nearby players in a radius and attack them.
	CObj* pObj;
	BOOL bApply = FALSE;
	D3DXVECTOR3 vPos = GetPos();
	int nRange = 24;
	float fRange = 24.0f;

	int attackSent = 0;

	vector<D3DXVECTOR3> attacksList;

	FOR_LINKMAP(GetWorld(), vPos, pObj, nRange, CObj::linkPlayer, GetLayer())
	{
		bApply = FALSE;
		if (IsValidObj(pObj) && pObj->GetType() == OT_MOVER)
		{
			if (attackSent < 10)
			{
				CMover* pTargetSplash = (CMover*)pObj;
				if (pTargetSplash->IsPlayer())
					bApply = TRUE;

				if (bApply && pObj->IsRangeObj(this, fRange))
				{
					if (pTargetSplash != this && pTargetSplash->IsLive())
					{
						D3DXVECTOR3 PlayerPos = pTargetSplash->GetPos();
						attacksList.clear();

						//Chase-y
						for (int i = 0; i < 5; i++)
							attacksList.push_back(PlayerPos);

						CreateStorm(skillID, attacksList, vPos, pTargetSplash->GetId(), 3, 500);
						attackSent++;
					}
				}
			}
		}
	}
	END_LINKMAP
}
void CMover::CreateKarvanAttack4(DWORD skillID, OBJID idTarget)
{
	vector< D3DXVECTOR3> positions;
	positions.push_back(D3DXVECTOR3(7453.0F, 100.0F, 6430.0F));
	positions.push_back(D3DXVECTOR3(7485.0F, 100.0F, 6479.0F));

	positions.push_back(D3DXVECTOR3(7479.0F, 100.0F, 6377.0F));
	positions.push_back(D3DXVECTOR3(7516.0F, 100.0F, 6420.0F));
	positions.push_back(D3DXVECTOR3(7552.0F, 100.0F, 6466.0F));

	positions.push_back(D3DXVECTOR3(7576.0F, 100.0F, 6434.0F));
	positions.push_back(D3DXVECTOR3(7543.0F, 100.0F, 6384.0F));

	auto rng = std::default_random_engine{};
	shuffle(positions.begin(), positions.end(), rng);

	CreateStorm(skillID, positions, GetPos(), idTarget, 1, 500);
}


void CMover::CreateClockworkAttack4(DWORD skillID, OBJID idTarget)
{
	int BaseSize = 18;
	int attackSize = 4; //Step Size

	D3DXVECTOR3 vPos = GetPos();
	D3DXVECTOR3 vPosTopRight = D3DXVECTOR3(vPos.x + BaseSize, 0, vPos.z + BaseSize);
	D3DXVECTOR3 vPosTopLeft = D3DXVECTOR3(vPos.x + BaseSize, 0, vPos.z - BaseSize);
	D3DXVECTOR3 vPosBottomRight = D3DXVECTOR3(vPos.x - BaseSize, 0, vPos.z + BaseSize);
	D3DXVECTOR3 vPosBottomLeft = D3DXVECTOR3(vPos.x - BaseSize, 0, vPos.z - BaseSize);


	vector<D3DXVECTOR3> attacksList;

	attacksList = CreateCycle(vPos, vPosTopRight, BaseSize, attackSize);
	CreateStorm(skillID, attacksList, vPos, idTarget, 1, 500);

	attacksList = CreateCycle(vPos, vPosBottomRight, BaseSize, attackSize);
	CreateStorm(skillID, attacksList, vPos, idTarget, 1, 500);

	attacksList = CreateCycle(vPos, vPosBottomLeft, BaseSize, attackSize);
	CreateStorm(skillID, attacksList, vPos, idTarget, 1, 500);

	attacksList = CreateCycle(vPos, vPosTopLeft, BaseSize, attackSize);
	CreateStorm(skillID, attacksList, vPos, idTarget, 1, 500);
}

//Attack on each Target.
void CMover::CreateClockworkAttack3(DWORD skillID, OBJID idTarget)
{
	//Find all nearby players in a radius and attack them.
	CObj* pObj;
	BOOL bApply = FALSE;
	D3DXVECTOR3 vPos = GetPos();
	int nRange = 24;
	float fRange = 24.0f;

	int attackSent = 0;

	vector<D3DXVECTOR3> attacksList;

	FOR_LINKMAP(GetWorld(), vPos, pObj, nRange, CObj::linkPlayer, GetLayer())
	{
		bApply = FALSE;
		if (IsValidObj(pObj) && pObj->GetType() == OT_MOVER)
		{
			if (attackSent < 15)
			{
				CMover* pTargetSplash = (CMover*)pObj;
				if (pTargetSplash->IsPlayer())
					bApply = TRUE;

				if (bApply && pObj->IsRangeObj(this, fRange))
				{
					if (pTargetSplash != this && pTargetSplash->IsLive())
					{
						D3DXVECTOR3 PlayerPos = pTargetSplash->GetPos();
						attacksList.clear();

						//Chase-y
						for (int i = 0; i < 5; i++)
							attacksList.push_back(PlayerPos);

						CreateStorm(skillID, attacksList, vPos, pTargetSplash->GetId(), 3, 500);
						attackSent++;
					}
				}
			}
		}
	}
	END_LINKMAP
}

//Center Block.
void CMover::CreateClockworkAttack2(DWORD skillID, OBJID idTarget)
{
	BOSSATTACK attack;
	attack.skillID = skillID;
	attack.randomizedDelay = false;

	int attackSize = 8;
	D3DXVECTOR3 vPos1 = GetPos();
	D3DXVECTOR3 vPos2 = GetPos();
	D3DXVECTOR3 vPos3 = GetPos();
	D3DXVECTOR3 vPos4 = GetPos();
	D3DXVECTOR3 vPos5 = GetPos();
	CustomBossAttack_CreateAttack(attack, vPos1);

	vPos2.x += attackSize;
	CustomBossAttack_CreateAttack(attack, vPos2);

	vPos3.x -= attackSize;
	CustomBossAttack_CreateAttack(attack, vPos3);

	vPos4.z -= attackSize;
	CustomBossAttack_CreateAttack(attack, vPos4);

	vPos5.z += attackSize;
	CustomBossAttack_CreateAttack(attack, vPos5);
}

//Around the Edges
void CMover::CreateClockworkAttack1(DWORD skillID, OBJID idTarget)
{
	int BaseSize = 19;
	int attackSize = 8; //Step Size

	D3DXVECTOR3 vPos = GetPos();
	D3DXVECTOR3 vPosTopRight = D3DXVECTOR3(vPos.x + BaseSize, 0, vPos.z + BaseSize);
	D3DXVECTOR3 vPosTopLeft = D3DXVECTOR3(vPos.x + BaseSize, 0, vPos.z - BaseSize);
	D3DXVECTOR3 vPosBottomRight = D3DXVECTOR3(vPos.x - BaseSize, 0, vPos.z + BaseSize);
	D3DXVECTOR3 vPosBottomLeft = D3DXVECTOR3(vPos.x - BaseSize, 0, vPos.z - BaseSize);


	vector<D3DXVECTOR3> attacksList;

	attacksList = CreateCycle(vPosTopLeft, vPosTopRight, BaseSize, attackSize);
	CreateStorm(skillID, attacksList, vPos, idTarget, 1, 500);

	attacksList = CreateCycle(vPosTopRight, vPosBottomRight, BaseSize, attackSize);
	CreateStorm(skillID, attacksList, vPos, idTarget, 1, 500);

	attacksList = CreateCycle(vPosBottomRight, vPosBottomLeft, BaseSize, attackSize);
	CreateStorm(skillID, attacksList, vPos, idTarget, 1, 500);

	attacksList = CreateCycle(vPosBottomLeft, vPosTopLeft, BaseSize, attackSize);
	CreateStorm(skillID, attacksList, vPos, idTarget, 1, 500);
}

void CMover::CreateStorm(DWORD skillID, vector<D3DXVECTOR3> attacks, D3DXVECTOR3& vPos, OBJID idTarget, int ver, int delay)
{
	//Get the skill that the storm does,
	ItemProp* pSkillProp;
	AddSkillProp* pAddSkillProp;
	GetSkillProp(&pSkillProp, &pAddSkillProp, skillID, 1, "CreateStorm");

	//Create the Bomb/Mine Type
	CContDamageCtrl_Custom* pDmgCtrl = new CContDamageCtrl_Custom;
	if (pDmgCtrl)
	{
		pDmgCtrl->m_pSkillProp = pSkillProp;
		pDmgCtrl->m_pAddSkillProp = pAddSkillProp;
		pDmgCtrl->m_idSrc = GetId();
		pDmgCtrl->m_idTarget = idTarget;
		pDmgCtrl->SetPos(vPos);
		pDmgCtrl->m_bControl = FALSE;
		pDmgCtrl->dwCustomType = TYPE_STORM; //4 = Storm Type.

		pDmgCtrl->storm_creationDelay = delay;
		pDmgCtrl->stormSize = 25;
		pDmgCtrl->followTarget = 0;
		pDmgCtrl->dwMineID = xRandom(4294967295);
		pDmgCtrl->attacksList = attacks;
		pDmgCtrl->cwAttackVer = ver;

		pDmgCtrl->bombTimer = 25000;
		pDmgCtrl->m_bDuelTarget = FALSE;

		GetWorld()->ADDOBJ(pDmgCtrl, FALSE, GetLayer());
	}
}

vector<D3DXVECTOR3> CMover::CreateCircle(D3DXVECTOR3 center, int radius, int amount)
{
	const double pi = 3.141592653;
	vector<D3DXVECTOR3> elements;
	for (int i = 0; i < amount; i++)
	{
		int xValue = radius * cos((i * 2 * pi) / amount);
		int yValue = radius * sin((i * 2 * pi) / amount);

		D3DXVECTOR3 pos = D3DXVECTOR3(center.x + xValue, center.y, center.z + yValue);
		elements.push_back(pos);
	}

	return elements;
}

vector<D3DXVECTOR3> CMover::CreateCycle(D3DXVECTOR3 start, D3DXVECTOR3 end, int distance, int step)
{
	vector<D3DXVECTOR3> attacks;
	attacks.clear();

	int amountOfSteps = ((distance * 2) / step) + 1;

	for (int i = 0; i < amountOfSteps; i++)
	{
		D3DXVECTOR3 newPos = start;
		if (start.x < end.x)
			newPos.x += step * i;
		else if (start.x > end.x)
			newPos.x -= step * i;
		if (start.z < end.z)
			newPos.z += step * i;
		else if (start.z > end.z)
			newPos.z -= step * i;

		attacks.push_back(newPos);
	}

	return attacks;
}

void	CMover::OnAttackMelee_CustomBoss1(BOSSMECHANICS mechanics, CMover* pHitObj)
{
	BOSSATTACK nextAttack;

	//Select the next attack.
	if (mechanics.randomized)
	{
		nextAttack = mechanics.attacks[m_dwAttackCount];
		m_dwAttackCount++;

		//Reset
		if (m_dwAttackCount == mechanics.attacks.size())
			m_dwAttackCount = 0;
	}
	else
	{
		int randomNumber = xRandom(10000);
		if (randomNumber > 1)
		{
			int randomIndex = xRandom(0, mechanics.attacks.size());
			nextAttack = mechanics.attacks[randomIndex];
		}
	}

	D3DXVECTOR3 attackPos;
	DWORD attackerID;

	bool skip = false;
	float radius = 1.0f;
	switch (nextAttack.HitType)
	{
	case BOSSATK_HITSELF:
		attackPos = GetPos();
		attackerID = GetId();
		radius = GetRadius() / 2;
		break;
	case BOSSATK_HITTARGET:
		attackPos = pHitObj->GetPos();
		attackerID = pHitObj->GetId();
		radius = pHitObj->GetRadius() / 2;
		break;
	case BOSSATK_HITTYPE_ALL:
		skip = true;
		//Find all nearby players in a radius and attack them.
		CObj* pObj;
		BOOL bApply = FALSE;
		D3DXVECTOR3 vPos = GetPos();
		int nRange = 16;
		float fRange = 16.0f;

		FOR_LINKMAP(GetWorld(), vPos, pObj, nRange, CObj::linkPlayer, GetLayer())
		{
			bApply = FALSE;
			if (IsValidObj(pObj) && pObj->GetType() == OT_MOVER)
			{
				CMover* pTargetSplash = (CMover*)pObj;
				if (pTargetSplash->IsPlayer())
					bApply = TRUE;

				if (bApply && pObj->IsRangeObj(this, fRange))
				{
					if (pTargetSplash != this && pTargetSplash->IsLive())
					{
						//Apply Attack
						switch (nextAttack.AttackType)
						{
						case ATTACK_AROUNDSELF:
							CustomBossAttack_SelfAttack(nextAttack, pTargetSplash->GetPos(), pTargetSplash->GetRadius() / 2);
							break;
						case ATTACK_LINE:
							CustomBossAttack_LineAttack(nextAttack, TRUE, pTargetSplash->GetPos(), pTargetSplash->GetRadius() / 2);
							break;
						case ATTACK_TRIANGLE:
							CustomBossAttack_TriangleAttack(nextAttack, pTargetSplash->GetPos(), pTargetSplash->GetRadius() / 2);
							break;
						case ATTACK_SQUARE:
							CustomBossAttack_SquareAttack(nextAttack, pTargetSplash->GetPos(), pTargetSplash->GetRadius() / 2);
							break;
						case ATTACK_RANDOM:
							CustomBossAttack_RandomAttack(nextAttack, pTargetSplash->GetPos(), pTargetSplash->GetRadius() / 2);
							break;
						case ATTACK_TARGET:
							CustomBossAttack_Targetted(nextAttack, pTargetSplash->GetPos());
							break;
						case ATTACK_CROSS:
							CustomBossAttack_LineAttack(nextAttack, FALSE, pTargetSplash->GetPos(), pTargetSplash->GetRadius() / 2);
							break;
						case ATTACK_STORM:
							CustomBossAttack_CreateAttackStorm(nextAttack, pTargetSplash->GetPos(), pTargetSplash->GetId());
							break;
						case ATTACK_CORNER:
							CustomBossAttack_CornerAttack(nextAttack, pTargetSplash->GetPos(), pTargetSplash->GetRadius() / 2);
							break;
						case ATTACK_CIRCLE1:
							CustomBossAttack_CircleAttack(nextAttack, pTargetSplash->GetPos(), pTargetSplash->GetRadius() / 2, 1);
							break;
						case ATTACK_CIRCLE2:
							CustomBossAttack_CircleAttack(nextAttack, pTargetSplash->GetPos(), pTargetSplash->GetRadius() / 2, 2);
							break;
						case ATTACK_CIRCLE3:
							CustomBossAttack_CircleAttack(nextAttack, pTargetSplash->GetPos(), pTargetSplash->GetRadius() / 2, 3);
							break;
						}
					}
				}
			}
		}
		END_LINKMAP
			break;
	}

	if (!skip)
	{
		switch (nextAttack.AttackType)
		{
		case ATTACK_AROUNDSELF:
			CustomBossAttack_SelfAttack(nextAttack, attackPos, radius);
			break;
		case ATTACK_LINE:
			CustomBossAttack_LineAttack(nextAttack, TRUE, attackPos, radius);
			break;
		case ATTACK_TRIANGLE:
			CustomBossAttack_TriangleAttack(nextAttack, attackPos, radius);
			break;
		case ATTACK_SQUARE:
			CustomBossAttack_SquareAttack(nextAttack, attackPos, radius);
			break;
		case ATTACK_RANDOM:
			CustomBossAttack_RandomAttack(nextAttack, attackPos, radius);
			break;
		case ATTACK_TARGET:
			CustomBossAttack_Targetted(nextAttack, attackPos);
			break;
		case ATTACK_CROSS:
			CustomBossAttack_LineAttack(nextAttack, FALSE, attackPos, radius);
			break;
		case ATTACK_STORM:
			CustomBossAttack_CreateAttackStorm(nextAttack, attackPos, attackerID);
			break;
		case ATTACK_CORNER:
			CustomBossAttack_CornerAttack(nextAttack, attackPos, radius);
			break;
		case ATTACK_CIRCLE1:
			CustomBossAttack_CircleAttack(nextAttack, attackPos, radius, 1);
			break;
		case ATTACK_CIRCLE2:
			CustomBossAttack_CircleAttack(nextAttack, attackPos, radius, 2);
			break;
		case ATTACK_CIRCLE3:
			CustomBossAttack_CircleAttack(nextAttack, attackPos, radius, 3);
			break;
		default:
			return;
		}
	}
}
//Creates 3 Attacks close around the given position.
void	CMover::CustomBossAttack_SelfAttack(BOSSATTACK attack, D3DXVECTOR3& center, float radius)
{
	//Get the skill
	ItemProp* pSkillProp;
	AddSkillProp* pAddSkillProp;
	BOOL bSuccess = GetSkillProp(&pSkillProp, &pAddSkillProp, attack.skillID, 1, "CustomBossAttack_CreateAttack");

	int range = 0;
	if (radius > pAddSkillProp->dwSkillRange)
		range = radius;
	else
		range = pAddSkillProp->dwSkillRange;

	D3DXVECTOR3 myPos = center;

	D3DXVECTOR3 vPos1 = myPos;
	vPos1.z -= range;

	D3DXVECTOR3 vPos2 = myPos;
	vPos2.z += range;
	vPos2.x += range;

	D3DXVECTOR3 vPos3 = myPos;
	vPos3.z += range;
	vPos3.x -= range;

	CustomBossAttack_CreateAttack(attack, vPos1);
	CustomBossAttack_CreateAttack(attack, vPos2);
	CustomBossAttack_CreateAttack(attack, vPos3);
}
//Creates line based attacks that can either be 1 up to 4 lines outwards of the monster.
//Amount of attacks is always 4.
//If isRandom is False. The attack is a 'cross style' attack where all 4 lines are active.
void	CMover::CustomBossAttack_LineAttack(BOSSATTACK attack, bool isRandom, D3DXVECTOR3& center, float radius)
{
	//Get the skill
	ItemProp* pSkillProp;
	AddSkillProp* pAddSkillProp;
	BOOL bSuccess = GetSkillProp(&pSkillProp, &pAddSkillProp, attack.skillID, 1, "CustomBossAttack_CreateAttack");

	D3DXVECTOR3 monsterPos = center;

	int amountOfAttacks = 4;

	BOOL xAxis = xRandom(1000) > 500;
	BOOL zAxis = xRandom(1000) > 500;

	BOOL xBackward = xRandom(1000) > 500;
	BOOL zBackward = xRandom(1000) > 500;

	if (!xAxis && !zAxis)
		xAxis = TRUE;

	if (!isRandom)
	{
		xAxis = TRUE;
		zAxis = TRUE;
		xBackward = TRUE;
		zBackward = TRUE;
	}

	vector<D3DXVECTOR3> positions;
	int rangeFirst = pAddSkillProp->dwSkillRange + (pAddSkillProp->dwSkillRange / 2);

	int range = 0;
	if (radius > rangeFirst)
		range = radius;
	else
		range = rangeFirst;

	if (xAxis)
	{
		for (int i = 0; i < amountOfAttacks; i++)
		{
			D3DXVECTOR3 vPos = monsterPos;
			vPos.x += (range * i);
			positions.push_back(vPos);
		}

		if (attack.ApplyType == APPLY_STEP)
		{
			CreateStorm(attack.skillID, positions, center, GetId(), 1, 250);
			positions.clear();
		}

		if (xBackward)
		{
			for (int i = 0; i < amountOfAttacks; i++)
			{
				D3DXVECTOR3 vPos = monsterPos;
				vPos.x -= (range * i);
				positions.push_back(vPos);
			}

			if (attack.ApplyType == APPLY_STEP)
			{
				CreateStorm(attack.skillID, positions, center, GetId(), 1, 250);
				positions.clear();
			}
		}
	}

	if (zAxis)
	{
		for (int i = 0; i < amountOfAttacks; i++)
		{
			D3DXVECTOR3 vPos = monsterPos;
			vPos.z += (range * i);
			positions.push_back(vPos);
		}

		if (attack.ApplyType == APPLY_STEP)
		{
			CreateStorm(attack.skillID, positions, center, GetId(), 1, 250);
			positions.clear();
		}

		if (zBackward)
		{
			for (int i = 0; i < amountOfAttacks; i++)
			{
				D3DXVECTOR3 vPos = monsterPos;
				vPos.z -= (range * i);
				positions.push_back(vPos);
			}

			if (attack.ApplyType == APPLY_STEP)
			{
				CreateStorm(attack.skillID, positions, center, GetId(), 1, 250);
				positions.clear();
			}
		}
	}

	if (attack.ApplyType == APPLY_INSTANT)
	{
		for (int i = 0; i < positions.size(); i++)
			CustomBossAttack_CreateAttack(attack, positions[i]);
	}
}

void	CMover::CustomBossAttack_CircleAttack(BOSSATTACK attack, D3DXVECTOR3& center, float mobRadius, int waves)
{
	//Get the skill
	ItemProp* pSkillProp;
	AddSkillProp* pAddSkillProp;
	BOOL bSuccess = GetSkillProp(&pSkillProp, &pAddSkillProp, attack.skillID, 1, "CustomBossAttack_CreateAttack");

	for (int wave = 1; wave < (waves + 1); wave++)
	{
		if (mobRadius < 3)
			mobRadius = 2;

		int range = mobRadius + (pAddSkillProp->dwSkillRange * 2);
		int waveBonus = 1 + (pAddSkillProp->dwSkillRange * 1.5f) * (wave - 1);

		if (wave > 1)
			range = range + waveBonus;

		int amount = 10;

		if (wave == 2)
			amount += 5;
		if (wave == 3)
			amount += 10;

		vector< D3DXVECTOR3> attacks = CreateCircle(center, (int)range, amount);

		for (int i = 0; i < attacks.size(); i++)
		{
			int delay = 100 + (i * 100);

			if (wave == 2)
				delay += 2000;
			if (wave == 3)
				delay += 4000;

			if (attack.randomizedDelay == FALSE)
			{
				delay = 0;
				if (wave == 2)
					delay += 500;
				if (wave == 3)
					delay += 1000;
			}

			if (attack.ApplyType == APPLY_INSTANT)
				CustomBossAttack_CreateAttack(attack, attacks[i], delay);
		}

		if (attack.ApplyType == APPLY_STEP)
			CreateStorm(attack.skillID, attacks, center, GetId(), 1, (100 * wave));
	}
}

//Creates randomly 1-3 crystals in a corner radius.
void	CMover::CustomBossAttack_CornerAttack(BOSSATTACK attack, D3DXVECTOR3& center, float mobRadius)
{
	int amount = xRandom(1, 4);
	int radius = 5 + mobRadius;

	if (amount < 1)
		amount = 1;

	D3DXVECTOR3 vPosLeft = center;
	vPosLeft.z += radius;
	vPosLeft.x += radius;

	D3DXVECTOR3 vPosRight = center;
	vPosRight.z += radius;
	vPosRight.x -= radius;

	D3DXVECTOR3 vPosTop = center;
	vPosTop.z -= radius;

	if (amount > 0)
		CustomBossAttack_CreateAttack(attack, vPosTop, 0);
	if (amount > 1)
		CustomBossAttack_CreateAttack(attack, vPosLeft, 0);
	if (amount > 2)
		CustomBossAttack_CreateAttack(attack, vPosRight, 0);
}

//Creates a Triangle/Pyramid shaped attack with 6 Attacks.
void	CMover::CustomBossAttack_TriangleAttack(BOSSATTACK attack, D3DXVECTOR3& center, float mobRadius)
{
	//Get the skill
	ItemProp* pSkillProp;
	AddSkillProp* pAddSkillProp;
	BOOL bSuccess = GetSkillProp(&pSkillProp, &pAddSkillProp, attack.skillID, 1, "CustomBossAttack_CreateAttack");

	int skillRange = 0;
	if (mobRadius > pAddSkillProp->dwSkillRange)
		skillRange = mobRadius;
	else
		skillRange = pAddSkillProp->dwSkillRange;

	D3DXVECTOR3 vPosTop = center;
	vPosTop.z -= skillRange * 2;
	D3DXVECTOR3 vPosLeft = center;
	vPosLeft.z += skillRange * 2;
	vPosLeft.x += skillRange * 2;
	D3DXVECTOR3 vPosRight = center;
	vPosRight.z += skillRange * 2;
	vPosRight.x -= skillRange * 2;
	D3DXVECTOR3 vPosTop2 = center;
	vPosTop2.x -= skillRange * 1;
	D3DXVECTOR3 vPosLeft2 = center;
	vPosLeft2.x += skillRange * 1;
	D3DXVECTOR3 vPosRight2 = center;
	vPosRight2.z += skillRange * 2;

	if (attack.ApplyType == APPLY_STEP)
	{
		vector<D3DXVECTOR3> positions;

		positions.push_back(vPosTop);
		positions.push_back(vPosTop2);
		positions.push_back(vPosLeft);
		positions.push_back(vPosLeft2);
		positions.push_back(vPosRight);
		positions.push_back(vPosRight2);

		CreateStorm(attack.skillID, positions, center, GetId(), 1, 125);
	}
	else
	{
		CustomBossAttack_CreateAttack(attack, vPosTop, 0);
		CustomBossAttack_CreateAttack(attack, vPosTop2, 250);

		CustomBossAttack_CreateAttack(attack, vPosLeft, 0);
		CustomBossAttack_CreateAttack(attack, vPosLeft2, 250);

		CustomBossAttack_CreateAttack(attack, vPosRight, 0);
		CustomBossAttack_CreateAttack(attack, vPosRight2, 250);
	}
}
//Creates 9 Attacks in a Square shaped pattern.
void	CMover::CustomBossAttack_SquareAttack(BOSSATTACK attack, D3DXVECTOR3& center, float mobRadius)
{
	//Get the skill
	ItemProp* pSkillProp;
	AddSkillProp* pAddSkillProp;
	BOOL bSuccess = GetSkillProp(&pSkillProp, &pAddSkillProp, attack.skillID, 1, "CustomBossAttack_CreateAttack");

	int skillRange = 0;
	if (mobRadius > pAddSkillProp->dwSkillRange * 2)
		skillRange = mobRadius;
	else
		skillRange = pAddSkillProp->dwSkillRange * 2;

	int rows = 3;
	for (int i = 0; i < rows; i++)
	{
		D3DXVECTOR3 vPosLeft = center;
		D3DXVECTOR3 vPosMiddle = center;
		D3DXVECTOR3 vPosRight = center;

		//Left Right movement
		vPosLeft.x -= skillRange;
		vPosRight.x += skillRange;

		//Top Bottom movement
		if (i == 0)
		{
			vPosLeft.z += skillRange;
			vPosMiddle.z += skillRange;
			vPosRight.z += skillRange;
		}
		if (i == 2)
		{
			vPosLeft.z -= skillRange;
			vPosMiddle.z -= skillRange;
			vPosRight.z -= skillRange;
		}
		if (attack.ApplyType == APPLY_STEP)
		{
			vector<D3DXVECTOR3> positions;

			positions.push_back(vPosLeft);
			positions.push_back(vPosMiddle);
			positions.push_back(vPosRight);

			CreateStorm(attack.skillID, positions, center, GetId(), 1, 250);
		}
		else
		{
			//Create the row
			CustomBossAttack_CreateAttack(attack, vPosLeft, i * 250);
			CustomBossAttack_CreateAttack(attack, vPosMiddle, i * 250);
			CustomBossAttack_CreateAttack(attack, vPosRight, i * 250);
		}
	}
}

//Creates semi-random attacks around the given location.
//The range of the radius is randomized and the amount of attacks is randomized between 5-15.
void	CMover::CustomBossAttack_RandomAttack(BOSSATTACK attack, D3DXVECTOR3& center, float mobRadius)
{
	//Get the skill
	ItemProp* pSkillProp;
	AddSkillProp* pAddSkillProp;
	BOOL bSuccess = GetSkillProp(&pSkillProp, &pAddSkillProp, attack.skillID, 1, "CustomBossAttack_CreateAttack");
	int skillRange = 0;
	if (mobRadius > pAddSkillProp->dwSkillRange)
		skillRange = mobRadius;
	else
		skillRange = pAddSkillProp->dwSkillRange;

	int amountOfAttacks = xRandom(5, 10);
	vector<D3DXVECTOR3> positions;
	for (int i = 0; i < amountOfAttacks; i++)
	{
		D3DXVECTOR3 vPos = center;
		int randomizedRange = xRandom(0, skillRange * 1.5f) + xRandom(2, 6);

		if (xRandom(1000) > 500)
			vPos.x += randomizedRange;
		else
			vPos.x -= randomizedRange;

		if (xRandom(2000) > 1000)
		{
			if (xRandom(3000) > 1500)
				vPos.z += randomizedRange;
			else
				vPos.z -= randomizedRange;
		}
		if (attack.ApplyType == APPLY_INSTANT)
			CustomBossAttack_CreateAttack(attack, vPos);
		else
			positions.push_back(vPos);
	}

	if (attack.ApplyType == APPLY_STEP)
		CreateStorm(attack.skillID, positions, center, GetId(), 1, 125);
}

//Creates attacks directly on top of x
void	CMover::CustomBossAttack_Targetted(BOSSATTACK attack, D3DXVECTOR3& center)
{
	CustomBossAttack_CreateAttack(attack, center);
}

//Creates a single attack and sends creation SFX.
//The Custom Delay property can be used to either disable the 'randomizer' in delays
//Or to create like a Wave-like attack pattern where attacks land after certain delays.
//However attacks are always PLACED at the same time. this only affects the damage-landing.
void	CMover::CustomBossAttack_CreateAttack(BOSSATTACK attack, D3DXVECTOR3& vPos, int customDelay)
{
#ifdef __MINES_BOMBS
	//Get the skill
	ItemProp* pSkillProp;
	AddSkillProp* pAddSkillProp;
	BOOL bSuccess = GetSkillProp(&pSkillProp, &pAddSkillProp, attack.skillID, 1, "CustomBossAttack_CreateAttack");

	//Create the Bomb/Mine Type
	vPos.y = GetPos().y;

	CContDamageCtrl_Custom* pDmgCtrl = new CContDamageCtrl_Custom;	// Áö¼Óµ¥¹ÌÁö¸¦ ÁÖ´Â °¡»ó¿ÀºêÁ§Æ® »ý¼º - ¸Þ¸ð¸®Ç®¸µ Ã³¸® ÇÒ°Í
	if (pDmgCtrl)
	{
		pDmgCtrl->m_pSkillProp = pSkillProp;
		pDmgCtrl->m_pAddSkillProp = pAddSkillProp;
		pDmgCtrl->m_idSrc = GetId();
		pDmgCtrl->m_idTarget = GetId();
		pDmgCtrl->SetPos(vPos);
		pDmgCtrl->m_bControl = FALSE;
		pDmgCtrl->dwCustomType = pAddSkillProp->dwBombMine; //1 = bomb, 2 = mine.
		pDmgCtrl->dwMineID = xRandom(4294967295);

		//Bomb timers are slightly random. So if we define 3 seconds. it will be anywhere between 3-4 seconds.
		DWORD timerVariance = xRandom(1000);

		if (attack.randomizedDelay == false)
			timerVariance = 0;

		if (customDelay > -1)
			timerVariance = customDelay;

		DWORD bombTimer = pAddSkillProp->dwBombExplodeTimer + timerVariance;

		pDmgCtrl->bombTimer = bombTimer;
		pDmgCtrl->m_bDuelTarget = FALSE;

		GetWorld()->ADDOBJ(pDmgCtrl, FALSE, GetLayer());

		if (pSkillProp->dwSfxObj3 != NULL_ID)
		{
			//Create the Bomb Sfx
			g_UserMng.AddWorldCreateSfxObj(pSkillProp->dwSfxObj3, vPos.x, vPos.y, vPos.z, FALSE, GetWorld()->GetID(), bombTimer + 1000, pDmgCtrl->dwMineID, GetLayer());
		}
	}

#endif //__MINES_BOMBS
}

//skillID = the skill the storm creates. Storms itself dont need a skill.
void	CMover::CustomBossAttack_CreateAttackStorm(BOSSATTACK attack, D3DXVECTOR3& vPos, OBJID idTarget)
{
#ifdef __MINES_BOMBS
	//Get the skill of the storm
	ItemProp* pSkillPropStorm;
	AddSkillProp* pAddSkillPropStorm;
	BOOL bSuccess = GetSkillProp(&pSkillPropStorm, &pAddSkillPropStorm, attack.skillID, 1, "CustomBossAttack_CreateAttackStorm");

	//Get the skill that the storm does,
	ItemProp* pSkillProp;
	AddSkillProp* pAddSkillProp;
	GetSkillProp(&pSkillProp, &pAddSkillProp, attack.stormSkillID, 1, "CustomBossAttack_CreateAttackStorm");

	//Create the Bomb/Mine Type
	CContDamageCtrl_Custom* pDmgCtrl = new CContDamageCtrl_Custom;
	if (pDmgCtrl)
	{
		pDmgCtrl->m_pSkillProp = pSkillProp;
		pDmgCtrl->m_pAddSkillProp = pAddSkillProp;
		pDmgCtrl->m_idSrc = GetId();
		pDmgCtrl->m_idTarget = idTarget;
		pDmgCtrl->SetPos(vPos);
		pDmgCtrl->m_bControl = FALSE;
		pDmgCtrl->dwCustomType = pAddSkillPropStorm->dwBombMine; //4 = Storm Type.
		pDmgCtrl->storm_creationDelay = pAddSkillPropStorm->dwPainTime;
		pDmgCtrl->stormSize = pAddSkillPropStorm->dwSkillRange;
		pDmgCtrl->followTarget = pAddSkillPropStorm->nDestData1[0] == 1;
		pDmgCtrl->dwMineID = xRandom(4294967295);

		pDmgCtrl->bombTimer = pAddSkillPropStorm->dwSkillTime;
		pDmgCtrl->m_bDuelTarget = FALSE;

		GetWorld()->ADDOBJ(pDmgCtrl, FALSE, GetLayer());

		//g_DPCoreClient.SendCaption( "Behold the Storm", GetWorld()->GetID(), FALSE, GetLayer() );	
	}
#endif //__MINES_BOMBS
}
#endif //__NEW_BOSSMECHANICS
#endif //__WORLDSERVER

void	CMover::OnAttackMelee_BigMuscle( DWORD dwState, CMover *pHitObj )
{
	int		nItemID = GetActParam( 1 );	// »ç¿ëÇÒ ¾ÆÀÌÅÛ ¾ÆÀÌµð
	CModelObject *pModel = (CModelObject *)m_pModel;
	
#ifdef __WORLDSERVER
	UpdateMatrix();		// ¸öÃ¼ÀÇ Æ¯Á¤ºÎÀ§¿¡¼­ ³ª´Â µ¥¹ÌÁö¸¦ Ã³¸®ÇÏ±â À§ÇØ¼± ¼­¹ö¿¡¼­µµ ¸ÅÆ®¸¯½º¸¦ °»½ÅÇØ¾ßÇÑ´Ù.
	pModel->UpdateMatrixBone();		// ¼­¹ö¿¡¼­´Â º»¾Ö´Ï¸ÞÀÌ¼ÇÀ» ÇÏÁö ¾ÊÀ¸¹Ç·Î GetEventPos()¸¦ »ç¿ëÇÒ ÀÏÀÌ ÀÖÀ»¶© ¾÷µ¥ÀÌÆ®¸¦ ÇØÁà¾ß ÇÑ´Ù.
#endif // WorldServer
	
	switch( dwState )
	{
	case OBJSTA_ATK1:	
	case OBJSTA_ATK2:
		{
			if( IsValidObj(pHitObj) )
			{
				OnDamage( nItemID, dwState, pHitObj );		
			}
		}
		break;
	case OBJSTA_ATK3:		// ¶¥Ä¡±â ½ºÅ³ - µÎ¼Õ
		{
			D3DXMATRIX mMatrix;
			
			D3DXMatrixMultiply( &mMatrix, (pModel->GetMatrixBone(12)), &(GetMatrixWorld()) );
			
			D3DXVECTOR3 v2;
			v2.x = mMatrix._41;
			v2.y = mMatrix._42;
			v2.z = mMatrix._43;
			v2.y -= 5.0f;
			
		#ifdef __CLIENT
			// ¶¥Ä¡°í ³¡³¯¶§ ÀÌÆåÆ® ¿Þ¼Õ
			CSfx *pSfx = CreateSfx( D3DDEVICE, XI_SKILL_CIRCLE_DUST, v2 );			
			if( pSfx )
				pSfx->SetScale( D3DXVECTOR3( 12.0f, 12.0f, 12.0f ) );

			PLAYSND( SND_PC_SKILLD_HITOFPENYA );//, &v2 );
		#endif //__CLIENT 			
			
			D3DXMatrixMultiply( &mMatrix, (pModel->GetMatrixBone(16)), &(GetMatrixWorld()) );
			D3DXVECTOR3 v3;
			v3.x = mMatrix._41;
			v3.y = mMatrix._42;
			v3.z = mMatrix._43;						
			v3.y -= 5.0f;
			
		#ifdef __CLIENT
			// ¶¥Ä¡°í ³¡³¯¶§ ÀÌÆåÆ® ¿À¸¥¼Õ
			pSfx = CreateSfx( D3DDEVICE, XI_SKILL_CIRCLE_DUST, v3 );			
			if( pSfx )
				pSfx->SetScale( D3DXVECTOR3( 12.0f, 12.0f, 12.0f ) );
		#endif //__CLIENT 			
		
			if( m_pActMover->m_nMotionHitCount == 1 )
			{				
	#ifdef __WORLDSERVER
				GetWorld()->SendDamageAround( &GetPos(), (AF_GENERIC | AF_CRITICAL) , this, OBJTYPE_PLAYER, II_WEA_MOB_MONSTER4_ATK2
					, 16.0f );					

				ItemProp *pSkillProp;
				AddSkillProp *pAddSkillProp;
				BOOL bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_GEN_BLEEDING, 10, "OnAttackMelee_BigMuscle" );
				if( bSuccess )
					ApplySkillAround( this, OBJTYPE_PLAYER, pSkillProp, pAddSkillProp , false );							
	#endif //__WORLDSERVER
				
			}
			else
			{
	#ifdef __CLIENT
				PLAYSND( SND_PC_BOSS_STUN );
	#endif //__CLIENT
	#ifdef __WORLDSERVER				
				ItemProp *pSkillProp;
				AddSkillProp *pAddSkillProp;
				BOOL bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_BIGMUSCLE_STUNGROUP, 1, "OnAttackMelee_BigMuscle" );
				if( bSuccess )
					ApplySkillAround( this, OBJTYPE_PLAYER, pSkillProp, pAddSkillProp , false );							
	#endif //__WORLDSERVER
			}
		}
		break;
	case OBJSTA_ATK4:   // ¶¥Ä¡±â ½ºÅ³ - ÇÑ¼Õ
		{
			static D3DXVECTOR3 v3OldPos;

			if( m_pActMover->m_nMotionHitCount == 0 )
			{
				v3OldPos = pHitObj->GetPos();			
			}
			else
			if( m_pActMover->m_nMotionHitCount == 1 )
			{
				D3DXMATRIX mMatrix;
				
				D3DXMatrixMultiply( &mMatrix, (pModel->GetMatrixBone(12)), &(GetMatrixWorld()) );
				
				D3DXVECTOR3 v2;
				v2.x = mMatrix._41;
				v2.y = mMatrix._42;
				v2.z = mMatrix._43;
				v2.y -= 5.0f;
				
			#ifdef __CLIENT
				// ¶¥Ä¡°í ³¡³¯¶§ ÀÌÆåÆ® ¿Þ¼Õ
				CSfx *pSfx = CreateSfx( D3DDEVICE, XI_SKILL_CIRCLE_DUST, v2 );
				if( pSfx )
					pSfx->SetScale( D3DXVECTOR3( 9.0f, 9.0f, 9.0f ) );
				
				pSfx = CreateSfx( D3DDEVICE, XI_SKILL_MAG_EARTH_ROCKCRASH01, v3OldPos );
				if( pSfx )
					pSfx->SetScale( D3DXVECTOR3( 2.0f, 2.0f, 2.0f ) );
				
				PLAYSND( SND_PC_SKILLD_HITOFPENYA );
			#endif //__CLIENT

			#ifdef __WORLDSERVER
				ItemProp *pSkillProp;
				AddSkillProp *pAddSkillProp;
				BOOL bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_GEN_BLEEDING, 10, "OnAttackMelee_BigMuscle" );
				if( bSuccess )
					DoApplySkill( pHitObj, pSkillProp, pAddSkillProp );	
				
				GetWorld()->SendDamageAround( &(v3OldPos), AF_GENERIC | AF_CRITICAL , this, OBJTYPE_PLAYER, II_WEA_MOB_MONSTER4_ATK2
					, 4.0f );	
			#endif //__WORLDSERVER
				
					
			}
		}
		
		break;
	}
}

void	CMover::OnAttackMelee_Krrr( DWORD dwState, CMover *pHitObj )
{
	int		nItemID = GetActParam( 1 );	// »ç¿ëÇÒ ¾ÆÀÌÅÛ ¾ÆÀÌµð

	CModelObject *pModel = (CModelObject *)m_pModel;
	
#ifdef __WORLDSERVER
	UpdateMatrix();		// ¸öÃ¼ÀÇ Æ¯Á¤ºÎÀ§¿¡¼­ ³ª´Â µ¥¹ÌÁö¸¦ Ã³¸®ÇÏ±â À§ÇØ¼± ¼­¹ö¿¡¼­µµ ¸ÅÆ®¸¯½º¸¦ °»½ÅÇØ¾ßÇÑ´Ù.
	pModel->UpdateMatrixBone();		// ¼­¹ö¿¡¼­´Â º»¾Ö´Ï¸ÞÀÌ¼ÇÀ» ÇÏÁö ¾ÊÀ¸¹Ç·Î GetEventPos()¸¦ »ç¿ëÇÒ ÀÏÀÌ ÀÖÀ»¶© ¾÷µ¥ÀÌÆ®¸¦ ÇØÁà¾ß ÇÑ´Ù.
#endif // WorldServer
	
	switch( dwState )
	{
	case OBJSTA_ATK1:	
		{
	#ifdef __WORLDSERVER			
			OnDamage( nItemID, dwState, pHitObj );		
	#endif //__WORLDSERVER			
		}
		break;
	case OBJSTA_ATK2:	
		{
	#ifdef __WORLDSERVER
			int nRandom = xRandom(100);
			if( nRandom <= 50 )
			{
				ItemProp *pSkillProp;
				AddSkillProp *pAddSkillProp;
				BOOL bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_KRRR_POISON, 1, "OnSfxHit" );
				if( bSuccess )
				{
					pHitObj->ApplySkill( this, pSkillProp, pAddSkillProp );
				}
			}
			else
			{
				OnDamage( nItemID, dwState, pHitObj );		
			}
	#endif // WorldServer
		}
		break;
	case OBJSTA_ATK3:		// µÎ¼ÕÀ¸·Î µµ³¢ ³»·ÁÄ¡±â
		{
		#ifdef __CLIENT
			CSfx *pSfx = CreateSfx( D3DDEVICE, XI_NPCSP1DIRFIRESP, pHitObj->GetPos() );	// ÀÌÆåÆ®¸¦ ¹ß»ý - ¼­¹ö¿¡¼± »ý¼º ¾ÈµÊ.
			if( pSfx )
				pSfx->SetAngle( -GetAngle() );

			PLAYSND( SND_PC_BOSS_CRASH, &pHitObj->GetPos() );
		#endif //__CLIENT

		#ifdef __WORLDSERVER
			ItemProp *pSkillProp;
			AddSkillProp *pAddSkillProp;
			BOOL bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_GEN_KNOCK_BACK, 4, "OnAttackMelee_BigMuscle" );
			if( bSuccess )
				ApplySkillAround( this, OBJTYPE_PLAYER, pSkillProp, pAddSkillProp , false );							

			GetWorld()->SendDamageAround( &(pHitObj->GetPos()), AF_GENERIC, this, OBJTYPE_PLAYER, II_WEA_MOB_MONSTER4_ATK1
				, 7.0f );	
		#endif //__WORLDSERVER
		}
		break;
	case OBJSTA_ATK4:		// ÁÖ¹®À» ¿Ü¿ì°í ÇÃ·¹ÀÌ¾îµé ÇÑ°÷¿¡ ¸ðÀÎÈÄ ±¤¿ªµ¥¹ÌÁö ÁÜ
		{
			static D3DXVECTOR3	  vLocal;
			if( m_pActMover->m_nMotionHitCount == 0 )
			{
		#ifdef __CLIENT
				PLAYSND( SND_PC_BOSS_SUMMONS );
		#endif //__CLIENT
				
				AngleToVectorXZ( &vLocal, GetAngle(), 5.0f );	// ¶§¸®´Â¹æÇâ 5¹ÌÅÍ¾Õ.
				vLocal += GetPos();

				FLOAT fHeight = GetWorld()->GetLandHeight( vLocal.x, vLocal.z );
				vLocal.y = fHeight;
				
		#ifdef __WORLDSERVER
				CPartyQuestProcessor* pProc	= CPartyQuestProcessor::GetInstance();
				CWorld* pWorld	= GetWorld();
				if( pWorld )
				{
					int nId	= pProc->PtInQuestRect( pWorld->GetID(), GetPos() );
					if( nId > -1 )
					{
						PPARTYQUESTELEM pElem	= pProc->GetPartyQuest( nId );
						PPARTYQUESTRECT pRect	= pProc->GetPartyQuestRect( nId );
						if( pElem && pRect )
#ifdef __LAYER_1015
							g_UserMng.ReplaceWorldArea( pElem->idParty, pRect->dwWorldId, pRect->dwWorldId, vLocal.x, vLocal.z, 0.5f, TRUE, GetLayer() );
#else	// __LAYER_1015
							g_UserMng.ReplaceWorldArea( pElem->idParty, pRect->dwWorldId, pRect->dwWorldId, vLocal.x, vLocal.z, 0.5f, TRUE );
#endif	// __LAYER_1015
					}
				}
		#endif //__WORLDSERVER
			}
			else
			if( m_pActMover->m_nMotionHitCount == 1 )		// ¾à 5ÃÊÈÄ¿¡ ½ºÅÏ
			{	
		#ifdef __CLIENT
				PLAYSND( SND_PC_BOSS_STUN );
		#endif //__CLIENT
#ifdef __WORLDSERVER
				ItemProp *pSkillProp;
				AddSkillProp *pAddSkillProp;
				BOOL bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_KRRR_STUNGROUP, 1, "OnAttackMelee_Krrr" );
				if( bSuccess )
					ApplySkillAround( this, OBJTYPE_PLAYER, pSkillProp, pAddSkillProp , false );	
#endif //__WORLDSERVER
				
			}
			else
			if( m_pActMover->m_nMotionHitCount == 2 )
			{	
#ifdef __CLIENT
				D3DXVECTOR3 v3Pos = vLocal;
				CSfx *pSfx = CreateSfx( D3DDEVICE, XI_SKILL_ELE_MULTI_METEOSHOWER02, v3Pos );	// ÀÌÆåÆ®¸¦ ¹ß»ý - ¼­¹ö¿¡¼± »ý¼º ¾ÈµÊ.
				if( pSfx )
					pSfx->SetScale( D3DXVECTOR3( 0.8f, 0.8f, 0.8f ) );
				
				v3Pos.x += ( xRandomF( 12.0f ) + -6.0f );
				pSfx = CreateSfx( D3DDEVICE, XI_SKILL_ELE_MULTI_METEOSHOWER02, v3Pos );	// ÀÌÆåÆ®¸¦ ¹ß»ý - ¼­¹ö¿¡¼± »ý¼º ¾ÈµÊ.
				if( pSfx )
					pSfx->SetScale( D3DXVECTOR3( 0.8f, 0.8f, 0.8f ) );
				
				v3Pos = vLocal;
				v3Pos.z += ( xRandomF( 12.0f ) + -6.0f );
				pSfx = CreateSfx( D3DDEVICE, XI_SKILL_ELE_MULTI_METEOSHOWER02, v3Pos );	// ÀÌÆåÆ®¸¦ ¹ß»ý - ¼­¹ö¿¡¼± »ý¼º ¾ÈµÊ.
				if( pSfx )
					pSfx->SetScale( D3DXVECTOR3( 0.8f, 0.8f, 0.8f ) );
				
#endif //__CLIENT
				
			}
			else
			if( m_pActMover->m_nMotionHitCount == 3 )
			{	
		#ifdef __WORLDSERVER
				GetWorld()->SendDamageAround( &(pHitObj->GetPos()), AF_GENERIC, this, OBJTYPE_PLAYER, II_WEA_MOB_MONSTER4_ATK2
					, 5.0f );	
		#endif //__WORLDSERVER
				
			}
		}
		break;
	}
}

#if __VER >= 10 // __Y_DRAGON_FIRE
void	CMover::OnAttackMelee_Meteonyker( DWORD dwState, CMover *pHitObj )
{
	int		nItemID = GetActParam( 1 );	// »ç¿ëÇÒ ¾ÆÀÌÅÛ ¾ÆÀÌµð

	CModelObject *pModel = (CModelObject *)m_pModel;
	
#ifdef __WORLDSERVER
	UpdateMatrix();		// ¸öÃ¼ÀÇ Æ¯Á¤ºÎÀ§¿¡¼­ ³ª´Â µ¥¹ÌÁö¸¦ Ã³¸®ÇÏ±â À§ÇØ¼± ¼­¹ö¿¡¼­µµ ¸ÅÆ®¸¯½º¸¦ °»½ÅÇØ¾ßÇÑ´Ù.
	pModel->UpdateMatrixBone();		// ¼­¹ö¿¡¼­´Â º»¾Ö´Ï¸ÞÀÌ¼ÇÀ» ÇÏÁö ¾ÊÀ¸¹Ç·Î GetEventPos()¸¦ »ç¿ëÇÒ ÀÏÀÌ ÀÖÀ»¶© ¾÷µ¥ÀÌÆ®¸¦ ÇØÁà¾ß ÇÑ´Ù.
#endif // WorldServer
	
	switch( dwState )
	{
	case OBJSTA_ATK1:
		{
			if( IsValidObj(pHitObj) )
			{
				OnDamage( nItemID, dwState, pHitObj );		
			}
		}
		break;
	case OBJSTA_ATK3:		// ÆÄÀÌ¾îº¼ ¹ß»ç
		{
			if( m_pActMover->m_nMotionHitCount == 0 )
			{
				CMover *pTarget = pHitObj;

				D3DXVECTOR3 vPos;
				CModelObject *pModel = (CModelObject *)m_pModel;
				pModel->GetEventPos( &vPos, 0 );	// ¿ëÀÇ ÀÔ ÁÂÇ¥.
				D3DXVec3TransformCoord( &vPos, &vPos, GetMatrixWorldPtr() );

				if( IsValidObj(pTarget) )
				{
					OnDamage( nItemID, dwState, pTarget, &pTarget->GetPos() );		// Å¸°ÙÀÇ ÁÂÇ¥¸¦ Áß½ÉÀ¸·Î µ¥¹ÌÁö¸¦ ÁÜ.
					ItemProp *pSkillProp;
					AddSkillProp *pAddSkillProp;
					BOOL bFind	= GetSkillProp( &pSkillProp, &pAddSkillProp, SI_GEN_STUNSINGLE, 5, "SI_GEN_STUNSINGLE" );
					if( bFind )
					{
						if( xRand() % 2 )
							DoApplySkill( pTarget, pSkillProp, pAddSkillProp , false );
					}

	#ifdef __CLIENT
					CSfx *pSfx = CreateSfx( D3DDEVICE, XI_NPCSP1RANBALL, vPos, GetId(), pTarget->GetPos(), pTarget->GetId(), -1 );		// Æ÷Åº
					if( pSfx )
					{
						pSfx->SetScale( D3DXVECTOR3(4.0f, 4.0f, 4.0f) );
						{
							FLOAT fAngXZ, fAngH;
							D3DXVECTOR3 vDist = pTarget->GetPos() - vPos;
							xGetDegree( &fAngXZ, &fAngH, vDist );		// ¸ñÇ¥¿ÍÀÇ °¢µµ±¸ÇÔ.
							((CSfxAtkStraight *)pSfx)->ShootSfx( fAngXZ, -fAngH, 2.0f, XI_NPCSP1RANBOOM );		// ³¯¾Æ°¡´Â ¹æÇâ ¼³Á¤.
						}
					}
	#endif	// __CLIENT
				}
			}
		}
		break;
	case OBJSTA_ATK4:   // ³¯°³ Á¢¾ú´Ù°¡ ÆîÄ¡±â
		{
			if( m_pActMover->m_nMotionHitCount == 0 )
			{
				// ±¤¿ª È¿°ú
				ItemProp *pSkillProp;
				AddSkillProp *pAddSkillProp;
				BOOL bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_GEN_BURN, 1, "OnAttackMelee_Meteonyker" );
				if( bSuccess )
				{
					D3DXVECTOR3 vPos	= GetPos();
					ApplySkillAround( this, OBJTYPE_PLAYER, pSkillProp, pAddSkillProp, false, FALSE, 10.0F );
					MoverProp* pProp	= GetProp();
					OnDamage( pProp->dwAtk4, OBJSTA_ATK4, NULL, &vPos );
#ifdef __CLIENT
					CSfx *pSfx = CreateSfx( D3DDEVICE, XI_NPCMETEONYKER, vPos );
#endif	// __CLIENT
				}
			}
		}
		break;
	}
}
#endif //__Y_DRAGON_FIRE

void	CMover::OnAttackMelee_Bear( DWORD dwState, CMover *pHitObj )
{
	int		nItemID = GetActParam( 1 );	// »ç¿ëÇÒ ¾ÆÀÌÅÛ ¾ÆÀÌµð

	CModelObject *pModel = (CModelObject *)m_pModel;
	
#ifdef __WORLDSERVER
	UpdateMatrix();		// ¸öÃ¼ÀÇ Æ¯Á¤ºÎÀ§¿¡¼­ ³ª´Â µ¥¹ÌÁö¸¦ Ã³¸®ÇÏ±â À§ÇØ¼± ¼­¹ö¿¡¼­µµ ¸ÅÆ®¸¯½º¸¦ °»½ÅÇØ¾ßÇÑ´Ù.
	pModel->UpdateMatrixBone();		// ¼­¹ö¿¡¼­´Â º»¾Ö´Ï¸ÞÀÌ¼ÇÀ» ÇÏÁö ¾ÊÀ¸¹Ç·Î GetEventPos()¸¦ »ç¿ëÇÒ ÀÏÀÌ ÀÖÀ»¶© ¾÷µ¥ÀÌÆ®¸¦ ÇØÁà¾ß ÇÑ´Ù.
#endif // WorldServer
	
	switch( dwState )
	{
	case OBJSTA_ATK1:	
		{
	#ifdef __WORLDSERVER
			ItemProp *pSkillProp;
			AddSkillProp *pAddSkillProp;
			BOOL bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_GEN_ATKSPELL_RATEGROUP, 5, "OnAttackMelee_BigMuscle" );
			if( bSuccess )
				ApplySkillAround( this, OBJTYPE_PLAYER, pSkillProp, pAddSkillProp , false );			
			
			OnDamage( nItemID, dwState, pHitObj );					
	#endif // WorldServer
		}
		break;
	case OBJSTA_ATK2:	
		{
	#ifdef __WORLDSERVER
			OnDamage( nItemID, dwState, pHitObj );					
	#endif // WorldServer
		}
		break;
	case OBJSTA_ATK3:		
		{
			if( m_pActMover->m_nMotionHitCount == 0 )
			{				
	#ifdef __CLIENT
				CSfx *pSfx = CreateSfx( D3DDEVICE, XI_SKILL_CIRCLE_DUST, GetPos() );			
				if( pSfx )
					pSfx->SetScale( D3DXVECTOR3( 12.0f, 12.0f, 12.0f ) );
				
				PLAYSND( SND_PC_SKILLD_HITOFPENYA );//, &v2 );
	#endif //__CLIENT 			
				
	#ifdef __WORLDSERVER
				ItemProp *pSkillProp;
				AddSkillProp *pAddSkillProp;
				BOOL bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_GEN_KNOCK_BACK, 4, "OnAttackMelee_BigMuscle" );
				if( bSuccess )
					ApplySkillAround( this, OBJTYPE_PLAYER, pSkillProp, pAddSkillProp , false );
	#endif //__WORLDSERVER			
			}
			else
			if( m_pActMover->m_nMotionHitCount == 1 )
			{
	#ifdef __CLIENT
				PLAYSND( SND_PC_BOSS_STUN );
	#endif //__CLIENT
				
	#ifdef __WORLDSERVER
				ItemProp *pSkillProp;
				AddSkillProp *pAddSkillProp;
				BOOL bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_GEN_STUNGROUP, 5, "OnAttackMelee_Bear" );
				if( bSuccess )
					ApplySkillAround( this, OBJTYPE_PLAYER, pSkillProp, pAddSkillProp , false );				
	#endif //__WORLDSERVER			
			}
		}
		break;
	case OBJSTA_ATK4:	
		{	
#ifdef __WORLDSERVER
			ItemProp *pSkillProp;
			AddSkillProp *pAddSkillProp;
			BOOL bSuccess;
	
			// ÀÚ½Å Èú¸µ
			bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_ASS_HEAL_HEALING, 1, "OnAttackMelee_BigMuscle" );
			if( bSuccess )
				DoApplySkill( this, pSkillProp, pAddSkillProp , false );

			//¹ö¼­Å©
			bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_MUSHMOOT_BERSERK, 1, "OnAttackMelee_Bear" );
			if( bSuccess )
				DoApplySkill( this, pSkillProp, pAddSkillProp , false );

			// ¿ìµç½ºÅ² 
			bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_MUSHMOOT_WOODENSKIN, 1, "OnAttackMelee_Bear" );
			if( bSuccess )
				DoApplySkill( this, pSkillProp, pAddSkillProp , false );
			
			// Èû¾÷
			bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_ASS_CHEER_HEAPUP, 1, "OnAttackMelee_BigMuscle" );
			if( bSuccess )
				DoApplySkill( this, pSkillProp, pAddSkillProp , false );

			//Ä³³íº¼
			bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_ASS_CHEER_CANNONBALL, 1, "OnAttackMelee_BigMuscle" );
			if( bSuccess )
				DoApplySkill( this, pSkillProp, pAddSkillProp , false );

			//¸àÅ»»çÀÎ
			bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_ASS_CHEER_MENTALSIGN, 1, "OnAttackMelee_BigMuscle" );
			if( bSuccess )
				DoApplySkill( this, pSkillProp, pAddSkillProp , false );

			//ºñÇÁ¾÷
			bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_ASS_CHEER_BEEFUP, 1, "OnAttackMelee_BigMuscle" );
			if( bSuccess )
				DoApplySkill( this, pSkillProp, pAddSkillProp , false );
			
			
			//Ä³Ã÷ÇÃ·º½º
			bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_ASS_CHEER_CATSREFLEX, 1, "OnAttackMelee_BigMuscle" );
			if( bSuccess )
				DoApplySkill( this, pSkillProp, pAddSkillProp , false );

			//¾îÅ¥·¯½Ã
			bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_ASS_CHEER_ACCURACY, 1, "OnAttackMelee_BigMuscle" );
			if( bSuccess )
				DoApplySkill( this, pSkillProp, pAddSkillProp , false );

			//ÇØÀÌ½ºÆ®
			bSuccess = GetSkillProp( &pSkillProp, &pAddSkillProp, SI_ASS_CHEER_HASTE, 1, "OnAttackMelee_BigMuscle" );
			if( bSuccess )
				DoApplySkill( this, pSkillProp, pAddSkillProp , false );
			

			// º¸½º¸ó½ºÅÍ°¡ Á¡Á¡ Ä¿Áø´Ù.
			D3DXVECTOR3 vScale = GetScale();

			vScale *= 1.3f;

			if( vScale.x < 10.0f )
			{
				SetScale( vScale );
				g_UserMng.AddSetScale( this, (vScale.x / m_pModel->m_pModelElem->m_fScale)  );
			}
			
#endif //__WORLDSERVER			
		}
		break;
	}
}
// µ¥¹ÌÁö¸¦ Àû¿ëÇÏ´Â ºÎºÐ. - °ø°Ý¹æ½Ä¿¡ µû¶ó¼­ Å¸Á¡ÇÑ¹ø¿¡ ¾î·¯¹ø È£ÃâµÉ ¼öµµ ÀÖ´Ù.
// pHitObj : µ¥¹ÌÁö¸¦ ¸ÔÀ» ´ë»ó. NULLÀÌ¸é vDamagePosÀÇ ÁÂÇ¥¸¦ Áß½ÉÀ¸·Î µ¥¹ÌÁö¸¦ ÁØ´Ù.
BOOL	CMover::OnDamage( int nItemID, DWORD dwState, CMover *pHitObj, const D3DXVECTOR3 *pvDamagePos, DWORD dwAtkFlag )
{
	int nParam = 0x01;		//sun

	if( IsPlayer() && IsDualWeapon() )		// ½ÖÄ®¸ðµå³Ä?
	{
		if( m_pActMover->m_dwAtkFlags & AF_GENERIC )	// ÆòÅ¸¸é
		{
			switch( dwState )
			{
			case OBJSTA_ATK1:	nParam |= 0x01;		break; // ¿À¸¥¼Õ
			case OBJSTA_ATK2:	nParam |= 0x02;		break; // ¿Þ¼Õ
			case OBJSTA_ATK3:	nParam |= 0x01;		break; // ¿À¸¥¼Õ
			case OBJSTA_ATK4:	nParam |= 0x03;		break; // ¾ç¼Õ
			}
		}
	}


#if defined(__CLIENT)
	if( IsValidObj(pHitObj) )
	{
		CModelObject* pHitModel = (CModelObject*)pHitObj->m_pModel;
		if( pHitModel )
		{
			D3DXVECTOR3 vDir;
			pHitModel->m_SparkInfo.m_bUsed = TRUE;
			pHitModel->m_SparkInfo.m_v3Color.x = 2.0f;
			pHitModel->m_SparkInfo.m_v3Color.y = 2.0f;
			pHitModel->m_SparkInfo.m_v3Color.z = 2.0f;
			pHitModel->m_SparkInfo.m_nCnt = 0;
			pHitModel->m_SparkInfo.m_fLerp= 1.0f;

			vDir = pHitObj->GetPos() - GetPos();
			D3DXVec3Normalize( &pHitModel->m_SparkInfo.m_v3SparkDir, &vDir );
		}
	}
#endif //defined(__CLIENT) 
	
#ifdef __NO_HP_DMG_LIMIT
	long long nDamage = 0;
#else
	int	nDamage = 0;
#endif
	if( IsPlayer() )
	{
		// ÇÃ·¹ÀÌ¾î
		nDamage = pHitObj->m_pActMover->SendDamage( m_pActMover->m_dwAtkFlags, GetId(), nParam );
	}
	else
	{
		// ¸ó½ºÅÍ
		ItemProp *pItemProp = prj.GetItemProp( nItemID );
		if( pItemProp )
		{
			if( pItemProp->dwSpellRegion == SRO_AROUND )
			{
				int nType = OBJTYPE_PLAYER;		// ÇÃ·¹ÀÌ¾îµé¸¸ µ¥¹ÌÁö.
				if( pHitObj )
					pHitObj->SendDamageAround( dwAtkFlag, this, nType, nItemID, (float)pItemProp->_dwSkillRange, 1.0f, 1.0f ); 
				else
					GetWorld()->SendDamageAround( pvDamagePos, dwAtkFlag, this, nType, nItemID, (float)pItemProp->_dwSkillRange ); 
			} else
			{
				if( pHitObj )
					nDamage = pHitObj->m_pActMover->SendDamage( m_pActMover->m_dwAtkFlags, GetId(), 1 );
			}
		} else
		{
			if( pHitObj )
				nDamage = pHitObj->m_pActMover->SendDamage( m_pActMover->m_dwAtkFlags, GetId(), 1 );
		}
	}


 #ifdef __WORLDSERVER
	if( nDamage > 0 )		// THIS°¡ °ø°ÝÇß´Âµ¥ µ¥¹ÌÁö ¸ÔÀÌ´Âµ¥ ¼º°øÇß´Ù
	{
		if( pHitObj->m_pActMover->GetState() & OBJSTA_ATK_MELEESKILL )	// ¸Â´Â³ðÀÌ ½ºÅ³ ¸ð¼ÇÁßÀÌ¾ú´Ù.
		{
			DWORD dwSkill = pHitObj->GetActParam(0);		// ÇöÀç »ç¿ëÇÏ°í ÀÖ´Â ½ºÅ³. dwSkill
			if( dwSkill == SI_MER_ONE_REFLEXHIT )			// ¸®ÇÃ·ºÈ÷Æ® ½ºÅ³À» ¾²°í ÀÖ´Â Áß¿¡ ¸Â¾Ò´Ù.
			{
				pHitObj->m_nReflexDmg += nDamage;			// ¸®ÇÃ·ºµ¥¹ÌÁö´Â ½×ÀÓ.
			}
		}
	}
 #endif
	return nDamage > 0;
}

//
// ÀÏ¹Ý °ø°ÝÀÇ Å¸Á¡¶§ È£ÃâµÇ´Â ÇÚµé·¯.
BOOL	CMover::OnAttackMelee( DWORD dwState, CMover *pHitObj )
{
	CModelObject	*pModel = (CModelObject *)m_pModel;
	int		nItemID = GetActParam( 1 );	// »ç¿ëÇÒ ¾ÆÀÌÅÛ ¾ÆÀÌµð

#ifdef __WORLDSERVER
	PostAIMsg( AIMSG_ATTACK_MELEE );
#endif
	
 	if( m_dwIndex == MI_CLOCKWORK1 )	// Å¬¶ô¿öÅ©ÀÇ °æ¿ì ¶§¸±¶§ ÀÌÆåÆ®.
	{
		OnAttackMelee_ClockWorks( dwState, pHitObj );
#ifdef __CLOCKWORK_AI		
#ifdef __WORLDSERVER
		switch (dwState)
		{
		case OBJSTA_ATK1:
			CreateClockworkAttack1(SI_ATTACK_CLOCKWORK_1, pHitObj->GetId());
			break;
		case OBJSTA_ATK2:
			CreateClockworkAttack2(SI_ATTACK_CLOCKWORK_2, pHitObj->GetId());
			break;
		case OBJSTA_ATK3:
			CreateClockworkAttack3(SI_ATTACK_CLOCKWORK_3, pHitObj->GetId());
			break;
		case OBJSTA_ATK4:
			CreateClockworkAttack4(SI_ATTACK_CLOCKWORK_4, pHitObj->GetId());
			break;
		}

		//if( IsNPC() && CMonsterSkill::GetInstance()->ApplySkill( this, pHitObj, ATK_MELEE ) )
		//{
		//	return TRUE;
		//}
#endif //__WORLDSERVER
#endif //__CLOCKWORK_AI	
		return TRUE;
	}

#ifdef __WORLDSERVER		
#ifdef __NEW_BOSSMECHANICS

	MoverProp* pProp = GetProp();
	if (pProp->bossMechanics.hasBossAttacks)
		OnAttackMelee_CustomBoss1(pProp->bossMechanics, pHitObj);
#endif //__NEW_BOSSMECHANICS
#endif	//__WORLDSERVER

	if( m_dwIndex == MI_BIGMUSCLE )	// ºò¸Ó½½ÀÇ °æ¿ì ¶§¸±¶§ ÀÌÆåÆ®.
	{
		OnAttackMelee_BigMuscle( dwState, pHitObj );
		m_pActMover->m_nMotionHitCount++;		
		return TRUE;
	}

	if( m_dwIndex == MI_KRRR )	// Å©¸£¸ªÀÇ °æ¿ì ¶§¸±¶§ ÀÌÆåÆ®.
	{
		OnAttackMelee_Krrr( dwState, pHitObj );
		m_pActMover->m_nMotionHitCount++;		
		return TRUE;
	}	

	if( m_dwIndex == MI_MUSHMOOT )	// Å©¸£¸ªÀÇ °æ¿ì ¶§¸±¶§ ÀÌÆåÆ®.
	{
		OnAttackMelee_Bear( dwState, pHitObj );
		m_pActMover->m_nMotionHitCount++;		
		return TRUE;
	}	

#if __VER >= 10 // __Y_DRAGON_FIRE
	if( m_dwIndex == MI_DU_METEONYKER || m_dwIndex == MI_DU_METEONYKER2 || m_dwIndex == MI_DU_METEONYKER3 ||
		m_dwIndex == MI_DU_METEONYKER4 )
	{
		OnAttackMelee_Meteonyker( dwState, pHitObj );
		m_pActMover->m_nMotionHitCount++;		
		return TRUE;
	}
#endif //__Y_DRAGON_FIRE

#ifdef __WORLDSERVER
#if __VER >= 12 // __MONSTER_SKILL
	if( IsNPC() && CMonsterSkill::GetInstance()->ApplySkill( this, pHitObj, ATK_MELEE ) )
	{
		//m_pActMover->m_nMotionHitCount++;
		return TRUE;
	}
#endif // __MONSTER_SKILL
#endif // __WORLDSERVER

	BOOL bSuccess = FALSE;
	BOOL bDamage = TRUE;

#ifdef __WORLDSERVER
	if( IsNPC() && pHitObj->IsPlayer() && pHitObj->IsRangeObj( this, 10.0f ) == FALSE )		// µÎ¹øÁ×´Â °æ¿ì¶«¿¡ ³Ö¾îºÃ´Ù. ¸÷->À¯Àú 10¹ÌÅÍ ÀÌ»ó ¶³¾îÁ®ÀÖÀ»¶§´Â ¾È¸Â°Ô.
		bDamage = FALSE;
#endif
	if( bDamage )
	{
		bSuccess = OnDamage( nItemID, dwState, pHitObj );	// µ¥¹ÌÁö¸¦ ÁØ´Ù.
	}

#ifdef __WORLDSERVER
	if (bSuccess)
	{
		if (IsPlayer())
		{
//#ifndef __NEW_TASKBAR_V19
			if (dwState == OBJSTA_ATK1 && ((CUser*)this)->m_playTaskBar.m_nActionPoint < 100)	// 2Å¸Â° Ä¡´Â°Ç ¾×¼ÇÆ÷ÀÎÆ® ¿Ã¶ó°¨.
				((CUser*)this)->m_playTaskBar.m_nActionPoint++;
//#endif // __NEW_TASKBAR_V19
		}
	}
#endif	// worldserver

#ifdef __CLIENT
	if( bSuccess )		// Å¸°Ý¿¡ ¼º°øÇß´Ù¸é Å¸°ÝÀ½À» ÇÃ·¹ÀÌ.
	{
		if (CMover::GetActiveMover() == this)
		{
//#ifndef __NEW_TASKBAR_V19
			if (dwState == OBJSTA_ATK1 && g_WndMng.m_pWndTaskBar->m_nActionPoint < 100)	// 2Å¸Â° Ä¡´Â°Ç ¾×¼ÇÆ÷ÀÎÆ® ¿Ã¶ó°¨.
				g_WndMng.m_pWndTaskBar->m_nActionPoint++;
//#endif // __NEW_TASKBAR_V19
	}
		//  ÇÃ·¹ÀÌ¾î´Â µé°í ÀÖ´Â ¹«±â¿¡ µû¶ó Å¸°Ý À½ÀÌ ´Ù¸£´Ù.
		ItemProp* pItemProp = GetActiveHandItemProp();
		if( pItemProp )
		{
/*		#ifndef __Y_DRAGON_FIRE
			if( pItemProp->dwSfxObj2 != NULL_ID )
			{
				CSfx *pSfx = CreateSfx( D3DDEVICE, pItemProp->dwSfxObj2,  GetPos(), GetId(), this->GetPos(), this->GetId(), 0 ); 
			}
		#endif //__Y_DRAGON_FIRE
*/
			PLAYSND( pItemProp->dwSndAttack1, &GetPos() );
		}
		
		if( IsPlayer() )
		{
			pModel->m_nPause = 5;	// frame ¸ØÃã
		}
		else
		{
			pModel->m_nPause = 0;	// ¸ó½ºÅÍ´Â ¸ØÃßÁö ¾ÊÀ½
			pHitObj->m_pModel->m_nPause = 0;
		}

#if defined(__CLIENT)
		{
			if( IsValidObj( pHitObj ) )
			{
				pModel->m_SparkInfo.m_bUsed  = TRUE;
				pModel->m_SparkInfo.m_v3Color.x = 2.0f;
				pModel->m_SparkInfo.m_v3Color.y = 2.0f;
				pModel->m_SparkInfo.m_v3Color.z = 2.0f;
				pModel->m_SparkInfo.m_nCnt = 0;
				pModel->m_SparkInfo.m_fLerp= 1.0f;
				
				D3DXVECTOR3 vDir = GetPos() - pHitObj->GetPos();
				D3DXVec3Normalize( &pModel->m_SparkInfo.m_v3SparkDir, &vDir );
			}
		}
#endif //defined(__CLIENT)
		
		
	}
#endif // client
	
	
	return TRUE;
}

//
//
// Å¸Á¡ ÀÌÈÄºÎÅÍ ³¡³¯¶§±îÁö °è¼Ó È£Ãâ.
BOOL	CMover::OnAttackMeleeContinue( DWORD dwState )
{
	int		nItemID = GetActParam( 1 );	// »ç¿ëÇÒ ¾ÆÀÌÅÛ ¾ÆÀÌµð

	if( m_dwIndex == MI_CLOCKWORK1 )	// Å¬¶ô¿öÅ©ÀÇ °æ¿ì ¶§¸±¶§ ÀÌÆåÆ®.
	{
	#ifdef __WORLDSERVER
		UpdateMatrix();		// ¸öÃ¼ÀÇ Æ¯Á¤ºÎÀ§¿¡¼­ ³ª´Â µ¥¹ÌÁö¸¦ Ã³¸®ÇÏ±â À§ÇØ¼± ¼­¹ö¿¡¼­µµ ¸ÅÆ®¸¯½º¸¦ °»½ÅÇØ¾ßÇÑ´Ù.
		CModelObject *pModel = (CModelObject *)m_pModel;
		pModel->UpdateMatrixBone();		// ¼­¹ö¿¡¼­´Â º»¾Ö´Ï¸ÞÀÌ¼ÇÀ» ÇÏÁö ¾ÊÀ¸¹Ç·Î GetEventPos()¸¦ »ç¿ëÇÒ ÀÏÀÌ ÀÖÀ»¶© ¾÷µ¥ÀÌÆ®¸¦ ÇØÁà¾ß ÇÑ´Ù.
	#endif // WorldServer

		switch( dwState )
		{
		case OBJSTA_ATK3:
			{
				D3DXVECTOR3 v1, v2;
				CModelObject *pModel = (CModelObject *)m_pModel;
				pModel->GetEventPos( &v1, 2 );		// ·¹ÀÌÀú ³ª°¡´Â ºÎºÐ.
				D3DXVec3TransformCoord( &v1, &v1, GetMatrixWorldPtr() );	// ¿ùµå°ø°£À¸·Î º¯È¯.
				
				v2 = D3DXVECTOR3( 0, 0, 40.0f );
				D3DXVec3TransformCoord( &v2, &v2, pModel->GetMatrixBone(6) );	// 6ÀÌ ¸Ó¸®.  ¸Ó¸®¿¡¼­ v2ÁöÁ¡ÀÇ À§Ä¡¸¦ °è»ê.
				D3DXVec3TransformCoord( &v2, &v2, GetMatrixWorldPtr() );	// ¿ùµå °ø°£À¸·Î º¯È¯.
				
		#ifdef __CLIENT
				extern CPartsLaser g_Laser;
				g_Laser.SetPos( v1, v2, 0.5f );
		#endif

		#ifdef __CLIENT
				if( (m_pActMover->m_nCount & 1) == 0 )
		#else				
				if( (m_pActMover->m_nCount & 3) == 0 )
		#endif
				{
					CWorld *pWorld = GetWorld();
					D3DXVECTOR3 vOut;
					if( pWorld->IntersectObjLine( &vOut, v1, v2, FALSE, TRUE, FALSE ) )
					{
						OnDamage( nItemID, dwState, NULL, &vOut );		// ÀÌÆåÆ®°¡ ÅÍÁö´Â À§Ä¡¿¡ µ¥¹ÌÁö¸¦ ÁÜ.

					#ifdef __CLIENT
						CSfx *pSfx = CreateSfx( D3DDEVICE,  XI_NPCSP1RANSPARK, vOut );
						if( pSfx )
							pSfx->SetScale( D3DXVECTOR3( 2.0f, 2.0f, 2.0f ) );
					#endif // __CLIENT
					}
						
				}
			}
			break;
		}
	}
#if __VER >= 10 // __Y_DRAGON_FIRE
	else
	if( m_dwIndex == MI_DU_METEONYKER || m_dwIndex == MI_DU_METEONYKER2 || m_dwIndex == MI_DU_METEONYKER3 ||
		m_dwIndex == MI_DU_METEONYKER4 )
	{
	#ifdef __WORLDSERVER
		UpdateMatrix();		// ¸öÃ¼ÀÇ Æ¯Á¤ºÎÀ§¿¡¼­ ³ª´Â µ¥¹ÌÁö¸¦ Ã³¸®ÇÏ±â À§ÇØ¼± ¼­¹ö¿¡¼­µµ ¸ÅÆ®¸¯½º¸¦ °»½ÅÇØ¾ßÇÑ´Ù.
		CModelObject *pModel = (CModelObject *)m_pModel;
		pModel->UpdateMatrixBone();		// ¼­¹ö¿¡¼­´Â º»¾Ö´Ï¸ÞÀÌ¼ÇÀ» ÇÏÁö ¾ÊÀ¸¹Ç·Î GetEventPos()¸¦ »ç¿ëÇÒ ÀÏÀÌ ÀÖÀ»¶© ¾÷µ¥ÀÌÆ®¸¦ ÇØÁà¾ß ÇÑ´Ù.
	#endif // WorldServer

		switch( dwState )
		{
			case OBJSTA_ATK2:
			{
				if( m_pActMover->m_nMotionHitCount == 1 )
				{
					D3DXVECTOR3 v1, v2, v3;
					CModelObject *pModel = (CModelObject *)m_pModel;
					pModel->GetEventPos( &v1, 0 );		// ·¹ÀÌÀú ³ª°¡´Â ºÎºÐ.
					pModel->GetEventPos( &v3, 1 );		// ·¹ÀÌÀú ³ª°¡´Â ºÎºÐ.
					D3DXVec3TransformCoord( &v1, &v1, GetMatrixWorldPtr() );	// ¿ùµå°ø°£À¸·Î º¯È¯.
					D3DXVec3TransformCoord( &v3, &v3, GetMatrixWorldPtr() );	// ¿ùµå°ø°£À¸·Î º¯È¯.

					v2 = D3DXVECTOR3( 0, 0, 40.0f );
					D3DXVec3TransformCoord( &v2, &v2, pModel->GetMatrixBone(6) );	// 6ÀÌ ¸Ó¸®.  ¸Ó¸®¿¡¼­ v2ÁöÁ¡ÀÇ À§Ä¡¸¦ °è»ê.
					D3DXVec3TransformCoord( &v2, &v2, GetMatrixWorldPtr() );	// ¿ùµå °ø°£À¸·Î º¯È¯.
					
			#ifdef __CLIENT
					D3DXVECTOR3 vDir = v3 - v1;
					D3DXVec3Normalize( &vDir, &vDir );
					D3DXVECTOR3 vTemp;
					D3DXVECTOR3 vScal = D3DXVECTOR3( 0.3f, 0.3f, 0.3f );
					D3DXVECTOR3 vModelScal = GetScale();

					vScal.x *= vModelScal.x;
					vScal.y *= vModelScal.y;
					vScal.z *= vModelScal.z;

					for( int i = 0; i < 2; i ++ )
					{
						vTemp = vDir * (xRandomF( 0.2f ) + 0.1f );
						vTemp *= 0.8f;
						vTemp.y -= (xRandomF( 0.05f ) + 0.01f );
						
						extern CPartsFireDragon	g_FireDragon;
						g_FireDragon.Create( D3DDEVICE, v1, XI_NAT_FIRE01_ADV, vScal, vTemp );
					}

			#endif

			#ifdef __CLIENT
					if( (m_pActMover->m_nCount & 1) == 0 )
			#else				
					if( (m_pActMover->m_nCount & 3) == 0 )
			#endif
					{
						CWorld *pWorld = GetWorld();
						D3DXVECTOR3 vOut	= GetPos();
//						if( pWorld->IntersectObjLine( &vOut, v1, v2, FALSE, TRUE, FALSE ) )
						{
							OnDamage( nItemID, dwState, NULL, &vOut );		// ÀÌÆåÆ®°¡ ÅÍÁö´Â À§Ä¡¿¡ µ¥¹ÌÁö¸¦ ÁÜ.
	/*
						#ifdef __CLIENT
							CSfx *pSfx = CreateSfx( D3DDEVICE,  XI_NPCSP1RANSPARK, vOut );
							if( pSfx )
								pSfx->SetScale( D3DXVECTOR3( 2.0f, 2.0f, 2.0f ) );
						#endif // __CLIENT
	*/
						}
							
					}
				}
				break;
			}
		}
	}
#endif //__Y_DRAGON_FIRE

	return TRUE;
}

// ¸ó½ºÅÍÀÇ Æ¯¼ö°ø°Ý Å¸°ÝºÎºÐ¿¡ È£Ãâ
BOOL	CMover::OnAttackSP()
{
	int		idTarget = GetActParam( 0 );		
	int		nItemID = GetActParam( 1 );	// »ç¿ëÇÒ ¾ÆÀÌÅÛ ¾ÆÀÌµð
	
	CMover* pHit = prj.GetMover( idTarget );	// Å¸°ÙÀÇ Æ÷ÀÎÅÍ¸¦ ¾ò¾î³¿.
	if( IsInvalidObj(pHit) )	return FALSE;		// Å¬¸¯ÇßÀ»´ç½Ã´Â ÀÖ¾úÀ¸³ª ¹ß»çµÇ±âÀü¿¡ »èÁ¦µÇ¾ú´Ù.

	ItemProp *pItemProp;
	if( nItemID == NULL_ID || nItemID == 0 )	
		pItemProp = GetActiveHandItemProp();	// ÀÌ·±°æ¿ì´Â °Á ¼Õ¿¡ µç ¹«±â(È¤Àº ±âº»¾ÆÀÌÅÛ)
	else
		pItemProp = prj.GetItemProp( nItemID );	// Á÷Á¢ ¾ÆÀÌÅÛÀ» ÁöÁ¤ÇÑ °æ¿ì´Â ±×°É·Î °ø°ÝÇÔ(¸ó½ºÅÍ°¡ ÁÖ·Î »ç¿ëÇÔ)

	if( pItemProp == NULL )
	{
		Error( "CMover::OnAttackSP : %sÀÇ itemPropÀÌ ¾ø´Ù. %d", m_szName, nItemID );
		return FALSE;
	}

	if( pItemProp->dwSpellRegion == SRO_AROUND )
	{	
		SendDamageAround( AF_GENERIC, this, OBJTYPE_PLAYER, nItemID, (float)( pItemProp->_dwSkillRange ), 0.0, 1.0f );	// ¹üÀ§°ø°Ý½ºµûÀÏ
	} else
	{
#ifdef __CLIENT
		if( pHit->IsLive() )
			pHit->m_pActMover->SendDamage( AF_MONSTER_SP_CLIENT, GetId(), (nItemID << 16) );	// 09_12_21 ¸ó½ºÅÍ ½ºÆä¼È °ø°Ý
#else
		if( pHit->IsLive() )
			pHit->m_pActMover->SendDamage( AF_GENERIC, GetId(), (nItemID << 16) );	// Á÷Á¢ °ø°Ý ½ºµûÀÏ.
#endif
	}

	return TRUE;
}                                                         

//
//	Ä³¸¯ÅÍ°¡ ³ôÀº°÷¿¡¼­ ¶³¾îÁø ½ÃÁ¡¿¡ È£Ãâ
//
void	CMover::OnActDrop()
{
#ifdef __WORLDSERVER
	if( m_pActMover->GetDmgState() & OBJSTA_DMG_FLY_ALL )		// µ¥¹ÌÁö ÇÃ¶óÀÌ¶© ÀÌ°Å ¾ÈÇÏ´Â°Ô ÁÁ´Ù.
		return;

	if( FALSE == IsPlayer() )
	{
		if( m_nCorr < 0
#if __VER >= 9	//__AI_0509
			&& GetSpeedFactor() < 1.9F
#endif	// __AI_0509
#ifdef __JEFF_11
			&& m_dwAIInterface != AII_PET
#endif	//	__JEFF_11
			)
		{
			ClearDestPos();
			SendActMsg( OBJMSG_STAND );
			if( m_pActMover->IsFly() )
				g_UserMng.AddMoverCorr2( this, GetPos(), m_pActMover->m_vDelta, GetAngle(), GetAngleX(),
					m_pActMover->m_fAccPower, m_pActMover->m_fTurnAngle, m_pActMover->GetState(), m_pActMover->GetStateFlag(),
					m_dwMotion, m_pActMover->m_nMotionEx, m_pModel->m_nLoop, m_dwMotionOption, g_TickCount.GetTickCount() );
			else
				g_UserMng.AddMoverCorr( this, GetPos(), m_pActMover->m_vDelta, GetAngle(),
					m_pActMover->GetState(), m_pActMover->GetStateFlag(), m_dwMotion, m_pActMover->m_nMotionEx,
					m_pModel->m_nLoop, m_dwMotionOption, g_TickCount.GetTickCount() );
			m_nCorr		= 0;
		}
	}
	else
	{
		if( FALSE == IsEmptyDest() && FALSE == m_fWaitQueryGetPos )
		{
			( (CUser*)this )->AddQueryGetPos( NULL_ID );
			m_fWaitQueryGetPos	= TRUE;
		}
	}
#else	// __WORLDSERVER

	if( IsActiveMover() )
	{
		if( m_nCorr != 0 )
		{
#ifndef __MOVE_LIKE_OFFI
			if (m_nCorr < 0) {
				ClearDest();
				SendActMsg(OBJMSG_STAND);
			}
#endif // !__MOVE_LIKE_OFFI
			if( m_pActMover->IsFly() )
				g_DPlay.SendPlayerCorr2();
			else
				g_DPlay.SendPlayerCorr();
			m_nCorr		= 0;
		}
	}
	else
	{
#if __VER >= 9	//__AI_0509
		if( IsPlayer() || GetSpeedFactor() < 1.9F )
#endif	// __AI_0509
		{
			if( FALSE == IsEmptyDest() && FALSE == m_fWaitQueryGetPos )
			{
				g_DPlay.SendQueryGetPos( this );
				m_fWaitQueryGetPos	= TRUE;
			}
		}
	}
#endif	// not __WORLDSERVER
}

void	CMover::OnActCollision()
{
#ifdef __WORLDSERVER
	if( FALSE == IsPlayer() )
	{
		if( m_nCorr < 0 
#if __VER >= 9	//__AI_0509
			&& GetSpeedFactor() < 1.9F && m_dwAIInterface != AII_PET
#endif	// __AI_0509
			)
		{

#ifndef __MOVE_LIKE_OFFI
			ClearDest();
			SendActMsg(OBJMSG_STAND);
#endif //__MOVE_LIKE_OFFI

			if( m_pActMover->IsFly() )
				g_UserMng.AddMoverCorr2( this, GetPos(), m_pActMover->m_vDelta, GetAngle(), GetAngleX(),
					m_pActMover->m_fAccPower, m_pActMover->m_fTurnAngle, m_pActMover->GetState(), m_pActMover->GetStateFlag(),
					m_dwMotion, m_pActMover->m_nMotionEx, m_pModel->m_nLoop, m_dwMotionOption, g_TickCount.GetTickCount() );
			else
				g_UserMng.AddMoverCorr( this, GetPos(), m_pActMover->m_vDelta, GetAngle(),
					m_pActMover->GetState(), m_pActMover->GetStateFlag(), m_dwMotion, m_pActMover->m_nMotionEx,
					m_pModel->m_nLoop, m_dwMotionOption, g_TickCount.GetTickCount() );

			m_nCorr		= 0;

			PostAIMsg( AIMSG_COLLISION );
		}
	}
	else
	{
		if( FALSE == IsEmptyDest() && FALSE == m_fWaitQueryGetPos )
		{
			( (CUser*)this )->AddQueryGetPos( NULL_ID );
			m_fWaitQueryGetPos	= TRUE;
		}
	}

#else	// __WORLDSERVER
	if( TRUE == IsActiveMover() )
	{
		if( m_nCorr != 0 )
		{
			if( m_nCorr < 0 )
			{
#ifndef __MOVE_LIKE_OFFI
				ClearDest();
				SendActMsg(OBJMSG_STAND);
#endif // __MOVE_LIKE_OFFI
				CWndWorld* pWndWorld	= (CWndWorld*)g_WndMng.GetWndBase( APP_WORLD );
				if( pWndWorld )
					pWndWorld->m_bLButtonDown	= FALSE;
			}
			if( m_pActMover->IsFly() )
				g_DPlay.SendPlayerCorr2();
			else
				g_DPlay.SendPlayerCorr();

			m_nCorr	= 0;
		}
	}
	else if( FALSE == IsActiveMover() )
	{
#if __VER >= 9	//__AI_0509
		if( IsPlayer() || GetSpeedFactor() < 1.9F )
#endif	// __AI_0509
		{
			if( FALSE == IsEmptyDest() && FALSE == m_fWaitQueryGetPos )
			{
				g_DPlay.SendQueryGetPos( this );
				m_fWaitQueryGetPos	= TRUE;
			}
		}
	}

#endif	// __WORLDSERVER
}

// ±ÙÁ¢½ºÅ³ µ¿ÀÛ ³¡³µÀ»¶§.
void	CMover::OnActEndMeleeSkill()
{
	ClearActParam();			// Çàµ¿»óÅÂ Å¬¸®¾î
	m_dwFlag &= (~MVRF_SKILL);
#ifdef __WORLDSERVER
	if( IsPlayer() )
	{
		if( ((CUser *)this)->m_playTaskBar.m_nUsedSkillQueue != -1 )
		{
			((CUser *)this)->m_playTaskBar.SetNextSkill( (CUser *)this );
		}
	}
#endif 

}

// ¸¶¹ý½ºÅ³ µ¿ÀÛ ³¡³µÀ»¶§.
void	CMover::OnActEndMagicSkill()
{
	ClearActParam();			// Çàµ¿»óÅÂ Å¬¸®¾î
	m_dwFlag &= (~MVRF_SKILL);
 #ifdef __WORLDSERVER
	if( IsPlayer() )
	{
		if( ((CUser *)this)->m_playTaskBar.m_nUsedSkillQueue != -1 )
		{
			((CUser *)this)->m_playTaskBar.SetNextSkill( (CUser *)this );
		}
	}
 #endif 
}

// ÂøÁö(JUMP4)ÇÃ·¡±×°¡ »ç¶óÁö´Â ¼ø°£.
void	CMover::OnActEndJump4()
{
	if( FALSE == IsEmptyDestPos() )
		SetDestPos( GetDestPos(), m_bForward, FALSE );

	if( m_dwIndex == MI_CLOCKWORK1 )
	{
		SendActMsg( OBJMSG_APPEAR );
	}
}

// ÂøÁö ÇÏ´Â ¼ø°£¿¡ ¹ß»ý.
void	CMover::OnActLanding()
{
#ifdef __CLIENT	
	if( m_dwIndex == MI_CLOCKWORK1 )
	{
		GetWorld()->m_pCamera->SetQuake( 60, 1.0f );		// º¸½º°¡ ¶³¾îÁö¸é ¶¥ÀÌ Èçµé¸².
	}
#endif
}

// ÀüÁø ÇÏ´Â ¼ø°£¿¡ ¹ß»ý.
void	CMover::OnActFMove()
{
#ifdef __WORLDSERVER
	PostAIMsg( AIMSG_BEGINMOVE );
#endif
}

// Interact ¿ÀºêÁ§Æ®¿¡ ÂøÁö ÇßÀ»¶§.
// pIAObj : ¾î¶² IA¿ÀºêÁ§Æ®¿¡ ÂøÁöÇß´Â°¡.
// vPos : ÂøÁöÇÑ thisÀÇ ÁÂÇ¥.
void	CMover::OnActIALanding( CObj *pIAObj, const D3DXVECTOR3 &vPos )
{
	if( pIAObj->GetType() != OT_SHIP )	
		return;
	CShip *pIA = (CShip *)pIAObj;

	CObj *pOldIA = GetIAObjLink();
	SetIAObjLink( pIA );
	
	if( IsActiveMover() )
	{
		if( pIA != pOldIA )	// °É¾î´Ù´Ò¶§µµ °è¼Ó °»½ÅµÇ±â¶«¿¡ ¸Å¹ø º¸³¾ÇÊ¿ä´Â ¾ø´Ù.
		{
#ifdef __CLIENT			
			D3DXVECTOR3 vLocal = GetPos() - pIA->GetPos();		// IA¿ÀºêÁ§Æ®·ÎºÎÅÍÀÇ »ó´ë ÁÂÇ¥¸¦ »ÌÀ½.
			g_DPlay.SendLocalPosFromIA( vLocal, pIA->GetId() );				// »ó´ëÁÂÇ¥ ¼­¹ö·Î Àü¼Û
			TRACE( "SendLocalPosFromIA\n" );
#endif //__CLIENT
		}
	}

}

/*
int		CMover::OnActCollecting() 
{ 
#ifdef __CLIENT
	if( (m_dwFlag & MVRF_COLLECT) == 0 )
	{
		ItemProp *pHandProp = GetActiveHandItemProp();
		if( pHandProp->dwSfxObj2 != NULL_ID )
		{
			D3DXVECTOR3 vSrc, vLocal = D3DXVECTOR3(0, 0.5f, 0);
			((CModelObject *)m_pModel)->GetForcePos( &vLocal, 0, PARTS_RWEAPON, GetMatrixWorld() );
			vSrc = vLocal;
			CSfx *pSfx = CreateSfx( D3DDEVICE, pHandProp->dwSfxObj2, vSrc, GetId(), D3DXVECTOR3(0,0,0), NULL_ID, -1 );
			if( pSfx )
			{
				pSfx->SetAngle( -GetAngle() + 90.0f );
				m_dwFlag |= MVRF_COLLECT;		// SFX°¡ »ý¼ºµÆÀ½.
			}
		}
	}
#endif // Client
	return 0; 
}				
*/

// °ø°ÝÀ» ¸· ½ÃÀÛÇßÀ»¶§(ÀÏ¹Ý/½ºÅ³/¿Ïµå µî)
void	CMover::OnAttackStart( CMover *pTarget, OBJMSG dwMsg )
{
}

// this°¡ Åõ¸íÈ­ »óÅÂ °É·ÁÀÖÀ¸¸é ÇØÁ¦½ÃÅ´.
void	CMover::RemoveInvisible()
{
#ifdef __WORLDSERVER

	if( GetAdjParam( DST_CHRSTATE ) & CHS_INVISIBILITY )		// Åõ¸íÈ­ »óÅÂ´Ù.
	{
		ResetDestParam( DST_CHRSTATE, CHS_INVISIBILITY, TRUE );
	}

	RemoveBuff( BUFF_SKILL, SI_ACR_SUP_DARKILLUSION );		// ÇØÁ¦.				
#ifdef __NEWCLASS
	RemoveBuff(BUFF_SKILL, SI_STORM_U_SKILL_02);
#endif // __NEWCLASS
#endif // __WORLDSERVER
}


// pItemÀÌ ·çÆÃ°¡´ÉÇÑ°¡¸¦ ÆÇº°.
#ifdef __WORLDSERVER
BOOL CMover::IsLoot( CItem *pItem, BOOL bPet )
{
	BOOL bTake	= FALSE;
	
	if( pItem->IsDelete() || ( pItem->m_idHolder != 0 && pItem->m_idHolder != m_idPlayer ) )
	{
		return bTake;
	}

	if( pItem->m_idOwn != NULL_ID )		// ¾ÆÀÌÅÛ¿¡ ÁÖÀÎÀÌ ÀÖÀ»¶§
	{
		// ÀÏ¹ÝÀûÀ¸·Î ¶³¾îÁø ¾ÆÀÌÅÛ.
		CMover *pOther = prj.GetMover( pItem->m_idOwn );		// pItemÀ» ÁýÀ» ±ÇÇÑÀÌ ÀÖ´Â»ç¶÷.(°¡·É...¸·Å¸)
		if( IsValidObj(pOther) )
		{
			if( m_idparty && (pOther->m_idparty == m_idparty) )		// ÆÄÆ¼°¡ ÀÖ°í ³ª¶û °°Àº ÆÄÆ¼¿øÀÌ¸é ÁÞÀ»¼ö ÀÖ¾î¿ä~~~ ¤»¤»¤»
				bTake = TRUE;
		} else
			bTake = TRUE;		// idOwnÀÌ Invalid»óÅÂ¸é ¾Æ¹«³ª ÁÞÀ» ¼ö ÀÖÀ½.
		
		if( pItem->m_idOwn == GetId() )		// ¾ÆÀÌÅÛÀÇ ¼ÒÀ¯±ÇÀÚ¸é ÁýÀ» ¼ö ÀÖ´Ù.
			bTake = TRUE;
		
	} else
		bTake = TRUE;	// ÁÖÀÎÀÌ ¾ø´Â°Å¸é ¾Æ¹«³ª ÁÞÀ»¼ö ÀÖ´Ù.

	DWORD dwTime	= g_tmCurrent;
#ifdef __EVENT_MONSTER
	DWORD dwMonsterId = pItem->m_IdEventMonster;
	if( dwMonsterId != NULL_ID && CEventMonster::GetInstance()->SetEventMonster( dwMonsterId ) )
	{
		DWORD dwLootTime = CEventMonster::GetInstance()->GetLootTime();
		if( (dwTime - pItem->m_dwDropTime) >= (DWORD)( SEC(dwLootTime) ) )
			bTake = TRUE;
		
		if( bPet && !CEventMonster::GetInstance()->IsPetAble() )
			bTake = FALSE;
	}
	else
#endif // __EVENT_MONSTER
#if __VER >= 9 // __S_9_ADD
	if( (dwTime - pItem->m_dwDropTime) >= SEC(7) )	// 7ÃÊ°¡ Áö³­°Ç ¾Æ¹«³ª ÁÞÀ» ¼ö ÀÖ´Ù.
#else // __S_9_ADD
	if( (dwTime - pItem->m_dwDropTime) >= SEC(40) )	// 40ÃÊ°¡ Áö³­°Ç ¾Æ¹«³ª ÁÞÀ» ¼ö ÀÖ´Ù.
#endif // __S_9_ADD
		bTake = TRUE;

	// ÆêÀº ¸®½ºÆùµÈ ¾ÆÀÌÅÛÀ» ÁýÀ»¼ö ¾øÀ½.
	if( bPet && bTake )
	{
		if( 0 < ((CCtrl*)pItem)->m_lRespawn )
			bTake = FALSE;
#ifdef __JEFF_11
		// ¼ÒÁöÇ°ÀÌ °¡µæ Â÷¼­ ÇØ´ç ¾ÆÀÌÅÛÀ» È¹µæÇÒ ¼ö ¾ø´Ù
		CItemElem* pItemElem	= (CItemElem*)pItem->m_pItemBase;
		ItemProp* pItemProp		= pItemElem->GetProp();
		if( pItemProp->dwItemKind3 != IK3_GOLD && m_Inventory.IsFull( pItemElem, pItemProp, pItemElem->m_nItemNum ) )
			bTake	= FALSE;
#endif	// __JEFF_11
	}

	return bTake;
}
#endif // WorldServer

// DoLootÀÇ ÇÏÀ§ - ¸÷ÀÌ ¶³¾îÆ®¸° ¾ÆÀÌÅÛÀ» ¼Ö·ÎÀ×ÀÏ¶§ ÁýÀ¸·Á ÇÒ¶§ Ã³¸®ºÎ
BOOL CMover::SubLootDropMobSingle( CItem *pItem )
{
	BOOL bSuccess = TRUE;
#ifdef __WORLDSERVER	
	CItemBase* pItemBase = pItem->m_pItemBase;
#ifdef __BAG_LOOT
	if (this->m_nSelectedBag == 0)
	{
#if defined  (__FL_FARM_STAT) || defined (__DROP_LOG)
		bSuccess = CreateItem(pItemBase, NULL, NULL, 0, TRUE);
#else
		bSuccess = CreateItem(pItemBase);
#endif
	}
	else
	{
		bSuccess = CreateItem2((CItemElem*)pItemBase, this->m_nSelectedBag - 1);
		if (!bSuccess)
		{
#if defined  (__FL_FARM_STAT) || defined (__DROP_LOG)
			bSuccess = CreateItem(pItemBase, NULL, NULL, 0, TRUE);
#else
			bSuccess = CreateItem(pItemBase);
#endif
		}
	}
#else
#if defined  (__FL_FARM_STAT) || defined (__DROP_LOG)
	bSuccess = CreateItem(pItemBase, NULL, NULL, 0, TRUE);
#else
	bSuccess = CreateItem(pItemBase);
#endif
#endif
	
	if( IsPlayer() && pItemBase->GetProp() != NULL )
	{
		if( bSuccess )
		{
#ifndef __DROP_LOG
			((CUser*)this)->AddDefinedText(TID_GAME_REAPITEM, "\"%s\"", pItemBase->GetProp()->szName);
#endif // __DROP_LOG

			if( IsLootSendText( pItemBase->GetProp() ) )
				((CUser*)this)->AddChatText( TID_GAME_REAPITEM, "\"%s\"", pItemBase->GetProp()->szName );									
			
		}
		else
			((CUser*)this)->AddDefinedText( TID_GAME_LACKSPACE );
	}
	
	if( ( (CItemElem*)pItemBase )->IsLogable() && bSuccess )
	{
		switch( pItemBase->GetProp()->dwItemKind2 ) 
		{
		case IK2_FOOD:
		case IK2_MAGIC:
		case IK2_POTION:
		case IK2_REFRESHER:
			{
				if( ( (CItemElem*)pItemBase )->m_nItemNum > 9 )
				{
					LogItemInfo aLogItem;
					aLogItem.Action = "R";
					aLogItem.SendName = "GROUND";
					aLogItem.RecvName = GetName();
					aLogItem.WorldId = GetWorld()->GetID();
					aLogItem.Gold = aLogItem.Gold2 = GetGold();
					g_DPSrvr.OnLogItem( aLogItem, ( (CItemElem*)pItemBase ), ( (CItemElem*)pItemBase )->m_nItemNum );
				}
				break;
			}
		default:
			{
				LogItemInfo aLogItem;
				aLogItem.Action = "R";
				aLogItem.SendName = "GROUND";
				aLogItem.RecvName = GetName();
				aLogItem.WorldId = GetWorld()->GetID();
				aLogItem.Gold = aLogItem.Gold2 = GetGold();
				g_DPSrvr.OnLogItem( aLogItem, ( (CItemElem*)pItemBase ), ( (CItemElem*)pItemBase )->m_nItemNum );
				break;
			}
		}
	}

#endif // WorldServer
	return bSuccess;
} // SubLootDropMobSingle

// DoLootÀÇ ÇÏÀ§ - ¸÷ÀÌ ¶³¾îÆ®¸° ¾ÆÀÌÅÛÀ» ÆÄÆ¼°¡ ÀÖÀ»¶§ ÁýÀ¸·Á ÇÒ¶§ Ã³¸®ºÎ
BOOL CMover::SubLootDropMobParty( CItem *pItem, CParty *pParty )
{
	BOOL bSuccess = TRUE;;
#ifdef __WORLDSERVER
	CUser *pListMember[ 8 ];
	int	nMaxListMember = 0;
	CUser* pMember	= NULL;
	CUser* pGetUser = NULL;
	D3DXVECTOR3	vDist;
	CItemBase* pItemBase = pItem->m_pItemBase;
	
	// ¾ÆÀÌÅÛÁÝ´Â»ç¶÷ ¹Ý°æ¾È¿¡ µå´Â ¸â¹öµé¸¸ Ãß·Á³½´Ù.
	memset( pListMember, 0, sizeof(pListMember) );
	for( int i = 0; i < pParty->m_nSizeofMember; i++ )
	{
		pMember		= g_UserMng.GetUserByPlayerID( pParty->m_aMember[i].m_uPlayerId );
//		if( IsValidObj( (CObj*)pMember ) )
		// 12-3 Ë¬: ¾ÆÀÌÅÛ È¹µæÀº °°Àº ¸Ê ÀÏÁ¤ ¹Ý°æ¿¡ ¼ÓÇÑ »ç¿ëÀÚ·Î Á¦ÇÑÇØ¾ßÇÑ´Ù.
		/*  
		if( IsValidObj( (CObj*)pMember ) && GetWorld() == pMember->GetWorld() )
		{
			vDist = pMember->GetPos() - GetPos();
			fDist = D3DXVec3LengthSq( &vDist );		// ¾ÆÀÌÅÛ ÁÝ´Â»ç¶÷°ú ¸â¹ö°£ÀÇ °Å¸®.
			if( fDist < 32.0f * 32.0f )		// xx¹ÌÅÍº¸´Ù ÀÛÀ¸¸é
			{
				pListMember[ nMaxListMember++ ] = pMember;
			}
		}
		*/ //2009.01.21 // ¹Ý°æ °Ë»ç¿¡ ·¹ÀÌ¾î Ãß°¡
		if( IsValidArea( pMember, 32.0f ) )
			pListMember[ nMaxListMember++ ] = pMember;
	}

	if( nMaxListMember == 0 )
	{
		pGetUser	= (CUser*)this;
	}
	else
	{
		switch( pParty->m_nTroupeShareItem )
		{
		case 1 :	// ¼ø¼­ºÐ¹è

			{
				for( int i = 0 ; i < nMaxListMember ; i++ )
				{
					if( pParty->m_nGetItemPlayerId == pListMember[i]->m_idPlayer )
					{
						if( i + 1 >= nMaxListMember )
						{
							pGetUser = pListMember[0];
							break;												
						}
						else
						{
							pGetUser = pListMember[ i+1 ];
							break;
						}
					}
				}
				
				if( pGetUser == NULL )
				{
					pGetUser = pListMember[0];
				}
			}
			break;
		case 2 :	// ¼öµ¿ºÐ¹è : ´ÜÀå¿¡°Ô ´Ù µé¾î°¨
			{
				if( pParty->IsLeader( pListMember[0]->m_idPlayer ) )
				{
					pGetUser = pListMember[0];
				}
				else
				{
					pGetUser = (CUser*)this;
				}
			}
			break;
		case 3 :	// ·£´ýºÐ¹è : ·£´ýÇÏ°Ô µé¾î°¨
			{
				DWORD dwRand = xRandom( nMaxListMember );
				pGetUser = pListMember[dwRand];
			}
			break;
		default:	// ±âº» °³ÀÓºÐ¹è

			{
				pGetUser = (CUser*)this; 
			}
			break;
		}	// switch
	}	
	pParty->m_nGetItemPlayerId = pGetUser->m_idPlayer;

#ifdef __BAG_LOOT
	if (pGetUser->m_nSelectedBag == 0)
	{
#if defined  (__FL_FARM_STAT) || defined (__DROP_LOG)
		bSuccess = pGetUser->CreateItem(pItemBase, NULL, NULL, 0, TRUE);
#else
		bSuccess = pGetUser->CreateItem(pItemBase);
#endif
	}
	else
	{
		bSuccess = pGetUser->CreateItem2((CItemElem*)pItemBase, pGetUser->m_nSelectedBag - 1);
		if (!bSuccess)
		{
#if defined  (__FL_FARM_STAT) || defined (__DROP_LOG)
			bSuccess = pGetUser->CreateItem(pItemBase, NULL, NULL, 0, TRUE);
#else
			bSuccess = pGetUser->CreateItem(pItemBase);
#endif
		}
	}
#else
#if defined  (__FL_FARM_STAT) || defined (__DROP_LOG)
	bSuccess = pGetUser->CreateItem(pItemBase, NULL, NULL, 0, TRUE);
#else
	bSuccess = pGetUser->CreateItem(pItemBase);
#endif
#endif

	for( int i = 0; i < nMaxListMember; i++ )
	{
		pMember = pListMember[i];
		if( TRUE == pMember->IsPlayer() && pItemBase->GetProp() != NULL )
		{
			if( bSuccess )
			{
				if( pMember->m_idPlayer != pGetUser->m_idPlayer )
				{
					if( ::GetLanguage() == LANG_TWN || ::GetLanguage() == LANG_JAP || ::GetLanguage() == LANG_HK )
						( (CUser*)pMember )->AddDefinedText( TID_GAME_TROUPEREAPITEM, "\"%s\" \"%s\"", pGetUser->GetName(), pItemBase->GetProp()->szName );
					else
					{
						if( ::GetLanguage() == LANG_THA )
							( (CUser*)pMember )->AddDefinedText( TID_GAME_REAPITEM_THA, "\"%s\" \"%s\"", pGetUser->GetName(), pItemBase->GetProp()->szName );
						else
							( (CUser*)pMember )->AddDefinedText( TID_GAME_REAPITEM, "\"%s%s %s\"", pGetUser->GetName(), prj.GetText(TID_GAME_FROM2), pItemBase->GetProp()->szName );
					}
				}
#ifndef __DROP_LOG
				else
				{
					((CUser*)pGetUser)->AddDefinedText(TID_GAME_REAPITEM, "\"%s\"", pItemBase->GetProp()->szName);
				}
#endif // __DROP_LOG
			}
			else
			{
				// CreateItemÀ» ½ÇÆÐÇÔ Full
				if( pGetUser == pMember )
					( (CUser*)pGetUser )->AddDefinedText( TID_GAME_LACKSPACE );
			}
		}									
	}
	
	if( ( (CItemElem*)pItemBase )->IsLogable() && bSuccess )
	{
		switch( pItemBase->GetProp()->dwItemKind2 ) 
		{
		case IK2_FOOD:
		case IK2_MAGIC:
		case IK2_POTION:
		case IK2_REFRESHER:
			{
				if( ( ( (CItemElem*)pItemBase )->m_nItemNum ) > 9 )
				{
					LogItemInfo aLogItem;
					aLogItem.Action = "R";
					aLogItem.SendName = "GROUND";
					aLogItem.RecvName = pGetUser->GetName();
					aLogItem.WorldId = pGetUser->GetWorld()->GetID();
					aLogItem.Gold = aLogItem.Gold2 = pGetUser->GetGold();
					g_DPSrvr.OnLogItem( aLogItem, ( (CItemElem*)pItemBase ), ( (CItemElem*)pItemBase )->m_nItemNum );
				}
				break;
			}
		default:
			{
				LogItemInfo aLogItem;
				aLogItem.Action = "R";
				aLogItem.SendName = "GROUND";
				aLogItem.RecvName = pGetUser->GetName();
				aLogItem.WorldId = pGetUser->GetWorld()->GetID();
				aLogItem.Gold = aLogItem.Gold2 = pGetUser->GetGold();
				g_DPSrvr.OnLogItem( aLogItem, ( (CItemElem*)pItemBase ), ( (CItemElem*)pItemBase )->m_nItemNum );
				break;
			}
		}
	}
#endif // __WORLDSERVER
	return bSuccess;
} // SubLootDropMobParty

//
//
// DoLootÀÇ ÇÏÀ§ - ¸÷ÀÌ ¶³¾îÆ®¸° ¾ÆÀÌÅÛ ·çÆÃºÎ...
BOOL CMover::SubLootDropMob( CItem *pItem )
{
	BOOL bSuccess = TRUE;
#ifdef __WORLDSERVER
	CParty *pParty	= g_PartyMng.GetParty( m_idparty );
	if( pParty && pParty->IsMember( m_idPlayer )  )	// ÆÄÆ¼°¡ ÀÖÀ¸¹Ç·Î °æÇèÄ¡ ºÐ¹è´ë·Î ÇØ¾ßÇÔ
	{
		// ÆÄÆ¼°¡ ÀÖÀ»°æ¿ì ·çÆÃ Ã³¸®.
		bSuccess = SubLootDropMobParty( pItem, pParty );
	}
	else // ÆÄÆ¼°¡ ¾øÀ»¶§~
	{
		bSuccess = SubLootDropMobSingle( pItem );
	}
#endif	// __WORLDSERVER

	return bSuccess;
}

// DoLootÀÇ ÇÏÀ§ - ¸÷ÀÌ ¶³¾îÆ®¸°°Ô ¾Æ´Ñ! ¾ÆÀÌÅÛ·çÆÃºÎ...
BOOL CMover::SubLootDropNotMob( CItem *pItem )
{
	BOOL bSuccess = TRUE;
#ifdef __WORLDSERVER
	CItemBase* pItemBase = pItem->m_pItemBase;
	
#ifdef __BAG_LOOT
	if (this->m_nSelectedBag == 0)
	{
#if defined  (__FL_FARM_STAT) || defined (__DROP_LOG)
		bSuccess = CreateItem(pItemBase, NULL, NULL, 0, TRUE);
#else
		bSuccess = CreateItem(pItemBase);
#endif
	}
	else
	{
		bSuccess = CreateItem2((CItemElem*)pItemBase, this->m_nSelectedBag - 1);
		if (!bSuccess)
		{
#if defined  (__FL_FARM_STAT) || defined (__DROP_LOG)
			bSuccess = CreateItem(pItemBase, NULL, NULL, 0, TRUE);
#else
			bSuccess = CreateItem(pItemBase);
#endif
		}
	}
#else
#if defined  (__FL_FARM_STAT) || defined (__DROP_LOG)
	bSuccess = CreateItem(pItemBase, NULL, NULL, 0, TRUE);
#else
	bSuccess = CreateItem(pItemBase);
#endif
#endif
	if( TRUE == IsPlayer() && pItemBase->GetProp() != NULL )
	{
		if( bSuccess )
		{
#ifndef __DROP_LOG
			((CUser*)this)->AddDefinedText(TID_GAME_REAPITEM, "\"%s\"", pItemBase->GetProp()->szName);
#endif // __DROP_LOG						

			if( IsLootSendText( pItemBase->GetProp() ) )
				((CUser*)this)->AddChatText( TID_GAME_REAPITEM, "\"%s\"", pItemBase->GetProp()->szName );									
		}
		else
			((CUser*)this)->AddDefinedText( TID_GAME_LACKSPACE );
	}
	
	if( ( (CItemElem*)pItemBase )->IsLogable() && bSuccess )
	{
		switch( pItemBase->GetProp()->dwItemKind2 ) 
		{
		case IK2_FOOD:
		case IK2_MAGIC:
		case IK2_POTION:
		case IK2_REFRESHER:
			{
				if( ( (CItemElem*)pItemBase )->m_nItemNum > 9 )
				{
					LogItemInfo aLogItem;
					aLogItem.Action = "R";
					aLogItem.SendName = "GROUND";
					aLogItem.RecvName = GetName();
					aLogItem.WorldId = GetWorld()->GetID();
					aLogItem.Gold = aLogItem.Gold2 = GetGold();
					g_DPSrvr.OnLogItem( aLogItem, ( (CItemElem*)pItemBase ), ( (CItemElem*)pItemBase )->m_nItemNum );
				}
				break;
			}
		default:
			{
				LogItemInfo aLogItem;
				aLogItem.Action = "R";
				aLogItem.SendName = "GROUND";
				aLogItem.RecvName = GetName();
				aLogItem.WorldId = GetWorld()->GetID();
				aLogItem.Gold = aLogItem.Gold2 = GetGold();
				g_DPSrvr.OnLogItem( aLogItem, ( (CItemElem*)pItemBase ), ( (CItemElem*)pItemBase )->m_nItemNum );
				break;
			}
		}
	}
#endif // __WORLDSERVER
	
	return bSuccess;
} // SubLootDropNotMob

//////////////////////////////////////////////////////////////////////////
//
// ¹Ù´Ú¿¡ ¶³¾îÁø pItemÀ» °®´Â´Ù.
//
//////////////////////////////////////////////////////////////////////////
BOOL CMover::DoLoot( CItem *pItem )
{
	if( IsPlayer() == FALSE )	return FALSE;

	CItemBase* pItemBase = pItem->m_pItemBase;
	BOOL bSuccess = TRUE;

#ifdef __CLIENT	
	PLAYSND( SND_INF_GROUNDPICKUP );
#endif
	
	ItemProp *pItemProp = pItem->GetProp();
	if( pItemProp->dwItemKind1 == IK1_GOLD ) 
	{
		PickupGold( ((CItemElem*)pItemBase)->GetGold(), pItem->m_bDropMob );
	}
	else 
	{
		// <¾ÆÀÌÅÛ ·Î±× - È¹µæ>
#ifdef __WORLDSERVER
		if( pItem->m_bDropMob == TRUE ) // ¸ó½ºÅÍ°¡ ¶³¾î¶ß¸°°Í¸¸
		{
			// ¸÷ÀÌ ¶³¾îÆ®¸° ¾ÆÀÌÅÛ¿¡ ´ëÇÑ ·çÆÃ Ã³¸®
			bSuccess = SubLootDropMob( pItem );
		}
		else	// ¾î¶²À¯Àú°¡ ¶³¾î¶ß¸°°ÍÀº ÁÞÀº³ÑÀÌ ÀÓÀÚ~
		{
			// ¸÷ÀÌ ¶³¾îÆ®¸°°Ô ¾Æ´Ñ ¾ÆÀÌÅÛÀÇ ·çÆÃ¿¡ ´ëÇÑ Ã³¸®
			bSuccess = SubLootDropNotMob( pItem );

		}
#endif	// __WORLDSERVER
	}

	if( TRUE == bSuccess )
	{
		pItem->Delete();
#ifdef __WORLDSERVER
//		g_UserMng.AddMotion( this, OBJMSG_PICKUP );
		RemoveInvisible();		// ¾ÆÀÌÅÛ ÁÞÀ¸¸é Åõ¸í ÇØÁ¦.
#endif	// __WORLDSERVER
	}

	return bSuccess;
}

```
