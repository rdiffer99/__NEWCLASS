# ProjectCmn.h

Chemin original: `C:\Users\rdiff\Desktop\__NEWCLASS\_AIInterface\ProjectCmn.h`
Chemin relatif: `_AIInterface\ProjectCmn.h`
Nom du fichier: `ProjectCmn.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `latin-1`

```cpp
#ifndef __PROJECTCMN_H__
#define	__PROJECTCMN_H__

#define	MAX_OBJARRAY			8
#define	MAX_QUICKSLOT			21
#define	MAX_EQUIPMENT			18
#ifdef __TABBED_INV
#define MAX_INVENTORY_SLOT		42
#define	MAX_INVENTORY			168
#include "defineItem.h"
#else // __TABBED_INV
#ifdef __INVENTORY_168
#define	MAX_INVENTORY	168			// 60 //42
#else
#define	MAX_INVENTORY			42			// 60 //42
#endif
#endif // __TABBED_INV
#define MAX_GUILDBANK			42
#define	MAX_BANK				42
#define	MAX_REPAIR				16
#define	MAX_TRADE				25
#define	MAX_VENDITEM			30
#define	MAX_REPAIRINGITEM		25
#define	MAX_VENDORNAME			48
#define	MAX_STUFF				( MAX_INVENTORY + MAX_QUICKSLOT )
#define	MAX_EXPLPPOINT			41
#define	MAX_EXPSKILL			21
#ifdef __NEWCLASS
#define	MAX_EXPCHARACTER		300
#define	MAX_FXPCHARACTER		200
#else // __NEWCLASS
#define	MAX_EXPCHARACTER		300
#define	MAX_FXPCHARACTER		200
#endif // __NEWCLASS
#define	MAX_CHARACTER_LIST		3 
#define	MAX_VENDOR_INVENTORY	100
#define	MAX_VENDOR_INVENTORY_TAB	4
#define	MAX_QUEST				100

#if __VER >= 19
#define	MAX_COMPLETE_QUEST		500 
#else
#define	MAX_COMPLETE_QUEST		300 
#endif

#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
#define MAX_CHECKED_QUEST		5
#endif // __IMPROVE_QUEST_INTERFACE
#define MAX_PARTYLEVEL			10
#define MAX_ADDEXPPARTY			16
#define MAX_RENEWEVENT			8000
#define MAX_REALITEM			8			// ÀÌº¥Æ® »óÇ° ¾ÆÀÌÅÛ
#define MAX_EVENTREALITEM		4096
#define MAX_EXPJOBLEVEL			90
#define	ITEM_KIND_MAX			100

const int	MAX_PROPMOVER =		15000;		// MoverProp¹è¿­ÀÇ ÃÖ´ë°¹¼ö 

#define	MAX_HONOR_TITLE		150	// ´ÞÀÎÅ¸ÀÌÆ² Á¦ÇÑ

#ifdef __USER_OWN_TITLE
#define MIN_CUSTOM_TITLE 4
#define MAX_CUSTOM_TITLE 20
#endif // __USER_OWN_TITLE

#if __VER >= 8 // __S8_VENDOR_REVISION
#define MAX_VENDOR_REVISION		20
#endif //__S8_VENDOR_REVISION

#ifdef __NEW_STACKABLE_AMPS
#define MAX_AMP_STACK_COUNT	5
#endif // __NEW_STACKABLE_AMPS

#if __VER >= 18
#define MAX_QUEST_COND_KILL	 2
#endif

#define dwDestParam1	dwDestParam[0]
#define dwDestParam2	dwDestParam[1]
#define nAdjParamVal1	nAdjParamVal[0]
#define nAdjParamVal2	nAdjParamVal[1]
#define dwChgParamVal1	dwChgParamVal[0]
#define dwChgParamVal2	dwChgParamVal[1]

#ifdef __PROP_0827
#define dwDestParam3	dwDestParam[2]
#define nAdjParamVal3	nAdjParamVal[2]
#define dwChgParamVal3	dwChgParamVal[2]
#endif	// __PROP_0827

#if __VER >= 16
#define dwDestParam4	dwDestParam[3]
#define dwDestParam5	dwDestParam[4]
#define dwDestParam6	dwDestParam[5]
#define nAdjParamVal4	nAdjParamVal[3]
#define nAdjParamVal5	nAdjParamVal[4]
#define nAdjParamVal6	nAdjParamVal[5]
#define dwChgParamVal4	dwChgParamVal[3]
#define dwChgParamVal5	dwChgParamVal[4]
#define dwChgParamVal6	dwChgParamVal[5]
#endif

#if __VER >= 9
#include "defineitemkind.h"
#endif	// 

#if __VER >= 16
#include "defineAttribute.h"
#endif

#ifdef __APP_TELEPORTER
struct TeleportInfo
{
#if defined(__WORLDSERVER)
	DWORD dwWorldID;
	D3DXVECTOR3 vPos;
#elif defined(__CLIENT)
	TCHAR   szName[64];
	TCHAR   szDesc[512];
	TCHAR   szImage[64];
	DWORD dwBossID;
	DWORD dwMinLevel;
	DWORD dwMaxLevel;
	DWORD dwClassID;
	DWORD dwCoolDown;
	vector<DWORD> vDrops;
#endif
};
#endif //__APP_TELEPORTER

#ifdef __BATTLEPASS
typedef struct _BATTLE_PASS_ITEM
{
	DWORD dwItem;
	int nTime;
	int nType;

	_BATTLE_PASS_ITEM()
	{
		dwItem = 0;
		nTime = 0;
		nType = 0;
	}
} BATTLE_PASS_ITEM, * PBATTLE_PASS_ITEM;

typedef struct _BATTLE_PASS_ITEM_TEMP
{
	DWORD dwItem;
	int nTime;
	int nType;

	_BATTLE_PASS_ITEM_TEMP()
	{
		dwItem = 0;
		nTime = 0;
		nType = 0;
	}
} BATTLE_PASS_ITEM_TEMP, * PBATTLE_PASS_ITEM_TEMP;


typedef struct _BATTLE_PASS_POINTS
{
	DWORD dwItem;
	int nPointsMin;
	int nPointsMax;

	_BATTLE_PASS_POINTS()
	{
		dwItem = 0;
		nPointsMin = 0;
		nPointsMax = 0;
	}
} BATTLE_PASS_POINTS, * PBATTLE_PASS_POINTS;

typedef struct _BATTLE_PASS
{
	int nLevel;
	int nType;
	int nPoints;
	DWORD dwItem;
	//BYTE nQuantity;
	int nQuantity;
	CString strLogo;
	CString strRarity;
	CString strCustomIcon;

	_BATTLE_PASS()
	{
		nLevel = 0;
		nType = 0;
		nPoints = 0;
		dwItem = 0;
		nQuantity = 0;
		strLogo = "";
		strRarity = "";
		strCustomIcon = "";
	}
} BATTLE_PASS, * PBATTLE_PASS;

typedef struct _BATTLE_PASS_MONSTER
{
	DWORD dwID;
	int nMin;
	int nMax;

	_BATTLE_PASS_MONSTER()
	{
		dwID = 0;
		//nMin = 0;
		nMin = 0;
		nMax = 0;
	}
} BATTLE_PASS_MONSTER, * PBATTLE_PASS_MONSTER;
#endif // __BATTLEPASS

struct tagColorText
{
	DWORD dwColor;
	TCHAR * lpszData;
}; 

struct ObjProp
{
	DWORD	dwID;		// º¯¼ö¸í	
	TCHAR	szName[64];	// ÇÑ±Û¸íÄª 
	DWORD	dwType; 
	DWORD	dwAI;		// AIInterface
	DWORD	dwHP;
	ObjProp()
	{
		*szName	= '\0';
		dwID	= dwType	= dwAI	= dwHP	= 0;
	}
};

struct CtrlProp : ObjProp
{
	DWORD   dwCtrlKind1;
	DWORD   dwCtrlKind2;
	DWORD   dwCtrlKind3;
	DWORD   dwSfxCtrl;
	DWORD   dwSndDamage;
	CtrlProp() : ObjProp()
	{
		dwCtrlKind1	= dwCtrlKind2	= dwCtrlKind3	= dwSfxCtrl	= dwSndDamage	= 0;
	}

#if __VER >= 15 // __GUILD_HOUSE
	BOOL IsGuildHousingObj( )	{ return CK1_GUILD_HOUSE == dwCtrlKind1; } //±æµå ÇÏ¿ìÂ¡ Àü¿ë ¿ÀºêÁ§Æ® ÀÎ°¡?
	BOOL IsHousingObj( )		{ return CK1_HOUSING == dwCtrlKind1; }		//°³ÀÎ ÇÏ¿ìÂ¡ Àü¿ë ¿ÀºêÁ§Æ® 
#endif // __GUILD_HOUSE
};

struct AddSkillProp
{
	DWORD	dwID;				// º¯¼ö¸í	
	DWORD	dwName;				// ¸íÄª
	DWORD	dwSkillLvl;			// ½ºÅ³·¹º§
	DWORD	dwAbilityMin;		// ÃÖ¼Ò´É·Â
	DWORD	dwAbilityMax;		// ÃÖ´ë´É·Â
	DWORD	dwAttackSpeed;		// °ø°Ý¼Óµµ
	DWORD	dwDmgShift;			// Å¸°Ý½Ã ¹Ýµ¿
	DWORD	nProbability;		// ¹ßµ¿ È®·ü
	DWORD	dwTaunt;			// Å¸¿îÆ®
	DWORD	dwDestParam[2];		// Àû¿ë´ë»ó1
	DWORD	nAdjParamVal[2];	// Àû¿ë°ª1;
	DWORD	dwChgParamVal[2];	//Àû¿ëº¯È­°ª1
	int		nDestData1[3];		// Àû¿ëµ¥ÀÌÅ¸3°³, DestParam[0]¿¡ ÇØ´ç.
	DWORD	dwActiveSkill;		// ¹ßµ¿ ¸¶¹ý
	DWORD	dwActiveSkillRate;	// ¹ßµ¿ ¸¶¹ý È®·ü.
#if __VER >= 9	// __SKILL_0706
	DWORD	dwActiveSkillRatePVP;	// ´ëÀÎ ¹ßµ¿ ¸¶¹ý È®·ü.
#endif	// __SKILL_0706
	int		nReqMp;				//ÇÊ¿äMP
	int		nReqFp;				//ÇÊ¿äFP
#if __VER >= 9	// __SKILL_0706
	DWORD	dwCooldown;		// Äð´Ù¿î
	DWORD	dwCastingTime;		//±â¼ú ÁØºñ½Ã°£
#else	// __SKILL_0706
	DWORD	dwSkillReady;		//±â¼ú ÁØºñ½Ã°£
#endif	// __SKILL_0706
	DWORD	dwSkillRange;		// ±â¼ú ½ÃÀü°Å¸®	
	DWORD	dwCircleTime;		//À¯Áö½Ã°£
	DWORD   dwPainTime;         // Áö¼Ó ÇÇÇØ½Ã°£
	DWORD	dwSkillTime;		//Áö¼Ó½Ã°£
	int		nSkillCount;		// ¹ß»çÃ¼ ¹ß»ç °³¼ö. °³´ç°ø°Ý·Â = ÃÑ°ø°Ý·Â / nSkillCount;
	DWORD   dwSkillExp;         //½ºÅ³ °æÇèÄ¡
	DWORD	dwExp;				//ÇöÀç°æÇèÄ¡
	DWORD	dwComboSkillTime;	//ÄÞº¸½ºÅ³Å¸ÀÓ
#if __VER >= 9	// __SKILL_0706
	DWORD	dwAbilityMinPVP;	// ÃÖ¼Ò´É·Â(´ëÀÎ)
	DWORD	dwAbilityMaxPVP;	// ÃÖ´ë´É·Â(´ëÀÎ)
	DWORD	nProbabilityPVP;	// ¹ßµ¿ È®·ü(´ëÀÎ)
#endif	// __SKILL_0706
#ifdef __MINES_BOMBS
	DWORD dwBombMine;
	DWORD dwBombExplodeTimer;
#endif //__MINES_BOMBS
	AddSkillProp()
	{
		dwID = dwName = 0;
		nProbability = 0;
		dwSkillLvl = dwAbilityMin = dwAbilityMax = dwAttackSpeed = dwDmgShift = dwTaunt = 0;
		dwDestParam[0] = dwDestParam[1] = nAdjParamVal[0] = nAdjParamVal[1] = dwChgParamVal[0] = dwChgParamVal[1] = 0;
		nReqMp = nReqFp = 0;
		dwActiveSkillRate	= 0;
#if __VER >= 9	// __SKILL_0706
		dwCastingTime	= 0;
		dwAbilityMinPVP		= 0;
		dwAbilityMaxPVP		= 0;
		dwCooldown	= 0;
		nProbabilityPVP	= 0;
		dwActiveSkillRatePVP	= 0;
#else	// __SKILL_0706
		dwSkillReady = 0;
#endif	// __SKILL_0706
		dwCircleTime = dwSkillTime = dwExp = dwComboSkillTime = 0;
#ifdef __MINES_BOMBS
		dwBombMine = NULL_ID;
		dwBombExplodeTimer = NULL_ID;
#endif //__MINES_BOMBS	
	}
};

struct PartySkillProp
{
	DWORD	dwID;				// º¯¼ö¸í	
	DWORD	dwName;				// ¸íÄª
	DWORD	dwSkillLvl;			// ½ºÅ³·¹º§
	DWORD	dwAbilityMin;		// ÃÖ¼Ò´É·Â
	DWORD	dwAtkAbilityMax;	// ÃÖ´ë´É·Â
	DWORD	dwAttackSpeed;		// °ø°Ý¼Óµµ
	DWORD	dwDmgShift;			// Å¸°Ý½Ã ¹Ýµ¿
	DWORD	dwGroggy;			// ±×·ÎÅ°
	DWORD	dwTaunt;			// Å¸¿îÆ®
	DWORD	dwDestParam[2];		// Àû¿ë´ë»ó1
	DWORD	nAdjParamVal[2];	// Àû¿ë°ª1;
	DWORD	dwChgParamVal[2];	//Àû¿ëº¯È­°ª1
	DWORD	dwReqMp;			//ÇÊ¿äMP
	DWORD	dwReqFp;			//ÇÊ¿äFP
	DWORD	dwSkillReady;		//±â¼ú ÁØºñ½Ã°£
	DWORD	dwCircleTime;		//À¯Áö½Ã°£
	DWORD	dwSkillTime;		//Áö¼Ó½Ã°£
	DWORD	dwExp;				//ÇöÀç°æÇèÄ¡
	DWORD	dwComboSkillTime;	//ÄÞº¸½ºÅ³Å¸ÀÓ
	PartySkillProp()
	{
		dwID = dwName = 0;
		dwSkillLvl = dwAbilityMin = dwAtkAbilityMax = dwAttackSpeed = dwDmgShift = dwGroggy = dwTaunt = 0;
		dwDestParam[0] = dwDestParam[1] = nAdjParamVal[0] = nAdjParamVal[1] = dwChgParamVal[0] = dwChgParamVal[1] = 0;
		dwReqMp = dwReqFp = dwSkillReady = 0;
		dwCircleTime = dwSkillTime = dwExp = dwComboSkillTime = 0;
	}
};

enum 
{	
	FILE_FILTER	= 0, 
	FILE_INVALID = 1, 
	FILE_NOTICE = 2,	
	FILE_GUILDCOMBAT_TEXT_1 = 3, 
	FILE_GUILDCOMBAT_TEXT_2 = 4, 
	FILE_GUILDCOMBAT_TEXT_3 = 5, 
	FILE_GUILDCOMBAT_TEXT_4 = 6, 
	FILE_GUILDCOMBAT_TEXT_5 = 7,
	FILE_GUILDCOMBAT_TEXT_6 = 8
#ifdef __RULE_0615
	,FILE_ALLOWED_LETTER	= 9
#endif	// __RULE_0615
#if __VER >= 11 // __GUILD_COMBAT_1TO1
	,
	FILE_GUILDCOMBAT_1TO1_TEXT_1 = 10,
	FILE_GUILDCOMBAT_1TO1_TEXT_2 = 11,
	FILE_GUILDCOMBAT_1TO1_TEXT_3 = 12,
	FILE_GUILDCOMBAT_1TO1_TEXT_4 = 13,
	FILE_GUILDCOMBAT_1TO1_TEXT_5 = 14
#endif //__GUILD_COMBAT_1TO1
#ifdef __VENDOR_1106
	,FILE_ALLOWED_LETTER2	= 15
#endif	// __VENDOR_1106
};

// Item Property Type
enum IP_TYPE 
{
	IP_FLAG_NONE	= 0x00,				// ÇÃ·¡±× ¾øÀ½ 
	IP_FLAG_BINDS	= 0x01,				// 1 - ±Í¼Ó ¾ÆÀÌÅÛ 
	IP_FLAG_UNDESTRUCTABLE	= 0x02	//	2 - »èÁ¦ ºÒ°¡ ¾ÆÀÌÅÛ
#if __VER >= 14 // __EQUIP_BIND
	,IP_FLAG_EQUIP_BIND	= 0x04
#endif // __EQUIP_BIND
//	0x04
};

#ifdef __ORIGIN_CARD_SYSTEM
struct CardProp
{
	DWORD	dwCardID;
	DWORD	dwRarety;
	int		nStr;
	int		nSta;
	int		nDex;
	int		nInt;
	TCHAR	szCardImage[64];
};
#endif // __ORIGIN_CARD_SYSTEM

#ifdef __DPSMETER_RYU
struct DPSProp
{
	DWORD	dwID;
};
#endif // __DPSMETER_RYU
struct ItemProp : CtrlProp
{
	DWORD	dwMotion;			// µ¿ÀÛ 
	DWORD	dwNum;				// ±âº»»ý¼º°³¼ö	
	DWORD	dwPackMax;			// ÃÖ´ëÈÄ§°³¼ö	
	DWORD	dwItemKind1;		// 1Â÷¾ÆÀÌÅÛÁ¾·ù	
	DWORD	dwItemKind2;		// 2Â÷¾ÆÀÌÅÛÁ¾·ù	
	DWORD	dwItemKind3;		// 3Â÷¾ÆÀÌÅÛÁ¾·ù	
	DWORD	dwItemJob;			// ¾ÆÀÌÅÛÁ÷¾÷¼Ò¼Ó 
	BOOL	bPermanence;		// ¼ÒºñºÒ°¡	
	DWORD	dwUseable;			// »ç¿ë½ÃÁ¡	
	DWORD	dwItemSex;			// »ç¿ë¼ºº°	
	DWORD	dwCost;				// °¡°Ý	 
	DWORD	dwEndurance;		// ³»±¸·Â	
	int		nLog;				// ·Î±×
	int		nAbrasion;			// ¸¶¸ðÀ²
	int		nMaxRepair;			// ¼ö¸®È½¼ö
	DWORD	dwHanded;			// Àâ´ÂÇü½Ä	
	DWORD	dwFlag;				// ´Ù¸ñÀû ÇÃ·¡±×	
	DWORD	dwParts;			// ÀåÂøÀ§Ä¡	
	DWORD	dwPartsub;			// ÀåÂøÀ§Ä¡	
	DWORD	bPartsFile;			// ÆÄÃ÷ÆÄÀÏ »ç¿ë¿©ºÎ 
	DWORD	dwExclusive;		// Á¦°ÅµÉÀ§Ä¡	
	DWORD	dwBasePartsIgnore;
	DWORD	dwItemLV;			// ¾ÆÀÌÅÛ·¹º§	
	DWORD	dwItemRare;			// Èñ±Í¼º	
	DWORD   dwShopAble;
	int		nShellQuantity;		// ÃÖ´ëÀåÀü°³¼ö	- IK°¡ Ã¤Áýµµ±¸ÀÏ¶§´Â ÃÖ´ë Ã¤Áý·®ÀÌ µÈ´Ù.(»èÁ¦ ¿¹Á¤)
	DWORD	dwActiveSkillLv;	// ¹ßµ¿ ¸¶¹ý ·¹º§
	DWORD   dwFuelRe;			// ÆÑ´ç¿¬·áÃæÀü·®
	DWORD	dwAFuelReMax;		// °¡¼Ó¿¬·áÃæÀü·®
	DWORD	dwSpellType;		// ¸¶¹ý¼Ó¼º	
	DWORD	dwLinkKindBullet;	// ÇÊ¿ä ¼Ò¸ðÀåºñ ¾ÆÀÌÅÛ	
	DWORD	dwLinkKind;			// ÇÊ¿ä ¾ÆÀÌÅÛÁ¾·ù
	DWORD	dwAbilityMin;		// ÃÖ¼Ò´É·ÂÄ¡ - °ø°Ý·Â, ¹æ¾î·Â, ¼º´É ±âÅ¸µîµî 
	DWORD	dwAbilityMax;		// ÃÖ´ë´É·ÂÄ¡ - °ø°Ý·Â, ¹æ¾î·Â, ¼º´É ±âÅ¸µîµî 
	BOOL	bCharged;		
	SAI79::ePropType	eItemType;
	short	wItemEatk;			// ¼Ó¼º µ¥¹ÌÁö( À§ ¼Ó¼º Å¸ÀÔÀ¸·Î °ø°Ý·ÂÀ» ¼³Á¤ÇÑ´Ù. )
	DWORD   dwParry;			// È¸ÇÇÀ² 
	DWORD   dwblockRating;		// ºí·° ¼öÄ¡ 
	int		nAddSkillMin;		// ÃÖ¼Ò Ãß°¡ ½ºÅ³
	int		nAddSkillMax;		// ÃÖ´ë Ãß°¡ ½ºÅ³.
	DWORD	dwAtkStyle;			// °ø°Ý ½ºÅ¸ÀÏ 
	DWORD	dwWeaponType;		// ¹«±âÁ¾·ù 
	DWORD	dwItemAtkOrder1;	// ¾ÆÀÌÅÛ1Â÷°ø°Ý¼ø¼­
	DWORD	dwItemAtkOrder2;	// ¾ÆÀÌÅÛ2Â÷°ø°Ý¼ø¼­
	DWORD	dwItemAtkOrder3;	// ¾ÆÀÌÅÛ3Â÷°ø°Ý¼ø¼­
	DWORD	dwItemAtkOrder4;	// ¾ÆÀÌÅÛ4Â÷°ø°Ý¼ø¼­
    DWORD	tmContinuousPain;	// Áö¼Ó ÇÇÇØ 
	DWORD	dwRecoil;			// ¹Ýµ¿	
	DWORD	dwLoadingTime;		// ÀåÀü½Ã°£	- IK°¡ Ã¤Áýµµ±¸ÀÏ¶§´Â Ã¤Áý¼Óµµ(´É·Â)ÀÌ µÈ´Ù.
	LONG	nAdjHitRate;		// Ãß°¡°ø°Ý¼º°ø·ü	
	FLOAT	fAttackSpeed;		// °ø°Ý¼Óµµ	
	DWORD	dwDmgShift;			// Å¸°Ý½Ã ¹Ýµ¿	
	DWORD	dwAttackRange;		// °ø°Ý¹üÀ§	
	int		nProbability;		// Àû¿ëÈ®·ü
#if __VER >= 16
	DWORD	dwDestParam[6];		// Àû¿ë´ë»ó1	
	LONG	nAdjParamVal[6];	// Àû¿ë°ª1	
	DWORD	dwChgParamVal[6];	// Àû¿ëº¯È­°ª1
#else
#ifndef __PROP_0827
	DWORD	dwDestParam[2];		// Àû¿ë´ë»ó1	
	LONG	nAdjParamVal[2];	// Àû¿ë°ª1	
	DWORD	dwChgParamVal[2];	// Àû¿ëº¯È­°ª1	
#else	// __PROP_0827
	DWORD	dwDestParam[3];		// Àû¿ë´ë»ó1	
	LONG	nAdjParamVal[3];	// Àû¿ë°ª1	
	DWORD	dwChgParamVal[3];	// Àû¿ëº¯È­°ª1	
#endif	// __PROP_0827
#endif
	int		nDestData1[3];		// Àû¿ëµ¥ÀÌÅ¸°ª 3°³, destParam1¿¡¸¸ ÇØ´çµÊ.
	DWORD	dwActiveSkill;		// ¹ßµ¿ ¸¶¹ý
	DWORD	dwActiveSkillRate;	// ¹ßµ¿ ¸¶¹ý È®·ü.
	DWORD	dwReqMp;			// ÇÊ¿äMP	
	DWORD	dwReqFp;			// ÇÊ¿äFP	
	DWORD	dwReqDisLV;
	DWORD   dwReSkill1;
	DWORD   dwReSkillLevel1;
	DWORD   dwReSkill2;
	DWORD   dwReSkillLevel2;
	DWORD	dwSkillReadyType;
	DWORD	dwSkillReady;		// ±â¼ú ÁØºñ½Ã°£	
	DWORD	_dwSkillRange;		// ±â¼ú ½ÃÀü°Å¸®	
	DWORD	dwSfxElemental;
	DWORD	dwSfxObj;			// »ý¼ºÇÒ È¿°ú ¿ÀºêÁ§Æ® 
	DWORD	dwSfxObj2;			// »ý¼ºÇÒ È¿°ú ¿ÀºêÁ§Æ® 
	DWORD	dwSfxObj3;			// ¹ßµ¿È¿°ú, Å¸°Ù
	DWORD	dwSfxObj4;			// Áö¼ÓµÇ´Â È¿°ú ÀÌÆåÆ®.
	DWORD	dwSfxObj5;			// ¹ßµ¿È¿°ú, ½ÃÀüÀÚ 
	DWORD	dwUseMotion;		// »ç¿ë ¸ð¼Ç
	DWORD	dwCircleTime;		// À¯Áö½Ã°£ 
	DWORD	dwSkillTime;		// Áö¼Ó½Ã°£	
	DWORD	dwExeTarget;
	DWORD	dwUseChance;
	DWORD	dwSpellRegion;		// ¸¶¹ý ¹üÀ§ 
	DWORD   dwReferStat1;
	DWORD   dwReferStat2;
	DWORD   dwReferTarget1;
	DWORD   dwReferTarget2;
	DWORD   dwReferValue1;
	DWORD   dwReferValue2;
	DWORD	dwSkillType;		// ±â¼ú¼Ó¼º	
	int		nItemResistElecricity;
	int		nItemResistDark;
	int		nItemResistFire;
	int		nItemResistWind;
	int		nItemResistWater;
	int		nItemResistEarth;
	LONG	nEvildoing;			// ¾ÇÇà	
	DWORD	dwExpertLV;	
	DWORD	dwExpertMax;		// ÃÖ´ë¼÷·Ã·¹º§ 
	DWORD	dwSubDefine;
	DWORD	dwExp;				// ÇöÀç°æÇèÄ¡	
	DWORD	dwComboStyle;
	FLOAT	fFlightSpeed;		// ºñÇàÃßÁø·Â(¼Óµµ)
	FLOAT	fFlightLRAngle;		// ÁÂ¿ì ÅÏ °¢µµ.
	FLOAT	fFlightTBAngle;		// »óÇÏ ÅÏ °¢µµ.
	DWORD	dwFlightLimit;		// ºñÇàÁ¦ÇÑ·¹º§
	DWORD	dwFFuelReMax;		// ºñÇà¿¬·áÃæÀü·®
	DWORD	dwLimitLevel1;		// Á¦ÇÑ·¹º§1
	int		nReflect;			// ¸®ÇÃ·º¼Ç ¿É¼Ç.
	DWORD	dwSndAttack1;		// È¿°úÀ½ : °ø°Ý 1
	DWORD	dwSndAttack2;		// È¿°úÀ½ : °ø°Ý 2
	DWORD	dwQuestId;
	TCHAR	szTextFileName[64];	// item¿¡ GM command¿¡ ³Ö´Â °Í¿¡ »ç¿ë

#ifdef __CLIENT
    TCHAR	szIcon[64];			// ddsÆÄÀÏ ÀÌ¸§ 
	TCHAR	szCommand[256];		// ¼³¸í¹® 
#endif
	int		nVer;

#ifdef __VERIFY_0201
	TCHAR	szIcon[64];
	TCHAR	szCommand[256];		// ¼³¸í¹® 
#endif	// __VERIFY_0201

#if __VER >= 16
	// CProject::LoadPropItem
	int		nMinLimitLevel;
	int		nMaxLimitLevel;
	int		nItemGroup;
	int		nUseLimitGroup;
	int		nMaxDuplication;
	int		nEffectValue;
	int		nTargetMinEnchant;
	int		nTargetMaxEnchant;
	BOOL	bResetBind;
	int		nBindCondition;
	int		nResetBindCondition;
	DWORD	dwHitActiveSkillId;
	DWORD	dwHitActiveSkillLv;
	DWORD	dwHitActiveSkillProb;
	DWORD	dwHitActiveSkillTarget;
	DWORD	dwDamageActiveSkillId;
	DWORD	dwDamageActiveSkillLv;
	DWORD	dwDamageActiveSkillProb;
	DWORD	dwDamageActiveSkillTarget;
	DWORD	dwEquipActiveSkillId;
	DWORD	dwEquipActiveSkillLv;
	DWORD	dwSmelting;
	DWORD	dwAttsmelting;
	DWORD	dwGemsmelting;
	DWORD	dwPierce;
	DWORD	dwUprouse;
	BOOL	bAbsoluteTime;

	// CProject::LoadPropItemEx
	DWORD	dwBuffTickType;
#endif

#if __VER >= 18
	// CProject::LoadPropItem
	DWORD   dwItemGrade;
	BOOL	bCanTrade;
	DWORD   dwMainCategory;
	DWORD   dwSubCategory;
	BOOL    bCanHaveServerTransform;
	BOOL	bCanSavePotion;
	
	// CProject::LoadPropItemEx

#endif

#if __VER >= 16
	// CProject::LoadPropItem
	BOOL	bCanLooksChange;
	BOOL	bIsLooksChangeMaterial;
	
	// CProject::LoadPropItemEx

	BOOL	bCanUseActionSlot;
	DWORD   dwMonsterGrade;
	DWORD   dwEquipItemKeepSkill;

#endif
	DWORD	GetCoolTime()  { return dwSkillReady; }
#if __VER >= 9	// __ULTIMATE
	BOOL	IsUltimate( void )
		{
			return( 
					(
						dwItemKind2 == IK2_WEAPON_DIRECT
						|| dwItemKind2 == IK2_WEAPON_MAGIC
					)
				&& dwReferStat1 == WEAPON_ULTIMATE
			);
		}
#endif	//
#ifdef __NEW_ITEM_VARUNA
	BOOL IsBaruna( void )
	{
		return( dwReferStat1 >= BARUNA_D && dwReferStat1 <= BARUNA_S );
	}
#endif // __NEW_ITEM_VARUNA
#ifdef __NEW_STACKABLE_AMPS
	BOOL IsExperienceScroll( void )
	{
		return( dwItemKind3 == IK3_EXP_RATE );
	}
#endif // __NEW_STACKABLE_AMPS
#if __VER >= 15 // __PETVIS
	BOOL	IsVisPet()	{ return (dwItemKind3 == IK3_PET) && (dwReferStat1 == PET_VIS); }
	BOOL	IsVis()		{ return (dwItemKind3 == IK3_VIS ); }
#ifdef __CLIENT
	BOOL	IsVisKey()	{ return (II_SYS_SYS_VIS_KEY01 == dwID ); }
	BOOL	IsPickupToBuff( ) { return ( II_SYS_SYS_SCR_PET_MAGIC == dwID ); }
#endif //__CLIENT
#endif // __PETVIS
#ifdef __TABBED_INV //Tab Sort
	int GetInvenIndex()
	{
		int nIndex = 0;
		switch (dwID)
		{
		case II_SYS_SYS_SCR_PETAWAKE:
		case II_SYS_SYS_SCR_PETAWAKECANCEL:
		case II_SYS_SYS_SCR_PET_MAGIC:
		case II_SYS_SYS_VIS_KEY01:
		case II_SYS_SYS_SCR_PET_HATCH:
		case II_SYS_SYS_SCR_EATPETAWAKE: nIndex = 1; break;

		case II_SYS_SYS_SCR_BLESSEDNESS:
		case II_SYS_SYS_SCR_BLESSEDNESS02: nIndex = 2; break;

		case II_SYS_SYS_QUE_ANGEL_RED100:
		case II_SYS_SYS_QUE_ANGEL_BLUE100:
		case II_SYS_SYS_QUE_ANGEL_GREEN100:
		case II_SYS_SYS_QUE_ANGEL_WHITE100: nIndex = 3; break;

		default:
		{
			switch (dwItemKind3)
			{
			case IK3_SUMMON_NPC:
			case IK3_PET:
			case IK3_EGG:
			case IK3_FEED:
			case IK3_GEM:
			case IK3_VIS: nIndex = 1; break;

			case IK3_GLOVE:
			case IK3_CLOTH:
			case IK3_CLOAK:
			case IK3_SHOES:
			case IK3_MASK:
			case IK3_ANI_WING:
			case IK3_WINGSFX:
			case IK3_ANIHAT:
			case IK3_HAT: nIndex = 2; break;

			case IK3_CURRENCY:	nIndex = 3; break;

			default: nIndex = 0; break;
	}
			}
		}
		return nIndex;
	}
#endif // __TABBED_INV
#ifdef __MAP_TORCH_SYSTEM
	BOOL IsMapTorchScroll(void) { return(dwItemKind3 == IK3_MAPOPEN_DUNGEON); }
#endif // __MAP_TORCH_SYSTEM
#ifdef __INSTANCE_AGGRO_SYSTEM
	BOOL IsDebuff()
	{
		if (   nEvildoing != 1
			&& dwReferTarget1 != RT_ATTACK
			&& dwReferTarget2 != RT_ATTACK )
			return TRUE;
		else
			return FALSE;
	}
	BOOL IsBuff()
	{
		return( nEvildoing == 1 );
	}
	BOOL IsHeal()
	{
		return( dwReferTarget1 == RT_HEAL );
	}
	BOOL IsAlwaysAggro()
	{
		return ( dwID == 400 );
	}
#endif // __INSTANCE_AGGRO_SYSTEM
};

// Á÷¾÷¿¡ µû¸¥ factor ENUM
enum JOB_PROP_TYPE
{
	JOB_PROP_SWD,
	JOB_PROP_AXE,	
	JOB_PROP_STAFF,
	JOB_PROP_STICK,
	JOB_PROP_KNUCKLE,
	JOB_PROP_WAND,
	JOB_PROP_BLOCKING,
	JOB_PROP_YOYO,
	JOB_PROP_CRITICAL,
};

// Á÷¾÷¿¡ µû¸¥ ÇÁ·ÎÆÛÆ¼ ( propJob.inc¿¡¼­ ÀÐ¾îµéÀÓ )
struct JobProp
{
	float	fAttackSpeed;			//°ø¼Ó 
	float	fFactorMaxHP;			//ÃÖ´ë HP °è»ê¿¡ »ç¿ëµÇ´Â factor
	float	fFactorMaxMP;			//ÃÖ´ë MP °è»ê¿¡ »ç¿ëµÇ´Â factor
	float	fFactorMaxFP;			//ÃÖ´ë FP °è»ê¿¡ »ç¿ëµÇ´Â factor
	float   fFactorDef;				//¹°¸® ¹æ¾î·Â °è»ê¿¡ »ç¿ëµÇ´Â factor
	float	fFactorHPRecovery;		//HPÈ¸º¹ factor
	float	fFactorMPRecovery;		//MPÈ¸º¹ factor
	float	fFactorFPRecovery;		//FPÈ¸º¹ factor
	float	fMeleeSWD;				//WT_MELEE_SWDÀÇ ATK factor
	float	fMeleeAXE;				//WT_MELEE_AXEÀÇ ATK factor
	float   fMeleeSTAFF; 			//WT_MELEE_STAFFÀÇ ATK factor
	float   fMeleeSTICK;			//WT_MELEE_STICKÀÇ ATK factor
	float   fMeleeKNUCKLE;			//WT_MELEE_KNUCKLEÀÇ ATK factor
	float   fMagicWAND;				//WT_MAGIC_WANDÀÇ ATK factor 
	float   fBlocking;				//ºí·ÏÅ· factor
	float	fMeleeYOYO;				//¿ä¿äÀÇ ATK factor 
	float   fCritical;				//Å©¸®Æ¼ÄÃ Ã³¸®
	float   fBow;					// BOW factor
#if __VER >= 16
	TCHAR	szJobIcon[64];
#endif
};

typedef	struct	tagRANDOM_ITEM
{
	BYTE	m_lpQuestFlagArray[ITEM_KIND_MAX / 8 + 1];

	void	SetItemKind( int nItemKind,BOOL bBool );
	BOOL	IsItemKind( int nItemKind );

	BYTE	m_nTotalNum;	// ¹ß»ý ¾ÆÀÌÅÛ °¹¼ö 
	BYTE	m_nUniqueMax;	// À¯´ÏÅ© ¾ÆÀÌÅÛ ÃÖ´ë 
	BYTE	m_nUniqueMin;	// À¯´ÏÅ© ¾ÆÀÌÅÛ ÃÖ¼Ò  
	WORD	m_nGoldMax;		// °ñµå ¸Æ½º 
	WORD	m_nAmmoMax;		// ÃÑ¾Ë ¸Æ½º 
	WORD	m_nDartMax;		// Ç¥Ã¢ ¸Æ½º 
	WORD	m_nGoldMin;		// °ñµå ¸Æ½º 
	WORD	m_nAmmoMin;	// ÃÑ¾Ë ¸Æ½º 
	WORD	m_nDartMin;	// Ç¥Ã¢ ¸Æ½º 
	tagRANDOM_ITEM()
	{
		m_nTotalNum		= 0;
		m_nUniqueMax	= 0;
		m_nUniqueMin	= 0;
		m_nGoldMax		= 0;
		m_nAmmoMax		= 0;
		m_nDartMax		= 0;
		m_nGoldMin		= 0;
		m_nAmmoMin		= 0;
		m_nDartMin		= 0;
	}
}
RANDOM_ITEM,* LPRANDOM_ITEM;

/*----------------------------------------------------------------------------------------------------*/
enum DROPTYPE
{
	DROPTYPE_NORMAL,
	DROPTYPE_SEED,
};

typedef struct	tagDROPITEM
{
	DROPTYPE	dtType;
	DWORD	dwIndex;
	DWORD	dwProbability;
	DWORD	dwLevel;
	DWORD	dwNumber;
	DWORD	dwNumber2;	// Min, MaxÁß Max·Î ¾¸.
}
DROPITEM,	*LPDROPITEM;

typedef	struct	tagDROPKIND
{
	DWORD	dwIK3;
	short	nMinUniq;
	short	nMaxUniq;
}
DROPKIND,	*LPDROPKIND;

typedef	struct	tagQUESTITEM
{
	DWORD	dwQuest;
	DWORD   dwState;
	DWORD	dwIndex;
	DWORD	dwProbability;
	DWORD	dwNumber; 
}
QUESTITEM,	*PQUESTITEM;

typedef struct tagEVENTITEM
{
	DWORD	dwIndex;
	DWORD	dwPrabability;
}
EVENTITEM,	*PEVENTITEM;

#define MAX_QUESTITEM	16
#define	MAX_DROPKIND	80

class CDropItemGenerator
{
private:
	vector<DROPITEM>	m_dropItems;

public:
	DWORD				m_dwMax;

public:
//	Contructions
	CDropItemGenerator() { m_dwMax = 0; }
	virtual	~CDropItemGenerator()	{	Clear();	}

//	Operations
	void		AddTail( CONST DROPITEM & rDropItem, const char* s );
	void	Clear( void )	{	m_dropItems.clear();	}
	DWORD		GetSize( void )	{	return m_dropItems.size();	}
	DROPITEM*	GetAt( int nIndex, BOOL bUniqueMode, float fProbability = 0.0f );
};

class CDropKindGenerator
{
private:
	int		m_nSize;
	DROPKIND	m_aDropKind[MAX_DROPKIND];
public:
//	Contructions
	CDropKindGenerator()
		{	m_nSize	= 0;	}
	virtual	~CDropKindGenerator()	{}
//	Operations
	void	AddTail( const DROPKIND & rDropKind );	// memcpy
	int		GetSize( void )		{	return m_nSize;	}
	LPDROPKIND	GetAt( int nIndex );
};

class CQuestItemGenerator
{
private:
	u_long	m_uSize;
	QUESTITEM	m_pQuestItem[MAX_QUESTITEM];
public:
	CQuestItemGenerator()
		{	m_uSize	= 0;	}
	~CQuestItemGenerator()	{}
	void	AddTail( const QUESTITEM & rQuestItem );
	u_long	GetSize( void )	{	return m_uSize;	}
	QUESTITEM*	GetAt( int nIndex );
};

#if __VER >= 14 // __INSTANCE_DUNGEON
struct MonsterTransform
{
	float fHPRate;
	DWORD dwMonsterId;
	MonsterTransform() : fHPRate( 0.0f ), dwMonsterId( NULL_ID ) {}
};
#endif // __INSTANCE_DUNGEON
/*----------------------------------------------------------------------------------------------------*/
#ifdef __NEW_BOSSMECHANICS
struct BOSSATTACK
{
	DWORD skillID;
	int AttackType;
	int HitType;
	bool randomizedDelay;
	DWORD stormSkillID;
	int ApplyType;
};

struct BOSSMECHANICS
{
	vector<BOSSATTACK> attacks;
	bool randomized;
	bool hasBossAttacks = false;
};
#endif //__NEW_BOSSMECHANICS
struct MoverProp : CtrlProp
{
	DWORD	dwStr;	// Èû,                  
	DWORD	dwSta;	// Ã¼·Â,
	DWORD	dwDex;	// ¹ÎÃ¸,
	DWORD	dwInt;	// Áö´É,
	DWORD	dwHR;
	DWORD   dwER;
	DWORD	dwRace;		// Á¾Á·,
	DWORD	dwBelligerence;		// È£Àü¼º,
	DWORD	dwGender;	// ¼ºº°,
	DWORD	dwLevel;	// ·¹º§,
	DWORD	dwFlightLevel;	// ºñÇà·¹º§
	DWORD	dwSize;		// Å©±â,
	DWORD   dwClass;
	BOOL	bIfParts;	// ÆÄÃ÷³Ä?
	int		nChaotic;	// ³ª»Û³ð ¸¶ÀÌ³Ê½º/ ÁÁÀº³Ñ ÇÃ·¯½º
#ifdef __S1108_BACK_END_SYSTEM
	DWORD	dwUseable;	// ¹æ¾î Ä³¸¯¼ö,
#else // __S1108_BACK_END_SYSTEM
	DWORD	dwDefExtent;	// ¹æ¾î Ä³¸¯¼ö,
#endif // __S1108_BACK_END_SYSTEM
	DWORD	dwActionRadius;		// ÀüÅõÇàµ¿¹ø°æ,
	DWORD	dwAtkMin;	// ÃÖ¼ÒÅ¸°ÝÄ¡,
	DWORD	dwAtkMax;	// ÃÖ´ëÅ¸°ÝÄ¡,
	DWORD	dwAtk1;
	DWORD	dwAtk2;
	DWORD	dwAtk3;
	DWORD	dwAtk4;		// dwHorizontalRate°¡ ÀÌ°É·Î ¹Ù²ñ.
#if __VER >= 9	//__AI_0509
	FLOAT	fFrame;	// ÀÌµ¿ ½Ã ÇÁ·¹ÀÓ °¡ÁßÄ¡
	DWORD	dwOrthograde;
#else	// __AI_0509
	DWORD	dwVerticalRate;		// ¼¼·ÎºñÀ²,
	DWORD	dwDiagonalRate;		// »ç¼±ºñÀ²,
#endif	// __AI_0509
	DWORD	dwThrustRate;	// Âî¸£±âºñÀ²,

	DWORD	dwChestRate;
	DWORD	dwHeadRate;  
	DWORD	dwArmRate;
	DWORD	dwLegRate;

	DWORD	dwAttackSpeed;	// °ø°Ý¼Óµµ,
	DWORD	dwReAttackDelay;
#ifdef __NO_HP_DMG_LIMIT
	unsigned long long 	dwAddHp;
#else
	int	dwAddHp;		// ,
#endif
	DWORD	dwAddMp;		// ,
	DWORD	dwNaturalArmor;	// ÀÚ¿¬¹æ¾î·Â 
	int		nAbrasion;	// ¸¶¸ðµµ
	int		nHardness;	// °æµµ
	DWORD	dwAdjAtkDelay;	// Ãß°¡°ø°Ý¼ÓµµÀúÇÏ,

	SAI79::ePropType	eElementType;
	short				wElementAtk;		// ¼Ó¼º µ¥¹ÌÁö( À§ ¼Ó¼º Å¸ÀÔÀ¸·Î °ø°Ý·ÂÀ» ¼³Á¤ÇÑ´Ù. )

	DWORD	dwHideLevel;	// ·¹º§ ¾Èº¸ÀÌ´Â³ÑÀÌ³Ä..
	FLOAT	fSpeed;	// ÀÌµ¿¼Óµµ,
	DWORD	dwShelter;	// °ÅÁÖÁö¿ª,
	DWORD	dwFlying;	// ºñÇàÀ¯¹«,
	DWORD	dwJumpIng;	// ³ôÀÌ¶Ù±â 
	DWORD	dwAirJump;	// ¸Ö¸®¶Ù±â
	DWORD	bTaming;	// Á¶·ÃÀ¯¹« 
	DWORD	dwResisMgic;	//¸¶¹ýÀúÇ× 

	int		nResistElecricity;
	int		nResistDark;
	int		nResistFire;
	int		nResistWind;
	int		nResistWater;
	int		nResistEarth;
	
	DWORD	dwCash;		// Á¦°ø±Ý¾×
	DWORD	dwSourceMaterial;	// Á¦°øÀç·á
	DWORD	dwMaterialAmount;	// Àç·á¾ç
	DWORD	dwCohesion;	// Àç·áÀÀÁýµµ
	DWORD	dwHoldingTime;	// ½ÃÃ¼À¯Áö½Ã°£
	DWORD	dwCorrectionValue;	// ¾ÆÀÌÅÛ»ý¼ºº¸Á¤°ª
	EXPINTEGER	nExpValue;
	int		nFxpValue;		// ºñÇà°æÇèÄ¡.
	DWORD	nBodyState;		// ¸ö»óÅÂ,
	DWORD	dwAddAbility;	// Ãß°¡´É·Â,
	DWORD	bKillable;	// Á×À½À¯¹«,

	DWORD	dwVirtItem[3];
	DWORD	bVirtType[3]; 

	DWORD   dwSndAtk1  ;
	DWORD   dwSndAtk2  ;
	DWORD   dwSndDie1  ;
	DWORD   dwSndDie2  ;
	DWORD   dwSndDmg1  ;
	DWORD   dwSndDmg2  ;
	DWORD   dwSndDmg3  ;
	DWORD   dwSndIdle1 ;
	DWORD   dwSndIdle2 ;

	short   m_nEvasionHP;
	short	m_nEvasionSec;
	short   m_nRunawayHP          ; // HP°¡ 10 ÀÌÇÏ¸é µµÁÖ 
	short   m_nCallHelperMax       ; // ÃÑ °¹¼ö 
	short   m_nCallHP              ; // µµ¿ò¿äÃ»ÇÏ±â À§ÇÑ HP
	short   m_nCallHelperIdx  [ 5 ]; // µµ¿ò¿äÃ»ÇÏ±â Id
	short   m_nCallHelperNum  [ 5 ]; // µµ¿ò¿äÃ»ÇÏ±â Id
	short   m_bCallHelperParty[ 5 ]; // µµ¿ò¿äÃ»ÇÏ±â Id

	short   m_dwAttackMoveDelay;
	short   m_dwRunawayDelay;
	short   m_bPartyAttack;
	short   m_nHelperNum;

#if !defined(__CORESERVER) 
	int		m_nScanJob;		// Å¸°ÙÀ» °Ë»öÇÒ¶§ Æ¯Á¤ Á÷¾÷À¸·Î °Ë»öÇÏ´Â°¡. 0 ÀÌ¸é ALL
	// °ø°ÝÁ¶°ÇµéÀº ºñ½ºÆ®¿¡¼­ ¼±°øÀ¸·Î ÁöÁ¤µÇ¾î ÀÖÀ»¶§ ¾ê±â´Ù.
	int		m_nHPCond;		// Å¸°ÙÀÌ hp% ÀÌÇÏÀÏ¶§ °ø°ÝÀ» ÇÔ.
	int		m_nLvCond;		// Å¸°Ù°ú ·¹º§ºñ±³ÇÏ¿© ³·À¸¸é °ø°ÝÀ» ÇÔ.
	int		m_nRecvCondMe;	// È¸º¹ Á¶°Ç.  ³»hp°¡ ¸î%ÀÌÇÏ·Î ¶³¾îÁ³À»¶§?
	int		m_nRecvCondHow;	// È¸º¹ÇÒ¶§ È¸º¹ÇÒ ¾ç %´ÜÀ§
	int		m_nRecvCondMP;	// È¸º¹ÇÒ¶§ MP¼Ò¸ð·® %´ÜÀ§
	BYTE	m_bMeleeAttack;	// ±ÙÁ¢ °ø°Ý AI°¡ ÀÖ´Â°¡?
	BYTE	m_bRecvCondWho;	// ´©±¸¸¦ Ä¡·áÇÒ²¨³Ä. 0:ÁöÁ¤¾ÈµÊ 1:´Ù¸¥³ð 2:³ª 3:¸ðµÎ.
	BYTE	m_bRecvCond;	// Ä¡·áÇÏ³Ä? 0:Ä¡·á¾ÈÇÔ 1:ÀüÅõÁß¿¡¸¸ Ä¡·áÇÔ 2:ÀüÅõ/ºñÀüÅõ ¸ðµÎ Ä¡·á
	BYTE	m_bHelpWho;		// µµ¿ò¿äÃ»½Ã - 0:ºÎ¸£Áö¾ÊÀ½ 1:¾Æ¹«³ª  2:°°ÀºÁ¾Á·¸¸.
	BYTE	m_bRangeAttack[ MAX_JOB ];		// °¢ Á÷¾÷º° ¿ø°Å¸® °ø°Ý °Å¸®.
	int		m_nSummProb;	// ¼ÒÈ¯ È®·ü : 0ÀÌ¸é ¼ÒÈ¯´É·Â ¾øÀ½.
	int		m_nSummNum;		// ÇÑ¹ø¿¡ ¸î¸¶¸®³ª ¼ÒÈ¯ÇÏ³Ä.
	int		m_nSummID;		// ¾î¶² ¸ó½ºÅÍ?
	int		m_nHelpRangeMul;	// µµ¿ò¿äÃ» °Å¸®. ½Ã¾ßÀÇ ¹è¼ö
	DWORD	m_tmUnitHelp;			// ÇïÇÁ Å¸ÀÌ¸Ó.
	int		m_nBerserkHP;		// ¹ö¼­Ä¿°¡ µÇ±â À§ÇÑ HP%
	float	m_fBerserkDmgMul;	// ¹ö¼­Ä¿°¡ µÇ¾úÀ»¶§ µ¥¹ÌÁö ¹è¼ö.
	int		m_nLoot;			// ·çÆÃ¸÷ÀÎ°¡.
	int		m_nLootProb;		// ·çÆÃ È®·ü
	DWORD   m_dwScanQuestId; 
	DWORD   m_dwScanItemIdx; 
	int		m_nScanChao;		// Ä«¿À, ºñÄ«¿À °Ë»ö
#endif // !__CORESERVER
	
#ifdef __S1108_BACK_END_SYSTEM
	float	m_fHitPoint_Rate;		// ¸ó½ºÅÍ ÃÖ´ë HP·ü // dwAddHp * m_nHitPoint_Rate
	float	m_fAttackPower_Rate;	// ¸ó½ºÅÍ ÃÖ´ë °ø°Ý·ü // dwAtkMin * m_nAttackPower_Rate
	float	m_fDefence_Rate;		// ¸ó½ºÅÍ ÃÖ´ë ¹æ¾î·ü // dwAddHp * m_nDefence_Rate
	float	m_fExp_Rate;			// ¸ó½ºÅÍ ÃÖ´ë °æÇèÄ¡·ü // dwAddHp * m_nExp_Rate
	float	m_fItemDrop_Rate;		// ¸ó½ºÅÍ ÃÖ´ë ¾ÆÀÌÅÛ µå·Ó·ü // dwAddHp * m_nItemDrop_Rate
	float	m_fPenya_Rate;			// ¸ó½ºÅÍ ÃÖ´ë Æä³Ä·ü // dwAddHp * m_nPenya_Rate
	BOOL	m_bRate;
#endif // __S1108_BACK_END_SYSTEM

	
	short	m_nAttackItemNear;
	short	m_nAttackItemFar;
	short	m_nAttackItem1;
	short	m_nAttackItem2;
	short	m_nAttackItem3;
	short	m_nAttackItem4;
	short	m_nAttackItemSec;
	short	m_nMagicReflection;
	short	m_nImmortality;
	BOOL 	m_bBlow;
	short	m_nChangeTargetRand;

	short   m_nAttackFirstRange;
	RANDOM_ITEM		m_randomItem  ;
	CDropItemGenerator	m_DropItemGenerator;
	CQuestItemGenerator		m_QuestItemGenerator;
	CDropKindGenerator	m_DropKindGenerator;
#if __VER >= 14 // __INSTANCE_DUNGEON
	MonsterTransform	m_MonsterTransform;
#endif // __INSTANCE_DUNGEON
#ifdef __NEW_BOSSMECHANICS
	BOSSMECHANICS bossMechanics;
#endif //__NEW_BOSSMECHANICS
#if __VER >= 16
	DWORD	dwAreaColor;
	char	szNpcMark[64];
	DWORD	dwMadrigalGiftPoint;
#endif
	
	MoverProp()
	{
		dwStr	= dwSta	= dwDex	= dwInt	= dwHR	= dwER	= dwRace	= dwBelligerence	=dwGender
		= dwLevel	= dwFlightLevel	= dwSize	= dwClass	= bIfParts	= nChaotic
		#ifdef __S1108_BACK_END_SYSTEM
		= dwUseable
		#else // __S1108_BACK_END_SYSTEM
		= dwDefExtent
		#endif // __S1108_BACK_END_SYSTEM
		= dwActionRadius	= dwAtkMin	= dwAtkMax	= dwAtk1	= dwAtk2	= dwAtk3	= dwAtk4	= 0;
		#if __VER >= 9	//__AI_0509
			fFrame	= 1.0F;
			dwOrthograde	= 0;
		#else	// __AI_0509
			dwVerticalRate	= dwDiagonalRate	= 0;
		#endif	// __AI_0509
		dwThrustRate		= 0;
		dwChestRate			= 0;
		dwHeadRate			= 0;
		dwArmRate			= 0;
		dwLegRate			= 0;
		dwAttackSpeed		= 0;
		dwReAttackDelay		= 0;
		dwAddHp				= 0;
		dwAddMp				= 0;
		dwNaturalArmor		= 0;
		nAbrasion			= 0;
		nHardness			= 0;
		dwAdjAtkDelay		= 0;
		dwHideLevel			= 0;
		eElementType		= SAI79::NO_PROP;
		wElementAtk			= 0;
		fSpeed				= 0.0F;
		dwShelter			= 0;
		dwFlying			= 0;
		dwJumpIng			= 0;
		dwAirJump			= 0;
		bTaming				= 0;
		dwResisMgic			= 0;
		nResistElecricity	= 0;
		nResistDark			= 0;
		nResistFire			= 0;
		nResistWind			= 0;
		nResistWater		= 0;
		nResistEarth		= 0;
		dwCash				= 0;
		dwSourceMaterial	= 0;
		dwMaterialAmount	= 0;
		dwCohesion			= 0;
		dwHoldingTime		= 0;
		dwCorrectionValue	= 0;
		nExpValue			= 0;
		nFxpValue			= 0;
		nBodyState			= 0;
		dwAddAbility		= 0;
		bKillable			= 0;
		
		memset( dwVirtItem, 0, sizeof(dwVirtItem) );
		memset( bVirtType, 0, sizeof(bVirtType) );

		dwSndAtk1			= 0;
		dwSndAtk2			= 0;
		dwSndDie1			= 0;
		dwSndDie2			= 0;
		dwSndDmg1			= 0;
		dwSndDmg2			= 0;
		dwSndDmg3			= 0;
		dwSndIdle1			= 0;
		dwSndIdle2			= 0;
		m_nEvasionHP		= 0;
		m_nEvasionSec		= 0;
		m_nRunawayHP		= 0;
		m_nCallHelperMax	= 0;
		m_nCallHP			= 0;
		
		memset( m_nCallHelperIdx, 0, sizeof(m_nCallHelperIdx) );
		memset( m_nCallHelperNum, 0, sizeof(m_nCallHelperNum) );
		memset( m_bCallHelperParty, 0, sizeof(m_bCallHelperParty) );
		
		m_dwAttackMoveDelay	= 0;
		m_dwRunawayDelay	= 0;
		m_bPartyAttack		= 0;
		m_nHelperNum		= 0;

#if !defined(__CORESERVER) 
		m_nScanJob			= 0;
		m_nHPCond			= 0;
		m_nLvCond			= 0;
		m_nRecvCondMe		= 0;
		m_nRecvCondHow		= 0;
		m_nRecvCondMP		= 0;
		m_bMeleeAttack		= 0;
		m_bRecvCondWho		= 0;
		m_bRecvCond			= 0;
		m_bHelpWho			= 0;
		memset( m_bRangeAttack, 0, sizeof(m_bRangeAttack) );
		m_nSummProb			= 0;
		m_nSummNum			= 0;
		m_nSummID			= 0;
		m_nHelpRangeMul		= 0;
		m_tmUnitHelp		= 0;
		m_nBerserkHP		= 0;
		m_fBerserkDmgMul	= 0;
		m_nLoot				= 0;
		m_nLootProb			= 0;
		m_dwScanQuestId		= 0;
		m_dwScanItemIdx		= 0;
		m_nScanChao			= 0;
#endif // !__CORESERVER

#ifdef __S1108_BACK_END_SYSTEM
		m_fHitPoint_Rate	=
		m_fAttackPower_Rate	= 
		m_fDefence_Rate	=
		m_fExp_Rate	= 
		m_fItemDrop_Rate	= 
		m_fPenya_Rate	= 0.0F;
		m_bRate	=
#endif // __S1108_BACK_END_SYSTEM
		m_nAttackItemNear	=
		m_nAttackItemFar	=
		m_nAttackItem1	=
		m_nAttackItem2	=
		m_nAttackItem3	=
		m_nAttackItem4	=
		m_nAttackItemSec	=
		m_nMagicReflection	=
		m_nImmortality	=
		m_bBlow	=
		m_nChangeTargetRand	=
		m_nAttackFirstRange	= 0;
		
#if __VER >= 16
		dwAreaColor = AREA_NORMAL;
#endif
	}
};

#ifdef __CREATE_CHAR_WITH_ITEMS
typedef struct tagJOBITEM
{
	DWORD dwJob;
	DWORD dwSex;
	DWORD dwPart;
	vector<pair<DWORD, short>> vecBeginItem;
} JOBITEM, * LPJOBITEM;
#else // __CREATE_CHAR_WITH_ITEMS
typedef	struct	tagBeginItem
{
	DWORD	dwItemType;
	DWORD	dwItemId;
	DWORD	dwNum;
}
BEGINITEM, * LPBEGINITEM;

#define MAX_BEGINEQUIP  10
#define MAX_BEGINITEM   42 //20 
#define MAX_JOBITEM     10 

typedef struct tagJOBITEM
{
	DWORD adwMale[MAX_BEGINEQUIP][2];
	BEGINITEM beginItem[MAX_BEGINITEM];

} JOBITEM, * LPJOBITEM;
#endif // __CREATE_CHAR_WITH_ITEMS

#define	MAX_BEGINPOS	16

typedef	struct tagBEGINPOSARR
{
	u_long	uSize;
	D3DXVECTOR3 avPos[MAX_BEGINPOS];
}
BEGINPOSARR, *LPBEGINPOSARR;

#define TASKBAR_TOP    0
#define TASKBAR_BOTTOM 1
#define TASKBAR_LEFT   2
#define TASKBAR_RIGHT  3

// short cut
#define MAX_SLOT_APPLET			18

#ifdef __NEW_TASKBAR_V19
#define MAX_SLOT_ITEM	10
#define MAX_SLOT_QUEUE	6
#else // __NEW_TASKBAR_V19
#define MAX_SLOT_ITEM			9
#define MAX_SLOT_QUEUE			5
#endif // __NEW_TASKBAR_V19

#if __VER >= 11 // __CSC_VER11_5
#define	MAX_SLOT_ITEM_COUNT		8
#else
#define	MAX_SLOT_ITEM_COUNT		4
#endif //__CSC_VER11_5


#define	SHORTCUT_NONE    0
#define	SHORTCUT_ETC     1
#define	SHORTCUT_APPLET  2
#define	SHORTCUT_MOTION  3
#define	SHORTCUT_SCRIPT  4
#define	SHORTCUT_ITEM    5
//#define	SHORTCUT_CARD    5
//#define	SHORTCUT_JACKBOX 6
#define	SHORTCUT_SKILL   6
#define SHORTCUT_OBJECT  7
#define SHORTCUT_CHAT    8
#define SHORTCUT_SKILLFUN 9
#define SHORTCUT_EMOTICON 10
#define SHORTCUT_LORDSKILL	 11


#if defined ( __CLIENT )
class CWndBase;
#endif	// __CLIENT

typedef struct tagSHORTCUT
{
#if defined ( __CLIENT )
	CWndBase* m_pFromWnd   ;
	CTexture* m_pTexture   ;
#if __VER >= 8	// __JEFF_VER_8
	DWORD	m_dwItemId;
#endif	// __JEFF_VER_8
#endif	// __CLIENT
	DWORD     m_dwShortcut ; 
	DWORD     m_dwId       ; 
	DWORD     m_dwType     ; 
	DWORD     m_dwIndex    ; 
	DWORD     m_dwUserId   ; 
	DWORD     m_dwData     ; 
	TCHAR     m_szString[MAX_SHORTCUT_STRING]; // SHORTCUT_CHATÀÏ °æ¿ì ÀúÀå.
	BOOL IsEmpty() { return m_dwShortcut == SHORTCUT_NONE; }
	void Empty() { m_dwShortcut = SHORTCUT_NONE; }
} SHORTCUT,* LPSHORTCUT;

typedef struct tagEXPPARTY
{
	DWORD	Exp;
	DWORD	Point;
}
EXPPARTY, *LPEXPPARTY;

typedef struct tagRENEWEVENT
{
	int		nLevel;
	DWORD	dwItemId;
	TCHAR	strItemName[64];
	float	fPercent;
}
RENEWEVENT, *LPRENEWEVENT;

typedef struct tagRENEWEVENTITEM
{
#ifdef __S0517
	CTime	EndTime;
#else // __S0517
	TCHAR strTime[32];
#endif // __S0517
	int nLevel;
	int	nRealitem[ MAX_REALITEM ];
	int nRealitemCount[ MAX_REALITEM ];
	int nSendRealitemCount[ MAX_REALITEM ];
	int nPercent[ MAX_REALITEM ];
	int nNextIndex;
}
RENEWEVENTITEM, *LPRENEWEVENTITEM;


typedef struct tagExpCharacter
{
	EXPINTEGER	nExp1;
	EXPINTEGER	nExp2;
	DWORD dwLPPoint;
	EXPINTEGER	nLimitExp;
}
EXPCHARACTER, *LPEXPCHARACTER;
#ifdef __TREASUREBOX
#ifndef __DBSERVER
#ifdef __WORLDSERVER
struct TreasureItem
{
	DWORD dwKeyID;
	DWORD dwItemID;
	int nChance;
	int nMaxamount;
	int nRepeat;
	int nLimitamount;
	BOOL bNotice;
};
#endif // __WORLDSERVER
struct TreasureBox
{
	DWORD dwBoxID;
	DWORD dwKeyID[3];
};
#endif // __DBSERVER
#endif // __TREASUREBOX

#ifdef __PLAYER_LIST
struct PlayerList
{
	TCHAR	szName[64];
	TCHAR	szRank[64];
	DWORD	dwJob;
	DWORD	dwLevel;
	DWORD	dwSex;
	int		nID;
};
#endif // __PLAYER_LIST

#ifdef __MOUNT
struct MOUNT_ANIMATION
{
	BYTE		mType;
	DWORD		dwPlayerAni;
	D3DXVECTOR3 vOffSet;
	D3DXVECTOR3 vRotation;
	DWORD		dwBindBone;
	map<int, CString> m_aMonsterAnimation;
	FLOAT		fGroundSpeed, fFlightSpeed;
	MOUNT_ANIMATION()
	{
		mType = 0;
		dwPlayerAni = 0;
		fGroundSpeed = fFlightSpeed = 0.0f;
		vRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		vOffSet = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		dwBindBone = NULL;
		m_aMonsterAnimation.clear();
	}
};
#endif // __MOUNT

#ifdef __WEAPON_RARITY
struct WeaponRarity
{
	int		m_nRarityLevel;
	char* m_szName;
	DWORD	m_dwColor;
	int		m_fUpgradeRate;
	float	m_fAttackRate;
	float	m_fStatsRate;
	int		m_nDropLuck;
#ifdef __BLING_BLING
	BOOL	m_bReflect;
#endif // __BLING_BLING
	WeaponRarity()
	{
#ifdef __BLING_BLING
		m_bReflect = FALSE;
#endif // __BLING_BLING
	}
};
#endif // __WEAPON_RARITY

#endif	// __PROJECTCMN_H__
```
