# Mover.h

Chemin original: `C:\Users\rdiff\Desktop\__NEWCLASS\_AIInterface\Mover.h`
Chemin relatif: `_AIInterface\Mover.h`
Nom du fichier: `Mover.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#if !defined(AFX_MOVER_H__4B7B21D7_A2D3_4115_946C_68DC9045A845__INCLUDED_)
#define AFX_MOVER_H__4B7B21D7_A2D3_4115_946C_68DC9045A845__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#if __VER >= 11 // __SYS_POCKET
#include "pocket.h"
#endif	// __SYS_POCKET

#ifdef __BUFF_1107
#include "buff.h"
#endif	// __BUFF_1107

#include "Ctrl.h"
#include "..\_AIInterface\ActionMover.h"
#include "SkillInfluence.h"
#include "CooltimeMgr.h"
#include "mempooler.h"

#ifdef __WORLDSERVER
	#include "NpcProperty.h"
	#include "SfxHitArray.h"
	#include "..\_AIInterface\AIInterface.h"
#else
	#include "CooltimeMgr.h"
#endif

typedef	MemPooler<CMover>	CMoverPool;

#define	MAX_NAME				64

#ifdef __GUILD_COLOR
#define COLOR_GUILD_FARBE_10	0xFFFFD700
#define COLOR_GUILD_FARBE_20	0xFFFF00FF
#define COLOR_GUILD_FARBE_30	0xFF32CD32
#define COLOR_GUILD_FARBE_40	0xFF00BFFF
#define COLOR_GUILD_FARBE_50	0xFF808080
#endif // __GUILD_COLOR 

#define	COLOR_PLAYER			0xffffffff
#define	COLOR_ENEMY				0xFFFF3030	//Red -> Siege Enemy
#define COLOR_GAMEMASTER        0xFFFFA500
#define COLOR_ADMINISTRATOR     0xFFE0115F
#define	COLOR_DEVELOPER			0xFFffff00
#define	COLOR_OWNER				0xFF00ffff
#define	COLOR_NPC				0XFFA0A0FF
#define	COLOR_MONSTER			0xffffffa0
#define	COLOR_PARTY				0xff70f070
#define COLOR_GUILDCOMBAT		0xff00ff00
#define	COLOR_GUILDMASTER		0xFFFFFF99

#define COLOR_SKY_RED			0xfffc6b03
#define COLOR_CHAT_GREEN		0xff30ff00
#define COLOR_CHAT_L_BLUE		0xff9e9eeb
#define COLOR_CHAT_SKY_B		0xff1bdbeb
#define COLOR_CHAT_VIOLET		0xffffa500
#define COLOR_CHAT_YELLOW		0xffffa500
#define COLOR_CHAT_D_PINK		0xffff008c
#define COLOR_CHAT_L_RED		0xffff0000

// Titanium MMO Specific
#define COLOR_PREMIUM			0XFFFFA500 // Orange

// Titanium MMO Easy Defines
#define COLOR_ERROR				0xFFFF0000 // Red
#define COLOR_SUCCESS			0XFF00F000 // Green
#define COLOR_ITEM_BG			0XFFFF00FF // Pink
#define COLOR_BLACK				0XFF000000 // Black
#define COLOR_WHITE				0XFFFFFFFF // White
#define COLOR_PLACEHOLDER		0XFF8C8C8C // Gray
#define COLOR_ITEMINFO			0XFF666666 // Dark Gray
#define COLOR_WARNING			0XFFFF8C00 // Orange

/// SetMotion() option
#define	MOP_NONE				0x00000000
#define	MOP_SWDFORCE			0x00000001		/// °Ë±¤ »ý¼ºÇÏ°Ô
#define	MOP_FIXED				0x00000002		/// dwMotion°ªÀ» ±×´ë·Î ·ÎµùÇÏ°Ô ( +100 ¾ÈÇÏ°Ô.. )
#define	MOP_NO_TRANS			0x00000004		/// ¸ð¼Ç Æ®·£Áö¼Ç ÇÏÁö¾ÊÀ½.
#define	MOP_HITSLOW				0x00000008		/// Å¸Á¡ÀÌÈÄºÎÅÍ ½½·Î¿ì.

#define	REQ_USESKILL			0x00000001		/// ÀÀ´ä¿äÃ» ÇÃ·¡±× - ½ºÅ³»ç¿ë ÀÀ´ä
#define	REQ_MOTION				0x00000002		/// ÀÀ´ä¿äÃ» ÇÃ·¡±× - ¸ð¼Ç ÀÀ´ä

#define	OBJTYPE_PLAYER			0x00000001		
#define	OBJTYPE_MONSTER			0x00000002		
#define OBJTYPE_CTRL			0x00000004		
#define	OBJTYPE_FLYING			0x00010000		/// m_dwTypeFlag¿¡¼­ »ç¿ë.

#define	CRITICAL_PROBABILITY	3
#define	CRITICAL_BERSERK_HP		30
#define	CRITICAL_BERSERK_PROB	22
#define	CRITICAL_AFTER_DEATH	22

// UPDATEITEM
#define	UI_NUM					0
#define	UI_HP					1
#define	UI_RN					2
#define	UI_AO					3
#define	UI_RAO					4
#define	UI_IR					5
#define	UI_PIERCING_SIZE		6
#define	UI_PIERCING				7
#define UI_COOLTIME				8
#define	UI_FLAG					9
#define	UI_RANDOMOPTITEMID		10
#define	UI_KEEPTIME				11
#define UI_REPAIR_NUM			12

#if __VER >= 12 // __EXT_PIERCING
#define UI_ULTIMATE_PIERCING_SIZE	13
#define UI_ULTIMATE_PIERCING		14
#endif // __EXT_PIERCING

#if __VER >= 15 // __PETVIS
#define UI_PETVIS_SIZE			15
#define UI_PETVIS_ITEM			16
#define UI_PETVIS_ITEMSWAP		17
#define UI_TRANSFORM_VISPET		18

const int PETVIS_DEFAULT_VIS_SLOT_SZIE	=	2;
#endif // __PETVIS
#ifdef __WEAPON_RARITY
#define UI_WEAPON_RARITY		19
#endif // __WEAPON_RARITY
#ifdef __SWITCH_GLOW_OLDNEW
#define	UI_CHANGE_GLOWOLD		20
#endif // __SWITCH_GLOW_OLDNEW
#ifdef __ADD_RESTATE_LOW
#define RESTATE_LOW				50
#endif // __ADD_RESTATE_LOW

#ifdef __NEWCLASS
#ifdef __MOONBEAM
#define MAX_SKILL_JOB	( MAX_JOB_SKILL + MAX_EXPERT_SKILL + MAX_PRO_SKILL + MAX_MASTER_SKILL + MAX_HERO_SKILL + MAX_LEGEND_HERO_SKILL + MAX_LEGEND_HERO_SKILL_ULTIMATE + MAX_CUSTOM_SKILL )
#else // __MOONBEAM
#define MAX_SKILL_JOB	( MAX_JOB_SKILL + MAX_EXPERT_SKILL + MAX_PRO_SKILL + MAX_MASTER_SKILL + MAX_HERO_SKILL + MAX_LEGEND_HERO_SKILL + MAX_LEGEND_HERO_SKILL_ULTIMATE )
#endif
#elif defined (__3RD_LEGEND16)
#define MAX_SKILL_JOB	( MAX_JOB_SKILL + MAX_EXPERT_SKILL + MAX_PRO_SKILL + MAX_MASTER_SKILL + MAX_HERO_SKILL + MAX_LEGEND_HERO_SKILL )
#else // __3RD_LEGEND16
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#define MAX_SKILL_JOB	( MAX_JOB_SKILL + MAX_EXPERT_SKILL + MAX_PRO_SKILL + MAX_MASTER_SKILL + MAX_HERO_SKILL )
#else // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#define MAX_SKILL_JOB	( MAX_JOB_SKILL + MAX_EXPERT_SKILL + MAX_PRO_SKILL )
#endif	// __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#endif // __3RD_LEGEND16

#ifdef __INTERNALSERVER
#define	TICK_CHEERPOINT	MIN( 1 )
#else	// __INTERNALSERVER
#define	TICK_CHEERPOINT	MIN( 60 )
#endif	// __INTERNALSERVER

#define	MAX_CHEERPOINT	3
#define	NULL_CHGPARAM	0x7FFFFFFF

const DWORD NEXT_TICK_DUEL          = SEC(1);
const DWORD NEXT_TICK_ENDDUEL       = MIN(3);
const DWORD NEXT_TICK_RECOVERY      = SEC(2);
const DWORD NEXT_TICK_RECOVERYSTAND = SEC(3);


#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

#define	LEGEND_CLASS_NORMAL			0
#define	LEGEND_CLASS_MASTER			1
#define	LEGEND_CLASS_HERO			2
#ifdef __3RD_LEGEND16
#define LEGEND_CLASS_LEGENDHERO	3
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
#define	LEGEND_CLASS_LEGENDHERO_ULTIMATE	4
#endif // __NEWCLASS
#endif	//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

#ifdef __BARUNA_PIERCING
#define MAX_BARUNA_DOT 2
#endif // __BARUNA_PIERCING


/// ReplaceÇÔ¼ö¿¡¼­ »ç¿ëÇÏ´Â Å¸ÀÔ 	
enum REPLACE_TYPE
{
	REPLACE_NORMAL,				/// ºñÇàÃ¼ Å¸°í ÀÎº¥ÀÌ Â÷¸é ¸·À½ 
	REPLACE_FORCE,				/// ¹«Á¶°Ç ÀÌµ¿ 
};

/// ½ºÅ³ »ç¿ë Å¸ÀÔ
enum SKILLUSETYPE
{
	SUT_NORMAL,			/// ´ÜÃàÅ°¿¡ ³Ö°í »ç¿ëÇÏ´Â ÀÏ¹ÝÀûÀÎ ¹æ½Ä.
	SUT_QUEUESTART,		/// ½ºÅ³Å¥·Î Ã³À½ ½ÃÀÛÇÏ´Â ½ºÅ³ÀÌ´Ù.(Ä³½ºÆÃÀ» ¸ô¾Æ¼­ÇÔ)
	SUT_QUEUEING,		/// ½ºÅ³Å¥ÀÇ ¿¬¼Ó¹ß»çÁß ½ºÅ³ÀÌ´Ù.(Ä³½ºÆÃµ¿ÀÛ¾øÀÌ ¹Ù·Î ¹ß»ç)
};

////////////////////////////////////////////////////////////////////////////////
// PVP °ü·Ã 
////////////////////////////////////////////////////////////////////////////////

/// Player vs PlayerÀÇ ¸ðµå 
enum PVP_MODE
{
	PVP_MODE_NONE,				/// PVPºÒ°¡ 	
	PVP_MODE_GUILDWAR,			/// ±æµå¿ö 
	PVP_MODE_PK,				/// PK
	PVP_MODE_DUEL				/// µà¾ó 
};

#if __VER < 8 // __S8_PK
/// PK Å¸ÀÔ 
enum PK_TYPE
{
	NORMAL_AND_NORMAL,			/// ÀÏ¹Ý À¯Àú ¿Í ÀÏ¹Ý À¯Àú 
	NORMAL_AND_SEMI,
	NORMAL_AND_CHAO,
	SEMI_AND_NORMAL,			/// ÁØÄ«¿À¿Í ÀÏ¹Ý À¯Àú 
	SEMI_AND_SEMI,
	SEMI_AND_CHAO,
	CHAO_AND_NORMAL,			/// Ä«¿À¿Í ÀÏ¹Ý À¯Àú 
	CHAO_AND_SEMI,
	CHAO_AND_CHAO
};

/// Ä«¸£¸¶ º¯°æ¿øÀÎ 
enum CHANGE_SLAUGHTER_TYPE
{
	CHANGE_SLAUGHTER_ATTACK,	/// 'PK½Ãµµ'·Î ÀÎÇÑ Ä«¸£¸¶(=½½·ÎÅÍ°ª) º¯°æ 
	CHANGE_SLAUGHTER_KILL,		/// PK·Î ÀÎÇÑ Ä«¸£¸¶(=½½·ÎÅÍ°ª) º¯°æ 
	CHANGE_SLAUGHTER_RECOVERY,	/// ÀÚ¿¬È¸º¹ 
	CHANGE_SLAUGHTER_SET,		/// ´Ü¼øÇÑ ´ëÀÔ 
};
#endif // __VER < 8 // __S8_PK

/// °Å·¡ È®ÀÎ Å¸ÀÔ 
enum TRADE_CONFIRM_TYPE
{
	TRADE_CONFIRM_ERROR,		/// ÀÎº¥¿¡ ¿©À¯°¡ ¾ø°Å³ª, GOLD°¡ OVERFLOW³ª´Â °æ¿ì 
	TRADE_CONFIRM_OK,			/// »ó´ëµµ ok(ÃÖÁ¾ °Å·¡)
};

/// °Å·¡»óÅÂ 
enum TRADE_STATE
{
	TRADE_STEP_ITEM,			/// ¾ÆÀÌÅÛ ´Ü°è - ¾ÆÀÌÅÛÀ» ¿Ã¸®°í ³»¸®°í  
	TRADE_STEP_OK,			    /// OK´©¸¥ ´Ü°è - ok¹öÆ°À» ´­·È´Ù.        
	TRADE_STEP_CONFIRM,			/// CONFIRM´Ü°è - ÃÖÁ¾È®ÀÎ´Ü°è            
};

////////////////////////////////////////////////////////////////////////////////
// struct
////////////////////////////////////////////////////////////////////////////////

#ifdef __ORIGIN_CARD_SYSTEM
typedef	struct	CARD_INFO
{
	DWORD	dwCardID;
	int		nNum;
} CARD_INFO;
#endif // __ORIGIN_CARD_SYSTEM

/// ÀåÂø Á¤º¸ ±¸Á¶Ã¼ 
typedef	struct	_EQUIP_INFO
{
	DWORD	dwId;
	int		nOption;
	BYTE	byFlag;
#ifdef __LOOKCHANGE
	DWORD	dwLook;
	_EQUIP_INFO()
	{
		dwLook = NULL_ID;
	}
#endif
#ifdef __SWITCH_GLOW_OLDNEW
	BOOL	bGlowOld;
#endif // __SWITCH_GLOW_OLDNEW
}	EQUIP_INFO,	*PEQUIP_INFO;
typedef struct ATTACKER_DATA
{
	u_long m_idAttacker;
	int totalDamageDealt;
	time_t initialTimeTick;
} ATTACKER_DATA;
/// ÀåÂø Ãß°¡ Á¤º¸ ±¸Á¶Ã¼ 
typedef	struct	_EQUIP_INFO_ADD
{
#if __VER >= 11 // __SYS_IDENTIFY
	__int64		iRandomOptItemId;
#else	// __SYS_IDENTIFY
	int				nRandomOptItemId;
#endif	// __SYS_IDENTIFY
//	PIERCINGINFO	piercingInfo;
	CPiercing	piercing;

	BYTE			bItemResist;
	int				nResistAbilityOption;
#ifdef __WEAPON_RARITY
	int				nWeaponRarity;
#endif // __WEAPON_RARITY
#ifdef __SWITCH_GLOW_OLDNEW
	BOOL			bGlowOld;
#endif // __SWITCH_GLOW_OLDNEW
#ifdef __CLIENT
	CTexture*		pTexture;
#endif	// __CLIENT
	_EQUIP_INFO_ADD()
	{
		iRandomOptItemId	= 0;
		piercing.Clear();
		bItemResist	= FALSE;
		nResistAbilityOption	= 0;
#ifdef __WEAPON_RARITY
		nWeaponRarity = 0;
#endif // __WEAPON_RARITY
#ifdef __SWITCH_GLOW_OLDNEW
		bGlowOld = FALSE;
#endif // __SWITCH_GLOW_OLDNEW
#ifdef __CLIENT
		pTexture	= NULL;
#endif	// __CLIENT
	}
	_EQUIP_INFO_ADD& operator=( const _EQUIP_INFO_ADD& e )
	{
		iRandomOptItemId	= e.iRandomOptItemId;
		piercing	= e.piercing;
		bItemResist		= e.bItemResist;
		nResistAbilityOption	= e.nResistAbilityOption;
#ifdef __WEAPON_RARITY
		nWeaponRarity = e.nWeaponRarity;
#endif // __WEAPON_RARITY
#ifdef __SWITCH_GLOW_OLDNEW
		bGlowOld = e.bGlowOld;
#endif // __SWITCH_GLOW_OLDNEW
#ifdef __CLIENT
		pTexture	= e.pTexture;
#endif	// __CLIENT
		return *this;
	}
}	EQUIP_INFO_ADD, *PEQUIP_INFO_ADD;

/// ÇÃ·¹ÀÌ¾î ¿Ü¾ç ±¸Á¶Ã¼ 
typedef struct tagPLAYER
{
	EQUIP_INFO	m_aEquipInfo[MAX_HUMAN_PARTS];
	char		m_byCostume;
	char		m_bySkinSet;
	char		m_byFace;
	char		m_byHairMesh;
	char		m_byHairColor;
	char		m_byHeadMesh;
	char		m_bySex;
	char		m_byJob;
	u_short		m_uSlot;
#ifdef __CREATE_CHAR_WITH_ITEMS
	char		m_byHelmet;
	char		m_bySuit;
	char		m_byGloves;
	char		m_byShoes;
#endif // __CREATE_CHAR_WITH_ITEMS
} PLAYER,* LPPLAYER;

/// Äù½ºÆ® ±¸Á¶Ã¼ 
typedef struct tagQuest
{
	BYTE		m_nState;
	WORD		m_wTime;
	WORD		m_wId;
//	BYTE		m_nKillNPCNum[ 2 ];	// chipi_091015 - NPC Kill Quest °¹¼ö È®Àå( BYTE -> WORD )
	WORD		m_nKillNPCNum[ MAX_QUEST_COND_KILL ];	// chipi_091015 - NPC Kill Quest °¹¼ö È®Àå( BYTE -> WORD )
	BYTE		m_bPatrol   : 1;
	BYTE		m_bDialog   : 1;
	BYTE		m_bReserve3 : 1;
	BYTE		m_bReserve4 : 1;
	BYTE		m_bReserve5 : 1;
	BYTE		m_bReserve6 : 1;
	BYTE		m_bReserve7 : 1;
	BYTE		m_bReserve8 : 1;

	QuestProp* GetProp() { return prj.m_aPropQuest.GetAt( m_wId ); }

} QUEST,* LPQUEST;

/// µ¿±âÈ­¿¡¼­ »ç¿ëÇÏ´Â ±¸Á¶Ã¼ 
typedef	struct tagCORR_ACTION
{
	float		f;
	float		fSpeed;
	DWORD		dwState;
	DWORD		dwStateFlag;
	DWORD		dwMotion;
	int			nMotionEx;
	int			nLoop;
	DWORD		dwMotionOption;
	D3DXVECTOR3	v;
	D3DXVECTOR3	vd;
	float		fAngleX;
	float		fAccPower;
	float		fTurnAngle;
	BOOL		fValid;
	BOOL		fBehavior;
	BOOL		fHalf;
} CORR_ACTION, *PCORR_ACTION;

/// ÇÇ°Ý Á¤º¸ ±¸Á¶Ã¼ 
struct HIT_INFO
{
#ifdef __NO_HP_DMG_LIMIT
	long long nHit;		/// ÀÔÀº µ¥¹ÌÁö 
#else
	int		nHit;		/// ÀÔÀº µ¥¹ÌÁö 
#endif
	DWORD	dwTick;		/// °ø°Ý´çÇÑ ½Ã°¢ 
};

typedef map<OBJID, HIT_INFO> SET_OBJID;		

/// °ø°ÝÀÇ Å¸ÀÔ 
enum HITTYPE
{
	HITTYPE_FAIL	= 0,
	HITTYPE_GENERIC,			/// Player vs Monster
	HITTYPE_PVP,				/// Player vs Player
	HITTYPE_WAR,				/// ±æµåÀü 
	HITTYPE_SCHOOL,				/// ÇÐ±³ ´ëÇ× ÀÌº¥Æ® Å¸ÀÔ 
	HITTYPE_PK,					/// Player Killing
	HITTYPE_GUILDCOMBAT,		/// ±æµå´ëÀü 
#ifdef __JEFF_11_4
	HITTYPE_ARENA,		// ¾Æ·¡³ª
#endif	// __JEFF_11_4
};

/// ¸®Àú·º¼Ç µ¥ÀÌÅ¸ ±¸Á¶Ã¼ 
typedef struct RESURRECTION_DATA
{
	u_long		  dwPlayerID;
	BOOL		  bUseing;
	ItemProp	 *pSkillProp;
	AddSkillProp *pAddSkillProp;
	int			  nDamage;
} RESURRECTION_DATA;

/// °Å·¡ÈÄ °á°ú ±¸Á¶Ã¼ 
struct VENDOR_SELL_RESULT
{
	CItemElem	item;			/// ÆÈ¸° ¾ÆÀÌÅÛ 
	int			nRemain;		/// ÆÈ¸®°í ³²Àº °¹¼ö 
	int			nErrorCode;		/// ¿¡·¯ÄÚµå 
};
#ifdef __DPSMETER_RYU
#ifdef __WORLDSERVER
struct __DPSPLAYER
{
	u_long m_idPlayer;
	char m_szName[MAX_NAME];

#ifdef __NO_HP_DMG_LIMIT
	long long nDPS;
	long long nDPSTotal;
#else
	int nDPS;
	int nDPSTotal;
#endif

	void Set(u_long idPlayer, LPCTSTR szName)
	{
		m_idPlayer = idPlayer;
		strcpy(m_szName, szName);
		nDPS = 0;
	}

#ifdef __NO_HP_DMG_LIMIT
	void Update(const long long nDamage)
#else
	void Update(int nDamage)
#endif
	{
		nDPS += nDamage;
		nDPSTotal += nDamage;
	}
};
#endif // __WORLDSERVER
#endif // __DPSMETER_RYU
/// °³ÀÎ»óÁ¡(Vendor)°ú °Å·¡(Trade) Å¬·¡½º 
class CVTInfo
{
private:
	DWORD					m_dwTradeGold;					/// °Å·¡ÁßÀÎ µ· 
	CItemBase*				m_apItem_VT[MAX_VENDITEM];		/// vendor and trader share pointer array
	OBJID					m_objId;						/// »ó´ë¹æ id
	CMover* m_pOwner;						/// Å¬·¡½º ¼ÒÀ¯ÀÚ 
	TRADE_STATE				m_state;						/// °Å·¡»óÅÂ 
	string					m_strTitle;						/// °³ÀÎ»óÁ¡ÀÇ Å¸ÀÌÆ² 

public:
	OBJID					GetOtherID() { return m_objId; }
	CMover*					GetOther();
	void					SetOther( CMover* pMover );
	void					Init( CMover* pMover );
	CItemBase*				GetItem( BYTE i );
	void					SetItem( BYTE i, CItemBase* pItemBase );
	LPCTSTR					GetTitle();
	void					SetTitle( LPCTSTR szTitle );
	BOOL					IsVendorOpen();
	void					TradeClear();
	void					TradeSetItem( BYTE nId, BYTE i, short nItemNum );
	BOOL					TradeClearItem( BYTE i );
	void					TradeSetGold( DWORD dwGold );
	int						TradeGetGold();
	BOOL					TradeConsent();
	DWORD					TradeSetItem2( BYTE nId, BYTE i, short & nItemNum );	// Return: dwText 
	TRADE_CONFIRM_TYPE		TradeLastConfirm( CAr & ar );
	TRADE_STATE				TradeGetState();
	void					TradeSetState( TRADE_STATE state );
	void					VendorClose(BOOL bClearTitle = TRUE);	// °³ÀÎ »óÁ¡ ´Ý±â
	void					VendorCopyItems( CItemBase** ppItemVd );
	void					VendorItemNum( BYTE i, short nNum );
#ifdef __EXTENDED_SALE_SYSTEM
	void					VendorSetItem(BYTE nId, BYTE i, short nNum, int nCost, int nPerinCost);
#else // __EXTENDED_SALE_SYSTEM
	void					VendorSetItem(BYTE nId, BYTE i, short nNum, int nCost);
#endif // __EXTENDED_SALE_SYSTEM
	BOOL					VendorClearItem( BYTE i );
	BOOL					VendorSellItem( CMover* pBuyer, BYTE nItem, DWORD dwItemId, short nNum, VENDOR_SELL_RESULT& result );
	BOOL					VendorIsVendor(); 

	BOOL				IsTrading( CItemElem* pItemElem );
};

/// ¼­¹ö¿¡¼­ SFXÇØÅ· ¶§¹®¿¡ »ý±ä ÀÚ·áÇü 
struct SFXHIT_INFO
{
	OBJID	idTarget;
	int		nMagicPower;
	DWORD	dwSkill;
	int		nDmgCnt;
	float	fDmgAngle;
	float	fDmgPower;
	DWORD	dwAtkFlags;
#if __VER >= 8 // __S8_PK
	BOOL	bControl;
#endif // __VER >= 8 // __S8_PK
	DWORD	dwTickCount;
};

struct	SFXHIT_COUNT
{
	DWORD	dwSkill;
	DWORD	dwTickCount;
};

class	CGuild;
class	CGuildWar;
class	CNpcProperty;
struct	ATTACK_INFO;
struct	REGIONELEM;
class	CParty;
class	CActionMover;

#ifdef __LAYER_1015
#define	REPLACE( uMulti, dwWorld, vPos, type, nLayer )	Replace( (uMulti), (dwWorld), (vPos), (type), (nLayer) )
#else	// __LAYER_1015
#define	REPLACE( uMulti, dwWorld, vPos, type, nLayer )	Replace( (uMulti), (dwWorld), (vPos), (type) )
#endif	// __LAYER_1015

#ifdef __CLIENT
class CClientPet
{
public:
	CClientPet();
	virtual	~CClientPet();
public:
	void	SetObj( CMover* pObj )	{	m_pObj	= pObj;	}
	CMover*	GetObj()	{	return m_pObj;		}
	void	SetLevelup( BYTE nLevelup )		{	m_nLevelup	= nLevelup;		}
	BYTE	GetLevelup()	{	return m_nLevelup;	}
#ifdef __PET_1024
	void	SetName( char* szName );
	char*	GetName()	{	return m_szName;	}
	BOOL	HasName()	{	return strlen( m_szName ) > 0;	}
#endif	// __PET_1024
private:
	CMover*	m_pObj;
	BYTE	m_nLevelup;		// PLU_LEVEL_UP ÀÌ¸é, Æê »ý¼º ½Ã Æê ·¹º§¾÷ È¿°ú »ý¼ºÇÏ°í 0À¸·Î ÃÊ±âÈ­
	
#ifdef __PET_1024
	char	m_szName[MAX_PET_NAME];
#endif	// __PET_1024
};
#endif	// __CLIENT


/// ÇÃ·¹ÀÌ¾î¿Í NPC
class CMover : public CCtrl
{	
public:	
	CMover();
	virtual ~CMover();

	friend			CActionMover;
	enum			{ PLAYER, NPC };			/// CMoverÀÇ Å¸ÀÔ 
#ifdef __LNB_ANIMATED_HATS
	void	InitializeAnimatedHat(DWORD dwItemId);
private:
	CModelObject* m_pAnimatedHat;
public:
	void SetAnimatedHat(CModelObject* pModel) { m_pAnimatedHat = pModel; }
	CModelObject* GainAniHatInfo() { return m_pAnimatedHat; }
#endif
public:
	BOOL			m_bPlayer;					/// PlayerÀÎ°¡, ¾Æ´Ï¶ó¸é NPC
	u_long			m_idPlayer;					/// playerÀÇ db¹øÈ£, NPC´Â 0xffffffff
	CActionMover*	m_pActMover;				/// ¹«¹ö¸¦ ¿òÁ÷ÀÌ´Â °´Ã¼. ¿©±â¼­ ¹«¹öÀÇ ¿òÁ÷ÀÓÀ» ÄÁÆ®·ÑÇÑ´Ù.
	DWORD			m_dwTypeFlag;				/// OBJTYPE_FLYING ¸¸ »ç¿ë flag
	DWORD			m_dwMode;					/// ¹«Àû, Åõ¸í, ÃÊÇÊ µîµî flag
	DWORD			m_dwFlag;					/// MVRF_ °ü·Ã flag ½Ã¸®Áî
	DWORD			m_dwStateMode;				/// PK, PVP, ºñÇà ½ÃÀü ... flag
	FLOAT			m_fCrrSpd;					/// ÀÌµ¿ ¼Óµµ  
	float			m_fAniSpeed;				/// ¾Ö´Ï¸ÞÀÌ¼Ç ¼Óµµ ¹è¼ö. 1.0ÀÌ ±âº». 2.0ÀÌ¸é µÎ¹èºü¸£±â. 2.0ÀÌ ¸Æ½º´Ù.
	float			m_fArrivalRange;			/// ¸ñÇ¥¿¡ ¾ó¸¶¸¸Å­ ±ÙÁ¢ÇØ¾ßÇÏ´Â°¡. ¹ÌÅÍ´ÜÀ§. µðÆúÆ® 0
	OBJID			m_idDest;					/// ¸ñÇ¥ °´Ã¼ ¾ÆÀÌµð
	D3DXVECTOR3		m_vDestPos;					/// ¸ñÇ¥ ÁöÁ¡ 
	float			m_fDestAngle;				/// ¸ñÇ¥ °¢µµ 		
	CShip*          m_pIADestPos;				/// ¿©±â¿¡ Æ÷ÀÎÅÍ°¡ ÀÖ´Ù¸é m_vDestPosÀÇ ÁÂÇ¥´Â m_pIADestPos¿ÀºêÁ§¿¡ ´ëÇÑ »ó´ëÁÂÇ¥°¡ µÈ´Ù.
	BOOL			m_fWaitQueryGetPos;			/// µ¿±âÈ­ °ü·Ã 
	int				m_nCorr;					/// µ¿±âÈ­ °ü·Ã - ³²¾ÆÀÖ´Â µ¿±â ÇÁ·¹ÀÓ ¼ö(½ÇÃ¼)
	u_long			m_uRemnantCorrFrm;			/// µ¿±âÈ­ °ü·Ã - ³²¾ÆÀÖ´Â µ¿±â ÇÁ·¹ÀÓ ¼ö(°í½ºÆ®)
	CORR_ACTION		m_CorrAction;				/// µ¿±âÈ­ Á¤º¸ ±¸Á¶Ã¼ 
	bool			m_bForward;					/// ÀüÁøÁß?
	bool			m_bPositiveX;				/// GetPos().x - m_vDestPos.x > 0.0f
	bool			m_bPositiveZ;				/// GetPos().z - m_vDestPos.z > 0.0f
	bool			m_bLeft;					/// leftÈ¸ÀüÁß? Å¬¶ó¸¸??
	DWORD			m_dwRegionAttr;				/// ÇöÀç ÁÂÇ¥ÀÇ region ¼Ó¼º 
	DWORD			m_dwOldRegionAttr;			/// ÀÌÀü ÁÂÇ¥ÀÇ region ¼Ó¼º 
	DWORD			m_dwMotion;					/// ¸ð¼Ç ¹øÈ£ 
	DWORD			m_dwMotionOption;			/// ¸ð¼Ç Ãß°¡ ¿É¼Ç
	OBJMSG			m_dwMotionArrive;			/// ÀÌµ¿ ¿Ï·á ÈÄ ¸ð¼Ç

	DWORD			m_dwTickRecovery;			/// ¾ÉÀº »óÅÂÀÇ hp, mp º¹±¸ timer
	DWORD			m_dwTickRecoveryStand;		/// stand »óÅÂÀÇ hp, mp º¹±¸ timer
#ifdef __HIDE_COAT
	BOOL			m_abHideCoat[5];
#endif

#ifdef __BAG_UPDATE
	BOOL	CanBeUsedInBag(ItemProp* pItemProp);
#endif

#ifdef __VTN_TIMELIMIT
	int				m_nAccountPlayTime;		//ms´ÜÀ§ °èÁ¤ ÇÃ·¹ÀÌ ½Ã°£
#endif // __VTN_TIMELIMIT

	BOOL	HasBuff( WORD wType, WORD wId );
	void	RemoveBuff( WORD wType, WORD wId );
	BOOL	HasBuffByIk3( DWORD dwIk3 );
	BOOL	HasPet();
#ifdef __WORLDSERVER
	void	RemovePet();
#endif	// __WORLDSERVER
	DWORD	GetDisguise();
	BOOL	AddBuff( WORD wType, WORD wId, DWORD dwLevel, DWORD tmTime, OBJID oiAttacker = NULL_ID );
	void	RemoveCommonBuffs();
	void	RemoveChrStateBuffs( DWORD dwChrState );
	void	RemoveIk3Buffs( DWORD dwIk3 );
	void	RemoveAllBuff();
	void	RemoveAttackerBuffs( OBJID oiAttacker );
	void	RemoveDstParamBuffs( DWORD dwDstParam );
	void	RemoveDebufBuffs();
	void	ProcessBuff();
#ifdef __CLIENT
	void	ClearBuffInst();
	int		GetCurrentMaxSkillPoint();
#endif	// __CLIENT

#ifdef __BUFF_1107
	CBuffMgr	m_buffs;
#else	// __BUFF_1107
	CSkillInfluence m_SkillState;				/// Áö¼Ó¼ºÀ» °®´Â ½ºÅ³ÀÇ »óÅÂ Ã³¸®(¿¹:ÇÁ·ÎÅØ¼Ç ??ÃÊµ¿¾È ¹æ¾î·Â ¾ó¸¶ Áõ°¡)
#endif	// __BUFF_1107
	DWORD			m_dwSMTime[SM_MAX];			/// À¯·á ¾ÆÀÌÅÛ ½Ã°£ °ªÀ» °¡Áö°í ÀÖÀ½
	SKILL			m_aJobSkill[ MAX_SKILL_JOB ];		/// ½ºÅ³ ¹è¿­ 
	DWORD			m_tmReUseDelay[ MAX_SKILL_JOB ];	/// ½ºÅ³ Àç»ç¿ë½Ã°¢
	
	LONG			m_nStr, m_nSta, m_nDex, m_nInt;		/// ½ºÅÝ 
	LONG			m_nLevel;					/// ·¹º§ 
	LONG			m_nDeathLevel;				/// Á×¾úÀ» ¶§ ·¹º§
	EXPINTEGER		m_nExp1, m_nDeathExp;		/// m_nExp1 - °æÇèÄ¡, DeathExp - Á×¾úÀ» ¶§ °æÇèÄ¡

private:
#if __VER >= 12 // __MOD_TUTORIAL
	int		m_nTutorialState;
#else	__MOD_TUTORIAL
	LONG	m_nFlightLv;
#endif	// __MOD_TUTORIAL
public:
#if __VER >= 12 // __MOD_TUTORIAL
	LONG	GetFlightLv( void )	{	return ( GetLevel() >= 20? 1: 0 );		}
	void	SetFlightLv( LONG nFlightLv )	{}
	int		GetTutorialState( void )	{	return m_nTutorialState;	}
	void	SetTutorialState( int nTutorialState )	{	m_nTutorialState	= nTutorialState;	}
#else	// __MOD_TUTORIAL
	LONG	GetFlightLv( void )	{	return m_nFlightLv;		}
	void	SetFlightLv( LONG nFlightLv )	{	m_nFlightLv	= nFlightLv;	}
#endif	// __MOD_TUTORIAL
#ifdef __BAG_LOOT
	int m_nSelectedBag;
#endif
	LONG			m_nFxp;		/// ºñÇà·¹º§, 
#ifdef __NO_HP_DMG_LIMIT
	__int64			m_nHitPoint;
#else
	LONG			m_nHitPoint;				/// HP
#endif
	LONG			m_nManaPoint;				/// MP
	LONG			m_nFatiguePoint;			/// FP( Áö±¸·Â )
	LONG			m_nRemainGP;				/// ½ºÅÈ Æ÷ÀÎÆ® 
	LONG			m_nDefenseMin, m_nDefenseMax;	/// ¹æ¾î·Â min, ¹æ¾î·Â max
	int				m_nAdjHitRate, m_nAdjParry;		/// ¼öÁ¤Ä¡ 
	BYTE			m_bySex;						/// ¼ºº° 
	DWORD			m_dwSkinSet, m_dwFace, m_dwHairMesh, m_dwHairColor, m_dwHeadMesh;	/// ¿Ü¾ç 
	FLOAT			m_fHairColorR, m_fHairColorG, m_fHairColorB;						/// ¸Ó¸®»ö 
	LONG			m_nJob;						/// Á÷¾÷ 
	DWORD			m_dwAuthorization;			/// À¯Àú ±ÇÇÑ (ÀÏ¹Ý¿¡¼­ ÃÖ°í °ü¸®ÀÚ±îÁö )
#ifdef __GAMEGUARD
	int				m_nAuth;
#endif // __GAMEGUARD

	TCHAR			m_szCharacterKey[32];		/// NPC key¹®ÀÚ¿­ 
	DWORD			m_dwBelligerence;			/// È£Àü¼º ¿©ºÎ 
	vector<ATTACKER_DATA> 	m_vRecentAttackers; // List of recent attackers and their damage dealt
	BOOL			m_bActiveAttack;			/// ¼±°ø¸÷ÀÎ°¡?
	DWORD			m_dwVirtItem;				/// npc°¡ »ç¿ë(°ø°Ý)ÇÒ ¾ÆÀÌÅÛ. ¶Ç´Â ÇÃ·¹ÀÌ¾î°¡ ¹«±â ºñÀåÂø½Ã »ç¿ëÇÒ ±âº» ¾ÆÀÌÅÛ. 
	DWORD			m_dwVirtType;				/// m_dwVirtItem°¡ ¾ÆÀÌÅÛÀÎÁö ½ºÅ³ÀÎÁö °áÁ¤ VT_ITEM, VT_SKILL
private:
	OBJID	m_oiEatPet;
public:
#ifdef __NAME_COLOR
	DWORD			m_dwNameColor;
#ifdef __NAME_FONT
	DWORD			m_nNameFont;
#endif // __NAME_FONT
#endif // __NAME_COLOR
	int				m_nFuel;					/// ºñÇàÃ¼ ÇöÀç ¿¬·á.
	int				m_tmAccFuel;				/// °¡¼Ó¿¬·á(½Ã°£´ÜÀ§)
#ifdef __JOPS_GLOW
	DWORD	m_dwGlowColor;
#endif
#ifdef __JOPS_GLOW
	int m_iGlowBody;
	int m_iGlowLegLeft;
	int m_iGlowLegRight;
	int m_iGlowArmLeft;
	int m_iGlowArmRight;
	int m_iGlowHandLeft;
	int m_iGlowHandRight;
	BOOL m_bodyc, m_bodyc2, m_gllc, m_glrc, m_galc, m_galc2, m_galc3, m_galc4, m_garc, m_garc2, m_garc3, m_garc4, m_ghlc, m_ghrc;
#endif
#ifdef __USER_OWN_TITLE
public:
	TCHAR	m_szOwnTitle[MAX_CUSTOM_TITLE];
#endif // __USER_OWN_TITLE
	BOOL			m_bItemFind;				/// Ä³½ºÆÃ ÈÄ¿¡ ¾ÆÀÌÅÛÀÌ ÀÖ´ÂÁö °Ë»çÇÒ °ÍÀÎ°¡? 
	int				m_nReadyTime;				/// ºñÇàÃ¼ Å¸±â Ä³½ºÆÃ ½Ã°£
	OBJID			m_dwUseItemId;				/// ºñÇàÃ¼ Å¸±â ¾ÆÀÌÅÛ ¾ÆÀÌµð 
#ifdef __AFK_REWARD_SYSTEM
	BOOL			m_bAfk;
#endif //__AFK_REWARD_SYSTEM
	DWORD			m_dwCtrlReadyTime;			/// box open Ä³½ºÆÃ Å¸ÀÔ  
	OBJID			m_dwCtrlReadyId;			/// Ä³½ºÆÃ ´ë»ó box ¾ÆÀÌµð  

	OBJID			m_idAttacker;				/// this¸¦ ½ÇÁ¦ °ø°ÝÇÑ³Ñ
	OBJID			m_idTargeter;				/// this¸¦ Å¸°ÙÀâ°í Á¡À¯ÇÏ°í ÀÖ´Â³Ñ.
	OBJID			m_idTracking;				/// ºñÇàÁß ÀÚµ¿ÃßÀûÇÏ°í ÀÖ´Â Å¸°Ù.
	OBJID			m_idLastHitMover;			/// this°¡ ¸¶Áö¸·À¸·Î ÃÆ´ø ¹«¹ö¾ÆÀÌµð
#ifdef __NO_HP_DMG_LIMIT
	double			m_fExpRatio;
#else
	float			m_fExpRatio;				/// exp Áö±Þ·ü. this¸¦ Á×¿´À»¶§ thisÀÇ expÀÇ ¸îÆÛ¼¾Æ®¸¦ ÁÙ°ÍÀÎ°¡. µðÆúÆ®´Â 1.0ÀÌ´Ù. ÀÌ°ÍÀº ÆÄÆ¼¶§´Â Àû¿ëµÇÁö ¾Ê´Â´Ù.
#endif
	int				m_nAtkCnt;					/// °ø°ÝÇÏ¸é Ä«¿îÅÍ°¡ 0ÀÌµÇ¸é¼­ °è¼Ó Áõ°¡ÇÑ´Ù.
	int				m_nReflexDmg;				/// ¸®ÇÃ·º½º µ¥¹ÌÁö ´©Àû (¼­¹ö¸¸)
	LONG			m_nPlusMaxHitPoint;			/// Ãß°¡ MAX HP
	DWORD			m_tmPoisonUnit;				/// µ¶ Àû¿ë ½Ã°£
	DWORD			m_tmBleedingUnit;			/// ¸îÃÊ¸¶´Ù ÇÑ¹ø¾¿ÀÎ°¡?
	OBJID			m_idPoisonAttacker;			/// µ¶ °ø°ÝÀÚ
	OBJID			m_idBleedingAttacker;		/// ÃâÇ÷ °ø°ÝÀÚ
	short			m_wStunCnt;					/// ½ºÅÏ»óÅÂ ½Ã°£ 
	short			m_wPoisonCnt;				/// µ¶»óÅÂ ½Ã°£ 
#ifdef __GAMEGUARD
	int				m_wPoisonDamage;			/// µ¶À¸·Î ±ðÀÏ µ¥¹ÌÁö
#else // __GAMEGUARD
	short			m_wPoisonDamage;			/// µ¶À¸·Î ±ðÀÏ µ¥¹ÌÁö
#endif // __GAMEGUARD
	short			m_wDarkCnt;					/// ¾ÏÈæ Áö¼Ó½Ã°£
	short			m_wDarkVal;					/// ¾ÏÈæµ¿¾È ±ðÀÏ ¸íÁß·ü ¼öÁ¤Ä¡
	short			m_wBleedingCnt;				/// ÃâÇ÷ »óÅÂ ½Ã°£ 
#ifdef __GAMEGUARD
	int				m_wBleedingDamage;			/// ÃâÇ÷·Î ±ðÀÏ µ¥¹ÌÁö
#else // __GAMEGUARD
	short			m_wBleedingDamage;			/// ÃâÇ÷·Î ±ðÀÏ µ¥¹ÌÁö
#endif // __GAMEGUARD
	short			m_wDarkCover;				/// ¾Èº¸ÀÌ°Ô ¼û±â
#if __VER >= 9	// __PET_0410
	short			m_nHealCnt;		//	0ÀÏ °æ¿ì¸¸ ÀÚµ¿ Ä¡À¯
#endif	// __PET_0410
#ifdef __BARUNA_PIERCING
	short			m_dwForceDamageDamage[4];
	short			m_dwForceDamageCnt[4];
	DWORD			m_dwForceDamageUnit[4];
	OBJID			m_dwForceAttackerID[4];
#endif // __BARUNA_PIERCING
#if __VER >= 9	//__AI_0509
	FLOAT	m_fSpeedFactor;
	void	SetSpeedFactor( FLOAT fSpeedFactor );
	FLOAT	GetSpeedFactor( void )	{	return m_fSpeedFactor;	}
#ifdef __WORLDSERVER
	BOOL	IsReturnToBegin( void );
#endif	// __WORLDSERVER
#endif	// __AI_0509

#if __VER >= 10	// __AI_0711
	BOOL	IsRank( DWORD dwClass )	
		{
			MoverProp* pProp	= GetProp();
			return( pProp && pProp->dwClass == dwClass );
		}
#endif	// __AI_0711

	BYTE			m_nAttackResistLeft;		/// ÄÚµå Á¸ÀçÇÏÁö¸¸ °ÔÀÓ³» »ç¿ëÇÏÁö ¾ÊÀ½ ( ¿Þ¼Õ ¼Ó¼º °ø°Ý·Â Ãß°¡ ) 
	BYTE			m_nAttackResistRight;		/// ÄÚµå Á¸ÀçÇÏÁö¸¸ °ÔÀÓ³» »ç¿ëÇÏÁö ¾ÊÀ½ ( ¿À¸¥¼Õ ¼Ó¼º °ø°Ý·Â Ãß°¡ ) 
	BYTE			m_nDefenseResist;			/// ÄÚµå Á¸ÀçÇÏÁö¸¸ °ÔÀÓ³» »ç¿ëÇÏÁö ¾ÊÀ½ ( ¼Ó¼º ¹æ¾î·Â ) 
	
	u_long			m_idparty;					/// ÆÄÆ¼ ¹øÈ£ (Å¬¶ó¿¡¼± Æ¯º°ÇÑ °æ¿ì°¡ ¾Æ´Ï¸é »ç¿ëÇØ¼± ¾ÈµÊ  g_Party.m_uPartyId¸¦ »ç¿ë )
	u_long			m_idGuild;					/// ±æµå ¹øÈ£ 
	BOOL			m_bGuildBank;				/// ±æµå ¹ðÅ©¸¦ ÀÌ¿ëÁßÀÎÁö È®ÀÎ
	DWORD			m_idGuildCloak;				/// ¸ÁÅäÀÇ ±æµå¹øÈ£¸¦ °¡Áö°í ÀÖÀ½
	u_long			m_idWar;					/// ±æµåÀü °íÀ¯ ¹øÈ£ 

	DWORD			m_tmActionPoint;			/// ¾×¼ÇÆ÷ÀÎÆ® ÀÚµ¿»ó½Â Å¸ÀÌ¸Ó(3ÃÊ) 
	DWORD			m_dwTickCheer;				/// ÀÀ¿ø Å¸ÀÌ¸Ó 
	int				m_nCheerPoint;				/// Å¸ÀÎ¿¡°Ô ÀÀ¿ø ¹ÞÀº °ª  

	DWORD			m_dwTickDuel;				/// µà¾ó »óÅÂ Å¸ÀÌ¸Ó 
	DWORD			m_dwTickEndDuel;			/// µà¾ó Á¾·á Å¸ÀÌ¸Ó 
	int				m_nDuelState;				/// µà¾ó»óÅÂ 
	int				m_nDuel;					/// µà¾óÁß »óÅÂ ( 0:¾øÀ½ 1:°³ÀÎµà¾óÁß 2:ÆÄÆ¼µà¾óÁß )
	OBJID			m_idDuelOther;				/// µà¾ó »ó´ëÀÇ ¾ÆÀÌµð
	u_long			m_idDuelParty;				/// ÆÄÆ¼µà¾óÁßÀÌ¸é »ó´ë¹æ ÆÄÆ¼ÀÇ ¾ÆÀÌµð 
#ifdef __CLOCKWORK_AI
	int				dwClockWorkTimer;
#endif
	int				m_nFame;					/// ¸í¼ºÄ¡ 
	u_long			m_idMurderer;				/// ³¯ ¸¶Áö¸·À¸·Î Á×¿´´ø³Ñ ÇÃ·¹ÀÌ¾î ¾ÆÀÌµð
#if __VER >= 8 // __S8_PK
	DWORD			m_dwPKTime;					/// ÇÎÅ© »óÅÂ ½Ã°£
	int				m_nPKValue;					/// PK ¼öÄ¡
	DWORD			m_dwPKPropensity;			/// PK ¼ºÇâ
	DWORD			m_dwPKExp;					/// PK ¼ºÇâ ½Àµæ °æÇèÄ¡		
#else // __VER >= 8 // __S8_PK
	int				m_nNumKill;					/// Å³¼ö
	DWORD			m_dwKarmaTick;				/// Ä«¸£¸¶ Æ÷ÀÎÆ® ÀÚ¿¬ È¸º¹¿ë Å¸ÀÌ¸Ó 
	int				m_nSlaughter;				/// Ä«¸£¸¶Æ÷ÀÎÆ®(Ä«¿À ¼öÄ¡)
#endif // __VER >= 8 // __S8_PK
#if __VER >= 8 //__CSC_VER8_5
	EXPINTEGER		m_nAngelExp;				/// ¿£Á© °æÇèÄ¡
	LONG			m_nAngelLevel;				/// ¿£Á© Level
#endif // __CSC_VER8_5

#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	BYTE			m_nLegend;
#endif	//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#if __VER >= 11 // __MA_VER11_06				// È®À²½ºÅ³ È¿°ú¼öÁ¤ world,neuz
	DWORD			dwRemoveSfxObj[MAX_SKILLBUFF_COUNT];			// »èÁ¦ÇÒ È¿°ú ¿ÀºêÁ§Æ® 
	DWORD			GetRemoveSfxObj(DWORD	dwRemoveSfxObjID);
	void			SetRemoveSfxObj(DWORD	dwRemoveSfxObjID);
#endif // __MA_VER11_06				// È®À²½ºÅ³ È¿°ú¼öÁ¤ world,neuz

#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
	int				m_nHonor;					// ´ÞÀÎ¼±ÅÃ 
	DWORD			m_dwHonorCheckTime;			//´ÞÀÎ ½Ã°£Ã¼Å©
	int				m_aHonorTitle[MAX_HONOR_TITLE];			// ´ÞÀÎ¼öÄ¡
	int				GetHonorTitle(int nIdx)	{	return m_aHonorTitle[nIdx];	}
	void			SetHonorCount(int nIdx , int nCount );
	void			CheckHonorStat();
	void			CheckHonorTime();
	void			SetHonorAdd(int nSmallIdx,int nLargeGroup,int nDefault = 0);
	CString			m_strTitle;
	LPCTSTR			GetTitle();
	void			SetTitle(LPCTSTR	pTitle);
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
#ifdef __CLIENT
	CSfx*			m_pSfxWing;
	DWORD			m_dwWingTime;

#if __VER >= 15 // __PETVIS
	CSfx*			m_pSfxBuffPet;
	void			SetSfxBuffPet( const DWORD idEffect );
#endif	//__PETVIS
#endif //__CLIENT

#ifdef __JEFF_9_20
	DWORD		m_dwMute;
#if __VER < 12 // __LORD
	BOOL	IsMute( void )	{	return ( m_dwMute > 0 );	}
#endif	// __LORD
#endif	// __JEFF_9_20

	RESURRECTION_DATA				m_Resurrection_Data;		/// ¸®Àú·º¼Ç ½ºÅ³ Á¤º¸ 
	CItemContainer< CItemElem  >*	m_ShopInventory[ MAX_VENDOR_INVENTORY_TAB ];	/// »óÀÎNPCÀÇ ¹°Ç° Á¤º¸ 
#ifdef __TABBED_INV
	CInventoryContainer< CItemElem  >	m_Inventory;
#else // __TABBED_INV
	CItemContainer< CItemElem  >	m_Inventory;				/// ????
#endif // __TABBED_INV
#if __VER >= 11 // __SYS_POCKET
	CPocketController	m_Pocket;
#endif	// __SYS_POCKET
	EQUIP_INFO		m_aEquipInfo[MAX_HUMAN_PARTS];				/// ÀåÂøÁ¤º¸ 	
	CVTInfo			m_vtInfo;					/// °Å·¡¿Í °³ÀÎ»óÁ¡ ¹øÈ£ 

	BYTE			m_nSlot;					/// ·Î±×ÀÎ È­¸éÀÇ 3°³ Ä³¸¯ÅÍ ¼ø¼­ ¹øÈ£ 
	BOOL			m_bBank;					/// ÀºÇà ÀÌ¿ë Áß?
	u_long			m_idPlayerBank[3];			/// 3°³ Ä³¸¯ÅÍ idPlayer
	DWORD			m_dwGoldBank[3];			/// 3°³ Ä³¸¯ÅÍ ±æµåµ· 
	CItemContainer< CItemElem >	m_Bank[3];		/// 3°³ Ä³¸¯ÅÍ ÀºÇà ¾ÆÀÌÅÛ 

	BYTE			m_nQuestKeeping;			/// Å¬¶ô¿öÅ© ±æµå Äù½ºÆ® ¹øÈ£  
	BYTE			m_nPartyQuestKeeping;		/// °Å´ë ¸ó½ºÅÍ Äù½ºÆ® ¹øÈ£ 
	BYTE			m_nQuestSize;				/// Äù½ºÆ® °¹¼ö 
	LPQUEST			m_aQuest;					/// ÇöÀç ÁøÇàÁßÀÎ Äù½ºÆ® ¹è¿­ 
	BYTE			m_nCompleteQuestSize;		/// ¿Ï·áµÈ Äù½ºÆ® °¹¼ö 
	LPWORD   		m_aCompleteQuest;			/// ¿Ï·áµÈ Äù½ºÆ® ¹è¿­ 	
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
	BYTE			m_nCheckedQuestSize;
	LPWORD			m_aCheckedQuest;
#endif // __IMPROVE_QUEST_INTERFACE

	int				m_nDead;					/// Á×Àº ÈÄ 5ÃÊ°£Àº ¹«Àû
	int				m_nGuildCombatState;		/// ±æµå ´ëÀü »óÅÂ 
	D3DXVECTOR3		m_vMarkingPos;				/// ·Îµå¶óÀÌÆ®¿¡¼­ ¸¶Å·ÇÑ ÁÂÇ¥ 
	OBJID			m_idMarkingWorld;			/// ·Îµå¶óÀÌÆ®¿¡¼­ ¸¶Å·ÇÑ ¿ùµå ¾ÆÀÌµð 

#ifdef __CLIENT
	static BOOL		m_bQuestEmoticonAdd;		/// Äù½ºÆ® ¾ÆÀÌÄÜ È®Ãà ÇÁ·Î¼¼½º 
	static FLOAT	m_fQuestEmoticonScale;
	int				m_nQuestEmoticonIndex;
	bool			m_bShowQuestEmoticon;

	NaviPoint		m_nvPoint;
	V_NaviPoint		m_vOtherPoint;
	int				m_idSfxHit;
	BYTE			m_nWaterCircleCount;
	DWORD			m_dwReqFlag;				/// ÀÀ´ä¿äÃ» ÇÃ·¡±×.
	char			m_szPartyName[32];
	float			m_fDestScale;				/// ÂÉ±×¶óµé¶§ ºÎµå·´°Ô ÇÏ±âÀ§ÇÑ..
	float			m_fDestScaleSlerp;			/// 1.0f ~ 0.0À¸·Î º¯È­ÇÔ.
	CCooltimeMgr	m_cooltimeMgr;	
	LPDIRECT3DTEXTURE9		m_pCloakTexture;	/// ¸ÁÅäÅØ½ºÃÄ.

#if __VER >= 8 //__Y_EYE_FLASH_8
	static LPDIRECT3DTEXTURE9		m_pTextureEye[2][MAX_HEAD];
	static LPDIRECT3DTEXTURE9		m_pTextureEyeFlash[2][MAX_HEAD];
#endif //__Y_EYE_FLASH_8

#endif // __CLIENT

#ifdef __WORLDSERVER
	CNpcProperty*	m_pNpcProperty;				/// NPC °íÀ¯ Á¤º¸( ´ë»ç, Äù½ºÆ®, ÆÄÀÏÀÌ¸§ ) ÇöÀç´Â ¸¶À» NPC ´ëÈ­Ã³¸®ÀÚ
	CTimer          m_timerQuestLimitTime;		/// Äù½ºÆ® Á¦ÇÑ ½Ã°£ Å¸ÀÌ¸Ó 
	DWORD	        m_dwPKTargetLimit;			/// PK¼±°øÁ¦ÇÑ½Ã°¢
	DWORD			m_dwTickCreated;			/// »ý¼º ½Ã°¢ 
	BOOL			m_bLastPK;					/// ¸¶Áö¸·À¸·Î Á×¾úÀ»¶§ ÇÃ·¹ÀÌ¾î¿¡°Ô(µà¾óÆ÷ÇÔ) Á×Àº°Ç°¡ ±×¿ÜÀÇ °æ¿ì·Î Á×Àº°Ç°¡.
	BOOL			m_bLastDuelParty;			/// ÆÄÆ¼µà¾ó·Î »ç¸Á?
	CTime			m_tGuildMember;				/// ±æµå Å»Åð ½Ã°¢ 
	BOOL			m_bGuildCombat;				/// ±æµå ´ëÀü Áß?
//	OBJID			m_idCollecter;				/// thisÀÇ Ã¤Áý¼ÒÀ¯ÀÚ.
//	int				m_nResource;				/// ÀÚ¿ø º¸À¯·®. - ¸ó½ºÅÍÃø¿¡¼­ »ç¿ë.
//	int				m_nCollectOwnCnt;			/// > 0 ÀÎ»óÈ²Àº this´Â m_idCollecter°ÍÀÌ´Ù.
	CSfxHitArray	m_sfxHitArray;				/// sfx hit Á¤º¸ ¹è¿­ 
	map< OBJID, queue< SFXHIT_INFO> >	m_mapSFXInfo;		/// sfx ÇØÅ· ¶§¹®¿¡ ....	
//	map< OBJID, int>					m_mapSFXCount;		/// sfx°¡ ¹ß»çµÇ¸é ++ 
	map< OBJID, queue< SFXHIT_COUNT > >	m_mapSFXCount;
#endif	// __WORLDSERVER

#ifdef __WORLDSERVER
private:
	void	DoUseEatPet( CItemElem* PitemElem );
	void	DoUseSystemPet( CItemElem* pItemElem );
public:
	void	ActivateEatPet( CItemElem* pItemElem );
	void	ActivateSystemPet( CItemElem* pItemElem );
	void	InactivateEatPet( void );
	void	InactivateSystemPet( CItemElem* pItemElem );

#if __VER >= 15 // __PETVIS
	void	SetPetVisDST( CItemElem* pItemElem );
	void	ResetPetVisDST( CItemElem* pItemElem );
	void	ProcessVisPet();
#endif // __PETVIS
#endif	// __WORLDSERVER
#if __VER >= 12 // __PET_0519
	BOOL	IsUsingEatPet( CItemElem* pItemElem );	// »ç¿ëÁßÀÎ ¸ÔÆêÀÎ°¡?
#endif	// __PET_0519

	BOOL	HasActivatedEatPet( void )		{	return m_oiEatPet != NULL_ID;	}
	BOOL	HasActivatedSystemPet( void )	{	return m_dwPetId != NULL_ID;	}
	OBJID	GetEatPetId( void )		{	return m_oiEatPet;		}
	void	SetEatPetId( OBJID oiEatPet )		{	m_oiEatPet	= oiEatPet;	}
	DWORD	GetPetId( void )	{	return m_dwPetId;	}
	void	SetPetId( DWORD dwPetId )		{	m_dwPetId	= dwPetId;	}
private:
	DWORD	m_dwPetId;	// ¼ÒÈ¯ÁßÀÌ ÆêÀÇ ÀÎº¥Åä¸® À§Ä¡(í»), ¼ÒÈ¯ÁßÀÎ Æê ÀÎµ¦½º(öâ)
#if __VER >= 12 // __PET_0519
	int		DoUseItemPetTonic( CItemElem* pItemElem );	// Æê ¿µ¾çÁ¦ »ç¿ë
#endif	// __PET_0519
#if __VER >= 15 // __PETVIS
private:
	BOOL	SetValidNeedVis( CItemElem* pItemElem, int nPos, vector<BYTE> & vecValid );
public:
	vector<BYTE>	GetValidVisTable( CItemElem* pItemElem );
	BYTE		IsSatisfyNeedVis( CItemElem* pItemElemVisPet, ItemProp* pItemPropVis );			
	CItemElem*	GetVisPetItem( void )	{ return m_Inventory.GetAtId( m_objIdVisPet ); }
	void		SetVisPetItem( OBJID objId )	{ m_objIdVisPet = objId; }
	BOOL		HasActivatedVisPet()	{ return m_objIdVisPet != NULL_ID; }
	DWORD		m_dwMoverSfxId;	// ¹«¹ö¿¡ ºÙ´Â ÀÌÆåÆ®
private:
	OBJID		m_objIdVisPet;	// ¼ÒÈ¯ÁßÀÎ ºñ½ºÆêÀÇ ÀÎº¥Åä¸® À§Ä¡
#endif // __PETVIS

public:
#if __VER >= 9	// __PET_0410
	CPet*	GetPet( void );
	CItemElem*	GetPetItem( void );
	void	PetLevelup( void );
	void	PetRelease( void );

#ifdef __CLIENT
	CClientPet	m_pet;
	CModelObject*	GetPetModel( void )		{	return (CModelObject*)( m_pet.GetObj()? m_pet.GetObj()->m_pModel: NULL );	}
	void	CreatePetSfx( void );
#if __VER >= 12 // __UPDATE_OPT
	BOOL	IsOptionRenderMask()	{	return !IsMode( MODE_OPTION_DONT_RENDER_MASK );	}
#endif	// __UPDATE_OPT
#else	// __CLIENT	// __WORLDSERVER
	void	ProcessPetAvail( void );
	void	ProcessPetEnergy( void );
	void	ProcessPetExp( void );
	int		DoUseItemFeedPocket( CItemElem* pItemElem );
#endif	// __CLIENT
#endif	// __PET_0410

#ifdef __SYS_TICKET
	CItemElem*	GetTicket( void );
#endif	// __SYS_TICKET

#if __VER >= 11 // __SYS_POCKET
	CItemElem*	GetItemId2( int nPocket, int nItem, BOOL bExpiration = TRUE );
#if (defined (__BAG_LOOT) && defined (__DROP_LOG)) || (defined (__BAG_LOOT) && defined (__FL_FARM_STAT))
	BOOL	CreateItem2(CItemElem* pItem, int nPocket, BOOL bAddDropLog = TRUE);
#else
	BOOL	CreateItem2(CItemElem* pItem, int nPocket);
#endif
	void	RemoveItem2( int nItem, short nNum, int nPocket );
#endif	// __SYS_POCKET

#if __VER >= 11 // __SYS_COLLECTING
	int						m_nMaxCltTime;
	int						m_nCltTime;
	BOOL	IsCollecting( void )	{	return	m_pActMover->GetActionState() == OBJSTA_COLLECT;	}
	virtual	void	ProcessCollecting( void );
	virtual	void	StartCollecting( void );
	virtual	void	StopCollecting( void );
	CItemElem*	GetCollector( void );
#endif	//	__SYS_COLLECTING

	int				m_nSkillLevel;				/// Áö±Ý±îÁö ¿Ã¸° ½ºÅ³·¹º§
	int				m_nSkillPoint;				/// ½ºÅ³ ÂïÀ» Æ÷ÀÎÆ® ¼öÄ¡ 

	CTimer			m_SkillTimer;
	BOOL			m_SkillTimerStop;
	
#if __VER >= 8 //__CSC_VER8_5
	BOOL			m_pAngelFlag;				/// Angel Buff Exist?
	CModelObject*	m_pAngel;					/// Angel Model Object.
	D3DXVECTOR3		m_AngelPos;					/// Angel Position.
	D3DXMATRIX		m_AngelWorldM;				/// Angel Matrix.
	DWORD			m_dwAngelKind;				/// Angel Kind.
#endif //__CSC_VER8_5
	
#ifdef __EVE_BALLOON
	BOOL			m_pBalloonFlag;				/// Balloon Buff Exist?
	CModelObject*	m_pBalloon;					/// Balloon Model Object.
	D3DXVECTOR3		m_BalloonPos;				/// Balloon Position.
	D3DXMATRIX		m_BalloonWorldM;			/// Balloon Matrix.
	DWORD			m_dwBalloonKind;			/// Balloon Kind.
	float			m_fBalloonYPos;				/// Balloon Y Position
	BOOL			m_bBalloon;
#endif //__EVE_BALLOON

private:
	SET_OBJID		m_idEnemies;				/// Àû¿¡°Ô °ø°Ý¹ÞÀº Á¤º¸ 

	OBJACT			m_oaCmd;					/// ¿ÀºêÁ§Æ® ¸í·É  
	int				m_nCParam[3];				/// ¹ü¿ë ¸í·É ÆÄ¶ó¸ÞÅÍ
	OBJACT			m_oaAct;					/// ¿ÀºêÁ§Æ® Çàµ¿»óÅÂ
#if __VER >= 8 // __S8_PK
	int				m_nAParam[5];				/// ¹ü¿ë Çàµ¿ ÆÄ¶ó¸ÞÅÍ
#else // __VER >= 8 // __S8_PK
	int				m_nAParam[4];				/// ¹ü¿ë Çàµ¿ ÆÄ¶ó¸ÞÅÍ
#endif // __VER >= 8 // __S8_PK

	LONG			m_adjParamAry[ MAX_ADJPARAMARY ];		/// ¼öÁ¤ ÆÄ¶ó¹ÌÅÍ( ¿¹: hp + ¼öÁ¤hp )
	LONG			m_chgParamAry[ MAX_ADJPARAMARY ];		/// ±³Ã¼ ÆÄ¶ó¹ÌÅÍ( ¿¹: ±³Ã¼ hp )

	BOOL			m_bRegenItem;				/// NPC »óÀÎÀÌ ÆÈ ¾ÆÀÌÅÛ »ý¼ºÇØ µÎ¾ú´Â°¡ flag  
	int				m_nMovePattern;				/// NPC ÆÐÅÏ ÀÌµ¿ Å¸ÀÔ
	int				m_nMoveEvent;				/// NPC ÆÐÅÏ ÀÌµ¿¶§ ¾²ÀÌ´Â »óÅÂº¯È­ 99¸é »óÅÂ³¡
	int				m_nMoveEventCnt;			/// NPC ÆÐÅÏÀÌµ¿¶§ ¾²ÀÌ´Â »óÅÂº¯È­Ä«¿îÅÍ

#ifdef	__CLIENT
	DWORD			m_dwLadolfFlag;
	CModelObject*   m_pLadolf;					/// ¶óµ¹ÇÁ¸ðµ¨
	int				m_nDmgCnt;					/// µ¥¹ÌÁö Ä«¿îÆ®
#if __VER >= 14 // __WING_ITEM
	enum WingStateFlag
	{
		FLOATING, FLYING, TURNING
	};

	WingStateFlag	m_eWingStateFlag;		/// ¾Ö´Ï¸ÞÀÌ¼Ç ÇÃ·¡±× ½ºÀ§Ä¡
	float			m_fOldLengthSq;			/// ³¯°³ ¾Ö´Ï¸ÞÀÌ¼Ç ¼Óµµ º¯È­·®ÀÇ ½ÃÀÛÁ¡À» ÀúÀåÇÏ±â À§ÇÑ º¯¼ö
#endif // __WING_ITEM
#if __VER >= 8 //__Y_EYE_FLASH_8
	CTimer			m_tmEye[2];
#endif //__Y_EYE_FLASH_8
#ifdef __MOUNT
	enum MountState
	{
		GROUND_WALK,
		GROUND_STAND,
		GROUND_IDLE1,
		GROUND_IDLE2,
		GROUND_RUN,
		GROUND_START_FLY,
		FLY_WALK,
		FLY_STAND,
		FLY_IDLE1,
		FLY_IDLE2,
		FLY_START_WALK
	};
	MountState m_eMountState;
#endif // __MOUNT
#endif // __CLIENT

#if __VER >= 15 // __CAMPUS
private:
	u_long	m_idCampus;			// »çÁ¦ ¾ÆÀÌµð
	//int		m_nCampusPoint;		// »çÁ¦ Æ÷ÀÎÆ®
public:
	int		m_nCampusPoint;		// »çÁ¦ Æ÷ÀÎÆ®
	u_long	GetCampusId()		{	return m_idCampus;	}
	void	SetCampusId( u_long idCampus )		{	m_idCampus = idCampus;	}
	int		GetCampusPoint()	{	return m_nCampusPoint;	}
	void	SetCampusPoint( int nMPPoint )		{	m_nCampusPoint = nMPPoint;	}
#endif // __CAMPUS
#ifdef __SYS_WORLDBOSS
	BOOL m_bIsWorldBoss;
	vector<u_long> m_wbAttackers;
	vector<const char*> _worldbossHWID;
#endif // __SYS_WORLDBOSS
#ifdef __ANI_WING
	CModelObject* m_pMask;
#endif
#ifdef __NEW_ITEM_VARUNA
	DWORD	dwBarunaPetItemId;
	u_long	m_idBarunaPetOwner;
	u_long	GetBarunaPetOwner() { return m_idBarunaPetOwner; }
	void	DoUseBarunaPet(CItemElem *pItemElem);
	void	InactivateBarunaPet();
	void	ProcBarunaPet();
#endif // __NEW_ITEM_VARUNA

#ifdef __PARTY_FIND
public:
	BOOL	m_bPartyJoin;
#endif // __PARTY_FIND

#ifdef __DPSMETER_RYU
#ifdef __CLIENT
	BOOL m_bShowDPS;
#endif // __CLIENT
#ifdef __WORLDSERVER
	BOOL m_bIsDPSMover;
	vector<__DPSPLAYER> m_aDPSPlayer;
#endif // __WORLDSERVER
#endif // __DPSMETER_RYU

protected:
	int				m_nCount;					/// ¹«¹ö°¡ ¹ü¿ëÀ¸·Î ¾²´Â ¼øÂ÷Àû Ä«¿îÅÍ. »ý¼ºÀÚ ¿Ü¿£ 0À¸·Î ÃÊ±âÈ­ ÇÏÁö ¸»°Í.
	DWORD			m_dwGold;					/// Æä³Ä 
	DWORD			m_dwRideItemIdx;			/// ºñÇàÃ¼ÀÇ ¾ÆÀÌÅÛ ÀÎµ¦½º
	CModelObject*	m_pRide;					/// ºñÇàÃ¼ °´Ã¼ Æ÷ÀÎÅÍ 
	TCHAR			m_szName[MAX_NAME];			/// ÀÌ¸§ 
#ifdef __MOUNT
	DWORD			m_dwMountItemID;
	CModelObject* m_pMountModel;
#endif // __MOUNT
public:
	static CMover*  GetActiveMover() { return (CMover*)m_pObjActive; }	// ÁÖÀÎ°ø °´Ã¼ ¾ò±â 	
	static	int		GetHairCost( CMover* pMover, BYTE nR, BYTE nG, BYTE nB, BYTE nHair );
#ifdef __TABBED_INV
	static void		UpdateParts(int nSex, int nSkinSet, int nFace, int nHairMesh, int nHeadMesh, PEQUIP_INFO pEquipInfo, CModelObject* pModel, CInventoryContainer< CItemElem  >* pInventory, BOOL bIfParts = TRUE, CMover* pMover = NULL);
	static BOOL		DoEquip(int nSex, int nSkinSet, CItemElem* pItemElem, int nPart, const EQUIP_INFO& rEquipInfo, CInventoryContainer< CItemElem  >* pInventory, PEQUIP_INFO pEquipeInfo, CModelObject* pModel, BOOL bEquip, CMover* pMover);
#else // __TABBED_INV
	static void		UpdateParts(int nSex, int nSkinSet, int nFace, int nHairMesh, int nHeadMesh, PEQUIP_INFO pEquipInfo, CModelObject* pModel, CItemContainer< CItemElem  >* pInventory, BOOL bIfParts = TRUE, CMover* pMover = NULL);
	static BOOL		DoEquip(int nSex, int nSkinSet, CItemElem* pItemElem, int nPart, const EQUIP_INFO& rEquipInfo, CItemContainer< CItemElem  >* pInventory, PEQUIP_INFO pEquipeInfo, CModelObject* pModel, BOOL bEquip, CMover* pMover);
#endif // __TABBED_INV
	static	float	GetItemEnduranceInfluence( int nEndurance );	
	static	int		GetItemEnduranceWeight( int nEndurance );	

	virtual	BOOL	SetIndex( LPDIRECT3DDEVICE9 pd3dDevice, DWORD dwIndex, BOOL bInitProp = FALSE, BOOL bDestParam = TRUE );
	virtual BOOL	Read( CFileIO* pFile );
	virtual void	Process();
	virtual	void	Serialize( CAr & ar ); // ½Ã¸®¾ó¶óÀÌÁî ; ³×Æ®¿÷ »óÅÂ¿¡¼­ ¼­¹ö¿Í Å¬¶óÀÌ¾ðÆ®, Å¬¶óÀÌ¾ðÆ® ¼­¹ö°¡ ÁÖ°í¹ÞÀ» ÆÐÅ¶ ³»¿ë 
	virtual	CModel* LoadModel( LPDIRECT3DDEVICE9 pd3dDevice, DWORD dwType, DWORD dwIndex );
	virtual void	InitProp( BOOL bInitAI = TRUE );		// °´Ã¼¸¦ ÇÁ·ÎÆÛÆ¼ ³»¿ëÀ¸·Î ÃÊ±âÈ­ 	
//	virtual int		OnActCollecting();				// User¸¸ »ç¿ëµÇ´Â °ÍÀÌ¹Ç·Î CUser°¡¼­ Ã£À»°Í.
#ifdef __NO_HP_DMG_LIMIT
	virtual long long SendDamage(DWORD dwAtkFlag, OBJID idAttacker, long long nParam = 0, BOOL bTarget = TRUE) { return m_pActMover->SendDamage(dwAtkFlag, idAttacker, nParam, bTarget); }
	virtual long long SendDamageForce(DWORD dwAtkFlag, OBJID idAttacker, long long nParam = 0, BOOL bTarget = TRUE) { return m_pActMover->SendDamageForce(dwAtkFlag, idAttacker, nParam, bTarget); }	// °­°ø°Ý
#else
	virtual int		SendDamage(DWORD dwAtkFlag, OBJID idAttacker, int nParam = 0, BOOL bTarget = TRUE) { return m_pActMover->SendDamage(dwAtkFlag, idAttacker, nParam, bTarget); }
	virtual int		SendDamageForce(DWORD dwAtkFlag, OBJID idAttacker, int nParam = 0, BOOL bTarget = TRUE) { return m_pActMover->SendDamageForce(dwAtkFlag, idAttacker, nParam, bTarget); }	// °­°ø°Ý
#endif
	void			Init();										// °´Ã¼ ÃÊ±âÈ­ 
#ifdef __REBIRTH
	void			InitLevelRebirth(int nJob, LONG nLevel, BOOL bGamma = TRUE);
#endif
	void			InitLevel( int nJob, LONG nLevel, BOOL bGamma = TRUE );			// °´Ã¼¸¦ nLevel·Î ¹Ù²ãÁÜ
#ifdef __NEW_CHANGE_JOB
	void			ChangeJob(int nJob, BOOL bGamma = TRUE);
#endif // __NEW_CHANGE_JOB
	void			ProcessAniSpeed();
	void			AllocShopInventory( LPCHARACTER pCharacter );
	BOOL			IsVendorNPC();
	void			CheckTickCheer();
	void			SetCheerParam( int nCheerPoint, DWORD dwTickCount, DWORD dwRest );
	void			ClearEquipInfo();
#ifdef __NO_HP_DMG_LIMIT
	__int64			GetMaxPoint(int nDest);
#else
	int				GetMaxPoint(int nDest);
#endif
	DWORD			GetReuseDelay( int nIndex );
	BOOL			InitSkillExp();
	void			InitCharacter( LPCHARACTER lpCharacter );	// ÀÌ¸§ ÃÊ±âÈ­ LoadDialogÈ£Ãâ 
	LPCHARACTER		GetCharacter();								// 
	void			InitNPCProperty();							// NPC°ü·Ã ½ºÅ©¸³Æ® ÃÊ±âÈ­ 	
	BOOL			LoadDialog();								// dialog ½ºÅ©¸³Æ® ·Îµå 
	void			ProcessRecovery();							// HP, MP, FPÈ¸º¹À» Ã³¸®ÇÑ´Ù.
	BOOL			IsActiveMover() { return m_pObjActive == this; }	// ³»°¡ ÁÖÀÎ°ø °´Ã¼ÀÎ°¡?
	int				IsSteal( CMover *pTarget );		// pTargetÀ» ½ºÆ¿ÇÏ·Á ÇÏ´Â°¡.
	int				IsSteal( OBJID idTaget );		// id·Î °Ë»çÇÏ´Â ¹öÀü.
	u_long			GetPartyId() { return m_idparty; }
	BOOL			IsMode( DWORD dwMode ); 
	void			SetMode( DWORD dwMode )		{ m_dwMode |= dwMode; }	// À¯Àú»óÅÂ ™VÆÃ
	void			SetNotMode( DWORD dwMode )	{ m_dwMode &= (~dwMode); } // À¯Àú»óÅÂ ¸®™V
	BOOL			SetDarkCover( BOOL bApply, DWORD tmMaxTime = 0 );
	BOOL			SetStun( BOOL bApply, DWORD tmMaxTime = 0 );
#ifdef __GAMEGUARD
	BOOL			SetPoison(BOOL bApply, OBJID idAttacker = NULL_ID, DWORD tmMaxTime = 0, DWORD tmUnit = 0, int wDamage = 0);	// this¸¦ µ¶¿¡ °É¸®°Ô ÇÑ´Ù.
#else // __GAMEGUARD
	BOOL			SetPoison(BOOL bApply, OBJID idAttacker = NULL_ID, DWORD tmMaxTime = 0, DWORD tmUnit = 0, short wDamage = 0);	// this¸¦ µ¶¿¡ °É¸®°Ô ÇÑ´Ù.
#endif // __GAMEGUARD
	BOOL			SetDark( BOOL bApply, DWORD tmMaxTime = 0, int nAdjHitRate = 0 );	// this¸¦ ¾ÏÈæ»óÅÂ¿¡ ºüÁö°Ô ÇÑ´Ù .
#ifdef __GAMEGUARD
	BOOL			SetBleeding(BOOL bApply, OBJID idAttacker = NULL_ID, DWORD tmMaxTime = 0, DWORD tmUnit = 0, int wDamage = 0);	// this¸¦ ÃâÇ÷½ÃÅ²´Ù.
#else // __GAMEGUARD
	BOOL			SetBleeding(BOOL bApply, OBJID idAttacker = NULL_ID, DWORD tmMaxTime = 0, DWORD tmUnit = 0, short wDamage = 0);	// this¸¦ ÃâÇ÷½ÃÅ²´Ù.
#endif // __GAMEGUARD
	void			RemoveDebuff( DWORD dwState );		// µð¹öÇÁ ÇØÁ¦
	void			RemoveBuffOne( DWORD dwSkill = 0 );		// ¹öÇÁ ÇÏ³ª ÇØÁ¦
	void			RemoveBuffAll();				// ¹öÇÁ ¸ðµÎ ÇØÁ¦.
	BOOL			IsStateMode( DWORD dwMode ); 
	void			SetStateMode( DWORD dwMode, BYTE nFlag );		// À¯Àú»óÅÂ ™VÆÃ
	void			SetStateNotMode( DWORD dwMode, BYTE nFlag );	// À¯Àú»óÅÂ ¸®™V
	BOOL			IsUseItemReadyTime( ItemProp* pItemProp, OBJID dwObjItemId );
	BOOL			IsNPC()				{ return !m_bPlayer; }
	BOOL			IsPlayer()			{ return m_bPlayer; }
	BOOL			IsEquipableNPC()	{	return( GetCharacter() && GetCharacter()->m_nEquipNum > 0 );	}
	BOOL			IsFlyingNPC()		{ return (m_dwTypeFlag & OBJTYPE_FLYING) ? TRUE : FALSE; }		// ºñÇàÇü ¸÷ÀÎ°¡.
	BOOL			IsFly();
	MoverProp*		GetProp() { return prj.GetMoverProp( m_dwIndex ); }	// °´Ã¼ÀÇ ÇÁ·ÎÆÛÆ¼ ¾ò±â 	
	ItemProp*		GetActiveHandItemProp( int nParts = PARTS_RWEAPON );							// ¼Õ¿¡ µé·ÁÁø ¾ÆÀÌÅÛÀÇ ÇÁ·ÎÆÛÆ¼¸¦ ¾ò±â 
	ItemProp*		GetTransyItem( ItemProp* pItemProp, BOOL bCheck = FALSE, LPCTSTR lpszFileName = NULL );
	OBJID			GetDestId()			{ return m_idDest; }
	CCtrl*			GetDestObj()		{ return prj.GetCtrl( m_idDest ); }
	void			SetDestObj( CCtrl* pObj, float fRange = 0.0f )	{	SetDestObj( pObj->GetId(), fRange );	}
	D3DXVECTOR3		GetDestPos()		{ return m_vDestPos; }
	void			SetDestPos( CONST D3DXVECTOR3& vDestPos, bool bForward = true, BOOL fTransfer = TRUE );
	void			SetDestPos( CShip *pIAObj, const D3DXVECTOR3 &vDestPos );
	
	void			ClearDestObj()     	{ m_idDest = NULL_ID; m_fArrivalRange = 0.0f; }
	void			ClearDestPos()		{ m_vDestPos = D3DXVECTOR3( 0.0f, 0.0f, 0.0f ); }		
	void			ClearDest()			{ ClearDestObj(); ClearDestPos(); }
	void			SetStop()			{ SendActMsg( OBJMSG_STAND ); ClearDestObj(); } // ¸ØÃã 

	BOOL			IsEmptyDestObj()	{ return m_idDest == NULL_ID; }
	BOOL			IsEmptyDestPos()	{ return m_vDestPos.x == 0.0f && m_vDestPos.z == 0.0f; }
	BOOL			IsEmptyDest()		{ return IsEmptyDestPos() && IsEmptyDestObj(); }
	void			SetDestAngle( float fDestAngle, bool bLeft )	{	m_fDestAngle	= fDestAngle;	m_bLeft	= bLeft;	}
	void			ClearDestAngle()	{ m_fDestAngle	= -1.0f; }
	BOOL			IsRegionAttr( DWORD dwAttribite ) { return ( m_dwRegionAttr & dwAttribite ) == dwAttribite ? TRUE : FALSE; }
	REGIONELEM*		UpdateRegionAttr();
	DWORD			GetRideItemIdx()	{ return m_dwRideItemIdx; }
	void			SetRide( CModel *pModel, int nRideItemIdx = 0 ) { m_dwRideItemIdx = nRideItemIdx; m_pRide = (CModelObject*)pModel; 	};
#ifdef __MOUNT
	DWORD			GetMountId() { return m_dwMountItemID; }
	CModelObject* GetMountModel() { return m_pMountModel; }
	void			SetMount(CModel* pModel, int nMountItemID = 0) { m_dwMountItemID = nMountItemID; m_pMountModel = (CModelObject*)pModel; };
#endif // __MOUNT
#ifdef __ANI_WING
	void			SetMaskWing(CModel* pModel)
	{
		m_pMask = (CModelObject*)pModel;
	};
#endif
	void			ClearDuel();
	void			ClearDuelParty();		
#ifdef __NO_HP_DMG_LIMIT
	long long		SendActMsg(OBJMSG dwMsg, long long nParam1 = 0, long long nParam2 = 0, long long nParam3 = 0, long long nParam4 = 0);
#ifdef __INSTANCE_AGGRO_SYSTEM
	void			SendAIMsg(DWORD dwMsg, unsigned long long dwParam1 = 0, unsigned long long dwParam2 = 0, unsigned long long dwParam3 = 0);
	void			PostAIMsg(DWORD dwMsg, unsigned long long dwParam1 = 0, unsigned long long dwParam2 = 0, unsigned long long dwParam3 = 0);
#else // __INSTANCE_AGGRO_SYSTEM
	void			SendAIMsg(DWORD dwMsg, unsigned long long dwParam1 = 0, unsigned long long  dwParam2 = 0);
	void			PostAIMsg(DWORD dwMsg, unsigned long long dwParam1 = 0, unsigned long long  dwParam2 = 0);
#endif // __INSTANCE_AGGRO_SYSTEM
#else
	int				SendActMsg(OBJMSG dwMsg, int nParam1 = 0, int nParam2 = 0, int nParam3 = 0, int nParam4 = 0);
#ifdef __INSTANCE_AGGRO_SYSTEM
	void			SendAIMsg(DWORD dwMsg, DWORD dwParam1 = 0, DWORD dwParam2 = 0, DWORD dwParam3 = 0);
	void			PostAIMsg(DWORD dwMsg, DWORD dwParam1 = 0, DWORD dwParam2 = 0, DWORD dwParam3 = 0);
#else // __INSTANCE_AGGRO_SYSTEM
	void			SendAIMsg(DWORD dwMsg, DWORD dwParam1 = 0, DWORD dwParam2 = 0);
	void			PostAIMsg(DWORD dwMsg, DWORD dwParam1 = 0, DWORD dwParam2 = 0);
#endif // __INSTANCE_AGGRO_SYSTEM
#endif
	BOOL			SetMotion(DWORD dwMotion, int nLoop = ANILOOP_LOOP, DWORD dwOption = 0 );	// MOP_SWDFORCE, MOP_FIXED, MOP_NO_TRANS, MOP_HITSLOW
	BOOL			InitMotion(DWORD dwMotion);
	void			SetDamagedMotion( CMover* pAttacker, DWORD dwAtkFlags );
	CItemElem*		GetWeaponItem( int nParts = PARTS_RWEAPON );					// ÀåÂøÇÑ ¹«±â ¾ò±â 
	CItemElem*		GetLWeaponItem();					// ¿Þ¼Õ¿¡ ÀåÂøÇÑ ¹«±â ¾ò±â.
	CItemElem*		GetEquipItem( int nParts );			// ÀåÂøÇÑ ¾ÆÀÌÅÛ ¾ò±â 
#ifdef __TABBED_INV
	ItemProp* GetEquipItemProp( CInventoryContainer<CItemElem>* pInventory, PEQUIP_INFO pEquipInfo, int nParts );
#else
	ItemProp* GetEquipItemProp( CItemContainer<CItemElem>* pInventory, PEQUIP_INFO pEquipInfo, int nParts );
#endif // __TABBED_INV
	BOOL			IsDualWeapon();
	void			RedoEquip( BOOL fFakeParts, BOOL bDestParam = TRUE );	
	void			UpdateParts( BOOL bFakeParts  = FALSE ); // normal or fake
	int				InvalidEquipOff( BOOL fFakeparts );		// °Å½Ã±âÇÑ Àåºñ¸¦ ¹þ±è.
	BOOL			DoEquip( CItemElem* pItemElem, BOOL bEquip, int nPart = -1 ); // for normal
#if __VER >= 11 // __SYS_IDENTIFY
	BOOL			IsEquipAble( CItemElem* pItem,BOOL bIgnoreLevel = FALSE );		// ÀåÂø°¡´ÉÇÑ°¡?
#else	// __SYS_IDENTIFY
	BOOL			IsEquipAble( ItemProp *pItemProp, OBJID dwObjid ,BOOL bIgnoreLevel = FALSE);		// ÀåÂø°¡´ÉÇÑ°¡?
#endif	// __SYS_IDENTIFY
	BOOL			IsUnEquipAble( ItemProp *pItemProp );					// ¹þ´Â°Ô °¡´ÉÇÑ°¡?
	void			SetEquipDstParam();
	void			SumEquipAdjValue( int* pnAdjHitRate, int* pnAdjParray );
	int				SumEquipDefenseAbility( LONG* pnMin, LONG* pnMax );
	void			SetDestParamEquip( ItemProp* pItemProp, CItemElem* pItemElem, BOOL bIgnoreSetItem = FALSE );
	void			ResetDestParamEquip( ItemProp* pItemProp, CItemElem* pItemElem );
	LPQUEST			FindQuest( int nQuestId );
	LPQUEST			GetQuest( int nQuestId );
	BOOL			RemoveQuest( int nQuestId );
	BOOL			IsCompleteQuest( int nQuestId );
	BOOL			MakeCompleteQuest( int nQuestId, LPQUEST lpQuest );
	BOOL			SetQuest( int nQuestId, int nState, LPQUEST lpReturnQuest );
	BOOL			SetQuest( LPQUEST lpQuest );
	void			RemoveAllQuest();
	void			RemoveCompleteQuest();
	BOOL            IsDisguise();
	BOOL			NoDisguise( LPDIRECT3DDEVICE9 pd3dDevice = NULL );
	BOOL			Disguise( LPDIRECT3DDEVICE9 pd3dDevice, DWORD dwMoverIndex );
	DWORD			IsAuthorization( DWORD dwAuthorization ) { return dwAuthorization == m_dwAuthorization; }
	DWORD			IsAuthHigher( DWORD dwAuthorization ) { return dwAuthorization <= m_dwAuthorization; }
#ifdef __NAME_COLOR
	DWORD			GetNameColor() { return m_dwNameColor; }
#ifdef __NAME_FONT
	DWORD			GetNameFont() { return m_nNameFont; }
#endif // __NAME_FONT
#endif // __NAME_COLOR
	void			UpdateParam();		
#ifdef __NO_HP_DMG_LIMIT
	__int64			GetParam(int nDestParameter, __int64 nParam);
#else
	int				GetParam(int nDestParameter, int nParam);
#endif
#ifdef __ORIGIN_CARD_SYSTEM
	int				getCollectedCard(int nKind);
	int				getFilledPage();
	void			SetDestParamCard(int nCardId);
	void			ResetDestParamCard(int nCardId);
	int				GetCardInvIdx(CardProp* pPropCard) { return (pPropCard->dwCardID - II_SYS_CARD_SMALLAIBATT); }
	BOOL			CheckCardAlbum(CItemElem* pItemElem);
	void			AddCardToAlbum(CItemElem* pItemElem);
	void			RemoveCardToAlbum(int nCardIdx);
	void			AddCardToInv(int nCardSlot, int nCardID);
	void			RemoveCardToInv(int nCardSlot);
#endif // __ORIGIN_CARD_SYSTEM
#ifdef __NO_HP_DMG_LIMIT
	void			SetDestParam(int nDstParameter, long long nAdjParameterValue, int nChgParameterValue, BOOL fSend = TRUE);
#else
	void			SetDestParam(int nDstParameter, int nAdjParameterValue, int nChgParameterValue, BOOL fSend = TRUE);
#endif
	void			SetDestParam( int nItemIdx2, BOOL fSend = TRUE );
	void			SetDestParam( int nIdx, ItemProp *pProp, BOOL bSend = TRUE );
	void			ResetDestParam( int nDstParameter, int nAdjParameterValue, BOOL fSend = TRUE );
#ifdef __SPEED_SYNC_0108		// ResetDestParam speed ¼öÁ¤
	void			ResetDestParamSync( int nDstParameter,int nAdjParameterValue, int nParameterValue, BOOL fSend = TRUE );
#endif // __SPEED_SYNC_0108		// ResetDestParam speed ¼öÁ¤
	void			ResetDestParam( int nIdx, ItemProp *pProp, BOOL bSend = TRUE );
	int				GetAdjParam( int nDestParameter );
	int				GetChgParam( int nDestParameter );
#ifdef __NO_HP_DMG_LIMIT
	__int64			GetPointParam(int nDstParameter);
#else
	int				GetPointParam(int nDstParameter);
#endif
#ifdef __NO_HP_DMG_LIMIT
	void			SetPointParam(int nDstParameter, __int64 nValue, BOOL bTrans = FALSE); // bTrans°¡ TRUEÀÌ¸é °­Á¦Àü¼Û
#else
	void			SetPointParam(int nDstParameter, int nValue, BOOL bTrans = FALSE); // bTrans°¡ TRUEÀÌ¸é °­Á¦Àü¼Û
#endif
	void			OnApplySM();
	LPSKILL			GetSkill( int nType, int nIdx );
	LPSKILL			GetSkill( DWORD dwSkill );
	int				GetSkillIdx( DWORD dwSkill );
	void			OnEndSkillState( DWORD dwSkill, DWORD dwLevel );
	BOOL			CheckSkill( DWORD dwSkill );
	void			SetHair( int nHair );
	void			SetHairColor( DWORD dwHairColor );
	void			SetHairColor( FLOAT r, FLOAT g, FLOAT b );
	void			SetHead( int nHead );
	void			SetSkinSet( int nSkinSet );
	void			SetName( const char* lpszName )		{	lstrcpy( m_szName, lpszName );	}
	LPCTSTR			GetName( BOOL bNickname = FALSE );	// °´Ã¼ÀÇ ÀÌ¸§ ¾ò±â
#ifdef __GAMEMASTER
	CString			GetAuthStr(BOOL bHook = FALSE);
#endif // __GAMEMASTER
#ifdef __VIP
	BOOL			IsVip() { return HasBuffByIk3(IK3_VIP); }
	BOOL			IsVip2() { return HasBuffByIk3(IK3_AFK); }
	BOOL			IsVip3() { return HasBuffByIk3(IK3_VIP15); }
	BOOL			IsVip4() { return HasBuffByIk3(IK3_VIP30); }
	BOOL			IsVip5() { return HasBuffByIk3(IK3_VIP4EVER); }
#endif // __VIP
	BYTE			GetSex() { return m_bySex; }
	void			SetSex( BYTE bySex ) { m_bySex = bySex; }
	BOOL			IsPeaceful() { return m_dwBelligerence == BELLI_PEACEFUL; }
#ifdef __AFK_REWARD_SYSTEM
	BOOL			IsAfk() { return m_bAfk; }
#endif //__AFK_REWARD_SYSTEM
	BOOL			IsBaseJob();
	BOOL			IsExpert();
	BOOL			IsPro();
	BOOL			IsInteriorityJob( int nJob );
	BOOL			SetExpert( int nExpert );
	BOOL			AddChangeJob( int nJob );
	int				GetJob();
	int				GetExpPercent();
	int				SetLevel( int nSetLevel );
	int				AddGPPoint( int nAddGPPoint );
	void			SetJobLevel( int nLevel, int nJob );
	BOOL			IsJobType( DWORD dwJobType ); 
	int				GetLevel() { return m_nLevel; }
	int				GetFxp() { return m_nFxp; }
	int				GetTxp() { return m_nFxp; }
	EXPINTEGER		GetExp1()	{	return m_nExp1;	}
	EXPINTEGER		GetMaxExp1()	{	return prj.m_aExpCharacter[m_nLevel+1].nExp1;	}
	EXPINTEGER		GetMaxExp2()	{	return prj.m_aExpCharacter[m_nLevel].nExp2;	}
	int				GetRemainGP(); // growth
#ifdef __NO_HP_DMG_LIMIT
	void			IncHitPoint(__int64 nVal);
#else
	void			IncHitPoint(int nVal);
#endif
	void			IncManaPoint(int nVal) ;
	void			IncFatiguePoint(int nVal) ;
#ifdef __NO_HP_DMG_LIMIT
	void			SetHitPoint(__int64 nVal);
#else
	void			SetHitPoint(int nVal);
#endif
	void			SetManaPoint( int nVal ) ;
	void			SetFatiguePoint( int nVal ) ;
	float			GetExpFactor();
	float			GetItemDropRateFactor( CMover* pAttacker );
	float			GetPieceItemDropRateFactor( CMover* pAttacker );
	BOOL			AddExperience( EXPINTEGER nExp, BOOL bFirstCall = TRUE, BOOL bMultiply = TRUE, BOOL bMonster = FALSE );	// bMultiply : »ó¿ëÈ­ ¾ÆÀÌÅÛ Àû¿ë? // bMonster : ¸ó½ºÅÍ¸¦ Á×¿©¼­ ¿Â °æÇèÄ¡ ÀÎ°¡?
	BOOL			DecExperience( EXPINTEGER nExp, BOOL bExp2Clear, BOOL bLvDown );	// °æÇèÄ¡¸¦ ±ð´Â´Ù.
	BOOL			DecExperiencePercent( float fPercent, BOOL bExp2Clear, BOOL bLvDown  );	// °æÇèÄ¡¸¦ ÆÛ¼¾Æ®·Î ±ð´Â´Ù.
	BOOL			AddFxp( int nFxp );
	BOOL			SetFxp( int nFxp, int nFlightLv );
#if __VER < 8 // __S8_PK
	int				GetKarma() { return m_nSlaughter; }
#endif // __VER < 8 // __S8_PK
	BOOL			IsPVPTarget( CMover* pMover );
	BOOL			IsWarTarget( CMover* pMover );
	BOOL			IsSchoolTarget( CMover* pMover );
	HITTYPE			GetHitType( CMover* pMover, BOOL bTarget, int nReflect );
#ifdef __JEFF_11_4
	BOOL	IsArenaTarget( CMover* pMover );
#endif	// __JEFF_11_4
#if __VER >= 8 // __S8_PK
	HITTYPE			GetHitType2( CMover* pMover, BOOL bTarget, BOOL bGood );
#else // __VER >= 8 // __S8_PK
	HITTYPE			GetHitType2( CMover* pMover, BOOL bTarget );
#endif // __VER >= 8 // __S8_PK
#ifdef __DEATH_MATCH
private:
	BOOL			m_bFightState;
public:
	BOOL			IsSiegeTarget(CMover* pMover);
	BOOL			GetSiegeFightState() { return m_bFightState; };
	void			SetSiegeFightState(BOOL bFightState) { m_bFightState = bFightState; };
#endif // __DEATH_MATCH
	void			ReSetDuelTime( CMover* pAttacker , CMover* pDefender);
	BOOL			IncStrLevel();
	BOOL			IncStaLevel();
	BOOL			IncDexLevel();
	BOOL			IncIntLevel();
	int				GetHR();
	void			SetStr( int nStr ) { m_nStr = nStr; }
	void			SetSta( int nSta ) { m_nSta = nSta; }
	void			SetDex( int nDex ) { m_nDex = nDex; }
	void			SetInt( int nInt ) { m_nInt = nInt; }	
	int				GetStr();
	int				GetDex();
	int				GetInt();
	int				GetSta();
	FLOAT			GetSpeed(FLOAT fSrcSpeed);    
	int				GetGold();
#ifdef __BATTLEPASS
	int		m_nBPLevel;
	int		m_nBPPoints;
	int		m_nBPType;
	int		m_nBPEnable;
	__time64_t	m_szBPEndTime;
	BOOL	IsBattlePass();
	int		BattlePassSize();
#endif // __BATTLEPASS
#if __VER >= 12 // __LORD
	int		GetPerinNum( void );
	__int64		GetTotalGold( void );
#ifdef __WORLDSERVER
	int		RemoveTotalGold( __int64 iGold );	// Á¦°ÅµÈ Æä¸° °³¼ö
	int		RemovePerin( int nPerin );
#endif	// __WORLDSERVER
#endif	// __LORD
	void			SetGold( int nGold );
	BOOL			AddGold( int nGold, BOOL bSend = TRUE );
	int				GetHitPointPercent( int nPercent = 100 );
	int				GetManaPointPercent( int nPercent = 100 );
	int				GetFatiguePointPercent( int nPercent = 100 );
#ifdef __NO_HP_DMG_LIMIT
	__int64			GetHitPoint();
#else
	int				GetHitPoint();
#endif
	int				GetManaPoint();
	int				GetFatiguePoint();
#ifdef __NO_HP_DMG_LIMIT
	__int64				GetMaxHitPoint();
#else
	int				GetMaxHitPoint();
#endif
	int				GetMaxManaPoint();
	int				GetMaxFatiguePoint();
#ifdef __NO_HP_DMG_LIMIT
	__int64				GetMaxOriginHitPoint(BOOL bOrinal = TRUE);
#else
	int				GetMaxOriginHitPoint(BOOL bOrinal = TRUE);
#endif
	int				GetMaxOriginManaPoint( BOOL bOrinal = TRUE );
	int				GetMaxOriginFatiguePoint( BOOL bOrinal = TRUE );
#ifdef __NO_HP_DMG_LIMIT
	__int64			GetHPRecovery();
#else
	int				GetHPRecovery();
#endif
	int				GetMPRecovery();
	int				GetFPRecovery();
	int				GetNaturalArmor();
 	float			GetAttackSpeed();
#ifdef __SHOW_ALL_STATS
	int				GetSpeedDepla();
	int				GetCriticalRate();
	int				GetSpellCastSpeed();
	int				GetReflectDamage();
	int				GetHitRate();
	int				GetBlockmelee();
	int				GetBlockRange();
	int				GetEsquiveRate();
#endif //__SHOW_ALL_STATS
	float			GetCastingAniSpeed();
	int				GetCastingTime( int nCastingTime );
	float			GetDamageMultiplier( ATTACK_INFO* pInfo );
#ifdef __NO_HP_DMG_LIMIT
	long long		PostCalcMagicSkill(long long nATK, ATTACK_INFO* pInfo);
	long long		PostCalcGeneric(long long nATK, ATTACK_INFO* pInfo);
#else
	int				PostCalcMagicSkill(int nATK, ATTACK_INFO* pInfo);
	int				PostCalcGeneric(int nATK, ATTACK_INFO* pInfo);
#endif
	float			GetMagicSkillFactor( CMover* pDefender, SAI79::ePropType skillType );
	float			GetATKMultiplier( CMover* pDefender, DWORD dwAtkFlags );
	float			GetDEFMultiplier( ATTACK_INFO* pInfo );
	float			GetBlockFactor( CMover* pAttacker, ATTACK_INFO* pInfo );
	int				GetWeaponATK( DWORD dwWeaponType );
	int				GetPlusWeaponATK( DWORD dwWeaponType );
	int				GetWeaponPlusDamage( int nDamage, BOOL bRandom = TRUE );
	void			GetDamagePropertyFactor( CMover* pDefender, int* pnATKFactor, int* pnDEFFactor, int nParts );
	int				GetPropATKPlus( int nParts );
	int				GetPropDEFPlus();
	void			GetDamageRange( int& nMin, int& nMax );
	BOOL			IsBlocking( CMover* pAttacker );
	BOOL			CanFlyByAttack();
	BOOL			IsCriticalAttack( CMover* pDefense, DWORD dwAtkFlags );
	int				GetCriticalProb();
	int				GetReqMp( int nReqMp );
	int				GetReqFp( int nReqFp );
	BOOL			GetAttackResult( CMover* pHitObj, DWORD dwOption );
	int				GetAdjHitRate();
#ifdef __NO_HP_DMG_LIMIT
	long long		GetHitPower(ATTACK_INFO* pInfo);
#else
	int				GetHitPower(ATTACK_INFO* pInfo);
#endif
	int				GetRangeHitPower( ATTACK_INFO* pInfo );
	int				GetParrying();
	int				GetDefenseByItem( BOOL bRandom = TRUE );
	int				GetShowDefense( BOOL bRandom );
	int				GetResistMagic();
	int				GetResistSpell( int nDestParam );
#ifdef __NO_HP_DMG_LIMIT
	long long		GetMeleeSkillPower(ATTACK_INFO* pInfo);	// ±ÙÁ¢°ø°Ý ½ºÅ³µ¥¹ÌÁö
	long long		GetMagicHitPower(int nMagicPower);			// ¿Ïµå°ø°Ý µ¥¹ÌÁö
#else
	int				GetMeleeSkillPower(ATTACK_INFO* pInfo);	// ±ÙÁ¢°ø°Ý ½ºÅ³µ¥¹ÌÁö
	int				GetMagicHitPower(int nMagicPower);			// ¿Ïµå°ø°Ý µ¥¹ÌÁö
#endif
	int				GetItemAbility( int nItem );
	int				GetItemAbilityMin( int nItem );
	int				GetItemAbilityMax( int nItem );
#ifdef __NO_HP_DMG_LIMIT
	void			GetHitMinMax(long long* pnMin, long long* pnMax, ATTACK_INFO* pInfo = NULL);
#else
	void			GetHitMinMax(int* pnMin, int* pnMax, ATTACK_INFO* pInfo = NULL);
#endif
	BOOL			IsAfterDeath();
	BOOL			IsDie() { return m_pActMover->IsDie() || m_nHitPoint == 0; }
	BOOL			IsLive() { return m_pActMover->IsDie() == FALSE || m_nHitPoint > 0; }		// && ¸¦  ||·Î ¹Ù²åÀ½.  !=¸¦ >·Î ¹Ù²Þ
	int				GetCount() { return m_nCount; }
#if __VER >= 8 // __S8_PK
	void			SetPKPink( DWORD dwTime ) { if( dwTime == 0 || m_dwPKTime < dwTime ) m_dwPKTime = dwTime; }
	DWORD			GetPKPink( void ) { return m_dwPKTime; }
	BOOL			IsPKPink( void )	{ return m_dwPKTime > 0; }			/// PK ÇÎÅ© ¸ðµåÀÎÁö
	BOOL			IsChaotic( void ) { return m_dwPKPropensity > 0; }	/// Ä«¿ÀÀÎÁö
	void			SetPKValue( int nValue );
	int				GetPKValue( void ) { return m_nPKValue; }
	void			SetPKPropensity( DWORD dwValue );
	DWORD			GetPKPropensity( void ) { return m_dwPKPropensity; }
	DWORD			NextPKPropensity( int nPKValue );
#else // __VER >= 8 // __S8_PK
	BOOL			IsGuardReactionChao();
	BOOL			IsGuardReactionNormal(); 
	BOOL			IsChaotic() { return GetSlaughterGrade() != SLAUGHTER_NORMAL; }	
	SLAUGHTER_GRADE	GetSlaughterGrade();						
#endif // __VER >= 8 // __S8_PK
	float			GetResist(SAI79::ePropType p_PropType);
	int				GetSetItemParts(DWORD dwParts);
	int				GetSetItemClient();
	int				GetSetItem( CItemElem* pItemElem = NULL );
	BOOL			IsSetItemPart( DWORD dwParts );
	void			SetSetItemAvail( int nAbilityOption );
	void			ResetSetItemAvail( int nAbilityOption );
	void			DestParamPiercingAvail( CItemElem* pItemElem, BOOL bSET = TRUE );
	BOOL			Pierce( CItemElem *pSuit, DWORD dwItemId );
	void			SetDestParamSetItem( CItemElem* pItemElem );
	void			ResetDestParamSetItem( CItemElem* pItemElem );
	int				GetEquipedSetItemNumber( CSetItem* pSetItem );
	void			GetEquipedSetItem( int nSetItemId, BOOL* pbEquiped, int* pnEquip );
	void			SetDestParamRandomOpt( CItemElem* pItemElem );
	void			ResetDestParamRandomOpt( CItemElem* pItemElem );
	
	void	SetDestParamRandomOptOrigin( CItemElem* pItemElem );
	void	SetDestParamRandomOptExtension( CItemElem* pItemElem );
	void	ResetDestParamRandomOptOrigin( CItemElem* pItemElem );
	void	ResetDestParamRandomOptExtension( CItemElem* pItemElem );

#ifdef __NO_HP_DMG_LIMIT
	void			GetItemATKPower(long long* pnMin, long long* pnMax, ItemProp* pItemProp, CItemElem* pWeapon);
#else
	void			GetItemATKPower(int* pnMin, int* pnMax, ItemProp* pItemProp, CItemElem* pWeapon);
#endif
	float			GetItemMultiplier( CItemElem* pItemElem );
	BOOL			SubLootDropNotMob( CItem *pItem );
	BOOL			SubLootDropMobSingle( CItem *pItem );
	BOOL			SubLootDropMobParty( CItem *pItem, CParty *pParty );
	BOOL			SubLootDropMob( CItem *pItem );
	BOOL			DoLoot( CItem *pItem );		// ¹Ù´Ú¿¡ ¶³¾îÁø pItemÀ» ÁÝ´Â´Ù.
	void			PickupGoldCore( int nGold );
	void			PickupGold( int nGold, BOOL bDropMob );
	BOOL			IsDropable( CItemElem* pItemElem, BOOL bPK );
 	BOOL			IsDropableState( BOOL bPK );
	CItem*			DropGold( DWORD dwGold, const D3DXVECTOR3& vPos, BOOL bPK = FALSE );
#if __VER >= 15 // __PETVIS
	void			UpdateItem( BYTE nId, CHAR cParam, DWORD dwValue, DWORD dwTime = 0 );
#else // __PETVIS
	void			UpdateItem( BYTE nId, CHAR cParam, DWORD dwValue );
#endif // __PETVIS
#ifdef __BAG_UPDATE
	void			UpdateItemBag(BYTE nId, CHAR cParam, DWORD dwValue, int nBag, DWORD dwTime = 0);
#endif
#if __VER >= 11 // __SYS_IDENTIFY
	void		UpdateItemEx( unsigned char id, char cParam, __int64 iValue );
#endif	// __SYS_IDENTIFY
	CItem*			_DropItemNPC( DWORD dwItemType, DWORD dwID, short nDropNum, const D3DXVECTOR3 &vPos );
	CItem*			DropItem( DWORD dwID, short nDropNum, const D3DXVECTOR3 &vPos, BOOL bPlayer = FALSE );
	int				DoDropItemRandom( BOOL bExcludeEquip, CMover* pAttacker, BOOL bOnlyEquip = FALSE );
	int				GetItemNum( DWORD dwItemId );
#ifdef __CLIENT
	int				GetItemNumForClient( DWORD dwItemId ); // Client¿¡¼­¸¸ »ç¿ëÇÏ´Â ¾ÆÀÌÅÛ °¹¼ö ±¸ÇÏ±â(Null check ÀÌ¿ÜÀÇ Usable check¾ÈÇÔ)
#endif //__CLIENT
	int				RemoveAllItem( DWORD dwItemId );
	BOOL			AddItem( CItemBase* pItemBase );
	CItemBase*		GetItemId( DWORD dwId );
	void			RemoveItemId( DWORD dwId  );
	void			SetKeeptimeInven( DWORD dwItemId, DWORD dwTime );
	void			SetKeeptimeBank( DWORD dwItemId, DWORD dwTime );
	void			SetKeeptimeItem( CItemElem* pItemElem, DWORD dwTime );
	void			OnTradeRemoveUser();
	BOOL			AddItemBank( int nSlot, CItemElem* pItemElem );
	void			UpdateItemBank( int nSlot, BYTE nId, CHAR cParam, DWORD dwValue );
	CItemBase*		GetItemBankId( int nSlot, DWORD dwId );
	void			RemoveItemBankId( int nSlot, DWORD dwId );
	void			GenerateVendorItem( ItemProp** apItemProp, int* pcbSize, int nMax, LPVENDOR_ITEM pVendor );
	BOOL			DropItemByDied( CMover* pAttacker );		// Á×¾î¼­ ¶³¾îÆ®¸®´Â µå¶ø.
#if __VER >= 8 // __S8_PK
	BOOL			DoUseSkill( DWORD dwSkill, int nLevel, OBJID idFocusObj, SKILLUSETYPE sutType = SUT_NORMAL, BOOL bControl = FALSE, const int nCastingTime = 0 );		// dwSkill/nLevel¸¸ °¡Áö°íµµ »ç¿ëÇÒ ¼ö ÀÖ´Â ¹öÀü.
#else // __VER >= 8 // __S8_PK
	BOOL			DoUseSkill( DWORD dwSkill, int nLevel, OBJID idFocusObj, SKILLUSETYPE sutType = SUT_NORMAL, const int nCastingTime = 0 );		// dwSkill/nLevel¸¸ °¡Áö°íµµ »ç¿ëÇÒ ¼ö ÀÖ´Â ¹öÀü.
#endif // __VER >= 8 // __S8_PK
	void			SetPKTargetLimit( int nSec );
	void			ClearCmd(); 
	OBJACT			GetCmd() { return m_oaCmd; }
	OBJACT			GetAct() { return m_oaAct; }
	int				GetCmdParam( int nIdx ) { return m_nCParam[nIdx]; }	
	void			ClearActParam(); 
	int				GetEnemyCount();
	OBJID			GetMaxEnemyHitID();
#ifdef __NO_HP_DMG_LIMIT
	unsigned long	AddEnemy(OBJID objid, long long nHit);
	long long		GetEnemyHit(OBJID objid, DWORD* pdwTick = NULL);
#else
	DWORD			AddEnemy(OBJID objid, int nHit);
	int				GetEnemyHit(OBJID objid, DWORD* pdwTick = NULL);
#endif
	void			RemoveEnemy( OBJID objid  );
	void			RemoveAllEnemies();
	BOOL			IsAttackAble( CObj *pObj );
	FLOAT			GetAttackRange( DWORD dwAttackRange );
	BOOL			IsAttackAbleNPC( CMover* pNPC );
	BOOL			IsPKInspection( CMover* pMover );
	int				IsPKPVPInspectionBase( DWORD dwRegionAttr, BOOL bPVP = TRUE );
#if __VER >= 8     // 8Â÷ µà¾óÁ¸¿¡ °ü°è¾øÀÌ PVP°¡´ÉÇÏ°ÔÇÔ   Neuz, World
	int				IsPVPInspectionBase( DWORD dwRegionAttr,DWORD dwWorldID, BOOL bPVP = TRUE );//8Â÷ µà¾óÁ¸¿¡ °ü°è¾øÀÌ PVP°¡´ÉÇÏ°ÔÇÔ   Neuz, World
#endif	// __VER >= 8  
	BOOL			SubPKPVPInspectionBase( CMover* pMover, CMover* pMover1, DWORD dwPKAttr, int nFlag );
	void			PrintString( CMover* pMover, DWORD dwId );
	int				CMD_SetUseSkill( OBJID idTarget, int nSkillIdx, SKILLUSETYPE sutType = SUT_NORMAL );
	void			CMD_SetMeleeAttack( OBJID idTarget, FLOAT fRange = 0.0f );
	void			CMD_SetMagicAttack( OBJID idTarget, int nMagicPower );
	void			CMD_SetRangeAttack( OBJID idTarget, int nPower );
	void			CMD_SetMoveToPos( const D3DXVECTOR3 &vPos );
	void			CMD_SetMoveToObj( OBJID idObj );
	void			CMD_SetUseItem( CCtrl *pCtrl );
//	void			CMD_SetCollect( CObj *pObj );
	void			OnAfterUseItem( const ItemProp* pItemProp );
	void			UnequipRide();		
	void			EquipItem( CItemElem *pItemElem, BOOL bEquip, int nPart );
	BOOL			DoUseEquipmentItem( CItemElem* pItemElem, DWORD dwId, int nPart );
	BOOL			DoUseItemVirtual( DWORD dwItemId, BOOL bEffectSkip );
	BOOL			DoUseItem( DWORD dwItemId, DWORD dwFocusId, int nPart = -1 );
#ifdef __BAG_UPDATE
	BOOL			DoUseItemBag(DWORD dwItemId, DWORD dwFocusId, int nBag);
#endif
	BOOL			DoUseItemBlinkWing( ItemProp *pItemProp, CItemElem* pItemElem, BOOL bUes = TRUE );
	BOOL			DoUseItemFood_SM( ItemProp *pItemProp, CItemElem* pItemElem );
	BOOL			DoUseItemFood( ItemProp *pItemProp, CItemElem* pItemElem );
	BOOL			DoUseItemWarp( ItemProp* pItemProp, CItemElem* pItemElem );
	int				DoUseItemSystem( ItemProp *pItemProp, CItemElem* pItemElem, int nPart = -1 );
#if __VER >= 16
	int				DoUseItemOnce( ItemProp* pItemProp, CItemElem* pItemElem, int nPart = -1);
	int				DoUseItemKeep( ItemProp* pItemProp, CItemElem* pItemElem, int nPart = -1);
#endif
	void			DoPickupItemAround();
	int				DoAttackMagic( CObj *pTargetObj, int nMagicPower,int idSfxHit = 0 );
	int				DoAttackRange( CObj *pTargetObj, DWORD dwItemID, int idSfxHit );
#ifdef __ATTACK_TRACKING	
	void			TrackLocalConsecutiveHits(DWORD lastTarget, DWORD count, double time);
#endif //__ATTACK_TRACKING
	int				DoAttackSP( CObj *pTargetObj, DWORD dwItemID );
	int				DoAttackMelee( CMover *pTarget, OBJMSG dwMsg = OBJMSG_ATK1, DWORD dwItemID = 0 );
	int				DoAttackMelee( OBJID idTarget, OBJMSG dwMsg = OBJMSG_ATK1, DWORD dwItemID = 0 );
	int				DoDie( CCtrl *pAttackCtrl, DWORD dwMsg = 0 );	// µØÁ®¶ó.	
	void			ChangeFame( CMover *pLose );
	int				DuelResult( CMover *pLose );
	PVP_MODE		GetPVPCase( CMover *pAttacker );
	void			SubPVP( CMover *pAttacker, int nReflect );	// »ç¶÷°ú »ç¶÷ÀÇ ½Î¿ò¿¡¼­ Á×¾úÀ»¶§.
	int				SubDuel( CMover *pAttacker );	// µà¾óÁß¿¡ Á×¾úÀ»¶§ 
	int				SubPK( CMover *pAttacker, int nReflect );		// PK¿¡ÀÇÇØ Á×¾úÀ»¶§.
	int				SubWar( CMover *pAttacker );	// ÀüÀï¶§ Á×¾úÀ½
	int				SubExperience( CMover *pDead );
	void			AddKillRecovery();
	BOOL			IsValidArea( CMover* pMover, float fLength );
	void			SetJJim( CMover *pJJimer );		// this¸¦ pJJimer°¡ ÂòÇß´Ù´Â°É Ç¥½Ã.
	void			SubReferTime( DWORD *pTime1, DWORD *pTime2, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp );
#ifdef __NO_HP_DMG_LIMIT
	BOOL			ApplyParam(CCtrl* pSrc, ItemProp* pSkillProp, AddSkillProp* pAddSkillProp, BOOL bSend = TRUE, long long nDamage = 0);	// this¿¡°Ô ÆÄ¶ó¸ÞÅÍ¸¦ Àû¿ë. pSrc´Â ½ÃÀüÀÚ.
#else
	BOOL			ApplyParam(CCtrl* pSrc, ItemProp* pSkillProp, AddSkillProp* pAddSkillProp, BOOL bSend = TRUE, int nDamage = 0);	// this¿¡°Ô ÆÄ¶ó¸ÞÅÍ¸¦ Àû¿ë. pSrc´Â ½ÃÀüÀÚ.
#endif
	BOOL			ApplyMagicSkill( CMover *pMover, DWORD dwSkill, DWORD dwLevel, ItemProp *pSkillProp, AddSkillProp *pAddSkillProp );	// pMover¿¡°Ô ½ºÅ³È¿°ú¸¦ Àû¿ëÇÔ.
	BOOL			GetSkillProp( ItemProp **ppSkillProp, AddSkillProp **ppAddSkillProp, int nSkill, DWORD dwLevel, LPCTSTR szErr );
	BOOL			CreateSkillEffect( OBJID idTarget, int nSkill, DWORD dwLevel );		// ½ÇÁ¦ ½ºÅ³ ¹ßµ¿.
	void			RemoveInvisible();		// Åõ¸íÈ­ »óÅÂ°É·ÁÀÖÀ¸¸é ÇØÁ¦ÇÔ.
	void			SendDamageAround( int nDmgType, CMover *pAttacker, int nApplyType, int nAttackID, float fRange, float fTargetRatio, float fAroundRatio );	// this¸¦ Áß½ÉÀ¸·Î ÁÖº¯¿¡ µ¥¹ÌÁö¸¦ ÀÔÈû.
	void			SendDamageLine( int nDmgType, int nApplyType, int nAttackID, float fWidth, float fHeight, float fDepth );
	void			ChangeExpRatio( CMover* pAttacker, CMover* pDefender );
#ifdef __NO_HP_DMG_LIMIT
	void			OnAttacked(CMover* pAttacker, long long nDamage, BOOL bTarget, int nReflect);
#else
	void			OnAttacked(CMover* pAttacker, int nDamage, BOOL bTarget, int nReflect);
#endif
	BOOL			OnDamage( int nItemID, DWORD dwState, CMover *pHitObj, const D3DXVECTOR3 *pvDamagePos = NULL, DWORD dwAtkFlag = AF_GENERIC );
#if __VER >= 9	// __SKILL_0706
	void			SetCoolTime( AddSkillProp* pAddSkillProp, LPCTSTR szCall );
#else	// __SKILL_0706
	void			SetCoolTime( ItemProp *pSkillProp, LPCTSTR szCall );
#endif	// __SKILL_0706
#ifdef __CLIENT
#ifdef __VOICE_LINES
	void			PlayClientVoiceLines(ItemProp* pSkillProp);
#endif //__VOICE_LINES
#endif //
	BOOL			OnMeleeSkill( int nType, int nCount = 1 );		// OBJMSG_ATK_MELEESKILL½ÇÇàÈÄ Å¸Á¡ÀÌ µÇ¾úÀ»¶§ ¹ß»ýÇÏ´Â ÀÌº¥Æ®.
	BOOL			OnMagicSkill( int nType, int nCount = 1 );		// OBJMSG_ATK_MAGICSKILL½ÇÇàÈÄ Å¸Á¡ÀÌ µÇ¾úÀ»¶§ ¹ß»ýÇÏ´Â ÀÌº¥Æ®.
	BOOL			OnAttackRange();		// Àå°Å¸®¹«±â°¡ ¹ß»çµÇ´Â ½ÃÁ¡¿¡ ¹ß»ýÇÏ´Â ÀÌº¥Æ®
	BOOL			OnAttackMelee( DWORD dwState, CMover *pHitObj );		// ±Ù°Å¸®°ø°Ý½Ã Å¸Á¡ÀÌ µÇ¾úÀ»¶§ ¹ß»ýÇÏ´Â ÀÌº¥Æ®.
	BOOL			OnAttackMeleeContinue( DWORD dwState );		// Ã¹¹øÂ° Å¸Á¡ÀÌÈÄºÎÅÍ ¾Ö´Ï³¡³¯¶§±îÁö °è¼Ó.
	void			OnAttackMelee_ClockWorks( DWORD dwState, CMover *pHitObj );
	void			OnAttackMelee_BigMuscle( DWORD dwState, CMover *pHitObj );	
	void			OnAttackMelee_Krrr( DWORD dwState, CMover *pHitObj );	
	void			OnAttackMelee_Bear( DWORD dwState, CMover *pHitObj );	
#ifdef __NEW_BOSSMECHANICS
#ifdef __WORLDSERVER
	void			CreateClockworkAttack4(DWORD skillID, OBJID idTarget);
	void			CreateClockworkAttack3(DWORD skillID, OBJID idTarget);
	void			CreateClockworkAttack2(DWORD skillID, OBJID idTarget);
	void			CreateClockworkAttack1(DWORD skillID, OBJID idTarget);

	void			CreateKarvanAttack1(DWORD skillID, OBJID idTarget);
	void			CreateKarvanAttack2(DWORD skillID, OBJID idTarget);
	void			CreateKarvanAttack3(DWORD skillID, OBJID idTarget);
	void			CreateKarvanAttack4(DWORD skillID, OBJID idTarget);

	void			CreateStorm(DWORD skillID, vector<D3DXVECTOR3> attacks, D3DXVECTOR3& vPos, OBJID idTarget, int ver, int delay);
	vector<D3DXVECTOR3> CreateCycle(D3DXVECTOR3 start, D3DXVECTOR3 end, int distance, int step);
	vector<D3DXVECTOR3> CreateCircle(D3DXVECTOR3 center, int radius, int amount);
	void			OnAttackMelee_CustomBoss1(BOSSMECHANICS mechanics, CMover* pHitObj);
	void			CustomBossAttack_SelfAttack(BOSSATTACK attack, D3DXVECTOR3& center, float modelRadius);
	void			CustomBossAttack_LineAttack(BOSSATTACK attack, bool isRandom, D3DXVECTOR3& center, float modelRadius);
	void			CustomBossAttack_TriangleAttack(BOSSATTACK attack, D3DXVECTOR3& center, float modelRadius);
	void			CustomBossAttack_CornerAttack(BOSSATTACK attack, D3DXVECTOR3& center, float modelRadius);
	void			CustomBossAttack_CircleAttack(BOSSATTACK attack, D3DXVECTOR3& center, float modelRadius, int waves);
	void			CustomBossAttack_SquareAttack(BOSSATTACK attack, D3DXVECTOR3& center, float modelRadius);
	void			CustomBossAttack_RandomAttack(BOSSATTACK attack, D3DXVECTOR3& center, float modelRadius);
	void			CustomBossAttack_Targetted(BOSSATTACK attack, D3DXVECTOR3& center);
	void			CustomBossAttack_CreateAttack(BOSSATTACK attack, D3DXVECTOR3& vPos, int customDelay = -1);
	void			CustomBossAttack_CreateAttackStorm(BOSSATTACK attack, D3DXVECTOR3& vPos, OBJID idTarget);
#endif //__WORLDSERVER
#endif //__NEW_BOSSMECHANICS	
#if __VER >= 10 // __Y_DRAGON_FIRE
	void			OnAttackMelee_Meteonyker( DWORD dwState, CMover *pHitObj );
#endif//__Y_DRAGON_FIRE
	BOOL			OnAttackMagic();		// ¿Ïµå°ø°ÝÀÌ ¹ß»çµÇ´Â ½ÃÁ¡¿¡ ¹ß»ýÇÏ´Â ÀÌº¥Æ®.
	BOOL			OnAttackSP();			// Æ¯¼ö°ø°Ý.
	void			OnActDrop();			// Ä³¸¯ÅÍ°¡ ³ôÀº°÷¿¡¼­ ¶³¾îÁö±â ½ÃÀÛÇÏ´Â ½ÃÁ¡¿¡ ¹ß»ý.
	void			OnActCollision();		//
	void			OnActEndMeleeSkill();	// ±ÙÁ¢½ºÅ³ µ¿ÀÛÀÌ ³¡³ª´Â ½ÃÁ¡¿¡ ¹ß»ý.
	void			OnActEndMagicSkill();	// ¸¶¹ý½ºÅ³ µ¿ÀÛÀÌ ³¡³ª´Â ½ÃÁ¡¿¡ ¹ß»ý.
	void			OnEndMeleeAttack( DWORD dwState );		// ÀÏ¹Ýµ¿ÀÛ °ø°Ý ³¡³¯¶§ ¹ß»ý(¸÷¸¸).
	void			OnActEndJump4();		// ÂøÁö ÇÃ·¡±×°¡ »ç¶óÁö´Â ¼ø°£.
	void			OnActLanding();		// ÂøÁö ÇÏ´Â ¼ø°£.
	void			OnActFMove();
	void			OnActIALanding( CObj *pIAObj, const D3DXVECTOR3 &vPos );		// Interact¿ÀºêÁ§Æ®¿¡ ÂøÁöÇßÀ»¶§.
	void			OnAttackStart( CMover *pTarget, OBJMSG dwMsg );					// °ø°ÝÀ» ¸· ½ÃÀÛÇßÀ»¶§(ÀÏ¹Ý/½ºÅ³/¿Ïµå µî)
	BOOL			IsBullet( ItemProp* pItemProp );
	void			ProcessMovePattern();
	int				GetMovePattern() { return m_nMovePattern; }
	int				GetMoveEvent() { return m_nMoveEvent; }
	void			SetMovePattern( int nPattern );		// ÀÌµ¿ÆÐÅÏ ¼³Á¤.
//	BOOL			DoCollect( CMover *pTarget );
	void			BehaviorActionForceSet();		// ¸í·ÉÀÌ Çàµ¿ ¸í·ÉÀÌ¸é °­Á¦ µ¿±âÇÏ°í, ¹«ºù ¸í·ÉÀÌ¸é ¹«½ÃÇÑ´Ù.
	void			ActionForceSet( D3DXVECTOR3 &vPos, D3DXVECTOR3 &vDelta, FLOAT fAngle, 
									DWORD dwState, DWORD dwStateFlag, int nMotion, int nMotionEx, 
									int nLoop, DWORD dwMotionOption );
	void			ActionForceSet2( D3DXVECTOR3 &vPos, D3DXVECTOR3 &vDelta, FLOAT fAngle,
									 FLOAT fAngleX, FLOAT fAccPower, FLOAT fTurnAngle,
									 DWORD dwState, DWORD dwStateFlag, int nMotion, int nMotionEx, 
									 int nLoop, DWORD dwMotionOption );
	void			HalfForceSet( D3DXVECTOR3 & vPos, D3DXVECTOR3 & vd,	float fAngle, float fAnlgeX, 
		                          float fAccPower, float fTurnAngle );
	CGuild*			GetGuild();
	CGuildWar*		GetWar();
	BOOL			IsSMMode( int nType ) { return ( m_dwSMTime[nType] > 0 ) ? TRUE : FALSE; }
	void			ReState();
#ifdef __S_ADD_RESTATE
	void			ReStateOne( int nKind );
#endif // __S_ADD_RESTATE
#ifdef __ADD_RESTATE_LOW
	void			ReStateOneLow( int nKind );
#endif // __ADD_RESTATE_LOW
	float			GetJobPropFactor( JOB_PROP_TYPE type );
#ifdef __NO_HP_DMG_LIMIT
	long long		CalcDefense(ATTACK_INFO* pInfo, BOOL bRandom = TRUE);
	long long		CalcDefenseCore(CMover* pAttacker, DWORD dwAtkFlags, BOOL bRandom = TRUE);
	long long		CalcDefensePlayer(CMover* pAttacker, DWORD dwAtkFlags);
	long long		CalcDefenseNPC(CMover* pAttacker, DWORD dwAtkFlags);
#else
	int				CalcDefense(ATTACK_INFO* pInfo, BOOL bRandom = TRUE);
	int				CalcDefenseCore(CMover* pAttacker, DWORD dwAtkFlags, BOOL bRandom = TRUE);
	int				CalcDefensePlayer(CMover* pAttacker, DWORD dwAtkFlags);
	int				CalcDefenseNPC(CMover* pAttacker, DWORD dwAtkFlags);
#endif
	void			PutLvUpSkillName_1( DWORD dwLevel );
	void			PutLvUpSkillName_2( DWORD dwSkill );
	BOOL			IsRegionMove( DWORD dwOlgRegionAttr, DWORD dwRegionAttr );
	DWORD			GetPKPVPRegionAttr();
	CItemBase*		GetVendorItem();		
	BOOL			IsAttackMode();
	void			AddSkillPoint( int nPoint);
	
#if __VER >= 8     // 8Â÷ µà¾óÁ¸¿¡ °ü°è¾øÀÌ PVP°¡´ÉÇÏ°ÔÇÔ   Neuz, World
	void			DoPVPEnd( CCtrl *pAttackCtrl, bool bWinner , DWORD dwMsg = 0 );	// µà¾ó³¡³­µÚ Ã³¸®
#ifdef __NO_HP_DMG_LIMIT
	void			EndPVP(long long nPVPHP);	// µà¾ó³¡³­µÚ Ã³¸®
#else
	void			EndPVP(int	nPVPHP);	// µà¾ó³¡³­µÚ Ã³¸®
#endif
	BOOL			m_bPVPEnd;			//µà¾óÀÌ ³¡³µ´Â°¡
#endif	// __VER >= 8  

#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	BYTE			GetLegendChar()	;
	void			SetLegendChar(	BYTE	nLegend	)	{	m_nLegend	=	nLegend;	}
	BOOL			IsMaster();
	BOOL			IsHero();
	void			SetMasterSkillPointUp();
#ifdef __3RD_LEGEND16
	BOOL			IsLegendHero();
#endif
#ifdef __NEWCLASS
	BOOL			IsLegendHeroUltimate();
#endif // __NEWCLASS
#endif	//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

#if __VER >= 14 // __NEW_ITEM_LIMIT_LEVEL
	DWORD			GetJobType( int nJob = NULL_ID )	{	if( nJob == NULL_ID ) nJob = m_nJob;	return prj.m_aJob[ nJob ].dwJobType;	}	// Á÷¾÷ Å¸ÀÔ
#endif // __NEW_ITEM_LIMIT_LEVEL


#if __VER >= 8 //__CSC_VER8_5
	void			AngelMoveProcess();
#endif //__CSC_VER8_5
#ifdef __EVE_BALLOON
	void			BalloonMoveProcess();
#endif //__EVE_BALLOON

#if __VER >= 8 // __S8_PK
	void			OnAttackSFX( OBJID	idTarget, int nMagicPower, DWORD dwSkill, int nDmgCnt, float	fDmgAngle, float fDmgPower,  DWORD dwAtkFlags, BOOL bControl );
#else // __VER >= 8 // __S8_PK
	void			OnAttackSFX( OBJID	idTarget, int nMagicPower, DWORD dwSkill, int nDmgCnt, float	fDmgAngle, float fDmgPower,  DWORD dwAtkFlags );
#endif // __VER >= 8 // __S8_PK
	BOOL			IsGuildCombatTarget( CMover* pMover );
#ifdef __WORLDSERVER
	void	ProcessSFXDamage( void );
	void	ProcessSFXExpire( void );
#endif	// __WORLDSERVER

#if __VER >= 9	// __PET_0410
	void	ProcessPet( void );
#endif	// __PET_0410

#ifdef __WORLDSERVER
	void			SetDestObj( OBJID idObj, float fRange = 0.0f, BOOL bSend = FALSE );
#else
	void			SetDestObj( OBJID idObj, float fRange = 0.0f, BOOL bSend = TRUE );
#endif

#if defined(__WORLDSERVER)
#if __VER < 8 // __S8_PK
	void			UpgradeKarma();
#endif // __VER < 8 // __S8_PK
	BOOL			IsPVPInspection( CMover* pMover, int nFlag = 0 );
	void			AddExperienceKillMember( CMover *pDead, EXPFLOAT fExpValue, MoverProp* pMoverProp, float fFxpValue );
	void			AddExperienceSolo( EXPFLOAT fExpValue, MoverProp* pMoverProp, float fFxpValue, BOOL bParty );
	void			AddExperienceParty( CMover *pDead, EXPFLOAT fExpValue, MoverProp* pMoverProp, float fFxpValue, CParty* pParty, CUser* apMember[], int* nTotalLevel, int* nMaxLevel10, int* nMaxLevel, int* nMemberSize );
	void			AddExperiencePartyContribution( CMover *pDead, CUser* apMember[], CParty* pParty, EXPFLOAT fExpValue, float fFxpValue, int nMemberSize, int nMaxLevel10 );
	void			AddExperiencePartyLevel( CUser* apMember[], CParty* pParty, EXPFLOAT fExpValue, float fFxpValue, int nMemberSize, int nMaxLevel10 );
	BOOL			GetPartyMemberFind( CParty* pParty, CUser* apMember[], int* nTotalLevel, int* nMaxLevel10, int* nMaxLevel, int* nMemberSize );
	float			GetExperienceReduceFactor( int nLevel, int nMaxLevel );
//	BOOL			IsResourceMonster() { return m_nResource != -1; }		// ÀÚ¿ø¸ó½ºÅÍ³Ä? -1ÀÌ¸é ÀÚ¿ø¸ó½ºÅÍ°¡ ¾Æ´Ï´Ù. 0 ~ ÀÚ¿ø¸ó½ºÅÍ¶ó´Â ¶æ.
	void			ArrowDown( int nCount );
	int				GetQueueCastingTime();
#if __VER >= 8 // __S8_PK
	BOOL			DoUseSkill( int nType, int nIdx, OBJID idFocusObj, SKILLUSETYPE sutType, BOOL bControl );
	float			SubDieDecExp( BOOL bTransfer = TRUE, DWORD dwDestParam = 0, BOOL bResurrection = FALSE  );	// Á×¾úÀ»¶§ °âÄ¡ ±ð´Â ºÎºÐ.
#else // __VER >= 8 // __S8_PK
	BOOL			DoUseSkill( int nType, int nIdx, OBJID idFocusObj, SKILLUSETYPE sutType );
	float			SubDieDecExp( BOOL bTransfer = TRUE, DWORD dwDestParam = 0 );	// Á×¾úÀ»¶§ °âÄ¡ ±ð´Â ºÎºÐ.
#endif // __VER >= 8 // __S8_PK

	void			SubAroundExp( CMover *pAttacker, float fRange );		// this¸¦ Áß½ÉÀ¸·Î fRange¹üÀ§¾È¿¡ ÀÖ´Â À¯Àú¿¡°Ô °æÇèÄ¡¸¦ ¹èºÐÇÑ´Ù.
	void			AddPartyMemberExperience( CUser * pUser, EXPINTEGER nExp, int nFxp );
	void			GetDieDecExp( int nLevel, FLOAT& fRate, FLOAT& fDecExp, BOOL& bPxpClear, BOOL& bLvDown );
#if __VER >= 8 // __S8_PK
	void			GetDieDecExpRate( FLOAT& fDecExp, DWORD dwDestParam, BOOL bResurrection );
#else // __VER >= 8 // __S8_PK
	void			GetDieDecExpRate( FLOAT& fDecExp, DWORD dwDestParam, int nSlaughter );
#endif // __VER >= 8 // __S8_PK
#if defined  (__FL_FARM_STAT) || defined (__DROP_LOG)
	BOOL			CreateItem(CItemBase* pItemBase, BYTE* pnId = NULL, short* pnNum = NULL, BYTE nCount = 0, BOOL bAdd = FALSE);
#else
	BOOL			CreateItem(CItemBase* pItemBase, BYTE* pnId = NULL, short* pnNum = NULL, BYTE nCount = 0);
#endif
	void			RemoveItem( BYTE nId, short nNum );
	int				RemoveItemA( DWORD dwItemId, short nNum );
	void			RemoveVendorItem( CHAR chTab, BYTE nId, short nNum );
	void			RemoveItemIK3( DWORD dwItemKind3 );
	BOOL			DoUseItemSexChange( int nFace );
	BOOL			ReplaceInspection( REGIONELEM* pPortkey );
	BOOL			Replace(u_long uIdofMulti, DWORD dwWorldID, D3DXVECTOR3& vPos, REPLACE_TYPE type, int nLayer, BOOL bTeleportImage = FALSE);
#if __VER < 8 // __S8_PK
	int				ChangeSlaughter( CHANGE_SLAUGHTER_TYPE type, CMover* pDefender, int nSetCarmaPoint = 0 );
	int				IncSlaughterPoint2( CMover *pDead );
	int				IncSlaughterPoint( CMover *pDead );
#endif // __VER < 8 // __S8_PK
	BOOL			IsLoot( CItem *pItem, BOOL bPet = FALSE );
	void			ProcInstantBanker();
	void			ProcInstantGC();
	BOOL			IsItemRedyTime( ItemProp* pItemProp, OBJID dwObjid, BOOL bItemFind );
#ifdef __NO_HP_DMG_LIMIT
	long long		ApplyDPC(long long ATK, ATTACK_INFO* pInfo);
	long long		CalcLinkAttackDamage(long long nDamage); // ÆÄÆ¼½ºÅ³:¸µÅ©¾îÅÃÀÇ Ãß°¡ µ¥ÀÌ¹Ì°è»ê 	
#else
	int				ApplyDPC(int ATK, ATTACK_INFO* pInfo);
	int				CalcLinkAttackDamage(int nDamage); // ÆÄÆ¼½ºÅ³:¸µÅ©¾îÅÃÀÇ Ãß°¡ µ¥ÀÌ¹Ì°è»ê 	
#endif	
#ifdef __NO_HP_DMG_LIMIT
	long long		CalcPropDamage(CMover* pDefender, DWORD dwAtkFlags);
	long long		CalcGenericDamage(CMover* pDefender, DWORD& dwAtkFlags);
	long long		GetMagicSkillPower(ATTACK_INFO* pInfo);
#else
	int				CalcPropDamage(CMover* pDefender, DWORD dwAtkFlags);
	int				CalcGenericDamage(CMover* pDefender, DWORD& dwAtkFlags);
	int				GetMagicSkillPower(ATTACK_INFO* pInfo);
#endif
	void			SubSMMode();
	void			ClearAllSMMode();
#if defined(__BUFF_SERVER) || defined (__REMOVE_CMM)
	void			RemoveSMMode(int nType);
#endif // __BUFF_SERVER
	BOOL			SetSMMode( int nType, DWORD dwTime );
	void			Abrade( CMover* pAttacker, int nParts = PARTS_RWEAPON );
	DWORD			GetRandomPartsAbraded();
	void			SetMarkingPos();
	void			RemoveSFX( OBJID idTarget, int id, BOOL bForce, DWORD dwSkill );
	int				GetSFXCount( OBJID idTarget );
	void			IncSFXCount( OBJID idTarget, DWORD dwSkill );
	void			AddSFXInfo( OBJID idTarget, SFXHIT_INFO& info );
	void			ClearSFX( OBJID idTarget );
	int				GetSummonState();
	BOOL			IsDoUseBuff( ItemProp* pItemProp );
	
#endif // __WORLDSERVER

#ifdef __CLIENT
	virtual void	Render( LPDIRECT3DDEVICE9 pd3dDevice );

	void			InitInterpolation();
	void			Interpolate();
	BOOL			IsStateDbuff();
	BOOL			EndMotion();
	BOOL			IsPKAttackAble( CMover* pMover );
	BOOL			IsPVPAttackAble( CMover* pMover );
	CSfx*			CreateSfxArrow( DWORD dwSfxObjArrow, DWORD dwSfxObjHit, D3DXVECTOR3 vPosDest, int idTarget );
	void			SetDmgCnt( int nDmgCnt ) { m_nDmgCnt = nDmgCnt; }
	void			CreateAbilityOption_SetItemSFX( int nAbilityOption );
	BOOL			GetEquipFlag( int nParts, BYTE* pbyFlag );
	void			OverCoatItemRenderCheck(CModelObject* pModel);
	void			PlayCombatMusic();
	BOOL			IsLoot( CItem *pItem ) { return TRUE; }
	LPCTSTR			GetFameName();						// ¸í¼º ÀÌ¸§ ¾ò±â
#if __VER < 8 // __S8_PK
	LPCTSTR			GetSlaughterName();					// ½½·¯ÅÍÀÌ¸§ ¾ò±â
#endif // __VER < 8 // __S8_PK
	LPCTSTR			GetJobString();						// Á÷¾÷ ÀÌ¸§ ¾ò±â 
	void			DialogOut( LPCTSTR lpszText );		// ¸»Ç³¼±¿¡ ÀÇÇÑ ´ë»ç Ãâ·Â
	BOOL			DoFakeEquip( const EQUIP_INFO & rEquipInfo, BOOL bEquip, int nPart, CModelObject* pModel = NULL ); // for Fake
#ifdef __ATTACK_TRACKING
	void			RenderGauge( LPDIRECT3DDEVICE9 pd3dDevice, int nValue, int maxValue);
#else // __ATTACK_TRACKING
	void			RenderGauge(LPDIRECT3DDEVICE9 pd3dDevice, int nValue);
#endif // __ATTACK_TRACKING
	void			RenderTurboGauge( LPDIRECT3DDEVICE9 pd3dDevice, DWORD nColor, int nValue, int nMaxValue );
	void			SetRenderPartsEffect( int nParts );
	void			RenderPartsEffect( LPDIRECT3DDEVICE9 pd3dDevice );
	void			RenderName( LPDIRECT3DDEVICE9 pd3dDevice, CD3DFont* pFont, DWORD dwColor = 0xffffffff );
	void			RenderHP(LPDIRECT3DDEVICE9 pd3dDevice);
#if __VER >= 11 // __SYS_COLLECTING
	void			RenderCltGauge(LPDIRECT3DDEVICE9 pd3dDevice);
#endif
	void			RenderChrState(LPDIRECT3DDEVICE9 pd3dDevice);
	void			RenderFlag( int nType );
	void			RenderCasting( LPDIRECT3DDEVICE9 pd3dDevice );
	void			RenderCtrlCasting( LPDIRECT3DDEVICE9 pd3dDevice );
#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	void			RenderSkillCasting( LPDIRECT3DDEVICE9 pd3dDevice );
#endif	//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	void			RenderPVPCount( LPDIRECT3DDEVICE9 pd3dDevice );
	void			RenderQuestEmoticon( LPDIRECT3DDEVICE9 pd3dDevice );
	void			RenderGuildNameLogo( LPDIRECT3DDEVICE9 pd3dDevice, CD3DFont* pFont, DWORD dwColor );
#if __VER >= 8 // __S8_PK
	BOOL			DoUseSkill( int nType, int nIdx, OBJID idFocusObj, SKILLUSETYPE sutType, BOOL bControl, const int nCastingTime, DWORD dwSkill = 0, DWORD dwLevel = 0 );
#else // __VER >= 8 // __S8_PK
	BOOL			DoUseSkill( int nType, int nIdx, OBJID idFocusObj, SKILLUSETYPE sutType, const int nCastingTime, DWORD dwSkill = 0, DWORD dwLevel = 0 );
#endif // __VER >= 8 // __S8_PK
#if __VER >= 8 //__CSC_VER8_5
	void			RenderAngelStatus(LPDIRECT3DDEVICE9 pd3dDevice);
#endif //__CSC_VER8_5
#endif	// __CLIENT

	int				GetSkillLevel( SKILL* pSkill );
	BOOL			SetExperience( EXPINTEGER nExp1, int nLevel );

	BOOL	IsUsing( CItemElem* pItemElem );

	BOOL	IsShoutFull( void );
	BOOL	IsCommBank( void );

private:
	void			ProcessMove();
	void			ProcessMoveArrival( CCtrl *pObj );
	void			ProcessRegenItem();
	void			ProcessRegion();
	void			ProcessQuest();
	void			ProcessIAObjLink( D3DXVECTOR3& vPos);
	void			ProcessActionPoint();
#ifdef __CLIENT
	void			ProcessScaleSlerp();
	void			ProcessWaterCircle( const D3DXVECTOR3& vPosTemp, const D3DXVECTOR3& vPos );
	void			ProcessWalkSound();
#ifdef __TRAILS
	void			ProcessTrails();
#ifdef	__MALEVOLENT_EVENT
	void			ProcessTrailsEvent();
#endif	// __MALEVOLENT_EVENT
#endif // __TRAILS
	void			ProcessDustSFX();
	void			ProcessETC();
#else
	void			ProcessScript();
	void			ProcessAbnormalState();
	void			ProcessTarget();
#endif // __CLIENT

	BOOL			DropItem( CMover* pAttacker );		// Á×¾î¼­ ¶³¾îÆ®¸®´Â µå¶ø.
	void			EnforcedGhostCorr();
	void			ApproachGhostAngle();
	void			OnArriveAtPos();
	void			OnArrive( DWORD dwParam1, DWORD dwParam2 );
	void			SetActParam( OBJACT act, int nParam1 = 0, int nParam2 = 0, int nParam3 = 0 );
	int				GetActParam( int nIdx ) { return m_nAParam[nIdx]; }
	void			SetCmd( OBJACT cmd, int nParam1 = 0, int nParam2 = 0, int nParam3 = 0 );
	void			SetCmdParam( int nIdx, int nValue ) { m_nCParam[nIdx] = nValue; }
	BOOL			__SetQuest( LPQUEST lpQuest, LPQUEST lpNewQuest );

public:
#ifdef __CLIENT
#if __VER >= 8 //__CSC_VER8_5
	void			CreateAngelParticle(D3DXVECTOR3 vPos);
#endif //__CSC_VER8_5

#if __VER >= 9	// __PET_0410
	void			CreatePetParticle(D3DXVECTOR3 vPos);
#endif //__PET_0410
	void			ProcessEyeFlash();
#if __VER >= 14 // __WING_ITEM
	void			WingMotionSetting( const CModelObject* pModel );
	float			GetRideFrameSpeed( void );
#endif // __WING_ITEM
#ifdef __MOUNT
	void			MountMotion(CModelObject* pModel);
#endif // __MOUNT
#ifdef __BS_EFFECT_LUA
	const char*		GetNameO3D( );
	BOOL			SetDataMTE( const char* fname1, const char* fname2 );
#endif

#endif //__CLIENT
#ifdef __WINGSFX
private:
	DWORD m_dwWingSfx;

public:
#if defined(__CLIENT)
	const void SetWingSfx(const DWORD sfx);
#elif defined(__WORLDSERVER)
	const void SetWingSfx(const DWORD sfx) { m_dwWingSfx = sfx; }
#endif
	const DWORD GetWingSfx() const { return m_dwWingSfx; }
	const void CreateWingSfx();
#endif
#ifdef __AUTO_STATS
	int m_nAutoStat;
#endif
#ifdef __MONSTER_HUNTING
	map<DWORD, int> m_mMonsterHunting;
#endif
#ifdef __FL_PARTY_ASSISTANTS_V2_FIX
	BOOL	m_bAssistMember;
	BOOL	GetAssist() { return m_bAssistMember; }
#endif //__PARTY_ASSISTANT
#ifndef __VM_0820
#ifndef __MEM_TRACE
	static			CMoverPool*		m_pPool;
	void*			operator new( size_t nSize )									{ return CMover::m_pPool->Alloc();	}
	void*			operator new( size_t nSize, LPCSTR lpszFileName, int nLine )	{ return CMover::m_pPool->Alloc();	}
	void			operator delete( void* lpMem )									{ CMover::m_pPool->Free( (CMover*)lpMem );	}
	void			operator delete( void* lpMem, LPCSTR lpszFileName, int nLine )	{ CMover::m_pPool->Free( (CMover*)lpMem );	}
#endif	// __MEM_TRACE
#endif	// __VM_0820
#ifdef __WORLDSERVER
	void AddSfxSnd(DWORD dwSfx, DWORD dwSound);
#endif // __WORLDSERVER
#ifdef __ADVANCED_ANNOUNCEMENT
public:
	CString GetAuthString();
#endif // __ADVANCED_ANNOUNCEMENT
#ifdef __BADGE
	void SetBadge(const int nbadge);
	int GetBadge() const;

#ifdef __WORLDSERVER
	void SetBadgeAddType(int Req, int Cond, int Default = 0);
#endif //__WORLDSERVER

	inline vector<int>& GetOwnedBadges() { return m_OwnedBadges; }

protected:
	vector<int> m_OwnedBadges;
	int m_nBadge;
#endif //__BADGE
};


// À¯Àú»óÅÂ ¾Ë¾Æº½
inline	BOOL CMover::IsMode( DWORD dwMode ) 
{ 
#ifdef __HACK_0516
	switch( dwMode )
	{
		case MATCHLESS_MODE:		// ¹«Àû »óÅÂ
		case ONEKILL_MODE:		// ÃÊÇÊ »óÅÂ
		case MATCHLESS2_MODE:	// ¹«Àû »óÅÂ2
			if( m_dwAuthorization == AUTH_GENERAL )
				return FALSE;
			break;
	}
#endif	// __HACK_0516
	if( (dwMode & TRANSPARENT_MODE) )	// Åõ¸íÈ­¸¦ °Ë»çÇÏ·¯ µé¾î¿ÔÀ»¶§
		if( GetAdjParam(DST_CHRSTATE) & CHS_INVISIBILITY )	// ¸¶¹ýÅõ¸íÈ­°¡ °É·È´Â°¡?
			return TRUE;
	return ( ( m_dwMode & dwMode ) == dwMode ) ? TRUE : FALSE; 
}	

inline	BOOL CMover::IsStateMode( DWORD dwMode ) 
{ 
	return ( ( m_dwStateMode & dwMode ) == dwMode ) ? TRUE : FALSE; 
}	

inline BOOL CMover::IsFly() 
{ 
#ifdef _DEBUG
	if( IsNPC() )
	{
		Error( _T( "CMover::IsFly : NPC´Â IsFly()¸¦ »ç¿ëÇÏ¸é ¾ÈµÈ´Ù. IsFlyingNPC()¸¦ »ç¿ëÇÏ¼Å! %s" ), m_szName );
		return FALSE;
	}
#endif
	return m_pActMover->IsFly();
}

inline int	CMover::DoAttackMelee( OBJID idTarget, OBJMSG dwMsg, DWORD dwItemID )
{
	CMover *pTarget = (CMover *)prj.GetMover( idTarget );
	if( IsInvalidObj(pTarget) )
		return 0;

	return DoAttackMelee( pTarget, dwMsg, dwItemID );
}

#if !defined(__WORLDSERVER)
inline int CMover::IsSteal( OBJID idTaget )		// id·Î °Ë»çÇÏ´Â ¹öÀü.
{
	CMover *pTarget = prj.GetMover( idTaget );
	if( IsInvalidObj(pTarget) )		
		return 0;
	else
		return 	IsSteal( pTarget );
}
#endif	// __WORLDSERVER

// ¾×¼Ç ¸Å½ÃÁö¸¦ º¸³¿ ; °´Ã¼ÀÇ ¿òÁ÷ÀÓÀ» ¸Å½ÃÁö·Î Á¦¾îÇÔ 
#ifdef __NO_HP_DMG_LIMIT
inline long long CMover::SendActMsg(OBJMSG dwMsg, long long nParam1, long long nParam2, long long nParam3, long long nParam4)
#else
inline int CMover::SendActMsg(OBJMSG dwMsg, int nParam1, int nParam2, int nParam3, int nParam4)
#endif	
{	
	if( m_pActMover )	
		return m_pActMover->SendActMsg( dwMsg, nParam1, nParam2, nParam3, nParam4 );	
	else
		return 0;
}

//raiders.2006.11.28	 tradeµ·À» °è»ê¿¡ Æ÷ÇÔÇÏ´ø °ÍÀ» Á¦°Å
inline int CMover::GetGold()
{
#ifdef __GAMEMASTER
	int nGold;
	return ((this->m_dwAuthorization >= AUTH_GAMEMASTER3) && ((m_dwMode & FREE_MONEY_MODE) == FREE_MONEY_MODE)) ? nGold = INT_MAX : nGold = m_dwGold;
#else // __GAMEMASTER
	int nGold = m_dwGold;
#endif // __GAMEMASTER
//	nGold -= m_vtInfo.TradeGetGold();
	ASSERT( nGold >= 0 );
	return nGold;
}

inline void CMover::SetGold( int nGold )
{
	ASSERT( nGold >= 0 );
#ifdef __GAMEMASTER
	if (!((this->m_dwAuthorization >= AUTH_GAMEMASTER3) && ((m_dwMode & FREE_MONEY_MODE) == FREE_MONEY_MODE)))
#endif // __GAMEMASTER
	{
		m_dwGold = (DWORD)nGold;
	}
}

inline void CMover::ClearCmd() 
{ 
//	TRACE( "ClearCmd %d->0 ", m_oaCmd );
	m_oaCmd = OBJACT_NONE; 
	memset( m_nCParam, 0xcd, sizeof(m_nCParam) ); 
}

inline void CMover::ClearActParam() 
{ 
	m_oaAct = OBJACT_NONE; 
	memset( m_nAParam, 0xcd, sizeof(m_nAParam) );
}


extern int GetWeaponPlusDamage( int nDamage, BOOL bRandom, ItemProp* pItemProp , int nOption );
extern int __IsEndQuestCondition( CMover* pMover, int nQuestId );
extern int __IsBeginQuestCondition( CMover* pMover, int nQuestId );
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
extern int __IsNextLevelQuest( CMover* pMover, int nQuestId );
#endif // __IMPROVE_QUEST_INTERFACE
extern	BOOL AttackBySFX( CMover* pAttacker, SFXHIT_INFO & info );

#endif // !defined(AFX_MOVER_H__4B7B21D7_A2D3_4115_946C_68DC9045A845__INCLUDED_)
```
