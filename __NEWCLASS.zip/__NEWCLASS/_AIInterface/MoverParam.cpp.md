# MoverParam.cpp

Chemin original: `C:\Users\rdiff\Desktop\__NEWCLASS\_AIInterface\MoverParam.cpp`
Chemin relatif: `_AIInterface\MoverParam.cpp`
Nom du fichier: `MoverParam.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "stdafx.h"
#include "defineSound.h"
#include "defineText.h"
#include "defineQuest.h"
#include "resdata.h"
#include "defineObj.h"

#ifdef __BADGE
#include "defineHonor.h"
#endif //__BADGE

#ifdef __WORLDSERVER
#include "DialogMsg.h"
#include "user.h"
#include "dpcoreclient.h"
#include "spevent.h"

#if __VER >= 12 // __LORD
#ifdef __WORLDSERVER
#include "slord.h"
#endif	// __WORLDSERVER 
#ifdef __CLIENT
#include "clord.h"
#endif	// __CLIENT
#endif	// __LORD

#if __VER >= 9 // __CSC_VER9_1
#ifdef __CLIENT
#include "wndfield.h"
#endif	// __CLIENT
#endif	// __CSC_VER9_1

extern	CUserMng	g_UserMng;
extern	CDPCoreClient	g_DPCoreClient;

#include "dpdatabaseclient.h"
extern	CDPDatabaseClient	g_dpDBClient;
extern	CDPCoreClient	g_DPCoreClient;
#endif	// __WORLDSERVER

#ifdef __CLIENT			
#include "Dialogmsg.h"
#endif

#include "Party.h"
extern	CPartyMng	g_PartyMng;

#ifdef __WORLDSERVER
#include "DPSrvr.h"
extern	CDPSrvr		g_DPSrvr;
#endif // __WORLDSERVER

#include "Project.h"
#include "ProjectCmn.h"


#ifdef __WORLDSERVER

#ifdef __ENVIRONMENT_EFFECT

#include "Environment.h"

#else // __ENVIRONMENT_EFFECT

#if defined(__EVENTLUA_RAIN) || defined(__EVENTLUA_SNOW)
#include "Environment.h"
extern CEnvironment g_Environment;
#else // __EVENTLUA_RAIN || __EVENTLUA_SNOW
#ifdef __RAIN_EVENT
#include "Environment.h"
extern CEnvironment g_Environment;
#endif // __RAIN_EVENT
#endif// __EVENTLUA_RAIN || __EVENTLUA_SNOW

#endif // __ENVIRONMENT_EFFECT

#if __VER >= 14 // __PCBANG
#include "PCBang.h"
#endif // __PCBANG

#if __VER >= 15 // __GUILD_HOUSE
#include "GuildHouse.h"
#endif // __GUILD_HOUSE

#if __VER >= 15 // __CAMPUS
#include "CampusHelper.h"
#endif // __CAMPUS
#ifdef __RECORD_BOOK
#include "RecordBook.h"
#endif
#endif // __WORLDSERVER

LPSKILL CMover::GetSkill( int nType, int nIdx )
{
	// nType == 0ÀÌ¸é Á÷¾÷ ½ºÅ³
	// nType == 1ÀÌ¸é ¶óÀÌ¼±½º ½ºÅ³ 
	if( nIdx >= MAX_SKILL_JOB )
	{
		Error( "CMover::GetSkill : %s nId = %d ¹üÀ§¸¦ ¹þ¾î³²", m_szName, nIdx );
		nIdx = 0;
	}
	return &m_aJobSkill[ nIdx ];
}
LPSKILL CMover::GetSkill( DWORD dwSkill )
{
	for( int i = 0; i < MAX_SKILL_JOB; i++ )	
	{
		if( m_aJobSkill[i].dwSkill == dwSkill )
			return &m_aJobSkill[i];
	}
	return NULL;
}

int		CMover::GetSkillIdx( DWORD dwSkill )
{
	for( int i = 0; i < MAX_SKILL_JOB; i++ )	
	{
		if( m_aJobSkill[i].dwSkill == dwSkill )
			return i;
	}
	return -1;
}


BOOL CMover::CheckSkill( DWORD dwSkill )
{
	ItemProp* pSkillProp = prj.GetSkillProp( dwSkill );
	
	if( pSkillProp == NULL || pSkillProp->nLog == 1 )
		return FALSE;
#ifdef __NEWCLASS
	if ( /* !IsMaster() && !IsHero() && !IsLegendHero() && !IsLegendHeroUltimate() && */ GetLevel() < (int)(pSkillProp->dwReqDisLV))
		return FALSE;
#else // __NEWCLASS
#ifdef __3RD_LEGEND16
	if (!IsMaster() && !IsHero() && !IsLegendHero() && GetLevel() < (int)(pSkillProp->dwReqDisLV))
		return FALSE;
#else // __3RD_LEGEND16
#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	if (!IsMaster() && !IsHero() && GetLevel() < (int)(pSkillProp->dwReqDisLV))
		return FALSE;
#else // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	if (GetLevel() < pSkillProp->dwReqDisLV)
		return FALSE;
#endif	// __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#endif // __3RD_LEGEND16
#endif // __NEWCLASS
				
	if( pSkillProp->dwReSkill1 != 0xffffffff )
	{
		LPSKILL pSkillBuf = GetSkill( pSkillProp->dwReSkill1 );
		if( pSkillBuf )
		{
			if( pSkillBuf->dwLevel < pSkillProp->dwReSkillLevel1 )
			{
				return FALSE;
			}
		}
	}
	
	if( pSkillProp->dwReSkill2 != 0xffffffff )
	{
		LPSKILL pSkillBuf = GetSkill( pSkillProp->dwReSkill2 );
		if( pSkillBuf )
		{
			if( pSkillBuf->dwLevel < pSkillProp->dwReSkillLevel2 )
			{
				return FALSE;
			}				
		}
	}	
	
	return TRUE;
}


// ÄÉ¸¯ÅÍ°¡ ·¹º§¾÷½Ã ½ºÅ³Áß¿¡ ÄÉ¸¯ÅÍ·¹º§¶«½Ã È°¼ºÈ­ ¾ÈµÈ°Íµé È°¼º¿©ºÎ Ã¼Å©ÇÏ¿© Á¤º¸Ãâ·Â
void CMover::PutLvUpSkillName_1( DWORD dwLevel )
{
#ifdef __CLIENT
	for( int i = 0; i < MAX_SKILL_JOB; i++ )	
	{
		if( m_aJobSkill[i].dwSkill == NULL_ID ) 
			continue;
		
		ItemProp* pSkillProp = prj.GetSkillProp( m_aJobSkill[i].dwSkill );
		
		if( pSkillProp && dwLevel == pSkillProp->dwReqDisLV )
		{
			if( pSkillProp->dwReSkill1 != -1 )
			{
				LPSKILL pSkill = GetSkill(pSkillProp->dwReSkill1);

				if( pSkillProp->dwReSkillLevel1 > pSkill->dwLevel )
					continue;
			}
			if( pSkillProp->dwReSkill2 != -1 )
			{
				LPSKILL pSkill = GetSkill(pSkillProp->dwReSkill2);
				
				if( pSkillProp->dwReSkillLevel2 > pSkill->dwLevel )
					continue;
			}

			CString str;
			str.Format( prj.GetText( TID_GAME_REAPSKILL ), pSkillProp->szName );
			g_WndMng.PutString( (LPCTSTR)str, NULL, prj.GetTextColor( TID_GAME_REAPSKILL ) );
		}
	}
#endif //__CLIENT
}		

BOOL IsSkillParent( CMover* pMover, DWORD dwSkill, DWORD dwChildSkill )
{
	LPSKILL pSkill = pMover->GetSkill( dwSkill );
	if( pSkill == NULL )
		return FALSE;

	ItemProp* pSkillProp = prj.GetSkillProp( dwSkill );
	if( pSkillProp == NULL )
		return FALSE;

	if( pSkillProp->dwReSkill1 == dwChildSkill || pSkillProp->dwReSkill2 == dwChildSkill )
		return TRUE;

	return FALSE;
}

BOOL IsActive( CMover* pMover, DWORD dwSkill )
{
	LPSKILL pSkill = pMover->GetSkill( dwSkill );
	if( pSkill == NULL )
		return FALSE;

	ItemProp* pSkillProp = prj.GetSkillProp( dwSkill );
	if( pSkillProp == NULL )
		return FALSE;

	if( pSkillProp->dwReSkill1 != NULL_ID )
	{
		LPSKILL pSkill1;
		ItemProp* pSkillProp1;

		pSkill1		= pMover->GetSkill( pSkillProp->dwReSkill1 );
		if( pSkill1 == NULL )
			return FALSE;

		pSkillProp1 = prj.GetSkillProp( pSkill1->dwSkill );
		if( pSkillProp1 == NULL )
			return FALSE;

#ifdef __NEWCLASS
		if ((int)(pSkillProp1->dwReqDisLV) > pMover->GetLevel() /* && !pMover->IsMaster() && !pMover->IsHero() && !pMover->IsLegendHero() && !pMover->IsLegendHeroUltimate() */)
			return FALSE;
#elif defined (__3RD_LEGEND16)
		if ((int)(pSkillProp1->dwReqDisLV) > pMover->GetLevel() && !pMover->IsMaster() && !pMover->IsHero() && !pMover->IsLegendHero())
			return FALSE;
#else // __3RD_LEGEND16
#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if ((int)(pSkillProp1->dwReqDisLV) > pMover->GetLevel() && !pMover->IsMaster() && !pMover->IsHero())
			return FALSE;
#else // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if (pSkillProp1->dwReqDisLV > pMover->GetLevel())
			return FALSE;
#endif	// __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#endif // __3RD_LEGEND16
		
		if( pSkillProp->dwReSkillLevel1 != pSkill1->dwLevel )
			return FALSE;
	}

	if( pSkillProp->dwReSkill2 != NULL_ID )
	{
		LPSKILL pSkill1;
		ItemProp* pSkillProp1;
		
		pSkill1		= pMover->GetSkill( pSkillProp->dwReSkill2 );
		if( pSkill1 == NULL )
			return FALSE;
	
		pSkillProp1 = prj.GetSkillProp( pSkill1->dwSkill );
		if( pSkillProp1 == NULL )
			return FALSE;
#ifdef __NEWCLASS
		if ((int)(pSkillProp1->dwReqDisLV) > pMover->GetLevel() /* && !pMover->IsMaster() && !pMover->IsHero() && !pMover->IsLegendHero() && !pMover->IsLegendHeroUltimate() */)
			return FALSE;
#elif defined (__3RD_LEGEND16)
		if ((int)(pSkillProp1->dwReqDisLV) > pMover->GetLevel() && !pMover->IsMaster() && !pMover->IsHero() && !pMover->IsLegendHero())
			return FALSE;
#else // __3RD_LEGEND16
#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if ((int)(pSkillProp1->dwReqDisLV) > pMover->GetLevel() && !pMover->IsMaster() && !pMover->IsHero())
			return FALSE;
#else // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if (pSkillProp1->dwReqDisLV > pMover->GetLevel())
			return FALSE;
#endif	// __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#endif // __3RD_LEGEND16
		
		if( pSkillProp->dwReSkillLevel2 != pSkill1->dwLevel )
			return FALSE;		
	}
#ifdef __NEWCLASS
	if ((int)(pSkillProp->dwReqDisLV) > pMover->GetLevel() /* && !pMover->IsMaster() && !pMover->IsHero() && !pMover->IsLegendHero() && !pMover->IsLegendHeroUltimate() */)
		return FALSE;
#elif defined (__3RD_LEGEND16)
	if ((int)(pSkillProp->dwReqDisLV) > pMover->GetLevel() && !pMover->IsMaster() && !pMover->IsHero() && !pMover->IsLegendHero())
		return FALSE;
#else // __3RD_LEGEND16
#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	if ((int)(pSkillProp->dwReqDisLV) > pMover->GetLevel() && !pMover->IsMaster() && !pMover->IsHero())
		return FALSE;
#else // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	if (pSkillProp->dwReqDisLV > pMover->GetLevel())
		return FALSE;
#endif	// __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#endif // __3RD_LEGEND16

	return TRUE;
}


// ½ºÅ³ ·¹º§¾÷½Ã ÄÉ¸¯ÅÍ ·¹º§¶«½Ã ¾È³ª¿Ô´ø ½ºÅ³µé °Ë»öÇÏ¿© Á¤º¸ Ãâ·Â
void CMover::PutLvUpSkillName_2( DWORD dwSkill )
{
#ifdef __CLIENT
	LPSKILL pSkill = GetSkill( dwSkill );
	ItemProp* pSkillProp = prj.GetSkillProp( dwSkill );
	
	//ÇöÀç È°¼ºÈ­ µÇ¾îÀÖ´Â³Ä?
	//³ª¸¦ °®°íÀÖ´Â ½ºÅ³À» °Ë»çÇÏ¿© Á¶°Ç¿¡ ¸ÂÀ¸¸é ±×½ºÅ³À» È°¼ºÈ­ ÇÑ´Ù.
	for( int i = 0; i < MAX_SKILL_JOB; i++ )	
	{
		if( m_aJobSkill[i].dwSkill == NULL_ID ) 
			continue;

		if( IsSkillParent( this, m_aJobSkill[i].dwSkill, dwSkill ) )
		{
			if( IsActive( this, m_aJobSkill[i].dwSkill ) )
			{
				ItemProp* pSkillProp1;
				pSkillProp1 = prj.GetSkillProp( m_aJobSkill[i].dwSkill );

				CString str;
				str.Format( prj.GetText( TID_GAME_REAPSKILL ), pSkillProp1->szName );
				g_WndMng.PutString( (LPCTSTR)str, NULL, prj.GetTextColor( TID_GAME_REAPSKILL ) );	
			}
		}
	}
#endif // CLIENT
}

#ifdef __WORLDSERVER
/// °Å·¡, Á×À½, °³ÀÎ»óÁ¡Áß, ÀüÅõÁß FALSE
int CMover::GetSummonState()
{
	// °Å·¡
	if( m_vtInfo.GetOther() != NULL )
		return 1;
	  // Ã¢°í
	if( m_bBank )
		return 1;
	  // ±æµåÃ¢°í
	if( m_bGuildBank )
		return 1;

	// Á×À½
	if( IsDie() )
		return 2;

	// °³ÀÎ»óÁ¡Áß
	if( m_vtInfo.VendorIsVendor() || m_vtInfo.IsVendorOpen() )
		return 3;

	// ÀüÅõÁß
	if( IsAttackMode() )
		return 4;
	
	// ºñÇàÁß
	if( ( IsFly() ) )
		return 5;


#if __VER >= 8 // 8Â÷ µà¾ó 061226 ma
	if( m_nDuel )
		return 6;
#endif // __VER >= 8 // 8Â÷ µà¾ó 061226 ma


	return 0;
}
#endif //


#ifdef __CLIENT
LPCTSTR CMover::GetJobString()
{
	if( m_nJob != -1 )
		return prj.m_aJob[ m_nJob ].szName;
	return _T( "" );
}
#endif	// __CLIENT

BOOL  CMover::IsJobType( DWORD dwJobType ) 
{ 
	if( IsExpert() )
	{
		if( dwJobType == JTYPE_EXPERT ) 
			return TRUE;
		return FALSE;
	}
	return JTYPE_BASE == dwJobType;
}
BOOL CMover::IsBaseJob()
{
	return prj.m_aJob[ m_nJob ].dwJobType == JTYPE_BASE;
}
BOOL CMover::IsExpert()
{
	return prj.m_aJob[ m_nJob ].dwJobType == JTYPE_EXPERT;
}
BOOL CMover::IsPro()
{
	return prj.m_aJob[ m_nJob ].dwJobType == JTYPE_PRO;
}

#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
BYTE	CMover::GetLegendChar()
{
	if(IsMaster())
		return LEGEND_CLASS_MASTER;
	else if(IsHero())
		return	LEGEND_CLASS_HERO;
#ifdef __3RD_LEGEND16
	else if(IsLegendHero())
		return LEGEND_CLASS_LEGENDHERO;
#endif //  __3RD_LEGEND16
#ifdef __NEWCLASS
	else if (IsLegendHeroUltimate())
		return LEGEND_CLASS_LEGENDHERO_ULTIMATE;
#endif // __NEWCLASS
	else
		return LEGEND_CLASS_NORMAL;
}

BOOL	CMover::IsMaster()
{
	return prj.m_aJob[ m_nJob ].dwJobType == 5;//temp JTYPE_MASTER;
}

BOOL	CMover::IsHero()
{
	return prj.m_aJob[ m_nJob ].dwJobType == 6;//temp JTYPE_HERO;
}
#endif	//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

#ifdef __3RD_LEGEND16
BOOL	CMover::IsLegendHero()
{
	return prj.m_aJob[ m_nJob ].dwJobType == JTYPE_LEGEND_HERO;
}
#endif // __3RD_LEGEND16

#ifdef __NEWCLASS
BOOL	CMover::IsLegendHeroUltimate()
{
	return prj.m_aJob[m_nJob].dwJobType == JTYPE_LEGEND_HERO_ULTIMATE;
}
#endif // __NEWCLASS

BOOL CMover::IsInteriorityJob( int nJob )
{
	if( nJob == JOB_VAGRANT || nJob == m_nJob )
		return TRUE;

	if( IsPro() && JOB_VAGRANT < nJob && nJob < MAX_EXPERT )
	{
		if( nJob * 2 + 4 == m_nJob || nJob * 2 + 5 == m_nJob )
		{
			return TRUE;
		}
	}
	if( IsMaster()  )	// ·¹º§ÀÌ ¾ÈµÇ¸é ¸øÂü.				
	{
		if( nJob < MAX_EXPERT )
		{
			if( nJob * 2 + 14 == m_nJob || nJob * 2 + 15 == m_nJob )
				return TRUE;
		}
		else if( nJob < MAX_PROFESSIONAL )
		{
			if( nJob + 10 == m_nJob )
				return TRUE;
		}
	}
	if( IsHero()  )	// ·¹º§ÀÌ ¾ÈµÇ¸é ¸øÂü.				
	{
		if( nJob < MAX_EXPERT )
		{
			if( nJob * 2 + 22 == m_nJob || nJob * 2 + 23 == m_nJob )
				return TRUE;
		}
		else if( nJob < MAX_PROFESSIONAL )
		{
			if( nJob + 18 == m_nJob )
				return TRUE;
		}
#if __VER >= 14 // __NEW_ITEM_LIMIT_LEVEL
		else if( nJob < MAX_MASTER )	// Hero´Â ¸¶½ºÅÍ ¹«±â¸¦ ÀåÂøÇÒ ¼ö ÀÖ´Ù.
		{
			if( nJob + 8 == m_nJob )
				return TRUE;
		}
#endif // __NEW_ITEM_LIMIT_LEVEL
	}
#ifdef __3RD_LEGEND16
	if( IsLegendHero() )
	{
		if( nJob < MAX_EXPERT )
		{
			if( nJob * 2 + 30 == m_nJob || nJob * 2 + 31 == m_nJob )
				return TRUE;
		}
		else if( nJob < MAX_PROFESSIONAL )
		{
			if( nJob + 26 == m_nJob )
				return TRUE;
		}
		else if( nJob < MAX_MASTER )	// Hero´Â ¸¶½ºÅÍ ¹«±â¸¦ ÀåÂøÇÒ ¼ö ÀÖ´Ù.
		{
			if( nJob + 16 == m_nJob )
				return TRUE;
		}
		else if( nJob < MAX_HERO )
		{
			if( nJob + 8 == m_nJob )
				return TRUE;
		}
	}
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
	if (IsLegendHeroUltimate())
	{
		if (nJob < MAX_EXPERT)
		{
			if (nJob * 2 + 38 == m_nJob || nJob * 2 + 39 == m_nJob)
				return TRUE;
		}
		else if (nJob < MAX_PROFESSIONAL)
		{
			if (nJob + 34 == m_nJob)
				return TRUE;
		}
		else if (nJob < MAX_MASTER)
		{
			if (nJob + 24 == m_nJob)
				return TRUE;
		}
		else if (nJob < MAX_HERO)
		{
			if (nJob + 16 == m_nJob)
				return TRUE;
		}
		else if (nJob < MAX_LEGEND_HERO)
		{
			if (nJob + 8 == m_nJob)
				return TRUE;
		}
	}
#endif // __NEWCLASS
	return FALSE;
}

// ½ºÅ³¼ö 3(±âº»)14(ÀÍ½ºÆÛÆ®)7(ÇÁ·ÎÆä¼Å³Î)
// Á÷¾÷ 10, ÀÍ½ºÆÛÆ® 40. ÇÁ·Î 30
BOOL  CMover::SetExpert( int nJob )
{
	if( m_nJob == nJob )
		return FALSE;
	m_nJob = nJob;

	int nNum = 3; // 3Àº ±âº» ½ºÅ³ÀÇ °¹¼ö´Ù. 3 ÀÌ»óºÎÅÍ ÀÍ½ºÆÛÆ® ½ºÅ³ÀÌ Ãß°¡µÈ´Ù´Â ÀÇ¹Ì 
	LPSKILL lpSkill;
	ItemProp** apSkillProp = prj.m_aJobSkill[ m_nJob ];
	int nJobNum = prj.m_aJobSkillNum[ m_nJob ];
	for( int i = 0; i < nJobNum; i++ )
	{
		ItemProp* pSkillProp = apSkillProp[ i ];
		lpSkill = &m_aJobSkill[ nNum++ ];
		lpSkill->dwSkill = pSkillProp->dwID;
	}
	return TRUE;
}

int   CMover::GetJob()
{
	return m_nJob; 
}

int   CMover::GetExpPercent()
{
	int nExpPercent = 0;

	nExpPercent = (int)( GetExp1() * 10000 / GetMaxExp1() );

	return nExpPercent; 
}


int   CMover::GetRemainGP()
{
	return m_nRemainGP;
}

// ¸íÁß·ü ÇÏ¶ô »óÅÂ´Â ÀÌÅ¢ÀÌº¥Æ®¿Í »ó°ü¾øÀÌ ¿Ã¼ö ÀÖ±â¶§¹®¿¡ GetParm()À» ¿©±â¼­ ÃÖÁ¾ °è»êÇØ¾ßÇÑ´Ù.
int	CMover::GetAdjHitRate( void )
{
	return GetParam( DST_ADJ_HITRATE, m_nAdjHitRate );
}

// È¸ÇÇÀ² 
int CMover::GetParrying()
{
	if( IsPlayer() )
		return	( (int)( (GetDex() * 0.5f) + GetParam( DST_PARRY, m_nAdjParry ) ) );
	else
		return GetProp()->dwER;
}


void CMover::UpdateParam()
{
	if( IsPlayer() ) 
	{
		SumEquipDefenseAbility( &m_nDefenseMin, &m_nDefenseMax ); 
		SumEquipAdjValue( &m_nAdjHitRate, &m_nAdjParry );
	}
	else
	{
		m_nDefenseMin = m_nDefenseMax = GetNaturalArmor();
		m_nAdjHitRate = 0;
		m_nAdjParry = 0;
	}
}
// ¾ÆÀÌÅÛÀÇ ¼º´ÉÀ» ¾ò´Â´Ù. 
int CMover::GetItemAbility( int nItem )
{
	ItemProp* pItemProp = prj.GetItemProp( nItem );
	int nAbilityMin = GetParam( DST_ABILITY_MIN, pItemProp->dwAbilityMin );
	int nAbilityMax = GetParam( DST_ABILITY_MAX, pItemProp->dwAbilityMax );
	if( nAbilityMax == nAbilityMin )
		return nAbilityMin;
	return nAbilityMin + ( xRand() % (nAbilityMax - nAbilityMin ) );
}
// ¾ÆÀÌÅÛÀÇ ÃÖ¼Ò ¼º´ÉÀ» ¾ò´Â´Ù.
int CMover::GetItemAbilityMin( int nItem )
{
	ItemProp* pItemProp = prj.GetItemProp( nItem );
	int nAbilityMin = GetParam( DST_ABILITY_MIN, pItemProp->dwAbilityMin );
	return nAbilityMin;
}
// ¾ÆÀÌÅÛÀÇ ÃÖ´ë ¼º´ÉÀ» ¾ò´Â´Ù.
int CMover::GetItemAbilityMax( int nItem )
{
	ItemProp* pItemProp = prj.GetItemProp( nItem );
	int nAbilityMax = GetParam( DST_ABILITY_MAX, pItemProp->dwAbilityMax );
	return nAbilityMax;
}

// È÷Æ®Æ÷ÀÎÆ® Áõ°¨
#ifdef __NO_HP_DMG_LIMIT
void CMover::IncHitPoint(__int64 nVal)
#else
void CMover::IncHitPoint(int nVal)
#endif
{ 
	SetPointParam( DST_HP, m_nHitPoint + nVal );
}
// ¸¶³ªÆ÷ÀÎÆ® Áõ°¨
void CMover::IncManaPoint(int nVal) 
{ 
#ifdef __WORLDSERVER 			
	if( IsSMMode( SM_MAINTAIN_MP ) && nVal < 0 )
		return;
#ifdef __EVENT1206
	if( IsPlayer() && g_eLocal.GetState( EVE_EVENT1206 ) ) //  raiders_fix051217
		return;
#endif	// __EVENT1206
#endif // __WORLDSERVER
	SetPointParam( DST_MP, m_nManaPoint + nVal );
}

void CMover::IncFatiguePoint(int nVal) 
{ 
#ifdef __WORLDSERVER
	if( IsSMMode( SM_MAINTAIN_FP ) && nVal < 0 )
		return;
#ifdef __EVENT1206
	if( IsPlayer() && g_eLocal.GetState( EVE_EVENT1206 ) )	// raiders_fix051217
		return;
#endif	// __EVENT1206
#endif // __WORLDSERVER
	SetPointParam( DST_FP, m_nFatiguePoint + nVal );
}

#if __VER < 8 // __S8_PK
SLAUGHTER_GRADE CMover::GetSlaughterGrade()
{
	return prj.GetSlaughterGrade( m_nSlaughter );		// project.h
}

PK_TYPE GetPKCase( CMover *pAttacker, CMover *pDefender )
{
	SLAUGHTER_GRADE atkGrade = pAttacker->GetSlaughterGrade();			
	SLAUGHTER_GRADE defGrade = pDefender->GetSlaughterGrade();			

	if( pAttacker->IsMode( RECOVERCHAO_MODE ) )		// Ä«¸£¸¶ È¸º¹ ±â°£¿¡ ÀÖ´Â »óÅÂ¿¡¼­ ´Ù½Ã ´Ù¸¥ À¯Àú¸¦ °¡°ÝÇÒ °æ¿ì, 
		atkGrade = SLAUGHTER_SEMI_CHAOTIC;			// ÁØ Ä«¿À À¯Àú¿Í °°Àº ·êÀÌ Àû¿ëÀÌ µÈ´Ù.
	
	static PK_TYPE table[3][3] = {
		{ NORMAL_AND_NORMAL, NORMAL_AND_SEMI, NORMAL_AND_CHAO },
		{ SEMI_AND_NORMAL,   SEMI_AND_SEMI,   SEMI_AND_CHAO },
		{ CHAO_AND_NORMAL,   CHAO_AND_SEMI,   CHAO_AND_CHAO }
	};

	return table[ atkGrade ][ defGrade ];
}
#endif // __VER < 8 // __S8_PK
// µà¾óÈÄÀÇ °á°ú Ã³¸®.
// this°¡ ½ÂÀÚ°¡ µÈ´Ù.
// pLose´Â ÆÐ¹èÀÚ.

#ifdef __WORLDSERVER

#if __VER < 8 // __S8_PK
// PK½Ãµµ¿¡ ÀÇÇÑ m_nSlaughter(=Ä«¸£¸¶ ¼öÄ¡) º¯°æ  
// nDead : Á×ÀºÀÚ, return : Áõ°¨·®.
int CMover::IncSlaughterPoint2( CMover *pDead )
{
	ASSERT( pDead->IsPlayer() && IsPlayer() );

	int nOld = m_nSlaughter;
	PK_TYPE type = GetPKCase( this, pDead );

	if( IsRegionAttr( RA_PENALTY_PK ) == FALSE )
		return 0;

	switch( type )
	{
	case NORMAL_AND_NORMAL:		// ÀÏ¹Ý À¯Àú ¿Í ÀÏ¹Ý À¯Àú 
		m_nSlaughter -= 50;
		break;
	case NORMAL_AND_SEMI:
		break;
	case NORMAL_AND_CHAO:
		break;

	case SEMI_AND_NORMAL:		// ÁØÄ«¿À¿Í ÀÏ¹Ý À¯Àú 
		m_nSlaughter -= 30;
		break;
	case SEMI_AND_SEMI:
		break;
	case SEMI_AND_CHAO:
		break;

	case CHAO_AND_NORMAL:		// Ä«¿À¿Í ÀÏ¹Ý À¯Àú 
		break;
	case CHAO_AND_SEMI:
		break;
	case CHAO_AND_CHAO:
		break;
	}
	return ( m_nSlaughter - nOld );

}

// PK¿¡ ÀÇÇÑ °æ¿ì, slaughter°ªÀ» º¯°æ½ÃÅ²´Ù.
// pDead : Á×ÀºÀÚ, return : Áõ°¨·®.
int CMover::IncSlaughterPoint( CMover *pDead )
{
	ASSERT( pDead->IsPlayer() && IsPlayer() );

	int nOld = m_nSlaughter;

	PK_TYPE type = GetPKCase( this, pDead );

	switch( type )
	{
	case NORMAL_AND_NORMAL:		// ÀÏ¹Ý À¯Àú ¿Í ÀÏ¹Ý À¯Àú 
		if( IsRegionAttr( RA_PENALTY_PK ) )
			m_nSlaughter = -2000;
		else if( IsRegionAttr( RA_PK ) )
			m_nSlaughter -= 50;
		break;
	case NORMAL_AND_SEMI:
		break;
	case NORMAL_AND_CHAO:
		{
			if( pDead->IsAfterDeath() == FALSE )
			{
				// Àý´ë°ªÀÇ Â÷°¡ Å« °æ¿ì¸¸ Ä«¸£¸¶ Æ÷ÀÎÆ®¸¦ ¾ò´Â´Ù.
				int nGradeA = prj.GetKarmaProp( m_nSlaughter )->nGrade;
				int nGradeB = prj.GetKarmaProp( pDead->m_nSlaughter )->nGrade;
				int nDelta = abs(nGradeB) - abs(nGradeA);
				if( nDelta > 0 )
					m_nSlaughter += nDelta;
			}
		}	
		break;

	case SEMI_AND_NORMAL:		// ÁØÄ«¿À¿Í ÀÏ¹Ý À¯Àú 
		if( IsRegionAttr( RA_PENALTY_PK ) )
			m_nSlaughter -= 2000;
		else if( IsRegionAttr( RA_PK ) )
			m_nSlaughter -= 50;
		break;
	case SEMI_AND_SEMI:
		break;

	case SEMI_AND_CHAO:
		break;

	case CHAO_AND_NORMAL:		// Ä«¿À¿Í ÀÏ¹Ý À¯Àú 
		if( IsRegionAttr( RA_PENALTY_PK ) )
		{
			int nGrade = prj.GetKarmaProp( m_nSlaughter )->nGrade;
			switch( nGrade )
			{
			case -4: m_nSlaughter -= 5; break;
			case -5: m_nSlaughter -= 3; break;
			case -6: m_nSlaughter -= 1; break;
			}
		}
		break;
	case CHAO_AND_SEMI:
		break;
	case CHAO_AND_CHAO:
		break;
	}

	return ( m_nSlaughter - nOld );
}
#endif // __VER < 8 // __S8_PK

void CMover::ChangeFame( CMover *pLose )
{
	int nVal = 0;
	float fVal = 0;
	int nGap = 0;

	nGap = pLose->GetLevel() - GetLevel();		// ÆÐÀÚ¿Í ½ÂÀÚÀÇ ·¹º§Â÷ÀÌ

	if( nGap >= 80 )	    { nVal = 100; fVal = 15.0f; }	// ÆÐÀÚ°¡ ·¹º§ÀÌ ÈÎ ³ô¾Ò´Ù.
	else if( nGap >= 30 )	{ nVal = 50;  fVal = 10.0f; }
	else if( nGap >= 20 )	{ nVal = 30;  fVal = 8.0f;  }
	else if( nGap >= 10 )	{ nVal = 10;  fVal = 6.0f;  }
	else if( nGap <= -80 )	{ nVal = 1;   fVal = 1.0f;  }	// ÆÐÀÚ°¡ ·¹º§ÀÌ ÈÎ ³·¾Ò´Ù.
	else if( nGap <= -30 )	{ nVal = 2;   fVal = 2.0f;  }
	else if( nGap <= -20 )	{ nVal = 3;   fVal = 3.0f;  }
	else if( nGap <= -10 )	{ nVal = 4;   fVal = 4.0f;  }
	else                    { nVal = 5;   fVal = 5.0f;  }	// 9 ~ -9


	if( nVal )		// ½ÂÀÚ¿¡°Ô ¸í¼ºÄ¡ ÁÜ
	{	
		if( this->IsFly() && pLose->IsFly() )	// °øÁß µà¾óÀÇ °æ¿ì¿¡´Â ÆÐ¹è½Ã »ó½ÇÇÏ´Â ¸í¼º Æ÷ÀÎÆ®´Â µ¿ÀÏÇÏÁö¸¸, ½Â¸® ½Ã È¹µæÇÏ´Â ¸í¼ºÆ÷ÀÎÆ®´Â Áö»ó ÀüÅõ¿¡ 2¹è·Î ÇÑ´Ù
			nVal *= 2;
			
		m_nFame += nVal;	
		g_UserMng.AddSetFame( this, m_nFame );
		((CUser*)this)->AddDefinedText( TID_GAME_GETFAMEPOINT, "%d", nVal );	// xxx ¸í¼º Æ÷ÀÎÆ®¸¦ ¾ò¾ú´Ù
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
		((CUser*)this)->CheckHonorStat();
		((CUser*)this)->AddHonorListAck();
		g_UserMng.AddHonorTitleChange( this, m_nHonor);
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
	}
	
	if( fVal )	// ÆÐÀÚÀÇ ¸í¼ºÄ¡(ÆÛ¼¾Æ®)¸¦ ±ðÀ½.
	{
		int		nDecVal;
		fVal = fVal / 100.0f;	// ºñÀ²·Î È¯»ê.
		nDecVal = (int)(pLose->m_nFame * fVal);
		if( nDecVal <= 0 )	nDecVal = 1;
		pLose->m_nFame -= nDecVal;
		if( pLose->m_nFame < 0 )
			pLose->m_nFame = 0;

		g_UserMng.AddSetFame( pLose, pLose->m_nFame );
		((CUser*)pLose)->AddDefinedText( TID_GAME_DECFAMEPOINT, "%d", nDecVal );	// xxx ¸í¼º Æ÷ÀÎÆ®°¡ °¨¼Ò.
		g_dpDBClient.SendLogPkPvp( this, pLose, nVal, 'D' );
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
		((CUser*)pLose)->CheckHonorStat();
		((CUser*)pLose)->AddHonorListAck();
		g_UserMng.AddHonorTitleChange( pLose, pLose->m_nHonor);
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
	}
}
#endif // __WORLDSERVER

int	CMover::DuelResult( CMover *pLose )
{
#ifdef __WORLDSERVER
	if( pLose->m_nDuel == 1 )
	{
		if( pLose->GetId() != m_idDuelOther )
			return 0;
	}

	// ½ÂÀÚ´Â ·¹º§Â÷¿¡µû¶ó °æÇèÄ¡ »ó½Â
	// ÆÐÀÚ´Â ·¹º§Â÷¿¡µû¶ó °æÇèÄ¡% ÇÏ¶ô
	if( pLose->m_nDuel == 1 )	// °³ÀÎ PvP
	{
		ChangeFame( pLose );
		
#ifdef __PVPDEBUFSKILL
		//pLose->m_SkillState.SetMover( pLose );
		pLose->m_nDead = PROCESS_COUNT * 2;		// Á¾·á ÈÄ 2ÃÊ°£Àº ¹«Àû
		pLose->RemoveAttackerBuffs( pLose->m_idDuelOther );
		//m_SkillState.SetMover( this );
		m_nDead = PROCESS_COUNT * 2;		// Á¾·á ÈÄ 2ÃÊ°£Àº ¹«Àû
		RemoveAttackerBuffs( m_idDuelOther );
#endif // __PVPDEBUFSKILL
	}
	else
	// ±Ø´Ü µà¾ó.
	if( pLose->m_nDuel == 2 )		// ±Ø´Ü µà¾óÁßÀÏ¶© ±Ø´ÜÀå³¢¸®ÀÇ ·¹º§À» ºñ±³.
	{
		int nVal = 0;
		float fVal = 0;
		int nGap = 0;

		CParty *pLoseParty = g_PartyMng.GetParty( pLose->m_idparty );
		if( pLoseParty == NULL || pLoseParty->IsLeader( pLose->m_idPlayer ) == FALSE )		// ÆÄÆ¼°¡ ¾ø°Å³ª Á×Àº³ÑÀÌ ´ëÀåÀÌ ¾Æ´Ï¸é °Á ¸®ÅÏ.
			return 0;
		
		CParty *pParty = g_PartyMng.GetParty( m_idparty );		// ÀÌ±äÃø ÆÄÆ¼.
		if( pParty == NULL )
			return 0;

		CMover* pLeader	= pParty->GetLeader();
		if( IsValidObj( pLeader ) )
			nGap	= pLose->GetLevel() - pLeader->GetLevel();
		else
			nGap	= pLose->GetLevel() - GetLevel();
		
		if( nGap >= 80 )	{ nVal = 100; fVal = 15.0f; }		// ÆÐÀÚ°¡ ·¹º§ÀÌ ÈÎ ³ô¾Ò´Ù.
		else if( nGap >= 50 )	{ nVal = 50; fVal = 10.0f; }
		else if( nGap >= 20 )	{ nVal = 30; fVal = 8.0f; }
		else if( nGap >= 10 )	{ nVal = 10; fVal = 6.0f; }
		else if( nGap <= -80 )	{ nVal = 1; fVal = 1.0f; }		// ÆÐÀÚ°¡ ·¹º§ÀÌ ÈÎ ³·¾Ò´Ù.
		else if( nGap <= -50 )	{ nVal = 2; fVal = 2.0f; }
		else if( nGap <= -20 )	{ nVal = 3; fVal = 3.0f; }
		else if( nGap <= -10 )	{ nVal = 4; fVal = 4.0f; }
		else { nVal = 5; fVal = 5.0f; }	// 9 ~ -9

		g_DPCoreClient.SendSetPartyDuel( pParty->m_uPartyId, pLoseParty->m_uPartyId, FALSE );

		pLose->m_bLastDuelParty = TRUE;
		pLoseParty->DoDuelResult( pParty, 0, nVal, fVal );		// ÆÄÆ¼¿øµé¿¡°Ô ÆÐ¹è»ç½ÇÀ» ¾Ë¸®°í µà¾ó ÁßÁö½ÃÅ´.
		pParty->DoDuelResult( pLoseParty, 1, nVal, fVal );		// ÆÄÆ¼¿øµé¿¡°Ô ½Â¸®¸¦ ¾Ë¸².
	}
#endif	// __WORLDSERVER

	return 1;
}

// È÷Æ®Æ÷ÀÎÆ®¸¦ ¼ÂÇÏ±â
#ifdef __NO_HP_DMG_LIMIT
void CMover::SetHitPoint(__int64 nVal)
#else
void CMover::SetHitPoint(int nVal)
#endif
{
	m_nHitPoint = nVal;
//	m_nHitPoint += nVal;
	if( m_nHitPoint < 0 )
		m_nHitPoint = 0;
	if( m_nHitPoint > GetMaxHitPoint() )
		m_nHitPoint = GetMaxHitPoint(); 
}
// ¸¶³ª Æ÷ÀÎÆ®¸¦ ¼ÂÇÏ±â 
void CMover::SetManaPoint(int nVal) 
{
	m_nManaPoint = nVal;
	if( m_nManaPoint < 0 )
		m_nManaPoint = 0;
	if( m_nManaPoint > GetMaxManaPoint() )
		m_nManaPoint = GetMaxManaPoint(); 
}
// ÇÇÁöÄ® Æ÷ÀÎÆ®¸¦ ¼ÂÇÏ±â 
void CMover::SetFatiguePoint(int nVal) 
{
	m_nFatiguePoint = nVal;
	if( m_nFatiguePoint < 0 )
		m_nFatiguePoint = 0;
	if( m_nFatiguePoint > GetMaxFatiguePoint() )
		m_nFatiguePoint = GetMaxFatiguePoint(); 
}

#ifdef __NO_HP_DMG_LIMIT
__int64 CMover::GetPointParam(int nDestParameter)
#else
int CMover::GetPointParam(int nDestParameter)
#endif
{
	switch( nDestParameter )
	{
		case DST_HP:	return( GetHitPoint() );
		case DST_MP:	return( GetManaPoint() );
		case DST_FP:	return( GetFatiguePoint() );
		case DST_GOLD:	return( GetGold() );
	}
	return( 0 );
}

#ifdef __NO_HP_DMG_LIMIT
void CMover::SetPointParam(int nDstParameter, __int64 nValue, BOOL bTrans)
#else
void CMover::SetPointParam(int nDstParameter, int nValue, BOOL bTrans)
#endif
{
#ifdef __WORLDSERVER
#ifdef __NO_HP_DMG_LIMIT
	long long nMax = nValue;
#else
	int nMax = nValue;
#endif
#endif // __WORLDSERVER
	if( nValue < 0 )	nValue	= 0;
	BOOL	bTransfer	= bTrans;

	switch( nDstParameter )
	{
		case DST_HP:
#ifdef __WORLDSERVER
			if( nValue > GetMaxHitPoint() || nMax == 999999999 )	nValue	= GetMaxHitPoint();
#else // __WORLDSERVER
			if( nValue > GetMaxHitPoint() )	nValue	= GetMaxHitPoint();
#endif // __WORLDSERVER
			if( m_nHitPoint != nValue )
			{
				bTransfer	= TRUE;
				m_nHitPoint		= nValue;
			}
			break;
		case DST_MP:
#ifdef __WORLDSERVER
			if( nValue > GetMaxManaPoint() || nMax == 999999999 )	nValue	= GetMaxManaPoint();
#else // __WORLDSERVER
			if( nValue > GetMaxManaPoint() )	nValue	= GetMaxManaPoint();
#endif // __WORLDSERVER
			if( m_nManaPoint != nValue )
			{
				bTransfer	= TRUE;
				m_nManaPoint	= nValue;
			}
			break;
		case DST_FP:
#ifdef __WORLDSERVER
			if( nValue > GetMaxFatiguePoint() || nMax == 999999999 )	nValue	= GetMaxFatiguePoint();
#else // __WORLDSERVER
			if( nValue > GetMaxFatiguePoint() )		nValue	= GetMaxFatiguePoint();
#endif // __WORLDSERVER
			if( m_nFatiguePoint != nValue )
			{
				bTransfer	= TRUE;
				m_nFatiguePoint		= nValue;
			}
			break;
		case DST_GOLD:
			//m_dwGold	= (DWORD)nValue;
#ifdef __PERIN_BUY_BUG	// chipi_091219 Ãß°¡
#ifdef __WORLDSERVER
			Error( "SetPointParam( DST_GOLD ) - [User:%s(%07d)], [Value:%d]", static_cast<CUser*>(this)->GetName(), static_cast<CUser*>(this)->m_idPlayer, nValue );
			return;
#endif // __WORLDSERVE
#endif // __PERIN_BUY_BUG

	#ifdef __CLIENT
			if( IsActiveMover() )
				PLAYSND(SND_INF_TRADE);
	#endif //__CLIENT
			bTransfer	= TRUE;
			SetGold( nValue );
			break;
	}
#ifdef __WORLDSERVER
	if( bTransfer )
		g_UserMng.AddSetPointParam( this, nDstParameter, nValue );
#endif	// __WORLDSERVER
}
BOOL CMover::IncStrLevel()
{
#ifdef __S_ADD_RESTATE
	if( m_nRemainGP > 0 )
	{
		m_nStr += 1;
		m_nRemainGP -= 1;
		return TRUE;
	}
#else // __S_ADD_RESTATE
	LPJOBABILITY pJobAbillity;
	if( IsExpert() )
		pJobAbillity = &prj.m_aJobAbillity[ GetJob() ];
	else
		pJobAbillity = &prj.m_aJobAbillity[ JOB_VAGRANT ];
	if( (int)m_nRemainGP >= (int)pJobAbillity->dwStr )		// ÀÌºÎºÐ (int)·Î Ä³½ºÆ® ÇØÁÖÁö ¾ÊÀ¸¸é ÄÄÆÄÀÏ·¯ ¹ö±× ³­´Ù.
	{
		m_nStr += pJobAbillity->dwStrAdd;
		m_nRemainGP -= pJobAbillity->dwStr;
		return TRUE;
	}
#endif // __S_ADD_RESTATE
	return FALSE;
}
BOOL CMover::IncStaLevel()
{
#ifdef __S_ADD_RESTATE
	if( m_nRemainGP > 0 )
	{
		m_nSta += 1;
		m_nRemainGP -= 1;
		return TRUE;
	}
#else // __S_ADD_RESTATE
	LPJOBABILITY pJobAbillity;
	if( IsExpert() )
		pJobAbillity = &prj.m_aJobAbillity[ GetJob() ];
	else
		pJobAbillity = &prj.m_aJobAbillity[ JOB_VAGRANT ];
	if( (int)m_nRemainGP >= (int)pJobAbillity->dwSta )
	{
		m_nSta += pJobAbillity->dwStaAdd;
		m_nRemainGP -= pJobAbillity->dwSta;
		return TRUE;
	}
#endif // __S_ADD_RESTATE
	return FALSE;
}
BOOL CMover::IncDexLevel()
{
#ifdef __S_ADD_RESTATE
	if( m_nRemainGP > 0 )
	{
		m_nDex += 1;
		m_nRemainGP -= 1;
		return TRUE;
	}
#else // __S_ADD_RESTATE
	LPJOBABILITY pJobAbillity;
	if( IsExpert() )
		pJobAbillity = &prj.m_aJobAbillity[ GetJob() ];
	else
		pJobAbillity = &prj.m_aJobAbillity[ JOB_VAGRANT ];
	if( (int)m_nRemainGP >= (int)pJobAbillity->dwDex )
	{
		m_nDex += pJobAbillity->dwDexAdd;
		m_nRemainGP -= pJobAbillity->dwDex;
		return TRUE;
	}
#endif // __S_ADD_RESTATE
	return FALSE;
}
BOOL CMover::IncIntLevel()
{
#ifdef __S_ADD_RESTATE
	if( m_nRemainGP > 0 )
	{
		m_nInt += 1;
		m_nRemainGP -= 1;
		return TRUE;
	}
#else // __S_ADD_RESTATE
	LPJOBABILITY pJobAbillity;
	if( IsExpert() )
		pJobAbillity = &prj.m_aJobAbillity[ GetJob() ];
	else
		pJobAbillity = &prj.m_aJobAbillity[ JOB_VAGRANT ];
	if( (int)m_nRemainGP >= (int)pJobAbillity->dwInt )
	{
		m_nInt += pJobAbillity->dwIntAdd;
		m_nRemainGP -= pJobAbillity->dwInt;
		return TRUE;
	}
#endif // __S_ADD_RESTATE
	return FALSE;
}

BOOL CMover::AddExperience( EXPINTEGER nExp, BOOL bFirstCall, BOOL bMultiPly, BOOL bMonster )
{
#ifdef __VTN_TIMELIMIT
	//	mulcom	BEGIN100315	º£Æ®³² ½Ã°£ Á¦ÇÑ
	if( ::GetLanguage() == LANG_VTN )
	{
		if( IsPlayer() && m_nAccountPlayTime != -1 )
		{
			if( m_nAccountPlayTime < 0 || m_nAccountPlayTime > MIN( 300 ) )
			{
				nExp	= 0;
			}
			else if( m_nAccountPlayTime >= MIN( 180 ) && m_nAccountPlayTime <= MIN( 300 ) )
			{
				nExp	= (EXPINTEGER)( nExp * 0.5f );
			}
		}
	}
	//	mulcom	END100315	º£Æ®³² ½Ã°£ Á¦ÇÑ
#endif // __VTN_TIMELIMIT

#ifdef __GAMEGUARD
	if (IsMode(MODE_EXPUP_STOP))
		return FALSE;
#endif // __GAMEGUARD

#ifdef __3RD_LEGEND16
	if (GetLevel() == MAX_LEGEND_LEVEL && !IsLegendHero())
		return FALSE;
#endif // __3RD_LEGEND16

#ifdef __NEWCLASS
	if (GetLevel() == MAX_3RD_LEGEND_LEVEL && !IsLegendHeroUltimate())
		return FALSE;
#endif // __NEWCLASS

	if( nExp <= 0 )		// nExp°¡ ¸¶ÀÌ³Ê½ºÀÌ°Å³ª 0ÀÌ¸é Ã³¸®ÇÒÇÊ¿ä ¾øÀ½.
		return FALSE;

	if( m_nHitPoint <= 0 )
		return FALSE;

#if __VER < 15 // __GUILD_HOUSE
	if( bFirstCall && bMultiPly )
	{
		nExp	*= GetExpFactor();
	}
#endif // __GUILD_HOUSE
#ifdef __INTERNALSERVER
	TRACE( "EXP = %I64d\n", nExp );
#endif	// __INTERNALSERVER

#if __VER >= 14 // __ANGEL_EXPERIENCE
	/*
#ifdef __NEWCLASS
	if (IsMaster() || IsHero() || IsLegendHero() || IsLegendHeroUltimate())
#elif defined (__3RD_LEGEND16)
	if (IsMaster() || IsHero() || IsLegendHero())
#else // __3RD_LEGEND16
	if (IsMaster() || IsHero())
#endif // __3RD_LEGEND16
	{
		nExp /= 2;
	}
	*/
#if __VER >= 15 // __GUILD_HOUSE
	if( bFirstCall && bMultiPly )
	{
#ifdef __WORLDSERVER
		EXPINTEGER nAddExp = static_cast<CUser*>( this )->GetAddExpAfterApplyRestPoint( nExp );
		nExp	= (EXPINTEGER)( nExp * GetExpFactor() );
		nExp += nAddExp;
#endif // __WORLDSERVER
	}
#endif // __GUILD_HOUSE

#if __VER >= 8 //__CSC_VER8_5
	if( bFirstCall && HasBuffByIk3( IK3_ANGEL_BUFF ) )
	{
		int nAngel = 100;
#ifdef __BUFF_1107
		IBuff* pBuff	= m_buffs.GetBuffByIk3( IK3_ANGEL_BUFF );
		WORD wId	= ( pBuff? pBuff->GetId(): 0 );
#else	// __BUFF_1107
		LPSKILLINFLUENCE lpSkillIn = m_SkillState.GetItemBuf( IK3_ANGEL_BUFF );
		WORD wId	= ( lpSkillIn? lpSkillIn->wID: 0 );
#endif	// __BUFF_1107
		if( wId > 0 )
		{
			ItemProp* pItemProp = prj.GetItemProp( wId );
			if( pItemProp )
				nAngel = (int)( (float)pItemProp->nAdjParamVal1 );
		}
		if( nAngel <= 0 || 100 < nAngel  )
			nAngel = 100;
		// Ë¬: ÀüÁ÷ Àü ¿£Á© ¹öÇÁ È°¼ºÈ­ ÈÄ ÀüÁ÷ÇÏ´Â °æ¿ì, ÇÊ¿ä ¼öÄ¡°¡ ³Ê¹« Å©´Ù.
		EXPINTEGER nMaxAngelExp = prj.m_aExpCharacter[m_nAngelLevel].nExp1 / 100 * nAngel;
		if( m_nAngelExp < nMaxAngelExp )
		{
			nExp /= 2;
			m_nAngelExp += nExp;
#ifdef __WORLDSERVER
#ifdef __ANGEL_LOG
#ifdef __EXP_ANGELEXP_LOG
			int nAngelExpPercent = (int)( m_nAngelExp * 100 / nMaxAngelExp );
			int nNextAngelExpLog = (int)(((CUser*)this)->m_nAngelExpLog / 20 + 1) * 20;
			
			if( nAngelExpPercent >= nNextAngelExpLog )
			{
				((CUser*)this)->m_nAngelExpLog = nAngelExpPercent;
				ItemProp* pItemProp = prj.GetItemProp( wId );
				
				if( pItemProp )
				{
					LogItemInfo aLogItem;
					aLogItem.Action		= "&";
					aLogItem.SendName	= ((CUser*)this)->GetName();
					aLogItem.RecvName	= "ANGEL_EXP_LOG";
					aLogItem.WorldId	= ((CUser*)this)->GetWorld()->GetID();
					aLogItem.Gold		= aLogItem.Gold2 = ((CUser*)this)->GetGold();
					//aLogItem.ItemName	= pItemProp->szName;
					_stprintf( aLogItem.szItemName, "%d", pItemProp->dwID );
					aLogItem.Gold_1		= (DWORD)( m_nAngelExp );
					g_DPSrvr.OnLogItem( aLogItem );
				}
			}
#endif //  __EXP_ANGELEXP_LOG
#endif // __ANGEL_LOG
			
			BOOL bAngelComplete = FALSE;
			if( m_nAngelExp > nMaxAngelExp )
			{
				m_nAngelExp = nMaxAngelExp;
				bAngelComplete = TRUE;
			}
			((CUser*)this)->AddAngelInfo( bAngelComplete );
#endif // __WORLDSERVER
		}
	}
#endif // __CSC_VER8_5
#endif // __ANGEL_EXPERIENCE

	if( IsBaseJob() )
	{
		if( m_nLevel >= MAX_JOB_LEVEL )
		{
			m_nExp1		= 0;
			return TRUE;
		}
	}
	else if( IsExpert() )
	{
		if( m_nLevel >= MAX_JOB_LEVEL + MAX_EXP_LEVEL )
		{
			m_nExp1		= 0;
			return TRUE;
		}
	}
	else if( IsPro() )
	{
		if( m_nLevel > MAX_GENERAL_LEVEL )
		{
			m_nLevel = MAX_GENERAL_LEVEL;
			return TRUE;
		}		
	}
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	else if(IsMaster())
	{
		if( m_nLevel > MAX_GENERAL_LEVEL )
		{
			m_nLevel = MAX_GENERAL_LEVEL;
			return TRUE;
		}
#if __VER < 14 // __ANGEL_EXPERIENCE
		else
		{
			nExp /= 2;
		}
#endif // __ANGEL_EXPERIENCE 
	}
	else if (IsHero())
	{
		if (m_nLevel > MAX_LEGEND_LEVEL)
		{
			m_nLevel = MAX_LEGEND_LEVEL; 
			return TRUE; 
		}
#if __VER < 14 // __ANGEL_EXPERIENCE 
		else
		{
			nExp /= 2;
		}
#endif // __ANGEL_EXPERIENCE
	}
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#ifdef __3RD_LEGEND16
	else if( IsLegendHero() )
	{
		if( m_nLevel > MAX_3RD_LEGEND_LEVEL )
		{
			m_nLevel = MAX_3RD_LEGEND_LEVEL;
			return TRUE;
		}
	}
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
	else if (IsLegendHeroUltimate())
	{
		if (m_nLevel > MAX_4TH_JOBS_LEVEL)
		{
			m_nLevel = MAX_4TH_JOBS_LEVEL;
			return TRUE;
		}
#if __VER < 14 // __ANGEL_EXPERIENCE
		else
		{
			nExp /= 2;
		}
#endif // __ANGEL_EXPERIENCE
	}
#endif // __NEWCLASS
	int nLevelbuf = m_nLevel;
	int nNextLevel = m_nLevel + 1;

#if __VER < 14 // __ANGEL_EXPERIENCE
#if __VER >= 8 //__CSC_VER8_5
	if( bFirstCall && HasBuffByIk3( IK3_ANGEL_BUFF ) )
	{
		int nAngel = 100;
#ifdef __BUFF_1107
		IBuff* pBuff	= m_buffs.GetBuffByIk3( IK3_ANGEL_BUFF );
		WORD wId	= ( pBuff? pBuff->GetId(): 0 );
#else	// __BUFF_1107
		LPSKILLINFLUENCE lpSkillIn = m_SkillState.GetItemBuf( IK3_ANGEL_BUFF );
		WORD wId	= ( lpSkillIn? lpSkillIn->wID: 0 );
#endif	// __BUFF_1107
		if( wId > 0 )
		{
			ItemProp* pItemProp = prj.GetItemProp( wId );
			if( pItemProp )
				nAngel = (float)pItemProp->nAdjParamVal1;
		}
		if( nAngel <= 0 || 100 < nAngel  )
			nAngel = 100;
		// Ë¬: ÀüÁ÷ Àü ¿£Á© ¹öÇÁ È°¼ºÈ­ ÈÄ ÀüÁ÷ÇÏ´Â °æ¿ì, ÇÊ¿ä ¼öÄ¡°¡ ³Ê¹« Å©´Ù.
		EXPINTEGER nMaxAngelExp = prj.m_aExpCharacter[m_nAngelLevel].nExp1 / 100 * nAngel;
		if( m_nAngelExp < nMaxAngelExp )
		{
			nExp /= 2;
			m_nAngelExp += nExp;
#ifdef __WORLDSERVER
#ifdef __ANGEL_LOG
#ifdef __EXP_ANGELEXP_LOG
			int nAngelExpPercent = m_nAngelExp * 100 / nMaxAngelExp;
			int nNextAngelExpLog = (int)(((CUser*)this)->m_nAngelExpLog / 20 + 1) * 20;
	
			if( nAngelExpPercent >= nNextAngelExpLog )
			{
				((CUser*)this)->m_nAngelExpLog = nAngelExpPercent;
				ItemProp* pItemProp = prj.GetItemProp( wId );

				if( pItemProp )
				{
					LogItemInfo aLogItem;
					aLogItem.Action = "&";
					aLogItem.SendName = ((CUser*)this)->GetName();
					aLogItem.RecvName = "ANGEL_EXP_LOG";
					aLogItem.WorldId = ((CUser*)this)->GetWorld()->GetID();
					aLogItem.Gold = aLogItem.Gold2 = ((CUser*)this)->GetGold();
					//aLogItem.ItemName = pItemProp->szName;
					_stprintf( aLogItem.szItemName, "%d", pItemProp->dwID );
					aLogItem.Gold_1 = m_nAngelExp;
					g_DPSrvr.OnLogItem( aLogItem );
				}
			}
#endif //  __EXP_ANGELEXP_LOG
#endif // __ANGEL_LOG

			BOOL bAngelComplete = FALSE;
			if( m_nAngelExp > nMaxAngelExp )
			{
				m_nAngelExp = nMaxAngelExp;
				bAngelComplete = TRUE;
			}
			((CUser*)this)->AddAngelInfo( bAngelComplete );
#endif // __WORLDSERVER
		}
	}
#endif // __CSC_VER8_5
#endif // __ANGEL_EXPERIENCE
#ifdef __REBIRTH_EXP
	if (m_nCampusPoint >= 1)
		nExp = nExp / m_nCampusPoint;
#endif
	m_nExp1 += nExp;									// pxp¿Í °ü°è¾øÀÌ exp°¡ Áõ°¡. ¸¸½¦ÀÌ!
	
	if( bFirstCall )
	{
#if __VER >= 8 // __S8_PK
#ifdef __WORLDSERVER
		if( bMonster && IsChaotic() )
		{
			m_dwPKExp	= (DWORD)( m_dwPKExp + nExp );
			DWORD dwPropensity = GetPKPropensity(); // undorflow
			int nLevelPKExp = prj.GetLevelExp( GetLevel() ); // Levelº° °¨¼Ò °æÇèÄ¡
			if( nLevelPKExp != 0 )
			{
				int nSubExp = m_dwPKExp / nLevelPKExp;
				if( nSubExp )
				{
					SetPKPropensity( GetPKPropensity() - ( m_dwPKExp / nLevelPKExp ) );
					if( dwPropensity <= GetPKPropensity() )
						SetPKPropensity( 0 );
					m_dwPKExp %= nLevelPKExp;
					
					g_UserMng.AddPKPropensity( this );
					g_dpDBClient.SendLogPkPvp( this, NULL, 0, 'P' );
				}
			}
		}
#endif // __WORLDSERVER
#endif // __VER >= 8 // __S8_PK
	}

	if( m_nExp1 >= prj.m_aExpCharacter[nNextLevel].nExp1 )	// ·¹º§¾÷
	{
#ifdef __NEWCLASS
		if (IsLegendHeroUltimate() && (nNextLevel > MAX_4TH_JOBS_LEVEL))
		{
			m_nLevel = MAX_4TH_JOBS_LEVEL;

			m_nExp1 = (prj.m_aExpCharacter[nNextLevel].nExp1 - 1);
			return FALSE;
		}
		else if (!IsHero() && !IsLegendHero() && !IsLegendHeroUltimate() && nNextLevel > MAX_GENERAL_LEVEL)
		{
			m_nLevel = MAX_GENERAL_LEVEL;

			m_nExp1 = (prj.m_aExpCharacter[nNextLevel].nExp1 - 1);
			return FALSE;
		}
#elif defined (__3RD_LEGEND16)
		if (IsLegendHero() && (nNextLevel > MAX_3RD_LEGEND_LEVEL))
		{
			m_nLevel = MAX_3RD_LEGEND_LEVEL;

			m_nExp1 = (prj.m_aExpCharacter[nNextLevel].nExp1 - 1);
			return FALSE;
		}
		else if (!IsHero() && !IsLegendHero() && nNextLevel > MAX_GENERAL_LEVEL)
		{
			m_nLevel = MAX_GENERAL_LEVEL;

			m_nExp1 = (prj.m_aExpCharacter[nNextLevel].nExp1 - 1);
			return FALSE;
		}
#else // __3RD_LEGEND16
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if (IsHero() && (nNextLevel > MAX_LEGEND_LEVEL))
		{
			m_nLevel = MAX_LEGEND_LEVEL;

			m_nExp1 = (prj.m_aExpCharacter[nNextLevel].nExp1 - 1);
			return FALSE;
		}
		else if (!IsHero() && nNextLevel > MAX_LEVEL)
		{
			m_nLevel = MAX_LEVEL;

			m_nExp1 = (prj.m_aExpCharacter[nNextLevel].nExp1 - 1);
			return FALSE;
		}
#else //__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if (nNextLevel > MAX_LEVEL)
		{
			m_nLevel = MAX_LEVEL;

			m_nExp1 = (prj.m_aExpCharacter[nNextLevel].nExp1 - 1);
			return FALSE;
		}
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#endif // __3RD_LEGEND16
		EXPINTEGER nExptmp;
//		BOOL f	= FALSE;

		{
			m_nRemainGP += prj.m_aExpCharacter[ nNextLevel ].dwLPPoint;
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#ifdef __NEWCLASS
			if (IsMaster() || IsHero() || IsLegendHero() || IsLegendHeroUltimate())
#elif defined (__3RD_LEGEND16)
			if (IsMaster() || IsHero() || IsLegendHero())
#else // __3RD_LEGEND16
			if (IsMaster() || IsHero())
#endif // __3RD_LEGEND16
			{
				m_nRemainGP++;
			}
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

			nExptmp		= m_nExp1 - prj.m_aExpCharacter[nNextLevel].nExp1;
#if __VER >= 8  
			m_nExp1		= 0;
#else //  __VER >= 8  
			m_nExp1		= m_nDeathExp		= 0;
#endif //  __VER >= 8  
			m_nLevel	= nNextLevel;

//			if( m_nLevel > m_nDeathLevel )
//				f	= TRUE;

			BOOL bLevelUp = TRUE;
			if( IsBaseJob() && m_nLevel > MAX_JOB_LEVEL ) 
			{
				m_nLevel = MAX_JOB_LEVEL;
				bLevelUp = FALSE;
			}
			else if( IsExpert() && m_nLevel > MAX_JOB_LEVEL + MAX_EXP_LEVEL )
			{
				m_nLevel = MAX_JOB_LEVEL + MAX_EXP_LEVEL;
				bLevelUp = FALSE;
			}
			else if( IsPro() && m_nLevel > MAX_GENERAL_LEVEL )
			{
				m_nLevel = MAX_GENERAL_LEVEL;
				bLevelUp = FALSE;

				m_nExp1  = (prj.m_aExpCharacter[nNextLevel].nExp1 - 1);
				nExptmp  = 0;
				return FALSE;
			}
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			else if( IsMaster() && m_nLevel > MAX_GENERAL_LEVEL )
			{
				m_nLevel = MAX_GENERAL_LEVEL;
				bLevelUp = FALSE;
				m_nExp1  = (prj.m_aExpCharacter[nNextLevel].nExp1 - 1);
				nExptmp  = 0;
				return FALSE;
			}
#ifdef __3RD_LEGEND16
			else if (IsHero() && (m_nLevel > MAX_LEGEND_LEVEL))
			{
				m_nLevel = MAX_LEGEND_LEVEL;
				bLevelUp = FALSE;
				m_nExp1 = (prj.m_aExpCharacter[nNextLevel].nExp1 - 1);
				nExptmp = 0;
				return FALSE;
			}
			else if( IsLegendHero() && m_nLevel > MAX_3RD_LEGEND_LEVEL )
			{
				m_nLevel = MAX_GENERAL_LEVEL;
				bLevelUp = FALSE;
				m_nExp1  = (prj.m_aExpCharacter[nNextLevel].nExp1 - 1);
				nExptmp  = 0;
				return FALSE;
			}			
#else // __3RD_LEGEND16
			else if( IsHero() && (m_nLevel > MAX_3RD_LEGEND_LEVEL ) )
			{
				m_nLevel = MAX_3RD_LEGEND_LEVEL;
				bLevelUp = FALSE;
				m_nExp1  = (prj.m_aExpCharacter[nNextLevel].nExp1 - 1);
				nExptmp  = 0;
				return FALSE;
			}
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
			else if (IsLegendHeroUltimate() && m_nLevel > MAX_4TH_JOBS_LEVEL)
			{
				m_nLevel = MAX_4TH_JOBS_LEVEL;
				bLevelUp = FALSE;
				m_nExp1 = (prj.m_aExpCharacter[nNextLevel].nExp1 - 1);
				nExptmp = 0;
				return FALSE;
			}
#endif // __NEWCLASS
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

			if( bLevelUp )
			{
				m_nHitPoint = GetMaxHitPoint();
				m_nManaPoint = GetMaxManaPoint();
				m_nFatiguePoint = GetMaxFatiguePoint();
				SetJobLevel( m_nLevel, m_nJob );
#ifdef __CREATE_CHAR_WITH_JOB
#ifdef __WORLDSERVER
				if (GetLevel() == 3)
				{
					LPSKILL pSkill = NULL;
					ItemProp* pSkillProp = NULL;

					for (int i = 0; i < MAX_SKILL_JOB; i++)
					{
						pSkill = &(((CUser*)this)->m_aJobSkill[i]);

						if (pSkill == NULL || pSkill->dwSkill == 0xffffffff)
							continue;

						pSkillProp = prj.GetSkillProp(pSkill->dwSkill);

						if (pSkillProp == NULL)
							continue;

						pSkill->dwLevel = pSkillProp->dwExpertMax;
						((CUser*)this)->AddSetSkill(pSkill->dwSkill, pSkill->dwLevel);
					}
				}
#endif // __WORLDSERVER
#endif // __CREATE_CHAR_WITH_JOB
#if __VER >= 8  
				if( m_nDeathLevel >= m_nLevel )
				{
					m_nRemainGP -= prj.m_aExpCharacter[ nNextLevel ].dwLPPoint;
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#ifdef __NEWCLASS
					if (IsMaster() || IsHero() || IsLegendHero() || IsLegendHeroUltimate())
#elif defined (__3RD_LEGEND16)
					if (IsMaster() || IsHero() || IsLegendHero())
#else // __3RD_LEGEND16
					if (IsMaster() || IsHero())
#endif // __3RD_LEGEND16
					{
						m_nRemainGP--;
					}
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
				}
#endif //  __VER >= 8  

#ifdef __WORLDSERVER
				if( m_nDeathLevel < m_nLevel )
				{
					int nGetPoint = ((GetLevel() - 1) / 20) + 2;
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#ifdef __NEWCLASS
					if (IsMaster() || IsHero() || IsLegendHero() || IsLegendHeroUltimate())
#elif defined (__3RD_LEGEND16)
					if (IsMaster() || IsHero() || IsLegendHero())
#else // __3RD_LEGEND16
					if (IsMaster() || IsHero())
#endif // __3RD_LEGEND16
					{
						SetMasterSkillPointUp();
					}
					else
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
					{
						AddSkillPoint( nGetPoint );
						g_dpDBClient.SendLogSkillPoint( LOG_SKILLPOINT_GET_HUNT, nGetPoint, this, NULL );
#ifdef __S_NEW_SKILL_2
						g_dpDBClient.SaveSkill( (CUser*)this );
#endif // __S_NEW_SKILL_2
					}
#ifdef __S_RECOMMEND_EVE
				    if( g_eLocal.GetState( EVE_RECOMMEND ) && IsPlayer() )
					{
						g_dpDBClient.SendRecommend( (CUser*)this );
					}					
#endif // __S_RECOMMEND_EVE
#ifdef __EXP_ANGELEXP_LOG
					((CUser*)this)->m_nExpLog = 0;
#endif // __EXP_ANGELEXP_LOG
#ifdef __EVENTLUA_GIFT
					prj.m_EventLua.SetLevelUpGift( (CUser*)this, m_nLevel );
#endif // __EVENTLUA_GIFT
#if __VER >= 15 // __CAMPUS
					CCampusHelper::GetInstance()->SetLevelUpReward( (CUser*)this );
#endif // __CAMPUS
#ifdef __BADGE
					static_cast<CUser*>(this)->SetBadgeAddType(HI_EARN_TITLE, GetJobType(GetJob()), GetLevel());
#endif //__BADGE
				}
#endif // __WORLDSERVER
			}
			else
			{
				m_nRemainGP -= prj.m_aExpCharacter[ nNextLevel ].dwLPPoint;
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#ifdef __NEWCLASS
				if (IsMaster() || IsHero() || IsLegendHero() || IsLegendHeroUltimate())
#elif defined (__3RD_LEGEND16)
				if (IsMaster() || IsHero() || IsLegendHero())
#else // __3RD_LEGEND16
				if (IsMaster() || IsHero())
#endif // __3RD_LEGEND16
				{
					m_nRemainGP--;
				}
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
				nExptmp	= m_nExp1	= 0;
			}

			// ·¹º§ 20ÀÌ µÇ´Â¼ø°£ ºñÇà·¹º§Àº 1ÀÌµÈ´Ù.
			if( m_nLevel == 20 )
				SetFlightLv( 1 );
			
#ifdef __CLIENT
			if( m_pActMover && ( m_pActMover->IsState( OBJSTA_STAND ) || m_pActMover->IsState( OBJSTA_STAND2 )) )
				SetMotion( MTI_LEVELUP, ANILOOP_1PLAY, MOP_FIXED );
			CreateSfx(g_Neuz.m_pd3dDevice,XI_GEN_LEVEL_UP01,GetPos(),GetId());
			PlayMusic( BGM_IN_LEVELUP );
#endif	// __CLIENT
		}

		if( nExptmp > 0 )
			AddExperience( nExptmp, FALSE, bMultiPly );
		return TRUE;
	}

	return FALSE;
}

// °æÇèÄ¡¸¦ nExp¸¸Å­ ±ð´Â´Ù.  ·¾´Ù¿îµµ µÈ´Ù.
// bExp2Clear : pxp¸¦ 0À¸·Î ÇÒ°ÇÁö ¸»°ÇÁö.
// bLvDown : ·¹º§´Ù¿îÀ» ÇÒ°ÇÁö ¸»°ÇÁö.
BOOL CMover::DecExperience( EXPINTEGER nExp, BOOL bExp2Clear, BOOL bLvDown )
{
	if( nExp < 0 )	// °ªÀº Ç×»ó ¾ç¼ö·Î¸¸ Áà¾ß ÇÑ´Ù.
		return FALSE;
	
	int nPrevLevel	= m_nLevel - 1;
	if( nPrevLevel < 1 )	// ·¹º§ 1ÀÌÇÏ·Î´Â ´õÀÌ»ó ³»·Á°¡Áö ¾ÊÀ½.
		return FALSE;

	m_nExp1		-= nExp;	// nExp¸¸Å­ °æÇèÄ¡¸¦ ±ðÀ½. Exp2´Â 0%·Î.

#if __VER < 8     // 8Â÷ ½ºÅ³°æÇèÄ¡´Ù¿îº¯°æ
	m_nSkillExp	-= nExp;
#endif	// __VER >= 8  

	if( m_nExp1 < 0 )
	{
		if( bLvDown )	// ·¾´Ù¿îÀÌ µÇ´Â »óÈ².
		{
#if __VER >= 8  
			--m_nLevel;
			m_nExp1 = (EXPINTEGER)(prj.m_aExpCharacter[m_nLevel+1].nExp1 + m_nExp1 );
#endif //  __VER >= 8  
			return TRUE;	// ·¾´Ù¿î µÆÀ¸¸é TRUE¸®ÅÏ
		}
		else
		{
			m_nExp1		= 0;
#ifdef __WORLDSERVER
			g_dpDBClient.SendLogLevelUp( this, 7 );
#endif // __WORLDSERVER
		}
	}
	return FALSE;
}

// ÇöÀç ·¹º§ÀÇ ÃÖ´ë°æÇèÄ¡ÀÇ %·Î °æÇèÄ¡ ÇÏ¶ô
// ex) fPercent = 0.2f;		// 20%
BOOL CMover::DecExperiencePercent( float fPercent, BOOL bExp2Clear, BOOL bLvDown )
{
	EXPINTEGER	nExpOld		= m_nExp1;		// ±ðÀÌ±âÀü exp
	EXPINTEGER	nMaxExp		= prj.m_aExpCharacter[m_nLevel+1].nExp1;	// ±ðÀÌ±âÀü °æÇèÄ¡Ä¡ ¸Æ½º·®.
	int	nOldLv	= m_nLevel;		// ±ðÀÌ±âÀü ·¹º§.

	if( fPercent == 0.0f )	
		return FALSE;	// 0%¸¦ ±ð´Â »óÈ²ÀÌ¸é °è»êÇÒ ÇÊ¿ä ¾ø´Ù.

	EXPINTEGER	nDecExp = (EXPINTEGER)(prj.m_aExpCharacter[m_nLevel+1].nExp1 * fPercent );	// ÇöÀç·¹º§ÀÇ ÃÖ´ë°æÇèÄ¡ * ÆÛ¼¾Æ®
	bLvDown		= DecExperience( nDecExp, bExp2Clear, bLvDown );

	if( bLvDown )	// ½ÇÁ¦·Î ·¹º§ÀÌ ´Ù¿îµÇ¾úÀ»¶§.
	{
		if( m_nLevel - nOldLv < -1 )	// ·¹º§ÀÌ µÎ´Ü°è ÀÌ»ó ´Ù¿îµÇ´Â ÀÏÀº ¾ø¾î¾ß ÇÑ´Ù.
			Error( "CMover::DecExperiencePercent : %s ·¹º§´Ù¿î ÀÌ»ó. %d -> %d  %I64d(%f)"
			, m_szName, nOldLv, m_nLevel, nDecExp, fPercent );

		EXPINTEGER	nDecExp2	= ( prj.m_aExpCharacter[m_nLevel+1].nExp1 - m_nExp1 ) + nExpOld;	// ½ÇÁ¦ ±ðÀÎ Æ÷ÀÎÆ®.
		if( nDecExp2 > nDecExp )	// ½ÇÁ¦ ±ðÀÎ¾çÀÌ ¿ø·¡ ±ðÀ¸·Á°í Çß´ø ¾çº¸´Ù ¸¹À¸¸é °æ°í.
			Error( "1 CMover::DecExperiencePercent : %s(Lv%d) °æÇèÄ¡°¡ ÀÌ»óÇÏ°Ô ±ðÀÓ. %I64d %I64d(%f) %I64d %I64d"
			, m_szName, GetLevel(), nMaxExp, nDecExp, fPercent, nExpOld, m_nExp1 );
	}
	else
	{
		EXPFLOAT fOldPercent = static_cast<EXPFLOAT>( nExpOld ) / static_cast<EXPFLOAT>( nMaxExp );		// ±ðÀÌ±âÀü ÆÛ¼¾Æ®·®.
		EXPFLOAT fCurPercent = static_cast<EXPFLOAT>( m_nExp1 ) / static_cast<EXPFLOAT>( nMaxExp );		// ±ïÀºÈÄ ÆÛ¼¾Æ®·®.

		if( fOldPercent - fCurPercent > 0.060f )
			Error( "0 CMover::DecExperiencePercent : %s(Lv%d) °æÇèÄ¡°¡ ÀÌ»óÇÏ°Ô ±ðÀÓ. %I64d %I64d(%f) %I64d(%f) %I64d(%f)"
			, m_szName, GetLevel(), nMaxExp, nDecExp, fPercent, nExpOld, fOldPercent, m_nExp1, fCurPercent );
	}

	return bLvDown;
}

// ºñÇà °æÇèÄ¡ È¹µæ
BOOL CMover::AddFxp( int nFxp )
{
	if( nFxp <= 0 )		// nExp°¡ ¸¶ÀÌ³Ê½ºÀÌ°Å³ª 0ÀÌ¸é Ã³¸®ÇÒÇÊ¿ä ¾øÀ½.
		return FALSE;

	if( m_nHitPoint <= 0 )		// Á×°í³ª¼± °æÇèÄ¡ È¹µæ ¸øÇÔ.
		return FALSE;

	if( GetFlightLv() == 0 )
		return FALSE;

	int nNextLevel = GetFlightLv() + 1;

	m_nFxp += nFxp;		// ÀÏ´Ü °æÇèÄ¡¸¦ ´õÇÏ°í.
	if( (DWORD)( m_nFxp ) >= prj.m_aFxpCharacter[nNextLevel].dwFxp ) // ·¹º§¾÷ÀÌ µÇ¾ú´ÂÁö È®ÀÎ.
	{
		int		FxpBuf;
		FxpBuf = m_nFxp - prj.m_aFxpCharacter[ nNextLevel ].dwFxp;		// ·¹º§¾÷ÇÏ°íµµ ¾ó¸¶³ª ´õ ¿À¹öµÆ´ÂÁö?
		m_nFxp = 0;
		SetFlightLv( nNextLevel );	// ·¹º§ Áõ°¡.
		
#ifdef __CLIENT
		// ·¹º§¾÷½Ã ÀÌÆåÆ®
		CreateSfx(g_Neuz.m_pd3dDevice,XI_GEN_LEVEL_UP01,GetPos(),GetId());
		PlayMusic( BGM_IN_LEVELUP );
#endif	// __CLIENT
	
		// ¿À¹ÙµÈ °æÇèÄ¡´Â ÇÑ¹ø´õ µ¹·Á¼­ ´õÇØÁÜ.
		if( FxpBuf > 0)
		{
			AddFxp( FxpBuf );
		}

		return TRUE;
	}
	return FALSE;
}

BOOL CMover::AddChangeJob( int nJob )
{
	BOOL	bResult = FALSE;
	LPSKILL lpSkill;
	if( MAX_JOBBASE <= nJob && nJob < MAX_EXPERT ) // 1Â÷ ÀüÁ÷ ±îÁö~~ ^^;;;;
	{
		m_nJob = nJob;
		
		ItemProp** apSkillProp = prj.m_aJobSkill[ m_nJob ];
		int nJobNum = prj.m_aJobSkillNum[ m_nJob ];
		for( int i = 0; i < nJobNum; i++ )
		{
			ItemProp* pSkillProp = apSkillProp[ i ];
			lpSkill = &m_aJobSkill[ i + MAX_JOB_SKILL ];
			lpSkill->dwSkill = pSkillProp->dwID;
		}
		bResult = TRUE;
	}
	if( MAX_EXPERT <= nJob && nJob < MAX_PROFESSIONAL ) // 2Â÷ ÀüÁ÷ ±îÁö~~ ^^;;;;
	{
		m_nJob = nJob;
		
		ItemProp** apSkillProp = prj.m_aJobSkill[ m_nJob ];
		int nJobNum = prj.m_aJobSkillNum[ m_nJob ];
		for( int i = 0; i < nJobNum; i++ )
		{
			ItemProp* pSkillProp = apSkillProp[ i ];
			lpSkill = &m_aJobSkill[ i + MAX_JOB_SKILL + MAX_EXPERT_SKILL ];
			lpSkill->dwSkill = pSkillProp->dwID;
		}
		bResult = TRUE;
	}
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	if( MAX_PROFESSIONAL <= nJob && nJob < MAX_MASTER ) // Àü½Â ±îÁö~~ ^^;;;;
	{
		m_nJob = nJob;
		
		ItemProp** apSkillProp = prj.m_aJobSkill[ m_nJob ];
		int nJobNum = prj.m_aJobSkillNum[ m_nJob ];
		for( int i = 0; i < nJobNum; i++ )
		{
			ItemProp* pSkillProp = apSkillProp[ i ];
			lpSkill = &m_aJobSkill[ i + MAX_JOB_SKILL + MAX_EXPERT_SKILL + MAX_PRO_SKILL];
			lpSkill->dwSkill = pSkillProp->dwID;
			lpSkill->dwLevel = 1;	//master½ºÅ³Àº 1ºÎÅÍ ÁØ´Ù.
		}
		bResult = TRUE;
	}
	
	if( MAX_MASTER <= nJob && nJob < MAX_HERO ) // ¿µ¿õ ±îÁö~~ ^^;;;;
	{
		m_nJob = nJob;
		
		ItemProp** apSkillProp = prj.m_aJobSkill[ m_nJob ];
		int nJobNum = prj.m_aJobSkillNum[ m_nJob ];
		for( int i = 0; i < nJobNum; i++ )
		{
			ItemProp* pSkillProp = apSkillProp[ i ];
			lpSkill = &m_aJobSkill[ i + MAX_JOB_SKILL + MAX_EXPERT_SKILL + MAX_PRO_SKILL + MAX_MASTER_SKILL ];
			lpSkill->dwSkill = pSkillProp->dwID;
		}
		bResult = TRUE;
	}
#ifdef __3RD_LEGEND16
	if( MAX_HERO <= nJob && nJob < MAX_LEGEND_HERO )
	{
		m_nJob = nJob;
		
		ItemProp** apSkillProp = prj.m_aJobSkill[ m_nJob ];
		int nJobNum = prj.m_aJobSkillNum[ m_nJob ];
		for( int i = 0; i < nJobNum; i++ )
		{
			ItemProp* pSkillProp = apSkillProp[ i ];
			lpSkill = &m_aJobSkill[ i + MAX_JOB_SKILL + MAX_EXPERT_SKILL + MAX_PRO_SKILL + MAX_MASTER_SKILL + MAX_HERO_SKILL ];
			lpSkill->dwSkill = pSkillProp->dwID;
		}
		bResult = TRUE;
	}
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
	if (MAX_LEGEND_HERO <= nJob && nJob < MAX_LEGEND_HERO_ULTIMATE)
	{
		m_nJob = nJob;

		ItemProp** apSkillProp = prj.m_aJobSkill[m_nJob];
		int nJobNum = prj.m_aJobSkillNum[m_nJob];
		for (int i = 0; i < nJobNum; i++)
		{
			ItemProp* pSkillProp = apSkillProp[i];
			lpSkill = &m_aJobSkill[i + MAX_JOB_SKILL + MAX_EXPERT_SKILL + MAX_PRO_SKILL + MAX_MASTER_SKILL + MAX_HERO_SKILL + MAX_LEGEND_HERO_SKILL];
			lpSkill->dwSkill = pSkillProp->dwID;
	}
		bResult = TRUE;
}
#endif // __NEWCLASS
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans


#ifdef __WORLDSERVER
#ifdef __S_NEW_SKILL_2
	g_dpDBClient.SaveSkill( (CUser*)this );
#endif // __S_NEW_SKILL_2
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
	((CUser*)this)->CheckHonorStat();
	((CUser*)this)->AddHonorListAck();
	g_UserMng.AddHonorTitleChange( this, m_nHonor);
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
#endif // __WORLDSERVER
	return bResult;
}

BOOL CMover::SetFxp( int nFxp, int nFlightLv )
{
	m_nFxp = nFxp;

	// ·¹º§ÀÌ ¿Ã¶úÀ¸¸é.
	if( nFlightLv > GetFlightLv() )
	{
		SetFlightLv( nFlightLv );
#ifdef __CLIENT
		CreateSfx(g_Neuz.m_pd3dDevice,XI_GEN_LEVEL_UP01,GetPos(),GetId());
		PlayMusic( BGM_IN_LEVELUP );
		g_WndMng.PutString( prj.GetText( TID_GAME_FLYLVLUP ), NULL, prj.GetTextColor( TID_GAME_FLYLVLUP ) );
#endif // CLIENT
		return TRUE;
	}

	return FALSE;
}

BOOL CMover::SetExperience( EXPINTEGER nExp1, int nLevel )
{
	m_nExp1		= nExp1;

	if( IsInvalidObj(this) )
		return 0;
#ifdef __NEW_CHANGE_JOB
#ifdef __CLIENT
	if ((GetLevel() == MAX_GENERAL_LEVEL && IsPro() && GetExpPercent() == 9999)
		|| (GetLevel() == MAX_GENERAL_LEVEL && IsMaster() && GetExpPercent() == 9999))
	{
		if (!g_WndMng.GetApplet(APP_CHANGE_JOB_03))
			g_WndMng.CreateApplet(APP_CHANGE_JOB_03);
	}
#endif // __CLIENT
#endif // __NEW_CHANGE_JOB
	if( nLevel > m_nLevel )
	{
#ifdef __CLIENT
 		// 15·¾ µÇ¸é ´õÀÌ»ó ÃÊº¸ÀÚ°¡ ¾Æ´Ï¹Ç·Î ÀÚµ¿À¸·Î ÃÊº¸ÀÚµµ¿ò¸» ²ôÀÚ.
		if( nLevel == 15 )		// 1Â÷ÀüÁ÷·¹º§ 15¿¡ ´ëÇÑ define ÀÖÀ¸¸é ±×°É·Î ¹Ù²ãÁÖ. -xuzhu-
			g_Option.m_nInstantHelp = 0;
 		
		PutLvUpSkillName_1(nLevel);

		if( m_pActMover && ( m_pActMover->IsState( OBJSTA_STAND ) || m_pActMover->IsState( OBJSTA_STAND2 ) ) )
			SetMotion( MTI_LEVELUP, ANILOOP_1PLAY, MOP_FIXED );
		CreateSfx(g_Neuz.m_pd3dDevice,XI_GEN_LEVEL_UP01,GetPos(),GetId());
		PlayMusic( BGM_IN_LEVELUP );
		if( m_nDeathLevel < nLevel )
			g_WndMng.PutString( prj.GetText( TID_GAME_LEVELUP ), NULL, prj.GetTextColor( TID_GAME_LEVELUP ) );
		
		if( g_WndMng.m_pWndWorld )
		{
#ifdef __ADVANCED_ANNOUNCEMENT
			g_Caption1.AddCaption(prj.GetText(TID_GAME_LEVELUP_CAPTION), NULL, NULL, D3DCOLOR_ARGB(255, 255, 255, 255), 6, 0);
#else //__ADVANCED_ANNOUNCEMENT
			if (::GetLanguage() != LANG_JAP)
				g_Caption1.AddCaption(prj.GetText(TID_GAME_LEVELUP_CAPTION), g_WndMng.m_pWndWorld->m_pFontAPICaption);
			else
				g_Caption1.AddCaption(prj.GetText(TID_GAME_LEVELUP_CAPTION), NULL);// CWndBase::m_Theme.m_pFontCaption );
#endif //__ADVANCED_ANNOUNCEMENT
		}
		
		// 2, 8, 12
		static	int nPatLv[4]	= { 2, 8, 12, 0	};
		for( int i = 0; i < 3; i++ ) {
			if( m_nLevel < nPatLv[i] && nLevel >= nPatLv[i] ) {
#ifndef __AUTO_MAX_SKILL
				g_WndMng.PutString(prj.GetText(TID_GAME_PATTERNUP), NULL, prj.GetTextColor(TID_GAME_PATTERNUP));
#endif // __AUTO_MAX_SKILL
				break;
			}
			else if( m_nLevel >= nPatLv[2] )
				break;
		}

		if( TRUE == IsJobType( JTYPE_BASE ) )
		{
			if( nLevel == 15 )
				g_WndMng.PutString( prj.GetText( TID_EVE_LEVEL15 ), NULL, prj.GetTextColor( TID_EVE_LEVEL15 ) );

			static	int nNum	= prj.m_aJobSkillNum[JOB_VAGRANT];
		}
		if( m_nLevel < 20 && nLevel >= 20 )
		{
			g_WndMng.PutString( prj.GetText( TID_GAME_FLYLVLUP ), NULL, prj.GetTextColor( TID_GAME_FLYLVLUP ) );
			SetFlightLv( 1 );
		}
		else if( nLevel < 20 )
			SetFlightLv( 0 );
#endif	// __CLIENT
		m_nLevel	= nLevel;

		SetJobLevel( m_nLevel, m_nJob );

		m_nHitPoint = GetMaxHitPoint();
		m_nManaPoint = GetMaxManaPoint();
		m_nFatiguePoint = GetMaxFatiguePoint();

#ifdef __CLIENT
		if( IsPlayer() )
		{
			CWndWorld* pWndWorld = (CWndWorld*)g_WndMng.GetWndBase( APP_WORLD );
			
			if( pWndWorld ) 
			{
#if __VER >= 13 // __RENEW_CHARINFO
#ifdef __AUTO_STATS
				BOOL bAddCharButton = TRUE;
				if (g_pPlayer)
				{
					if (g_pPlayer->m_nAutoStat > 0 && g_pPlayer->m_nAutoStat < 5)
						bAddCharButton = FALSE;
			}

				if (bAddCharButton)
					pWndWorld->GetAdvMgr()->AddAdvButton(APP_CHARACTER3);
#else
				pWndWorld->GetAdvMgr()->AddAdvButton(APP_CHARACTER3);
#endif
#elif __VER >= 9 // __CSC_VER9_2
				pWndWorld->GetAdvMgr()->AddAdvButton(APP_CHARACTER2);
#else //__CSC_VER9_2
				pWndWorld->GetAdvMgr()->AddAdvButton(APP_CHARACTER);
#endif //__CSC_VER9_2
//			#if __VER < 12 // __MOD_TUTORIAL				
//				if( GetLevel() != 1 )
//					pWndWorld->m_pWndGuideSystem->GuideStart(FALSE);
//			#endif
#ifdef __NEW_CHANGE_JOB
#ifdef __CLIENT
				/*if( GetLevel() == MAX_JOB_LEVEL && IsBaseJob() )
				{
					if( !g_WndMng.GetApplet( APP_CHANGE_JOB_01 ) )
						g_WndMng.CreateApplet( APP_CHANGE_JOB_01 );
				}*/
				if (GetLevel() == (MAX_JOB_LEVEL + MAX_EXP_LEVEL) && IsExpert())
				{
					if (!g_WndMng.GetApplet(APP_CHANGE_JOB_02))
						g_WndMng.CreateApplet(APP_CHANGE_JOB_02);
				}
#ifdef __3RD_LEGEND16
				if (GetLevel() == MAX_LEGEND_LEVEL && IsHero()
#ifdef __NEWCLASS
					|| GetLevel() == MAX_3RD_LEGEND_LEVEL && IsLegendHero()
#endif // __NEWCLASS
					)
				{
					if (!g_WndMng.GetApplet(APP_CHANGE_JOB_03))
						g_WndMng.CreateApplet(APP_CHANGE_JOB_03);
				}
#endif // __3RD_LEGEND16				
#endif // __CLIENT
#endif // __NEW_CHANGE_JOB
				switch(GetLevel())
				{
//			#if __VER >= 12 // __MOD_TUTORIAL
//				case 15:
//					pWndWorld->m_pWndGuideSystem->GuideStart(GUIDE_CHANGEJOB);
//					break;						
//				case 20:
//					pWndWorld->m_pWndGuideSystem->GuideStart(GUIDE_FLIGHT_METHOD);
//					break;
//				case 40:
//					pWndWorld->m_pWndGuideSystem->GuideStart(GUIDE_APP_GUILD);
//					break;
//			#else
//				case 2:
//#if __VER >= 13 // __RENEW_CHARINFO
//					pWndWorld->m_pWndGuideSystem->SendGuideMessage(APP_CHARACTER3);
//#else if __VER >= 9 // __CSC_VER9_2
//					pWndWorld->m_pWndGuideSystem->SendGuideMessage(APP_CHARACTER2);
//#else //__CSC_VER9_2
//					pWndWorld->m_pWndGuideSystem->SendGuideMessage(APP_CHARACTER);
//#endif //__CSC_VER9_2
//					break;
//				case 3:
//					pWndWorld->m_pWndGuideSystem->SendGuideMessage(GUIDE_EVENT_BERSERKERMODE);
//					break;
//				case 4:
//					pWndWorld->m_pWndGuideSystem->SendGuideMessage(APP_SKILL_BEFOREJOB);
//					break;
//				case 8:
//					pWndWorld->m_pWndGuideSystem->SendGuideMessage(GUIDE_ESSENSE);
//					break;
//				case 16:
//					pWndWorld->m_pWndGuideSystem->SendGuideMessage(GUIDE_FLIGHT);
//					break;
//				case 15:
//					pWndWorld->m_pWndGuideSystem->SendGuideMessage(GUIDE_CHANGEJOB);
//					break;						
//				case 20:
//					pWndWorld->m_pWndGuideSystem->SendGuideMessage(GUIDE_FLIGHT_METHOD);
//					break;
//				case 49:
//					pWndWorld->m_pWndGuideSystem->SendGuideMessage(GUIDE_APP_GUILD);
//					break;
//			#endif
				}
			}
		}
#endif //__CLIENT		

		return TRUE;
	}
	else if( nLevel < m_nLevel )	// ·¹º§ ´Ù¿îÀÌ µÇ¾úÀ»¶§.
	{
		m_nLevel	= nLevel;
		if( nLevel < 20 )
			SetFlightLv( 0 );
	}

	return FALSE;
}


void CMover::SetEquipDstParam()
{
	if( IsPlayer() ) 
	{
		CItemElem* pItemElem;
		for( int i = 0; i < MAX_HUMAN_PARTS; i++ )
		{
			pItemElem = GetEquipItem( i ); //m_Inventory.GetAtId( m_adwEquipment[ i ] );
			if( pItemElem )
				SetDestParam( pItemElem->m_dwItemId, FALSE );	//don't send
		}
	}
}


/////////////////////////////////////////////////////////////////////////////// aaaaaaaaa
int CMover::SumEquipDefenseAbility( LONG* pnMin, LONG* pnMax )
{
	if( IsPlayer() )
	{
		int	nMin = 0, nMax = 0;
		CItemElem* pItemElem;
		ItemProp *pItemProp;

		for( int i = 0; i < MAX_HUMAN_PARTS; i++ )
		{
			pItemElem = GetEquipItem( i ); //m_Inventory.GetAtId( m_adwEquipment[ i ] );
			//if(pItem && !pItem->IsBreakableItem() && (pItem->m_nHitPoint == 1 || pItem->m_nHitPoint == 0))
			//	continue; IK2_ARMOR
			// IK_ARMOR¸¦ ÀÌÁ¦ Ã¼Å©ÇÏÁö ¾ÊÀ¸¹Ç·Î ¸Ó¸®³ª ÆÈÂîµî¿¡ µðÆæ½º°ªÀÌ µé¾î°¡Áö ¾Êµµ·Ï ÁÖÀÇÇÑ´Ù.
			// ¹«±âÀÇ ¾îºô¸®Æ¼´Â µðÆæ½º¿¡ Æ÷ÇÔµÇÁö ¾Ê´Â´Ù
			//if( pItemElem && pItemElem->GetProp()->dwItemKind2 < IK2_WEAPON_DIRECT && pItemElem->GetProp()->dwItemKind2 > IK2_WEAPON_GUN )  //&& ( pItemElem->m_nHitPoint > 1 || pItemElem->m_nHitPoint == -1) )
			if( pItemElem )
			{
				pItemProp = pItemElem->GetProp();

				if( pItemProp == NULL )
				{
					Error( "Parts Not Property = %d", i );
				}

				if( pItemProp )
				{
					if( pItemProp->dwItemKind2 == IK2_ARMOR || pItemProp->dwItemKind2 == IK2_ARMORETC )
					{
						int nOption = pItemElem->GetAbilityOption();
						int nOptionVal = 0;
						if( nOption > 0 ) 
							nOptionVal = (int)( pow( (float)( nOption ), 1.5f ) );
							
				#if __VER < 11 // __REMOVE_ENDURANCE
						if( pItemElem->m_nRepairNumber >= 100 )
							nOptionVal	+= prj.GetExpUpItem( pItemProp->dwItemKind3, 1 );
				#endif // __REMOVE_ENDURANCE						
						float f		= GetItemMultiplier( pItemElem );
						nMin	+= (int)( pItemProp->dwAbilityMin * f ) + nOptionVal;
						nMax	+= (int)( pItemProp->dwAbilityMax * f ) + nOptionVal;
#ifdef __WEAPON_RARITY
						WeaponRarity* nWeaponRarity = prj.m_nWeaponRarity.GetAt(pItemElem->GetWeaponRarity());
						if (nWeaponRarity && pItemElem->GetWeaponRarity() > 0)
						{
							nMin = (int)(nMin * nWeaponRarity->m_fAttackRate);
							nMax = (int)(nMax * nWeaponRarity->m_fAttackRate);
						}
#endif // __WEAPON_RARITY
					}
				}
			}
		}
		// ¸ðµç ÇÕ»êÀÌ ³¡³µ´Ù¸é °¢ ¿ä¼Ò¿¡ ¼öÁ¤Ä¡¸¦ Àû¿ëÇÑ´Ù.
		nMin = GetParam( DST_ABILITY_MIN, nMin );
		nMax = GetParam( DST_ABILITY_MAX, nMax );
		if( pnMin ) *pnMin = nMin;
		if( pnMax ) *pnMax = nMax;
		return ( ( nMin + nMax ) / 2 ); // ¸®ÅÏ °ªÀº Æò±Õ °ªÀÌ´Ù. ÆÇÁ¤½Ã¿¡´Â »ç¿ëÇÏÁö ¾Ê´Â´Ù. Ãâ·ÂÀÌ³ª ±âÅ¸ ¿ëµµ·Î »ç¿ëÇÑ´Ù.
	}
	else
	{
	}
	
	return 0;
}

void CMover::SumEquipAdjValue( int* pnAdjHitRate, int* pnAdjParray )
{
	*pnAdjHitRate = 0;
	*pnAdjParray = 0;

	CItemElem* pItemElem;
	for( int i = 0; i < MAX_HUMAN_PARTS; i++ )
	{
		pItemElem = GetEquipItem( i );
		if( pItemElem )  
		{
			if( pItemElem->GetProp() )
			{
				if( (int)pItemElem->GetProp()->nAdjHitRate > 0 )
					*pnAdjHitRate += pItemElem->GetProp()->nAdjHitRate;
				if( (int)pItemElem->GetProp()->dwParry > 0 )
					*pnAdjParray += pItemElem->GetProp()->dwParry;
			}
		}
	}
}

// ¾Èº¸ÀÌ´Â »óÅÂ
BOOL CMover::SetDarkCover( BOOL bApply, DWORD tmMaxTime )
{
	if( bApply )
	{
		if( GetAdjParam( DST_IMMUNITY ) & CHS_INVISIBILITY )	// Åõ¸íÈ­¿¡ ¸é¿ªÀÌ¶ó....±×·±°Íµµ ÀÖ³ª?
			return FALSE;	
		SetDestParam( DST_CHRSTATE, CHS_INVISIBILITY, NULL_CHGPARAM );
		m_wDarkCover =	(short)( (tmMaxTime / 1000.0f) * PROCESS_COUNT );
	} else
	{
		if( GetAdjParam( DST_CHRSTATE) & CHS_INVISIBILITY )
		{
			ResetDestParam( DST_CHRSTATE, CHS_INVISIBILITY, TRUE );		// ¾ÏÈæ»óÅÂÇØÁ¦
		}
		m_wDarkCover = 0;
	}

	return TRUE;
}

// ½ºÅÏ»óÅÂ·Î ¸¸µé±â
BOOL CMover::SetStun( BOOL bApply, DWORD tmMaxTime )
{
	if( bApply )
	{
		MoverProp *pMoverProp = GetProp();
		if( pMoverProp->dwClass == RANK_SUPER || pMoverProp->dwClass == RANK_MIDBOSS )
			return FALSE;			// ½´ÆÛ¸÷Àº ½ºÅÏ¿¡ ¾È°É¸°´Ù. ÀÌ·¸°Ô ÇÏÁö¸»°í ½ºÅÏ¿¡ ÀÌ¹ÃÀÌ µÇ°Ô ¼³Á¤ÇÏ´Â°Ô ÁÁ´Ù.

#ifdef __SLEEPING_FIX
		if (GetAdjParam(DST_IMMUNITY) & CHS_STUN || GetAdjParam(DST_IMMUNITY) & CHS_SLEEPING)
#else
		if( GetAdjParam( DST_IMMUNITY ) & CHS_STUN ) 
#endif
			return FALSE;		// µ¶¿¡ ¸é¿ª»óÅÂ´Ù.

		SetDestParam( DST_CHRSTATE, CHS_STUN, NULL_CHGPARAM, FALSE );
#ifdef __SLEEPING_FIX
		SetDestParam(DST_CHRSTATE, CHS_SLEEPING, NULL_CHGPARAM, FALSE);
#endif
		SendActMsg( OBJMSG_STUN );		// ½ºÅÏ »óÅÂ ½ÃÀÛ.
		m_wStunCnt = (short)( (tmMaxTime / 1000.0f) * PROCESS_COUNT );		// ¾ó¸¶µ¿¾ÈÀÌ³ª ½ºÅÏ»óÅÂ°¡ µÇ´À³Ä.
	}
	else
	{
#ifdef __SLEEPING_FIX
		if (GetAdjParam(DST_CHRSTATE) & CHS_STUN || GetAdjParam(DST_CHRSTATE) & CHS_SLEEPING)
		{
			ResetDestParam(DST_CHRSTATE, CHS_STUN, FALSE);
			ResetDestParam(DST_CHRSTATE, CHS_SLEEPING, FALSE);
		}
#else
		if( GetAdjParam( DST_CHRSTATE ) & CHS_STUN )	// ÀÌ°Å °Ë»ç¾ÈÇÏ¸é ¸Å¹ø Å¬¶ó·Î ResetDestParamÀ» ³¯¸°´Ù.
			ResetDestParam( DST_CHRSTATE, CHS_STUN, FALSE);	// ½ºÅÏ »óÅÂ ÇØÁ¦.
#endif
		m_wStunCnt = 0;
		m_dwFlag &= (~MVRF_NOACTION);				// ¾×¼Ç ±ÝÁö »óÅÂ·Î ÀüÈ¯.
	}

#ifdef __WORLDSERVER
	g_UserMng.AddSetStun( this, tmMaxTime );
#endif // Worldserver

	return TRUE;
}


// this¸¦ µ¶¿¡ °É¸®°Ô ÇÑ´Ù.
// idAttacker : °ø°ÝÀÚ(ÄÁÆ®·ÑÀÏ¼öµµ ÀÖ½¿)
// tmMaxTime : 1/1000ÃÊ ´ÜÀ§.
// tmUnit : ¸îÃÊ ¸¶´Ù µ¶µ¥¹ÌÁö°¡ ±ðÀÏ²¨³Ä.
// nDamage : µ¥¹ÌÁö·®
#ifdef __GAMEGUARD
BOOL CMover::SetPoison(BOOL bApply, OBJID idAttacker, DWORD tmMaxTime, DWORD tmUnit, int wDamage)
#else // __GAMEGUARD
BOOL CMover::SetPoison(BOOL bApply, OBJID idAttacker, DWORD tmMaxTime, DWORD tmUnit, short wDamage)
#endif // __GAMEGUARD
{
	if( bApply )
	{
		if( GetAdjParam( DST_IMMUNITY ) & CHS_POISON ) 
			return FALSE;		// µ¶¿¡ ¸é¿ª»óÅÂ´Ù.
		SetDestParam( DST_CHRSTATE, CHS_POISON, NULL_CHGPARAM );
		if( tmMaxTime == -1 )
			Error( "SetPoison : %s µ¶È¿°úÀÇ Áö¼Ó½Ã°£ÀÌ ÁöÁ¤µÇÁö ¾ÊÀ½", GetName() );
		if( tmUnit == -1 )
			Error( "SetPoison : %s µ¶È¿°úÀÇ tick ½Ã°£ÀÌ ÁöÁ¤µÇÁö ¾ÊÀ½", GetName() );
		if( wDamage == -1 )
			Error( "SetPoison : %s µ¶È¿°úÀÇ Æ½´ç µ¥¹ÌÁö°¡ ÁöÁ¤µÇÁö ¾ÊÀ½", GetName() );
		
		m_wPoisonCnt = (short)( (tmMaxTime / 1000.0f) * PROCESS_COUNT );			// 1/1000
		m_wPoisonDamage = wDamage;
		m_tmPoisonUnit = tmUnit;
		m_idPoisonAttacker = idAttacker;
	} else
	{
		if( GetAdjParam( DST_CHRSTATE) & CHS_POISON )
			ResetDestParam( DST_CHRSTATE, CHS_POISON, TRUE );	// µ¶»óÅÂ ÇØÁ¦
		m_wPoisonCnt = 0;
		m_wPoisonDamage = 0;
		m_tmPoisonUnit = 0;
	}

	return TRUE;
}

// this¸¦ ¾ÏÈæ»óÅÂ¿¡ ºüÁö°Ô ÇÑ´Ù
// tmMaxTime : ¾ÏÈæ Áö¼Ó½Ã°£(1/1000)
// nAdjHitRate : Áö¼Ó½Ã°£µ¿¾È ¼öÁ¤µÉ ¸íÁß·ü
// bApply : Àû¿ë/ÇØÁ¦
BOOL CMover::SetDark( BOOL bApply, DWORD tmMaxTime, int nAdjHitRate )
{
	if( bApply )
	{
		if( GetAdjParam( DST_IMMUNITY ) & CHS_DARK ) 
			return FALSE;		// ¾ÏÈæ¿¡ ¸é¿ª»óÅÂ´Ù.
		SetDestParam( DST_CHRSTATE, CHS_DARK, NULL_CHGPARAM );
		SetDestParam( DST_ADJ_HITRATE, nAdjHitRate, NULL_CHGPARAM );
		m_wDarkCnt = (short)( (tmMaxTime / 1000.0f) * PROCESS_COUNT );
		if( nAdjHitRate == -1 )
			Error( "SetDark : %s ¾îµÒÈ¿°úÀÇ ¸íÁß·ü ¼öÁ¤Ä¡°¡ ÁöÁ¤µÇÁö ¾ÊÀ½", GetName() );
		m_wDarkVal = nAdjHitRate;
	} else
	{
		if( GetAdjParam( DST_CHRSTATE) & CHS_DARK )
		{
			ResetDestParam( DST_CHRSTATE, CHS_DARK, TRUE );		// ¾ÏÈæ»óÅÂÇØÁ¦
			ResetDestParam( DST_ADJ_HITRATE, m_wDarkVal, TRUE );	// ¾ÏÈæµ¿¾È ¼öÁ¤µÆ´ø ¸íÁß·ü ÇØÁ¦
//			if( m_wDarkCnt >= 0 )
//				Error( "SetDark : %d", m_wDarkVal );
		}
		m_wDarkCnt = 0;
		m_wDarkVal = 0;
	}
	return TRUE;
}

// this¸¦ ÃâÇ÷À» ÀÏÀ¸Å²´Ù. µ¶°ú ºñ½Á.
// tmMaxTime : 1/1000ÃÊ ´ÜÀ§.
// tmUnit : ¸îÃÊ ¸¶´Ù µ¥¹ÌÁö°¡ ±ðÀÏ²¨³Ä.
// nDamage : µ¥¹ÌÁö·®
#ifdef __GAMEGUARD
BOOL	CMover::SetBleeding(BOOL bApply, OBJID idAttacker, DWORD tmMaxTime, DWORD tmUnit, int wDamage)
#else // __GAMEGUARD
BOOL	CMover::SetBleeding(BOOL bApply, OBJID idAttacker, DWORD tmMaxTime, DWORD tmUnit, short wDamage)
#endif // __GAMEGUARD
{
	if( bApply )
	{
		if( GetAdjParam( DST_IMMUNITY ) & CHS_BLEEDING ) return FALSE;		// ÃâÇ÷¿¡ ¸é¿ª»óÅÂ´Ù.
		
		SetDestParam( DST_CHRSTATE, CHS_BLEEDING, NULL_CHGPARAM );
		if( tmMaxTime == -1 )
			Error( "SetBleeding : %s ÃâÇ÷È¿°úÀÇ Áö¼Ó½Ã°£ÀÌ ÁöÁ¤µÇÁö ¾ÊÀ½", GetName() );
		if( tmUnit == -1 )
			Error( "SetBleeding : %s ÃâÇ÷È¿°úÀÇ tick ½Ã°£ÀÌ ÁöÁ¤µÇÁö ¾ÊÀ½", GetName() );
		if( wDamage == -1 )
			Error( "SetBleeding : %s ÃâÇ÷È¿°úÀÇ Æ½´ç µ¥¹ÌÁö°¡ ÁöÁ¤µÇÁö ¾ÊÀ½", GetName() );
		
		m_wBleedingCnt = (short)( (tmMaxTime / 1000.0f) * PROCESS_COUNT );			// 1/1000
		m_wBleedingDamage = wDamage;
		m_tmBleedingUnit = tmUnit;
		m_idBleedingAttacker = idAttacker;
	} else
	{
		if( GetAdjParam( DST_CHRSTATE) & CHS_BLEEDING )
			ResetDestParam( DST_CHRSTATE, CHS_BLEEDING, TRUE );	// µ¶»óÅÂ ÇØÁ¦
		m_wBleedingCnt = 0;
		m_wBleedingDamage = 0;
		m_tmBleedingUnit = 0;
	}
	return TRUE;
}

// dwState¸¦ ÇØÁ¦ÇÔ
// CHS_ALLÀ» ÇÏ¸é ¸ðµç µð¹öÇÁ.
void CMover::RemoveDebuff( DWORD dwState )
{
	// ½ºÅ³·Î °É¸°°Ç ÀÌ°É·Î ÇØÁ¦ÇØ¾ßÇÏ°í
	RemoveChrStateBuffs( dwState );
	// ½ºÅ³ÀÌ ¾Æ´Ñ ¾ÆÀÌÅÛ°°Àº°É·Î »óÅÂ¸¸ °É¸°°Ç ÀÌ°É·Î Ç®¾î¾ß ÇÑ´Ù.
	if( dwState & CHS_DARK )
		SetDark( FALSE );
	if( dwState & CHS_POISON )
		SetPoison( FALSE );
#ifdef __SLEEPING_FIX
	if (dwState & CHS_STUN || dwState & CHS_SLEEPING)
#else
	if( dwState & CHS_STUN )
#endif
		SetStun( FALSE );
#if __VER >= 10	// 
	if( dwState & CHS_BLEEDING )
		SetBleeding( FALSE );
	
	#if __VER >= 11 // __MA_VER11_06				// È®À²½ºÅ³ È¿°ú¼öÁ¤ world,neuz
#if __VER >= 18
	if (dwState & DST_DEBUFF_ALL_CLEAR)
#else
	if( dwState & CHS_DEBUFFALL )
#endif
	{
		RemoveDstParamBuffs( DST_SPEED );
		RemoveDstParamBuffs( DST_CHR_CHANCEPOISON );
		RemoveDstParamBuffs( DST_CHR_CHANCESTUN );
		RemoveDstParamBuffs( DST_CHR_CHANCEBLEEDING );
	}
	#endif // __MA_VER11_06				// È®À²½ºÅ³ È¿°ú¼öÁ¤ world,neuz

#endif	//

	// ÀÌ°Å ¾È¿¡¼­ ResetÀ» È£ÃâÇÑ´Ù.
	SetDestParam( DST_CURECHR, dwState, NULL_CHGPARAM );
}

// this¿¡°Ô °É¸° ¹öÇÁ¸¦ 1°³ ¾ø¾Ø´Ù.
void CMover::RemoveBuffOne( DWORD dwSkill )
{
#ifdef __BUFF_1107
	m_buffs.RemoveBuffs( RBF_ONCE | RBF_GOODSKILL, 0 );
#else	// __BUFF_1107
	m_SkillState.RemoveOneSkillBuff();		// ÀÌ·Î¿î¹öÇÁ½ºÅ³ ÇÏ³ª¸¦ Á¦°Å ÇÑ´Ù.
#endif	// __BUFF_1107
}	

void CMover::RemoveBuffAll( void )
{
#ifdef __BUFF_1107
	m_buffs.RemoveBuffs( RBF_GOODSKILL, 0 );
#else	// __BUFF_1107
	m_SkillState.RemoveAllSkillBuff();		// ÀÌ·Î¿î¹öÇÁ½ºÅ³À» ¸ðµÎ Ã£¾Æ »èÁ¦ ÇÑ´Ù.
#endif	// __BUFF_1107
}

#ifdef __ORIGIN_CARD_SYSTEM
int CMover::getCollectedCard(int nKind)
{
	int nCollectedCard = 0;

	for (int n = 0; n < MAX_CARD_ALBUM; n++)
	{
		CardProp* pPropCard = prj.GetCardProp(m_aCardAlbum[n].dwCardID);

		if (pPropCard && pPropCard->dwRarety == nKind)
			nCollectedCard += m_aCardAlbum[n].nNum;
	}

	return nCollectedCard;
}

int CMover::getFilledPage()
{
	int nCardPerPage = 18;
	int	nMaxPage = (int)ceil(MAX_CARD_ALBUM / 18.0f);
	int nID;
	int nCardLastPage = MAX_CARD_ALBUM - ((nMaxPage - 1) * nCardPerPage);
	int nFilledPage = 0;
	int nCount = 0;

	for (int i = 1; i <= nMaxPage; i++)
	{
		nCount = 0;

		for (int n = 0; n < nCardPerPage; n++)
		{
			nID = n + (nCardPerPage * i) - nCardPerPage;

			if (nID < MAX_CARD_ALBUM)
			{
				if (m_aCardAlbum[nID].nNum > 0)
					nCount++;
			}
		}

		if (i < nMaxPage && nCount == nCardPerPage)
			nFilledPage++;
		else if (i == nMaxPage && nCount == nCardLastPage)
			nFilledPage++;
	}

	return nFilledPage * 5;
}

void CMover::SetDestParamCard(int nCardId)
{
	if (nCardId != 0)
	{
		CardProp* pPropCard = prj.GetCardProp(nCardId);
		if (pPropCard) {
			SetDestParam(DST_STR, pPropCard->nStr, NULL_CHGPARAM, TRUE);
			SetDestParam(DST_STA, pPropCard->nSta, NULL_CHGPARAM, TRUE);
			SetDestParam(DST_DEX, pPropCard->nDex, NULL_CHGPARAM, TRUE);
			SetDestParam(DST_INT, pPropCard->nInt, NULL_CHGPARAM, TRUE);
		}
	}
}

void CMover::ResetDestParamCard(int nCardId)
{
	if (nCardId != 0)
	{
		CardProp* pPropCard = prj.GetCardProp(nCardId);
		if (pPropCard) {
			ResetDestParam(DST_STR, pPropCard->nStr, TRUE);
			ResetDestParam(DST_STA, pPropCard->nSta, TRUE);
			ResetDestParam(DST_DEX, pPropCard->nDex, TRUE);
			ResetDestParam(DST_INT, pPropCard->nInt, TRUE);
		}
	}
}

BOOL CMover::CheckCardAlbum(CItemElem* pItemElem)
{
	CardProp* pPropCard = prj.GetCardProp(pItemElem->m_dwItemId);
	if (pPropCard)
	{
		int nIdx = GetCardInvIdx(pPropCard);

		if ((m_aCardAlbum[nIdx].nNum + pItemElem->m_nItemNum) < 100)
			return TRUE;
		else
			return FALSE;
	}
	else
		return FALSE;
}

void CMover::AddCardToAlbum(CItemElem* pItemElem)
{
#ifdef __WORLDSERVER
	CardProp* pPropCard = prj.GetCardProp(pItemElem->m_dwItemId);
	if (pPropCard) {
		int nIdx = GetCardInvIdx(pPropCard);

		m_aCardAlbum[nIdx].nNum += pItemElem->m_nItemNum;

		pItemElem->m_nItemNum = 1;

		((CUser*)this)->CardAlbumUpdate(m_aCardAlbum[nIdx].nNum, nIdx);
	}
#endif // __WORLDSERVER
}

void CMover::RemoveCardToAlbum(int nCardIdx)
{
#ifdef __WORLDSERVER
	m_aCardAlbum[nCardIdx].nNum--;
	((CUser*)this)->CardAlbumUpdate(m_aCardAlbum[nCardIdx].nNum, nCardIdx);
#endif // __WORLDSERVER
}

void CMover::AddCardToInv(int nCardSlot, int nCardID)
{
#ifdef __WORLDSERVER
	SetDestParamCard(nCardID);
	m_aCardInventory[nCardSlot].dwCardID = nCardID;
	((CUser*)this)->CardInvUpdate(nCardID, nCardSlot);
#endif // __WORLDSERVER
}

void CMover::RemoveCardToInv(int nCardSlot)
{
#ifdef __WORLDSERVER
	ResetDestParamCard(m_aCardInventory[nCardSlot].dwCardID);
	m_aCardInventory[nCardSlot].dwCardID = 0;
	((CUser*)this)->CardInvUpdate(0, nCardSlot);
#endif // __WORLDSERVER
}
#endif // __ORIGIN_CARD_SYSTEM

///////////////////////////////////////////////////////////////////////////////
// 
// µ¶, ¾ÏÈæµî Ãß°¡´É·ÂÄ¡ÀÇ ¼¼ÆÃÀº ÀÌ°É·Î ÇÏÀÚ.
void CMover::SetDestParam( int nIdx, ItemProp *pProp, BOOL bSend )
{
	SetDestParam( pProp->dwDestParam[nIdx], pProp->nAdjParamVal[nIdx], pProp->dwChgParamVal[nIdx], bSend );
}

void CMover::ResetDestParam( int nIdx, ItemProp *pProp, BOOL bSend )
{
	ResetDestParam( pProp->dwDestParam[nIdx], pProp->nAdjParamVal[nIdx], bSend );
}

// ¸ñÇ¥ ÆÄ¶ó¹ÌÅÍ¸¦ ¼ÂÇÑ´Ù.
void CMover::SetDestParam( int nItemIdx, BOOL bSend )
{
	ItemProp* pItemProp = prj.GetItemProp( nItemIdx );

#ifdef __SECURITY_FIXES
	if (!pItemProp)
		return;
#endif // __SECURITY_FIXES

	if( pItemProp->dwDestParam1 != -1 )
		SetDestParam( pItemProp->dwDestParam1, pItemProp->nAdjParamVal1, pItemProp->dwChgParamVal1, bSend );
	if( pItemProp->dwDestParam2 != -1 )
		SetDestParam( pItemProp->dwDestParam2, pItemProp->nAdjParamVal2, pItemProp->dwChgParamVal2, bSend );
#ifdef __PROP_0827
	if( pItemProp->dwDestParam3 != -1 )
		SetDestParam( pItemProp->dwDestParam3, pItemProp->nAdjParamVal3, pItemProp->dwChgParamVal3, bSend );
#endif	// __PROP_0827
#if __VER >= 18
	if (pItemProp->dwDestParam4 != -1)
		SetDestParam(pItemProp->dwDestParam4, pItemProp->nAdjParamVal4, pItemProp->dwChgParamVal4, bSend);
	if (pItemProp->dwDestParam5 != -1)
		SetDestParam(pItemProp->dwDestParam5, pItemProp->nAdjParamVal5, pItemProp->dwChgParamVal5, bSend);
	if (pItemProp->dwDestParam6 != -1)
		SetDestParam(pItemProp->dwDestParam6, pItemProp->nAdjParamVal6, pItemProp->dwChgParamVal6, bSend);
#endif
}

//--------------------------------------------------------------------------
//
// ¸ñÇ¥ ÆÄ¶ó¸ÞÅ¸¸¦ ¼ÂÇÑ´Ù.
#ifdef __NO_HP_DMG_LIMIT
void CMover::SetDestParam(int nDstParameter, long long nAdjParameterValue, int nChgParameterValue, BOOL bSend)
#else
void CMover::SetDestParam(int nDstParameter, int nAdjParameterValue, int nChgParameterValue, BOOL bSend)
#endif
{
	BOOL fSuccess	= FALSE;

#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	if( (nDstParameter < 0 ) && ( nDstParameter != DST_ADJDEF_RATE && nDstParameter != DST_ADJDEF ) )
		return;
#else
	if( nDstParameter < 0 )
		return;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	
	// HP, MPµîÀº SetPointParamÀ¸·Î Ã³¸®ÇÑ´Ù. ±Ùµð SetDestParam ÇÏ³ª·Î ÅëÀÏ½ÃÄ×À¸¸é ³´Áö ¾ÊÀ»±î?
	switch( nDstParameter )
	{
#ifdef __WORLDSERVER
	case DST_HP:
		{
			if( nAdjParameterValue == -1 )
				SetPointParam( nDstParameter, GetMaxHitPoint() );
			else
				SetPointParam( nDstParameter, GetHitPoint() + nAdjParameterValue );
		}
		return;
	case DST_MP:
		{
			if( nAdjParameterValue == -1 )
				SetPointParam( nDstParameter, GetMaxManaPoint() );
			else
				SetPointParam( nDstParameter, GetManaPoint() + nAdjParameterValue );
			
		}
		return;
	case DST_FP:
		{
			if( nAdjParameterValue == -1 )
				SetPointParam( nDstParameter, GetMaxFatiguePoint() );
			else
				SetPointParam( nDstParameter, GetFatiguePoint() + nAdjParameterValue );
		}
		return;
#else // __WORLDSERVER
	case DST_HP:	SetPointParam( nDstParameter, GetHitPoint() + nAdjParameterValue );	return;
	case DST_MP:	SetPointParam( nDstParameter, GetManaPoint() + nAdjParameterValue );	return;
	case DST_FP:	SetPointParam( nDstParameter, GetFatiguePoint() + nAdjParameterValue );	return;
#endif // __WORLDSERVER
	case DST_GOLD:	
#ifdef __PERIN_BUY_BUG	// chipi_091219 Ãß°¡
		Error( "SetDestParam( DST_GOLD ) - [User:%s(%07d)], [Value:%d]", static_cast<CUser*>(this)->GetName(), static_cast<CUser*>(this)->m_idPlayer, nAdjParameterValue );
		return;
#endif // __PERIN_BUY_BUG

		if( AddGold( nAdjParameterValue ) == FALSE )	
			SetGold( 0 );		// underflowÀÌ¸é 0·Î ¸¸µç´Ù. ÀÌÀüÄÚµå¿Í È£È¯µÇ°Ô ÇÑ´Ù. ¹º°¡ ÂòÂò 
		return;

	case DST_RESIST_ALL:
		SetDestParam( DST_RESIST_ELECTRICITY,	nAdjParameterValue, nChgParameterValue, bSend );
		SetDestParam( DST_RESIST_FIRE,			nAdjParameterValue, nChgParameterValue, bSend );
		SetDestParam( DST_RESIST_WIND,			nAdjParameterValue, nChgParameterValue, bSend );
		SetDestParam( DST_RESIST_WATER,			nAdjParameterValue, nChgParameterValue, bSend );
		SetDestParam( DST_RESIST_EARTH,			nAdjParameterValue, nChgParameterValue, bSend );
		return;
	case DST_STAT_ALLUP:
		SetDestParam( DST_STR,	nAdjParameterValue, nChgParameterValue, bSend );
		SetDestParam( DST_DEX,	nAdjParameterValue, nChgParameterValue, bSend );
		SetDestParam( DST_INT,	nAdjParameterValue, nChgParameterValue, bSend );
		SetDestParam( DST_STA,	nAdjParameterValue, nChgParameterValue, bSend );
		return;
	case DST_HPDMG_UP:	// DST_HP_MAX + DST_CHR_DMG 
		SetDestParam( DST_HP_MAX, nAdjParameterValue, nChgParameterValue, bSend );
		SetDestParam( DST_CHR_DMG, nAdjParameterValue, nChgParameterValue, bSend );
		return;
	case DST_DEFHITRATE_DOWN: // DST_ADJDEF + DST_ADJ_HITRATE
		SetDestParam( DST_ADJDEF, nAdjParameterValue, nChgParameterValue, bSend );
		SetDestParam( DST_ADJ_HITRATE, nAdjParameterValue, nChgParameterValue, bSend );
		return;
	case DST_LOCOMOTION:
		SetDestParam( DST_SPEED,	nAdjParameterValue, nChgParameterValue, bSend );
		SetDestParam( DST_JUMPING,	( nAdjParameterValue * 3 ), nChgParameterValue, bSend );
		return;
#ifdef __NEWWPN1024
	case DST_MASTRY_ALL:
		SetDestParam( DST_MASTRY_EARTH,	nAdjParameterValue, nChgParameterValue, bSend );
		SetDestParam( DST_MASTRY_FIRE,	nAdjParameterValue, nChgParameterValue, bSend );
		SetDestParam( DST_MASTRY_WATER,	nAdjParameterValue, nChgParameterValue, bSend );
		SetDestParam( DST_MASTRY_ELECTRICITY,	nAdjParameterValue, nChgParameterValue, bSend );
		SetDestParam( DST_MASTRY_WIND,	nAdjParameterValue, nChgParameterValue, bSend );
		return;
#endif	// __NEWWPN1024

	case DST_HP_RECOVERY_RATE:
		{
#ifdef __NO_HP_DMG_LIMIT
		long long nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		long long nRecv = (((long long)nMax * (nAdjParameterValue / 100.0f)));
#else
		int nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		int nRecv = (int)((nMax * (nAdjParameterValue / 100.0f)));
#endif
			SetDestParam( DST_HP_RECOVERY, nRecv, NULL_CHGPARAM, bSend );
		}
		return;
	case DST_MP_RECOVERY_RATE:
		{
			int nMax	= GetMaxOriginManaPoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			int nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			SetDestParam( DST_MP_RECOVERY, nRecv, NULL_CHGPARAM, bSend );
		}
		return;
	case DST_FP_RECOVERY_RATE:
		{
			int nMax	= GetMaxOriginFatiguePoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			int nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			SetDestParam( DST_FP_RECOVERY, nRecv, NULL_CHGPARAM, bSend );
		}
		return;
	case DST_ALL_RECOVERY:
		{
			// HP
			SetDestParam( DST_HP_RECOVERY, nAdjParameterValue, NULL_CHGPARAM, bSend );
			// MP
			SetDestParam( DST_MP_RECOVERY, nAdjParameterValue, NULL_CHGPARAM, bSend );
			// FP
			SetDestParam( DST_FP_RECOVERY, nAdjParameterValue, NULL_CHGPARAM, bSend );
		}
		return;
	case DST_ALL_RECOVERY_RATE:
		{
			// HP
#ifdef __NO_HP_DMG_LIMIT
		long long nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		long long nRecv = (((long long)nMax * (nAdjParameterValue / 100.0f)));
#else
		int nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		int nRecv = (int)((nMax * (nAdjParameterValue / 100.0f)));
#endif
			SetDestParam( DST_HP_RECOVERY, nRecv, NULL_CHGPARAM, bSend );

			// MP
			nMax	= GetMaxOriginManaPoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			SetDestParam( DST_MP_RECOVERY, nRecv, NULL_CHGPARAM, bSend );

			// FP
			nMax	= GetMaxOriginFatiguePoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			SetDestParam( DST_FP_RECOVERY, nRecv, NULL_CHGPARAM, bSend );
		}
		return;
	case DST_KILL_ALL:	
		{
			// HP
			SetDestParam( DST_KILL_HP, nAdjParameterValue, NULL_CHGPARAM, bSend );
			// MP
			SetDestParam( DST_KILL_MP, nAdjParameterValue, NULL_CHGPARAM, bSend );
			// FP
			SetDestParam( DST_KILL_FP, nAdjParameterValue, NULL_CHGPARAM, bSend );
		}
		return;
	case DST_KILL_HP_RATE:
		{
#ifdef __NO_HP_DMG_LIMIT
		long long nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		long long nRecv = (((long long)nMax * (nAdjParameterValue / 100.0f)));
#else

		int nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		int nRecv = (int)((nMax * (nAdjParameterValue / 100.0f)));
#endif
			SetDestParam( DST_KILL_HP, nRecv, NULL_CHGPARAM, bSend );
		}
		return;
	case DST_KILL_MP_RATE:
		{
			int nMax	= GetMaxOriginManaPoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			int nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			SetDestParam( DST_KILL_MP, nRecv, NULL_CHGPARAM, bSend );
		}
		return;
	case DST_KILL_FP_RATE:
		{
			int nMax	= GetMaxOriginFatiguePoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			int nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			SetDestParam( DST_KILL_FP, nRecv, NULL_CHGPARAM, bSend );
		}
		return;
	case DST_KILL_ALL_RATE:
		{
			// HP
#ifdef __NO_HP_DMG_LIMIT
		long long nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		long long nRecv = (((long long)nMax * (nAdjParameterValue / 100.0f)));
#else
		int nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		int nRecv = (int)((nMax * (nAdjParameterValue / 100.0f)));
#endif
			SetDestParam( DST_KILL_HP, nRecv, NULL_CHGPARAM, bSend );
			
			// MP
			nMax	= GetMaxOriginManaPoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			SetDestParam( DST_KILL_MP, nRecv, NULL_CHGPARAM, bSend );
			
			// FP
			nMax	= GetMaxOriginFatiguePoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			SetDestParam( DST_KILL_FP, nRecv, NULL_CHGPARAM, bSend );
		}
		return;
	case DST_ALL_DEC_RATE:
		{
			SetDestParam( DST_MP_DEC_RATE, nAdjParameterValue, NULL_CHGPARAM, bSend );
			SetDestParam( DST_FP_DEC_RATE, nAdjParameterValue, NULL_CHGPARAM, bSend );
		}
		return;
#ifdef __DST_COLLECTOR_TIME
#ifdef __CLIENT
	case DST_COLLECTOR_TIME:
	{
		if (m_nMaxCltTime)
		{
			m_nMaxCltTime = (int)(m_nMaxCltTime * (100.f - nAdjParameterValue) / 100.0f);
		}
		break;
	}
#endif // __CLIENT
#endif // __DST_COLLECTOR_TIME
	} // switch

	// ÀÌ °Ë»ç¸¦ ¿Ö À§¿¡´Ù ¾È³Ö°í ¿©±â´Ù ³Ö¾ú³Ä¸é
	// DST_GOLD, PXP, RESIST_ALL°°Àº°æ¿ì´Â MAX_ADJPARAMARYº¸´Ù ´õ Å«°ªÀ» »ç¿ëÇÑ´Ù. 
	// ±×·¡¼­ ±×·±°ÍµéÀº À§¿¡¼­ Ã³¸®ÇÏ°í ¹Ù·Î ¸®ÅÏÇÏ°í
	// ÀÏ¹ÝÀûÀÎ°Íµé¸¸ ÀÌÂÊÀ¸·Î ¿Â´Ù.
	if( nDstParameter >= MAX_ADJPARAMARY)
		return;
	
	if( nAdjParameterValue != 0 )	// 0ÀÌ µé¾î¿Â°Íµµ Àß¸øµÈ°Å´Ï±î °æ°í¸¦ ³»¾ß ÇÏÁö ¾ÊÀ»±î ½Í´Ù.
	{
		fSuccess	= TRUE;

		switch( nDstParameter )
		{
		case DST_CHRSTATE:		// »óÅÂº¯°æÀÇ °æ¿ì´Â
		case DST_IMMUNITY:
			if( nAdjParameterValue != NULL_ID )
			{
				if( nAdjParameterValue == 0xffffffff )
				{
					Error( "SetDestParam : Adj == -1, %s", GetName() );
					return;
				}
				m_adjParamAry[nDstParameter] |= nAdjParameterValue;		// ºñÆ®·Î ¿Â¿ÀÇÁ µÈ´Ù.
			} else
				fSuccess = FALSE;
			break;
		case DST_CURECHR:		// »óÅÂÇØÁ¦
			ResetDestParam( DST_CHRSTATE, nAdjParameterValue, bSend );
			return;
		case DST_REFLECT_DAMAGE:
			m_adjParamAry[nDstParameter] += nAdjParameterValue;		// µ¥¹ÌÁöÀÇ ¸î%¸¦ µ¹·ÁÁÖ´Â°¡?
			m_chgParamAry[nDstParameter] = nChgParameterValue;		// ¸î%ÀÇ È®·ü·Î ¹ßµ¿µÇ´Â°¡?
			break;
		case DST_CHR_CHANCEBLEEDING:
		case DST_CHR_CHANCESTEALHP:
		case DST_CHR_CHANCEPOISON:
		case DST_CHR_CHANCEDARK:
		case DST_CHR_CHANCESTUN:
		case DST_AUTOHP:
			m_adjParamAry[nDstParameter] += nAdjParameterValue;		// Âù½º È®·ü.	// %¹Ì¸¸À¸·Î È¸º¹µÇ°Ô ÇÒ²¨³Ä.
			m_chgParamAry[nDstParameter] = nChgParameterValue;		// Âù½º°¡ °É·ÈÀ»¶§ Áö¼Ó½Ã°£		// %HP°¡ È¸º¹µÉ²¨³Ä.
			break;
#if __VER >= 9	// __PET_0410
		case DST_HEAL:
			m_nHealCnt	= (short)( PROCESS_COUNT * 6.0f );		// ÄðÅ¸ÀÓ 6ÃÊ
			m_adjParamAry[nDstParameter]	+= nAdjParameterValue;	
			break;
#endif	// __PET_0410
		default:
		{
			m_adjParamAry[nDstParameter] += nAdjParameterValue;

#if defined (__RECORD_BOOK) && defined (__WORLDSERVER)
			if (IsPlayer())
			{
				switch (nDstParameter)
				{
				case DST_STR: CRecordBook::GetInstance()->AddPlayerRecord(this, RecordType::STR, GetStr(), false); break;
				case DST_STA:
				{
					CRecordBook::GetInstance()->AddPlayerRecord(this, RecordType::STA, GetSta(), false);
					CRecordBook::GetInstance()->AddPlayerRecord(this, RecordType::HP, GetMaxHitPoint(), false);
				}
				break;
				case DST_DEX: CRecordBook::GetInstance()->AddPlayerRecord(this, RecordType::DEX, GetDex(), false); break;
				case DST_INT:
				{
					CRecordBook::GetInstance()->AddPlayerRecord(this, RecordType::INTT, GetInt(), false);
				}
				break;
				case DST_CRITICAL_BONUS: CRecordBook::GetInstance()->AddPlayerRecord(this, RecordType::ADOCH, GetParam(DST_CRITICAL_BONUS, 0), false); break;
				case DST_HP_MAX:
				case DST_HP_MAX_RATE: CRecordBook::GetInstance()->AddPlayerRecord(this, RecordType::HP, GetMaxHitPoint(), false); break;
				default: break;
				}
			}
#endif
		}
		break;
		}
	}

	else if( nChgParameterValue != 0x7FFFFFFF ) 
	{
		fSuccess	= TRUE;

		// ëÅ
		if( nDstParameter == DST_SPEED )
		{
			if( m_chgParamAry[nDstParameter] == 0x7FFFFFFF )
				m_chgParamAry[nDstParameter]	= 0;
			m_chgParamAry[nDstParameter]++;
		}
		else
		{
			m_chgParamAry[nDstParameter] = nChgParameterValue;	// °íÁ¤µÈ °ª.
		}
	}
#ifdef __WORLDSERVER
	if( TRUE == ( fSuccess & bSend ) ) {
		g_UserMng.AddSetDestParam( this, nDstParameter, nAdjParameterValue, nChgParameterValue );
	}
#endif	// __WORLDSERVER
}

//
// ¸ñÇ¥ ÆÄ¶ó¸ÞÅ¸¸¦ ¸®¼ÂÇÑ´Ù.
//
void CMover::ResetDestParam( int nDstParameter, int nAdjParameterValue, BOOL fSend )
{
	switch( nDstParameter )
	{
	case DST_RESIST_ALL:
		ResetDestParam( DST_RESIST_ELECTRICITY,	nAdjParameterValue, TRUE );
		ResetDestParam( DST_RESIST_FIRE,		nAdjParameterValue, TRUE );
		ResetDestParam( DST_RESIST_WIND,		nAdjParameterValue, TRUE );
		ResetDestParam( DST_RESIST_WATER,		nAdjParameterValue, TRUE );
		ResetDestParam( DST_RESIST_EARTH,		nAdjParameterValue, TRUE );
		return;
	case DST_STAT_ALLUP:
		ResetDestParam( DST_STR,	nAdjParameterValue, TRUE );
		ResetDestParam( DST_DEX,	nAdjParameterValue, TRUE );
		ResetDestParam( DST_INT,	nAdjParameterValue, TRUE );
		ResetDestParam( DST_STA,	nAdjParameterValue, TRUE );
		return;
	case DST_HPDMG_UP:	// DST_HP_MAX + DST_CHR_DMG 
		ResetDestParam( DST_HP_MAX, nAdjParameterValue, TRUE );
		ResetDestParam( DST_CHR_DMG, nAdjParameterValue, TRUE );
		return;
	case DST_DEFHITRATE_DOWN: // DST_ADJDEF + DST_ADJ_HITRATE
		ResetDestParam( DST_ADJDEF, nAdjParameterValue, TRUE );
		ResetDestParam( DST_ADJ_HITRATE, nAdjParameterValue, TRUE );
		return;
	case DST_LOCOMOTION:
		ResetDestParam( DST_SPEED,	nAdjParameterValue, TRUE );
		ResetDestParam( DST_JUMPING,	( nAdjParameterValue * 3 ), TRUE );
		return;
#ifdef __NEWWPN1024
	case DST_MASTRY_ALL:
		ResetDestParam( DST_MASTRY_EARTH,	nAdjParameterValue, TRUE );
		ResetDestParam( DST_MASTRY_FIRE,	nAdjParameterValue, TRUE );
		ResetDestParam( DST_MASTRY_WATER,	nAdjParameterValue, TRUE );
		ResetDestParam( DST_MASTRY_ELECTRICITY,	nAdjParameterValue, TRUE );
		ResetDestParam( DST_MASTRY_WIND,	nAdjParameterValue, TRUE );
		return;
#endif	// __NEWWPN1024

	case DST_HP_RECOVERY_RATE:
		{
#ifdef __NO_HP_DMG_LIMIT
		long long nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		long long int nRecv = (long long)((nMax * (nAdjParameterValue / 100.0f)));
#else
		int nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		int nRecv = (int)((nMax * (nAdjParameterValue / 100.0f)));
#endif
			ResetDestParam( DST_HP_RECOVERY, nRecv, TRUE );
		}
		return;
	case DST_MP_RECOVERY_RATE:
		{
			int nMax	= GetMaxOriginManaPoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			int nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			ResetDestParam( DST_MP_RECOVERY, nRecv, TRUE );
		}
		return;
	case DST_FP_RECOVERY_RATE:
		{
			int nMax	= GetMaxOriginFatiguePoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			int nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			ResetDestParam( DST_FP_RECOVERY, nRecv, TRUE );
		}
		return;
	case DST_ALL_RECOVERY:
		{
			// HP
			ResetDestParam( DST_HP_RECOVERY, nAdjParameterValue, TRUE );
			// MP
			ResetDestParam( DST_MP_RECOVERY, nAdjParameterValue, TRUE );
			// FP
			ResetDestParam( DST_FP_RECOVERY, nAdjParameterValue, TRUE );
		}
		return;
	case DST_ALL_RECOVERY_RATE:
		{
			// HP
#ifdef __NO_HP_DMG_LIMIT
		long long nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		long long nRecv = (long long)((nMax * (nAdjParameterValue / 100.0f)));
#else
		int nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		int nRecv = (int)((nMax * (nAdjParameterValue / 100.0f)));
#endif
			ResetDestParam( DST_HP_RECOVERY, nRecv, TRUE );
			
			// MP
			nMax	= GetMaxOriginManaPoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			ResetDestParam( DST_MP_RECOVERY, nRecv, TRUE );
			
			// FP
			nMax	= GetMaxOriginFatiguePoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			ResetDestParam( DST_FP_RECOVERY, nRecv, TRUE );
		}
		return;
	case DST_KILL_ALL:	
		{
			// HP
			ResetDestParam( DST_KILL_HP, nAdjParameterValue, TRUE );
			// MP
			SetDestParam( DST_KILL_MP, nAdjParameterValue, TRUE );
			// FP
			SetDestParam( DST_KILL_FP, nAdjParameterValue, TRUE );
		}
		return;
	case DST_KILL_HP_RATE:
		{
#ifdef __NO_HP_DMG_LIMIT
		long long nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		long long nRecv = (long long)((nMax * (nAdjParameterValue / 100.0f)));

#else
		int nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		int nRecv = (int)((nMax * (nAdjParameterValue / 100.0f)));
#endif
			ResetDestParam( DST_KILL_HP, nRecv, TRUE );
		}
		return;
	case DST_KILL_MP_RATE:
		{
			int nMax	= GetMaxOriginManaPoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			int nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			ResetDestParam( DST_KILL_MP, nRecv, TRUE );
		}
		return;
	case DST_KILL_FP_RATE:
		{
			int nMax	= GetMaxOriginFatiguePoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			int nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			ResetDestParam( DST_KILL_FP, nRecv, TRUE );
		}
		return;
	case DST_KILL_ALL_RATE:
		{
			// HP
#ifdef __NO_HP_DMG_LIMIT
		long long nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		long long nRecv = (long long)((nMax * (nAdjParameterValue / 100.0f)));
#else
		int nMax = GetMaxOriginHitPoint();		// ������ ������ ���� ���� �������� ��
		int nRecv = (int)((nMax * (nAdjParameterValue / 100.0f)));
#endif
			ResetDestParam( DST_KILL_HP, nRecv, TRUE );
			// MP
			nMax	= GetMaxOriginManaPoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			ResetDestParam( DST_KILL_MP, nRecv, TRUE );
			// FP
			nMax	= GetMaxOriginFatiguePoint();		// ¹öÇÁÀÇ ¿µÇâÀ» ¹ÞÁö ¾ÊÀº ¿À¸®Áö³¯ ¾ç
			nRecv	= (int)( (nMax * (nAdjParameterValue / 100.0f)) );
			ResetDestParam( DST_KILL_FP, nRecv, TRUE );
		}
		return;
	case DST_ALL_DEC_RATE:
	{
		SetDestParam(DST_MP_DEC_RATE, nAdjParameterValue, TRUE);
		SetDestParam(DST_FP_DEC_RATE, nAdjParameterValue, TRUE);
	}
	break;
#ifdef __DST_COLLECTOR_TIME
#ifdef __CLIENT
	case DST_COLLECTOR_TIME:
	{
		if (m_nMaxCltTime)
		{
			m_nMaxCltTime = (int)(m_nMaxCltTime / (100.f - nAdjParameterValue) / 100.0f);
		}
	}
	break;
#endif // __CLIENT
#endif // __DST_COLLECTOR_TIME
	}


	// ÀÌ °Ë»ç¸¦ ¿Ö À§¿¡´Ù ¾È³Ö°í ¿©±â´Ù ³Ö¾ú³Ä¸é
	// DST_GOLD, PXP, RESIST_ALL°°Àº°æ¿ì´Â MAX_ADJPARAMARYº¸´Ù ´õ Å«°ªÀ» »ç¿ëÇÑ´Ù. 
	// ±×·¡¼­ ±×·±°ÍµéÀº À§¿¡¼­ Ã³¸®ÇÏ°í ¹Ù·Î ¸®ÅÏÇÏ°í
	// ÀÏ¹ÝÀûÀÎ°Íµé¸¸ ÀÌÂÊÀ¸·Î ¿Â´Ù.
	
	if( nDstParameter >= MAX_ADJPARAMARY || nDstParameter < 0 )
	{
//		Error( "ResetDestParam %s : Àß¸øµÈ °ª nDstParam : %d", m_szName, nDstParameter );
		return;
	}
	if( nAdjParameterValue != 0 ) 
	{
		if( nDstParameter == DST_CHRSTATE )
			m_adjParamAry[nDstParameter] &= (~nAdjParameterValue);		// ÇØ´çºñÆ® ¿ÀÇÁ.
		else
			m_adjParamAry[nDstParameter] += (-nAdjParameterValue);
	}

	// ëÅ
	if( nAdjParameterValue == 0 )	//
	{
		if( nDstParameter == DST_SPEED && m_chgParamAry[nDstParameter] != 0x7FFFFFFF && m_chgParamAry[nDstParameter] > 0 )
		{
			if( --m_chgParamAry[nDstParameter] == 0 )
				m_chgParamAry[nDstParameter]		= 0x7FFFFFFF;
		}
		else
		{
			m_chgParamAry[nDstParameter]		= 0x7FFFFFFF;
		}
	}
#ifdef __WORLDSERVER
	if( fSend == TRUE ) 
	{
	#ifdef	__SPEED_SYNC_0108 // ResetDestParam speed ¼öÁ¤
		if( nDstParameter == DST_SPEED )
			g_UserMng.AddResetDestParamSync( this, nDstParameter, nAdjParameterValue, (int)m_adjParamAry[nDstParameter] );
		else
			g_UserMng.AddResetDestParam( this, nDstParameter, nAdjParameterValue );
	#else	// 	__SPEED_SYNC_0108 ResetDestParam speed ¼öÁ¤
		g_UserMng.AddResetDestParam( this, nDstParameter, nAdjParameterValue );
	#endif	// 	__SPEED_SYNC_0108 ResetDestParam speed ¼öÁ¤
	}
#endif	// __WORLDSERVER
}

#ifdef __SPEED_SYNC_0108		// ResetDestParam speed ¼öÁ¤
void CMover::ResetDestParamSync( int nDstParameter,int nAdjParameterValue, int nParameterValue, BOOL fSend )
{
#ifdef __CLIENT
	if( nDstParameter >= MAX_ADJPARAMARY || nDstParameter < 0 )
	{
//		Error( "ResetDestParam %s : Àß¸øµÈ °ª nDstParam : %d", m_szName, nDstParameter );
		return;
	}

	switch( nDstParameter )
	{
		case DST_SPEED:
			{
				m_adjParamAry[nDstParameter] = nParameterValue;
				if( nAdjParameterValue == 0 && m_chgParamAry[nDstParameter] != 0x7FFFFFFF && m_chgParamAry[nDstParameter] > 0 )
				{
					if( --m_chgParamAry[nDstParameter] == 0 )
						m_chgParamAry[nDstParameter]		= 0x7FFFFFFF;
				}
			}
			break;
	}
#endif	// __CLIENT
}
#endif // __SPEED_SYNC_0108		// ResetDestParam speed ¼öÁ¤

// ¼öÁ¤ ÆÄ¶ó¹ÌÅÍ¸¦ ¾ò´Â´Ù.
int CMover::GetAdjParam( int nDestParameter )
{
	if( nDestParameter < MAX_ADJPARAMARY )
		return m_adjParamAry[ nDestParameter ];
	return 0;
}
// ±³Ã¼ ÆÄ¶ó¹ÌÅÍ¸¦ ¾ò´Â´Ù.
int CMover::GetChgParam( int nDestParameter )
{
	if( nDestParameter < MAX_ADJPARAMARY )
		return m_chgParamAry[ nDestParameter ];
	return 0x7FFFFFFF;
}

// ÆÄ¶ó¹ÌÅÍ¸¦ ¾ò´Â´Ù.
#ifdef __NO_HP_DMG_LIMIT
__int64 CMover::GetParam(int nDest, __int64 nParam)
#else
int CMover::GetParam(int nDest, int nParam)
#endif
{
	int nChgParam = GetChgParam( nDest );
	if( nChgParam != 0x7FFFFFFF ) 
		return nChgParam;

#ifdef __NO_HP_DMG_LIMIT
	long long nAdjParam = GetAdjParam(nDest);
#else
	int nAdjParam = GetAdjParam(nDest);
#endif
	if( nAdjParam )	
		return nParam + nAdjParam;
	else
		return nParam;
}

/////////////////////////////////////////////////////////////////////////////
// ¿©±âºÎÅÍ ÆÄ¶ó¸ÞÅ¸ ¾ò±â ÇÔ¼öµé 
// GetParamÀ» »ç¿ëÇÏ¿© ¼öÁ¤µÈ °ªÀ» ³»ÁØ´Ù.
//
// È÷Æ® Æ÷ÀÎÆ® ¾ò±â 
#ifdef __NO_HP_DMG_LIMIT
__int64 CMover::GetHitPoint()
#else
int CMover::GetHitPoint()
#endif
{
#ifdef	__FIX_GET_HP_MP_FP_POINT
#ifdef __NO_HP_DMG_LIMIT
	__int64 hitPoint = GetParam(DST_HP, m_nHitPoint);
	__int64 maxHitPoint = GetMaxHitPoint();
#else
	int hitPoint = GetParam(DST_HP, m_nHitPoint);
	int maxHitPoint = GetMaxHitPoint();
#endif
	if (hitPoint > maxHitPoint)
		return maxHitPoint;
	else
		return hitPoint;
#endif  // __FIX_GET_HP_MP_FP_POINT
	return GetParam( DST_HP, m_nHitPoint );
}
// ¸¶³ª Æ÷ÀÎÆ® ¾ò±â 
int CMover::GetManaPoint()
{
#ifdef __EVENT1206
	if( IsPlayer() && g_eLocal.GetState( EVE_EVENT1206 ) )  // raiders_fix051217
		return GetMaxManaPoint();
#endif	// __EVENT1206
#ifdef	__FIX_GET_HP_MP_FP_POINT
	__int64 manaPoint = GetParam(DST_MP, m_nManaPoint);
	__int64 maxManaPoint = GetMaxManaPoint();

	if (manaPoint > maxManaPoint)
		return maxManaPoint;
	else
		return manaPoint;
#endif // __FIX_GET_HP_MP_FP_POINT
	return GetParam( DST_MP, m_nManaPoint );
}
// ÇÇÁöÄ® Æ÷ÀÎÆ® ¾ò±â
int CMover::GetFatiguePoint()
{
#ifdef __EVENT1206
	if(  IsPlayer() && g_eLocal.GetState( EVE_EVENT1206 ) )	// raiders_fix051217
		return GetMaxFatiguePoint();
#endif	// __EVENT1206
#ifdef	__FIX_HPMPFP_POINT
	int fatiguePoint = GetParam(DST_FP, m_nFatiguePoint);
	int maxFatiguePoint = GetMaxFatiguePoint();

	if (fatiguePoint > maxFatiguePoint)
		return maxFatiguePoint;
	else
		return fatiguePoint;
#endif // __FIX_GET_HP_MP_FP_POINT
	return GetParam( DST_FP, m_nFatiguePoint );
}

// ÃÖ´ë È÷Æ® Æ÷ÀÎÆ® ¾ò±â 
#ifdef __NO_HP_DMG_LIMIT
__int64 CMover::GetMaxHitPoint()
#else
int CMover::GetMaxHitPoint()
#endif
{
	if( IsInvalidObj(this) )	
		return 0;

#ifdef __NO_HP_DMG_LIMIT
	float factor = 1.0f;
	__int64 nResult = GetParam(DST_HP_MAX, GetMaxOriginHitPoint(FALSE));
	__int64 nFactor = GetParam(DST_HP_MAX_RATE, 0);

	factor += (float)nFactor / (float)100;
	nResult = (__int64)(nResult * factor);
#else
	float factor = 1.0f;
	int nResult = GetParam(DST_HP_MAX, GetMaxOriginHitPoint(FALSE));
	int nFactor = GetParam(DST_HP_MAX_RATE, 0);

	factor += (float)nFactor / (float)100;
	nResult = (int)(nResult * factor);
#endif

#ifdef __JEFF_11
	if( nResult < 1 )
		nResult		= 1;
#endif	// __JEFF_11
	return nResult; 
}

// ÃÖ´ë ¸¶³ª Æ÷ÀÎÆ® ¾ò±â 
int CMover::GetMaxManaPoint()
{
	float factor = 1.0f;
	int nResult = GetParam( DST_MP_MAX, GetMaxOriginManaPoint( FALSE ) );
	int nFactor = GetParam( DST_MP_MAX_RATE, 0 );
	
	factor += (float)nFactor/(float)100;
	nResult	= (int)( nResult * factor );

#ifdef __JEFF_11
	if( nResult < 1 )
		nResult		= 1;
#endif	// __JEFF_11
	return nResult; 
}

// ÃÖ´ë ÇÇ·Î Æ÷ÀÎÆ® ¾ò±â
int CMover::GetMaxFatiguePoint()
{
	float factor = 1.0f;
	int nResult = GetParam( DST_FP_MAX, GetMaxOriginFatiguePoint( FALSE ) );
	int nFactor = GetParam( DST_FP_MAX_RATE, 0 );
	
	factor += (float)nFactor/(float)100;
	nResult	= (int)( nResult * factor );

#ifdef __JEFF_11
	if( nResult < 1 )
		nResult		= 1;
#endif	// __JEFF_11
	return nResult; 
}

#ifdef __NO_HP_DMG_LIMIT
__int64 CMover::GetMaxPoint(int nDest)
#else
int CMover::GetMaxPoint(int nDest)
#endif
{
	switch( nDest )
	{
		case DST_HP:
			return GetMaxHitPoint();
		case DST_MP:
			return GetMaxManaPoint();
		case DST_FP:
			return GetMaxFatiguePoint();
	}
	
	return 0;
}

#ifdef __NO_HP_DMG_LIMIT
__int64 CMover::GetMaxOriginHitPoint(BOOL bOriginal)
#else
int CMover::GetMaxOriginHitPoint(BOOL bOriginal)
#endif
{
	if( IsInvalidObj(this) )	
		return 0;

	if( IsPlayer() )
	{
		int nSta;
		if( bOriginal )
			nSta = m_nSta;
		else
			nSta = GetSta();

		JobProp* pProperty = prj.GetJobProp( GetJob() ); 

#ifdef __NO_HP_DMG_LIMIT
		double a = (pProperty->fFactorMaxHP * m_nLevel) / 2.0f;
		double b = a * ((m_nLevel + 1.0f) / 4.0f) * (1.0f + nSta / 50.0f) + (nSta * 10.0f);
		double maxHP = b + 80.f;

		return maxHP;
#else
		float a = (pProperty->fFactorMaxHP * m_nLevel) / 2.0f;
		float b = a * ((m_nLevel + 1.0f) / 4.0f) * (1.0f + nSta / 50.0f) + (nSta * 10.0f);
		float maxHP = b + 80.f;

		return (int)maxHP;
#endif
	}
	else
	{
		MoverProp *pMoverProp = GetProp();
#ifdef __NO_HP_DMG_LIMIT
#ifdef __S1108_BACK_END_SYSTEM
		return pMoverProp->dwAddHp * prj.m_fMonsterHitpointRate * pMoverProp->m_fHitPoint_Rate;
#else // __S1108_BACK_END_SYSTEM
		return pMoverProp->dwAddHp;
#endif // __S1108_BACK_END_SYSTEM
#else
#ifdef __S1108_BACK_END_SYSTEM
		return int(pMoverProp->dwAddHp * prj.m_fMonsterHitpointRate * pMoverProp->m_fHitPoint_Rate);
#else // __S1108_BACK_END_SYSTEM
		return pMoverProp->dwAddHp;
#endif // __S1108_BACK_END_SYSTEM
#endif
	}

	return 0;
}

int CMover::GetMaxOriginManaPoint( BOOL bOriginal )
{
	int nInt = 0;
	if( bOriginal )
		nInt = m_nInt;
	else
		nInt = GetInt();

	if( IsPlayer() )
	{
		// INT((((BaseLv*2) + (INT*8))*Job°è¼ö) + 22)+(INT*Job°è¼ö)) +  ¨ç 
		// ¨ç : ¾ÆÀÌÅÛ¿¡ÀÇÇÑ Ãß°¡ »ó½Â (%´ÜÀ§) TDDO
		JobProp* pProperty = prj.GetJobProp( GetJob() ); 
		float factor = pProperty->fFactorMaxMP;
		
		int nMaxMP = (int)( ((((m_nLevel*2.0f) + ( nInt*8.0f))*factor) + 22.0f)+( nInt*factor) );
		return nMaxMP;
	}
	return 	( ( m_nLevel * 2 ) + ( nInt * 8 ) + 22 );
}

int CMover::GetMaxOriginFatiguePoint( BOOL bOriginal )
{
	int nSta, nStr, nDex;
	if( bOriginal )
	{
		nSta = m_nSta;
		nStr = m_nStr;
		nDex = m_nDex;
	}
	else
	{
		nSta = GetSta();
		nStr = GetStr();
		nDex = GetDex();
	}

	if( IsPlayer() )
	{
		// (((BaseLv*2) + (STA*6))*Job°è¼ö) +(STA*Job°è¼ö) + ¨ç + ¨è
		JobProp* pProperty = prj.GetJobProp( GetJob() ); 
		float factor = pProperty->fFactorMaxFP;

		int nMaxFP = (int)( (((m_nLevel*2.0f) + (nSta*6.0f))*factor) +(nSta*factor) );
		return nMaxFP;
	}
	
	return ( ( m_nLevel * 2 ) + ( nStr * 7 ) + ( nSta *2 ) + ( nDex * 4 ) );
}

int CMover::GetHitPointPercent( int nPercent )
{
#ifdef __NO_HP_DMG_LIMIT
	__int64 nMax = GetMaxHitPoint();
#else
	int nMax = GetMaxHitPoint();
#endif
	if( nMax == 0 ) return 0;
//	return GetHitPoint() * nPercent / nMax;
#ifdef __NO_HP_DMG_LIMIT
	return aisaka::mulDiv(GetHitPoint(), nPercent, nMax);
#else
	return MulDiv(GetHitPoint(), nPercent, nMax);
#endif
}
int CMover::GetManaPointPercent( int nPercent )
{
	int nMax = GetMaxManaPoint();
	if( nMax == 0 ) return 0;
//	return GetManaPoint() * nPercent / GetMaxManaPoint();
	return MulDiv( GetManaPoint(), nPercent, nMax );
}
int CMover::GetFatiguePointPercent( int nPercent )
{
	int nMax = GetMaxFatiguePoint();
	if( nMax == 0 ) return 0;
//	return GetFatiguePoint() * nPercent / GetMaxFatiguePoint();
	return MulDiv( GetFatiguePoint(),  nPercent, nMax );
}

// HP È¸º¹ °ª ¾ò±â
/*
	HP Recovery : È¸º¹·®	PC/NPC : int(((ÇöÀç·¹º§ + STA)/3.4)+2) + AddHpRecovery
	MP Recovery : È¸º¹·®	PC/NPC : int(((ÇöÀç·¹º§ + INT)/4)+2) + Addecovery
	FP Recovery : È¸º¹·®	PC/NPC : int(((ÇöÀç·¹º§ + STA + DEX)/4.5)+2) + AddHpRecovery

	HP Recovery : È¸º¹¼Óµµ	PC/NPC : ÈÞ½Ä(Á¤Áö)½Ã 5ÃÊ¿¡ ÇÑ¹ø¾¿ È¸º¹ÇÏ¸ç ÈÞ½ÄÇÏÁö ¾Ê´Â »óÈ²¿¡¼­´Â 12ÃÊ¿¡ ÇÑ¹ø¾¿ È¸º¹ÇÔ - AddHpRecoveryTime
	MP Recovery : È¸º¹¼Óµµ	PC/NPC : ÈÞ½Ä(Á¤Áö)½Ã 5ÃÊ¿¡ ÇÑ¹ø¾¿ È¸º¹ÇÏ¸ç ÈÞ½ÄÇÏÁö ¾Ê´Â »óÈ²¿¡¼­´Â 12ÃÊ¿¡ ÇÑ¹ø¾¿ È¸º¹ÇÔ - AddMpRecoveryTime
	FP Recovery : È¸º¹¼Óµµ	PC/NPC : ÈÞ½Ä(Á¤Áö)½Ã 5ÃÊ¿¡ ÇÑ¹ø¾¿ È¸º¹ÇÏ¸ç ÈÞ½ÄÇÏÁö ¾Ê´Â »óÈ²¿¡¼­´Â 12ÃÊ¿¡ ÇÑ¹ø¾¿ È¸º¹ÇÔ - AddFpRecoveryTime

  */
#ifdef __NO_HP_DMG_LIMIT
__int64 CMover::GetHPRecovery()
#else
int CMover::GetHPRecovery()
#endif
{
	float fFactor = 1.0f;
	if( IsPlayer() )
	{
		JobProp* pProperty = prj.GetJobProp( GetJob() ); 
		fFactor = pProperty->fFactorHPRecovery;
	}

	//(·¹º§/3)+ (MaxHP/ (500* ·¹º§))+(STA*Job°è¼ö)
#ifdef __NO_HP_DMG_LIMIT
	__int64 nValue = (__int64)((GetLevel() / 3.0f) + (GetMaxHitPoint() / (500.f * GetLevel())) + (GetSta() * fFactor));
#else
	int nValue = (int)((GetLevel() / 3.0f) + (GetMaxHitPoint() / (500.f * GetLevel())) + (GetSta() * fFactor));
#endif
#if __VER >= 9 // __RECOVERY10
#ifdef __NO_HP_DMG_LIMIT
	nValue = (nValue - (nValue * 0.1f)); // ȸ���� 10% ����
#else
	nValue = (int)(nValue - (nValue * 0.1f)); // ȸ���� 10% ����
#endif
#endif //__RECOVERY10
	return GetParam( DST_HP_RECOVERY, nValue );
}
// MP È¸º¹ °ª ¾ò±â
int CMover::GetMPRecovery()
{
	float fFactor = 1.0f;
	if( IsPlayer() )
	{
		JobProp* pProperty = prj.GetJobProp( GetJob() ); 
		fFactor = pProperty->fFactorMPRecovery;
	}

	// ((·¹º§*1.5)+(MaxMP/(500*·¹º§))+(INT*Job°è¼ö))*0.2
	int nValue = (int)( ((GetLevel() * 1.5f) + (GetMaxManaPoint() / (500.f * GetLevel())) + (GetInt() * fFactor)) * 0.2f );
#if __VER >= 9 // __RECOVERY10
	nValue	= (int)( nValue - ( nValue * 0.1f ) ); // È¸º¹·® 10% ÇÏÇâ
#endif //__RECOVERY10
	return GetParam( DST_MP_RECOVERY, nValue );
}
// FP È¸º¹ °ª ¾ò±â 
int CMover::GetFPRecovery()
{
	float fFactor = 1.0f;
	if( IsPlayer() )
	{
		JobProp* pProperty = prj.GetJobProp( GetJob() ); 
		fFactor = pProperty->fFactorFPRecovery;
	}
	// ((·¹º§*2)+(MaxFP/(500*·¹º§))+(STA*Job°è¼ö))*0.2
	int nValue = (int)( ((GetLevel() * 2.0f) + (GetMaxFatiguePoint() / (500.f * GetLevel())) + (GetSta() * fFactor)) * 0.2f );
#if __VER >= 9 // __RECOVERY10
	nValue	= (int)( nValue - ( nValue * 0.1f ) ); // È¸º¹·® 10% ÇÏÇâ
#endif //__RECOVERY10
	return GetParam( DST_FP_RECOVERY, nValue );
}

#ifdef __CLIENT
// ¸í¼º ÀÌ¸§À» ½ºÆ®¸µÀ¸·Î µ¹·ÁÁØ´Ù.
LPCTSTR CMover::GetFameName( void )
{
	switch( GetJob() )
	{
	// ¾ÆÅ©·Î¹î
	case JOB_ACROBAT:
	case JOB_JESTER:
	case JOB_RANGER:
	case JOB_JESTER_MASTER:
	case JOB_RANGER_MASTER:
	case JOB_JESTER_HERO:
	case JOB_RANGER_HERO:
	case JOB_WINDLURKER_HERO:
	case JOB_CRACKSHOOTER_HERO:
		if( m_nFame >= 100000000 )	return prj.GetText( TID_GAME_ACR_FAME10 );
		else if( m_nFame >= 5000000 )	return prj.GetText( TID_GAME_ACR_FAME09 );
		else if( m_nFame >= 1000000 )	return prj.GetText( TID_GAME_ACR_FAME08 );
		else if( m_nFame >= 50000 )	return prj.GetText( TID_GAME_ACR_FAME07 );
		else if( m_nFame >= 20000 )	return prj.GetText( TID_GAME_ACR_FAME06 );
		else if( m_nFame >= 10000 )	return prj.GetText( TID_GAME_ACR_FAME05 );
		else if( m_nFame >= 4000 )	return prj.GetText( TID_GAME_ACR_FAME04 );
		else if( m_nFame >= 1000 )	return prj.GetText( TID_GAME_ACR_FAME03 );
		else if( m_nFame >= 100 )	return prj.GetText( TID_GAME_ACR_FAME02 );
		else if( m_nFame >= 10 )	return prj.GetText( TID_GAME_ACR_FAME01 );
		break;

	// ¸Ó¼­³Ê¸®ÀÏ¶§
	case JOB_MERCENARY:	
	case JOB_KNIGHT:	
	case JOB_BLADE:
	case JOB_KNIGHT_MASTER:
	case JOB_BLADE_MASTER:
	case JOB_KNIGHT_HERO:	
	case JOB_BLADE_HERO:
	case JOB_LORDTEMPLER_HERO:
	case JOB_STORMBLADE_HERO:
		if( m_nFame >= 100000000 )	return prj.GetText( TID_GAME_MER_FAME10 );
		else if( m_nFame >= 5000000 )	return prj.GetText( TID_GAME_MER_FAME09 );
		else if( m_nFame >= 1000000 )	return prj.GetText( TID_GAME_MER_FAME08 );
		else if( m_nFame >= 50000 )	return prj.GetText( TID_GAME_MER_FAME07 );
		else if( m_nFame >= 20000 )	return prj.GetText( TID_GAME_MER_FAME06 );
		else if( m_nFame >= 10000 )	return prj.GetText( TID_GAME_MER_FAME05 );
		else if( m_nFame >= 4000 )	return prj.GetText( TID_GAME_MER_FAME04 );
		else if( m_nFame >= 1000 )	return prj.GetText( TID_GAME_MER_FAME03 );
		else if( m_nFame >= 100 )	return prj.GetText( TID_GAME_MER_FAME02 );
		else if( m_nFame >= 10 )	return prj.GetText( TID_GAME_MER_FAME01 );
		break;
	// ¸ÅÁö¼Ç
	case JOB_MAGICIAN:
	case JOB_PSYCHIKEEPER:	
	case JOB_ELEMENTOR:
	case JOB_PSYCHIKEEPER_MASTER:	
	case JOB_ELEMENTOR_MASTER:
	case JOB_PSYCHIKEEPER_HERO:	
	case JOB_ELEMENTOR_HERO:
	case JOB_MENTALIST_HERO:
	case JOB_ELEMENTORLORD_HERO:
		if( m_nFame >= 100000000 )	return prj.GetText( TID_GAME_MAG_FAME10 );
		else if( m_nFame >= 5000000 )	return prj.GetText( TID_GAME_MAG_FAME09 );
		else if( m_nFame >= 1000000 )	return prj.GetText( TID_GAME_MAG_FAME08 );
		else if( m_nFame >= 50000 )	return prj.GetText( TID_GAME_MAG_FAME07 );
		else if( m_nFame >= 20000 )	return prj.GetText( TID_GAME_MAG_FAME06 );
		else if( m_nFame >= 10000 )	return prj.GetText( TID_GAME_MAG_FAME05 );
		else if( m_nFame >= 4000 )	return prj.GetText( TID_GAME_MAG_FAME04 );
		else if( m_nFame >= 1000 )	return prj.GetText( TID_GAME_MAG_FAME03 );
		else if( m_nFame >= 100 )	return prj.GetText( TID_GAME_MAG_FAME02 );
		else if( m_nFame >= 10 )	return prj.GetText( TID_GAME_MAG_FAME01 );
		break;

	// ¾î½Ã½ºÆ®
	case JOB_ASSIST:
	case JOB_BILLPOSTER:	
	case JOB_RINGMASTER:
	case JOB_BILLPOSTER_MASTER:	
	case JOB_RINGMASTER_MASTER:
	case JOB_BILLPOSTER_HERO:	
	case JOB_RINGMASTER_HERO:
	case JOB_FLORIST_HERO:
	case JOB_FORCEMASTER_HERO:
		if( m_nFame >= 100000000 )	return prj.GetText( TID_GAME_ASS_FAME10 );
		else if( m_nFame >= 5000000 )	return prj.GetText( TID_GAME_ASS_FAME09 );
		else if( m_nFame >= 1000000 )	return prj.GetText( TID_GAME_ASS_FAME08 );
		else if( m_nFame >= 50000 )	return prj.GetText( TID_GAME_ASS_FAME07 );
		else if( m_nFame >= 20000 )	return prj.GetText( TID_GAME_ASS_FAME06 );
		else if( m_nFame >= 10000 )	return prj.GetText( TID_GAME_ASS_FAME05 );
		else if( m_nFame >= 4000 )	return prj.GetText( TID_GAME_ASS_FAME04 );
		else if( m_nFame >= 1000 )	return prj.GetText( TID_GAME_ASS_FAME03 );
		else if( m_nFame >= 100 )	return prj.GetText( TID_GAME_ASS_FAME02 );
		else if( m_nFame >= 10 )	return prj.GetText( TID_GAME_ASS_FAME01 );		

		break;
	}
	return "";
}

#if __VER < 8 // __S8_PK
// ½½·ÎÅÍ ÀÌ¸§À» ½ºÆ®¸µÀ¸·Î µ¹·ÁÁØ´Ù.
LPCTSTR CMover::GetSlaughterName( void )
{
	KarmaProp* pProp = prj.GetKarmaProp( m_nSlaughter );

	if( pProp )
	{
		if(strlen(pProp->szName) > 0 )
			return pProp->szName;
	}	

	return "";
}
#endif // __VER < 8 // __S8_PK

#endif


// ¸¶¹ý ÀúÇâ·Â ¾ò±â 
int CMover::GetResistMagic()
{
	return GetParam( DST_RESIST_MAGIC, 0 );
}
int CMover::GetResistSpell( int nDestParam )
{
	MoverProp *pProp = GetProp();
	if( pProp == NULL )
		Error( "CMover::GetReistSpell : %d Fail to read prop", GetName() );

	int		nResist = 0;

	switch( nDestParam )
	{
	case DST_RESIST_ELECTRICITY:	nResist = pProp->nResistElecricity;		break;
	case DST_RESIST_FIRE:			nResist = pProp->nResistFire;		break;
	case DST_RESIST_WATER:			nResist = pProp->nResistWater;		break;
	case DST_RESIST_EARTH:			nResist = pProp->nResistEarth;		break;
	case DST_RESIST_WIND:			nResist = pProp->nResistWind;		break;
	default:
		Error( "CMover::GetResistSpell : %s ÆÄ¶ó¸ÞÅÍ Àß¸øµÊ %d", GetName(), nDestParam );
		break;
	}
	return GetParam( nDestParam, nResist );
}

int CMover::GetNaturalArmor()
{
	return GetProp()->dwNaturalArmor;//GetParam(DST_NATURAL_ARMOR,GetProp()->m_dwNaturalArmor);
}

int CMover::GetStr()
{
	int nResult = m_nStr + GetParam( DST_STR, 0 );

#if __VER < 8 // __S8_PK
	// ½Ã·Ã¸ðµåÀÌ°í ½Ã·ÃÁ¦ÇÑ»óÅÂÀÌ¸é Æä³ÎÆ¼ Àû¿ë
	if( IsMode( RECOVERCHAO_MODE ) && IsSMMode(SM_STR_DOWN) )
	{
		KarmaProp* pKarmaProp = prj.GetKarmaProp(m_nSlaughter);
		if( pKarmaProp )
			nResult -= (int)(nResult * (pKarmaProp->nStatLimitRate / 100.0f));
	}
#endif // __VER < 8 // __S8_PK

#ifdef __JEFF_11
	if( nResult < 1 )
		nResult	= 1;
#endif	// __JEFF_11

	return nResult;
}
int CMover::GetDex()
{
	int nResult = m_nDex + GetParam( DST_DEX, 0 );

#if __VER < 8 // __S8_PK
	// ½Ã·Ã¸ðµåÀÌ°í ½Ã·ÃÁ¦ÇÑ»óÅÂÀÌ¸é Æä³ÎÆ¼ Àû¿ë
	if( IsMode( RECOVERCHAO_MODE ) && IsSMMode(SM_DEX_DOWN) )
	{
		KarmaProp* pKarmaProp = prj.GetKarmaProp(m_nSlaughter);
		if( pKarmaProp )
			nResult -= (int)(nResult * (pKarmaProp->nStatLimitRate / 100.0f));
	}
#endif // __VER < 8 // __S8_PK

#ifdef __JEFF_11
	if( nResult < 1 )
		nResult	= 1;
#endif	// __JEFF_11

	return nResult;
}
int CMover::GetInt()
{
	int nResult = m_nInt + GetParam( DST_INT, 0 );

#if __VER < 8 // __S8_PK
	// ½Ã·Ã¸ðµåÀÌ°í ½Ã·ÃÁ¦ÇÑ»óÅÂÀÌ¸é Æä³ÎÆ¼ Àû¿ë
	if( IsMode( RECOVERCHAO_MODE ) && IsSMMode(SM_INT_DOWN) )
	{
		KarmaProp* pKarmaProp = prj.GetKarmaProp(m_nSlaughter);
		if( pKarmaProp )
			nResult -= (int)(nResult * (pKarmaProp->nStatLimitRate / 100.0f));
	}
#endif // __VER < 8 // __S8_PK

#ifdef __JEFF_11
	if( nResult < 1 )
		nResult	= 1;
#endif	// __JEFF_11

	return nResult;
}
int CMover::GetSta()
{
	int nResult = m_nSta + GetParam( DST_STA, 0 );

#if __VER < 8 // __S8_PK
	// ½Ã·Ã¸ðµåÀÌ°í ½Ã·ÃÁ¦ÇÑ»óÅÂÀÌ¸é Æä³ÎÆ¼ Àû¿ë
	if( IsMode( RECOVERCHAO_MODE ) && IsSMMode(SM_STA_DOWN) )
	{
		KarmaProp* pKarmaProp = prj.GetKarmaProp(m_nSlaughter);
		if( pKarmaProp )
			nResult -= (int)(nResult * (pKarmaProp->nStatLimitRate / 100.0f));
	}
#endif // __VER < 8 // __S8_PK

#ifdef __JEFF_11
	if( nResult < 1 )
		nResult	= 1;
#endif	// __JEFF_11

	return nResult;
}

FLOAT CMover::GetSpeed(FLOAT fSrcSpeed)
{
#ifdef __MOUNT
	if (GetMountId() > 0)
	{
		MOUNT_ANIMATION* pMountAnimation = prj.GetMountAnimation(GetMountId());
		if (pMountAnimation)
			return IsFly() ? pMountAnimation->fFlightSpeed : pMountAnimation->fGroundSpeed;
	}
#endif // __MOUNT
#if __VER >= 9	// __PET_0410
#ifdef __CLIENT
	if( m_dwAIInterface == AII_EGG && m_pAIInterface )
	{
		CAIEgg* pAI	= (CAIEgg*)m_pAIInterface;
		CMover* pOwner	= prj.GetMover( pAI->GetOwnerId() );
		if( IsValidObj( pOwner ) )
			return pOwner->GetSpeed( pOwner->m_pActMover->m_fSpeed );
	}
#endif	// __CLIENT
#endif	// __PET_0410

#if __VER >= 9	//__AI_0509
	fSrcSpeed	*= GetSpeedFactor();
#endif	// __AI_0509

	if( m_fCrrSpd != 0.0f )
		return m_fCrrSpd;
	int nChgValue	= GetChgParam( DST_SPEED );
//	if( nChgValue != 0x7FFFFFFF )
//		return fSrcSpeed * (nChgValue / 100.0f);		// ex) fSrcSpeed * 0.5f

	// ëÅ
	if( nChgValue != 0x7FFFFFFF )
		return 0;

	int nAdjValue	= GetAdjParam( DST_SPEED );
	if( nAdjValue != 0 )
	{
#ifdef MAX_SPEED
#ifdef __GAMEMASTER
		if (nAdjValue > MAX_SPEED && this->m_dwAuthorization < AUTH_GAMEMASTER3)
#else // __GAMEMASTER
		if (nAdjValue > MAX_SPEED)
#endif // __GAMEMASTER
		{
			nAdjValue = MAX_SPEED;
		}
#endif // MAX_SPEED
#ifdef __JEFF_11
		fSrcSpeed = fSrcSpeed + ( fSrcSpeed * (nAdjValue / 100.0f) );
		if( fSrcSpeed < 0.0F )
			fSrcSpeed	= 0.0F;
#endif	// __JEFF_11
		return fSrcSpeed;
	}
#ifdef __JEFF_11
	if( fSrcSpeed < 0.0F )
		fSrcSpeed	= 0.0F;
#endif	// __JEFF_11

	return fSrcSpeed;
}




//
// ÇöÀç µ¿ÀÛ»óÅÂ¸¦ °­Á¦·Î ¼¼ÆÃ
// µ¿±âÈ­ ÀÌ¿Ü´Â »ç¿ëÇÏÁö ¸»°Í.
//

// ÇàÀ§ ¸í·ÉÀº °­Á¦ µ¿±âÈ­ ÇÏ°í ÀÌµ¿ ¸í·ÉÀº ¹«½ÃÇÑ´Ù.
void CMover::BehaviorActionForceSet( void )
{
	if( m_CorrAction.fValid && m_CorrAction.fBehavior == TRUE ) {
		if( m_CorrAction.dwStateFlag & OBJSTAF_FLY ) {
			ActionForceSet2( m_CorrAction.v, m_CorrAction.vd, m_CorrAction.f,
								m_CorrAction.fAngleX, m_CorrAction.fAccPower, m_CorrAction.fTurnAngle,
								m_CorrAction.dwState, m_CorrAction.dwStateFlag,
								m_CorrAction.dwMotion, m_CorrAction.nMotionEx, m_CorrAction.nLoop, m_CorrAction.dwMotionOption );
		}
		else {
			ActionForceSet( m_CorrAction.v, m_CorrAction.vd, m_CorrAction.f,
								m_CorrAction.dwState, m_CorrAction.dwStateFlag,
								m_CorrAction.dwMotion, m_CorrAction.nMotionEx, m_CorrAction.nLoop, m_CorrAction.dwMotionOption );
		}
	}
	memset( &m_CorrAction, 0, sizeof(CORR_ACTION) );
}

void CMover::ActionForceSet( D3DXVECTOR3 &vPos, D3DXVECTOR3 &vDelta, FLOAT fAngle, 
							 DWORD dwState, DWORD dwStateFlag, int nMotion, int nMotionEx, int nLoop, DWORD dwMotionOption )
{
	m_uRemnantCorrFrm	= 0;
	if( m_pActMover == NULL )	return;
	CModelObject* pModel = (CModelObject*)m_pModel;
#ifdef __SYNC_1217
	ClearDestPos();
#else	// __SYNC_1217
	ClearDest();
#endif	// __SYNC_1217
	ClearDestAngle();
	SetPos( vPos );
	SetAngle( fAngle );
	m_pActMover->ForcedSet( vDelta, dwState, dwStateFlag, nMotionEx );
	m_dwMotion = -1;
	SetMotion( nMotion, nLoop, dwMotionOption );
	pModel->SetMotionBlending( FALSE );
}

void CMover::ActionForceSet2( D3DXVECTOR3 &vPos, D3DXVECTOR3 &vDelta, FLOAT fAngle, 
							 FLOAT fAngleX, FLOAT fAccPower, FLOAT fTurnAngle,
							 DWORD dwState, DWORD dwStateFlag, int nMotion, int nMotionEx, int nLoop, DWORD dwMotionOption )
{
	m_uRemnantCorrFrm	= 0;
	if( m_pActMover == NULL )	return;
	CModelObject* pModel = (CModelObject*)m_pModel;
	ClearDest();
	ClearDestAngle();
	SetPos( vPos );
	SetAngle( fAngle );
	SetAngleX( fAngleX );
	m_pActMover->ForcedSet2( vDelta, fAccPower, fTurnAngle, dwState, dwStateFlag, nMotionEx );
	m_dwMotion = -1;
#ifdef __WORLDSERVER	
	if( nMotion == 31 && (dwMotionOption & MOP_FIXED) == 0 )
		dwMotionOption |= MOP_FIXED;	
#endif

	SetMotion( nMotion, nLoop, dwMotionOption );
	pModel->SetMotionBlending( FALSE );
}

void CMover::HalfForceSet( D3DXVECTOR3 & vPos, D3DXVECTOR3 & vd, float fAngle, float fAngleX, float fAccPower, float fTurnAngle )
{
	m_uRemnantCorrFrm	= 0;
	if( m_pActMover == NULL )	return;
	ClearDest();
	ClearDestAngle();
	SetPos( vPos );
	SetAngle( fAngle );
	SetAngleX( fAngleX );
	m_pActMover->HalfForcedSet( vd, fAccPower, fTurnAngle );
}

BOOL CMover::IsCompleteQuest( int nQuestId )
{
	for( int i = 0; i < m_nCompleteQuestSize; i++ )
	{
		if( m_aCompleteQuest[ i ] == nQuestId )
		{
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CMover::MakeCompleteQuest( int nQuestId, LPQUEST lpQuest )
{
	for( int i = 0; i < m_nCompleteQuestSize; i++ )
	{
		if( m_aCompleteQuest[ i ] == nQuestId )
		{
			ZeroMemory( lpQuest, sizeof( QUEST ) );
			lpQuest->m_wId = nQuestId;
			lpQuest->m_nState = QS_END;
			return TRUE;
		}
	}
	return FALSE;
}
void CMover::RemoveAllQuest()
{
	m_nQuestSize = 0;
	m_nCompleteQuestSize = 0;
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
	m_nCheckedQuestSize = 0;
#endif // __IMPROVE_QUEST_INTERFACE
}
void CMover::RemoveCompleteQuest()
{
	m_nCompleteQuestSize = 0;
}


LPQUEST CMover::FindQuest( int nQuestId )
{
	for( int i = 0; i < m_nQuestSize; i++ )
	{
		if( m_aQuest[ i ].m_wId == nQuestId )
		{
			return &m_aQuest[ i ];
		}
	}

	return NULL;
}
BOOL CMover::RemoveQuest( int nQuestId )
{
	QuestProp* pProp = prj.m_aPropQuest.GetAt( nQuestId );

	for( int i = 0; i < m_nQuestSize; i++ )
	{
		if( m_aQuest[ i ].m_wId == nQuestId )
		{
			for( ; i < m_nQuestSize - 1; i++ )
			{
				m_aQuest[ i ] = m_aQuest[ i + 1 ];
			}
			m_nQuestSize--;
			break;
		}
	}
	for( int i = 0; i < m_nCompleteQuestSize; i++ )
	{
		if( m_aCompleteQuest[ i ] == nQuestId )
		{
			for( ; i < m_nCompleteQuestSize - 1; i++ )
			{
				m_aCompleteQuest[ i ] = m_aCompleteQuest[ i + 1 ];
			}
			m_nCompleteQuestSize--;
			break;
		}
	}
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
	for( int i = 0; i < m_nCheckedQuestSize; ++i )
	{
		if( m_aCheckedQuest[ i ] == nQuestId )
		{
			for( ; i < m_nCheckedQuestSize -1; ++i )
				m_aCheckedQuest[ i ] = m_aCheckedQuest[ i + 1 ];
			m_aCheckedQuest[ --m_nCheckedQuestSize ] = 0;
			break;
		}
	}
#endif // __IMPROVE_QUEST_INTERFACE

#ifdef __CLIENT
	PlayMusic( BGM_EV_END );
#endif
	return TRUE;
}

BOOL CMover::SetQuest( int nQuestId, int nState, LPQUEST lpReturnQuest )
{
	QUEST newQuest;
	ZeroMemory( &newQuest, sizeof( QUEST ) );
	newQuest.m_wId = nQuestId;
	newQuest.m_nState = nState;

	LPQUEST lpQuest = FindQuest( nQuestId );
	// ÀÌ¹Ì ¿Ï·áµÈ ÄÉ½ºÆ®¶ó¸é ¼¼ÆÃ ½ÇÆÐ 
	if( lpQuest == NULL && IsCompleteQuest( newQuest.m_wId ) )
		return FALSE;
	if( lpReturnQuest )
		memcpy( lpReturnQuest, &newQuest, sizeof( QUEST ) );
	return __SetQuest( lpQuest, &newQuest );
}
BOOL CMover::SetQuest( LPQUEST lpNewQuest )
{
	LPQUEST lpQuest = FindQuest( lpNewQuest->m_wId );
	// ÀÌ¹Ì ¿Ï·áµÈ ÄÉ½ºÆ®¶ó¸é ¼¼ÆÃ ½ÇÆÐ 
	if( lpQuest == NULL && IsCompleteQuest( lpNewQuest->m_wId ) )
		return FALSE;
	return __SetQuest( lpQuest, lpNewQuest );
}
BOOL CMover::__SetQuest( LPQUEST lpQuest, LPQUEST lpNewQuest )
{
	// Äù½ºÆ®¸¦ ¹ß°ß ¸øÇßÀ¸¸é »õ·Î Ãß°¡ÇÑ´Ù.
	if( lpQuest == NULL )
	{
		if( m_nQuestSize >= MAX_QUEST )
		{
			Error("SetQuestCnt : Äù½ºÆ® ÃÊ°ú");
			return FALSE;
		}
#ifdef __CLIENT
		PlayMusic( BGM_EV_START );
#endif
		if( m_nCompleteQuestSize < MAX_COMPLETE_QUEST ) 
			lpQuest = &m_aQuest[ m_nQuestSize++ ];
		else
			return FALSE;

		QuestProp* pQuestProp = prj.m_aPropQuest.GetAt( lpNewQuest->m_wId );
		if( pQuestProp && pQuestProp->m_nEndCondLimitTime  )
			lpNewQuest->m_wTime = pQuestProp->m_nEndCondLimitTime;
#ifdef __WORLDSERVER
		// Å¸ÀÌ¸Ó ÃÊ±âÈ­ 
		m_timerQuestLimitTime.Reset();
#endif
	}
	else
	// Äù½ºÆ® ¿Ï·á´Ù. ±×·¸´Ù¸é Ä³½¬¿¡¼­ µÚÁ®¼­ Á¦°ÅÇÏÀÚ 
	if( lpNewQuest->m_nState == QS_END )
	{
		// ´ë½Å, ¿Ï·á ±Ë½ºÆ® ¹è¿­¿¡ ³Ö¾î º¸°üÇÑ´Ù.
		if( m_nCompleteQuestSize < MAX_COMPLETE_QUEST ) 
		{
			for( int i = 0; i < m_nQuestSize; i++ )
			{
				if( m_aQuest[ i ].m_wId == lpNewQuest->m_wId )
				{
					for( ; i < m_nQuestSize - 1; i++ )
					{
						m_aQuest[ i ] = m_aQuest[ i + 1 ];
					}
					m_nQuestSize--;
					break;
				}
			}
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
			for( int i = 0; i < m_nCheckedQuestSize; ++i )
			{
				if( m_aCheckedQuest[ i ] == lpNewQuest->m_wId )
				{
					for( ; i < m_nCheckedQuestSize - 1; ++i )
						m_aCheckedQuest[ i ] = m_aCheckedQuest[ i + 1 ];
					m_aCheckedQuest[--m_nCheckedQuestSize] = 0;
					break;
				}
			}
#endif // __IMPROVE_QUEST_INTERFACE
			QuestProp* pProp = prj.m_aPropQuest.GetAt( lpNewQuest->m_wId );
			// Äù½ºÆ® Å¸ÀÔÀÌ ÀÇ·Ú¼Ò¶ó¸é ¿Ï·á ¹è¿­¿¡ µé¾î°¡Áö ¾Ê´Â´Ù. 
			//if( pProp->m_nQuestType != QT_REQUEST && pProp->m_bRepeat == FALSE )
			if( pProp && pProp->m_bRepeat == FALSE )
				m_aCompleteQuest[ m_nCompleteQuestSize++ ] = lpNewQuest->m_wId; 
			lpQuest = NULL;
#if __VER >= 15 /* __IMPROVE_QUEST_INTERFACE */  && defined( __CLIENT )
			g_QuestTreeInfoManager.DeleteTreeInformation( lpNewQuest->m_wId );
			D3DXVECTOR3& rDestinationArrow = g_WndMng.m_pWndWorld->m_vDestinationArrow;
			rDestinationArrow = D3DXVECTOR3( -1.0F, 0.0F, -1.0F );
#endif // defined( __IMPROVE_QUEST_INTERFACE ) && defined( __CLIENT )
		}
		else
			return FALSE;
	}
	if( lpQuest )
		memcpy( lpQuest, lpNewQuest, sizeof( QUEST ) );

#ifdef __CLIENT
	if( lpNewQuest->m_nState == QS_END )
		PlayMusic( BGM_EV_END );
#endif
	return TRUE;
}

LPQUEST CMover::GetQuest( int nQuestId )
{
	return FindQuest( nQuestId );
}

int CMover::GetItemNum( DWORD dwItemId )
{
	int nNum	= 0;
	int nSize	= m_Inventory.GetMax();
	CItemElem* pItemElem;
	for( int i = 0 ; i < nSize; i++ )
	{
		pItemElem	= m_Inventory.GetAtId( i );
		if( pItemElem )
		{
			//raiders.06.05.02 (prevent abuse quest ending condition : trade & quest )
			if( IsUsableItem( pItemElem ) == FALSE )
				return 0;
			if( pItemElem->m_dwItemId == dwItemId )
				nNum	+= pItemElem->m_nItemNum;
		}
	}
	return nNum;
}

#ifdef __CLIENT
int CMover::GetItemNumForClient( DWORD dwItemId )
{
	int nNum	= 0;
	int nSize	= m_Inventory.GetMax();
	CItemElem* pItemElem;
	for( int i = 0 ; i < nSize; i++ )
	{
		pItemElem	= m_Inventory.GetAtId( i );
		if( pItemElem )
		{
			if( pItemElem->m_dwItemId == dwItemId )
				nNum	+= pItemElem->m_nItemNum;
		}
	}
	return nNum;
}
#endif //__CLIENT
#ifdef __WORLDSERVER
// ½ºÅ©¸³Æ®¿¡¼­ »ç¿ëÇÏ´Â ÇÔ¼ö
// Äù½ºÆ®¿¡¼­ ¾ÆÀÌÅÛÀ» Á¦°ÅÇÒ ¶§ »ç¿ëÇÑ´Ù. Äù½ºÆ® ¾ÆÀÌÅÛµéÀº °Å·¡³ª °³ÀÎ»óÁ¡¿¡ ¿Ã¸± ¼ö ¾ø±â ¶§¹®¿¡
// IsUsableItem°Ë»ç¸¦ ÇÏÁö ¾Ê´Â´Ù.
int CMover::RemoveItemA( DWORD dwItemId, short nNum )
{
	if( nNum == -1 )
	{
		return RemoveAllItem( dwItemId );
	}

	int	nSize	= m_Inventory.GetMax();
	CItemElem* pItemElem;
	short nRemnant	= nNum;

	for( int i = 0 ; i < nSize && nRemnant > 0; i++ )
	{
		pItemElem	= m_Inventory.GetAtId( i );
		if( pItemElem && pItemElem->m_dwItemId == dwItemId )
		{
			if( nRemnant > pItemElem->m_nItemNum )
			{
				UpdateItem( i, UI_NUM, 0 );	// remove
				nRemnant	-= pItemElem->m_nItemNum;
			}
			else
			{
				UpdateItem( i, UI_NUM, pItemElem->m_nItemNum - nRemnant );
				nRemnant	= 0;
			}
		}
	}
	return ( nNum - nRemnant );
}
#endif	// __WORLDSERVER

// ½ºÅ©¸³Æ®¿¡¼­ »ç¿ëÇÏ´Â ÇÔ¼ö 
int CMover::RemoveAllItem( DWORD dwItemId )
{
	int nNum = 0;
	int	nSize	= m_Inventory.GetMax();

	for( int i = 0 ; i < nSize; ++i )
	{
		CItemElem* pItemElem = m_Inventory.GetAtId( i );
		if( pItemElem && pItemElem->m_dwItemId == dwItemId )
		{
			nNum += pItemElem->m_nItemNum;
			UpdateItem( i, UI_NUM, 0 );		// remove
		}
	}
	return nNum;
}

void CMover::OnTradeRemoveUser()
{
	if( IsPlayer() )
	{
		CMover* pOther = m_vtInfo.GetOther();
		if( IsValidObj( pOther ) && pOther->IsPlayer() )
		{	
			if( pOther->m_vtInfo.GetOther() == this )
			{
				pOther->m_vtInfo.TradeClear();
			}
		}
		m_vtInfo.TradeClear();
	}
}

#ifdef __WORLDSERVER

void CMover::Abrade( CMover* pAttacker, int nParts )
{
#if __VER < 11 // __REMOVE_ENDURANCE
	if( NULL == pAttacker )
		return;

	if( pAttacker->IsPlayer() )
	{
		CItemElem* pWeapon	= pAttacker->GetWeaponItem( nParts );
		if( pWeapon == NULL )
			return;

		ItemProp* pWeaponProp	= pWeapon->GetProp();
		if( pWeaponProp == NULL )
			return;
		
		int nWpn = pWeapon->m_nHitPoint;
		pWeapon->m_nHitPoint	-= ( pWeaponProp->nAbrasion  / 5 ) * GetItemEnduranceWeight(0);			// µÚ¿¡¼­ Ãß°¡·Î ±ðÁö ¾Ê°í ¿©±â¼­ 2¹ø °öÇß´Ù.
		if( pWeapon->m_nHitPoint < 0 )		pWeapon->m_nHitPoint = 0;
		
		if( nWpn != pWeapon->m_nHitPoint )
			pAttacker->UpdateItem( pWeapon->m_dwObjId, UI_HP, pWeapon->m_nHitPoint );
		
		if( !IsPlayer() )	// PVP
			return;
		
		DWORD dwParts	= GetRandomPartsAbraded();
		CItemElem* pArmorElem	= m_Inventory.GetEquip( dwParts );
		if( pArmorElem )
		{
			ItemProp* pArmorProp		= pArmorElem->GetProp();
			if( pArmorProp && ( pArmorProp->dwItemKind2 == IK2_ARMOR || pArmorProp->dwItemKind2 == IK2_ARMORETC ))
			{
				int nArm = pArmorElem->m_nHitPoint;
				pArmorElem->m_nHitPoint		-= pArmorProp->nAbrasion * GetItemEnduranceWeight(0);
				if( pArmorElem->m_nHitPoint < 0 )	pArmorElem->m_nHitPoint	= 0;
				
				if( nArm != pArmorElem->m_nHitPoint )
					UpdateItem( pArmorElem->m_dwObjId, UI_HP, pArmorElem->m_nHitPoint );
			}
		}
	}
	else
	{
		if( !IsPlayer() )	// MVP
			return;

		DWORD dwParts	= GetRandomPartsAbraded();
		CItemElem* pArmorElem	= m_Inventory.GetEquip( dwParts );
		if( pArmorElem == NULL )
			return;
		
		ItemProp* pArmorProp		= pArmorElem->GetProp();
		if( pArmorProp && ( pArmorProp->dwItemKind2 == IK2_ARMOR || pArmorProp->dwItemKind2 == IK2_ARMORETC ) )
		{
			ItemProp* pWeaponProp	= pAttacker->GetActiveHandItemProp( nParts );
			if( pWeaponProp )
			{
				int nArm = pArmorElem->m_nHitPoint;
				pArmorElem->m_nHitPoint		-= pArmorProp->nAbrasion * GetItemEnduranceWeight(0);
				if( pArmorElem->m_nHitPoint < 0 )
					pArmorElem->m_nHitPoint	= 0;
				if( nArm != pArmorElem->m_nHitPoint )
					UpdateItem( pArmorElem->m_dwObjId, UI_HP, pArmorElem->m_nHitPoint );
			}
		}
	}
#endif // __REMOVE_ENDURANCE
}

DWORD CMover::GetRandomPartsAbraded( void )
{
//	½Çµå 50%
	int nRand	= xRand();
	if( nRand % 2 )
		return PARTS_SHIELD;
	nRand	= nRand % 100;
	if( nRand < 20 )	// 20%
		return PARTS_CAP;
	else if( nRand < 60 )	// 40%
		return PARTS_UPPER_BODY;
	else if( nRand < 85 )	// 25%
		return PARTS_HAND;
	else	// 15%
		return PARTS_FOOT;
}
#endif	// __WORLDSERVER



float CMover::GetItemEnduranceInfluence( int nEndurance )
{
	if( nEndurance == 0 )
		return 0.0f;
/*	else if( nEndurance <= 50 )
		return 0.6f;
	else if( nEndurance <= 75 )
		return 0.8f;
*/	return 1.0f;
}

int CMover::GetItemEnduranceWeight( int nEndurance )
{
	int nMinusMultyPly = 5;
/*	if( nEndurance <= 50 )
		return (int)3 * nMinusMultyPly;
	else if( nEndurance <= 75 )
		return (int)2 * nMinusMultyPly;
*/	return 1 * nMinusMultyPly;
}

#if __VER >= 11 // __SYS_IDENTIFY
void CMover::UpdateItemEx( unsigned char id, char cParam, __int64 iValue )
{
	CItemElem* pItemElem = (CItemElem*)GetItemId( id );

	if( pItemElem )
	{
		switch( cParam )
		{
			case UI_RANDOMOPTITEMID:
				{
					pItemElem->SetRandomOptItemId( iValue );
					break;
				}
			default:
				break;
		}
#ifdef __CLIENT
		CWndInventory* pWnd		= (CWndInventory*)g_WndMng.GetWndBase( APP_INVENTORY );
		if( pWnd )
		{
#ifdef __TABBED_INV
			int nIndex = 0;
			if (pItemElem && pItemElem->GetProp())
				nIndex = pItemElem->GetProp()->GetInvenIndex();
			pWnd->UpdateTooltip(nIndex);
#else // __TABBED_INV
			pWnd->UpdateTooltip();
#endif // __TABBED_INV
	}
#endif	// __CLIENT
	}
#ifdef __WORLDSERVER
	if( IsPlayer() )
		( (CUser*)this )->AddUpdateItemEx( id, cParam, iValue );
#endif
}
#endif	// __SYS_IDENTIFY

#ifdef __BAG_UPDATE
void CMover::UpdateItemBag(BYTE nId, CHAR cParam, DWORD dwValue, int nBag, DWORD dwTime)
{
	CItemBase* pItemBase = GetItemId2(nBag, nId);

	if (pItemBase)
	{
		switch (cParam)
		{
		case UI_COOLTIME:
		case UI_NUM:
		{
			if ((int)dwValue <= 0)
			{
				m_Pocket.RemoveAtId(nBag, nId, 1);
			}
			else
			{
				((CItemElem*)pItemBase)->m_nItemNum = (short)(dwValue);
			}
			break;
		}
		default:
			break;
		}
#ifdef __CLIENT
		CWndInventory* pWnd = (CWndInventory*)g_WndMng.GetWndBase(APP_INVENTORY);
		if (pWnd)
			pWnd->UpdateTooltip(0);
#endif	// __CLIENT
	}

#ifdef __WORLDSERVER
	if (IsPlayer())
	{
		static_cast<CUser*>(this)->AddUpdateItem(0, nId, cParam, dwValue, dwTime, nBag);
	}
#endif // __WORLDSERVER
}
#endif

#if __VER >= 15 // __PETVIS
void CMover::UpdateItem( BYTE nId, CHAR cParam, DWORD dwValue, DWORD dwTime )
#else // __PETVIS
void CMover::UpdateItem( BYTE nId, CHAR cParam, DWORD dwValue )
#endif // __PETVIS
{
	CItemBase* pItemBase = GetItemId( nId );

	if( pItemBase )
	{
		switch( cParam )
		{
			case UI_COOLTIME:
			case UI_NUM:
				{
					if( (int)dwValue <= 0 ) 
					{
						RemoveItemId( nId );
					}
					else 
					{
						( (CItemElem*)pItemBase )->m_nItemNum	= (short)( dwValue );
					}
					break;
				}
			case UI_HP:
				{
					( (CItemElem*)pItemBase )->m_nHitPoint	= dwValue;
					UpdateParam();
					break;
				}
			case UI_REPAIR_NUM:
				{
					( (CItemElem*)pItemBase )->m_nRepair	= dwValue;
					break;
				}
			case UI_RN:
				{
					if( ( (CItemElem*)pItemBase )->m_nRepairNumber >= 100 )
						return;
					if( dwValue > 100 )
						dwValue		= 100;
					( (CItemElem*)pItemBase )->m_nRepairNumber	= (BYTE)( dwValue );
					UpdateParam();
				}
				break;
				
			case UI_AO: // ¾ÆÀÌÅÛ + ¿Ã¸®±â...
				{
#if __VER >= 13 // __EXT_ENCHANT
					DWORD dwMax = 20;
#else // __EXT_ENCHANT
					DWORD dwMax	= 10;
#endif // __EXT_ENCHANT
#if __VER >= 11 // __SYS_COLLECTING
					if( ( (CItemElem*)pItemBase )->IsAccessory() )
						dwMax	= 20;
#endif	// __SYS_COLLECTING
#if __VER >= 11 // __SYS_IDENTIFY
					if( ( (CItemElem*)pItemBase )->IsCollector( TRUE ) )
						dwMax	= 5;
#endif	// __SYS_IDENTIFY
					if( ( (CItemElem*)pItemBase )->GetAbilityOption() > (int)( dwMax ) )
						return;
					if( dwValue > dwMax )
						dwValue		= dwMax;

					( (CItemElem*)pItemBase )->SetAbilityOption( dwValue );
					UpdateParam();
				}
				break;
			case UI_RAO: // ¾ÆÀÌÅÛ ¼Ó¼º + ¿Ã¸®±â...
				{
#if __VER >= 13 // __EXT_ENCHANT
					if( ( (CItemElem*)pItemBase )->m_nResistAbilityOption > 20 )
#else // __EXT_ENCHANT
					if( ( (CItemElem*)pItemBase )->m_nResistAbilityOption > 10 ) 
#endif // __EXT_ENCHANT
						return;
#if __VER >= 13 // __EXT_ENCHANT
					if( dwValue > 20 )
						dwValue		= 20;
#else // __EXT_ENCHANT
					if( dwValue > 10 )
						dwValue		= 10;
#endif // __EXT_ENCHANT
					( (CItemElem*)pItemBase )->m_nResistAbilityOption	= dwValue;
					UpdateParam();
				}
				break;
			case UI_IR:  // ¾ÆÀÌÅÛ¿¡ ¹«½¼¼Ó¼ºÀÎÁö ³Ö±â
				{
					( (CItemElem*)pItemBase )->m_bItemResist	= (BYTE)( dwValue );
					UpdateParam();
				}
				break;

			case UI_PIERCING_SIZE:
				( (CItemElem*)pItemBase )->SetPiercingSize( dwValue );
				break;
			case UI_PIERCING:
				{
					WORD wIndex	= LOWORD( dwValue ), wItemId	= HIWORD( dwValue );
					( (CItemElem*)pItemBase )->SetPiercingItem( wIndex, wItemId );
				}
				break;

#if __VER >= 12 // __EXT_PIERCING
			case UI_ULTIMATE_PIERCING_SIZE:
				( (CItemElem*)pItemBase )->SetUltimatePiercingSize( dwValue );
				break;
			case UI_ULTIMATE_PIERCING:
				{
					WORD wIndex	= LOWORD( dwValue ), wItemId	= HIWORD( dwValue );
					( (CItemElem*)pItemBase )->SetUltimatePiercingItem( wIndex, wItemId );
				}
				break;
#endif // __EXT_PIERCING

#if __VER >= 15 // __PETVIS
			case UI_PETVIS_SIZE:	
				{
					static_cast<CItemElem*>(pItemBase)->SetPiercingSize( dwValue );
					static_cast<CItemElem*>(pItemBase)->SetVisKeepTimeSize( dwValue );

#ifdef __CLIENT	//sun : ½ÇÃ¼ ºñ½º ÀåÂøÀÌ( ¼­¹ö·ÎºÎÅÍ ÆÐÅ¶À» ¹Þ¾Æ¼­ Ã³¸®µÉ¶§ )ÀÌ·ç¾îÁú¶§ È¿°úÀ½ Ãâ·Â 
					PLAYSND(SND_INF_EQUIPACCESSORY, &g_pPlayer->GetPos());
#endif // __CLIENT
				}
				break;
			case UI_PETVIS_ITEM:
				{
					WORD wIndex	= LOWORD( dwValue ), wItemId	= HIWORD( dwValue );
					static_cast<CItemElem*>(pItemBase)->SetPiercingItem( wIndex, wItemId );
					static_cast<CItemElem*>(pItemBase)->SetVisKeepTime( wIndex, ( dwTime * 60 ) + time_null() ); // ºÐ´ÜÀ§ ½Ã°£À» ÃÊ´ÜÀ§·Î º¯°æ

#ifdef __CLIENT
					PLAYSND(SND_INF_EQUIPACCESSORY, &g_pPlayer->GetPos());
#endif // __CLIENT
				}
				break;

			case UI_PETVIS_ITEMSWAP:
				{
					WORD wPos1	= LOWORD( dwValue ), wPos2	= HIWORD( dwValue );
					static_cast<CItemElem*>(pItemBase)->SetSwapVisItem( wPos1, wPos2 );

#ifdef __CLIENT
					PLAYSND(SND_INF_EQUIPACCESSORY, &g_pPlayer->GetPos());
#endif // __CLIENT
				}
				break;

			case UI_TRANSFORM_VISPET:
				{
					static_cast<CItemElem*>(pItemBase)->m_bTranformVisPet = static_cast<BOOL>( dwValue );
					static_cast<CItemElem*>(pItemBase)->m_bCharged = TRUE;
				}
				break;
#endif // __PETVIS

			case UI_RANDOMOPTITEMID:
				{
					( (CItemElem*)pItemBase )->SetRandomOpt( dwValue );
					break;
				}
			case UI_KEEPTIME:	// offset
				{
					CTime tm	= CTime::GetCurrentTime() + CTimeSpan( 0, 0, dwValue, 0 );
					( (CItemElem*)pItemBase )->m_dwKeepTime	= (DWORD)( tm.GetTime() );
					break;
				}

			case UI_FLAG:
				{
#ifdef __CLIENT
					DWORD dwObjIndex	= (DWORD)(short)LOWORD( dwValue );
					BYTE byFlag		= (BYTE)HIWORD( dwValue );
					int nParts	= dwObjIndex - m_Inventory.GetSize();
					if( nParts >= 0 && nParts < MAX_HUMAN_PARTS )
						m_aEquipInfo[nParts].byFlag	= byFlag;
					( (CItemElem*)pItemBase )->m_byFlag		= byFlag;
					UpdateParts( FALSE );
#endif	// __CLIENT
					UpdateParam();
					break;
				}
#ifdef __WEAPON_RARITY
			case UI_WEAPON_RARITY:
			{
				((CItemElem*)pItemBase)->SetWeaponRarity(dwValue);
				break;
			}
#endif // __WEAPON_RARITY
#ifdef __SWITCH_GLOW_OLDNEW
			case UI_CHANGE_GLOWOLD:
			{
				((CItemElem*)pItemBase)->m_bGlowOld = (BOOL)dwValue;
				break;
			}
#endif // __SWITCH_GLOW_OLDNEW
			default:
				break;
		}
#if __VER >= 9 // __CSC_VER9_1
#ifdef __CLIENT
		CWndInventory* pWnd	= (CWndInventory*)g_WndMng.GetWndBase( APP_INVENTORY );
		if( pWnd )
		{
#ifdef __TABBED_INV
			int nIndex = 0;
			if (pItemBase && pItemBase->GetProp())
				nIndex = pItemBase->GetProp()->GetInvenIndex();
			pWnd->UpdateTooltip(nIndex);
#else // __TABBED_INV
			pWnd->UpdateTooltip();
#endif // __TABBED_INV
		}

// 		CWndInventory* pWnd	= (CWndInventory*)g_WndMng.GetWndBase( );		
// 		if( pWnd )
// 			pWnd->UpdateTooltip();
#endif	// __CLIENT
#endif	// __CSC_VER9_1
	}
	else
	{
		switch( cParam )
		{
			case UI_FLAG:
				{
#ifdef __CLIENT
					DWORD dwObjIndex	= (DWORD)(short)LOWORD( dwValue );
					BYTE byFlag		= (BYTE)HIWORD( dwValue );
					int nParts	= dwObjIndex - m_Inventory.GetSize();
					if( nParts >= 0 && nParts < MAX_HUMAN_PARTS )
					{
						m_aEquipInfo[nParts].byFlag	= byFlag;
						UpdateParts( TRUE );
					}
#endif	// __CLIENT
					break;
				}
			default:
				break;
		}
	}
#ifdef __WORLDSERVER
	if( IsPlayer() )
#if __VER >= 15 // __PETVIS
	{
		static_cast<CUser*>( this )->AddUpdateItem( 0, nId, cParam, dwValue, dwTime );
		if( pItemBase && cParam == UI_TRANSFORM_VISPET && HasActivatedEatPet() )
		{
			InactivateEatPet();
			ActivateEatPet( static_cast<CItemElem*>( pItemBase ) );
		}
	}
#else // __PETVIS
		( (CUser*)this )->AddUpdateItem( 0, nId, cParam, dwValue );
#endif // __PETVIS
#endif // __WORLDSERVER
}

float CMover::GetItemDropRateFactor( CMover* pAttacker )
{
	float fFactor	= 1.0F;
#ifdef __WORLDSERVER
	fFactor		*= prj.m_fItemDropRate;
#ifdef __S1108_BACK_END_SYSTEM
	fFactor		*= GetProp()->m_fItemDrop_Rate;
#endif // __S1108_BACK_END_SYSTEM
#ifdef __ITEMDROPRATE
	fFactor		*= CEventGeneric::GetInstance()->GetItemDropRateFactor();
#endif // __ITEMDROPRATE
#if __VER >= 9 // __EVENTLUA
	fFactor		*= prj.m_EventLua.GetItemDropRate();
#endif // __EVENTLUA
#endif	// __WORLDSERVER
	return fFactor;
}

float CMover::GetPieceItemDropRateFactor( CMover* pAttacker )
{
	float fFactor	= 1.0F;
#ifdef __WORLDSERVER
#if __VER >= 9 // __EVENTLUA
	fFactor		*= prj.m_EventLua.GetPieceItemDropRate();
#endif // __EVENTLUA
#if __VER >= 12 // __LORD
	ILordEvent* pEvent		= CSLord::Instance()->GetEvent();
	fFactor		*= pEvent->GetIFactor();
	if( pAttacker->HasBuff( BUFF_ITEM, II_SYS_SYS_LS_CHEERING ) )
		fFactor		*=	1.1F;
	if( pAttacker->HasBuff( BUFF_ITEM, II_SYS_SYS_VOTE_THANKS ) )
		fFactor		*= 1.05F;
#endif	// __LORD
#if __VER >= 13 // __COUPLE_1202
	if( pAttacker->HasBuff( BUFF_ITEM, II_COUPLE_BUFF_MIRACLE_01 ) )
		fFactor	*= 1.05F;
#endif	// __COUPLE_1202
#if __VER >= 14 // __PCBANG
	if( pAttacker->IsPlayer() )
		fFactor *= CPCBang::GetInstance()->GetPieceItemDropFactor( static_cast<CUser*>( pAttacker ) );
#endif // __PCBANG

#endif // __WORLDSERVER
	return fFactor;
}

float CMover::GetExpFactor( void )
{
	float fFactor	= 1.0f;
	if( IsMode( EVENT_OLDBOY_MODE ) )
		fFactor	*= 1.1f;

	BOOL bGlvCheer	= FALSE;
	BOOL bSpecial = FALSE;
#ifndef __NEW_STACKABLE_AMPS
	int nCountBuf = 0;
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESA ) )
		++nCountBuf;
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESA1 ) )
		++nCountBuf;
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESA2 ) )
		++nCountBuf;
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESB ) )
		++nCountBuf;
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESB1 ) )
		++nCountBuf;
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESB2 ) )
		++nCountBuf;
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESC ) )
		++nCountBuf;
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESC1 ) )
		++nCountBuf;
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESC2 ) )
		++nCountBuf;
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESD ) )
		++nCountBuf;
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESD1 ) )
		++nCountBuf;
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESD2 ) )
		++nCountBuf;
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESE ) )
		++nCountBuf;
#ifdef __S_ADD_EXP
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESS ) )
	{
		++nCountBuf;	bSpecial = TRUE;
	}
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESS1 ) )
	{
		++nCountBuf;	bSpecial = TRUE;
	}
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESS2 ) )
	{
		++nCountBuf;	bSpecial = TRUE;
	}
#endif // __S_ADD_EXP

	int nLevel = GetLevel();
	if( nCountBuf == 1 )
	{
		fFactor *= 1.5f;
	}
	else if( nCountBuf == 2 )
	{
		if( bSpecial || nLevel < 61 )
			fFactor *= 2.0f;
		else
			fFactor *= 1.5f;
	}
	else if( 3 <= nCountBuf )
	{
		if( bSpecial || nLevel < 41 )
			fFactor *= 2.5f;
		else if( nLevel < 61 )
			fFactor *= 2.0f;
		else
			fFactor *= 1.5f;
	}

	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPES ) )
		fFactor	*= 1.5f;
	
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPEM ) )
		fFactor	*= 2.0f;
#else // __NEW_STACKABLE_AMPS

	int nLevel = GetLevel();
	int nExtraEXP = 0;

	for( MAPBUFF::iterator i = m_buffs.m_mapBuffs.begin(); i != m_buffs.m_mapBuffs.end(); ++i )
	{
		ItemProp* pItemProp = prj.GetItemProp( i->second->GetId());

		if( pItemProp )
		{
			if( pItemProp->dwItemKind3 == IK3_EXP_RATE )
			{
				if( nLevel >= pItemProp->nMinLimitLevel && nLevel <= pItemProp->nMaxLimitLevel )
				{
					nExtraEXP += pItemProp->nEffectValue;
				}
			}
		}
	}
	fFactor *= 1.0f + ((float)nExtraEXP / 100 );

#endif // __NEW_STACKABLE_AMPS
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_GLVCHEER ) )
	{
		bGlvCheer	= TRUE;
		fFactor	*= 1.10f;
	}

	if( !bGlvCheer && HasBuff( BUFF_ITEM, II_CHEERUP ) )
	{
#ifdef __EVENTLUA_CHEEREXP
		if( prj.m_EventLua.GetCheerExpFactor() > 1.05f )
			fFactor *= prj.m_EventLua.GetCheerExpFactor();
		else
#endif // __EVENTLUA_CHEEREXP
			fFactor	*= 1.05f;
	}

#ifdef __WORLDSERVER

	fFactor	*= CEventGeneric::GetInstance()->GetExpFactor();
#if __VER >= 9 // __EVENTLUA
	fFactor	*= prj.m_EventLua.GetExpFactor();
#endif // __EVENTLUA
	fFactor		*= prj.m_fMonsterExpRate;
#if __VER >= 9 // __ULTIMATE
	int nDstExp = GetParam( DST_EXPERIENCE, 0 );
	if( 0 < nDstExp )
		fFactor *= ( 1.0f + ( nDstExp / 100.0f ) );
#endif // __ULTIMATE
#if __VER >= 12 // __LORD
	ILordEvent* pEvent		= CSLord::Instance()->GetEvent();
	fFactor		*= pEvent->GetEFactor();
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_LS_CHEERING ) )
		fFactor		*=	1.1F;
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_VOTE_THANKS ) )
		fFactor		*=	1.05F;
#endif	// __LORD

#ifdef __ENVIRONMENT_EFFECT

	if( CEnvironment::GetInstance()->GetEnvironmentEffect() == TRUE )
	{
		fFactor *= prj.m_EventLua.GetWeatherEventExpFactor();
	}

#else // __ENVIRONMENT_EFFECT

#ifdef __EVENTLUA_RAIN
	if( g_Environment.m_bRain )
		fFactor *= prj.m_EventLua.GetRainEventExpFactor();
#else // __EVENTLUA_RAIN
#ifdef __RAIN_EVENT
	if( g_Environment.m_bRain )
		fFactor *= 2.0f;
#endif // __RAIN_EVENT
#endif // __EVENTLUA_RAIN
#ifdef __EVENTLUA_SNOW
	if( g_Environment.m_bSnow )
		fFactor *= prj.m_EventLua.GetSnowEventExpFactor();
#endif // __EVENTLUA_SNOW

#endif // __ENVIRONMENT_EFFECT

#endif	// __WORLDSERVER

	return fFactor;
}

#ifdef __SKILL0517
int	CMover::GetSkillLevel( SKILL* pSkill )
{
	if( !pSkill )
		return 0;
	ItemProp* pSkillProp	= prj.GetSkillProp( pSkill->dwSkill );
	if( pSkillProp )
	{
		DWORD dwSkillLevel	= (DWORD)GetParam( DST_SKILL_LEVEL, pSkill->dwLevel );
		return(  dwSkillLevel > pSkillProp->dwExpertMax? pSkillProp->dwExpertMax: dwSkillLevel );
	}
	return 0;
}
#endif	// __SKILL0517
```
