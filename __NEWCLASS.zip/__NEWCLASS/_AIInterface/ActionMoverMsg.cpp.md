# ActionMoverMsg.cpp

Chemin original: `C:\Users\rdiff\Desktop\__NEWCLASS\_AIInterface\ActionMoverMsg.cpp`
Chemin relatif: `_AIInterface\ActionMoverMsg.cpp`
Nom du fichier: `ActionMoverMsg.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `cp1252`

```cpp
#include "stdafx.h"
#include "defineObj.h"
#include "defineSkill.h"
#include "ActionMover.h"
#include "ErrorCode.h"
#include "party.h"

#ifdef __CLIENT
	#include "DPClient.h"
#else
	#include "user.h"
	#include "dpcoreclient.h"
	#include "dpdatabaseclient.h"
	#include "..\_AIInterface\AIInterface.h"
#endif	

#if __VER >= 12 // __NEW_ITEMCREATEMON_SERVER
#include "CreateMonster.h"
#endif // __NEW_ITEMCREATEMON_SERVER

#ifdef __MOUNT
#include "Mover.h"
#endif // __MOUNT

extern	CPartyMng	g_PartyMng;

#ifdef __CLIENT
	extern	CDPClient	g_DPlay;
#else
	extern	CUserMng			g_UserMng;
	extern	CDPDatabaseClient	g_dpDBClient;
	extern	CDPCoreClient		g_DPCoreClient;
#endif 

// ÇöÀç »óÅÂ¸¦ ¹«½ÃÇÏ°í »õ·Î¿î µ¿ÀÛÀ¸·Î °­Á¦ ¼¼ÆÃ.
// ¼­¹ö¿Í µ¿±âÈ­ ÇÒ¶§¿Ü¿£ »ç¿ëÇÏÁö ¸»°Í.
void	CActionMover::ForcedSet( D3DXVECTOR3 &vDelta, DWORD dwState, DWORD dwStateFlag, int nMotionEx )
{
	if( ( GetStateFlag() & OBJSTAF_FLY ) == 0 && ( dwStateFlag & OBJSTAF_FLY ) )
		return;
	if( ( GetStateFlag() & OBJSTAF_FLY ) && ( dwStateFlag & OBJSTAF_FLY ) == 0 )
		return;
	if( ( GetStateFlag() & OBJSTAF_SIT ) == 0 && ( dwStateFlag & OBJSTAF_SIT ) )
		return;
	if( ( GetStateFlag() & OBJSTAF_SIT ) && ( dwStateFlag & OBJSTAF_SIT ) == 0 )
		return;

	m_vDelta = vDelta;
	__ForceSetState( dwState );	// ¿©±â ÀÌ¿Ü¿£ ÀÌÇÔ¼ö »ç¿ëÇÏÁö ¸»°Í.
			
	ClearStateFlag();
	AddStateFlag( dwStateFlag );

	if( (GetStateFlag() & OBJSTAF_SIT) && ((dwState & OBJSTA_MOVE_ALL) != OBJSTA_SIT) )	// IsSit()ÀÎµ¥
		Error( "ForcedSet : dwState=0x%08x, dwStateFlag=0x%08x", GetState(), GetStateFlag() );
	else if( (GetStateFlag() & OBJSTAF_SIT) == 0 && ((dwState & OBJSTA_MOVE_ALL) == OBJSTA_SIT) )	// IsSit()¾Æ´Ñµ¥ SITÀÌ¸é
		Error( "ForcedSet : dwState=0x%08x, dwStateFlag=0x%08x", GetState(), GetStateFlag() );

	m_nMotionEx = nMotionEx;
	DefaultSet();
}

void	CActionMover::ForcedSet2( D3DXVECTOR3 &vDelta, float fAccPower, float fTurnAngle, DWORD dwState, DWORD dwStateFlag, int nMotionEx )
{
	if( ( GetStateFlag() & OBJSTAF_FLY ) == 0 && ( dwStateFlag & OBJSTAF_FLY ) )
		return;
	if( ( GetStateFlag() & OBJSTAF_FLY ) && ( dwStateFlag & OBJSTAF_FLY ) == 0 )
		return;

	m_vDelta = vDelta;
	m_fAccPower	= fAccPower;
	m_fTurnAngle	= fTurnAngle;
	__ForceSetState( dwState );
	ClearStateFlag();
	AddStateFlag( dwStateFlag );
	m_nMotionEx = nMotionEx;
	DefaultSet();
	if( (GetStateFlag() & OBJSTAF_SIT) && (dwState != OBJSTA_SIT))	// IsSit()ÀÎµ¥
		Error( "ForcedSet2 : dwState=0x%08x, dwStateFlag=0x%08x", GetState(), GetStateFlag() );
	else if( (GetStateFlag() & OBJSTAF_SIT) == 0 && (dwState == OBJSTA_SIT) )	// IsSit()¾Æ´Ñµ¥ SITÀÌ¸é
		Error( "ForcedSet2 : dwState=0x%08x, dwStateFlag=0x%08x", GetState(), GetStateFlag() );
}

void CActionMover::HalfForcedSet( D3DXVECTOR3 & vd, float fAccPower, float fTurnAngle )
{
	m_vDelta	 = vd;
	m_fAccPower	 = fAccPower;
	m_fTurnAngle = fTurnAngle;
	DefaultSet();
}

void	CActionMover::DefaultSet( void )
{
	m_pMover->m_fCrrSpd	= 0.0f;
}

//
//	Action Message Process
//	¾×¼Ç ¸Þ½ÃÁö¸¦ ¹Þ¾Æ Ã³¸®ÇÑ´Ù.
//	¾î¶² ÇàÀ§°¡ ¹ß»ýÇÏ´Â ½ÃÁ¡¿¡ ´ëÇÑ Ã³¸®¸¦ ´ã´ç.
//	ÃÖÀûÈ­¸¦ À§ÇØ¼­ ÀÌ¹Ì ¼³Á¤µÇ¾î ÀÖ´Â »óÅÂ¸é Áßº¹ Ã³¸® ÇÏÁö ¾ÊÀ½
//
#ifdef __NO_HP_DMG_LIMIT
int		CActionMover::ProcessActMsg1(CMover* pMover, OBJMSG dwMsg, long long nParam1, long long nParam2, long long nParam3, long long nParam4, long long nParam5)
#else
int		CActionMover::ProcessActMsg1(CMover* pMover, OBJMSG dwMsg, int nParam1, int nParam2, int nParam3, int nParam4, int nParam5)
#endif
{
#ifdef __SECURITY_FIXES
	if (IsInvalidObj(pMover))
		return -1;
#endif // __SECURITY_FIXES
	CModelObject* pModel = (CModelObject*)pMover->m_pModel;

	switch( dwMsg )
	{
	// ÆòÈ­¸ðµå Á¦ÀÚ¸®¿¡ ¼­ÀÖ¾î¶ó!
	case OBJMSG_STAND:
#ifdef __Y_INTERFACE_VER3
		if( (GetMoveState() == OBJSTA_FMOVE) || (GetMoveState() == OBJSTA_BMOVE) || (GetMoveState() == OBJSTA_LMOVE) || (GetMoveState() == OBJSTA_RMOVE) )	// Àü/ÈÄÁøÁßÀÏ¶§ Á¦ÀÚ¸®¿¡ ¼¼¿î´Ù.
#else //__Y_INTERFACE_VER3
		if( (GetMoveState() == OBJSTA_FMOVE) || (GetMoveState() == OBJSTA_BMOVE) )	// Àü/ÈÄÁøÁßÀÏ¶§ Á¦ÀÚ¸®¿¡ ¼¼¿î´Ù.
#endif //__Y_INTERFACE_VER3
		{
			ResetState( OBJSTA_MOVE_ALL );		
			m_vDelta.x = m_vDelta.z = 0;
			if( pMover->IsFlyingNPC() )
			{
				m_vDelta.y = 0;
				pMover->SetAngleX(0);
			}
		}

		if( GetMoveState() == OBJSTA_STAND )	return 0;
		if( GetMoveState() == OBJSTA_PICKUP )	return 0;
		if( IsActJump() )		return -1;
		if( IsActAttack() )		return -2;
		if( IsActDamage() )		return -3;
		if( IsDie() )			return -4;
		if( IsAction() )		return 0;
		SetMoveState( OBJSTA_STAND );
		pMover->SetMotion( MTI_STAND );
		RemoveStateFlag( OBJSTAF_ETC );
		break;
	case OBJMSG_STOP:		
	case OBJMSG_ASTOP:
	#ifdef __Y_INTERFACE_VER3
		if( (GetMoveState() == OBJSTA_FMOVE) || (GetMoveState() == OBJSTA_BMOVE) || (GetMoveState() == OBJSTA_LMOVE) || (GetMoveState() == OBJSTA_RMOVE) )	// Àü/ÈÄÁøÁßÀÏ¶§ Á¦ÀÚ¸®¿¡ ¼¼¿î´Ù.
	#else //__Y_INTERFACE_VER3
		if( (GetMoveState() == OBJSTA_FMOVE) || (GetMoveState() == OBJSTA_BMOVE) )	// Àü/ÈÄÁøÁßÀÏ¶§ Á¦ÀÚ¸®¿¡ ¼¼¿î´Ù.
	#endif //__Y_INTERFACE_VER3
		{
			ResetState( OBJSTA_MOVE_ALL );		
			m_vDelta.x = m_vDelta.z = 0;
			if( pMover->IsFlyingNPC() )
			{
				m_vDelta.y = 0;
				pMover->SetAngleX(0);
			}
		}
		pMover->ClearDest();
		return 0;	// ControlGround¿¡¼­ Å°ÀÔ·Â¾øÀ»¶§ STOPÀ» ºÎ¸£´Âµ¥ °Å±â¼­ ¸®ÅÏ°ªÀ» ¸ÂÃß±â À§ÇØ ÀÌ·¸°Ô ÇßÀ½. 
		break;
	case OBJMSG_SITDOWN:
		if( GetStateFlag() & OBJSTAF_SIT )	return 0;		// ÀÌ¹Ì ¾ÉÀº¸ðµå¸é ¸®ÅÏ - ÇÃ·¡±×·Î °Ë»çÇÏÁö ¸»°í state·Î Á÷Á¢°Ë»çÇÏÀÚ.

		if( nParam3 == 0 )
		{
			if( IsActJump() )	return 0;
			if( IsActAttack() )	return 0;
			if( IsActDamage() )	return 0;
			if( IsAction() )	return 0;
		#ifdef __CLIENT
			if( pMover->IsActiveMover() && (pMover->m_dwReqFlag & REQ_USESKILL) )	return 0;		// ¼­¹ö·ÎºÎÅÍ useskillÀÀ´äÀÌ ¿À±âÀü±îÁø ¾×¼ÇÇØ¼± ¾ÈµÊ.
		#endif	// __CLIENT
		}
		AddStateFlag( OBJSTAF_SIT );		
		SendActMsg( OBJMSG_STOP );
		pMover->SetMotion( MTI_SIT, ANILOOP_CONT );		// ¾É±â ¸ð¼Ç½ÃÀÛ
		SetMoveState( OBJSTA_SIT );
		break;
	case OBJMSG_STANDUP:
		if( (GetStateFlag() & OBJSTAF_SIT) == 0 )	return 0;	

		if( nParam3 == 0 )
		{
			if( IsActJump() )	return 0;
			if( IsActAttack() )	return 0;
			if( IsActDamage() )	return 0;
			if( IsAction() )	return 0;
#ifdef __CLIENT
			if( pMover->IsActiveMover() && (pMover->m_dwReqFlag & REQ_USESKILL) )	return 0;		// ¼­¹ö·ÎºÎÅÍ useskillÀÀ´äÀÌ ¿À±âÀü±îÁø ¾×¼ÇÇØ¼± ¾ÈµÊ.
#endif	// __CLIENT
		}
		SetMoveState( OBJSTA_SIT );
		AddStateFlag( OBJSTAF_SIT );		 
		pMover->SetMotion( MTI_GETUP, ANILOOP_CONT );
		break;
	case OBJMSG_PICKUP:
		if( IsSit() )	return 0;
		if( IsAction() )	return 0;
		if( IsActJump() )	return 0;
		if( IsActAttack() )	return 0;
		if( IsActDamage() )	return 0;
#ifdef __CLIENT
		if( pMover->IsActiveMover() )
		{
			if( pMover->m_dwReqFlag & REQ_USESKILL )	return 0;		// ¼­¹ö·ÎºÎÅÍ useskillÀÀ´äÀÌ ¿À±âÀü±îÁø ¾×¼ÇÇØ¼± ¾ÈµÊ.
			if( pMover->m_dwReqFlag & REQ_MOTION )		return 0;	// ¼­¹ö·ÎºÎÅÍ ¸ð¼Ç ÀÀ´äÀÌ ¿À±âÀü±îÁö ¾×¼Ç ±ÝÁö.
		}
#endif	// __CLIENT
		if( GetMoveState() == OBJSTA_PICKUP )	return 0;	// ÀÌ¹Ì Áý°í ÀÖÀ¸¸é Ãß°¡·Î ½ÇÇàµÇÁö ¾Ê°Ô .
		SetMoveState( OBJSTA_PICKUP );
		pMover->SetMotion( MTI_PICKUP, ANILOOP_1PLAY, MOP_FIXED );
		break;

	case OBJMSG_COLLECT:
		
		//if( IsSit() )		return 0;
		//if( IsAction() )	return 0;
		//if( IsActJump() )	return 0;
		//if( IsActAttack() )	return 0;
		//if( IsActDamage() )	return 0;
		//SetState( OBJSTA_ACTION_ALL, OBJSTA_COLLECT );
		//pMover->SetMotion( MTI_COLLECT, ANILOOP_LOOP, MOP_FIXED );
		//pMover->RemoveInvisible();
		
		// Ë¬	// Ã¤Áý
		ClearState();
		ResetState( OBJSTA_ACTION_ALL );
		SetState( OBJSTA_ACTION_ALL, OBJSTA_COLLECT );
		pMover->m_dwFlag |= MVRF_NOACTION;
		pMover->SetMotion( MTI_COLLECT, ANILOOP_LOOP, MOP_FIXED );
		pMover->RemoveInvisible();
		break;

	case OBJMSG_STUN:
		SetState( OBJSTA_ACTION_ALL, OBJSTA_STUN );		// ½ºÅÏÀº ¾î¶² »óÅÂ¿¡¼­µµ °É¸± ¼ö ÀÖÀ¸´Ï »óÅÂ´Â ¹«Á¶°Í ¼¼ÆÃÇÏÀÚ.
		pMover->m_dwFlag |= MVRF_NOACTION;				// ¾×¼Ç ±ÝÁö »óÅÂ·Î ÀüÈ¯.
		pMover->m_wStunCnt = (short)nParam1;			// ¾ó¸¶µ¿¾ÈÀÌ³ª ½ºÅÏ»óÅÂ°¡ µÇ´À³Ä.

		if( GetState() == OBJSTA_STAND )
			pMover->SetMotion( MTI_GROGGY, ANILOOP_LOOP, MOP_FIXED );		// ¾Æ¹«°Íµµ ¾ÈÇÏ´Â ½ºÅÄµù »óÅÂ¸é ½ºÅÏ ¸ð¼Ç ³»ÀÚ.
		break;

	case OBJMSG_FALL:
		if( IsActJump() )	return 0;

		// ¹«ÀûÀÌ¸é ¿©±â¼­ ¸®ÅÏ.
#ifdef __GAMEGUARD
		if ((pMover->m_dwMode & MATCHLESS_MODE) && pMover->IsAuthHigher(AUTH_GAMEMASTER2))		// ¹«ÀûÀÌ¸é ¿©±â¼­ ¸®ÅÏ.
#else // __GAMEGUARD
		if (pMover->m_dwMode & MATCHLESS_MODE)		// ¹«ÀûÀÌ¸é ¿©±â¼­ ¸®ÅÏ.
#endif // __GAMEGUARD
		{
			return 0;
		}
		
#ifdef __NEWCLASS
		if (pMover->HasBuff(BUFF_SKILL, SI_LORDT_U_SKILL_04) && pMover->GetJob() == JOB_LORDTEMPLER_HERO_ULTIMATE)
		{
			return 0;
		}
#endif // __NEWCLASS

		pMover->m_dwFlag |= MVRF_NOACTION;				// ¾×¼Ç ±ÝÁö »óÅÂ·Î ÀüÈ¯.
		
		if( GetState() != OBJSTA_DMG_FLY )
		{
			SetState( OBJSTA_DMG_ALL, OBJSTA_DMG_FLY );	
			pMover->SetMotion( MTI_DMGFLY, ANILOOP_LOOP, MOP_FIXED );
		}
		break;
		
	// ÀüÁøÇØ¶ó!
	case OBJMSG_TURNMOVE:
		if( GetMoveState() == OBJSTA_FMOVE && (int)pMover->GetAngle() == nParam1 )	return 0;	// ÀüÁø »óÅÂÀÌ¸ç °¢µµ°¡ °°À¸¸é ¸Þ½ÃÁö ¹«È¿ 
		if( pMover->m_dwFlag & MVRF_NOMOVE )	
			return 0;		// ÀÌµ¿±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pMover->GetAdjParam( DST_CHRSTATE ) & CHS_LOOT)			return 0;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		
		if( GetState() & OBJSTA_DMG_FLY_ALL )	// ³¯¶ó°¡´Â µ¿ÀÛÁßÀÌ¸é Ãë¼Ò
			return 0;
		
		if( IsActAttack() )		return -2;
		if( GetDmgState() == OBJSTA_DMG )	// ÇÇ°Ý Áß ¸í·ÉÀÌ¸é ÇÇ°Ý »óÅÂ¸¦ Å¬¸®¾î ½ÃÅ²´Ù.
			ResetState( OBJSTA_DMG_ALL );
		else if( GetState() & OBJSTA_DMG_ALL )	// ±×¿Ü ÇÇ°Ýµ¿ÀÛÀº ´Ù Ãë¼Ò
			return -3;
		pMover->SetAngle( (float)nParam1 );
		if( pMover->IsFlyingNPC() )
			pMover->SetAngleX( (float)nParam2 );
		SendActMsg( OBJMSG_STOP_TURN );
		SendActMsg( OBJMSG_FORWARD );
		break;
	case OBJMSG_TURNMOVE2:
		if( GetMoveState() == OBJSTA_FMOVE && (int)pMover->GetAngle() == nParam1 )	return 0;	// ÀüÁø »óÅÂÀÌ¸ç °¢µµ°¡ °°À¸¸é ¸Þ½ÃÁö ¹«È¿ 
		if( pMover->m_dwFlag & MVRF_NOMOVE )	return 0;		// ÀÌµ¿±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pMover->GetAdjParam( DST_CHRSTATE ) & CHS_LOOT)			return 0;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

		if( IsAction() )	return 0;

		if( GetState() & OBJSTA_DMG_FLY_ALL )	// ³¯¶ó°¡´Â µ¿ÀÛÁßÀÌ¸é Ãë¼Ò
			return 0;

		if( IsActJump() )	return -1;	// Á¡ÇÁ°Å³ª °ø°Ý »óÅÂ¸é ¸Þ½ÃÁö ¹«È¿ Ã³¸®
		if( IsActAttack() )		return -2;
		if( GetDmgState() == OBJSTA_DMG )	// ÇÇ°Ý Áß ¸í·ÉÀÌ¸é ÇÇ°Ý »óÅÂ¸¦ Å¬¸®¾î ½ÃÅ²´Ù.
			ResetState( OBJSTA_DMG_ALL );
		else if( GetState() & OBJSTA_DMG_ALL )	// ±×¿Ü ÇÇ°Ýµ¿ÀÛÀº ´Ù Ãë¼Ò
			return -3;
		pMover->SetAngle( (float)nParam1 );
		if( pMover->IsFlyingNPC() )
			pMover->SetAngleX( (float)nParam2 );
		SendActMsg( OBJMSG_STOP_TURN );
		SendActMsg( OBJMSG_BACKWARD );
		break;

#ifdef __Y_INTERFACE_VER3
	case OBJMSG_LFORWARD:
		if( IsActJump() )	return -1;
		if( IsActAttack() )		return -2;
		if( GetDmgState() == OBJSTA_DMG )	// ÇÇ°Ý Áß ¸í·ÉÀÌ¸é ÇÇ°Ý »óÅÂ¸¦ Å¬¸®¾î ½ÃÅ²´Ù.
			ResetState( OBJSTA_DMG_ALL );
		else
			if( GetState() & OBJSTA_DMG_ALL )	// ±×¿Ü ÇÇ°Ýµ¿ÀÛÀº ´Ù Ãë¼Ò
				return -3;
		if( GetMoveState() == OBJSTA_LMOVE )	return 0;	// ÀÌ¹Ì ÀüÁø»óÅÂ¸é Ãß°¡·Î Ã³¸® ÇÏÁö ¾ÊÀ½
		if( IsSit() )		return 0;		// ¸®ÅÏ 0À¸·Î ÇØµµ µÇ³ª?.
		if( pMover->m_dwFlag & MVRF_NOMOVE )	return 0;		// ÀÌµ¿±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pMover->GetAdjParam( DST_CHRSTATE ) & CHS_LOOT)			return 0;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

		SetMoveState( OBJSTA_LMOVE );
		if( IsStateFlag( OBJSTAF_WALK ) )	// °È´Â¸ðµå
		{
			pMover->SetMotion( MTI_WALK );		// ÀüÅõ¸ðµå·Î °È±â
		} 
		else
		{
			if( pMover->SetMotion( MTI_RUN ) )
				pModel->SetMotionBlending( TRUE );
		}
		break;
	case OBJMSG_RFORWARD:
		if( IsActJump() )	return -1;
		if( IsActAttack() )		return -2;
		if( GetDmgState() == OBJSTA_DMG )	// ÇÇ°Ý Áß ¸í·ÉÀÌ¸é ÇÇ°Ý »óÅÂ¸¦ Å¬¸®¾î ½ÃÅ²´Ù.
			ResetState( OBJSTA_DMG_ALL );
		else
			if( GetState() & OBJSTA_DMG_ALL )	// ±×¿Ü ÇÇ°Ýµ¿ÀÛÀº ´Ù Ãë¼Ò
				return -3;
		if( GetMoveState() == OBJSTA_RMOVE )	return 0;	// ÀÌ¹Ì ÀüÁø»óÅÂ¸é Ãß°¡·Î Ã³¸® ÇÏÁö ¾ÊÀ½
		if( IsSit() )		return 0;		// ¸®ÅÏ 0À¸·Î ÇØµµ µÇ³ª?.
		if( pMover->m_dwFlag & MVRF_NOMOVE )	return 0;		// ÀÌµ¿±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pMover->GetAdjParam( DST_CHRSTATE ) & CHS_LOOT)			return 0;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

		SetMoveState( OBJSTA_RMOVE );
		if( IsStateFlag( OBJSTAF_WALK ) )	// °È´Â¸ðµå
		{
			pMover->SetMotion( MTI_WALK );		// ÀüÅõ¸ðµå·Î °È±â
		} 
		else
		{
			if( pMover->SetMotion( MTI_RUN ) )
				pModel->SetMotionBlending( TRUE );
		}
		break;
#endif //__Y_INTERFACE_VER3

	case OBJMSG_FORWARD:
		if( IsActJump() )	return -1;
		if( IsActAttack() )		return -2;
		if( GetDmgState() == OBJSTA_DMG )	// ÇÇ°Ý Áß ¸í·ÉÀÌ¸é ÇÇ°Ý »óÅÂ¸¦ Å¬¸®¾î ½ÃÅ²´Ù.
			ResetState( OBJSTA_DMG_ALL );
		else if( GetState() & OBJSTA_DMG_ALL )	// ±×¿Ü ÇÇ°Ýµ¿ÀÛÀº ´Ù Ãë¼Ò
				return -3;
		if( GetMoveState() == OBJSTA_FMOVE )	return 0;	// ÀÌ¹Ì ÀüÁø»óÅÂ¸é Ãß°¡·Î Ã³¸® ÇÏÁö ¾ÊÀ½
		if( IsSit() )		return 0;		// ¸®ÅÏ 0À¸·Î ÇØµµ µÇ³ª?.
		if( pMover->m_dwFlag & MVRF_NOMOVE )	return 0;		// ÀÌµ¿±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pMover->GetAdjParam( DST_CHRSTATE ) & CHS_LOOT)			return 0;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

		SetMoveState( OBJSTA_FMOVE );
		if( IsStateFlag( OBJSTAF_WALK ) )	// °È´Â¸ðµå
		{
			pMover->SetMotion( MTI_WALK );
#ifdef __MOUNT
#ifdef __CLIENT
			if (!IsFly() && IsUseMount())
			{
				MOUNT_ANIMATION* pMount = prj.GetMountAnimation(pMover->GetMountId());
				if (IsStateFlag(OBJSTAF_WALK))
				{
					if (pMover->m_eMountState != CMover::MountState::GROUND_WALK)
					{
						CString strMotion = pMover->m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_WALK)->second);
						assert(strMotion != _T(""));
						pMover->m_pMountModel->LoadMotion(strMotion);
						pMover->m_pMountModel->SetMotionBlending(TRUE);
						pMover->m_pMountModel->SetLoop(ANILOOP_LOOP);
						pMover->m_eMountState = CMover::MountState::GROUND_WALK;
					}
				}
			}
#endif // __CLIENT
#endif // __MOUNT
		} 
		else
		{
			if( pMover->SetMotion( MTI_RUN ) )
				pModel->SetMotionBlending( TRUE );
#ifdef __MOUNT
#ifdef __CLIENT
			if (!IsFly() && IsUseMount())
			{
				MOUNT_ANIMATION* pMount = prj.GetMountAnimation(pMover->GetMountId());
				if (pMover->m_eMountState != CMover::MountState::GROUND_RUN)
				{
					CString strMotion = pMover->m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_RUN)->second);
					assert(strMotion != _T(""));
					pMover->m_pMountModel->LoadMotion(strMotion);
					pMover->m_pMountModel->SetMotionBlending(TRUE);
					pMover->m_pMountModel->SetLoop(ANILOOP_LOOP);
					pMover->m_eMountState = CMover::MountState::GROUND_RUN;
				}
			}
#endif // __CLIENT
#endif // __MOUNT
		}
		pMover->OnActFMove();
		break;
		
	case OBJMSG_STOP_RUN:
	#ifdef __CLIENT
		if( IsActJump() )	return -1;
		if( IsActAttack() )		return -2;
		if( GetDmgState() == OBJSTA_DMG )	// ÇÇ°Ý Áß ¸í·ÉÀÌ¸é ÇÇ°Ý »óÅÂ¸¦ Å¬¸®¾î ½ÃÅ²´Ù.
			ResetState( OBJSTA_DMG_ALL );
		else if( GetState() & OBJSTA_DMG_ALL )	// ±×¿Ü ÇÇ°Ýµ¿ÀÛÀº ´Ù Ãë¼Ò
			return -3;
		if( GetMoveState() == OBJSTA_STOP_RUN )	return 0;	// ÀÌ¹Ì ÀüÁø»óÅÂ¸é Ãß°¡·Î Ã³¸® ÇÏÁö ¾ÊÀ½
		if( IsSit() )		return 0;						// ¸®ÅÏ 0À¸·Î ÇØµµ µÇ³ª?.
		if( pMover->m_dwFlag & MVRF_NOMOVE )	return 0;	// ÀÌµ¿±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pMover->GetAdjParam( DST_CHRSTATE ) & CHS_LOOT)			return 0;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

		SetMoveState( OBJSTA_STOP_RUN );
	#endif
		break;

	
	// ÈÄÁøÇØ¶ó!
	case OBJMSG_BACKWARD:
		if( IsActJump() )	return -1;	// if jump, x
		if( IsActAttack() )		return -2;	// °ø°Ýµ¿ÀÛÁßÀÌ¸é Ãë¼ÒµÊ.
		if( IsActDamage() )		return -3;
		if( GetMoveState() == OBJSTA_BMOVE )	return 0;
		if( IsSit() )		return 0;		// ¸®ÅÏ 0À¸·Î ÇØµµ µÇ³ª?.
		if( IsAction() )	return 0;
		if( pMover->m_dwFlag & MVRF_NOMOVE )	return 0;		// ÀÌµ¿±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pMover->GetAdjParam( DST_CHRSTATE ) & CHS_LOOT)			return 0;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#ifdef __MOUNT
#ifdef __CLIENT
		if (!IsFly() && IsUseMount())
		{
			MOUNT_ANIMATION* pMount = prj.GetMountAnimation(pMover->GetMountId());
			if (pMount && pMover->m_eMountState != CMover::MountState::GROUND_WALK)
			{
				CString strMotion = pMover->m_pMountModel->GetMotionFileName(pMount->m_aMonsterAnimation.find(MTI_BACK)->second);
				assert(strMotion != _T(""));
				pMover->m_pMountModel->LoadMotion(strMotion);
				pMover->m_pMountModel->SetMotionBlending(TRUE);
				pMover->m_pMountModel->SetLoop(ANILOOP_LOOP);
				pMover->m_eMountState = CMover::MountState::GROUND_WALK;
			}
		}
#endif // __CLIENT
#endif // __MOUNT
		SetMoveState( OBJSTA_BMOVE );
		pMover->SetMotion( MTI_WALK );		
		break;
	// ÁÂ/¿ì ÅÏ ÇØ¶ó!
	case OBJMSG_LTURN:
		if( IsActJump() )	return -1;
		if( IsActAttack() )		return -2;
		if( GetDmgState() == OBJSTA_DMG )	// ÇÇ°Ý Áß ¸í·ÉÀÌ¸é ÇÇ°Ý »óÅÂ¸¦ Å¬¸®¾î ½ÃÅ²´Ù.
			ResetState( OBJSTA_DMG_ALL );
		else if( GetState() & OBJSTA_DMG_ALL )	// ±×¿Ü ÇÇ°Ýµ¿ÀÛÀº ´Ù Ãë¼Ò
				return -3;
		if( GetTurnState() == OBJSTA_LTURN )	return 0;
		if( IsSit() )		return 0;		// ¸®ÅÏ 0À¸·Î ÇØµµ µÇ³ª?.
		if( IsAction() )	return 0;
		if( pMover->m_dwFlag & MVRF_NOMOVE )	return 0;		// ÀÌµ¿±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pMover->GetAdjParam( DST_CHRSTATE ) & CHS_LOOT)			return 0;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

		SetTurnState( OBJSTA_LTURN );
		break;
	case OBJMSG_RTURN:
		if( IsActJump() )	return -1;
		if( IsActAttack() )		return -2;
		if( GetDmgState() == OBJSTA_DMG )	// ÇÇ°Ý Áß ¸í·ÉÀÌ¸é ÇÇ°Ý »óÅÂ¸¦ Å¬¸®¾î ½ÃÅ²´Ù.
			ResetState( OBJSTA_DMG_ALL );
		else if( GetState() & OBJSTA_DMG_ALL )	// ±×¿Ü ÇÇ°Ýµ¿ÀÛÀº ´Ù Ãë¼Ò
			return -3;
		if( GetTurnState() == OBJSTA_RTURN )	return 0;
		if( IsSit() )		return 0;		// ¸®ÅÏ 0À¸·Î ÇØµµ µÇ³ª?.
		if( IsAction() )	return 0;
		if( pMover->m_dwFlag & MVRF_NOMOVE )	return 0;		// ÀÌµ¿±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pMover->GetAdjParam( DST_CHRSTATE ) & CHS_LOOT)			return 0;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

		SetTurnState( OBJSTA_RTURN );
		break;
	case OBJMSG_STOP_TURN:
		if( GetTurnState() == 0 )		return 0;		// ÀÌ¹Ì ÅÏ »óÅÂ°¡ ¾ø´Ù¸é Ã³¸® ¾ÈÇÔ
		SetTurnState( 0 );		// ÅÏÀ» ÁßÁö
		break;

	// ÇÇÄ¡¸¦ µé¾î¿Ã¸². ºñÇà¸÷ÀÇ °æ¿ì¸¸ »ç¿ë.
	case OBJMSG_LOOKUP:
		if( IsActJump() )	return -1;
		if( IsActAttack() )		return -2;
		if( GetDmgState() == OBJSTA_DMG )	// ÇÇ°Ý Áß ¸í·ÉÀÌ¸é ÇÇ°Ý »óÅÂ¸¦ Å¬¸®¾î ½ÃÅ²´Ù.
			ResetState( OBJSTA_DMG_ALL );
		else if( GetState() & OBJSTA_DMG_ALL )	// ±×¿Ü ÇÇ°Ýµ¿ÀÛÀº ´Ù Ãë¼Ò
			return -3;
		if( GetTurnState() == OBJSTA_LOOKUP )	return 0;
		if( IsSit() )		return 0;		// ¸®ÅÏ 0À¸·Î ÇØµµ µÇ³ª?.
		if( IsAction() )	return 0;
		if( pMover->m_dwFlag & MVRF_NOMOVE )	return 0;		// ÀÌµ¿±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pMover->GetAdjParam( DST_CHRSTATE ) & CHS_LOOT)			return 0;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

		SetLookState( OBJSTA_LOOKUP );
		break;
	case OBJMSG_LOOKDOWN:
		if( IsActJump() )	return -1;
		if( IsActAttack() )		return -2;
		if( GetDmgState() == OBJSTA_DMG )	// ÇÇ°Ý Áß ¸í·ÉÀÌ¸é ÇÇ°Ý »óÅÂ¸¦ Å¬¸®¾î ½ÃÅ²´Ù.
			ResetState( OBJSTA_DMG_ALL );
		else if( GetState() & OBJSTA_DMG_ALL )	// ±×¿Ü ÇÇ°Ýµ¿ÀÛÀº ´Ù Ãë¼Ò
			return -3;
		if( GetTurnState() == OBJSTA_LOOKDOWN )	return 0;
		if( IsSit() )		return 0;		// ¸®ÅÏ 0À¸·Î ÇØµµ µÇ³ª?.
		if( IsAction() )	return 0;
		if( pMover->m_dwFlag & MVRF_NOMOVE )	return 0;		// ÀÌµ¿±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pMover->GetAdjParam( DST_CHRSTATE ) & CHS_LOOT)			return 0;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

		SetLookState( OBJSTA_LOOKDOWN );
		break;
	case OBJMSG_STOP_LOOK:
		if( GetLookState() == 0 )		return 0;
		SetLookState( 0 );		// ·è ÁßÁö
		break;
		// Á¡ÇÁ
	case OBJMSG_JUMP:
		if( IsActJump() )		return 0;
		if( IsActAttack() )		return -2;
		if( IsActDamage() )		return -3;
		if( IsSit() )			return 0;		// ¸®ÅÏ 0À¸·Î ÇØµµ µÇ³ª?.
		if( IsAction() )		return 0;
		if( pMover->m_dwFlag & MVRF_NOMOVE )	return 0;		// ÀÌµ¿±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pMover->GetAdjParam( DST_CHRSTATE ) & CHS_LOOT)			return 0;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#ifdef __SECURITY_FIXES
		if (!pMover->m_pActMover->m_bGround) return 0;
		if (pMover->GetPos().y > (m_fCurrentHeight + 0.2f + (pMover->GetParam(DST_JUMPING, 0) / 1000.0f)) * 1.15f) return 0;
#endif // __SECURITY_FIXES
#ifdef __CLIENT
		if( pMover->IsActiveMover() )
		{
			if( pMover->m_dwReqFlag & REQ_USESKILL )	return 0;	// ¼­¹ö·ÎºÎÅÍ useskillÀÀ´äÀÌ ¿À±âÀü±îÁø Á¡ÇÁÇØ¼± ¾ÈµÊ.
			if( pMover->m_dwReqFlag & REQ_MOTION )		return 0;	// ¼­¹ö·ÎºÎÅÍ ¸ð¼Ç ÀÀ´äÀÌ ¿À±âÀü±îÁö Á¡ÇÁ ±ÝÁö.
		}
#endif	// __CLIENT
#ifdef __GAMEGUARD
		if (!pMover->m_pActMover->m_bGround)
			return 0;
#endif // __GAMEGUARD
		SendActMsg( OBJMSG_STOP_TURN );
		SetJumpState( OBJSTA_SJUMP1 );
		if( (GetState() & OBJSTA_COLLECT)== 0 ) pMover->SetMotion( MTI_JUMP1, ANILOOP_1PLAY );
		pModel->SetMotionBlending( FALSE );
		break;
	// ¿Ïµå°ø°Ý
	case OBJMSG_ATK_MAGIC1:	// °ø°Ý 1
		{
			if( IsAction() )	return 0;
			if( IsSit() )		// ¾É¾ÆÀÖ´Â»óÅÂ¿´À¸¸é ÇØÁ¦
				ResetState( OBJSTA_MOVE_ALL );
			if( GetState() & OBJSTA_ATK_ALL )	return 0;		// ÀÌ¹Ì °ø°Ýµ¿ÀÛÀ» ÇÏ°í ÀÖÀ¸¸é Ãë¼Ò.
			if( pMover->m_dwFlag & MVRF_NOATTACK )	return -1;		// °ø°Ý±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
			if( pMover->IsMode( NO_ATTACK_MODE ) ) return -1;
			CMover* pHitObj		= prj.GetMover( nParam1 );
			if( IsInvalidObj( pHitObj ) )	return -1;
			if( pHitObj->IsDie() )	return -1;
#ifdef __WORLDSERVER
			if( !g_eLocal.GetState( EVE_STEAL ) )
			{
				if( pMover->IsSteal( pHitObj ) )	// pHitObj¸¦ ½ºÆ¿ÇÏ·ÁÇÏ¸é ÀÌ°ø°ÝÀº ¹«½Ã.
					return -1;
			}
#endif
			if( IsActDamage() )
				ResetState( OBJSTA_DMG_ALL );
			if( IsStateFlag( OBJSTAF_COMBAT ) == FALSE )
				SendActMsg( OBJMSG_MODE_COMBAT );
		
			SendActMsg( OBJMSG_STOP_TURN );
			SendActMsg( OBJMSG_STAND );
			SetState( OBJSTA_ATK_ALL, OBJSTA_ATK_MAGIC1 );
			pMover->SetMotion( MTI_ATK1, ANILOOP_1PLAY );		// ¿Ïµåµ¿ÀÛÀÌ ¾øÀ¸¹Ç·Î °ø°Ýµ¿ÀÛÀ¸·Î ´ë½ÅÇÔ.
			pHitObj->SetJJim( pMover );
			pMover->m_nAtkCnt = 1;		// Ä«¿îÆ® ½ÃÀÛ.
			pMover->OnAttackStart( pHitObj, dwMsg );			// °ø°Ý½ÃÀÛ ÇÚµé·¯.
		}
		break;
		// ·¹ÀÎÁö°ø°Ý
	case OBJMSG_ATK_RANGE1:	// °ø°Ý 1
		{
			if( IsAction() )	return 0;
			if( pMover->m_dwFlag & MVRF_NOATTACK )	return -1;		// °ø°Ý±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
			if( pMover->IsMode( NO_ATTACK_MODE ) ) return -1;
			if( IsSit() )		// ¾É¾ÆÀÖ´Â»óÅÂ¿´À¸¸é ÇØÁ¦
				ResetState( OBJSTA_MOVE_ALL );
			if( GetState() & OBJSTA_ATK_ALL )	return 0;		// ÀÌ¹Ì °ø°Ýµ¿ÀÛÀ» ÇÏ°í ÀÖÀ¸¸é Ãë¼Ò.
			CMover* pHitObj		= prj.GetMover( nParam1 );
			if( IsValidObj( (CObj*)pHitObj ) == FALSE )	
				return -1;
			if( pHitObj->IsDie() )
				return -1;

			m_idTarget = (DWORD)nParam1;		// °ø°Ý Å¸°Ù.

#ifdef __WORLDSERVER
			if( !g_eLocal.GetState( EVE_STEAL ) )
			{
				if( pMover->IsSteal( pHitObj ) )	// pHitObj¸¦ ½ºÆ¿ÇÏ·ÁÇÏ¸é ÀÌ°ø°ÝÀº ¹«½Ã.
					return -1;
			}
#endif
			if( GetDmgState() == OBJSTA_DMG )	// ÇÇ°Ý Áß °ø°Ý¸í·ÉÀÌ¸é ÇÇ°Ý »óÅÂ¸¦ Å¬¸®¾î ½ÃÅ²´Ù.
				ResetState( OBJSTA_DMG_ALL );
			else if( GetState() & OBJSTA_DMG_ALL )	// ±×¿Ü ÇÇ°Ýµ¿ÀÛÀº ´Ù Ãë¼Ò
				return -1;
			if( IsStateFlag( OBJSTAF_COMBAT ) == FALSE )
				SendActMsg( OBJMSG_MODE_COMBAT );
			
			int nUseMotion = nParam2;
//			SendActMsg( OBJMSG_STOP_TURN );
//			SendActMsg( OBJMSG_STAND );
			SetState( OBJSTA_ATK_ALL, OBJSTA_ATK_RANGE1 );
			pMover->SetMotion( nUseMotion, ANILOOP_1PLAY );		// ¿Ïµåµ¿ÀÛÀÌ ¾øÀ¸¹Ç·Î °ø°Ýµ¿ÀÛÀ¸·Î ´ë½ÅÇÔ.
			pHitObj->SetJJim( pMover );			// °ø°ÝÀÌ ½ÃÀÛµÇ¸é Å¸°Ù¿¡´Ù°¡ ³»°¡ ÂòÇß´Ù´Â°É Ç¥½Ã.
			pMover->OnAttackStart( pHitObj, dwMsg );			// °ø°Ý½ÃÀÛ ÇÚµé·¯.
			pMover->m_nAtkCnt = 1;		// Ä«¿îÆ® ½ÃÀÛ.
		}
		break;
		// °ø°Ý - ¸®ÅÏ°ª -2´Â Å¬¶ó·Î ºÎÅÍ ¹ÞÀº ¸í·ÉÀ» ¿ÏÀü ¹«½ÃÇÑ´Ù.
	case OBJMSG_ATK1:	// °ø°Ý 1
	case OBJMSG_ATK2:	// °ø°Ý 2
	case OBJMSG_ATK3:	// °ø°Ý 3	
	case OBJMSG_ATK4:	// °ø°Ý 4
		{
			if( IsAction() )
				return 0;
			if( pMover->m_dwFlag & MVRF_NOATTACK )
				return -2;		// °ø°Ý±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
			if( pMover->IsMode( NO_ATTACK_MODE ) )
				return -2;

#ifdef __CLIENT
			if( pMover->IsActiveMover() )
#endif
			{
				// ±âº»Àº ¿À¸¥¼Õ °Ë»ç( ¿Ïµå¿ë )
				CItemElem* pItemElem = pMover->GetWeaponItem();
#ifdef __CROSSBOW
				if( pItemElem && (pItemElem->GetProp()->dwItemKind3 == IK3_WAND || pItemElem->GetProp()->dwItemKind3 == IK3_BOW || pItemElem->GetProp()->dwItemKind3 == IK3_CROSSBOW ))
#else // __CROSSBOW
				if( pItemElem && (pItemElem->GetProp()->dwItemKind3 == IK3_WAND || pItemElem->GetProp()->dwItemKind3 == IK3_BOW ) )
#endif // __CROSSBOW	
					return -2;
			}
				
			CMover* pHitObj		= prj.GetMover( nParam1 );
			if( IsValidObj( (CObj*)pHitObj ) == FALSE )
				return( -1 );

#ifdef __XUZHU
			if( pMover->IsPlayer() )
			{
				int a = 0;
			}
#endif // xuzhu
			m_idTarget = (DWORD)nParam1;		// °ø°Ý Å¸°Ù.
#ifdef __WORLDSERVER
			if( !g_eLocal.GetState( EVE_STEAL ) )
			{
				if( pMover->IsSteal( pHitObj ) )	// pHitObj¸¦ ½ºÆ¿ÇÏ·ÁÇÏ¸é ÀÌ°ø°ÝÀº ¹«½Ã.
					return -2;
			}
#endif
			if( pHitObj->m_pActMover->IsDie() )	return( -1 );
			if( GetState() & OBJSTA_ATK_ALL )	return( 0 );	// ÀÌ¹Ì °ø°ÝÁßÀÌ¸é ¸®ÅÏ
			if( IsSit() )		// ¾É¾ÆÀÖ´Â»óÅÂ¿´À¸¸é ÇØÁ¦
				ResetState( OBJSTA_MOVE_ALL );
			if( GetDmgState() == OBJSTA_DMG )	// ÇÇ°Ý Áß °ø°Ý¸í·ÉÀÌ¸é ÇÇ°Ý »óÅÂ¸¦ Å¬¸®¾î ½ÃÅ²´Ù.
				ResetState( OBJSTA_DMG_ALL );
			else
			if( GetState() & OBJSTA_DMG_ALL )	// ±×¿Ü ÇÇ°Ýµ¿ÀÛÀº ´Ù Ãë¼Ò
				return -3;
			if( IsStateFlag( OBJSTAF_COMBAT ) == FALSE )
				SendActMsg( OBJMSG_MODE_COMBAT );
			SendActMsg( OBJMSG_STOP_TURN );	// °ø°ÝÇÒ¶© ÅÏÀ» Á¤Áö½ÃÅ´
			SendActMsg( OBJMSG_STAND );
			

			DWORD dwOption = MOP_SWDFORCE | MOP_NO_TRANS;
			
#ifdef __XSLOW1018
			int nMin, nTemp;
			pMover->GetHitMinMax( &nMin, &nTemp );
			if( dwMsg == OBJMSG_ATK3 || dwMsg == OBJMSG_ATK4 )
				if( pMover->GetLevel() >= 12 && pHitObj->GetHitPoint() < (int)(nMin * 1.5f) )
					dwOption |= MOP_HITSLOW;
#endif // xSlow1018
			if( pMover->IsPlayer() )
				pMover->m_fAniSpeed = pMover->GetAttackSpeed();
			
			switch( dwMsg )
			{
				case OBJMSG_ATK1:
					SetState( OBJSTA_ATK_ALL, OBJSTA_ATK1 );
					pMover->SetMotion( MTI_ATK1, ANILOOP_1PLAY, dwOption );		// ÃÖÃÊ ¸Þ½ÃÁö ÀÔ·Â½Ã µ¿ÀÛ ¼³Á¤
					break;
				case OBJMSG_ATK2:	
					SetState( OBJSTA_ATK_ALL, OBJSTA_ATK2 );
					pMover->SetMotion( MTI_ATK2, ANILOOP_1PLAY, dwOption );		// ÃÖÃÊ ¸Þ½ÃÁö ÀÔ·Â½Ã µ¿ÀÛ ¼³Á¤
					break;
				case OBJMSG_ATK3:	
					SetState( OBJSTA_ATK_ALL, OBJSTA_ATK3 );
					pMover->SetMotion( MTI_ATK3, ANILOOP_1PLAY, dwOption );		// ÃÖÃÊ ¸Þ½ÃÁö ÀÔ·Â½Ã µ¿ÀÛ ¼³Á¤
					break;
				case OBJMSG_ATK4:	
					SetState( OBJSTA_ATK_ALL, OBJSTA_ATK4 );
					pMover->SetMotion( MTI_ATK4, ANILOOP_1PLAY, dwOption );		// ÃÖÃÊ ¸Þ½ÃÁö ÀÔ·Â½Ã µ¿ÀÛ ¼³Á¤
					break;
			}
			pMover->SetAngle( GetDegree( pHitObj->GetPos(), m_pMover->GetPos() ) );
			pHitObj->SetJJim( pMover );

			pMover->m_nAtkCnt = 1;		// Ä«¿îÆ® ½ÃÀÛ.
			pMover->OnAttackStart( pHitObj, dwMsg );			// °ø°Ý½ÃÀÛ ÇÚµé·¯.
			m_objidHit	= (OBJID)nParam1;	// Å¸°ÙÀÇ ¾ÆÀÌµð.	

			m_dwAtkFlags	= (DWORD)LOWORD( (DWORD)nParam3 );
#ifdef __WORLDSERVER
			if (m_dwAtkFlags == 0)
			{
#ifdef __GAMEGUARD
				if (pMover->IsMode(ONEKILL_MODE) && !pMover->IsAuthHigher(AUTH_GAMEMASTER))
					m_dwAtkFlags = AF_MISS;
				else
#endif // __GAMEGUARD
				{
#ifndef __DMGCORRECT
					if (pMover->GetAttackResult(pHitObj, dwOption))
						m_dwAtkFlags = AF_GENERIC;
					else
						m_dwAtkFlags = AF_MISS;
#else
					m_dwAtkFlags = AF_GENERIC;
#endif
				}
	}
#else
			m_dwAtkFlags = AF_GENERIC;		// ±¸Á¶°¡ Á» ÀÌ»óÇÑµ¥. Å¬¶ó¿¡¼­´Â ¸íÁßÆÇÁ¤À» ÇÏÁö ¾ÊÀ¸¹Ç·Î ¹«Á¶°Ç ÆòÅ¸¸íÁßÀ¸·Î ÀÎÁ¤.
#endif
			
			return( (int)m_dwAtkFlags );
			break;
		}	
	// ¸ó½ºÅÍµéÀÇ Æ¯¼ö°ø°Ý.
	case OBJMSG_SP_ATK1:
	case OBJMSG_SP_ATK2:
		{
			CMover* pHitObj		= prj.GetMover( nParam1 );
			//nParam2;		// Æ¯¼ö°ø°Ý¿¡ »ç¿ëÇÒ ¹«±â. º¸ÅëÀº ¸ó½ºÅÍÀÌ¹Ç·Î °¡»ó¾ÆÀÌÅÛÀÌ µé¾î¿Â´Ù.
			int		nUseMotion	= nParam3;		// »ç¿ëÇÒ ¸ð¼Ç.
			if( IsValidObj( (CObj*)pHitObj ) == FALSE )	return( -1 );
			if( pHitObj->m_pActMover->IsDie() )	return( -1 );
			if( GetState() & OBJSTA_ATK_ALL )	return( 0 );	// ÀÌ¹Ì °ø°ÝÁßÀÌ¸é ¸®ÅÏ
			if( pMover->m_dwFlag & MVRF_NOATTACK )	return 0;		// °ø°Ý±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
			if( GetDmgState() == OBJSTA_DMG )	// ÇÇ°Ý Áß °ø°Ý¸í·ÉÀÌ¸é ÇÇ°Ý »óÅÂ¸¦ Å¬¸®¾î ½ÃÅ²´Ù.
				ResetState( OBJSTA_DMG_ALL );
			else
			if( GetState() & OBJSTA_DMG_ALL )	// ±×¿Ü ÇÇ°Ýµ¿ÀÛÀº ´Ù Ãë¼Ò
				return -3;
			if( IsStateFlag( OBJSTAF_COMBAT ) == FALSE )
				SendActMsg( OBJMSG_MODE_COMBAT );
			SendActMsg( OBJMSG_STOP_TURN );	// °ø°ÝÇÒ¶© ÅÏÀ» Á¤Áö½ÃÅ´
			SendActMsg( OBJMSG_STAND );

			DWORD dwOption = MOP_SWDFORCE /*| MOP_NO_TRANS*/;	// ¸ó½ºÅÍ´Ï±î °ø°Ýµ¿ÀÛµµ ¸ð¼ÇÆ®·£Áö¼Ç µÇ°Ô ÇØºÃ´Ù.
			SetState( OBJSTA_ATK_ALL, OBJSTA_SP_ATK1 );
			pMover->SetMotion( nUseMotion, ANILOOP_1PLAY, dwOption );		// ÃÖÃÊ ¸Þ½ÃÁö ÀÔ·Â½Ã µ¿ÀÛ ¼³Á¤
			pMover->SetAngle( GetDegree( pHitObj->GetPos(), m_pMover->GetPos() ) );
			pMover->OnAttackStart( pHitObj, dwMsg );			// °ø°Ý½ÃÀÛ ÇÚµé·¯.
			return 1;
		}
		break;

	// Àü»çµéÀÇ ±ÙÁ¢ ÀüÅõ½ºÅ³·ù
	case OBJMSG_MELEESKILL:
		{
			if( IsAction() )	return -2;	
			if( pMover->m_dwFlag & MVRF_NOATTACK )	return -2;		// °ø°Ý±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
			CMover* pHitObj		= prj.GetMover( nParam2 );
			if( IsValidObj( pHitObj ) == FALSE )	return -2;
#ifdef __WORLDSERVER
			if( GetState() & OBJSTA_ATK_RANGE1 )
				ResetState( OBJSTA_ATK_RANGE1 );
			if( GetState() & OBJSTA_ATK_ALL )	return -2;	// ÀÌ¹Ì °ø°ÝÁßÀÌ¸é ¸®ÅÏ. ¼­¹ö¿¡¼± ¾ÃÈ÷Áö ¾Ê°Ô ÇÏÀÚ.
			pMover->m_dwMotion = -1;	// ³ª¸ÓÁö °æ¿ì´Â °£´ÜÇÏ°Ô »ý°¢ÇÏ±â À§ÇØ ¸ðµÎ Å¬¸®¾î ½ÃÅ°°í ½ºÅ³¸¸ ½ÇÇàÇÏÀÚ.
			ClearState();				// »óÅÂ Å¬¸®¾îÇÏ°í ´Ù½Ã ¸ÂÃã,.
#else
			// ÀÌ¸®Àú¸® ÇØº¸´Ï ¾×Æ¼ºê ¹«¹ö°Ç ¾Æ´Ï°Ç ¼­¹ö¿¡¼­ ½ÅÈ£¿À¸é ¹Ù·Î ½ÃÀÛÇÏ´Â°Ô ÁÁÀ»°Å °°¾Ö¼­ ÀÌ·¸°Ô ÇÔ.
			pMover->m_dwMotion = -1;	
			ClearState();				// »óÅÂ Å¬¸®¾îÇÏ°í ´Ù½Ã ¸ÂÃã,.
#endif
			SetState( OBJSTA_ATK_ALL, OBJSTA_ATK_MELEESKILL );			// ±ÙÁ¢ÀüÅõ½ºÅ³»óÅÂ ¼³Á¤.
			DWORD dwMotion = (DWORD)nParam1;
			int	nLoop = ANILOOP_1PLAY;

			int	nSkill = pMover->GetActParam( 0 );
			if( nSkill == SI_BLD_DOUBLESW_SILENTSTRIKE || nSkill == SI_ACR_YOYO_COUNTER )
				nLoop = ANILOOP_CONT;

#ifdef __CLIENT			
			if( pMover->HasBuffByIk3( IK3_TEXT_DISGUISE ) )
				dwMotion = MTI_ATK1;
#endif
#ifdef __CROSSBOW
			CItemElem* pItemElem = pMover->GetWeaponItem();
			if( pItemElem && ( pItemElem->GetProp()->dwItemKind3 == IK3_CROSSBOW ))
				dwMotion += 200;
#endif // __CROSSBOW

			pMover->SetMotion( dwMotion, nLoop, MOP_SWDFORCE | MOP_NO_TRANS | MOP_FIXED );		// ÇØ´ç µ¿ÀÛ¾Ö´Ï ½ÃÀÛ.
			pMover->OnAttackStart( pHitObj, dwMsg );			// °ø°Ý½ÃÀÛ ÇÚµé·¯.
			
			m_nMotionHitCount = 0;
			
			break;
		}
	// ¸¶¹ý»çµéÀÇ ¸¶¹ý½ºÅ³·ù.
	case OBJMSG_MAGICSKILL:
	case OBJMSG_MAGICCASTING:
		{
			if( IsAction() )	return -2;
			if( pMover->m_dwFlag & MVRF_NOATTACK )	return -2;		// °ø°Ý±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
			CMover* pHitObj		= prj.GetMover( nParam2 );
			if( IsValidObj( pHitObj ) == FALSE )	return -2;
		#ifdef __WORLDSERVER
			if( GetState() & OBJSTA_ATK_ALL )	return -2;	// ÀÌ¹Ì °ø°ÝÁßÀÌ¸é ¸®ÅÏ
		#endif  

			pMover->m_dwMotion = -1;	
			ClearState();				// »óÅÂ Å¬¸®¾îÇÏ°í ´Ù½Ã ¸ÂÃã.

			m_nCastingTime	= nParam3 * 4;	// ProcessActionÀº ¼­¹ö/Å¬¶ó È£Ãâ È¸¼ö µ¿ÀÏÇÏ¹Ç·Î, SEC1 »ç¿ëÀÌ Àû´çÇÏÁö ¾Ê´Ù.

#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			m_dwCastingEndTick = (DWORD)( GetTickCount() + nParam3 * 66.66F );
			m_nCastingTick	= (int)( nParam3 * 66.66F );
			m_nCastingSKillID = nParam4;
#endif	//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			if( m_nCastingTime > 0 )	// Ä³½ºÆÃ Å¸ÀÓÀÌ ÀÖÀ»¶§¸¸...
			{
				m_nCount	= 0;	// ÀüÃ¼ Ä³½ºÆÃ Å¸ÀÓÀº µ¿ÀÛ1+µ¿ÀÛ2ÀÇ ÇÕÀÌ¾î¾ß ÇÏ¹Ç·Î ¿©±â¼­ Ä«¿îÅÍ¸¦ ÃÊ±âÈ­ ÇÑ´Ù.
				SetState( OBJSTA_ATK_ALL, OBJSTA_ATK_CASTING1 );			// Ä³½ºÆÃºÎÅÍ ½ÃÀÛ -> ¹ß»ç¸ð¼Ç.
			}
			else
				SetState( OBJSTA_ATK_ALL, OBJSTA_ATK_MAGICSKILL );			// ¹ß»ç¸ð¼Ç¸¸.

		#ifdef __CLIENT
			if( dwMsg == OBJMSG_MAGICSKILL && pMover->HasBuffByIk3( IK3_TEXT_DISGUISE ) )
				nParam1 = MTI_ATK1;
		#endif

			pMover->SetMotion( nParam1, ANILOOP_1PLAY, MOP_SWDFORCE | MOP_NO_TRANS | MOP_FIXED );		// ÇØ´ç µ¿ÀÛ¾Ö´Ï ½ÃÀÛ.
			pMover->OnAttackStart( pHitObj, dwMsg );			// °ø°Ý½ÃÀÛ ÇÚµé·¯.
			m_nMotionHitCount = 0;
			break;
		}
			

	//-------------------- ¸Â¾Ò´Ù.
	case OBJMSG_DAMAGE:
	case OBJMSG_DAMAGE_FORCE:	// °­°ø°Ý¿¡ ¸Â¾Ò´Ù. ³¯¾Æ°¨.
		{
			CMover* pAttacker = PreProcessDamage( pMover, (OBJID)nParam2, nParam4, nParam5 );
			if( pAttacker == NULL )
				return 0;

			if( dwMsg == OBJMSG_DAMAGE_FORCE )			// °­°ø°ÝÀ¸·Î µé¾î¿ÔÀ»¶§
				if( pMover->CanFlyByAttack() == FALSE )	// ³¯¾Æ°¡Áö ¸øÇÏ´Â »óÅÂ¸é.
					dwMsg = OBJMSG_DAMAGE;				// ÀÏ¹Ý µ¥¹ÌÁö·Î ¹Ù²Þ.

			// ½ÇÁ¦ °¡°ÝÇÑ µ¥¹ÌÁö¸¦ ¸®ÅÏÇÔ.
#ifdef __NO_HP_DMG_LIMIT
			long long nDamage = _ProcessMsgDmg(dwMsg, pAttacker, nParam1, nParam3, nParam4, nParam5);
#else
			int nDamage = _ProcessMsgDmg(dwMsg, pAttacker, (DWORD)nParam1, nParam3, nParam4, nParam5);
#endif	
#if __VER >= 10	// __METEONYKER_0608
#ifdef __WORLDSERVER
#if __VER >= 12 // __NEW_ITEMCREATEMON_SERVER
			if( pAttacker->IsPlayer() && CCreateMonster::GetInstance()->IsAttackAble( static_cast<CUser*>(pAttacker), pMover ) )
#endif // __NEW_ITEMCREATEMON_SERVER
#endif // __WORLDSERVER
				pMover->PostAIMsg( AIMSG_DAMAGE, pAttacker->GetId(), nDamage );
#endif	// __METEONYKER_0608
			return nDamage;
		}
		break;

	// HP°¡ 0ÀÌ µÈ ¼ø°£ È£Ãâ
	case OBJMSG_DIE:
	{
		if( IsSit() )						// ¾É¾ÆÀÖ´Â»óÅÂ¿´À¸¸é ÇØÁ¦
			ResetState( OBJSTA_MOVE_ALL );
		
		ClearState();						// Á×À»¶© ´Ù¸¥ µ¿ÀÛ ÇÏ°í ÀÖ´ø°Å ´Ù Å¬¸®¾î ½ÃÄÑ¹ö¸®ÀÚ.
		m_vDelta.x = m_vDelta.z = 0;		// Á×¾úÀ¸¸é µ¨Å¸°ª Å¬¸®¾î.

		pMover->RemoveInvisible();
#ifdef __WORLDSERVER
		pMover->PostAIMsg( AIMSG_DIE, nParam2 );
#endif
		CMover *pAttacker = (CMover *)nParam2;	
		if( pAttacker )
		{
			if( pMover->IsPlayer() && pAttacker->IsPlayer() )	// Á×Àº³ð°ú Á×ÀÎ³ðÀÌ ÇÃ·¹ÀÌ¾î°í
			{
#ifdef __WORLDSERVER
				if( pMover->m_nDuel == 1 && pMover->m_idDuelOther == pAttacker->GetId() )	// µÑÀÌ µà¾óÁßÀÌ¾úÀ¸¸é
				{
					pMover->ClearDuel();
					pAttacker->ClearDuel();
					((CUser*)pMover)->AddSetDuel( pMover );
					((CUser*)pAttacker)->AddSetDuel( pAttacker );
				}
				else if( pMover->m_nDuel == 2 && pMover->m_idDuelParty == pAttacker->m_idparty )
				{
					pMover->m_nDuelState	= 300;		
					CMover *pMember;
					CParty* pParty	= g_PartyMng.GetParty( pMover->m_idparty );

					if( pParty )
					{
						for( int i = 0; i < pParty->m_nSizeofMember; i ++ )
						{
							pMember = (CMover *)g_UserMng.GetUserByPlayerID( pParty->m_aMember[i].m_uPlayerId );
							if( IsValidObj( pMember ) )
								((CUser*)pMember)->AddSetDuel( pMover );
						}
					}

					CParty* pParty2		= g_PartyMng.GetParty( pMover->m_idDuelParty );
					if( pParty2 )
					{
						for( int i = 0; i < pParty2->m_nSizeofMember; i ++ )
						{
							pMember = (CMover *)g_UserMng.GetUserByPlayerID( pParty2->m_aMember[i].m_uPlayerId );
							if( IsValidObj( pMember ) )
								((CUser*)pMember)->AddSetDuel( pMover );
						}
					}
				}
#endif	// __WORLDSERVER
			}

			if( pAttacker->IsNPC() )	// °ø°ÝÀÚ°¡ ¸÷.
			{	// ³¯¶§¸°¸÷ÀÇ ¾îÅÂÄ¿°¡ ³ªÀÏ°æ¿ì´Â Á×±âÀü¿¡ Å¬¸®¾î½ÃÄÑÁØ´Ù.
				if( pAttacker->m_idAttacker == pMover->GetId() )	// °ø°ÝÇÑ¸÷À» Ä£»ç¶÷ÀÌ ³ªÀÏ°æ¿ì´Â ½ºÆ¿Ã¼Å© ÇØÁ¦.
				{
					pAttacker->m_idAttacker = NULL_ID;
					pAttacker->m_idTargeter = NULL_ID;
				}
			}
		}
		
		switch( nParam1 )
		{
#ifdef __BS_DEATH_ACTION
		case OBJMSG_DAMAGE:
		case OBJMSG_DAMAGE_FORCE:
		{
			int rAngle = 0;
			int rPower = 0;
			int nCase = rand() % 6;
			if( nCase < 3 )
			{
				rAngle = -2;
				rPower = 10 + rand() % 50;
			}
			else if( nCase < 4 )
			{
				rAngle = 10;
				rPower = 10 + rand() % 50;
			}
			else if( nCase < 5 )
			{
				rAngle = 50;
				rPower = 10 + rand() % 50;
			}
			else
			{
				rAngle = rand() % 30;
				rPower = rand() % 200;
			}
			
			if( OBJMSG_DAMAGE_FORCE == nParam1 )
				rPower += 50;
		
			CMover *pAttacker = (CMover *)nParam2;
			SetState( OBJSTA_DMG_ALL, OBJSTA_DMG_FLY );
			pMover->SetMotion( MTI_DMGFLY, ANILOOP_CONT );
			if( pAttacker )
			{
				float faddPower = rPower * 0.01f;
				float faddAngle = (float)( rAngle );

				DoDamageFly( pAttacker->GetAngle(), 100.0f + faddAngle, 0.05f + faddPower );	// ¾îÅÂÄ¿°¡ º¸´ÂÂÊÀ¸·Î ³¯·Áº¸³¿.
			}
		}
		break;
#else
		case OBJMSG_DAMAGE_FORCE:	// °­ °ø°ÝÀ¸·Î Á×¾ú´Ù¸é ³¯¾Æ°¡¼­ Á×±â
			{
			CMover *pAttacker = (CMover *)nParam2;
			SetState( OBJSTA_DMG_ALL, OBJSTA_DMG_FLY );
			pMover->SetMotion( MTI_DMGFLY, ANILOOP_CONT );
			if( pAttacker )
				DoDamageFly( pAttacker->GetAngle(), 145.0f, 0.25f );	// ¾îÅÂÄ¿°¡ º¸´ÂÂÊÀ¸·Î ³¯·Áº¸³¿.
			}
			break;
		case OBJMSG_DAMAGE:		// °Á ÀÏ¹Ý µ¥¹ÌÁö·Î Á×¾ú´Ù¸é ±×³É ¾²·¯Á® Á×±â
#endif
		default:	
			SetState( OBJSTA_DMG_ALL, OBJSTA_DEAD );
			pMover->SetMotion( MTI_DIE1, ANILOOP_CONT );
			break;

		}

		if( !pMover->IsPlayer() )	// ¸ó½ºÅÍÀÏ °æ¿ì.
		{
		#ifdef __WORLDSERVER			
			m_nDeadCnt	= 60*3;	// µðÆúÆ® - 3ÃÊ ÈÄ¿¡ ¾ø¾îÁü.
			MoverProp *pProp = pMover->GetProp();
			if( pProp )
			{
				/*
				if( pProp->dwSourceMaterial != NULL_ID || pProp->dwClass == RANK_MATERIAL )	// ÀÚ¿ø ¸÷ÀÌ¸é..
				{
					if( pProp->dwHoldingTime == NULL_ID )
						Error( "%s ÀÇ MoverProp::dwHoldingTime °ªÀÌ -1", pMover->GetName() );
					m_nDeadCnt = (int)(60.0f * (pProp->dwHoldingTime / 1000.0f));
					if( pProp->dwHoldingTime < 10000 )		// 10ÃÊ ÀÌÇÏÀÏ¶§
						Error( "dwHoldingTime : %d %s", pProp->dwHoldingTime, pMover->GetName() );
					pMover->m_nCollectOwnCnt = PROCESS_COUNT * 40;
					CMover *pAttacker = (CMover *)nParam2;	
					if( pAttacker )
						pMover->m_idCollecter = pAttacker->GetId();		// °ø°ÝÀÚ°¡ ¼ÒÀ¯ÀÚ°¡ µÈ´Ù.
					
				}
				{
					if( pProp->dwSourceMaterial == NULL_ID && pProp->dwClass == RANK_MATERIAL )	// ÀÚ¿ø¸÷ÀÎµ¥ ÀÚ¿ø°ªÀÌ ¾ø´Â°æ¿ì
						Error( "OBJMSG_DIE : %s %d", pMover->GetName(), pProp->dwSourceMaterial );
					if( pProp->dwSourceMaterial != NULL_ID && pProp->dwClass != RANK_MATERIAL )	// ÀÚ¿ø¸÷ÀÌ ¾Æ´Ñµ¥ ÀÚ¿ø°ªÀÌ ÀÖ´Â°æ¿ì.
						Error( "OBJMSG_DIE 2 : %s %d", pMover->GetName(), pProp->dwSourceMaterial );
				}
				*/
			}
		#endif // WorldServer
		}
		break;
	}
		
	case OBJMSG_APPEAR:
		SetState( OBJSTA_ACTION_ALL, OBJSTA_APPEAR );
		pMover->SetMotion( MTI_APPEAR2, ANILOOP_1PLAY, MOP_FIXED | MOP_NO_TRANS );
		break;
	//---- ¸ðµåÀüÈ¯ ------------------------
	case OBJMSG_MODE_COMBAT:
		if( GetStateFlag() & OBJSTAF_COMBAT )	return 0;		// ÀÌ¹Ì ÀüÅõ¸ðµå¸é ¸®ÅÏ
		if( IsActJump() )	return 0;
		if( IsActAttack() )	return 0;
		if( IsActDamage() )	return 0;
		if( IsSit() )		return 0;
		if( IsAction() )	return 0;
		AddStateFlag( OBJSTAF_COMBAT );	// ÀüÅõ¸ðµå·Î ¼­¶ó°¡ ¾Æ´Ï°í ÀüÅõ¸ðµå·Î ¹Ù²ã¶ó±â¶«¿¡ ¼­´Ù ¸í·ÉÀº ¹ß»ý½ÃÅ°Áö ¾Ê´Â´Ù.
		pMover->m_dwMotion = -1;	// °°Àº ¸ð¼ÇÀ» ÇÏ¶ó°í ÇÑ°Å¶ó ¸ð¼ÇÀÌ ¾È¹Ù²î¹Ç·Î ÀÌ·¸°Ô...
		pMover->SetMotion( MTI_STAND );
		break;
	case OBJMSG_MODE_PEACE:
		if( (GetStateFlag() & OBJSTAF_COMBAT) == 0 )	return 0;
		if( IsActJump() )	return 0;
		if( IsActAttack() )	return 0;
		if( IsActDamage() )	return 0;
		if( IsSit() )		return 0;
		if( IsAction() )	return 0;
		RemoveStateFlag( OBJSTAF_COMBAT );
		pMover->m_dwMotion = -1;
		pMover->SetMotion( MTI_STAND );
		break;
	case OBJMSG_MODE_WALK:
		if( IsSit() )		return 0;
		if( IsAction() )	return 0;
		if( GetStateFlag() & OBJSTAF_WALK )	return 0;		// ÀÌ¹Ì °È±â¸ðµå¸é ¸®ÅÏ
		AddStateFlag( OBJSTAF_WALK );
		break;
	case OBJMSG_MODE_RUN:
		if( IsSit() )		return 0;
		if( IsAction() )	return 0;
		if( (GetStateFlag() & OBJSTAF_WALK) == 0 )	return 0;		// 
		RemoveStateFlag( OBJSTAF_WALK );
		break;
	case OBJMSG_MODE_FLY:
	{
		if( nParam3 == 0 )
		{
			if( IsSit() )		return 0;
			if( IsAction() )	return 0;
			if( IsActAttack() )	return 0;
			if( pMover->m_dwFlag & MVRF_NOMOVE )	return 0;		// ÀÌµ¿±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			if( pMover->GetAdjParam( DST_CHRSTATE ) & CHS_LOOT)			return 0;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

			{
				CWorld* pWorld	= pMover->GetWorld();
				if( pWorld )
				{
					int nAttr = pMover->GetWorld()->GetHeightAttribute( pMover->GetPos().x, pMover->GetPos().z );		// ÀÌµ¿ÇÒ À§Ä¡ÀÇ ¼Ó¼º ÀÐÀ½.
					if( nAttr == HATTR_NOFLY )		// ºñÇà ±ÝÁö Áö¿ª¿¡¼­ Å¸·Á°í ÇÏ¸é ¸øÅº´Ù.
						return 0;
				}
			}
		}
		AddStateFlag( OBJSTAF_FLY );
		ItemProp *pItemProp = prj.GetItemProp( nParam1 );	// ºøÀÚ·ç ÇÁ·ÎÆÛÆ¼.
		if( pItemProp )
		{
			if( pMover->m_nFuel == -1 )		// ÃÊ±â°ªÀÌ¸é
				pMover->m_nFuel = (int)pItemProp->dwFFuelReMax;	// ºøÀÚ·ç ÃÖ´ë ¿¬·á·®À» ¼¼ÆÃ.
			// -1ÀÏ¶§¸¸ ¼¼ÆÃÇØ¾ßÁö ¿¬·á¸¦ ¹ÝÂë ¾²´Ù°¡ ºøÀÚ·ç¸¦ ¹Ù²ãµµ »õ·Î ¼¼ÆÃ µÇÁö ¾Ê´Â´Ù.
		}
#ifndef __JEFF_9_20
#ifdef __WORLDSERVER
		if( pMover->IsPlayer() )
		{
			((CUser*)pMover)->SetFlyTimeOn();
		}
#endif // __WORLDSERVER
#endif	// __JEFF_9_20
		ClearState();
#ifdef __CLIENT
		if( m_pMover == CMover::GetActiveMover() )
		{
			m_pMover->GetWorld()->SetObjFocus( NULL );	// ºñÇàÁ÷Àü¿¡ ±âÁ¸Å¸°ÙÆÃÀ» Å¬¸®¾îÇØÁØ´Ù.
			g_Neuz.m_camera.Unlock();
			g_WndMng.m_pWndTaskBar->OnCancelSkill();	// ºñÇàÁ÷Àü¿£ ½ºÅ³¹Ù »ç¿ë Ãë¼Ò.
		}
#endif

		CModel* pModel = prj.m_modelMng.LoadModel( D3DDEVICE, OT_ITEM, (DWORD) nParam1 );
#if __VER >= 14 // __WING_ITEM
		CModelObject* pModelObject = (CModelObject*)pModel;
		if( pModelObject->m_pBone )
		{
			CString strMotion = pModelObject->GetMotionFileName( _T("stand") );
			assert( strMotion != _T("") );
			pModelObject->LoadMotion( strMotion );
		}
#endif // __WING_ITEM
#ifdef __MOUNT
		if (pItemProp->dwItemKind3 == IK3_MOUNT)
		{
			if (!pMover->GetMountModel())
				m_pMover->SetMount(pModel, (DWORD)nParam1);
		}
		else
#endif // __MOUNT
		{
			m_pMover->SetRide(pModel, (DWORD)nParam1);
		}
		break;
	}
	case OBJMSG_MOTION:		// ´Ü¼ø ¸ð¼Ç ÇÃ·¹ÀÌ
		{
			if( IsSit() )		return 0;
			if( IsAction() )	return 0;
			if( IsActJump() )	return 0;
			if( IsActAttack() )	return 0;
			if( IsActDamage() )	return 0;
			if( pMover->m_dwFlag & MVRF_NOMOVE )	return 0;		// ÀÌµ¿±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pMover->GetAdjParam( DST_CHRSTATE ) & CHS_LOOT)			return 0;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

			AddStateFlag( OBJSTAF_ETC );		// ´Ü¼ø ¸ð¼Ç ÇÃ·¹ÀÌ »óÅÂ
			m_nMotionEx = nParam1;				// ¸ð¼Ç ÀÎµ¦½º
			int nPlayMode = nParam2;			// ·çÇÎ ¸ðµå.
			if( m_nMotionEx != -1 )
				pMover->SetMotion( m_nMotionEx, nPlayMode, MOP_FIXED/* | MOP_SWDFORCE*/ );

			pMover->RemoveInvisible();
		}
		break;
	// ÀÏ¹Ý ¾×¼Ç.
	case OBJMSG_RESURRECTION:		// ºÎÈ°.
#ifdef __SECURITY_FIXES
#ifdef __WORLDSERVER
		if (pMover->IsDie() == FALSE && pMover->IsPlayer())
		{
			return 0;
		}
#endif // __WORLDSERVER
#ifdef __CLIENT
		if (CMover::GetActiveMover()->IsDie() == FALSE && CMover::GetActiveMover()->IsPlayer())
			return 0;
#endif // __CLIENT
#endif // __SECURITY_FIXES
		ClearState();
		SetState( OBJSTA_DMG_ALL, OBJSTA_RESURRECTION );
		pMover->SetMotion( MTI_ASS_RESURRECTION, ANILOOP_1PLAY, MOP_FIXED );
		break;


#if	defined(_DEBUG) && defined(__CLIENT)
	case OBJMSG_TEMP:
		{
			for( int i=0; i < 1; i ++ )
			{

				CMover* pObj = new CMover;
				D3DXVECTOR3 vPos = pMover->GetPos();
				pObj->SetPos( vPos );
				pObj->SetIndex( g_Neuz.m_pd3dDevice, MI_AIBATT1, TRUE );
				pObj->SetMotion( 0 );
				g_WorldMng.Get()->AddObj( pObj, TRUE ); 
			}
		}
		break;
		
	case OBJMSG_TEMP2:	// µð¹ö±ë¿ë °ø°Ýµ¿ÀÛ¸¸ º¼¶§.
		if( CMover::GetActiveMover()->IsAuthHigher( AUTH_GAMEMASTER ) )	// ¿µÀÚ °èÁ¤ÀÏ¶§
		{
			CObj *pObj = pMover->GetWorld()->GetObjFocus();
			g_DPlay.SendCorrReq( pObj );
			g_DPlay.SendError( FE_GENERAL, 0 );
		}
		break;
	
	case OBJMSG_TEMP3:
		{
		#ifdef __XUZHU			
			g_DPlay.SendError( 0, 0 );
		#endif
		}
		break;
#endif // defined(_DEBUG) && defined(__CLIENT)
#ifdef __MOUNT
	case OBJMSG_MOUNT_GROUND_STAND:
	{
		if (nParam1 <= 0)
			return FALSE;

		if (nParam3 == 0)
		{
			//if( IsFly() )		return 0;
			if (IsSit())		return 0;
			if (IsAction())	return 0;
			if (IsActAttack())	return 0;
			if (pMover->m_dwFlag & MVRF_NOMOVE)	return 0;		// ÀÌµ¿±ÝÁö »óÅÂ¸é °Á ¸®ÅÏ.
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			if (pMover->GetAdjParam(DST_CHRSTATE) & CHS_LOOT)			return 0;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			{
				CWorld* pWorld = pMover->GetWorld();
				if (pWorld)
				{
					int nAttr = pMover->GetWorld()->GetHeightAttribute(pMover->GetPos().x, pMover->GetPos().z);		// ÀÌµ¿ÇÒ À§Ä¡ÀÇ ¼Ó¼º ÀÐÀ½.
					if (nAttr == HATTR_NOWALK)		// ºñÇà ±ÝÁö Áö¿ª¿¡¼­ Å¸·Á°í ÇÏ¸é ¸øÅº´Ù.
						return 0;
				}
			}
		}

		AddStateFlag(OBJSTAF_MOUNT_GROUND_STAND);
		RemoveStateFlag(OBJSTAF_FLY);
		RemoveStateFlag(OBJSTA_STAND);
		ItemProp* pItemProp = prj.GetItemProp(nParam1);	// ºøÀÚ·ç ÇÁ·ÎÆÛÆ¼.

		ClearState();
#ifdef __CLIENT
		if (m_pMover == CMover::GetActiveMover())
		{
			m_pMover->GetWorld()->SetObjFocus(NULL);	// ºñÇàÁ÷Àü¿¡ ±âÁ¸Å¸°ÙÆÃÀ» Å¬¸®¾îÇØÁØ´Ù.
			g_Neuz.m_camera.Lock();//Kamera Fix
			g_WndMng.m_pWndTaskBar->OnCancelSkill();	// ºñÇàÁ÷Àü¿£ ½ºÅ³¹Ù »ç¿ë Ãë¼Ò.
		}
#endif // __CLIENT

		CModel* pModel = prj.m_modelMng.LoadModel(D3DDEVICE, OT_ITEM, (DWORD)nParam1);
		CModelObject* pModelObject = (CModelObject*)pModel;
		if (pModelObject->m_pBone)
		{
			CString strMotion = pModelObject->GetMotionFileName(_T("stand"));
			assert(strMotion != _T(""));
			pModelObject->LoadMotion(strMotion);
		}
#ifdef __CLIENT
		m_pMover->m_eMountState = pMover->GROUND_STAND;
#endif // __CLIENT
		if (!m_pMover->GetMountModel())
			m_pMover->SetMount(pModel, (DWORD)nParam1);

		m_pMover->SetMotion(prj.GetMountAnimation((DWORD)nParam1)->dwPlayerAni, ANILOOP_LOOP);
		break;
	}
#endif // __MOUNT
	}
	return 1;
}


/*

  p0 + tD0 = -e0

  t = -( p0 + e0 ) / d0

void	Test( RECT r, Point p, Point.d )
{
	Point t;	// ±³Â÷Á¡

	tx = (p0 + 
	
}

*/

// return: attackerÀÇ Æ÷ÀÎÅÍ 
CMover* CActionMover::PreProcessDamage( CMover* pMover, OBJID idAttacker, BOOL bTarget, int nReflect )
{
#ifdef __GAMEGUARD
	if ((pMover->m_dwMode & MATCHLESS_MODE) && pMover->IsAuthHigher(AUTH_GAMEMASTER2))		// ¹«ÀûÀÌ¸é ¿©±â¼­ ¸®ÅÏ.
#else // __GAMEGUARD
	if (pMover->m_dwMode & MATCHLESS_MODE)		// ¹«ÀûÀÌ¸é ¿©±â¼­ ¸®ÅÏ.
#endif // __GAMEGUARD
	{
		return NULL;
	}
#ifdef __NEWCLASS
	if (pMover->HasBuff(BUFF_SKILL, SI_LORDT_U_SKILL_04) && pMover->GetJob() == JOB_LORDTEMPLER_HERO_ULTIMATE)
	{
		return NULL;
	}
#endif // __NEWCLASS
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	if( pMover->GetAdjParam( DST_CHRSTATE ) & CHS_SETSTONE)
		return NULL;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

	CCtrl* pCtrl = prj.GetCtrl( idAttacker );	// °ø°ÝÀÚ 
	if( IsValidObj( pCtrl ) == FALSE )
		return NULL;

	CMover* pAttacker = NULL;
	if( pCtrl->GetType() == OT_MOVER )
		pAttacker = (CMover*)pCtrl; 
	else
		return NULL;							

	if( pMover->IsNPC() )						// ¸Â´Â³ÑÀÌ NPC°í
	{
		MoverProp *pProp = pMover->GetProp();
		if( pProp && pProp->bKillable != 1 )	// Á×ÀÌ±â°¡ ºÒ°¡´É ÇÑ³ÑÀÌ¸é ¿©±â¼­ ¸®ÅÏ.
			return NULL;
	}

#ifdef __WORLDSERVER
	HITTYPE ht = pAttacker->GetHitType( pMover, bTarget, nReflect );
	if( ht == HITTYPE_FAIL )
		return 0;
#if __VER < 10	// __METEONYKER_0608
	pMover->PostAIMsg( AIMSG_DAMAGE, idAttacker ); 
#endif	// __METEONYKER_0608

#endif

	pAttacker->RemoveInvisible();
	return pAttacker;
}
```
