# MoverSkill.cpp

Chemin original: `C:\Users\rdiff\Desktop\__NEWCLASS\_AIInterface\MoverSkill.cpp`
Chemin relatif: `_AIInterface\MoverSkill.cpp`
Nom du fichier: `MoverSkill.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `cp1252`

```cpp
#include "stdafx.h"
#include "defineItem.h"
#include "defineSkill.h"
#include "defineSound.h"
#include "defineText.h"
#include "ModelObject.h"
#include "CreateObj.h"
#include "defineobj.h"
#include "eveschool.h"
#include "party.h"

#include "definequest.h"

#ifdef __CLIENT
	#include "DPClient.h"
#else	// __CLIENT
	#include "..\_aiinterface\AIPet.h"
	#include "User.h"
	#include "WorldMng.h"
	#include "DPSrvr.h"
	#include "DPCoreClient.h"
	#include "dpdatabaseclient.h"
#ifdef __SYS_TICKET
	#include "ticket.h"
#endif	// __SYS_TICKET
#if __VER >= 15 // __PETVIS
	#include "ItemUpgrade.h"
#endif  // __PETVIS
#endif	// __CLIENT

#if __VER >= 11 // __SYS_PLAYER_DATA
#include "playerdata.h"
#endif	// __SYS_PLAYER_DATA

#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
	#include "honor.h"
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ

#ifdef __FUNNY_COIN
#include "FunnyCoin.h"
#endif // __FUNNY_COIN

#ifdef __CLIENT
	extern	CDPClient			g_DPlay;
#else
	extern	CUserMng			g_UserMng;
	extern	CWorldMng			g_WorldMng;
	extern	CDPSrvr				g_DPSrvr;
	extern	CDPCoreClient		g_DPCoreClient;
	extern	CDPDatabaseClient	g_dpDBClient;
#if __VER >= 15 // __GUILD_HOUSE
#include "GuildHouse.h"
#endif // __GUILD_HOUSE
#endif

extern	CPartyMng				g_PartyMng;
extern	CGuildCombat			g_GuildCombatMng;

extern void __SetQuest( DWORD dwIdMover, int nQuest );

#ifdef __WORLDSERVER

#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
void	CMover::SetMasterSkillPointUp()
{
	if( m_nLevel != 72 && m_nLevel != 84 && m_nLevel != 96 && m_nLevel != 108 )
		return;
	if( IsHero() )
		return;
#ifdef __3RD_LEGEND16
	if( IsLegendHero() )
		return;
#endif // __3RD_LEGEND16
#ifdef __NEWCLASS
	if (IsLegendHeroUltimate())
		return;
#endif // __NEWCLASS

	for( int i = 0; i < MAX_SKILL_JOB; i++ ) 
	{				
		LPSKILL lpSkill = &(m_aJobSkill[i]);
		if( lpSkill && lpSkill->dwSkill != NULL_ID )
		{
			ItemProp* pSkillProp    = prj.GetSkillProp( lpSkill->dwSkill );			
			if( pSkillProp == NULL )
				continue;
			if( pSkillProp->dwItemKind1 != JTYPE_MASTER)
				continue;
			lpSkill->dwLevel++;
			g_dpDBClient.SendLogSkillPoint( LOG_SKILLPOINT_USE, 1, this, &(m_aJobSkill[i]) );
		}
	}	
	g_UserMng.AddCreateSfxObj(this, XI_SYS_EXCHAN01, GetPos().x, GetPos().y, GetPos().z);

	CUser *pUser = (CUser *)this;
	pUser->AddDoUseSkillPoint( &m_aJobSkill[0], m_nSkillPoint );

#ifdef __S_NEW_SKILL_2
	g_dpDBClient.SaveSkill( this );
#endif // __S_NEW_SKILL_2
}
#endif	//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

// ½ºÅ³Å¥¿¡ µé¾î ÀÖ´Â ¸¶¹ýµéÀÇ ÃÑ Ä³½ºÆÃ ½Ã°£À» °è»ê.
int		CMover::GetQueueCastingTime()
{
#ifdef __NEW_TASKBAR_V19
	/*if (!g_Option.isClassicTheme() && !g_Option.isRedTheme() && !g_Option.isClassicBlueTheme())
		return 0;
	else */
	{
		if (IsNPC())
			return 0;

		CUser* pUser = (CUser*)this;
		int		i;
		SHORTCUT* pSlotQueue = pUser->m_playTaskBar.m_aSlotQueue;
		int		nTotalTime = 0;

		for (i = 0; i < MAX_SLOT_QUEUE; i++)
		{
			if (pSlotQueue[i].m_dwShortcut)
			{
				LPSKILL pSkill = GetSkill(0, pSlotQueue[i].m_dwId);

				ItemProp* pSkillProp;
				if (!(pSkillProp = pSkill->GetProp()))					// JobSkill ¸®½ºÆ®¿¡¼­ ²¨³½ ½ºÅ³ÀÇ ÇÁ·ÎÆÛÆ¼¸¦ ²¨³¿.
				{
					Error("CMover::GetQueueCastingTime : %s. ½ºÅ³(%d)ÀÇ ÇÁ·ÎÆÛÆ¼°¡ ¾ø´Ù.", m_szName, pSkill->dwSkill);
					return FALSE;	// property not found
				}

				AddSkillProp* pAddSkillProp;

#ifdef __SKILL0517
				if (!(pAddSkillProp = prj.GetAddSkillProp(pSkillProp->dwSubDefine, GetSkillLevel(pSkill))))					// JobSkill ¸®½ºÆ®¿¡¼­ ²¨³½ ½ºÅ³ÀÇ ÇÁ·ÎÆÛÆ¼¸¦ ²¨³¿.
#else	// __SKILL0517
				if (!(pAddSkillProp = prj.GetAddSkillProp(pSkillProp->dwSubDefine, pSkill->dwLevel)))					// JobSkill ¸®½ºÆ®¿¡¼­ ²¨³½ ½ºÅ³ÀÇ ÇÁ·ÎÆÛÆ¼¸¦ ²¨³¿.
#endif	// __SKILL0517
				{
					Error("CMover::GetQueueCastingTime : %s. ¾Öµå½ºÅ³(%d)ÀÇ ÇÁ·ÎÆÛÆ¼°¡ ¾ø´Ù.", m_szName, pSkill->dwSkill);
					return FALSE;	// property not found
				}

#ifdef _DEBUG
#if __VER >= 9	// __SKILL_0706
				if ((int)pAddSkillProp->dwCastingTime <= 0)
					Error("GetQueueCastingTime : %sÀÇ addProp dwCastingTimeÀÌ %d", pSkillProp->szName, pAddSkillProp->dwCastingTime);
#else	// __SKILL_0706
				if ((int)pAddSkillProp->dwSkillReady <= 0)
					Error("GetQueueCastingTime : %sÀÇ addProp dwSkillReady°¡ %d", pSkillProp->szName, pAddSkillProp->dwSkillReady);
#endif	// __SKILL_0706
#endif
#if __VER >= 9	// __SKILL_0706
				nTotalTime += (int)pAddSkillProp->dwCastingTime;
#else	// __SKILL_0706
				nTotalTime += (int)pAddSkillProp->dwSkillReady;
#endif	// __SKILL_0706
			}
		}

		nTotalTime = (int)(nTotalTime * 0.7f);		// 70ÇÁ·Î Àû¿ëÇÑÈÄ.
		nTotalTime = (int)((nTotalTime / 1000.0f) * SEC1);	// Ä³½ºÆÃ´ÜÀ§ ½Ã°£À¸·Î º¯È¯.
		nTotalTime = GetCastingTime(nTotalTime);

		return nTotalTime;
	}
#else // __NEW_TASKBAR_V19
	if (IsNPC())
		return 0;

	CUser* pUser = (CUser*)this;
	int		i;
	SHORTCUT* pSlotQueue = pUser->m_playTaskBar.m_aSlotQueue;
	int		nTotalTime = 0;

	for (i = 0; i < MAX_SLOT_QUEUE; i++)
	{
		if (pSlotQueue[i].m_dwShortcut)
		{
			LPSKILL pSkill = GetSkill(0, pSlotQueue[i].m_dwId);

			ItemProp* pSkillProp;
			if (!(pSkillProp = pSkill->GetProp()))					// JobSkill ¸®½ºÆ®¿¡¼­ ²¨³½ ½ºÅ³ÀÇ ÇÁ·ÎÆÛÆ¼¸¦ ²¨³¿.
			{
				Error("CMover::GetQueueCastingTime : %s. ½ºÅ³(%d)ÀÇ ÇÁ·ÎÆÛÆ¼°¡ ¾ø´Ù.", m_szName, pSkill->dwSkill);
				return FALSE;	// property not found
			}

			AddSkillProp* pAddSkillProp;

#ifdef __SKILL0517
			if (!(pAddSkillProp = prj.GetAddSkillProp(pSkillProp->dwSubDefine, GetSkillLevel(pSkill))))					// JobSkill ¸®½ºÆ®¿¡¼­ ²¨³½ ½ºÅ³ÀÇ ÇÁ·ÎÆÛÆ¼¸¦ ²¨³¿.
#else	// __SKILL0517
			if (!(pAddSkillProp = prj.GetAddSkillProp(pSkillProp->dwSubDefine, pSkill->dwLevel)))					// JobSkill ¸®½ºÆ®¿¡¼­ ²¨³½ ½ºÅ³ÀÇ ÇÁ·ÎÆÛÆ¼¸¦ ²¨³¿.
#endif	// __SKILL0517
			{
				Error("CMover::GetQueueCastingTime : %s. ¾Öµå½ºÅ³(%d)ÀÇ ÇÁ·ÎÆÛÆ¼°¡ ¾ø´Ù.", m_szName, pSkill->dwSkill);
				return FALSE;	// property not found
			}

#ifdef _DEBUG
#if __VER >= 9	// __SKILL_0706
			if ((int)pAddSkillProp->dwCastingTime <= 0)
				Error("GetQueueCastingTime : %sÀÇ addProp dwCastingTimeÀÌ %d", pSkillProp->szName, pAddSkillProp->dwCastingTime);
#else	// __SKILL_0706
			if ((int)pAddSkillProp->dwSkillReady <= 0)
				Error("GetQueueCastingTime : %sÀÇ addProp dwSkillReady°¡ %d", pSkillProp->szName, pAddSkillProp->dwSkillReady);
#endif	// __SKILL_0706
#endif
#if __VER >= 9	// __SKILL_0706
			nTotalTime += (int)pAddSkillProp->dwCastingTime;
#else	// __SKILL_0706
			nTotalTime += (int)pAddSkillProp->dwSkillReady;
#endif	// __SKILL_0706
		}
	}

	nTotalTime = (int)(nTotalTime * 0.7f);		// 70ÇÁ·Î Àû¿ëÇÑÈÄ.
	nTotalTime = (int)((nTotalTime / 1000.0f) * SEC1);	// Ä³½ºÆÃ´ÜÀ§ ½Ã°£À¸·Î º¯È¯.
	nTotalTime = GetCastingTime(nTotalTime);

	return nTotalTime;
#endif // __NEW_TASKBAR_V19
}

#endif // worldserver


// ÃÖÃÊÀÇ ½ºÅ³ »ç¿ë ¸í·ÉÀÌ ³»¸®Áü
// Mover°¡ »ç¿ë°¡´ÉÇÑ ½ºÅ³¹è¿­(m_aJobSkill[3+14])¿¡¼­ nIdx¿¡ ÇØ´çÇÏ´Â ½ºÅ³À» ²¨³» ±×°ÍÀ» ½ÇÇàÇÑ´Ù.
// sutType : ½ºÅ³»ç¿ë½Ã ´ÜÃàÅ°/½ºÅ³Å¥ÀÇ ¿©ºÎ¸¦ Å¬¶ó·ÎºÎÅÍ ¹Þ¾Æ¼­ Ã³¸®.  Ä³½ºÆÃÅ¸ÀÓ °è»êÀÌ ´Ù¸£´Ù.
//
#ifdef __CLIENT
#if __VER >= 8 // __S8_PK
	BOOL	CMover::DoUseSkill( int nType, int nIdx, OBJID idFocusObj, SKILLUSETYPE sutType, BOOL bControl, const int nCastingTime, DWORD dwSkill, DWORD dwLevel )
#else // __VER >= 8 // __S8_PK
	BOOL	CMover::DoUseSkill( int nType, int nIdx, OBJID idFocusObj, SKILLUSETYPE sutType, const int nCastingTime, DWORD dwSkill, DWORD dwLevel )
#endif // __VER >= 8 // __S8_PK
#else // __CLIENT
	#if __VER >= 8 // __S8_PK
		BOOL	CMover::DoUseSkill( int nType, int nIdx, OBJID idFocusObj, SKILLUSETYPE sutType, BOOL bControl )
	#else // __VER >= 8 // __S8_PK
		BOOL	CMover::DoUseSkill( int nType, int nIdx, OBJID idFocusObj, SKILLUSETYPE sutType )
	#endif // __VER >= 8 // __S8_PK
#endif // __CLIENT
{
	if( IsNPC() )	
		return FALSE;		// ¿£ÇÇ¾¾´Â ÀÌÂÊÀ» Å¸¸é ¾ÈµÈ´Ù.

#ifdef __WORLDSERVER
	DWORD dwSkill = 0, dwLevel;
#endif	// __WORLDSERVER
	
	if( nIdx >= 0 )
	{
		LPSKILL pSkill = GetSkill( nType, nIdx );
		if( pSkill == NULL )
		{
			Error( "CMover::DoUseSkill : %s´Â nIdx¿¡ ½ºÅ³À» °¡Áö°í ÀÖÁö ¾Ê´Ù. %d", m_szName, nIdx );
			return FALSE;
		}
		dwSkill	= pSkill->dwSkill;
	#ifdef __SKILL0517
		dwLevel	= GetSkillLevel( pSkill );
	#else	// __SKILL0517
		dwLevel	= pSkill->dwLevel;
	#endif	// __SKILL0517

		if( dwSkill == DWORD(-1) )
			return FALSE;

		if( dwLevel <= 0 )
			return FALSE;
/*
#ifdef __GUILD_COMBAT_1TO1 // chipi_071227 ÀÓ½Ã·Î ¸·À½
		if( dwSkill == SI_KNT_HERO_DRAWING )
		{
		#ifdef __CLIENT
			if( g_GuildCombat1to1Mng.IsPossibleMover( this ) )
				return FALSE;
		#endif // __CLIENT
		#ifdef __WORLDSERVER
			if( g_GuildCombat1to1Mng.IsPossibleUser( (CUser*)this ) )
			{
				((CUser*)this)->AddDefinedText( TID_GAME_NEVERKILLSTOP );
				return FALSE;
			}
		#endif // __WORLDSERVER
		}
#endif // __GUILD_COMBAT_1TO1
*/
	}

#ifdef __WORLDSERVER
	int nCastingTime = 0;
#endif

	ItemProp *pSkillProp = NULL;
	AddSkillProp *pAddSkillProp = NULL;
	GetSkillProp( &pSkillProp, &pAddSkillProp, dwSkill, dwLevel, "DoUseSkill_P" );

	if(pSkillProp == NULL)
		return FALSE;

	OBJMSG dwMsg = OBJMSG_NONE;
	int nMotion = (int)pSkillProp->dwUseMotion;
	
#ifdef __NEW_TASKBAR_V19
	/*if(!g_Option.isClassicTheme() && !g_Option.isRedTheme() && !g_Option.isClassicBlueTheme())
	{
		if( pSkillProp->dwSkillType == KT_MAGIC )
		{
			#ifdef __WORLDSERVER
				nCastingTime = 0;
			#endif

			if( sutType == SUT_QUEUESTART )
				dwMsg = OBJMSG_MAGICSKILL;
			else if( sutType == SUT_QUEUEING )
			{
				dwMsg = OBJMSG_MAGICSKILL;
				nMotion += 2;
			}
			else
				dwMsg = OBJMSG_MAGICSKILL;
		}
		else if( pSkillProp->dwSkillType == KT_SKILL )
		{
		#ifdef __WORLDSERVER
			nCastingTime = 1;
		#endif
		}
	}
	else*/
	{
		if (pSkillProp->dwSkillType == KT_MAGIC)
		{
			if (sutType == SUT_QUEUESTART)		// ½ºÅ³Å¥ ½ÃÀÛ ½ºÅ³
			{
#ifdef __WORLDSERVER
				nCastingTime = GetQueueCastingTime();	// Å¥³»ÀÇ ¸ðµç ½ºÅ³ÀÇ Ä³½ºÆÃÀ» ¸ô¾Æ¼­ ÇÑ´Ù.
#endif
				dwMsg = OBJMSG_MAGICCASTING;
			}
			else if (sutType == SUT_QUEUEING)	// ½ºÅ³Å¥ ÁøÇàÁß ½ºÅ³
			{
#ifdef __WORLDSERVER
				nCastingTime = 0;						// Ä³½ºÆÃ µ¿ÀÛ¾øÀÌ ½ÃÀü.
#endif
				nMotion += 2;
				dwMsg = OBJMSG_MAGICSKILL;
			}
			else
			{									// ÀÏ¹ÝÀûÀÎ ¸¶¹ý ½ºÅ³ »ç¿ë
#ifdef __WORLDSERVER

#if __VER >= 9	// __SKILL_0706
				nCastingTime = (int)((pAddSkillProp->dwCastingTime / 1000.0f) * SEC1);	// Ä³½ºÆÃ µ¿ÀÛ ÀÖÀ½.
#else	// __SKILL_0706
				nCastingTime = (int)((pAddSkillProp->dwSkillReady / 1000.0f) * SEC1);	// Ä³½ºÆÃ µ¿ÀÛ ÀÖÀ½.
#endif	// __SKILL_0706

				nCastingTime = GetCastingTime(nCastingTime);
#endif	// __WORLDSERVER
				dwMsg = OBJMSG_MAGICCASTING;
			}
		}
		else if (pSkillProp->dwSkillType == KT_SKILL)
		{
#ifdef __WORLDSERVER
			nCastingTime = 1;
#endif
		}
	}
#else // __NEW_TASKBAR_V19
	if (pSkillProp->dwSkillType == KT_MAGIC)
	{
		if (sutType == SUT_QUEUESTART)		// ½ºÅ³Å¥ ½ÃÀÛ ½ºÅ³
		{
#ifdef __WORLDSERVER
			nCastingTime = GetQueueCastingTime();	// Å¥³»ÀÇ ¸ðµç ½ºÅ³ÀÇ Ä³½ºÆÃÀ» ¸ô¾Æ¼­ ÇÑ´Ù.
#endif
			dwMsg = OBJMSG_MAGICCASTING;
		}
		else if (sutType == SUT_QUEUEING)	// ½ºÅ³Å¥ ÁøÇàÁß ½ºÅ³
		{
#ifdef __WORLDSERVER
			nCastingTime = 0;						// Ä³½ºÆÃ µ¿ÀÛ¾øÀÌ ½ÃÀü.
#endif
			nMotion += 2;
			dwMsg = OBJMSG_MAGICSKILL;
		}
		else
		{									// ÀÏ¹ÝÀûÀÎ ¸¶¹ý ½ºÅ³ »ç¿ë
#ifdef __WORLDSERVER

#if __VER >= 9	// __SKILL_0706
			nCastingTime = (int)((pAddSkillProp->dwCastingTime / 1000.0f) * SEC1);	// Ä³½ºÆÃ µ¿ÀÛ ÀÖÀ½.
#else	// __SKILL_0706
			nCastingTime = (int)((pAddSkillProp->dwSkillReady / 1000.0f) * SEC1);	// Ä³½ºÆÃ µ¿ÀÛ ÀÖÀ½.
#endif	// __SKILL_0706

			nCastingTime = GetCastingTime(nCastingTime);
#endif	// __WORLDSERVER
			dwMsg = OBJMSG_MAGICCASTING;
		}
	}
	else if (pSkillProp->dwSkillType == KT_SKILL)
	{
#ifdef __WORLDSERVER
		nCastingTime = 1;
#endif
	}
#endif // __NEW_TASKBAR_V19

#if __VER >= 8 // __S8_PK
	BOOL bSuccess = DoUseSkill( dwSkill, dwLevel, idFocusObj, sutType, bControl, nCastingTime );
#else // __VER >= 8 // __S8_PK
	BOOL bSuccess = DoUseSkill( dwSkill, dwLevel, idFocusObj, sutType, nCastingTime );
#endif // __VER >= 8 // __S8_PK
	return  bSuccess;
}

// dwSkill,nLevel¸¸ ÀÖÀ¸¸é ¾îµð¼­µçÁö »ç¿ë°¡´ÉÇÑ ¹öÀü	
// ¸ó½ºÅÍ±îÁö »ç¿ë°¡´É
#if __VER >= 8 // __S8_PK
BOOL CMover::DoUseSkill( DWORD dwSkill, int nLevel, OBJID idFocusObj, SKILLUSETYPE sutType, BOOL bControl, const int nCastingTime )
#else // __VER >= 8 // __S8_PK
BOOL CMover::DoUseSkill( DWORD dwSkill, int nLevel, OBJID idFocusObj, SKILLUSETYPE sutType, const int nCastingTime )
#endif // __VER >= 8 // __S8_PK
{
	if( IsDie() )	return FALSE;
	if( m_pActMover->IsFly() )	return FALSE;
#ifdef __MOUNT
	if (m_pActMover->IsUseMount()) return FALSE;
#endif // __MOUNT
	if( m_dwFlag & MVRF_NOATTACK )	
		return FALSE;		// °ø°Ý±ÝÁö »óÅÂ¿¡¼± ½ºÅ³ ¸ø¾¸.

#ifdef __QUIZ
	if( GetWorld() && GetWorld()->GetID() == WI_WORLD_QUIZ )
		return FALSE;
#endif // __QUIZ
	
#if defined(__WORLDSERVER)	
	// ±æµå´ëÀü¸Ê¿¡¼­ ¼±¼ö¸¸ »ç¿ë
	CWorld* pWorld	= GetWorld();
	if( pWorld && pWorld->GetID() == WI_WORLD_GUILDWAR )
	{		
		if( m_nGuildCombatState == 0 )
		{
			if( IsPlayer() )
				((CUser*) this)->AddText( prj.GetText( TID_GAME_GUILDCOMBAT_STANDS_NOTUSESKILL ) );	//"¼öÁ¤ÇØ¾ßÇÔ : °üÁß¼®¿¡¼­´Â ½ºÅ³À» »ç¿ëÇÒ¼ö ¾ø½À´Ï´Ù" );
			return FALSE;
		}
#ifdef __GAMEGUARD
		CGuildCombat::__GuildCombatMember* pGCMember = g_GuildCombatMng.FindGuildCombatMember(m_idGuild);
		if (pGCMember != NULL)
		{
			CGuildCombat::__JOINPLAYER* pJoinPlayer;
			for (int veci = pGCMember->vecGCSelectMember.size() - 1; veci >= 0; --veci)
			{
				pJoinPlayer = pGCMember->vecGCSelectMember[veci];
				if (pJoinPlayer->uidPlayer == m_idPlayer && pJoinPlayer->nlife <= 0 && IsPlayer())
				{
					((CUser*)this)->AddText(prj.GetText(TID_GAME_GUILDCOMBAT_STANDS_NOTUSESKILL));
					return FALSE;
				}
			}
		}
#endif // __GAMEGUARD
	}
#endif //defined(__WORLDSERVER)

	if( IsMode( NO_ATTACK_MODE ) ) return FALSE;
	
	ItemProp *pSkillProp = NULL;
	AddSkillProp *pAddSkillProp = NULL;
	GetSkillProp( &pSkillProp, &pAddSkillProp, dwSkill, nLevel, "DoUseSkill" );

#ifdef __CLIENT
	// ÀÏ´ëÀÏ ±æµå´ëÀü ½Ã ºí¸µÅ©Ç® »ç¿ë ±ÝÁö
	DWORD dwWorldID(GetWorld()->GetID());
	if(dwWorldID >= WI_WORLD_GUILDWAR1TO1_0 && dwWorldID <= WI_WORLD_GUILDWAR1TO1_L)
	{
		if(pSkillProp->dwID == SI_MAG_MAG_BLINKPOOL)
		{
			g_WndMng.PutString(prj.GetText(TID_GAME_NEVERKILLSTOP), NULL, prj.GetTextColor(TID_GAME_NEVERKILLSTOP));
			return FALSE;
		}
	}
#endif // __CLIENT

#ifdef __GOLDEN_MINE
#ifdef __WORLDSERVER
	if (pWorld && pWorld->GetID() == WI_WORLD_MINE)
	{
		switch (pSkillProp->dwID)
		{
		case SI_BLD_DOUBLESW_BLADEDANCE:
		case SI_BLD_DOUBLE_SONICBLADE:
		case SI_STORM_DOUBLE_STORMBLAST:
		case SI_KNT_TWOSW_EARTHDIVIDER:
		case SI_KNT_TWOAX_POWERSTUMP:
		case SI_KNT_TWO_POWERSWING:
		case SI_LOD_SUP_SCOPESTRIKE:

		case SI_ASS_KNU_BURSTCRACK:
		case SI_BIL_KNU_PIERCINGSERPENT:
		case SI_BIL_PST_BGVURTIALBOLD:
		case SI_RIN_SUP_MERKABAHANZELRUSHA:

		case SI_ACR_BOW_ARROWRAIN:
		case SI_RAG_BOW_ICEARROW:
		case SI_RAG_BOW_FLAMEARROW:
		case SI_RAG_BOW_PIRCINGARROW:
		case SI_CRA_CRBOW_RANGESTRIKE:

		case SI_ELE_FIRE_BURINGFIELD:
		case SI_ELE_EARTH_EARTHQUAKE:
		case SI_ELE_WIND_WINDFIELD:
		case SI_ELE_ELECTRICITY_ELETRICSHOCK:
		case SI_ELE_WATER_POISONCLOUD:
		case SI_ELE_MULTY_METEOSHOWER:
		case SI_ELE_MULTY_LIGHTINGSTORM:
		case SI_ELE_MULTY_SANDSTORM:
		case SI_ELE_MULTY_AVALANCHE:
		case SI_ELE_STF_THUNDERBOLT:
		case SI_PSY_PSY_MAXIMUMCRISIS:
		case SI_PSY_PSY_PSYCHICWALL:
		case SI_PSY_PSY_PSYCHICSQUARE:
		{
			((CUser*)this)->AddText("You cannot use that skill here", 0xFFFF0000);
			return FALSE;
		}
	}
}
#endif // __WORLDSERVER
#endif // __GOLDEN_MINE

	CMover* pTarget = prj.GetMover( idFocusObj );	// Å¸°ÙÀÇ Æ÷ÀÎÅÍ¸¦ ¾ò¾î³¿.
	if( IsInvalidObj( pTarget ) )	
		return FALSE;

	if( pSkillProp->dwID == SI_ASS_HEAL_HEALING )	// Èú¸µ »ó´ë°¡ Á×¾úÀ¸¸é Ãë¼Ò
	{
		if( pTarget->IsDie() )
			return FALSE;
	}

#ifdef __WORLDSERVER
#ifdef __PK_PVP_SKILL_REGION
	if( pSkillProp->nEvildoing < 0 )	//PK ±ÝÁö±¸¿ª¿¡¼­ ¾ÇÇà Á¾·ùÀÇ ½ºÅ³Àº PVP »ó´ë¿¡°Ô¸¸ »ç¿ëÇÏµµ·Ï..
	{
		int nAttackerPK, nDefenderPK;
		nAttackerPK = nDefenderPK = 0;
		if( IsPlayer() && pTarget->IsPlayer() && (this != pTarget) ) //(this!=pTarget) - Å¸°ÙÀ» ¾ÈÂï´Â ½ºÅ³Àº Å¸°ÙÀÌ ½ÃÀüÀÚÀÌ´Ù.
		{
			DWORD dwRegionAttr	= GetPKPVPRegionAttr();
			nAttackerPK = IsPKPVPInspectionBase( dwRegionAttr, FALSE );
			nDefenderPK = pTarget->IsPKPVPInspectionBase( dwRegionAttr, FALSE );
			if( (nAttackerPK == 1 || nDefenderPK == 1) &&
				!( 
						IsPVPTarget( pTarget )
					|| IsWarTarget( pTarget )
					|| IsGuildCombatTarget( pTarget ) 
#ifdef __JEFF_11_4
					|| IsArenaTarget( pTarget )
#endif	// __JEFF_11_4
#ifdef __DEATH_MATCH
					|| IsSiegeTarget(pTarget)
#endif // __DEATH_MATCH
				) )
			{
				((CUser*)this)->AddDefinedText( TID_GMAE_PK_NOT_AREA, "" );
				return FALSE;
			}
		}
	}
#endif // __PK_PVP_SKILL_REGION
	if( 
#ifdef __NEWCLASS
		HasBuff(BUFF_SKILL, SI_STORM_U_SKILL_01)
#endif // __NEWCLASS
		)		// ¹ö¼­Å©°¡ °É·ÁÀÖ´Â »óÅÂ¿¡¼± ½ºÅ³»ç¿ë ±ÝÁö.
	{
		return FALSE;
	}

#ifdef __NPC_BUFF
	if( ( pSkillProp->dwID == SI_ASS_CHEER_QUICKSTEP && pTarget->HasBuff(BUFF_SKILL, SI_GEN_EVE_QUICKSTEP) )
		|| ( pSkillProp->dwID == SI_ASS_CHEER_HASTE && pTarget->HasBuff(BUFF_SKILL, SI_GEN_EVE_HASTE) )
		|| ( pSkillProp->dwID == SI_ASS_CHEER_HEAPUP && pTarget->HasBuff(BUFF_SKILL, SI_GEN_EVE_HEAPUP) )
		|| ( pSkillProp->dwID == SI_ASS_CHEER_ACCURACY && pTarget->HasBuff(BUFF_SKILL, SI_GEN_EVE_ACCURACY) ) )
	{
		if( pTarget->IsPlayer() )
			((CUser*)pTarget)->AddDefinedText( TID_GAME_NPCBUFF_FAILED, "\"%s\"", pSkillProp->szName );
		return FALSE;
	}
#endif // __NPC_BUFF

#ifdef __GAMEGUARD
	FLOAT fRange = GetAttackRange(pSkillProp->dwAttackRange);
	switch (pSkillProp->dwID)
	{
	case SI_BIL_PST_ASALRAALAIKUM:
	{
		if (fRange > GetAttackRange(AR_SHORT))
			return FALSE;
	}
	break;
	case SI_JST_YOYO_HITOFPENYA:
	case SI_ASS_HEAL_PREVENTION:
	case SI_ASS_CHEER_STONEHAND:
	case SI_ASS_KNU_POWERFIST:
	{
		if (fRange > GetAttackRange(AR_HRANGE))
			return FALSE;
		}
	break;
	}
#endif // __GAMEGUARD
	if( pSkillProp->dwID == SI_ACR_YOYO_SNITCH || pSkillProp->dwID == SI_JST_YOYO_VATALSTAB )	// °­Å», È¥½ÅÀÇ ÀÏ°Ý½ºÅ³ÀÌ¸é ´ÙÀÌÀÏ·çÁ¯»óÅÂÀÎÁö °Ë»çÇÑ´Ù.
	{
		if( !HasBuff( BUFF_SKILL, SI_ACR_SUP_DARKILLUSION ) )		// ´ÙÅ©ÀÏ·çÁ¯ »óÅÂ°¡ ¾Æ´Ï¸é »ç¿ë¸øÇÔ
		{
			if( IsPlayer() )
				((CUser*)this)->AddDefinedText( TID_GAME_REQ_DARK, "" );		// ´ÙÅ©ÀÏ·çÁ¯»óÅÂ¿¡¼­ °¡´ÉÇÕ´Ï´Ù.
			return FALSE;
		}
	}

#ifdef __NEWCLASS
	if (pSkillProp->dwID == SI_STORM_U_SKILL_03)	// °­Å», È¥½ÅÀÇ ÀÏ°Ý½ºÅ³ÀÌ¸é ´ÙÀÌÀÏ·çÁ¯»óÅÂÀÎÁö °Ë»çÇÑ´Ù.
	{
		if (!HasBuff(BUFF_SKILL, SI_STORM_U_SKILL_02))		// ´ÙÅ©ÀÏ·çÁ¯ »óÅÂ°¡ ¾Æ´Ï¸é »ç¿ë¸øÇÔ
		{
			if (IsPlayer())
				((CUser*)this)->AddText(prj.GetText(TID_4TH_JOB_ER_01), 0xFFFF0000);		// ´ÙÅ©ÀÏ·çÁ¯»óÅÂ¿¡¼­ °¡´ÉÇÕ´Ï´Ù.
			return FALSE;
		}
	}
#endif // __NEWCLASS

#if __VER >= 13 // __RAINBOW_RACE
#ifndef __RM_HERO_SKILL
	if (pSkillProp->dwID == SI_RIG_HERO_RETURN
		&& IsPlayer() && CRainbowRaceMng::GetInstance()->IsEntry(((CUser*)this)->m_idPlayer))
	{
		((CUser*)this)->AddDefinedText(TID_GAME_RAINBOWRACE_NOTELEPORT);
		return FALSE;
	}
#endif
#endif // __RAINBOW_RACE
#ifdef __3RD_LEGEND16
	DWORD dwWorldID(GetWorld()->GetID());
	if( pSkillProp->dwID == SI_LOD_SUP_PULLING && dwWorldID != WI_INSTANCE_BEHAMAH )
	{
		((CUser*)this)->AddDefinedText( TID_GAME_NEVERKILLSTOP );
		return FALSE;
	}
	if( pSkillProp->dwID == SI_LOD_SUP_ANGER && dwWorldID != WI_INSTANCE_BEHAMAH )
	{
		((CUser*)this)->AddDefinedText( TID_GAME_NEVERKILLSTOP );
		return FALSE;
	}
#endif //__3RD_LEGEND16
#endif //defined(__WORLDSERVER)

	MoverProp *pMoverProp = pTarget->GetProp();
	if( pMoverProp == NULL )
		Error( "DoUseSkill : %s , Å¸°Ù %s ÀÇ ÇÁ·ÎÆÛÆ¼°¡ ¾ø´Ù", m_szName, pTarget->m_szName );
	
	if( pTarget != this )	// Å¸ÀÎ¿¡°Ô ¾²´Â Á¾·ùÀÏ¶§¸¸ ¾Æ·¡°Ë»ç¸¦ ÇÔ.
	{
	#ifdef __WORLDSERVER
		if( pSkillProp->dwUseChance == WUI_NOW )	// Ë¬ - ¸®¼Ò½º ÇØÅ·
			return FALSE;
		if( pSkillProp->dwExeTarget == EXT_SELFCHGPARAMET )
			return FALSE;

		if( pTarget->IsNPC() && pTarget->IsPeaceful() )	
			return FALSE;	// NPCÁö¸¸ Ä£ÇÑ?NPC¿¡°Õ ½ºÅ³ »ç¿ë ±ÝÁö
		
		if( !g_eLocal.GetState( EVE_STEAL ) )
		{
			if( pSkillProp->nEvildoing < 0 )	// ³ª»Û¸¶¹ýÀ» ¾²·ÁÇÒ¶§
				if( IsSteal( pTarget ) )	// pTarget¸¦ ½ºÆ¿ ÇÏ·ÁÇÏ¸é 
					return FALSE;
		}
#ifdef __JEFF_11_4
#ifdef __GAMEMASTER
		if (pWorld && pWorld->IsArena() == FALSE && !IsAuthHigher(AUTH_GAMEMASTER3))		// ¾Æ·¹³ª°¡ ¾Æ´Ï¸é,
#else // __GAMEMASTER
		if (pWorld && pWorld->IsArena() == FALSE)		// ¾Æ·¹³ª°¡ ¾Æ´Ï¸é,
#endif // __GAMEMASTER
#endif	// __JEFF_11_4
		{
			if( pSkillProp->nEvildoing > 0 )	// ÁÁÀº ¸¶¹ýÀ»
			{
				HITTYPE hy;
#if __VER >= 8 // __S8_PK
				if( (hy = GetHitType2( pTarget, TRUE, TRUE)) != HITTYPE_FAIL )  	// Àû´ëÀûÀÎ ´ë»ó¿¡°Ô ¾²·ÁÇÒ¶§
#else // __VER >= 8 // __S8_PK
				if( (hy = GetHitType2( pTarget, TRUE)) != HITTYPE_FAIL )  	// Àû´ëÀûÀÎ ´ë»ó¿¡°Ô ¾²·ÁÇÒ¶§
#endif // __VER >= 8 // __S8_PK
				{
					if( IsPlayer() )
						((CUser*)this)->AddDefinedText( TID_GAME_NEVERKILLSTOP, "" );		// ½ºÅ³À» »ç¿ëÇÒ ¼ö ¾ø½À´Ï´Ù.
					return FALSE;		// ½ºÅ³ Ãë¼Ò
				}
			}
		}
		
	#endif
		SetAngle( GetDegree(pTarget->GetPos(), GetPos()) );		// ¸ñÇ¥ÂÊÀ¸·Î ¸öÀ» µ¹¸².
	}
	
	// ±æµåÄÄ¹îÁß¿¡´Â ºÎÈ°½ºÅ³ ±ÝÁö
	if( GetWorld()->GetID() == WI_WORLD_GUILDWAR )
	{
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if (pSkillProp->dwID == SI_MAG_MAG_BLINKPOOL
#ifndef __RM_HERO_SKILL
			|| pSkillProp->dwID == SI_RIG_HERO_RETURN
#endif
			)
#else //__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pSkillProp->dwID == SI_MAG_MAG_BLINKPOOL )
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			return FALSE;

		if( g_GuildCombatMng.m_nState != CGuildCombat::WAR_STATE )
		{
			if( pSkillProp->dwID == SI_ASS_HEAL_RESURRECTION )
				return FALSE;
#ifdef __NEWCLASS
			if (pSkillProp->dwID == SI_MENTA_U_SKILL_03)
				return FALSE;
#endif // __NEWCLASS
		}
	}

#ifdef __WORLDSERVER

/*
---- 2008.03.25 µå·ÎÀ×½ºÅ³ ¹ö±× »èÁ¦
	#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	if( pSkillProp->dwID == SI_KNT_HERO_DRAWING )
	{
		CParty* pParty	= g_PartyMng.GetParty( ((CUser*)this)->m_idparty );
		if( pParty )
			pParty->DoUsePartyReCall( ((CUser*)this)->m_idparty, ((CUser*)this)->m_idPlayer, 0);
	}
	#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
---- 2008.03.25 µå·ÎÀ×½ºÅ³ ¹ö±× »èÁ¦
*/
	if( g_eLocal.GetState( EVE_SCHOOL ) )
	{
		if( pSkillProp->dwID == SI_ASS_HEAL_RESURRECTION )
			return FALSE;
#ifdef __NEWCLASS
		if (pSkillProp->dwID == SI_MENTA_U_SKILL_03)
			return FALSE;
#endif // __NEWCLASS
	}

	// ½ºÅ³À» »ç¿ëÇÒ¶§ ÀûÇÕÇÑ ¹«±â¸¦ µé°í ÀÖ´Â°¡ °Ë»ç
	ItemProp* pItemProp = NULL;
	DWORD	dwItemKind3;

	if( pSkillProp->dwLinkKind == IK3_SHIELD || pSkillProp->dwLinkKind == IK3_MAGICBARUNA || pSkillProp->dwLinkKind == IK3_ZEMBARUNA )	// ÇÊ¿ä¾Æ¾ÆÀÌÅÛÀÌ ¹æÆÐÀÏ¶§
	{
		CItemElem *pItemElem = GetEquipItem( PARTS_SHIELD );
		if( pItemElem )
		{
			pItemProp = pItemElem->GetProp();
			dwItemKind3 = pItemProp->dwItemKind3;
		} else
			dwItemKind3 = NULL_ID;
	}
	else	// ÇÊ¿ä¾ÆÀÌÅÛÀÌ ¹æÆÐ°¡ ¾Æ´Ò¶§´Â ¾×Æ¼ºê ¾ÆÀÌÅÛÀ»...
	{
		pItemProp = GetActiveHandItemProp();
		dwItemKind3 = pItemProp->dwItemKind3;
	}
	
	switch( pSkillProp->dwLinkKind )	// ½ºÅ³ÀÌ ÇÊ¿ä·ÎÇÏ´Â ¹«±â.
	{
	case IK3_ENCHANTWEAPON:
		{
			if( IsPlayer() )
			{
				BOOL bFail = FALSE;

				CItemElem *pItemElemR = GetWeaponItem();
				CItemElem *pItemElemL = GetLWeaponItem();

				if( pItemElemR && pItemElemL )	// ¾ç¼ÕÁã°í ÀÖÀ»¶§.
				{	// ¾ç¼Õ´Ù ¼Ó¼ºÀÌ ¾øÀ»¶©
					if( (pItemElemR && pItemElemR->m_bItemResist == SAI79::NO_PROP) &&		
						(pItemElemL && pItemElemL->m_bItemResist == SAI79::NO_PROP) )
						bFail = TRUE;		// »ç¿ë±ÝÁö
				} 
				else if( pItemElemR && pItemElemL == NULL )	// ¿À¸¥¼Õ¸¸ Áã°í ÀÖÀ»¶§.
				{
					if( pItemElemR && pItemElemR->m_bItemResist == SAI79::NO_PROP )		// ¿À¸¥¼Õ¿¡ ¼Ó¼ºÀÌ ¾øÀ»¶©
						bFail = TRUE;		// »ç¿ë±ÝÁö
				} 
				else if( pItemElemR == NULL && pItemElemL == NULL )	// ¾ç¼Õ´Ù ¾øÀ»¶§
				{
					bFail = TRUE;		// ÀÌ¶§´Â ¹«Á¶°Ç »ç¿ë±ÝÁö
				}

				if( bFail )
				{
					( (CUser*)this )->AddDefinedText( TID_SKILL_NOTELEWEAPON, "" );	// ¼Ó¼º¹«±â°¡ ¾ø¾î »ç¿ë¸øÇÔ.
					return FALSE;
				}
			}
		}
		break;
	case IK3_MAGICBOTH:
		if( dwItemKind3 != IK3_WAND  && dwItemKind3 != IK3_STAFF )	// ¼Õ¿¡µç ¹«±â°¡ ¿Ïµåµµ ½ºÅÂÇÁµµ ¾Æ´Ï¸é
		{
			if( IsPlayer() )
				( (CUser*)this )->AddDefinedText( TID_GAME_WRONGITEM, "" );
			return FALSE;
		}
		break;
	case IK3_YOBO:
#ifdef __CROSSBOW
		if( dwItemKind3 != IK3_YOYO && dwItemKind3 != IK3_BOW && dwItemKind3 != IK3_CROSSBOW )	
#else // __CROSSBOW
		if( dwItemKind3 != IK3_YOYO && dwItemKind3 != IK3_BOW )	
#endif // __CROSSBOW
		{
			if( IsPlayer() )
				( (CUser*)this )->AddDefinedText( TID_GAME_WRONGITEM, "" );
			return FALSE;
		}
		break;
#ifdef __CROSSBOW
	case IK3_BOW:
		if( dwItemKind3 != IK3_BOW && dwItemKind3 != IK3_CROSSBOW )
		{
			if( IsPlayer() )
				( (CUser*)this )->AddDefinedText( TID_GAME_WRONGITEM, "" );
			return FALSE;
		}
		break;
#endif // __CROSSBOW
	default:
		if( pSkillProp->dwLinkKind != NULL_ID && pSkillProp->dwLinkKind != dwItemKind3 )	// ±×¿Ü´Â IK3¸¦ ºñ±³ÇØ¼­ Æ²¸®¸é ¿¡·¯.
		{
			if( IsPlayer() )
				( (CUser*)this )->AddDefinedText( TID_GAME_WRONGITEM, "" );
			return FALSE;
		}
		break;
	}

#if __VER >= 8 //__CSC_VER8_3 //Å¸°ÙÀÇ ¹öÇÁÁß ÀÌ¹Ì °É¸° ¹öÇÁ°¡ ·¹º§ÀÌ ³ôÀ» °æ¿ì °ÉÁö ¸øÇÏ°Ô ÇÔ.
	if(pSkillProp->dwSkillType == BUFF_SKILL)
	{
		CMover* searchMover;
		if(pTarget == this)
			searchMover = this;
		else
			searchMover = pTarget;

#ifdef __BUFF_1107
		IBuff* pBuff	= searchMover->m_buffs.GetBuff( BUFF_SKILL, (WORD)( pSkillProp->dwID ) );
		if( pBuff )
		{
			if( pBuff->GetLevel() > (DWORD)( nLevel ) )
#else	// __BUFF_1107
		SKILLINFLUENCE* hasSkill = searchMover->m_SkillState.Find( BUFF_SKILL, pSkillProp->dwID );
		if( hasSkill )
		{
			if( hasSkill->dwLevel > nLevel )
#endif	// __BUFF_1107
			{
				if( IsPlayer() ) // À±»óÀÌ	// this°¡ CUser°¡ ¾Æ´Ò ¼ö ÀÖÀ½.
					( (CUser*)this )->AddDefinedText( TID_GAME_DONOTUSEBUFF, "" );
				return FALSE;
			}
		}
	}
#endif //__CSC_VER8_3

	// ÅõÇÚµå¿ëÀÌ³Ä ¿øÇÚµå¿ëÀÌ³ÄÀÇ Á¶°Ç°Ë»ç.
	if( pSkillProp->dwHanded != NULL_ID )
	{
		if( pItemProp )
		{
			if( IsPlayer() )
			{
				if( pSkillProp->dwHanded == HD_DUAL )		// µà¾ó¿ë ½ºÅ³ÀÎµ¥
				{
					if( IsDualWeapon() == FALSE )			// µà¾ó·Î ¾ÈÂ÷°í ÀÖ´Ù.
					{
						((CUser*)this)->AddDefinedText( TID_GAME_WRONGITEM, "" );
						return FALSE;
					}
				} 
				else if( pItemProp->dwHanded != pSkillProp->dwHanded )	// ½ºÅ³°ú Áã°í ÀÖ´Â ¾ÆÀÌÅÛÀÇ Handed Á¾·ù°¡ ´Ù¸£¸é ¿¡·¯
				{
					((CUser*)this)->AddDefinedText( TID_GAME_WRONGITEM, "" );
					return FALSE;
				}
			}
		}
	}

	// ÇÊ¿äÃÑ¾ËÁ¾·ù°¡ ÁöÁ¤µÇ¾î ÀÖ´Ù¸é
	if( IsBullet( pSkillProp ) == FALSE )
		return FALSE;

	if( IsPlayer() )
	{
#ifdef __NEWCLASS
		if (pSkillProp->dwReqDisLV != NULL_ID && GetLevel() < (int)(pSkillProp->dwReqDisLV) /* && !IsMaster() && !IsHero() && !IsLegendHero() && !IsLegendHeroUltimate() */)
			return FALSE;
#elif defined (__3RD_LEGEND16)
		if (pSkillProp->dwReqDisLV != NULL_ID && GetLevel() < (int)(pSkillProp->dwReqDisLV) && !IsMaster() && !IsHero() && !IsLegendHero())
			return FALSE;
#else // __3RD_LEGEND16
#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if (pSkillProp->dwReqDisLV != NULL_ID && GetLevel() < (int)(pSkillProp->dwReqDisLV) && !IsMaster() && !IsHero())
			return FALSE;
#else // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if (pSkillProp->dwReqDisLV != NULL_ID && GetLevel() < pSkillProp->dwReqDisLV)
			return FALSE;
#endif	// __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
#endif // __3RD_LEGEND16
		
		if( pSkillProp->dwReSkill1 != 0xffffffff )
		{
			LPSKILL pSkillBuf = GetSkill( pSkillProp->dwReSkill1 );
			if( pSkillBuf )
			{
				if( pSkillBuf->dwLevel < pSkillProp->dwReSkillLevel1 )
				{
					( (CUser*)this )->AddText( "SkillLevel1 " );
					return FALSE;
				}
			}
			else
			{
				int nIdx = GetSkillIdx( dwSkill );
				Error( "DoUseSkill : %s NULL GetSkill %d = dwReSkill(%d, %d)", m_szName, nIdx, pSkillProp->dwReSkill1, pSkillProp->dwReSkill2 );
			}
		}

		if( pSkillProp->dwReSkill2 != 0xffffffff )
		{
			LPSKILL pSkillBuf = GetSkill( pSkillProp->dwReSkill2 );
			if( pSkillBuf )
			{
				if( pSkillBuf->dwLevel < pSkillProp->dwReSkillLevel2 )
				{
					( (CUser*)this )->AddText( "SkillLevel2 " );
					return FALSE;
				}				
			}
			else
			{
				int nIdx = GetSkillIdx( dwSkill );
				Error( "DoUseSkill : %s NULL GetSkill %d = dwReSkill(%d, %d)", m_szName, nIdx, pSkillProp->dwReSkill1, pSkillProp->dwReSkill2 );
			}
		}
	}

	if( pSkillProp->dwID == SI_BIL_PST_ASALRAALAIKUM )	// ¾Ñ»ì¶óÀÇ °æ¿ì ¿¹¿ÜÃ³¸®.
	{
		//if( GetFatiguePoint() <= 0  )		// FP°¡ ÇÏ³ªµµ ¾øÀ¸¸é »ç¿ë¾ÈµÊ. // chipi_090917 Á¦°Å
		if( IsPlayer() && GetFatiguePoint() < GetReqFp( pAddSkillProp->nReqFp )  )		// chipi_090917 ÇÊ¿ä FP °Ë»ç
		{
			((CUser*)this)->AddDefinedText( TID_GAME_REQFP ); // chipi_00917
			return FALSE;
		}
	}

	// ÄðÅ¸ÀÓ °Ë»ç.
	{
		int nSkillIdx = GetSkillIdx( dwSkill );		// ½ºÅ³¸®½ºÆ® ÀÎµ¦½º¸¦ Ã£À½.
		if( nSkillIdx >= 0 )
		{
			if( GetReuseDelay( nSkillIdx ) )		// ¾²·Á°í ÇÏ´Â ½ºÅ³ ÄðÅ¸ÀÓÀÌ ³²¾ÆÀÖÀ¸¸é ½ÇÇà¾ÈµÊ.
			{
				if( IsPlayer() )
					((CUser*)this)->AddDefinedText( TID_GAME_SKILLWAITTIME, "" );	// ¾ÆÁ÷ »ç¿ëÇÒ ¼ö ¾ø½À´Ï´Ù.
				return FALSE;
			}
		}
	}

#ifdef __3RD_LEGEND16
	if( !pTarget->IsDie() && pTarget->GetWorld() == GetWorld() )
	{
		if( ( pAddSkillProp->nReqFp == NULL_ID || GetFatiguePoint() >= pAddSkillProp->nReqFp ) &&
			( pAddSkillProp->nReqMp == NULL_ID || GetManaPoint() >= pAddSkillProp->nReqMp ) )
		{
			if( pSkillProp->dwID == SI_LOD_SUP_PULLING )
			{
				pTarget->SetPos( GetPos() );
			}
			else if( pSkillProp->dwID == SI_WIN_YOYO_BACKSTEP )
			{
				FLOAT fX = m_vPos.x + ( ( pTarget->m_vPos.x - m_vPos.x ) * 0.8f );
				FLOAT fZ = m_vPos.z + ( ( pTarget->m_vPos.z - m_vPos.z ) * 0.8f );
				if( GetWorld()->VecInWorld( fX, fZ ) )
				{
					D3DXVECTOR3 vPos = D3DXVECTOR3( fX, 100.0f, fZ );
					if( GetWorld() )
						vPos.y = GetWorld()->GetFullHeight( vPos );
					g_UserMng.AddSetPos( (CCtrl*)this, vPos );
					SetPos( vPos );

					if( IsPlayer() )
					{
						((CUser*)this)->Notify();
						((CUser*)this)->AddSetTarget( pTarget->GetId() );
						((CUser*)this)->m_idSetTarget = pTarget->GetId();
					}
				}
				else
					return FALSE;
			}
		}
	}
#endif // __3RD_LEGEND16

#endif // __WORLDSERVER
		

	SendActMsg( OBJMSG_STOP );
	ClearDest();

	OBJMSG dwMsg = OBJMSG_NONE;
	int nMotion = (int)pSkillProp->dwUseMotion;
#ifdef __CLIENT
#ifdef __VOICE_LINES
	CMover* pMover = static_cast<CMover*>(this);
	if (pMover && pMover->IsActiveMover() && pMover->HasBuff(BUFF_ITEM2, II_CST_VOICELINES))
	{
		pMover->PlayClientVoiceLines(pSkillProp);
	}
#endif //__VOICE_LINES
#endif //__CLIENT
	//--- ¸¶³ª°¡ ÃæºÐÇÑÁö °Ë»ç...
	if( pSkillProp->dwSkillType == KT_SKILL )
	{
	#ifdef __WORLDSERVER

		#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			if(GetReqFp( pAddSkillProp->nReqFp ) == 9999999)
			{
				if( GetManaPoint() != GetMaxManaPoint())
				{
					if( TRUE == IsPlayer() )
						( (CUser*)this )->AddDefinedText( TID_GAME_REQMP, "" );
					return FALSE;
				}
				if( GetFatiguePoint() != GetMaxFatiguePoint())
				{
					if( TRUE == IsPlayer() )
						( (CUser*)this )->AddDefinedText( TID_GAME_REQFP, "" );
					return FALSE;
				}
			}
			else
			{
				if( GetFatiguePoint() - GetReqFp( pAddSkillProp->nReqFp ) < 0 )	// FP°¡ ¸ðÀÚ¸£¹Ç·Î Ãë¼Ò
				{
					if( TRUE == IsPlayer() )
						( (CUser*)this )->AddDefinedText( TID_GAME_REQFP, "" );
					return FALSE;
				}

				// KT_SKILLÁß¿¡ MP°¡ ¼Ò¸ðµÇ´Â °ªÀÌÀÖÀ¸¸é FP¿Í °°ÀÌ ¼Ò¸ð½ÃÄÑÁØ´Ù.
				if( (int)pAddSkillProp->nReqMp > 0 )
				{
					if( GetManaPoint() - GetReqMp( pAddSkillProp->nReqMp ) < 0 )		// ¸¶³ª°¡ ¸ðÀÚ¸£¹Ç·Î Ãë¼Ò
					{
						if( TRUE == IsPlayer() )
							( (CUser*)this )->AddDefinedText( TID_GAME_REQMP, "" );
						return FALSE;
					}
				}
			}
		#else //__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
			if( GetFatiguePoint() - GetReqFp( pAddSkillProp->nReqFp ) < 0 )	// FP°¡ ¸ðÀÚ¸£¹Ç·Î Ãë¼Ò
			{
				if( TRUE == IsPlayer() )
					( (CUser*)this )->AddDefinedText( TID_GAME_REQFP, "" );
				return FALSE;
			}

			// KT_SKILLÁß¿¡ MP°¡ ¼Ò¸ðµÇ´Â °ªÀÌÀÖÀ¸¸é FP¿Í °°ÀÌ ¼Ò¸ð½ÃÄÑÁØ´Ù.
			if( (int)pAddSkillProp->nReqMp > 0 )
			{
				if( GetManaPoint() - GetReqMp( pAddSkillProp->nReqMp ) < 0 )		// ¸¶³ª°¡ ¸ðÀÚ¸£¹Ç·Î Ãë¼Ò
				{
					if( TRUE == IsPlayer() )
						( (CUser*)this )->AddDefinedText( TID_GAME_REQMP, "" );
					return FALSE;
				}
			}
		#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

	#endif
		dwMsg = OBJMSG_MELEESKILL;	// Å¬¶ó¿¡¼­µµ ½ÇÇàÇØ¾ßÇÔ
	} 
	else if( pSkillProp->dwSkillType == KT_MAGIC )
	{
	#ifdef __WORLDSERVER
		if( GetAdjParam( DST_CHRSTATE ) & CHS_SILENT )		// Ä§¹¬»óÅÂ¿¡¼± ¸ÅÁ÷½ºÅ³ ¾µ ¼ö ¾øÀ½.
			return FALSE;

#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if(GetReqMp( pAddSkillProp->nReqMp ) == 9999999)
		{
			if( GetManaPoint() != GetMaxManaPoint())
			{
				if( TRUE == IsPlayer() )
					( (CUser*)this )->AddDefinedText( TID_GAME_REQMP, "" );
				return FALSE;
			}
			if( GetFatiguePoint() != GetMaxFatiguePoint())
			{
				if( TRUE == IsPlayer() )
					( (CUser*)this )->AddDefinedText( TID_GAME_REQFP, "" );
				return FALSE;
			}
		}
		else
		{
			if( GetManaPoint() - GetReqMp( pAddSkillProp->nReqMp ) < 0 )		// ¸¶³ª°¡ ¸ðÀÚ¸£¹Ç·Î Ãë¼Ò
			{
				if( TRUE == IsPlayer() )
					( (CUser*)this )->AddDefinedText( TID_GAME_REQMP, "" );
				return FALSE;
			}
		}
#else //__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( GetManaPoint() - GetReqMp( pAddSkillProp->nReqMp ) < 0 )		// ¸¶³ª°¡ ¸ðÀÚ¸£¹Ç·Î Ãë¼Ò
		{
			if( TRUE == IsPlayer() )
				( (CUser*)this )->AddDefinedText( TID_GAME_REQMP, "" );
			return FALSE;
		}
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

	#endif // worldserver
		if( sutType == SUT_QUEUESTART )		// ½ºÅ³Å¥ ½ÃÀÛ ½ºÅ³. - Å¥³»ÀÇ ¸ðµç ½ºÅ³ÀÇ Ä³½ºÆÃÀ» ¸ô¾Æ¼­ ÇÑ´Ù.
		{
			if( IsPlayer() )
				dwMsg = OBJMSG_MAGICCASTING;
		} 
		else if( sutType == SUT_QUEUEING )	// ½ºÅ³Å¥ ÁøÇàÁß ½ºÅ³. - Ä³½ºÆÃ µ¿ÀÛ¾øÀÌ ½ÃÀü.
		{
			nMotion += 2;
			dwMsg = OBJMSG_MAGICSKILL;
		} 
		else
		{									// ÀÏ¹ÝÀûÀÎ ¸¶¹ý ½ºÅ³ »ç¿ë - Ä³½ºÆÃ µ¿ÀÛ ÀÖÀ½.
			dwMsg = OBJMSG_MAGICCASTING;
		}
	}
	else
		Error( "DoUseSkill : %s dwSkillType = %d", m_szName, pSkillProp->dwSkillType );	// ÇÁ·ÎÆÛÆ¼°ªÀÌ ÀÌ»óÇÔ.

	if( sutType != SUT_QUEUEING && nCastingTime == 0 && pSkillProp->dwID != SI_GEN_ATK_COUNTER )
		nMotion += 2;
	
	//--- µ¿ÀÛ ½ÃÀÛ -----------------------------------------------------------------
#if __VER >= 10 // __LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	int nRet = m_pActMover->SendActMsg( dwMsg, nMotion, idFocusObj, nCastingTime, dwSkill );
#else //__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	int nRet = m_pActMover->SendActMsg( dwMsg, nMotion, idFocusObj, nCastingTime );
#endif	//__LEGEND	//	9Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans

	if( nRet == 1 )	// ½ºÅ³ µ¿ÀÛ ½ÃÀÛ.
	{
		// ¸í·É¼öÇàÁß ÇÊ¿äÇÑ ÆÄ¶ó¸ÞÅÍ¼¼ÆÃ.
		SetActParam( OBJACT_USESKILL, dwSkill, idFocusObj );	
		m_nAParam[3]	= nLevel;
#if __VER >= 8 // __S8_PK
		m_nAParam[4]	= bControl;
#endif // __VER >= 8 // __S8_PK

	#ifdef __WORLDSERVER
		if( pSkillProp->dwSkillType == KT_SKILL )
		{
			// ±ÙÁ¢½ºÅ³Àº »ç¿ëÇÏ´Â Áï½Ã fp°¨¼Ò.
			if( (int)pAddSkillProp->nReqFp > 0 )
				IncFatiguePoint( -GetReqFp( pAddSkillProp->nReqFp ) );			// FP°¨¼Ò

			int nReqMp	= GetReqMp( pAddSkillProp->nReqMp );
			if( nReqMp > 0 )
			{
				IncManaPoint( -nReqMp );
			}
		}
	#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		if( pSkillProp->dwSkillType == KT_MAGIC )
		{
			if( GetReqMp( pAddSkillProp->nReqMp ) == 9999999 )
			{
				IncFatiguePoint( -GetFatiguePoint() );			// FP°¨¼Ò
				IncManaPoint( -GetManaPoint() );
			}
		}
	#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
		
		if( pSkillProp->dwLinkKindBullet != NULL_ID )	// ÃÑ¾Ë(?)À» ÇÊ¿ä·Î ÇÏ´Â°Å¸é
		{
			CItemElem *pItemElem = GetEquipItem( PARTS_BULLET );
			if( pItemElem )
				ArrowDown( 1 );
		}

		if( pSkillProp->nEvildoing < 0 )		// ³ª»Û¸¶¹ýÀ¸·Î¸¸ ¸ó½ºÅÍ³ª ÇÃ·¹ÀÌ¾î¸¦ ÂòÇÒ¼öÀÖ´Ù.
		{
			pTarget->SetJJim( this );			// pTarget¸¦ ÂòÇß´Ù´Â°É Ç¥½Ã.
			m_nAtkCnt = 1;						// ºøÀÚ·ç µô·¹ÀÌ¸¦ À§ÇÑ °ø°Ý Ä«¿îÅÍ ½ÃÀÛ.
		}

		// DST paramÀÌ Àû¿ëµÇ´Â ½ºÅ³Àº ¿©±â¼­ Àû¿ëÇÔ.
		g_UserMng.AddUseSkill( this, dwSkill, nLevel, idFocusObj, sutType, nCastingTime );
	#endif	// __WORLDSERVER
	} 
	else if( nRet == -2 )	// 0:Å¥¿¡ ½×´Â´Ù -1:¸ð¸§  -2:¿ÏÀü½ÇÆÐÇÏ¿© Ãë¼Ò½ÃÅ´   -3:¸ð¸§
	{
		return FALSE;
	}
	
	m_dwFlag |= MVRF_SKILL;		// ½ºÅ³»ç¿ë ¸í·ÉÀÌ ½ÃÀÛµÆ´Ù.
#ifdef __CLIENT
	if( IsActiveMover() )		// g_pPlayerÀÏ°æ¿ì 
	{
		CWndTaskBar* pTaskBar = g_WndMng.m_pWndTaskBar;
		if( pTaskBar->m_nExecute == 1 )		// ½ºÅ³¹Ù »ç¿ë ´ë±âÁß»óÅÂ¿´À¸¸é
			pTaskBar->m_nExecute = 2;		// ½ÇÁ¦ ½ºÅ³¹Ù »ç¿ëÁßÀ¸·Î ÀüÈ¯.
	}
#endif

#ifdef __CLIENT
	{
		DWORD dwLinkSfxDouble = NULL_ID;
		switch( dwSkill )
		{	// ¿©±â´Ù XI_ Ãß°¡ÇÏ¸é CreateSfxÀÇ CSfxPartsLink()¿¡µµ Ãß°¡½ÃÄÑ¾ß ÇÔ/
		case SI_BLD_DOUBLEAX_SPRINGATTACK:	dwLinkSfxDouble = XI_SKILL_BLD_DOUBLEAX_SPRINGATTACK01;	break;
		case SI_BLD_DOUBLE_SONICBLADE:		dwLinkSfxDouble = XI_SKILL_BLD_DOUBLE_SONICBLADE01;	break;
		case SI_KNT_TWOSW_CHARGE:			dwLinkSfxDouble = XI_SKILL_KNT_TWOSW_CHARGE01;	break;
		case SI_BLD_DOUBLESW_BLADEDANCE:	dwLinkSfxDouble = XI_SKILL_BLD_DOUBLESW_BLADEDANCE01;      break;

		// Á¦½ºÅÍ ¾ç¼Õ ÀÌÆåÆ® : sfxÇÁ·¹ÀÓÀÌ ³¡ÀÌ¸é ¼Ò¸êÇÔ
		case SI_JST_YOYO_VATALSTAB:	dwLinkSfxDouble = XI_SKILL_JST_YOYO_VATALSTAB01;	break;
		case SI_JST_YOYO_HITOFPENYA:	dwLinkSfxDouble = XI_SKILL_JST_YOYO_HITOFPENYA01;	break;

		case SI_JST_YOYO_CRITICALSWING:	dwLinkSfxDouble = XI_SKILL_JST_SUP_CRITICALSWING01;	break;
		case SI_ACR_SUP_SLOWSTEP:	dwLinkSfxDouble = XI_SKILL_ACR_YOYO_SLOWSTEP01;	break;
		case SI_JST_SUP_POISON:		dwLinkSfxDouble = XI_SKILL_JST_SUP_POISON01;	break;
		case SI_JST_SUP_BLEEDING:	dwLinkSfxDouble = XI_SKILL_JST_SUP_BLEEDING01;	break;
		case SI_JST_YOYO_BACKSTAB:	dwLinkSfxDouble = XI_SKILL_JST_YOYO_BACKSTAB01;	break;
		case SI_JST_SUP_ABSORB:	dwLinkSfxDouble = XI_SKILL_JST_SUP_ABSORB01;	break;
			break;
		}
		if( dwLinkSfxDouble != NULL_ID )
		{
			CSfx *pSfx = CreateSfx( g_Neuz.m_pd3dDevice, dwLinkSfxDouble, GetPos(), GetId() );  // ½ÃÀüµ¿ÀÛÀÌ±â¶§¹®¿¡ ¹«Á¶°Ç ÀÚ±â¿¡°Ô ³ªÅ¸³­´Ù.
			if( pSfx )
			{
				pSfx->SetPartLink( 0 );		// ¿À¸¥¼Õ¿¡ ¸µÅ©.
				pSfx = CreateSfx( g_Neuz.m_pd3dDevice, dwLinkSfxDouble, GetPos(), GetId() );  // ¸µÅ©ÀÌÆå ÇÏ³ª´õ »ý¼º.
				if( pSfx )
					pSfx->SetPartLink( 1 );		// ¼Õ¿¡ ¸µÅ©.
			}
		}
	}

	// ¿Þ¼Õ ¸µÅ© ÀÌÆå
	DWORD dwLinkSfxLeft = NULL_ID;
	switch( dwSkill )
	{	// ¾ÆÅ©·Îºª ½ºÅ³ÀÌ¸é È° ½ÃÀü ÀÌÆåÆ® ¿Þ¼Õ¿¡ ¸µÅ©ÇÑ´Ù
	case SI_RAG_BOW_ICEARROW:	dwLinkSfxLeft = XI_SKILL_RAG_BOW_ICEARROW01;	break;
	case SI_ACR_BOW_JUNKBOW:	dwLinkSfxLeft = XI_SKILL_ACR_BOW_JUNKBOW01;	break;
	case SI_ACR_BOW_AIMEDSHOT:	dwLinkSfxLeft = XI_SKILL_ACR_BOW_AIMEDSHOT01;	break;
	case SI_ACR_BOW_SILENTSHOT:	dwLinkSfxLeft = XI_SKILL_ACR_BOW_SILENTSHOT01;	break;
	case SI_ACR_BOW_ARROWRAIN:	dwLinkSfxLeft = XI_SKILL_ACR_BOW_ARROWRAIN01;      break;
	case SI_ACR_BOW_AUTOSHOT:	dwLinkSfxLeft = XI_SKILL_ACR_BOW_AUTOSHOT01;      break;
		
	case SI_RAG_SUP_FASTATTACK:	  dwLinkSfxLeft = XI_SKILL_RAG_SUP_FASTATTACK01;break;
	case SI_RAG_BOW_FLAMEARROW:	  dwLinkSfxLeft = XI_SKILL_RAG_BOW_FLAMEARROW01;break;
	case SI_RAG_BOW_PIRCINGARROW: dwLinkSfxLeft = XI_SKILL_RAG_BOW_PIRCINGARROW01;break;
	case SI_RAG_BOW_POISONARROW:  dwLinkSfxLeft = XI_SKILL_RAG_BOW_POISONARROW01;break;
	case SI_RAG_BOW_SILENTARROW:  dwLinkSfxLeft = XI_SKILL_RAG_BOW_SILENTARROW01;break;
	case SI_RAG_BOW_TRIPLESHOT:   dwLinkSfxLeft = XI_SKILL_RAG_BOW_TRIPLESHOT01;break;
		
		break;
	}
	
	if( dwLinkSfxLeft != NULL_ID )
	{
		CSfx *pSfx = CreateSfx( g_Neuz.m_pd3dDevice, dwLinkSfxLeft, GetPos(), GetId() );  // ½ÃÀüµ¿ÀÛÀÌ±â¶§¹®¿¡ ¹«Á¶°Ç ÀÚ±â¿¡°Ô ³ªÅ¸³­´Ù.
		if( pSfx )
			pSfx->SetPartLink( 1 );		// ¿Þ¼Õ¿¡ ¸µÅ©.
	}

	// ¿À¸¥¼Õ ¸µÅ© ÀÌÆå
	DWORD dwLinkSfxRight = NULL_ID;
	switch( dwSkill )
	{
	case SI_MER_ONE_SPLMASH: dwLinkSfxRight = XI_SKILL_MER_ONE_SUPPORT04; break;
	case SI_MER_ONE_GUILOTINE: dwLinkSfxRight = XI_SKILL_MER_ONE_SUPPORT02; break;
	case SI_MER_ONE_REFLEXHIT: dwLinkSfxRight = XI_SKILL_MER_ONE_SUPPORT01; break;
	case SI_MER_ONE_SPECIALHIT: dwLinkSfxRight = XI_SKILL_MER_ONE_SUPPORT03; break;
	case SI_ASS_KNU_POWERFIST:	dwLinkSfxRight = XI_SKILL_ASS_KNU_SUPPORT03;	break;
	case SI_ASS_KNU_TAMPINGHOLE:	dwLinkSfxRight = XI_SKILL_ASS_KNU_SUPPORT02;	break;
	case SI_ASS_KNU_BURSTCRACK:	dwLinkSfxRight = XI_SKILL_ASS_KNU_SUPPORT01;	break;
	case SI_GEN_ATK_COUNTER:	dwLinkSfxRight = XI_SKILL_JST_YOYO_BACKSTAB01;	break;
		break;
	}
	
	if( dwLinkSfxRight != NULL_ID )
	{
		CSfx *pSfx = CreateSfx( g_Neuz.m_pd3dDevice, dwLinkSfxRight, GetPos(), GetId() );  // ½ÃÀüµ¿ÀÛÀÌ±â¶§¹®¿¡ ¹«Á¶°Ç ÀÚ±â¿¡°Ô ³ªÅ¸³­´Ù.
		if( pSfx )
			pSfx->SetPartLink( 0 );		// ¿À¸¥¼Õ¿¡ ¸µÅ©.
	}

	// ¸¶¹ý È¤Àº ÀüÅõ½ºÅ³ÀÇ ¹ßµ¿½ÃÀÛ ÀÌÆåÆ®¹ß»ý
	// ÀÚ±âid GetId()
	// Å¸°Ùid idFocusObj
	if( pSkillProp->dwSfxObj != NULL_ID )
	{
		CreateSfx( g_Neuz.m_pd3dDevice, pSkillProp->dwSfxObj, GetPos(), GetId() );  // ½ÃÀüµ¿ÀÛÀÌ±â¶§¹®¿¡ ¹«Á¶°Ç ÀÚ±â¿¡°Ô ³ªÅ¸³­´Ù.
	}	
	// °ø°Ý½ºÅ³°ú Å¸°ÙÀÌ ¸ó½ºÅÍ ÀÌ¸é È­¸é¿¡ Ãâ·ÂÀ» ¾ÈÇÔ
	if( pSkillProp->dwExeTarget != EXT_MELEEATK && 
		pSkillProp->dwExeTarget != EXT_MAGICATK && 
		pSkillProp->dwExeTarget != EXT_AROUNDATK &&  
		pSkillProp->dwExeTarget != EXT_MAGICATKSHOT && 
		pTarget->IsPlayer() )
	{
		CString str;
		if( this == g_pPlayer ) // ³»°¡ ¾´°Í
		{
			str.Format( prj.GetText( TID_GAME_SKILL_SELF ), pSkillProp->szName );
			g_WndMng.PutString( (LPCTSTR)str, NULL, prj.GetTextColor( TID_GAME_SKILL_SELF ) );	
		}
		else
		if( pTarget == g_pPlayer && ( this != pTarget || pSkillProp->dwID == SI_ASS_CHEER_CIRCLEHEALING ) ) // ³»°¡ ¾´°ÍÀÌ ¾Æ´Ï¶ó¸é
		{
			str.Format( prj.GetText( TID_GAME_SKILL_MATE ), GetName(), pSkillProp->szName );
			g_WndMng.PutString( (LPCTSTR)str, NULL, prj.GetTextColor( TID_GAME_SKILL_MATE ) );	
		}
	}
#endif	// __CLIENT

#ifdef __CLIENT	
	if( ::GetLanguage() == LANG_JAP )
	{
		if( g_pPlayer )
		{
			if( g_Option.m_bVoice )
			{
				if( IsActiveMover() )
				{
					int nindex = 0;
					
					if( pSkillProp->dwID != -1 )
					{
						if( GetSex() == 0 )
							nindex = pSkillProp->dwID+3000;
						else
							nindex = pSkillProp->dwID+3500;

						g_SoundMng.m_nOldSoundVolume = g_SoundMng.m_nSoundVolume;
						g_SoundMng.m_nSoundVolume = 0;
						PLAYSND( nindex );

						g_SoundMng.m_nSoundVolume = g_SoundMng.m_nOldSoundVolume;
					}
				}
			}
		}
	}
#endif	// __CLIENT

#if __VER >= 8 // __S8_PK
#ifdef __WORLDSERVER
#ifdef __WORLDSERVER_MENU
	if (g_eLocal.GetState(EVE_PK) && CDPSrvr::GetInstance()->m_bPk == TRUE)
#else // __WORLDSERVER_MENU
	if (g_eLocal.GetState(EVE_PK))
#endif // __WORLDSERVER_MENU
	{
		if( !IsChaotic() && ( pTarget->IsPKPink() || ( pTarget->IsChaotic() && pSkillProp->nEvildoing > 0 ) ) )
		{
			SetPKPink( GetTickCount() + SEC(prj.m_PKSetting.nReadyAttack) );
			g_UserMng.AddPKPink( this, 1 );	
		}
	}
#endif // __WORLDSERVER
#endif // __VER >= 8 // __S8_PK
	
	return TRUE;
}

//
//	Áö¼Ó¼ºÀ» °®´Â ½ºÅ³ÀÌ ½Ã°£ÀÌ ´ÙµÇ ³¡³µÀ»¶§ È£ÃâµÊ.
//
void	CMover::OnEndSkillState( DWORD dwSkill, DWORD dwLevel )
{
	if( dwSkill < 0 || (int)( dwSkill ) > prj.m_aPropSkill.GetSize() )
	{
		Error( "OnEndSkillState : ½ºÅ³ÀÇ ¹üÀ§¸¦ ³Ñ¾î¼¶. %d", dwSkill );
		return;
	}
	ItemProp* pSkillProp = NULL;
	AddSkillProp *pAddSkillProp = NULL;
	GetSkillProp( &pSkillProp, &pAddSkillProp, dwSkill, dwLevel, "OnEndSkillState" );

	if( dwSkill == SI_ACR_YOYO_COUNTER )	// Ä«¿îÅÍ ¾îÅÃ½ºÅ³ÀÇ °æ¿ì
	{
		m_pActMover->ResetState( OBJSTA_ATK_ALL );		// °ø°Ýµ¿ÀÛ Áß´Ü½ÃÅ´.  (ÀÌ·± ÆÐÅÏÀÇ ½ºÅ³Àº ¾ÕÀ¸·Î ÀÏ¹ÝÈ­ ½ÃÅ°ÀÚ)
	}
#if defined( __CLIENT ) 
/*	// 091022 mirchang - ÇÁ·ÎÅØ¼Ç, Ææ¹Ù¸®¾î ½ºÅ³ ¹öÇÁ ÇØÁ¦ ½Ã sfx »èÁ¦
	#if __VER >= 11 // __MA_VER11_06				// È®À²½ºÅ³ È¿°ú¼öÁ¤ world,neuz
	if(	dwSkill == SI_MAG_FIRE_HOTAIR)
	{
		SetRemoveSfxObj( pSkillProp->dwSfxObj2 );
//		CSfx *pSfx = prj.GetSfx((this)->m_dwObjID,
//		if(pSfx)
//			pSfx->m_nSec = 0;	
	}
	if(	dwSkill == SI_PSY_HERO_STONE)
	{
		SetRemoveSfxObj( pSkillProp->dwSfxObj4 );
	}
	#endif // __MA_VER11_06				// È®À²½ºÅ³ È¿°ú¼öÁ¤ world,neuz
*/	// 091022 mirchang - ÇÁ·ÎÅØ¼Ç, Ææ¹Ù¸®¾î ½ºÅ³ ¹öÇÁ ÇØÁ¦ ½Ã sfx »èÁ¦
	switch( dwSkill )	// 091022 mirchang - ÇÁ·ÎÅØ¼Ç, Ææ¹Ù¸®¾î ½ºÅ³ ¹öÇÁ ÇØÁ¦ ½Ã sfx »èÁ¦
	{
		case SI_MAG_FIRE_HOTAIR :
			SetRemoveSfxObj( pSkillProp->dwSfxObj2 );
			break;
		case SI_PSY_HERO_STONE :
		case SI_MER_SHIELD_PANBARRIER:
		case SI_MER_SHIELD_PROTECTION:
			SetRemoveSfxObj( pSkillProp->dwSfxObj4 );
			break;
	}
  #endif	// 

	BOOL	bSend = FALSE;
#ifdef __WORLDSERVER
	bSend = TRUE;			// ¼­¹öÀÏ°æ¿ì À¯Àúµé¿¡°Ô º¸³»ÁÜ.

#ifdef __3RD_LEGEND16
	if( dwSkill == SI_FLO_SUP_ABSOLUTE )
		ResetDestParam( DST_IGNORE_DMG_PVP, GetParam( DST_IGNORE_DMG_PVP, 0), bSend );
	else
#endif // __3RD_LEGEND16
	{
		ResetDestParam( pAddSkillProp->dwDestParam1, pAddSkillProp->nAdjParamVal1, bSend );
		ResetDestParam( pAddSkillProp->dwDestParam2, pAddSkillProp->nAdjParamVal2, bSend );
	}
#endif


}

// ÀÏ¹Ý °ø°Ý µ¿ÀÛÀÌ ³¡³µÀ»¶§ È£Ãâ.
void	CMover::OnEndMeleeAttack( DWORD dwState )
{
#ifdef __WORLDSERVER
	PostAIMsg( AIMSG_END_MELEEATTACK );
#endif // WorldServer
}

#if __VER >= 11 // __MA_VER11_06				// È®À²½ºÅ³ È¿°ú¼öÁ¤ world,neuz
DWORD	CMover::GetRemoveSfxObj(DWORD	dwRemoveSfxObjID)
{
	DWORD	dwResult = 0;
	for(int i=0;i<MAX_SKILLBUFF_COUNT;i++)
	{
		if(dwRemoveSfxObj[i] ==  dwRemoveSfxObjID)
		{
			dwResult = dwRemoveSfxObj[i];
			dwRemoveSfxObj[i] = 0;
			return	dwResult;
		}
	}	
	return	dwResult;	
}

void	CMover::SetRemoveSfxObj(DWORD	dwRemoveSfxObjID)
{
	for(int i=0;i<MAX_SKILLBUFF_COUNT;i++)
	{
		if(dwRemoveSfxObj[i] ==  dwRemoveSfxObjID)
			return;
	}
	for( int i=0;i<MAX_SKILLBUFF_COUNT;i++)
	{
		if(dwRemoveSfxObj[i] ==  0)
		{
			dwRemoveSfxObj[i] = dwRemoveSfxObjID;
			return;
		}
	}
}
#endif // __MA_VER11_06				// È®À²½ºÅ³ È¿°ú¼öÁ¤ world,neuz
/*--------------------------------------------------------------------------------------------------------


											Do Use Item


----------------------------------------------------------------------------------------------------------*/

// ¾ÆÀÌÅÛ ID·Î ¾ÆÀÌÅÛ »ý¼º(ÀÎº¥Åä¸®¿Í »ó°ü¾øÀÌ »ç¿ë)
BOOL CMover::DoUseItemVirtual( DWORD dwItemId, BOOL bEffectSkip )
{
#ifdef __WORLDSERVER
	//ÀÎº¥¾ø´Â ¾ÆÅÛ »ç¿ë½Ã´Â Á×À½°ú °ü°è¾øÀÌ ½ÇÇà°¡´ÉÇÏ°ÔÇÑ´Ù.

	ItemProp* pItemProp = prj.GetItemProp( dwItemId );

	if( pItemProp )
	{
		if( IsItemRedyTime( pItemProp, pItemProp->dwID, FALSE ) == FALSE )
			return FALSE;

		D3DXVECTOR3 sPos = D3DXVECTOR3(0.0f,0.0f,0.0f);

		if( dwItemId == II_SYS_SYS_SCR_RETURN )
		{
			// µ¹¾Æ°¡±â 
			if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_RETURN ) )
				RemoveBuff( BUFF_ITEM, II_SYS_SYS_SCR_RETURN );

			DWORD dwWorldID;
			D3DXVECTOR3 vPos = ((CUser*)this)->GetReturnPos( &dwWorldID );
			((CUser*)this)->REPLACE( g_uIdofMulti, dwWorldID, vPos, REPLACE_NORMAL, nTempLayer );
			return TRUE;
		}


		if( dwItemId == II_CHR_SYS_SCR_ESCAPEBLINKWING )
		{
			if( pItemProp->dwCircleTime != (DWORD)-1 )
			{
				if( !IsSMMode( SM_ESCAPE ) )
				{
					SetSMMode( SM_ESCAPE, pItemProp->dwCircleTime );
				}
				else
				{
					return FALSE;
				}
			}
			return DoUseItemBlinkWing( pItemProp, NULL, FALSE );
		}

		DWORD	dwSfxID = pItemProp->dwSfxObj3;
		if( dwSfxID != NULL_ID && !bEffectSkip )		// ¾ÆÀÌÅÛ »ç¿ë½Ã¿¡ »ý¼ºµÉ ÀÌÆåÆ®
		{
			g_UserMng.AddCreateSfxObj( this, dwSfxID, sPos.x, sPos.y, sPos.z );	// Àý´ëÁÂÇ¥·Î ÇÏÀÚ.
		}	
	}
#endif //__WORLDSERVER

	return TRUE;
}

// ¾ÆÀÌÅÛÀ» »ç¿ëÇÏ´Â ½ÃÁ¡¿¡ È£ÃâµÈ´Ù. 
void CMover::OnAfterUseItem( const ItemProp* pItemProp )
{
#ifdef __WORLDSERVER
	if( pItemProp == NULL )
		return;

	D3DXVECTOR3 sPos = D3DXVECTOR3(0.0f,0.0f,0.0f);
	DWORD dwSfxID = pItemProp->dwSfxObj3;		// ¾ÆÀÌÅÛ »ç¿ë½Ã¿¡ »ý¼ºµÉ ÀÌÆåÆ®

	if(	pItemProp->dwItemKind3 == IK3_MAGICTRICK ) // ÀÌÆåÆ® ¾ÆÀÌÅÛ·ù
	{
		float	fTheta = D3DXToRadian( GetAngle() );
		switch( pItemProp->dwID )
		{
		case II_GEN_MAG_TRI_FIRESHOWER:
		case II_GEN_MAG_TRI_HWFIREWORKS:
		case II_CHR_MAG_TRI_ROCKETBOMB:
		case II_CHR_MAG_TRI_HEARTBOMB:
		case II_CHR_MAG_TRI_TWISTERBOMB:
			sPos.x = GetPos().x + sinf(fTheta) * 3.0f;			// ¹Ù¶óº¸´Â ¹æÇâ 1¹ÌÅÍ ¾Õ¿¡´Ù ¹ß»ý½ÃÅ´.
			sPos.z = GetPos().z + -cosf(fTheta) * 3.0f;
			sPos.y = GetPos().y + 1.5f;
			sPos.y = GetWorld()->GetUnderHeight( D3DXVECTOR3(sPos.x,sPos.y,sPos.z) );
			break;
		case II_GEN_MAG_TRI_NEWYEARBOMB:
		case II_GEN_MAG_TRI_SULNALBOMB:
		case II_GEN_MAG_TRI_GOODBYEBOMB:
			sPos.x = GetPos().x;
			sPos.z = GetPos().z;
			sPos.y = GetPos().y + 3.0f;
			break;
		}
	}

	if( dwSfxID != NULL_ID )		
		g_UserMng.AddCreateSfxObj( this, dwSfxID, sPos.x, sPos.y, sPos.z );	// Àý´ëÁÂÇ¥·Î ÇÏÀÚ.
#if __VER >= 13 // __HONORABLE_TITLE			// ´ÞÀÎ
	if (IsPlayer())
	{
		((CUser*)this)->SetHonorAdd(pItemProp->dwID, HI_USE_ITEM);
#ifdef __BADGE
		static_cast<CUser*>(this)->SetBadgeAddType(HI_USE_ITEM, pItemProp->dwID);
#endif //__BADGE
	}
#ifndef __MAINSERVER

	else
		FILEOUT( "..\\HonorError.txt", "OnAfterUseItem()\n" );
#endif	// __MAINSERVER
#endif	// __HONORABLE_TITLE			// ´ÞÀÎ
#endif // __WORLDSERVER
}

#ifdef __BAG_UPDATE
BOOL CMover::DoUseItemBag(DWORD dwData, DWORD dwFocusId, int nBag)
{
#ifdef __WORLDSERVER
	if (IsDie())
		return FALSE;
#ifdef __S_SERVER_UNIFY
	if (((CUser*)this)->m_bAllAction == FALSE)
		return FALSE;
#endif // __S_SERVER_UNIFY

	if (GetHitPoint() > GetMaxHitPoint())
		SetHitPoint(GetMaxHitPoint());
	if (GetManaPoint() > GetMaxManaPoint())
		SetManaPoint(GetMaxManaPoint());
	if (GetFatiguePoint() > GetMaxFatiguePoint())
		SetFatiguePoint(GetMaxFatiguePoint());

	WORD dwType = LOWORD(dwData);
	WORD dwId = HIWORD(dwData);

	CItemBase* pItemBase = GetItemId2(nBag, dwId);
	if (IsUsableItem(pItemBase) == FALSE)
		return FALSE;

	CItemElem* pItemElem = (CItemElem*)pItemBase;
	ItemProp* pItemProp = pItemBase->GetProp();
	if (!pItemProp)
		return FALSE;

	DWORD dwItemKind1 = pItemProp->dwItemKind1;
	DWORD dwItemKind2 = pItemProp->dwItemKind2;
	DWORD dwItemKind3 = pItemProp->dwItemKind3;

	CWorld* pWorld = GetWorld();
	if (pWorld && pWorld->GetID() == WI_WORLD_GUILDWAR)
	{
		if (m_nGuildCombatState == 0)
		{
			if (IsPlayer())
				((CUser*)this)->AddText(prj.GetText(TID_GAME_GUILDCOMBAT_STANDS_NOTUSEITEM));
			return FALSE;
		}
	}

#if __VER >= 10 
	if (GetAdjParam(DST_CHRSTATE) & CHS_SETSTONE)
		return FALSE;
#endif	//__LEGEND	
	{
		if (IsItemRedyTime(pItemProp, pItemElem->m_dwObjId, TRUE) == FALSE)
			return FALSE;

		DWORD dwGroup = 0;

		if (IsPlayer())
		{
			CUser* pUser = (CUser*)this;

			dwGroup = pUser->m_cooltimeMgr.GetGroup(pItemProp);
			if (dwGroup)
			{
				if (pUser->m_cooltimeMgr.CanUse(dwGroup) == FALSE)
				{
					return FALSE;
				}
			}
		}

		switch (pItemProp->dwItemKind2)
		{
#if __VER >= 15 // __GUILD_HOUSE
		case IK2_GUILDHOUSE_FURNITURE:
		case IK2_GUILDHOUSE_NPC:
		case IK2_GUILDHOUSE_PAPERING:
		{
			if (GuildHouseMng->SendWorldToDatabase(static_cast<CUser*>(this), GUILDHOUSE_PCKTTYPE_LISTUP, GH_Fntr_Info(pItemProp->dwID)))
				g_DPSrvr.PutItemLog(static_cast<CUser*>(this), "f", "GUILDHOUSE_LISTUP", pItemElem, 1);
			else
				return FALSE;
			break;
		}
#endif // __GUILD_HOUSE
#if __VER >= 13 // __HOUSING
		case IK2_FURNITURE:
		case IK2_PAPERING:
		{
			if (CHousingMng::GetInstance()->ReqSetFurnitureList((CUser*)this, pItemElem->m_dwItemId))
			{
				LogItemInfo aLogItem;
				aLogItem.SendName = GetName();
				aLogItem.RecvName = "HOUSING_USE";
				aLogItem.WorldId = GetWorld()->GetID();
				aLogItem.Gold = GetGold();
				aLogItem.Gold2 = GetGold();
				aLogItem.Action = "f";
				g_DPSrvr.OnLogItem(aLogItem, pItemElem);
			}
			else
				return FALSE;
			break;
		}
#endif // __HOUSING
#if __VER >= 11 // __SYS_COLLECTING
		case IK2_BUFF2:
		{
			if (IsDoUseBuff(pItemProp) != 0)
				return FALSE;
			CTime tm = CTime::GetCurrentTime() + CTimeSpan(0, 0, pItemProp->dwAbilityMin, 0);
			time_t t = (time_t)(tm.GetTime());
			AddBuff(BUFF_ITEM2, (WORD)(pItemElem->m_dwItemId), t, 0);
			break;
		}
#endif	// __SYS_COLLECTING
#ifdef __BUFF_TOGIFT
		case IK2_BUFF_TOGIFT:
#endif // __BUFF_TOGIFT
		case IK2_BUFF:
		{

			if (IsDoUseBuff(pItemProp) != 0)
				return FALSE;

			DoApplySkill(this, pItemProp, NULL);
		}
		break;
		case IK2_SYSTEM:
		{
#ifdef __JEFF_9_20
#ifdef __WORLDSERVER
			if (pItemProp->dwLimitLevel1 != 0xFFFFFFFF)
			{
				if (GetLevel() < (int)(pItemProp->dwLimitLevel1))
				{
					((CUser*)this)->AddDefinedText(TID_GAME_ITEM_LEVEL, "\"%d\"", pItemProp->dwLimitLevel1);
					return FALSE;
				}
			}
#endif	// __WORLDSERVER
#endif	// __JEFF_9_20
			int nResult = 0;
			nResult = DoUseItemSystem(pItemProp, pItemElem);
			{
				if (0 < nResult)
				{
					if (nResult == 2)
					{
						((CUser*)this)->AddDefinedText(TID_GAME_LIMITED_USE, "");
					}
					else if (nResult == 3)
					{
						((CUser*)this)->AddDefinedText(TID_GAME_NOTOVERLAP_USE, "");
					}
					return FALSE;
				}
				else
				{
					if (pItemElem->m_dwItemId == II_SYS_SYS_SCR_RECCURENCE_LINK)
					{
						g_dpDBClient.SendLogSMItemUse("1", (CUser*)this, pItemElem, pItemProp);
					}
					else if (pItemElem->m_dwItemId == II_SYS_SYS_SCR_RECCURENCE && pItemElem->m_bCharged != TRUE)
					{
						g_DPSrvr.PutItemLog((CUser*)(this), "w", "USE_RECCURENCE_ITEM", pItemElem, 1);
					}
					else if (pItemElem->m_dwItemId == II_CHR_SYS_SCR_RESTATE && pItemElem->m_bCharged != TRUE)
					{
						g_DPSrvr.PutItemLog((CUser*)(this), "w", "USE_RESTATE_ITEM", pItemElem, 1);
					}
				}
			}
		}
		break;
#if __VER >= 16
		case IK2_ONCE:
		{
			int nResult = 0;
			if (IsNeedTarget(pItemProp))
			{
				return FALSE;
			}

			nResult = DoUseItemOnce(pItemProp, pItemElem);
			{
				if (0 < nResult)
				{
					if (nResult == 2)
					{
						((CUser*)this)->AddDefinedText(TID_GAME_LIMITED_USE, "");
					}
					else if (nResult == 3)
					{
						((CUser*)this)->AddDefinedText(TID_GAME_NOTOVERLAP_USE, "");
					}
					return FALSE;
				}
			}
		}
		break;
		case IK2_KEEP:
		{
#ifndef __NEW_STACKABLE_AMPS
			int nResult = 0;
			nResult = DoUseItemSystem(pItemProp, pItemElem, nPart);
			{
				if (nResult > 0)
				{
					if (nResult == 2)
					{
						((CUser*)this)->AddDefinedText(TID_GAME_LIMITED_USE, "");
					}
					else if (nResult == 3)
					{
						((CUser*)this)->AddDefinedText(TID_GAME_NOTOVERLAP_USE, "");
					}
					return FALSE;
				}
			}
#else // __NEW_STACKABLE_AMPS
			int nResult = 0;
			nResult = DoUseItemKeep(pItemProp, pItemElem);
			{
				if (nResult > 0)
				{
					if (nResult == 1)
					{
						CString str;
						str.Format("%d - %d", pItemProp->nMinLimitLevel, pItemProp->nMaxLimitLevel);
						((CUser*)this)->AddDefinedText(TID_GAME_EXP_NOTUSELEVEL, "\"%s\"", str);
						return FALSE;
					}
					else if (nResult == 2)
					{
						((CUser*)this)->AddDefinedText(TID_GAME_LIMITED_USE, "");
						return FALSE;
					}
					else if (nResult == 3)
					{
						CString str;
						str.Format("%d", GetLevel());
						CString szMaxBuf;
						szMaxBuf.Format("%d", pItemProp->nMaxDuplication);
						((CUser*)this)->AddDefinedText(TID_GAME_EXP_NOTUSE, "\"%s\" \"%s\"", str, szMaxBuf); // 
						return FALSE;
					}
					else if (nResult == 4)
					{
						int nExtraEXP = 0;
						for (MAPBUFF::iterator i = m_buffs.m_mapBuffs.begin(); i != m_buffs.m_mapBuffs.end(); ++i)
						{
							ItemProp* pAmpProp = prj.GetItemProp(i->second->GetId());

							if (pAmpProp)
							{
								if (pAmpProp->dwItemKind3 == IK3_EXP_RATE)
								{
									nExtraEXP += pAmpProp->nEffectValue;
								}
							}
						}
						CString strTemp;
						strTemp.Format("%s %d%% %s", prj.GetText(TID_GAME_EXPITEM_TOOLTIP), nExtraEXP, prj.GetText(TID_GAME_EXPITEM_TOOLTIP1));
						((CUser*)this)->AddText(strTemp); // 
					}
				}
			}
#endif // __NEW_STACKABLE_AMPS
		}
		break;
#endif // __VER >= 16
		case IK2_REFRESHER:
		{
			if (pItemProp->dwCircleTime != (DWORD)-1)
			{
				if (IsSMMode(SM_MAINTAIN_MP) == FALSE && SetSMMode(SM_MAINTAIN_MP, pItemProp->dwCircleTime))
				{
					SetPointParam(DST_MP, GetMaxManaPoint());
				}
				else
				{
					((CUser*)this)->AddDefinedText(TID_GAME_LIMITED_USE, ""); //   
					return FALSE;
				}
				g_dpDBClient.SendLogSMItemUse("1", (CUser*)this, pItemElem, pItemProp);
			}
			else
			{
				if (DoUseItemFood(pItemProp, pItemElem) == FALSE)
					return FALSE;
			}
			break;
		}
		case IK2_POTION:
			if (pItemProp->dwCircleTime != (DWORD)-1)
			{
				if (IsSMMode(SM_MAINTAIN_FP) == FALSE && SetSMMode(SM_MAINTAIN_FP, pItemProp->dwCircleTime))
				{
					SetPointParam(DST_FP, GetMaxFatiguePoint());
				}
				else
				{
					((CUser*)this)->AddDefinedText(TID_GAME_LIMITED_USE, ""); //   
					return FALSE;
				}
				g_dpDBClient.SendLogSMItemUse("1", (CUser*)this, pItemElem, pItemProp);
			}
			else
			{
				if (DoUseItemFood(pItemProp, pItemElem) == FALSE)
					return FALSE;
			}
			break;
		case IK2_FOOD:
			if (DoUseItemFood(pItemProp, pItemElem) == FALSE)
				return FALSE;
			break;
		case IK2_AIRFUEL:
		{
			ItemProp* pRideProp = prj.GetItemProp(m_dwRideItemIdx);
			if (pRideProp && TRUE == IsPlayer() && m_pActMover->IsFly())
			{
				if (pItemProp->dwItemKind3 == IK3_ACCEL)
				{
					m_tmAccFuel = pItemProp->dwAFuelReMax * 1000;;
				}
				else
				{
					if (pRideProp->dwItemKind3 == IK3_BOARD && pItemProp->dwItemKind3 == IK3_CFLIGHT)
					{
						((CUser*)this)->AddDefinedText(TID_GAME_COMBFUEL, "");
						return FALSE;
					}
					else
						if (pRideProp->dwItemKind3 == IK3_STICK && pItemProp->dwItemKind3 == IK3_BFLIGHT)
						{
							((CUser*)this)->AddDefinedText(TID_GAME_BOARDFUEL, "");
							return FALSE;
						}

					m_nFuel += pItemProp->dwFuelRe;
					if ((DWORD)(m_nFuel) >= pRideProp->dwFFuelReMax)
						m_nFuel = pRideProp->dwFFuelReMax;
				}
				((CUser*)this)->AddSetFuel(m_nFuel, m_tmAccFuel);
			}
			else
				return FALSE;
		}
		break;

		case IK2_SKILL:
		{
			BOOL bUseItem = FALSE;
			DWORD dwActiveSkill = pItemProp->dwActiveSkill;
			if (dwActiveSkill != NULL_ID)
			{
				if (pItemProp->dwActiveSkillRate == NULL_ID ||
					xRandom(100) < pItemProp->dwActiveSkillRate)
				{
					ItemProp* pSkillProp;
					pSkillProp = (ItemProp*)prj.GetSkillProp(dwActiveSkill);
					if (pSkillProp)
					{
						if (pSkillProp->dwUseChance == WUI_TARGETINGOBJ)
						{
							if (IsPlayer())
							{
								DWORD idTarget = ((CUser*)this)->m_idSetTarget;
								CMover* pTarget = prj.GetMover(idTarget);
								if (IsValidObj(pTarget))
								{
									DoActiveSkill(dwActiveSkill, pItemProp->dwActiveSkillLv, pTarget);
								}
							}
						}
						else
							if (pSkillProp->dwUseChance == WUI_NOW)
							{
								DoActiveSkill(dwActiveSkill, pItemProp->dwActiveSkillLv, this);
							}
					}
					else
						Error("DoUseItem, IK2_SKILL, item %s -> %d skill not prop", pItemProp->szName, dwActiveSkill);
				}
			}
		}
		break;
		default:
		{
			if (pItemProp->dwSkillTime != NULL_ID)
			{
				DoApplySkill(this, pItemProp, NULL);
			}
		}
		}

		OnAfterUseItem(pItemProp);

		pItemElem->UseItem();

		CHAR cUIParam = UI_NUM;
		if (dwGroup)
		{
			CUser* pUser = (CUser*)this;
			pUser->m_cooltimeMgr.SetTime(dwGroup, pItemProp->GetCoolTime());
			cUIParam = UI_COOLTIME;
		}

		UpdateItemBag((BYTE)(dwId), cUIParam, pItemElem->m_nItemNum, nBag);
	}
#endif // WORLDSERVER

	return TRUE;
}
#endif

BOOL CMover::DoUseItem( DWORD dwData, DWORD dwFocusId, int nPart  )
{
#ifdef __WORLDSERVER
	if( IsDie() )
		return FALSE;
#ifdef __S_SERVER_UNIFY
	if( ((CUser*)this)->m_bAllAction == FALSE )
		return FALSE;
#endif // __S_SERVER_UNIFY

#ifdef __GAMEGUARD
	if (GetHitPoint() > GetMaxHitPoint())
		SetHitPoint(GetMaxHitPoint());
	if (GetManaPoint() > GetMaxManaPoint())
		SetManaPoint(GetMaxManaPoint());
	if (GetFatiguePoint() > GetMaxFatiguePoint())
		SetFatiguePoint(GetMaxFatiguePoint());
#endif // __GAMEGUARD

	WORD dwType = LOWORD( dwData );
	WORD dwId   = HIWORD( dwData );

	CItemBase* pItemBase = GetItemId( dwId ); 
	if( IsUsableItem( pItemBase ) == FALSE )
		return FALSE;

	CItemElem* pItemElem = (CItemElem*)pItemBase;
	ItemProp* pItemProp  = pItemBase->GetProp();

#ifdef __SECURITY_FIXES
	if (!pItemProp)
		return FALSE;
#endif //  __SECURITY_FIXES

	if( pItemProp->dwItemKind3 == IK3_LINK )
	{
		pItemProp	= prj.GetItemProp( pItemProp->dwActiveSkill );
		if( pItemProp == NULL )
			return FALSE;
	}

	DWORD dwItemKind1    = pItemProp->dwItemKind1;
	DWORD dwItemKind2    = pItemProp->dwItemKind2;
	DWORD dwItemKind3    = pItemProp->dwItemKind3;

#ifdef __GAMEGUARD
	if (pItemProp->dwItemKind3 == IK3_TEXT_DISGUISE)
	{
		CItemElem* pHat = ((CUser*)this)->m_Inventory.GetEquip(PARTS_HAT);
		if (pHat && (pHat->GetProp()->dwID == II_ARM_M_CHR_DARKVADER01HAT || pHat->GetProp()->dwID == II_ARM_F_CHR_DARKVADER01HAT))
			return FALSE;
	}
#endif // __GAMEGUARD

#ifdef PERFECT_EATPET
#ifdef __WORLDSERVER
	BOOL bPet;
	BYTE nKind;

	if (pItemProp->dwItemKind3 == IK3_PET_SCROLL)
	{
		CPet* pPet = ((CUser*)this)->GetPet();

		if (pPet && pPet->GetLevel() != PL_EGG)
			return FALSE;

		switch (pItemProp->dwID)
		{
		case II_SYS_PERFECT_EATPET_01: nKind = 0; bPet = TRUE; break;
		case II_SYS_PERFECT_EATPET_02: nKind = 1; bPet = TRUE; break;
		case II_SYS_PERFECT_EATPET_03: nKind = 2; bPet = TRUE; break;
		case II_SYS_PERFECT_EATPET_04: nKind = 3; bPet = TRUE; break;
		case II_SYS_PERFECT_EATPET_05: nKind = 4; bPet = TRUE; break;
		case II_SYS_PERFECT_EATPET_06: nKind = 5; bPet = TRUE; break;
		case II_SYS_PERFECT_EATPET_07: nKind = 6; bPet = TRUE; break;
		}

		if (bPet == TRUE)
		{
			if (IsValidObj(((CUser*)this)))
			{
				if (pPet == NULL)
					return TRUE;
				if (nKind >= PK_MAX)
					return TRUE;
				BYTE nExpRate = 0;
				BYTE nLevel = 5;

				if (nLevel > PL_S)
					return TRUE;

				BYTE nLife;
				nLife = 99;
				CItemElem* pItemElem2 = ((CUser*)this)->GetPetItem();
				pPet->SetKind(nKind);
				pPet->SetLevel(nLevel);

				if (nLevel == PL_EGG)
					pPet->SetKind(0);
				pItemElem2->m_dwItemId = pPet->GetItemId();
				pPet->SetEnergy(pPet->GetMaxEnergy());
				DWORD dwExp = pPet->GetMaxExp() * nExpRate / 100;
				pPet->SetExp(dwExp);

				//LVL Fam.
#if PERFECT_EATPET < 99999
				pPet->SetAvailLevel(PL_D, 1);
				pPet->SetAvailLevel(PL_C, 3);
				pPet->SetAvailLevel(PL_B, 5);
				pPet->SetAvailLevel(PL_A, 7);
				pPet->SetAvailLevel(PL_S, 9);
#else // PERFECT_EATPET
				pPet->SetAvailLevel(PL_D, 9);
				pPet->SetAvailLevel(PL_C, 9);
				pPet->SetAvailLevel(PL_B, 9);
				pPet->SetAvailLevel(PL_A, 9);
				pPet->SetAvailLevel(PL_S, 9);
#endif // PERFECT_EATPET
				pPet->SetLife(nLife);

				if (((CUser*)this)->HasPet())
					((CUser*)this)->RemovePet();

				g_dpDBClient.CalluspPetLog(((CUser*)this)->m_idPlayer, pItemElem2->GetSerialNumber(), 0, PETLOGTYPE_LEVELUP, pPet);
				((CUser*)this)->AddPet(pPet, PF_PET_GET_AVAIL);
				g_UserMng.AddPetLevelup(((CUser*)this), MAKELONG((WORD)pPet->GetIndex(), (WORD)pPet->GetLevel()));
				((CUser*)this)->UpdateItem((BYTE)pItemElem->m_dwObjId, UI_NUM, 0);
				return TRUE;
			}
		}
	}
#endif // __WORLDSERVER
#endif // PERFECT_EATPET

#ifdef NEW_PET
#ifdef __WORLDSERVER
	{
		BOOL bPet;
		BYTE nKind;
	}

	if (pItemProp->dwItemKind3 == IK3_PET_SCROLL)
	{
		CPet* pPet = ((CUser*)this)->GetPet();

		if (pPet && pPet->GetLevel() != PL_EGG)
			return FALSE;

		switch (pItemProp->dwID)
		{
		case II_SYS_NEW_PET_01: nKind = 7; bPet = TRUE; break;
		case II_SYS_NEW_PET_02: nKind = 8; bPet = TRUE; break;
		case II_SYS_NEW_PET_03: nKind = 9; bPet = TRUE; break;
		case II_SYS_NEW_PET_04: nKind = 10; bPet = TRUE; break;
		case II_SYS_NEW_PET_05: nKind = 11; bPet = TRUE; break;
		case II_SYS_NEW_PET_06: nKind = 12; bPet = TRUE; break;
		case II_SYS_NEW_PET_07: nKind = 13; bPet = TRUE; break;
		}

		if (bPet == TRUE)
		{
			if (IsValidObj(((CUser*)this)))
			{
				if (pPet == NULL)
					return TRUE;
				if (nKind >= PK_MAX)
					return TRUE;
				BYTE nExpRate = 0;
				BYTE nLevel = 1;

				if (nLevel > PL_S)
					return TRUE;

				BYTE nLife;
				nLife = 1;
				CItemElem* pItemElem2 = ((CUser*)this)->GetPetItem();
				pPet->SetKind(nKind);
				pPet->SetLevel(nLevel);

				if (nLevel == PL_EGG)
					pPet->SetKind(0);
				pItemElem2->m_dwItemId = pPet->GetItemId();
				pPet->SetEnergy(pPet->GetMaxEnergy());
				DWORD dwExp = pPet->GetMaxExp() * nExpRate / 100;
				pPet->SetExp(dwExp);

				//LVL Fam.
#if NEW_PET < 1
				pPet->SetAvailLevel(PL_D, 1);
#else // NEW_PET
				pPet->SetAvailLevel(PL_D, 1);
#endif // NEW_PET
				pPet->SetLife(nLife);

				if (((CUser*)this)->HasPet())
					((CUser*)this)->RemovePet();

				g_dpDBClient.CalluspPetLog(((CUser*)this)->m_idPlayer, pItemElem2->GetSerialNumber(), 0, PETLOGTYPE_LEVELUP, pPet);
				((CUser*)this)->AddPet(pPet, PF_PET_GET_AVAIL);
				g_UserMng.AddPetLevelup(((CUser*)this), MAKELONG((WORD)pPet->GetIndex(), (WORD)pPet->GetLevel()));
				((CUser*)this)->UpdateItem((BYTE)pItemElem->m_dwObjId, UI_NUM, 0);
				return TRUE;
			}
		}
	}
#endif // __WORLDSERVER
#endif // NEW_PET

	// ±æµå´ëÀü¸Ê¿¡¼­ ¼±¼ö¸¸ »ç¿ë
	CWorld* pWorld	= GetWorld();
	if( pWorld && pWorld->GetID() == WI_WORLD_GUILDWAR )
	{			
		if( m_nGuildCombatState == 0 )
		{
			if( IsPlayer() )
				((CUser*) this)->AddText( prj.GetText( TID_GAME_GUILDCOMBAT_STANDS_NOTUSEITEM ) );	//"¼öÁ¤ÇØ¾ßÇÔ : °üÁß¼®¿¡¼­´Â ¾ÆÀÌÅÛÀ» »ç¿ëÇÒ¼ö ¾ø½À´Ï´Ù" );
			return FALSE;
		}
	}
#if __VER >= 10 // __LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans ¼®È­µð¹öÇÁ¿¡ °É¸®¸é ¾ÆÀÌÅÛ »ç¿ë±ÝÁö
	if( GetAdjParam( DST_CHRSTATE ) & CHS_SETSTONE)
		return FALSE;
#endif	//__LEGEND	//	10Â÷ Àü½Â½Ã½ºÅÛ	Neuz, World, Trans
	if( pItemProp->dwParts != NULL_ID )
	{
		// armor, weapon
		if( m_pActMover->IsActAttack() == FALSE )	// °ø°ÝÁß¿£ Àåºñ ¸ø¹Ù²Þ.
		{
			DoUseEquipmentItem( pItemElem, dwId, nPart );
		}
		// ÀåÂø ¾ÆÀÌÅÛÀº Å»Âø °¡´ÉÇØ¾ßÇÏ¹Ç·Î ±â°£ ¸¸·á¿¡ ÀÇÇÑ »ç¿ë Á¦ÇÑ ¾øÀ½.
	}
	else	// ÀÏ¹ÝÀûÀÎ ¾ÆÀÌÅÛ »ç¿ë 
	{
		if( IsItemRedyTime( pItemProp, pItemElem->m_dwObjId, TRUE ) == FALSE )
			return FALSE;

		DWORD dwGroup = 0;

		if( IsPlayer() )
		{
			CUser* pUser = (CUser*)this;

			dwGroup = pUser->m_cooltimeMgr.GetGroup( pItemProp );
			if( dwGroup )
			{
				if( pUser->m_cooltimeMgr.CanUse( dwGroup ) == FALSE )
				{
					return FALSE;
				}
			}
		}

		// ºñ »ó¿ëÈ­ ¾ÆÀÌÅÛ
		switch( pItemProp->dwItemKind2 )
		{
#if __VER >= 15 // __GUILD_HOUSE
			case IK2_GUILDHOUSE_FURNITURE:
			case IK2_GUILDHOUSE_NPC:
			case IK2_GUILDHOUSE_PAPERING:
				{
					if( GuildHouseMng->SendWorldToDatabase( static_cast<CUser*>( this ), GUILDHOUSE_PCKTTYPE_LISTUP, GH_Fntr_Info( pItemProp->dwID ) ) )
						g_DPSrvr.PutItemLog( static_cast<CUser*>( this ), "f", "GUILDHOUSE_LISTUP", pItemElem, 1 );
					else
						return FALSE;
					break;
				}
			case IK2_GUILDHOUES_COMEBACK:
				{
					if( !GuildHouseMng->EnteranceGuildHouse( static_cast<CUser*>( this ), pItemProp->dwID ) )
						return FALSE;
					break;
				}			
#endif // __GUILD_HOUSE
#if __VER >= 13 // __HOUSING
			case IK2_FURNITURE:
			case IK2_PAPERING:
				{
					if(	CHousingMng::GetInstance()->ReqSetFurnitureList( (CUser*)this, pItemElem->m_dwItemId ) )
					{
						// ÇÏ¿ìÂ¡ ¸®½ºÆ® Ãß°¡ ·Î±×
						LogItemInfo aLogItem;
						aLogItem.SendName	= GetName();
						aLogItem.RecvName = "HOUSING_USE";
						aLogItem.WorldId	= GetWorld()->GetID();
						aLogItem.Gold	= GetGold();
						aLogItem.Gold2	= GetGold();
						aLogItem.Action	= "f";
						g_DPSrvr.OnLogItem( aLogItem, pItemElem );
					}
					else
						return FALSE;
					break;
				}
#endif // __HOUSING
#ifdef __FUNNY_COIN
			case IK2_TOCASH:
				{
					if( !CFunnyCoin::GetInstance()->DoUseFunnyCoin( (CUser*)this, pItemElem ) )
						return FALSE;
				}
				break;
#endif // __FUNNY_COIN
			case IK2_WARP:
				return DoUseItemWarp( pItemProp, pItemElem );
#if __VER >= 11 // __SYS_COLLECTING
			case IK2_BUFF2:
				{
					if( IsDoUseBuff( pItemProp ) != 0 )
						return FALSE;
					CTime tm	= CTime::GetCurrentTime() + CTimeSpan( 0, 0, pItemProp->dwAbilityMin, 0 );
					time_t t	= (time_t)( tm.GetTime() );
					// wID: dwItemId
					// dwLevel
					AddBuff( BUFF_ITEM2, (WORD)( pItemElem->m_dwItemId ), t, 0 ); 
					break;
				}
#endif	// __SYS_COLLECTING
#ifdef __BUFF_TOGIFT
			case IK2_BUFF_TOGIFT:
#endif // __BUFF_TOGIFT
			case IK2_BUFF:
				{
					if( IsDoUseBuff( pItemProp ) != 0 )
						return FALSE;
					DoApplySkill( this, pItemProp, NULL );		// ´ë»ó¿¡°Ô ¾ÆÀÌÅÛÈ¿°ú¸¦ Àû¿ëÇÔ. 
#if __VER >= 8 //__CSC_VER8_5
					if( pItemProp->dwItemKind3 == IK3_ANGEL_BUFF )
					{
		#ifdef __EXP_ANGELEXP_LOG
						((CUser*)this)->m_nAngelExpLog = 0;
		#endif // __EXP_ANGELEXP_LOG
		#ifdef __ANGEL_LOG
						LogItemInfo aLogItem;
						aLogItem.Action = "&";
						aLogItem.SendName = ((CUser*)this)->GetName();
						aLogItem.RecvName = "ANGEL_SUMMON";
						aLogItem.WorldId = ((CUser*)this)->GetWorld()->GetID();
						aLogItem.Gold = aLogItem.Gold2 = ((CUser*)this)->GetGold();
						//aLogItem.ItemName = pItemProp->szName;
						_stprintf( aLogItem.szItemName, "%d", pItemProp->dwID );
						g_DPSrvr.OnLogItem( aLogItem );
		#endif // __ANGEL_LOG
						m_nAngelExp = 0;
						m_nAngelLevel = GetLevel() + 1;
						((CUser*)this)->AddAngelInfo();
					}
#endif // __CSC_VER8_5
				}
				break;
			case IK2_TEXT: //ÅØ½ºÆ® ¹®¼­ Ã³¸® 
				// Äù½ºÆ®°¡ ÀÖÀ¸¸é Äù½ºÆ® ½ÃÀÛ 
				if( pItemProp->dwQuestId && pItemElem->m_bItemResist == FALSE )
				{
					::__SetQuest( GetId(), pItemProp->dwQuestId );
					pItemElem->m_bItemResist = TRUE;
					UpdateItem( (BYTE)( pItemElem->m_dwObjId ), UI_IR, pItemElem->m_bItemResist );	
				}
				break;
			case IK2_SYSTEM:
				{
#ifdef __JEFF_9_20
#ifdef __WORLDSERVER
					if( pItemProp->dwLimitLevel1 != 0xFFFFFFFF )
					{
						if( GetLevel() < (int)( pItemProp->dwLimitLevel1 ) )
						{
							( (CUser*)this )->AddDefinedText( TID_GAME_ITEM_LEVEL, "\"%d\"", pItemProp->dwLimitLevel1 );
							return FALSE;
						}
					}
#endif	// __WORLDSERVER
#endif	// __JEFF_9_20
					int nResult = 0;
					nResult = DoUseItemSystem( pItemProp, pItemElem, nPart );
					{
						if( 0 < nResult )
						{
							if( nResult == 2 )
							{
								((CUser*)this)->AddDefinedText( TID_GAME_LIMITED_USE, "" ); // »ç¿ëÁßÀÌ¾î¼­ »ç¿ëÇÒ¼ö ¾øÀ½
							}
							else if( nResult == 3 )
							{
								((CUser*)this)->AddDefinedText( TID_GAME_NOTOVERLAP_USE, "" ); // ÀÌ ¾ÆÀÌÅÛ°ú´Â Áßº¹ÇÏ¿© »ç¿ëÇÒ ¼ö ¾ø½À´Ï´Ù
							}
							return FALSE;
						}
						else
						{
							if( pItemElem->m_dwItemId == II_SYS_SYS_SCR_RECCURENCE_LINK )
							{
								g_dpDBClient.SendLogSMItemUse( "1", (CUser*)this, pItemElem, pItemProp );
							}

							//////////////////////////////////////////////////////////////////////////
							//	mulcom	BEGIN100125	ÀÌº¥Æ®¿ë ¸®½ºÅ³ ¹× ÀÌº¥Æ®¿ë ¸®½ºÅ×Æ® »ç¿ë ³»¿ª¿¡ ´ëÇÑ ·Î±× Ãß°¡
							//						( e-mail : [À¯·´] ¾ÆÀÌÅÛ ·Î±× Ãß°¡ ( 2010-01-25 17:33 ) Âü°í )
							else if( pItemElem->m_dwItemId == II_SYS_SYS_SCR_RECCURENCE && pItemElem->m_bCharged != TRUE )
							{
								g_DPSrvr.PutItemLog( (CUser*)( this ), "w", "USE_RECCURENCE_ITEM", pItemElem, 1 );
							}
							else if(  pItemElem->m_dwItemId == II_CHR_SYS_SCR_RESTATE && pItemElem->m_bCharged != TRUE )
							{
								g_DPSrvr.PutItemLog( (CUser*)( this ), "w", "USE_RESTATE_ITEM", pItemElem, 1 );
							}
							//	mulcom	END100125	ÀÌº¥Æ®¿ë ¸®½ºÅ³ ¹× ÀÌº¥Æ®¿ë ¸®½ºÅ×Æ® »ç¿ë ³»¿ª¿¡ ´ëÇÑ ·Î±× Ãß°¡
							//////////////////////////////////////////////////////////////////////////
						}
					}
				}
				break;
#if __VER >= 16
			case IK2_ONCE:
			{
				int nResult = 0;
				if (IsNeedTarget(pItemProp))
				{
					return FALSE;
				}

				nResult = DoUseItemOnce(pItemProp, pItemElem);
				{
					if (0 < nResult)
					{
						if (nResult == 2)
						{
							((CUser*)this)->AddDefinedText(TID_GAME_LIMITED_USE, "");
						}
						else if (nResult == 3)
						{
							((CUser*)this)->AddDefinedText(TID_GAME_NOTOVERLAP_USE, "");
						}
						return FALSE;
					}
				}
			}
			break;
			case IK2_KEEP:
			{
#ifndef __NEW_STACKABLE_AMPS
				int nResult = 0;
				nResult = DoUseItemSystem(pItemProp, pItemElem, nPart);
				{
					if (nResult > 0)
					{
						if (nResult == 2)
						{
							((CUser*)this)->AddDefinedText(TID_GAME_LIMITED_USE, "");
						}
						else if (nResult == 3)
						{
							((CUser*)this)->AddDefinedText(TID_GAME_NOTOVERLAP_USE, "");
						}
						return FALSE;
					}
				}
#else // __NEW_STACKABLE_AMPS
				int nResult = 0;
				nResult = DoUseItemKeep(pItemProp, pItemElem);
				{
					if (nResult > 0)
					{
						if (nResult == 1)
						{
							CString str;
							str.Format("%d - %d", pItemProp->nMinLimitLevel, pItemProp->nMaxLimitLevel);
							((CUser*)this)->AddDefinedText(TID_GAME_EXP_NOTUSELEVEL, "\"%s\"", str);
							return FALSE;
						}
						else if (nResult == 2)
						{
							((CUser*)this)->AddDefinedText(TID_GAME_LIMITED_USE, "");
							return FALSE;
						}
						else if (nResult == 3)
						{
							CString str;
							str.Format("%d", GetLevel());
							CString szMaxBuf;
							szMaxBuf.Format("%d", pItemProp->nMaxDuplication);
							((CUser*)this)->AddDefinedText(TID_GAME_EXP_NOTUSE, "\"%s\" \"%s\"", str, szMaxBuf); // 
							return FALSE;
						}
						else if (nResult == 4)
						{
							int nExtraEXP = 0;
							for (MAPBUFF::iterator i = m_buffs.m_mapBuffs.begin(); i != m_buffs.m_mapBuffs.end(); ++i)
							{
								ItemProp* pAmpProp = prj.GetItemProp(i->second->GetId());

								if (pAmpProp)
								{
									if (pAmpProp->dwItemKind3 == IK3_EXP_RATE)
									{
										nExtraEXP += pAmpProp->nEffectValue;
									}
								}
							}
							CString strTemp;
							strTemp.Format("%s %d%% %s", prj.GetText(TID_GAME_EXPITEM_TOOLTIP), nExtraEXP, prj.GetText(TID_GAME_EXPITEM_TOOLTIP1));
							((CUser*)this)->AddText(strTemp); // 
						}
					}
				}
#endif
		}
			break;
#endif
			case IK2_BLINKWING:
				return DoUseItemBlinkWing( pItemProp, pItemElem );

			case IK2_REFRESHER:
				{
					if( pItemProp->dwCircleTime != (DWORD)-1 )
					{
						if( IsSMMode( SM_MAINTAIN_MP ) == FALSE && SetSMMode( SM_MAINTAIN_MP, pItemProp->dwCircleTime ) )
						{
							SetPointParam( DST_MP, GetMaxManaPoint() );
						}
						else
						{
							((CUser*)this)->AddDefinedText( TID_GAME_LIMITED_USE, "" ); //   
							return FALSE;
						}
						g_dpDBClient.SendLogSMItemUse( "1", (CUser*)this, pItemElem, pItemProp );
					}
					else
					{
						if( DoUseItemFood( pItemProp, pItemElem ) == FALSE )
							return FALSE;
					}
					break;
				}
			case IK2_POTION:
				if( pItemProp->dwCircleTime != (DWORD)-1 )	// »ó¿ë¾ÆÀÌÅÛÀº dwCircleTimeÀ» ½è´õ¶ó. ³ªÁß¿¡ dwSkillTimeÀ¸·Î ÅëÇÕ¿¹Á¤.
				{
					if( IsSMMode( SM_MAINTAIN_FP ) == FALSE && SetSMMode( SM_MAINTAIN_FP, pItemProp->dwCircleTime ) )
					{
						SetPointParam( DST_FP, GetMaxFatiguePoint() );
					}
					else
					{
						((CUser*)this)->AddDefinedText( TID_GAME_LIMITED_USE, "" ); //   
						return FALSE;
					}
					g_dpDBClient.SendLogSMItemUse( "1", (CUser*)this, pItemElem, pItemProp );
				}
				else
				{
					if( DoUseItemFood( pItemProp, pItemElem ) == FALSE )
						return FALSE;
				}
				break;
			case IK2_FOOD:
				if( DoUseItemFood( pItemProp, pItemElem ) == FALSE )
					return FALSE;
				break;
#ifdef __ORIGIN_CARD_SYSTEM
			case IK2_CARD:
			{
				if (CheckCardAlbum(pItemElem))
				{
					AddCardToAlbum(pItemElem);
				}
				else
				{
					((CUser*)this)->AddText("Il n'y a pas assez de place dans l'album.");
					return FALSE;
				}
				break;
			}
#endif // __ORIGIN_CARD_SYSTEM
			case IK2_AIRFUEL:	// ºñÇà¿¬·á·ù
				{
					ItemProp *pRideProp = prj.GetItemProp( m_dwRideItemIdx );	// ºøÀÚ·ç ÇÁ·ÎÆÛÆ¼
					if( pRideProp && TRUE == IsPlayer() && m_pActMover->IsFly() )
					{
						if( pItemProp->dwItemKind3 == IK3_ACCEL )	// °¡¼Ó ¿¬·á
						{
							m_tmAccFuel = pItemProp->dwAFuelReMax * 1000;;	// ¸îÃÊ°£ °¡¼ÓÇÒ¼ö ÀÖ³Ä.
						}
						else
						{	// ºñÇà¿¬·á
							if( pRideProp->dwItemKind3 == IK3_BOARD && pItemProp->dwItemKind3 == IK3_CFLIGHT )	// Å¸°íÀÖ´Â°Ç º¸µå / »ç¿ëÇÏ·Á´Â°Ç ºøÀÚ·ç¿ë
							{
								((CUser*)this)->AddDefinedText( TID_GAME_COMBFUEL, "" );	// ÀÌ°Ç ºøÀÚ·ç¿ëÀÌ¿©~
								return FALSE;
							}
							else
							if( pRideProp->dwItemKind3 == IK3_STICK && pItemProp->dwItemKind3 == IK3_BFLIGHT )	// Å¸°íÀÖ´Â°Ç ºøÀÚ·ç / »ç¿ëÇÏ·Á´Â°Ç º¸µå¿ë
							{
								((CUser*)this)->AddDefinedText( TID_GAME_BOARDFUEL, "" );	// ÀÌ°Ç º¸µå¿ëÀÌ¿©~
								return FALSE;
							}
								
							m_nFuel += pItemProp->dwFuelRe;		// ÃæÀü·®.
							if( (DWORD)( m_nFuel ) >= pRideProp->dwFFuelReMax )	// ºøÀÚ·ç ¿¬·áÅëº¸´Ù Å©¸é ³¡.
								m_nFuel = pRideProp->dwFFuelReMax;
						}
						((CUser *)this)->AddSetFuel( m_nFuel, m_tmAccFuel );		// º¯È­µÈ ·®À» Àü¼Û. - SetPointParam¿¡´Ù ÇÕÃÄµµ ±¦ÂúÀ»µí?
					} else
						return FALSE;
				}
				break;

			case IK2_GMTEXT:
				{
					BOOL bGMTime = TRUE;
					if( pItemProp->dwSkillTime != NULL_ID )		// Áö¼Ó½Ã°£ÀÌ ÀÖ´Â ¾ÆÀÌÅÛ
					{
						if( pItemProp->dwItemKind3 == IK3_TEXT_DISGUISE )	// º¯½Å ¾ÆÀÌÅÛÀº ºñÇàÁß¿¡´Â »ç¿ëÇÒ¼ö ¾øÀ½.
						{
							if( IsFly() )
							{
								((CUser*)this)->AddDefinedText( TID_PK_FLIGHT_NOUSE, "" ); // ºñÇà Áß¿¡´Â »ç¿ëÇÒ ¼ö ¾ø½À´Ï´Ù.
								bGMTime = FALSE;
							}
#ifdef __MOUNT
							else if (GetMountId() > 0)
							{
								((CUser*)this)->AddDefinedText(TID_PK_FLIGHT_NOUSE, ""); // ºñÇà Áß¿¡´Â »ç¿ëÇÒ ¼ö ¾ø½À´Ï´Ù.
								bGMTime = FALSE;
							}
#endif // __MOUNT
#if __VER >= 14	// __INSTANCE_DUNGEON	// ÀÎ´ø ³» ¶Ç´Â ÀÔÀå½Ã º¯½Å±¸ »ç¿ë ±ÝÁö
							else if( CInstanceDungeonHelper::GetInstance()->IsInstanceDungeon( GetWorld()->GetID() ) )
							{
								((CUser*)this)->AddDefinedText( TID_GAME_INSTANCE_DISGUISE01 );
								bGMTime = FALSE;
							}
#endif // __INSTANCE_DUNGEON	// ÀÎ´ø ³» ¶Ç´Â ÀÔÀå½Ã º¯½Å±¸ »ç¿ë ±ÝÁö
						}
						if( bGMTime )
						{
							if( !HasBuffByIk3( pItemProp->dwItemKind3 ) )
							{
								DoApplySkill( this, pItemProp, NULL );		// ´ë»ó¿¡°Ô ¾ÆÀÌÅÛÈ¿°ú¸¦ Àû¿ëÇÔ. 
							}
							else
							{
								((CUser*)this)->AddDefinedText( TID_GAME_LIMITED_USE, "" ); // »ç¿ëÁßÀÌ¾î¼­ »ç¿ëÇÒ¼ö ¾øÀ½
								bGMTime = FALSE;
							}
						}								
					}

					if(  pItemProp->dwID == II_SYS_SYS_GM_NODISGUISE )
					{
						if( HasBuffByIk3( IK3_TEXT_DISGUISE ) )
							RemoveIk3Buffs( IK3_TEXT_DISGUISE );
						else
							bGMTime = FALSE;
					}

					if( bGMTime )
					{
						if( pItemProp->dwID != II_SYS_SYS_GM_NODISGUISE )
						{
							char szGMCommand[64] = {0,};
							CString szGMText = pItemProp->szTextFileName;
							szGMText.Replace( '(', '\"' );
							szGMText.Replace( ')', '\"' ); 
							int nGMCount = szGMText.Find( "/", 1 );
							if( nGMCount != -1 )
								strncpy( szGMCommand, szGMText, nGMCount );
							else
								strcpy( szGMCommand, szGMText );
							ParsingCommand( szGMCommand, (CMover*)this, TRUE );
						}
					}
					else
						return FALSE;
				}
				break;
			case IK2_SKILL:
				{
					BOOL bUseItem = FALSE;
					DWORD dwActiveSkill = pItemProp->dwActiveSkill;
					if( dwActiveSkill != NULL_ID )		// Ãß°¡ ¹ßµ¿ ½ºÅ³ÀÌ ÀÖ´Ù.
					{
						if( pItemProp->dwActiveSkillRate == NULL_ID ||
							xRandom(100) < pItemProp->dwActiveSkillRate )	// ¹ßµ¿È®·ü¿¡ °É·È´Â°¡.
						{
							ItemProp* pSkillProp;
							pSkillProp = (ItemProp *)prj.GetSkillProp( dwActiveSkill );
							if( pSkillProp )
							{
								if( pSkillProp->dwUseChance == WUI_TARGETINGOBJ )	// Å¸°Ù¿¡°Ô »ç¿ëÇÏ´Â ¹æ½Ä.
								{
									if( IsPlayer() )
									{
										DWORD idTarget = ((CUser*)this)->m_idSetTarget;
										CMover *pTarget = prj.GetMover( idTarget );
										if( IsValidObj( pTarget ) )
										{
											DoActiveSkill( dwActiveSkill, pItemProp->dwActiveSkillLv, pTarget );	// dwActiveSkill ¹ßµ¿.
										}
									}
								} else
								if( pSkillProp->dwUseChance == WUI_NOW )		// ÀÚ½Å¿¡°Ô¸¸ »ç¿ëÇÏ´Â ¹æ½Ä.
								{
									DoActiveSkill( dwActiveSkill, pItemProp->dwActiveSkillLv, this );	// ¹ßµ¿
								}
							} else
								Error( "DoUseItem, IK2_SKILL, item %s -> %d skill not prop", pItemProp->szName, dwActiveSkill );
						}
					}
				}
				break;
#ifdef __TREASUREBOX
			case IK2_TREASURE: return FALSE; break;
#endif // __TREASUREBOX
			default:
				{
					if( pItemProp->dwSkillTime != NULL_ID )		// Áö¼Ó½Ã°£ÀÌ ÀÖ´Â ¾ÆÀÌÅÛ
					{
						DoApplySkill( this, pItemProp, NULL );		// ´ë»ó¿¡°Ô ¾ÆÀÌÅÛÈ¿°ú¸¦ Àû¿ëÇÔ. 
					}
				}
		} // switch ik2

		switch( pItemProp->dwItemKind3 )
		{
			case IK3_EGG:
				DoUseSystemPet( pItemElem );
				break;
			case IK3_PET:
				DoUseEatPet( pItemElem );
				break;
#ifdef __NEW_ITEM_VARUNA
			case IK3_SUMMON_NPC:
				DoUseBarunaPet(pItemElem);
				break;
#endif // __NEW_ITEM_VARUNA
		}

		OnAfterUseItem( pItemProp );	// raiders 06.04.20
		pItemElem->UseItem();			// --m_nItemNum;

		if( pItemElem->m_bCharged )		// »ó¿ëÈ­ ¾ÆÀÌÅÛ ·Î±×
			g_dpDBClient.SendLogSMItemUse( "1", (CUser*)this, pItemElem, pItemProp );		

		CHAR cUIParam = UI_NUM;
		if( dwGroup )	// ÄðÅ¸ÀÓ ¾ÆÀÌÅÛÀÌ¸é »ç¿ë½Ã°¢À» ±â·ÏÇÑ´Ù.
		{
			CUser* pUser = (CUser*)this;
			pUser->m_cooltimeMgr.SetTime( dwGroup, pItemProp->GetCoolTime() );	
			cUIParam = UI_COOLTIME;
		}

		UpdateItem( (BYTE)( dwId ), cUIParam, pItemElem->m_nItemNum );	// °¹¼ö°¡ 0ÀÌ¸é  ¾ÆÀÌÅÛ »èÁ¦ , Àü¼Û 
	}
	
#endif // WORLDSERVER

	return TRUE;
}

// IK2_BLINKWINGÀÇ Ã³¸®.
BOOL CMover::DoUseItemBlinkWing( ItemProp *pItemProp, CItemElem* pItemElem, BOOL bUse )
{
#ifdef __WORLDSERVER
	if( m_pActMover->IsSit() ) // 2005.12.08 raiders ¾É¾Æ ÀÖÀ¸¸é ¾ÈµÇ°Ô 
		return FALSE;

	if( IsStateMode( STATE_BASEMOTION_MODE ) ) 
		return FALSE;

	if( bUse )
	{
		if( GetWorld()->m_dwWorldID == WI_WORLD_KEBARAS )
			return FALSE;
	}

	if( GetWorld()->m_dwWorldID == WI_WORLD_GUILDWAR )
		return FALSE;

#if __VER >= 11 // __GUILD_COMBAT_1TO1
	if( g_GuildCombat1to1Mng.IsPossibleUser( (CUser*)this ) )
	{
		if( IsPlayer() )
			((CUser*)this)->AddDefinedText( TID_GAME_GUILDCOMBAT1TO1_NOBLINKWING );
		return FALSE;
	}
#endif // __GUILD_COMBAT_1TO1

#if __VER >= 12 // __SECRET_ROOM
	if( CSecretRoomMng::GetInstance()->IsInTheSecretRoom( this ) )
	{
		if( IsPlayer() )
			((CUser*)this)->AddDefinedText( TID_GAME_SECRETROOM_USEBRINKITEM );
		return FALSE;
	}
#endif // __SECRET_ROOM

#if __VER >= 13 // __RAINBOW_RACE
	if( CRainbowRaceMng::GetInstance()->IsEntry( ((CUser*)this)->m_idPlayer ) )
	{
		if( IsPlayer() )
			((CUser*)this)->AddDefinedText( TID_GAME_RAINBOWRACE_NOTELEPORT );
		return FALSE;
	}
#endif // __RAINBOW_RACE

#if __VER >= 13 // __HOUSING
	if( GetWorld()->GetID() == WI_WORLD_MINIROOM )	// ÇÏ¿ìÂ¡¿¡¼­´Â ºí¸µÅ©À® ±ÝÁö.
		return FALSE;
#endif // __HOUSING

	// Á¦ÇÑ·¹º§ÀÌ °É·ÁÀÖÀ»¶§.
 	if( pItemProp->dwLimitLevel1 != NULL_ID && (int)( pItemProp->dwLimitLevel1 ) > GetLevel() )
	{
		if( TRUE == IsPlayer() )
			( (CUser*)this )->AddDefinedText( TID_GAME_USINGNOTLEVEL, "\"%s\"", pItemProp->szName );
		return FALSE;
	}

	if( pItemProp->dwItemKind3 == IK3_TOWNBLINKWING )	// IK3_TOWNBLINKWING
	{
		REPLACE_TYPE type = REPLACE_NORMAL;
		if( pItemProp->dwID == II_CHR_SYS_SCR_ESCAPEBLINKWING )
			type = REPLACE_FORCE; 

		// lodestar
		if( bUse )
		{
			if( IsUsableItem( pItemElem ) == FALSE )
				return FALSE;

			pItemElem->UseItem();
			UpdateItem( (BYTE)( pItemElem->m_dwObjId ), UI_NUM, pItemElem->m_nItemNum );
		}
		
		PRegionElem pRgnElem	= NULL;
		CWorld* pWorld	= GetWorld();
		if( !pWorld )
			return FALSE;

		if( IsChaotic() )
		{
#if __VER >= 8 // __S8_PK
			if( pWorld->GetID() != pWorld->m_dwIdWorldRevival && pWorld->m_dwIdWorldRevival != 0 )
				pRgnElem	= g_WorldMng.GetRevivalPosChao( pWorld->m_dwIdWorldRevival, pWorld->m_szKeyRevival );
			if( NULL == pRgnElem )	// Find near revival pos
				pRgnElem	= g_WorldMng.GetNearRevivalPosChao( pWorld->GetID(), GetPos() );
#else // __VER >= 8 // __S8_PK
			pRgnElem	= g_WorldMng.GetNearRevivalPosChao( pWorld->GetID(), GetPos() );
#endif // __VER >= 8 // __S8_PK
		}
		else

		{
			if( pWorld->GetID() != pWorld->m_dwIdWorldRevival && pWorld->m_dwIdWorldRevival != 0 )
				pRgnElem	= g_WorldMng.GetRevivalPos( pWorld->m_dwIdWorldRevival, pWorld->m_szKeyRevival );
			if( NULL == pRgnElem )	// Find near revival pos
				pRgnElem	= g_WorldMng.GetNearRevivalPos( pWorld->GetID(), GetPos() );
		}
		if( NULL != pRgnElem )
			REPLACE( g_uIdofMulti, pRgnElem->m_dwWorldId, pRgnElem->m_vPos, type, nRevivalLayer );
		else
			REPLACE( g_uIdofMulti, pWorld->GetID(), GetPos(), type, nDefaultLayer );
	}
	else
	{
		//		x: dwItemAtkOrder1
		//		y: dwItemAtkOrder2
		//		z: dwItemAtkOrder3
		//		angle: dwItemAtkOrder4
		//		dwWeaponType: worldid
		if( pItemProp->dwWeaponType == WI_WORLD_NONE || pItemProp->dwWeaponType == 0xffffffff )
			return FALSE;
		D3DXVECTOR3 vPos( (float)( pItemProp->dwItemAtkOrder1 ), (float)( pItemProp->dwItemAtkOrder2 ), (float)( pItemProp->dwItemAtkOrder3 ) );
		SetAngle( (float)pItemProp->dwItemAtkOrder4 );
		// remove & transfer
		if( bUse )
		{
			if( IsUsableItem( pItemElem ) == FALSE )
				return FALSE;

			pItemElem->UseItem();
			UpdateItem( (BYTE)( pItemElem->m_dwObjId ), UI_NUM, pItemElem->m_nItemNum );
		}
#if __VER >= 8 // __S8_PK
		if( IsChaotic() )
		{
			PRegionElem pRgnElem	= NULL;
			CWorld* pWorld = g_WorldMng.GetWorld( pItemProp->dwWeaponType );
			if( pWorld )
				pRgnElem	= g_WorldMng.GetRevivalPosChao( pItemProp->dwWeaponType, pItemProp->szTextFileName );
			if( NULL == pRgnElem )	// Find near revival pos
				pRgnElem	= g_WorldMng.GetNearRevivalPosChao( pWorld->GetID(), GetPos() );

			if( pRgnElem )
				REPLACE( g_uIdofMulti, pRgnElem->m_dwWorldId, pRgnElem->m_vPos, REPLACE_NORMAL, nRevivalLayer );
		}
		else
#endif // __VER >= 8 // __S8_PK
		{
			REPLACE( g_uIdofMulti, pItemProp->dwWeaponType, vPos, REPLACE_NORMAL, nTempLayer );
		}
	}
#endif // worldserver
	return TRUE;
}

int	CMover::DoUseItemSystem( ItemProp *pItemProp, CItemElem* pItemElem, int nPart )
{
	int nResult = 0;
#ifdef __WORLDSERVER
#ifdef __AZRIA_1023
	if( IsPlayer() )
	{
		CUser* pThis	= static_cast<CUser*>( this );
		if( pThis->HasInput() )
			return pThis->DoUseItemInput( pItemProp, pItemElem );
	}
#endif	// __AZRIA_1023

#ifdef __GAMEGUARD
	CUser* pUser = ((CUser*)this);
	if (IsInvalidObj(pUser))
		return 0;
#endif // __GAMEGUARD

	switch( pItemProp->dwID )
	{
	case II_CHR_SYS_SCR_RESTATE:
		{
			if( m_nInt == 15 && m_nSta == 15 && m_nStr == 15 && m_nDex == 15 )
			{
				((CUser*)this)->AddDefinedText( TID_GAME_DONOTUSE_RESTATE );
				nResult = 1;
			}
			else
				ReState();
		}
		break;
#ifdef __S_ADD_RESTATE
	case II_CHR_SYS_SCR_RESTATE_STR:
		{
			if( m_nStr == 15 )
			{
				((CUser*)this)->AddDefinedText( TID_GAME_DONOTUSE_RESTATE );			
				nResult = 1;
			}
			else
				ReStateOne( 0 );
		}
		break;
	case II_CHR_SYS_SCR_RESTATE_STA:
		{
			if( m_nSta == 15 )
			{
				((CUser*)this)->AddDefinedText( TID_GAME_DONOTUSE_RESTATE );			
				nResult = 1;
			}
			else
				ReStateOne( 1 );
		}
		break;
	case II_CHR_SYS_SCR_RESTATE_DEX:
		{
			if( m_nDex == 15 )
			{
				((CUser*)this)->AddDefinedText( TID_GAME_DONOTUSE_RESTATE );			
				nResult = 1;
			}
			else
				ReStateOne( 2 );
		}
		break;
	case II_CHR_SYS_SCR_RESTATE_INT:
		{
			if( m_nInt == 15 )
			{
				((CUser*)this)->AddDefinedText( TID_GAME_DONOTUSE_RESTATE );			
				nResult = 1;
			}
			else
				ReStateOne( 3 );
		}
		break;
#endif // __S_ADD_RESTATE
#ifdef __BUFF_SERVER
	case II_SYS_SYS_BUFF_SERVER_STREN:
	case II_SYS_SYS_BUFF_SERVER_DEXTE:
	case II_SYS_SYS_BUFF_SERVER_INTEL:
	case II_SYS_SYS_BUFF_SERVER_STAMI:
	case II_SYS_SYS_BUFF_SERVER_DEFEN:
	case II_SYS_SYS_BUFF_SERVER_ATPOW:
	case II_SYS_SYS_BUFF_SERVER_HPMAX:
	case II_SYS_SYS_BUFF_SERVER_MPMAX:
	case II_SYS_SYS_BUFF_SERVER_FPMAX:
	case II_SYS_SYS_BUFF_SERVER_SPEED:
	case II_SYS_SYS_BUFF_SERVER_SPELL:
	case II_SYS_SYS_BUFF_SERVER_CRITI:
	case II_SYS_SYS_BUFF_SERVER_ADOCH:
	case II_SYS_SYS_BUFF_SERVER_SPATK:
	case II_SYS_SYS_BUFF_SERVER_CITOYEN:
	{
		CString str;

		g_UserMng.LaunchSrvBuff(pItemProp->dwID);
	}
	break;
#endif // __BUFF_SERVER
	case II_CHR_SYS_SCR_TRANSY:
		{
			if( DoUseItemSexChange( nPart ) == FALSE )
			{
				nResult = 1;
			}
			else
			{
				if( HasBuffByIk3( IK3_TEXT_DISGUISE ) )
					RemoveIk3Buffs( IK3_TEXT_DISGUISE );
			}
		}
		break;
#if __VER >= 9	// __PET_0410
	case II_SYS_SYS_SCR_PET_LIFE:
	case II_SYS_SYS_SCR_PET_LIFE02:
		{
			CPet* pPet	= GetPet();
			if( pPet == NULL )
			{
				( (CUser*)this )->AddDefinedText( TID_GAME_PET_NOT_FOUND );
				nResult	= 1;
				break;
			}

			if( pPet->GetLevel() == PL_EGG )
			{
				( (CUser*)this )->AddDefinedText( TID_GAME_PET_CANT_USE_TO_EGG );
				nResult	= 1;
				break;
			}
			
			if( pPet->GetLife() >= MAX_PET_LIFE )
			{
				nResult	= 1;
				break;
			}

			WORD wLife	= pPet->GetLife();
			wLife	+= ( pItemProp->dwID == II_SYS_SYS_SCR_PET_LIFE? CPetProperty::GetInstance()->GetAddLife(): 1 );

			pPet->SetLife( wLife > MAX_PET_LIFE? MAX_PET_LIFE: wLife );
				
			CItemElem* pItemElem	= GetPetItem();
			( (CUser*)this )->AddPetState( pItemElem->m_dwObjId, pPet->GetLife(), pPet->GetEnergy(), pPet->GetExp() );
			g_dpDBClient.CalluspPetLog( m_idPlayer, pItemElem->GetSerialNumber(), wLife, PETLOGTYPE_LIFE, pPet );
			break;
		}
	case II_SYS_SYS_SCR_PET_HATCH:
		{
			CPet* pPet	= GetPet();
			if( pPet == NULL )
			{
				( (CUser*)this )->AddDefinedText( TID_GAME_PET_NOT_FOUND );
				nResult	= 1;
				break;
			}
			if( pPet->GetLevel() != PL_EGG )
			{
				( (CUser*)this )->AddDefinedText( TID_GAME_PET_4EGG );
				nResult	= 1;
				break;
			}
			PetLevelup();
			break;
		}
#endif	// __PET_0410
#if __VER >= 11 // __SYS_COLLECTING
	case II_GEN_TOO_COL_NORMALBATTERY:
		{
			CUser* pThis	= (CUser*)this;
			if( !pThis->DoUseItemBattery() )
			{
				pThis->AddDefinedText( TID_GAME_CANT_USE_BATTERY );
				nResult	= 1;
			}
			break;
		}
#endif	// __SYS_COLLECTING
	case II_CHR_SYS_SCR_SHOUTFULL15:
		{
			if( !IsShoutFull() )
				SetSMMode( SM_SHOUT15, pItemProp->dwCircleTime );
			else
				nResult = 2;
		}
		break;
	case II_CHR_SYS_SCR_SHOUTFULL30:
		{
			if( !IsShoutFull() )
				SetSMMode( SM_SHOUT30, pItemProp->dwCircleTime );
			else
				nResult = 2;
		}
		break;
	case II_CHR_SYS_SCR_SHOUTFULL001:
		{
			if( !IsShoutFull() )
				SetSMMode( SM_SHOUT001, pItemProp->dwCircleTime );
			else
				nResult = 2;
		}
		break;
#ifdef __SYS_SCR_PARTYSPEEDLEVELUP
	case II_SYS_SYS_SCR_PARTYSPEEDLEVELUP01: 
	{ 
		CParty* pParty = g_PartyMng.GetParty( GetPartyId() ); 
		if(pParty && pParty->IsLeader( ((CUser*)this)->m_idPlayer ) ) 
			pParty->SetPartyLevel(((CUser*)this),40,pParty->GetPoint()+400,pParty->GetExp()); 
		else 
		{ 
			((CUser*)this)->AddText("This scroll can only be used by the party leader."); 
			nResult=2; 
		} 
	}
	break;
#endif
	case II_CHR_SYS_SCR_PSKILLFULL1:
		{
			if( !( IsSMMode( SM_PARTYSKILL1 ) || IsSMMode( SM_PARTYSKILL15 ) || IsSMMode( SM_PARTYSKILL30 ) ) )
#if __VER >= 12 // __PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
			{
				SetSMMode( SM_PARTYSKILL1, pItemProp->dwCircleTime );
				g_DPCoreClient.SendUserPartySkill( m_idPlayer, PARTY_PARSKILL_MODE, 1000, 0, 1 );
			}
#else	//__PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
				SetSMMode( SM_PARTYSKILL1, pItemProp->dwCircleTime );
#endif //__PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
			else
				nResult = 2;
		}
		break;
	case II_CHR_SYS_SCR_PSKILLFULL15:
		{
			if( !( IsSMMode( SM_PARTYSKILL1 ) || IsSMMode( SM_PARTYSKILL15 ) || IsSMMode( SM_PARTYSKILL30 ) ) )
#if __VER >= 12 // __PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
			{
				SetSMMode( SM_PARTYSKILL15, pItemProp->dwCircleTime );
				g_DPCoreClient.SendUserPartySkill( m_idPlayer, PARTY_PARSKILL_MODE, 1000, 0, 1 );
			}
#else	//__PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
				SetSMMode( SM_PARTYSKILL15, pItemProp->dwCircleTime );
#endif //__PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
			else
				nResult = 2;
		}
		break;
	case II_CHR_SYS_SCR_PSKILLFULL30:
		{
			if( !( IsSMMode( SM_PARTYSKILL1 ) || IsSMMode( SM_PARTYSKILL15 ) || IsSMMode( SM_PARTYSKILL30 ) ) )
#if __VER >= 12 // __PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
			{
				SetSMMode( SM_PARTYSKILL30, pItemProp->dwCircleTime );
				g_DPCoreClient.SendUserPartySkill( m_idPlayer, PARTY_PARSKILL_MODE, 1000, 0, 1 );
			}
#else	//__PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
				SetSMMode( SM_PARTYSKILL30, pItemProp->dwCircleTime );
#endif //__PARSKILL1001	//12Â÷ ÆÄ½ºÅ³ ¾ÆÀÌÅÛ ¼öÁ¤  world,core,neuz
			else
				nResult = 2;
		}
		break;
	case II_CHR_SYS_SCR_COMMBANK15:
		{
			if( !IsCommBank() )
				SetSMMode( SM_BANK15, pItemProp->dwCircleTime );
			else
				nResult = 2;
		}
		break;
	case II_CHR_SYS_SCR_COMMBANK30:
		{
			if( !IsCommBank() )
				SetSMMode( SM_BANK30, pItemProp->dwCircleTime );
			else
				nResult = 2;
		}
		break;
	case II_CHR_SYS_SCR_COMMBANK001:
		{
			if( !IsCommBank() )
				SetSMMode( SM_BANK001, pItemProp->dwCircleTime );
			else
				nResult = 2;
		}
		break;
	case II_CHR_SYS_SCR_ACTIVITION:
		{
			if( !( IsSMMode( SM_ACTPOINT ) ) )
				SetSMMode( SM_ACTPOINT, pItemProp->dwCircleTime );
			else
				nResult = 2;
		}
		break;
#ifdef __SYS_SCR_NEWACTIVITION
	case II_CHR_SYS_SCR_NEWACTIVITION:
	{
		if (!(IsSMMode(SM_NEWACTPOINT)))
			SetSMMode(SM_NEWACTPOINT, pItemProp->dwCircleTime);
		else
			nResult = 2;
	}
	break;
#endif
	case II_CHR_SYS_SCR_UPCUTSTONE01:
		{
			if( !( IsSMMode( SM_ATTACK_UP1 ) || IsSMMode( SM_ATTACK_UP ) ) )
				SetSMMode( SM_ATTACK_UP1, pItemProp->dwCircleTime );
			else
				nResult = 2;
		}
		break;
	case II_CHR_SYS_SCR_UPCUTSTONE:
		{
			if( !( IsSMMode( SM_ATTACK_UP1 ) || IsSMMode( SM_ATTACK_UP ) ) )
			{
				SetSMMode( SM_ATTACK_UP, pItemProp->dwCircleTime );
			}
			else
				nResult = 2;
		}
		break;
#if __VER < 8 // __S8_PK
	case II_SYS_SYS_SCR_FORGIVE:
		if( IsPlayer() )
		{
			if( IsChaotic() )
			{
				UpgradeKarma();
				((CUser*)this)->AddDefinedText( TID_GAME_GETKARMA );	// Ä«¸£¸¶°¡ 1´Ü°è È¸º¹µÇ¾ú½À´Ï´Ù						
			}
			else
			{
				// Ä«¿ÀÆ½ ÇÃ·¹ÀÌ¾îÀÇ °æ¿ì¸¸ »ç¿ë ÇÒ ¼ö ÀÖ½À´Ï´Ù.
				((CUser*)this)->AddDefinedText( TID_GAME_NOTCHOAS );
				nResult = 1;		// 1 - ¾ÆÀÌÅÛÀÌ »ç¿ë¾ÈµÇ°Ô ÇÑ´Ù.
			}
		}
		break;
#endif // __VER < 8 // __S8_PK
	case II_SYS_SYS_SCR_BLESSING:
		{
			if( !( IsSMMode( SM_REVIVAL ) ) )
				SetSMMode( SM_REVIVAL, pItemProp->dwCircleTime );
			else
				nResult = 2;					
		}
		break;
	case II_SYS_SYS_SCR_SELPAR:
		{
			CParty* pParty;
			pParty = g_PartyMng.GetParty( GetPartyId() );
			if( pParty )
			{
				if( pParty->m_nLevel < MAX_PARTYLEVEL )	// ´Ü¸·±Ø´ÜÀÏ¶§¸¸ »ç¿ë°¡´É
					pParty->SetPartyLevel( ((CUser*)this), 10, 180, 0 );
				else
					nResult = 1;
			}
			else
			{
				nResult = 1;
			}
			if( nResult == 1 )
				((CUser*)this)->AddDefinedText( TID_GAME_NTROUPEO10, "" );
		}
		break;
	case II_SYS_SYS_SCR_HOLY:
		RemoveDebufBuffs();
		break;
	case II_SYS_SYS_SCR_VELOCIJUMP:
		{
			if( !( IsSMMode( SM_VELOCIJUMP ) ) )
			{
				if( pItemProp->dwDestParam1 != -1 )
					SetDestParam( pItemProp->dwDestParam1, pItemProp->nAdjParamVal1, pItemProp->nAdjParamVal1 );
				if( pItemProp->dwDestParam2 != -1 )
					SetDestParam( pItemProp->dwDestParam2, pItemProp->nAdjParamVal2, pItemProp->nAdjParamVal2 );
				SetSMMode( SM_VELOCIJUMP, pItemProp->dwCircleTime );
			}
			else
			{
				nResult = 2;	
			}
		}
		break;
	case II_SYS_SYS_SCR_RECCURENCE:
		{
			if( InitSkillExp() )
				((CUser*)this)->AddInitSkill();
			else
				nResult = 1;
		}
		break;
#ifndef __NEW_STACKABLE_AMPS
	case II_SYS_SYS_SCR_AMPES:	// "ESÁõÆøÀÇ µÎ·ç¸¶¸®"		
		{
			// ES, EMÀº µ¿ÀÏ¾È ¾ÆÀÌÅÛ.. I´Â °°ÀÌ »ç¿ëÇÒ¼ö ¾÷½À´Ï´Ù.
			if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPES ) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPEM ) ||
				HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESA ) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESA1) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESA2) ||
				HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESB ) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESB1) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESB2) ||
				HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESC ) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESC1) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESC2) || 
				HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESD ) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESD1) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESD2) ||
#ifdef __S_ADD_EXP
				HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESS ) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESS1) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESS2) ||
#endif // __S_ADD_EXP
				HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESE )
				)
				nResult = 2;
			else if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPI ) )
				nResult = 3;
			else
				DoApplySkill( (CCtrl*)this, pItemProp, NULL );
		}
		break;
	case II_SYS_SYS_SCR_AMPESA:
	case II_SYS_SYS_SCR_AMPESB:
	case II_SYS_SYS_SCR_AMPESC:
	case II_SYS_SYS_SCR_AMPESD:
	case II_SYS_SYS_SCR_AMPESE:
#ifdef __S_ADD_EXP
	case II_SYS_SYS_SCR_AMPESS:
#endif // __S_ADD_EXP
		{
			if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPES ) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPEM ) )
				nResult = 2;
			else if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPI ) )
				nResult = 3;

			// ·¹º§ °Ë»ç
			int nLevel = GetLevel();

			CString str;
			if( pItemProp->dwID == II_SYS_SYS_SCR_AMPESA )
			{
				if( 20 < nLevel )
				{
					str.Format( "%d - %d", 1, 20 );
					((CUser*)this)->AddDefinedText( TID_GAME_EXP_NOTUSELEVEL, "\"%s\"", str ); // 
					nResult = 99;
				}
			}
			else if( pItemProp->dwID == II_SYS_SYS_SCR_AMPESB )
			{
				if( nLevel < 21 || 40 < nLevel )
				{
					str.Format( "%d - %d", 21, 40 );
					((CUser*)this)->AddDefinedText( TID_GAME_EXP_NOTUSELEVEL, "\"%s\"", str ); // 
					nResult = 99;
				}
			}
			else if( pItemProp->dwID == II_SYS_SYS_SCR_AMPESC )
			{
				if( nLevel < 41 || 60 < nLevel )
				{
					str.Format( "%d - %d", 41, 60 );
					((CUser*)this)->AddDefinedText( TID_GAME_EXP_NOTUSELEVEL, "\"%s\"", str ); // 
					nResult = 99;
				}
			}
			else if( pItemProp->dwID == II_SYS_SYS_SCR_AMPESD )
			{
				if( nLevel < 61 || 80 < nLevel )
				{
					str.Format( "%d - %d", 61, 80 );
					((CUser*)this)->AddDefinedText( TID_GAME_EXP_NOTUSELEVEL, "\"%s\"", str ); // 
					nResult = 99;
				}
			}
			else if( pItemProp->dwID == II_SYS_SYS_SCR_AMPESE )
			{
				if( nLevel < 81 || 120 < nLevel )
				{
					str.Format( "%d - %d", 81, 120 );
					((CUser*)this)->AddDefinedText( TID_GAME_EXP_NOTUSELEVEL, "\"%s\"", str ); // 
					nResult = 99;
				}
			}

			if( !(nResult == 2 || nResult == 3 || nResult == 99 ) )
			{
				BOOL bBuf[3];
				int nBufCount = 0;
				BOOL bSpecial = FALSE;
				int nSpecialCount = 0;

				ZeroMemory( bBuf, sizeof( bBuf ) );
				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESA ) )
				{
					bBuf[0] = TRUE;		++nBufCount;
				}
				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESA1 ) )
				{
					bBuf[1] = TRUE;		++nBufCount;
				}
				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESA2 ) )
				{
					bBuf[2] = TRUE;		++nBufCount;
				}

				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESB ) )
				{
					bBuf[0] = TRUE;		++nBufCount;
				}
				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESB1 ) )
				{
					bBuf[1] = TRUE;		++nBufCount;
				}
				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESB2 ) )
				{
					bBuf[2] = TRUE;		++nBufCount;
				}

				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESC ) )
				{
					bBuf[0] = TRUE;		++nBufCount;
				}
				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESC1 ) )
				{
					bBuf[1] = TRUE;		++nBufCount;
				}
				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESC2 ) )
				{
					bBuf[2] = TRUE;		++nBufCount;
				}
				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESD ) )
				{
					bBuf[0] = TRUE;		++nBufCount;
				}
				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESD1 ) )
				{
					bBuf[1] = TRUE;		++nBufCount;
				}
				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESD2 ) )
				{
					bBuf[2] = TRUE;		++nBufCount;
				}
				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESE ) )
				{
					bBuf[0] = TRUE;		++nBufCount;
				}
#ifdef __S_ADD_EXP
				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESS ) )
				{
					bBuf[0] = TRUE;		++nBufCount;	nSpecialCount++;//bSpecial = TRUE;
				}
				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESS1 ) )
				{
					bBuf[1] = TRUE;		++nBufCount;	nSpecialCount++;//bSpecial = TRUE;
				}
				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESS2 ) )
				{
					bBuf[2] = TRUE;		++nBufCount;	nSpecialCount++;//bSpecial = TRUE;
				}
#endif // __S_ADD_EXP

				int nMaxBuf = 3;
				//if( bSpecial == FALSE )
				{				
					if( nLevel < 41 )
						nMaxBuf = 3;				
					else if( nLevel < 61 && nSpecialCount < 2 )
						nMaxBuf = 2;
					else if( nLevel <= 120 && nSpecialCount < 1 )
						nMaxBuf = 1;
					else
						nMaxBuf = 3;
				}

#ifdef __S_ADD_EXP
				//if( bSpecial && pItemProp->dwID != II_SYS_SYS_SCR_AMPESS )
				if( nSpecialCount && pItemProp->dwID != II_SYS_SYS_SCR_AMPESS )
				{
					nResult = 2;					
				}
				else
#endif // __S_ADD_EXP
				if( nBufCount < nMaxBuf )
				{
					for( int i = 0 ; i < nMaxBuf ; ++i )
					{
						if( bBuf[i] == FALSE )
						{
							if( i == 0 )
								pItemProp = prj.GetItemProp( pItemProp->dwID );
							else if( i == 1 )
								pItemProp = prj.GetItemProp( pItemProp->dwID + 1 );
							else 
								pItemProp = prj.GetItemProp( pItemProp->dwID + 2 );	
							break;
						}							
					}

					DoApplySkill( (CCtrl*)this, pItemProp, NULL );
					float fFactor = 1;
					switch( nBufCount + 1)
					{
					case 1:
						{
							fFactor *= 1.5f;
						}
						break;
					case 2:
						{
							//if( bSpecial || nLevel < 61 )
							if( nSpecialCount || nLevel < 61 )
								fFactor *= 2.0f;
							else
								fFactor *= 1.5f;
						}
						break;
					case 3:
						{
							//if( bSpecial || nLevel < 41 )
							if( nSpecialCount || nLevel < 41 )
								fFactor *= 2.5f;
							else if( nLevel < 61 )
								fFactor *= 2.0f;
							else
								fFactor *= 1.5f;
						}
						break;
					}
					CString strTemp;
#if __VER >= 11 // __EXPITEM_TOOLTIP_CHANGE
					int nPercent = (int)( (fFactor - 1.0f) * 100.0f );
					strTemp.Format( "%s %d%% %s", prj.GetText( TID_GAME_EXPITEM_TOOLTIP ), nPercent, prj.GetText( TID_GAME_EXPITEM_TOOLTIP1 ) );
#else //__EXPITEM_TOOLTIP_CHANGE
					strTemp.Format( "%s%.1f%s", prj.GetText( TID_GAME_EXPTOOLTIP ), fFactor, prj.GetText( TID_GAME_EXPTOOLTIP1 ) );
#endif //__EXPITEM_TOOLTIP_CHANGE
					((CUser*)this)->AddText( strTemp ); // 
				}
				else
				{
#ifdef __S_ADD_EXP
					//if( bSpecial )
					//{
					//	((CUser*)this)->AddDefinedText( TID_GAME_EXP_3 ); //
					//}
//					else
#endif // __S_ADD_EXP
					{
						if( nLevel < 21 )
							str.Format( "%d - %d", 1, 20 );
						else if( nLevel < 41 )
							str.Format( "%d - %d", 21, 40 );
						else if( nLevel < 61 )
							str.Format( "%d - %d", 41, 60 );
						else if( nLevel < 81 )
							str.Format( "%d - %d", 61, 80 );
						else if( nLevel <= 120 )
							str.Format( "%d - %d", 81, 120 );

						CString szMaxBuf;
						szMaxBuf.Format( "%d", nMaxBuf );
						((CUser*)this)->AddDefinedText( TID_GAME_EXP_NOTUSE, "\"%s\" \"%s\"", str, szMaxBuf ); // 
					}
					nResult = 99;					
				}				
			}
		}
		break;
	case II_SYS_SYS_SCR_AMPEM:	// "EMÁõÆøÀÇ µÎ·ç¸¶¸®"		
		{
			// ES, EMÀº µ¿ÀÏ¾È ¾ÆÀÌÅÛ.. I´Â °°ÀÌ »ç¿ëÇÒ¼ö ¾÷½À´Ï´Ù.
			if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPES ) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPEM ) ||
				HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESA ) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESA1) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESA2) ||
				HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESB ) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESB1) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESB2) ||
				HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESC ) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESC1) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESC2) || 
				HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESD ) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESD1) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESD2) ||
#ifdef __S_ADD_EXP
				HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESS ) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESS1) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESS2) ||
#endif // __S_ADD_EXP
				HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPESE ) 
				)
				nResult = 2;
			else if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_AMPI ) )
				nResult = 3;
			else
				DoApplySkill( (CCtrl*)this, pItemProp, NULL );
		}
		break;
#endif // __NEW_STACKABLE_AMPS
#ifdef __Y_BEAUTY_SHOP_CHARGE
	case II_SYS_SYS_SCR_BEAUTYSHOP: // "Beauty Shop Charge"		
		{
		}
		break;
#endif // __Y_BEAUTY_SHOP_CHARGE
	case II_SYS_SYS_SCR_GLVCHEER:	// ÀÀ¿øÀÇ Èò Àå°©
	case II_SYS_SYS_SCR_SMELPROT:	// "º¸È£ÀÇ µÎ·ç¸¶¸®"		
#ifdef __SM_ITEM_2ND_EX
	case II_SYS_SYS_SCR_SMELPROT2:
#endif	// __SM_ITEM_2ND_EX
#if __VER >= 9 // __ULTIMATE
	case II_SYS_SYS_SCR_SMELPROT3: // " º¸È£ÀÇ µÎ·ç¸¶¸®(ÃÖ»ó±Þ)
#endif // __ULTIMATE
#if __VER >= 11 // __SYS_COLLECTING
	case II_SYS_SYS_SCR_SMELPROT4:	// ¾Ç¼¼»ç¸® º¸È£ÀÇ µÎ·ç¸¶¸®
#endif	// __SYS_COLLECTING
	case II_SYS_SYS_SCR_SMELTING:	// "Á¦·ÃÀÇ µÎ·ç¸¶¸®"	
	case II_SYS_SYS_SCR_SUPERLEADERPARTY:	// "´ÜÀåÀÇ Ãàº¹"		
	case II_SYS_SYS_SCR_SUPERSMELTING:	// "Á¦·Ã µÎ·ç¸¶¸®(Áø)"
	case II_SYS_SYS_SCR_FONTEDIT:	// "Font Edit"		
#ifdef __Y_BEAUTY_SHOP_CHARGE
	case II_SYS_SYS_SCR_VENDOR:	// "Vendor Charge"		
#endif //__Y_BEAUTY_SHOP_CHARGE
	case II_SYS_SYS_SCR_SKLINSTRUCT:	// "±â¼úÀÇ Àü¼öÀÚ"
#if __VER >= 14 // __EXT_ATTRIBUTE
	case II_SYS_SYS_SCR_SMELTING2:	// ¼Ó¼º Á¦·ÃÀÇ µÎ·ç¸¶¸®
#endif // __EXT_ATTRIBUTE
#ifdef __SYS_SCR_NOR_SMELTING01
	case II_SYS_SYS_SCR_NOR_SMELTING01:
#endif
#ifdef __SYS_SCR_NOR_SMELTING02
	case II_SYS_SYS_SCR_NOR_SMELTING02:
#endif
#ifdef __SYS_SCR_NOR_SMELTING03
	case II_SYS_SYS_SCR_NOR_SMELTING03:
#endif
		{
			if( HasBuff( BUFF_ITEM, (WORD)( pItemProp->dwID ) ) )
				nResult = 2;
			else
				DoApplySkill( (CCtrl*)this, pItemProp, NULL );
		}
		break;
		//	mulcom	BEGIN100405	°¢¼º º¸È£ÀÇ µÎ·ç¸¶¸®
#ifdef	__PROTECT_AWAKE
	case	II_SYS_SYS_SCR_AWAKESAFE:
		{
			if( HasBuff( BUFF_ITEM, (WORD)( pItemProp->dwID ) ) )
			{
				nResult = 2;
			}
			else
			{
				DoApplySkill( (CCtrl*)this, pItemProp, NULL );
			}
		}
		break;
#endif	//__PROTECT_AWAKE
		//	mulcom	END100405	°¢¼º º¸È£ÀÇ µÎ·ç¸¶¸®


#if __VER >= 9	// __PET_0410
	case II_SYS_SYS_SCR_PET_TONIC_A:
	case II_SYS_SYS_SCR_PET_TONIC_B:
#if __VER >= 12 // __PET_0519
		nResult		= DoUseItemPetTonic( pItemElem );	// Æê ¿µ¾çÁ¦ »ç¿ë
		break;
#else	// __PET_0519
		if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_PET_TONIC_A ) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_PET_TONIC_B ) )
			nResult = 2;
		else
			DoApplySkill( (CCtrl*)this, pItemProp, NULL );
		break;
#endif	// __PET_0519
	case II_SYS_SYS_SCR_PET_FEED_POCKET:
		{
			nResult = DoUseItemFeedPocket( pItemElem );
			break;
		}
#endif	// __PET_0410
#ifdef __EVE_BALLOON
#if __VER < 14 // __BALLOON_CODE_IMPROVEMENT
	case II_SYS_SYS_EVE_BALLOON:
	case II_SYS_SYS_EVE_BALLOON01:
	case II_SYS_SYS_EVE_BALLOON02:
	case II_SYS_SYS_EVE_BALLOON_01:
	case II_SYS_SYS_EVE_BALLOON01_01:
	case II_SYS_SYS_EVE_BALLOON02_01:
		{
			if( HasBuff( BUFF_ITEM, II_SYS_SYS_EVE_BALLOON )
				|| HasBuff( BUFF_ITEM, II_SYS_SYS_EVE_BALLOON01 )
				|| HasBuff( BUFF_ITEM, II_SYS_SYS_EVE_BALLOON02 )
				|| HasBuff( BUFF_ITEM, II_SYS_SYS_EVE_BALLOON_01 )
				|| HasBuff( BUFF_ITEM, II_SYS_SYS_EVE_BALLOON01_01 )
				|| HasBuff( BUFF_ITEM, II_SYS_SYS_EVE_BALLOON02_01 )
			)
				nResult = 2;
			else
				DoApplySkill( (CCtrl*)this, pItemProp, NULL );
		}
		break;
#endif // __BALLOON_CODE_IMPROVEMENT
#endif //__EVE_BALLOON
#if __VER >= 9 // __II_SYS_SYS_SCR_GET
	case II_SYS_SYS_SCR_GET01:
	case II_SYS_SYS_SCR_GET02:
		{
			if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_GET01 ) ||
				HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_GET02 ) )
				nResult = 2;
			else
				DoApplySkill( (CCtrl*)this, pItemProp, NULL );
		}
		break;
#endif // __II_SYS_SYS_SCR_GET
	case II_SYS_SYS_SCR_RETURN:		// "±ÍÈ¯ÀÇ µÎ·ç¸¶¸®"		
		{
			if( IsPlayer() )
			{
				if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_RETURN ) )
					nResult = 2;
				else
				{
					CWorld* pWorld	= GetWorld();
					if( !pWorld )
						return 0;

					D3DXVECTOR3 vPos = GetPos();
					//Å¬¶ô¿öÅ© µ¼/ ÄÉ¹Ù¶ó½º¿¡¼­´Â ÀÌ ¾ÆÀÌÅÛÀ» »ç¿ëÇÒ ¼ö ¾øÀ¸¸ç ¸¸¾à »ç¿ëÇÏ·Á ½Ãµµ ½Ã 'ÀÌ Áö¿ªÀº Á¦ÇÑ Áö¿ªÀÌ¹Ç·Î ¾ÆÀÌÅÛÀ» »ç¿ëÇÒ ¼ö ¾ø½À´Ï´Ù.'¶ó´Â ¸Þ½ÃÁö¸¦ Ãâ·ÂÇÑ´Ù
					if( pWorld->GetID() == WI_WORLD_GUILDWAR || pWorld->GetID() == WI_WORLD_KEBARAS || prj.IsGuildQuestRegion( vPos ) )
					{			
						((CUser*) this)->AddDefinedText( TID_GAME_LIMITZONE_USE );
						return 0;
					}

#if __VER >= 11 // __GUILD_COMBAT_1TO1
					if( g_GuildCombat1to1Mng.IsPossibleUser( (CUser*)this ) )
					{
						((CUser*) this)->AddDefinedText( TID_GAME_LIMITZONE_USE );
						return 0;
					}
#endif // __GUILD_COMBAT_1TO1

					((CUser*) this)->SetReturnPos( vPos );

					//1.±ÍÈ¯¸ðµå·Î ¼³Á¤ 
					DoApplySkill( (CCtrl*)this, pItemProp, NULL );
					//2. ¼±ÅÃµÈ ¸¶À»·Î ÀÌµ¿ 
					LPCTSTR lpszKey = ((CUser*)this)->m_lpszVillage;
					if( lpszKey )
					{
						PRegionElem pRgnElem = g_WorldMng.GetRevivalPos( GetWorld()->GetID(), lpszKey );
						if( pRgnElem )
							REPLACE( g_uIdofMulti, pRgnElem->m_dwWorldId, pRgnElem->m_vPos, REPLACE_NORMAL, nRevivalLayer );
					}
					else
					{
						Error( "II_SYS_SYS_SCR_RETURN selected village is NULL\n" );
					}
				}
			}
		}
		break;
	case II_SYS_SYS_SCR_CUSTODY2:
		{
			CMover* pMover	= (CMover*)CreateObj( D3DDEVICE, OT_MOVER, MI_INFO_PENG );
			lstrcpy( pMover->m_szCharacterKey, "MaFl_InstantBank" );
			pMover->InitNPCProperty();
			pMover->InitCharacter( pMover->GetCharacter() );
			pMover->SetPos( GetPos() );
			pMover->InitMotion( MTI_STAND );
			pMover->UpdateLocalMatrix();
			pMover->m_dwTickCreated		= GetTickCount();
			GetWorld()->ADDOBJ( pMover, TRUE, GetLayer() );
			break;
		}
	
	case II_SYS_SYS_SCR_FRIENDSUMMON_A:
	case II_SYS_SYS_SCR_FRIENDSUMMON_B:
		{
			int nState = GetSummonState();
			if( nState != 0 )
			{
				DWORD dwMsgId = 0;
				if( nState == 1 )	// °Å·¡Áß
					dwMsgId = TID_GAME_TRADE_NOTUSE;
				else if( nState == 2 ) // Á×À½
					dwMsgId = TID_GAME_DIE_NOTUSE;
				else if( nState == 3 ) // °³ÀÎ»óÁ¡ Áß
					dwMsgId = TID_GAME_VENDOR_NOTUSE;
				else if( nState == 4 ) // ÀüÅõÁß
					dwMsgId = TID_GAME_ATTACK_NOTUSE;
				else if( nState == 5 ) // ºñÇàÁß
					dwMsgId = TID_GAME_FLY_NOTUSE;
				
				((CUser*) this)->AddDefinedText( TID_GAME_STATE_NOTUSE , "\"%s\"", prj.GetText( dwMsgId ) );
			}
#if __VER >= 11 // __GUILD_COMBAT_1TO1
			else if( g_GuildCombat1to1Mng.IsPossibleUser( (CUser*)this ) )
			{
				((CUser*) this)->AddDefinedText( TID_GAME_STATE_NOTUSE , "\"%s\"", prj.GetText( TID_GAME_ATTACK_NOTUSE ) );
			}
#endif // __GUILD_COMBAT_1TO1
			else
			{
				((CUser*) this)->AddSummonFriendUse( pItemElem );	
			}
			nResult = 99;
		}
		break;

#if __VER >= 11 // __MA_VER11_02	// ¼öÇ¥ °³³ä È­Æä 'Æä¸°' Ãß°¡
	case II_SYS_SYS_SCR_PERIN:
		{
			int nState = GetSummonState();
			if( nState != 0 )
			{
				DWORD dwMsgId = 0;
				if( nState == 1 )	// °Å·¡Áß
					dwMsgId = TID_GAME_TRADE_NOTUSE;
				else if( nState == 2 ) // Á×À½
					dwMsgId = TID_GAME_DIE_NOTUSE;
				else if( nState == 3 ) // °³ÀÎ»óÁ¡ Áß
					dwMsgId = TID_GAME_VENDOR_NOTUSE;
				else if( nState == 4 ) // ÀüÅõÁß
					dwMsgId = TID_GAME_ATTACK_NOTUSE;
				else if( nState == 5 ) // ºñÇàÁß
					dwMsgId = TID_GAME_FLY_NOTUSE;
				
				((CUser*) this)->AddDefinedText( TID_GAME_STATE_NOTUSE , "\"%s\"", prj.GetText( dwMsgId ) );
				nResult = 99;
			}
			else
			{
				float	fTmpGold = (float)( ((CUser*) this)->GetGold() );
				if( fTmpGold >= 2000000000 || fTmpGold < 0  )
				{
					((CUser*) this)->AddDiagText( prj.GetText(TID_GAME_TOOMANYMONEY_USE_PERIN) );
					return 99;
				}
				else
				{
#ifdef __AUTO_PERIN_CONVERTER
					if (IsMode(AUTO_CONVERT_MODE))
					{
						CUser* pUser = (CUser*)this;
						pUser->SetNotMode(AUTO_CONVERT_MODE);
						pUser->AddText(prj.GetText(TID_AUTO_CONVERTER_OFF), 0xFFFF0000);
						g_UserMng.AddModifyMode(pUser);
					}
#endif // __AUTO_PERIN_CONVERTER
					((CUser*) this)->AddGold(100000000,true);
#ifdef __DROP_LOG
					((CUser*)this)->AddGoldText(100000000);
#endif // __DROP_LOG
					// chipi080711 - Æä¸°»ç¿ë ·Î±×
					LogItemInfo aLogItem;
					aLogItem.Action = "C";
					aLogItem.SendName = ((CUser*) this)->GetName();
					aLogItem.RecvName = "USE_PERIN";
					aLogItem.WorldId = ((CUser*) this)->GetWorld()->GetID();
					aLogItem.Gold = (DWORD)( fTmpGold );
					aLogItem.Gold2 = ((CUser*) this)->GetGold();
					aLogItem.Gold_1  = ((CUser*) this)->GetGold() - static_cast<int>(fTmpGold);
					//aLogItem.ItemName = pItemElem->GetName();
					_stprintf( aLogItem.szItemName, "%d", pItemProp->dwID );
					aLogItem.itemNumber = 1;
					aLogItem.ItemNo = pItemElem->GetSerialNumber();
					g_DPSrvr.OnLogItem( aLogItem );
				}
			}
		}
		break;
#endif	// __MA_VER11_02
#ifdef __ADD_RESTATE_LOW
	case II_CHR_SYS_SCR_RESTATE_STR_LOW:
		{
			if( m_nStr == 15 )
			{
				((CUser*)this)->AddDefinedText( TID_GAME_DONOTUSE_RESTATE );			
				nResult = 1;
			}
			else
				ReStateOneLow( 0 );
		}
		break;
	case II_CHR_SYS_SCR_RESTATE_STA_LOW:
		{
			if( m_nSta == 15 )
			{
				((CUser*)this)->AddDefinedText( TID_GAME_DONOTUSE_RESTATE );			
				nResult = 1;
			}
			else
				ReStateOneLow( 1 );
		}
		break;
	case II_CHR_SYS_SCR_RESTATE_DEX_LOW:
		{
			if( m_nDex == 15 )
			{
				((CUser*)this)->AddDefinedText( TID_GAME_DONOTUSE_RESTATE );			
				nResult = 1;
			}
			else
				ReStateOneLow( 2 );
		}
		break;
	case II_CHR_SYS_SCR_RESTATE_INT_LOW:
		{
			if( m_nInt == 15 )
			{
				((CUser*)this)->AddDefinedText( TID_GAME_DONOTUSE_RESTATE );			
				nResult = 1;
			}
			else
				ReStateOneLow( 3 );
		}
		break;
#endif // __ADD_RESTATE_LOW
#ifdef __TRAILS
	case II_SYS_SYS_SCR_NO_TRAIL:
	{
		if (HasBuffByIk3(IK3_TRAIL))
			RemoveIk3Buffs(IK3_TRAIL);
		else
		{
			((CUser*)this)->AddText(prj.GetText(TID_DONOTUSE_TRAIL));
			nResult = 1;
		}
	}
	break;
#endif // __TRAILS
	default:
			nResult = 1;
		break;
	}

#ifndef __AZRIA_1023
#ifdef __SYS_TICKET
	if( pItemProp->dwItemKind3 == IK3_TICKET )
	{
		( (CUser*)this )->DoUseItemTicket( pItemElem );
		nResult		= 0;
	}
#endif	// __SYS_TICKET
#endif	// __AZRIA_1023

#if __VER >= 14 // __BALLOON_CODE_IMPROVEMENT
	if( pItemProp->dwItemKind3 == IK3_BALLOON )
	{
		if( HasBuffByIk3( IK3_BALLOON ) != FALSE )
			nResult = 2;
		else
		{
			DoApplySkill( (CCtrl*)this, pItemProp, NULL );
			nResult = 0;
		}
	}
#endif // __BALLOON_CODE_IMPROVEMENT

#endif // __WORLDSERVER

	return nResult;
}

#if __VER >= 16
int CMover::DoUseItemOnce(ItemProp* pItemProp, CItemElem* pItemElem, int nPart)
{
	int nResult = 0;
#ifdef __WORLDSERVER
	if (HasBuffByIk3(pItemProp->dwItemKind3))
		nResult = 2;
	else
		DoApplySkill((CCtrl*)this, pItemProp, NULL);
#endif // __WORLDSERVER
	return nResult;
}

int CMover::DoUseItemKeep(ItemProp* pItemProp, CItemElem* pItemElem, int nPart)
{
#ifdef __WORLDSERVER
#ifdef __NEW_STACKABLE_AMPS
	int nAmount = 0;
	for (MAPBUFF::iterator i = m_buffs.m_mapBuffs.begin(); i != m_buffs.m_mapBuffs.end(); ++i)
	{
		ItemProp* pItemProp = prj.GetItemProp(i->second->GetId());

		if (pItemProp)
		{
			if (pItemProp->dwItemKind3 == IK3_EXP_RATE)
			{
				nAmount++;
			}
		}
	}

	if (GetLevel() < pItemProp->nMinLimitLevel || GetLevel() > pItemProp->nMaxLimitLevel)
		return 1;

	if (nAmount >= MAX_AMP_STACK_COUNT)
		return 2;

	if (HasBuff(BUFF_ITEM, (WORD)(pItemProp->dwID)))
	{
		MAPAMPSTORE::iterator i = prj.m_mapAmpStore.find(pItemProp->dwID);
		if (i != prj.m_mapAmpStore.end())
		{
			AMP_STORE_INFO* info = i->second;
			if (HasBuff(BUFF_ITEM, (WORD)(info->dwIDSecond)))
			{
				if (HasBuff(BUFF_ITEM, (WORD)(info->dwIDThird)))
				{
					if (HasBuff(BUFF_ITEM, (WORD)(info->dwIDFourth)))
					{
						if (HasBuff(BUFF_ITEM, (WORD)(info->dwIDFifth)))
						{
							return 2;
						}
						else
						{
							if (pItemProp->nMaxDuplication >= 5)
							{
								ItemProp* pAmpProp = prj.GetItemProp(info->dwIDFifth);
								DoApplySkill((CCtrl*)this, pAmpProp, NULL);
								return 4;
							}
						}
					}
					else
					{
						if (pItemProp->nMaxDuplication >= 4)
						{
							ItemProp* pAmpProp = prj.GetItemProp(info->dwIDFourth);
							DoApplySkill((CCtrl*)this, pAmpProp, NULL);
							return 4;
						}
					}
				}
				else
				{
					if (pItemProp->nMaxDuplication >= 3)
					{
						ItemProp* pAmpProp = prj.GetItemProp(info->dwIDThird);
						DoApplySkill((CCtrl*)this, pAmpProp, NULL);
						return 4;
					}
				}
			}
			else
			{
				if (pItemProp->nMaxDuplication >= 2)
				{
					ItemProp* pAmpProp = prj.GetItemProp(info->dwIDSecond);
					DoApplySkill((CCtrl*)this, pAmpProp, NULL);
					return 4;
				}
			}
		}
	}
	else
	{
		AddBuff(BUFF_ITEM, (WORD)(pItemProp->dwID), 0, pItemProp->dwSkillTime, GetId());
		return 4;
	}
#endif // __NEW_STACKABLE_AMPS
#endif // __WORLDSERVER
	return 3;
}
#endif

#ifdef __WORLDSERVER
#ifdef __STACKABLE_ITEM
bool CantStackAnymore(CMover* mover, ItemProp* itemProp) {
	IBuff* pBuff = mover->m_buffs.GetBuff(BUFF_ITEM, (WORD)(itemProp->dwID));

	if (pBuff)
	{
		DWORD dwCurr = ::timeGetTime();
		if (static_cast<int>(itemProp->dwSkillTime) > static_cast<int>(itemProp->dwSkillTime + (pBuff->GetTotal() - (dwCurr - pBuff->GetInst()))))
			return true;
	}
	return false;
}

#endif
BOOL CMover::IsDoUseBuff( ItemProp* pItemProp )
{
	int nResult = 0;
	if( pItemProp->dwItemKind3 == IK3_POTION_BUFF_STR
		|| pItemProp->dwItemKind3 == IK3_POTION_BUFF_DEX
		|| pItemProp->dwItemKind3 == IK3_POTION_BUFF_INT
		|| pItemProp->dwItemKind3 == IK3_POTION_BUFF_STA
		|| pItemProp->dwItemKind3 == IK3_POTION_BUFF_DEFENSE		
#if __VER >= 8 //__CSC_VER8_5
		|| pItemProp->dwItemKind3 == IK3_ANGEL_BUFF		
#endif // __CSC_VER8_5
#ifdef __BUFF_TOGIFT
		|| pItemProp->dwItemKind2 == IK2_BUFF_TOGIFT
#endif // __BUFF_TOGIFT
#ifdef __TRAILS
		|| pItemProp->dwItemKind3 == IK3_TRAIL
#endif // __TRAILS
#ifdef __CANDY_CRUSH
		|| pItemProp->dwItemKind3 == IK3_CANDY_CRUSH
#endif // __CANDY_CRUSH
#ifdef __VIP
		|| pItemProp->dwItemKind3 == IK3_VIP
		|| pItemProp->dwItemKind3 == IK3_AFK
#endif // __VIP
#ifdef __CSHOUTSCR
		|| pItemProp->dwItemKind3 == IK3_CSHOUT
#endif // __CSHOUTSCR
		)
	{
		if( HasBuffByIk3( pItemProp->dwItemKind3 ) )
			nResult = 1;

#if __VER >= 8 //__CSC_VER8_5
#ifdef __PKSERVER_USE_ANGEL
		if( pItemProp->dwItemKind3 == IK3_ANGEL_BUFF )
		{
#ifdef __WORLDSERVER_MENU
			if (g_eLocal.GetState(EVE_PK) && CDPSrvr::GetInstance()->m_bPk == TRUE)
#else // __WORLDSERVER_MENU
			if (g_eLocal.GetState(EVE_PK))
#endif // __WORLDSERVER_MENU
			{
				if( 0 >= GetPKValue() )
					nResult = 2;
				if( GetQuest( QUEST_PKMINUS ) == NULL )
					nResult = 3;
				if( m_Inventory.GetAtItemId( II_SYS_SYS_QUE_ANGEL_RED100 ) != NULL 
					|| m_Inventory.GetAtItemId( II_SYS_SYS_QUE_ANGEL_BLUE100 ) != NULL 
					|| m_Inventory.GetAtItemId( II_SYS_SYS_QUE_ANGEL_GREEN100 ) != NULL 
					|| m_Inventory.GetAtItemId( II_SYS_SYS_QUE_ANGEL_WHITE100 ) != NULL 
					)
					nResult = 4;
			}
			else
				nResult = 5;
		}
#else //__PKSERVER_USE_ANGEL
		if( pItemProp->dwItemKind3 == IK3_ANGEL_BUFF )
		{
			if( 0 >= GetPKValue() )
				nResult = 2;
			if( GetQuest( QUEST_PKMINUS ) == NULL )
				nResult = 3;
			if( m_Inventory.GetAtItemId( II_SYS_SYS_QUE_ANGEL_RED100 ) != NULL 
				|| m_Inventory.GetAtItemId( II_SYS_SYS_QUE_ANGEL_BLUE100 ) != NULL 
				|| m_Inventory.GetAtItemId( II_SYS_SYS_QUE_ANGEL_GREEN100 ) != NULL 
				|| m_Inventory.GetAtItemId( II_SYS_SYS_QUE_ANGEL_WHITE100 ) != NULL 
				)
				nResult = 4;
		}
#endif //__PKSERVER_USE_ANGEL
#endif // __CSC_VER8_5
	}
#if __VER >= 8
	else if( pItemProp->dwID == II_SYS_SYS_SCR_DEFENSE20 || pItemProp->dwID == II_SYS_SYS_SCR_DEFENSE50 )
	{
		if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_DEFENSE20 ) || HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_DEFENSE50 ) )
			nResult = 1;
	}
#endif // __VER >= 8
#ifdef __JEFF_11_1
	else if( pItemProp->dwID == II_SYS_SYS_SCR_PET_FEED_POCKET02 )
	{
		int nMax	= m_Inventory.GetMax();
		CItemElem* pItem;
		for( int i = 0 ; i < nMax; i++ )
		{
			pItem	= m_Inventory.GetAtId( i );
			if( IsUsableItem( pItem )
				&& pItem->m_dwItemId == II_SYS_SYS_SCR_PET_FEED_POCKET
				&& pItem->m_dwKeepTime > 0
				&& !pItem->IsFlag( CItemElem::expired )
				)
			{
				nResult		= 1;
				break;
			}
		}
		if( nResult != 1 )
		{
#ifdef __BUFF_1107
#ifdef __STACKABLE_ITEM
			if (CantStackAnymore(this, pItemProp)) {
				nResult = 1;
			}
#else
			IBuff* pBuff = m_buffs.GetBuff(BUFF_ITEM, (WORD)(pItemProp->dwID));
			if (pBuff)
			{
				DWORD dwCurr = ::timeGetTime();
				if (static_cast<int>(pItemProp->dwSkillTime) > static_cast<int>(pItemProp->dwSkillTime + (pBuff->GetTotal() - (dwCurr - pBuff->GetInst()))))
					nResult = 1;
			}
#endif
#else	// __BUFF_1107
			LPSKILLINFLUENCE ptr	= m_SkillState.FindPtr( BUFF_ITEM, pItemProp->dwID );
			if( ptr )
			{
				DWORD dwCurr	= ::timeGetTime();
				if( static_cast<int>( pItemProp->dwSkillTime ) > static_cast<int>( pItemProp->dwSkillTime + ( ptr->tmCount - ( dwCurr - ptr->tmTime ) ) ) )
					nResult		= 1;
			}
		#endif	// __BUFF_1107
		}
	}
#endif	// __JEFF_11_1
	else if( HasBuff( BUFF_ITEM, (WORD)( pItemProp->dwID ) ) )
	{
#ifndef __STACKABLE_ITEM
	nResult = 1;
#else
	if (pItemProp->dwItemKind3 != IK3_STACKABLE) {
		nResult = 1;
	}
	else if (CantStackAnymore(this, pItemProp)) {
		nResult = 1;
	}
#endif
	}
#if __VER >= 11 // __SYS_COLLECTING
	else if( pItemProp->dwID == II_GEN_TOO_COL_SILVERBATTERY
		|| pItemProp->dwID == II_GEN_TOO_COL_GOLDBATTERY
		|| pItemProp->dwID == II_GEN_TOO_COL_BATTERY001
#ifdef __PREMIUM_BATTERY
		|| pItemProp->dwID == II_GEN_TOO_COL_SILVERBATTERY_P
		|| pItemProp->dwID == II_GEN_TOO_COL_GOLDBATTERY_P
		|| pItemProp->dwID == II_GEN_TOO_COL_BATTERY001_P
#endif
		)
	{
		if( HasBuff( BUFF_ITEM2, II_GEN_TOO_COL_SILVERBATTERY )
			|| HasBuff( BUFF_ITEM2, II_GEN_TOO_COL_GOLDBATTERY )
			|| HasBuff( BUFF_ITEM2, II_GEN_TOO_COL_BATTERY001 )
#ifdef __PREMIUM_BATTERY
			|| HasBuff(BUFF_ITEM2, II_GEN_TOO_COL_SILVERBATTERY_P)
			|| HasBuff(BUFF_ITEM2, II_GEN_TOO_COL_GOLDBATTERY_P)
			|| HasBuff(BUFF_ITEM2, II_GEN_TOO_COL_BATTERY001_P)
#endif
			)
			nResult = 1;
	}
#endif // __SYS_COLLECTING
#if __VER >= 12 // __JHMA_VER12_1	//12Â÷ ±Ø´ÜÀ¯·á¾ÆÀÌÅÛ
	#define II_SYS_SYS_SCR_PARTYEXPUP01_01 20296
#define II_SYS_SYS_SCR_PARTYSKILLUP01_01 20297
	else if( pItemProp->dwID == II_SYS_SYS_SCR_PARTYEXPUP01
		|| pItemProp->dwID == II_SYS_SYS_SCR_PARTYEXPUP02
		|| pItemProp->dwID == II_SYS_SYS_SCR_PARTYEXPUP01_01
		)
	{
		if( HasBuff( BUFF_ITEM2, II_SYS_SYS_SCR_PARTYEXPUP01 )
			|| HasBuff( BUFF_ITEM2, II_SYS_SYS_SCR_PARTYEXPUP02 )
			|| HasBuff( BUFF_ITEM2, II_SYS_SYS_SCR_PARTYEXPUP01_01 )
			)
			nResult = 1;
	}
	else if( pItemProp->dwID == II_SYS_SYS_SCR_SPETGOOD
		)
	{
		if( HasBuff( BUFF_ITEM2, II_SYS_SYS_SCR_SPETGOOD )
			)
			nResult = 1;
	}
	else if( pItemProp->dwID == II_SYS_SYS_SCR_PARTYSKILLUP01
		|| pItemProp->dwID == II_SYS_SYS_SCR_PARTYSKILLUP02
		|| pItemProp->dwID == II_SYS_SYS_SCR_PARTYSKILLUP01_01
		)
	{
		if( HasBuff( BUFF_ITEM2, II_SYS_SYS_SCR_PARTYSKILLUP01 )
			|| HasBuff( BUFF_ITEM2, II_SYS_SYS_SCR_PARTYSKILLUP02 )
			|| HasBuff( BUFF_ITEM2, II_SYS_SYS_SCR_PARTYSKILLUP01_01 )
			)
			nResult = 1;
	}
#endif // //12Â÷ ±Ø´ÜÀ¯·á¾ÆÀÌÅÛ
	
#ifdef __SYS_SCR_PARTYPOINTFREE
	else if( pItemProp->dwID == II_SYS_SYS_SCR_PARTYPOINTFREE01
		|| pItemProp->dwID == II_SYS_SYS_SCR_PARTYPOINTFREE02
		|| pItemProp->dwID == II_SYS_SYS_SCR_PARTYPOINTFREE03
		)
	{
		if( HasBuff( BUFF_ITEM2, II_SYS_SYS_SCR_PARTYPOINTFREE01 )
			|| HasBuff( BUFF_ITEM2, II_SYS_SYS_SCR_PARTYPOINTFREE02 )
			|| HasBuff( BUFF_ITEM2, II_SYS_SYS_SCR_PARTYPOINTFREE03 )
			)
			nResult = 1;
	}
#endif

#ifdef __GAMEGUARD
	if (HasBuff(BUFF_ITEM2, II_CHR_FOO_COO_GRILLEDEEL) || HasBuff(BUFF_ITEM2, II_CHR_FOO_COO_GRILLEDEEL_1))
		nResult = 1;
#endif // __GAMEGUARD

#ifdef __SYS_SYS_ARMOREFFECTCHANGE
	else if (pItemProp->dwID == II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_7DAY
		|| pItemProp->dwID == II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_15DAY
		|| pItemProp->dwID == II_SYS_SYS_ARMOREFFECTCHANGE_RED_7DAY
		|| pItemProp->dwID == II_SYS_SYS_ARMOREFFECTCHANGE_RED_15DAY
		|| pItemProp->dwID == II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_7DAY
		|| pItemProp->dwID == II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_15DAY
		|| pItemProp->dwID == II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_7DAY
		|| pItemProp->dwID == II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_15DAY
		|| pItemProp->dwID == II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_7DAY
		|| pItemProp->dwID == II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_15DAY
		|| pItemProp->dwID == II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY
		|| pItemProp->dwID == II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_15DAY)
	{
		if (HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_7DAY)
			|| HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_GOLD_15DAY)
			|| HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_RED_7DAY)
			|| HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_RED_15DAY)
			|| HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_7DAY)
			|| HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_BLACK_15DAY)
			|| HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_7DAY)
			|| HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_GREEN_15DAY)
			|| HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_7DAY)
			|| HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_PUPPLE_15DAY)
			|| HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_7DAY)
			|| HasBuff(BUFF_ITEM2, II_SYS_SYS_ARMOREFFECTCHANGE_WHITE_15DAY))
			nResult = 1;
	}
#endif

	switch( nResult )
	{
	case 1:
		((CUser*)this)->AddDefinedText( TID_GAME_LIMITED_USE, "" ); // »ç¿ëÁßÀÌ¾î¼­ »ç¿ëÇÒ¼ö ¾øÀ½
		break;
#if __VER >= 8 //__CSC_VER8_5
	case 2:
		((CUser*)this)->AddDefinedText( TID_GAME_PKVALUE_NOT_ANGEL );
		break;
	case 3:
		((CUser*)this)->AddDefinedText( TID_GAME_NOT_QUEST_ANGEL );
		break;	
	case 4:
		((CUser*)this)->AddDefinedText( TID_GAME_NOT_COMPLETE_ANGEL );
		break;	
#endif // __CSC_VER8_5
	}
	return nResult;
}
#endif // __WORLDSERVER

// ¼Ò½ºº¸±â Çò°¥¸®´Ï±î À¯·á¾ÆÀÌÅÛ¸¸ µû·Î »¯´Ù.
BOOL	CMover::DoUseItemFood_SM( ItemProp *pItemProp, CItemElem* pItemElem )
{
#ifdef __WORLDSERVER
	if( !( IsSMMode( SM_MAX_HP ) || IsSMMode( SM_MAX_HP50 ) ) )		// MAXHP ¹öÇÁ°¡ ¾øÀ»¶§¸¸ »ç¿ëµÊ.
	{
		DWORD nAdjParamVal;
		int nType;
		if( pItemProp->dwID == II_CHR_FOO_COO_BULLHAMS )
		{
			nAdjParamVal = pItemProp->nAdjParamVal2;
			nType = SM_MAX_HP;
		}
		else
		if( pItemProp->dwID == II_CHR_FOO_COO_GRILLEDEEL )
		{
			m_nPlusMaxHitPoint = nAdjParamVal = int( GetMaxOriginHitPoint() / ( 100 / pItemProp->nAdjParamVal1 ) );
			nType = SM_MAX_HP50;
		}
		else
			return FALSE;
			
		SetDestParam( pItemProp->dwDestParam1, nAdjParamVal, nAdjParamVal );
		SetSMMode( nType, pItemProp->dwCircleTime );
	}
	else
	{
		((CUser*)this)->AddDefinedText( TID_GAME_LIMITED_USE, "" );	// »ç¿ëÁßÀÎ »ó¿ë ¾ÆÀÌÅÛ
		return FALSE;
	}
#endif
	return TRUE;
}

// IK2_FOOD / IK2_REFRESHER
BOOL	CMover::DoUseItemFood( ItemProp *pItemProp, CItemElem* pItemElem )
{
#ifdef __WORLDSERVER
	if( pItemProp->dwID == II_GEN_FOO_INS_SUPERHOTDOG )
	{
		SetPointParam( DST_HP, GetMaxHitPoint() );
		SetPointParam( DST_MP, GetMaxManaPoint() );
		SetPointParam( DST_FP, GetMaxFatiguePoint() );
		return TRUE;
	}

#ifdef __NO_HP_DMG_LIMIT
	__int64 nPoint;
	__int64 nMax, nHP, nHPMax;
#else
	int nPoint;
	int nMax, nHP, nHPMax;
#endif
#ifdef __PROP_0827
	for( int i = 0; i < 3; i ++ )
#else	// __PROP_0827
	for( int i = 0; i < 2; i ++ )
#endif	// __PROP_0827
	{
		if( pItemProp->dwDestParam[i] != (DWORD)-1 )
		{
			nHP	   = GetPointParam( pItemProp->dwDestParam[i] );
			nPoint = pItemProp->nAdjParamVal[i];
			nHPMax = GetMaxPoint( pItemProp->dwDestParam[i]);
			nMax   = pItemProp->dwAbilityMin;
			
			if( pItemProp->dwCircleTime != -1)	// À¯·á¾ÆÀÌÅÛ¸¸ dwCircleTimeÀ¸·Î ´Ù ½è´õ¶ó....
			{
				BOOL bRet = DoUseItemFood_SM( pItemProp, pItemElem );
				if( bRet == FALSE )	return FALSE;
			}
			else
			{
				if( pItemProp->dwDestParam[i] == DST_HP || pItemProp->dwDestParam[i] == DST_MP || pItemProp->dwDestParam[i] == DST_FP )
				{
#ifndef __RECOVER_RATE
					if (nPoint != -1)
					{
						if (nHP >= nMax)
						{
							if (nHP + (nPoint * 0.3f) >= nHPMax)
								nHP = nHPMax;
							else
							{
								if (TRUE == IsPlayer())
								{
									DWORD dwParam = 0;
									switch (pItemProp->dwDestParam[i])
									{
									case DST_HP:	dwParam = TID_GAME_LIMITHP;		break;
									case DST_MP:	dwParam = TID_GAME_LIMITMP;		break;
									case DST_FP:	dwParam = TID_GAME_LIMITFP;		break;
									}

									((CUser*)this)->AddDefinedText(dwParam, "");
								}

#ifdef __NO_HP_DMG_LIMIT
								nPoint = (__int64)(nPoint * 0.3f);
#else
								nPoint = (int)(nPoint * 0.3f);
#endif
								nHP = nHP + nPoint;
							}
						}
						else
						{
							if (nHP + nPoint >= nHPMax)	// Æ÷ÀÎÆ® ´õÇßÀ»¶§ ¿À¹ÙµÇ´Â°É Ã³¸®.
								nHP = nHPMax;
							else
								nHP = nHP + nPoint;
						}
					}

					SetPointParam(pItemProp->dwDestParam[i], nHP);
#else // __RECOVER_RATE
					SetPointParam(pItemProp->dwDestParam[i], nHP + nPoint);
#endif // __RECOVER_RATE
				} // DST_HP, MP, FP
				else
				{
					DoApplySkill( this, pItemProp, NULL );
				}
			}
		}
	} // for
#endif // worldserver
	
	return TRUE;
}


#ifdef __WORLDSERVER
BOOL CMover::DoUseItemSexChange( int nFace )
{
	// 1.
	for( DWORD dwParts = 0; dwParts < MAX_HUMAN_PARTS; dwParts++ )
	{
		if( dwParts == PARTS_HEAD || dwParts == PARTS_HAIR || dwParts == PARTS_LWEAPON
			|| dwParts == PARTS_RWEAPON || dwParts == PARTS_SHIELD || dwParts == PARTS_RIDE
			|| ( dwParts >= PARTS_NECKLACE1 && dwParts <= PARTS_BULLET )
#ifdef __SHARDS
			|| dwParts == PARTS_LRUNE || dwParts == PARTS_RRUNE
#endif // __SHARDS
			)
			continue;
		
		CItemElem* pArmor	= m_Inventory.GetEquip( dwParts );
		if( pArmor )
		{
			((CUser*)this)->AddDefinedText( TID_GAME_CHECK_EQUIP, "" );
				return FALSE;
		}
	}

	// 2.
	DWORD dwIndex;
	if( GetSex() == SEX_MALE )
	{
		dwIndex		= MI_FEMALE;
		SetSex( SEX_FEMALE );
	}
	else
	{
		dwIndex	= MI_MALE;
		SetSex( SEX_MALE );
	}

	SetTypeIndex( D3DDEVICE, OT_MOVER, dwIndex );
	ResetScale();
	SetMotion( MTI_WALK );
	//RedoEquip( FALSE );		// chipi_091125 Á¦°Å
	RedoEquip( FALSE, FALSE );	// chipi_091125 Ãß°¡ - ¾Ç¼¼»ç¸®, ¹«±â µîÀÇ ¾ÆÀÌÅÛÀº Âø¿ë »óÅÂ·Î Æ®·£Áö°¡ °¡´ÉÇÑµ¥ ´É·ÂÄ¡¸¦ ´Ù½Ã(Áßº¹) Àû¿ë½ÃÅ°´Â ¹®Á¦°¡ ÀÖ¾ú´Ù.
	UpdateLocalMatrix();

	// 3.
	g_UserMng.AddSexChange( this );

	// 4.
	m_dwHeadMesh	= (DWORD)nFace;
	g_UserMng.AddChangeFace( m_idPlayer, (DWORD)nFace );

#if __VER >= 11 // __SYS_PLAYER_DATA
	g_dpDBClient.SendUpdatePlayerData( static_cast<CUser*>(this) );
#endif // __SYS_PLAYER_DATA

	return TRUE;
}
#endif	// __WORLDSERVER

/*--------------------------------------------------------------------------------------------------------


											Do Wand Attack


----------------------------------------------------------------------------------------------------------*/
//
// ¿Ïµå¾îÅÃÀ» ÇÏ¶ó!
//
int	 CMover::DoAttackMagic( CObj *pTargetObj, int nMagicPower, int idSfxHit )
{
	if( IsInvalidObj(pTargetObj) )		// Å¸°ÙÀÌ °Å½Ã±â ÇÏ¸é ¸®ÅÏ
		return( -1 );

	ItemProp* pItemProp;
#ifndef __CLIENT
	CItemElem* pItemElem = GetWeaponItem();	// ¼Õ¿¡µç ¹«±â°¡ ¾øÀ¸¸é ¸®ÅÏ
	if( pItemElem == NULL )
		return( - 1 ) ;
	pItemProp	= pItemElem->GetProp();
#ifdef __SECURITY_FIXES
	if (!pItemProp)
		return -1;
#endif // __SECURITY_FIXES
#else	// __CLIENT
	if( IsActiveMover() ) {
		CItemElem* pItemElem = GetWeaponItem();
		if( pItemElem == NULL )
			return( - 1 ) ;
		pItemProp	= pItemElem->GetProp();
	}
	else {
		DWORD dwItemId	= m_aEquipInfo[PARTS_RWEAPON].dwId;
		if( dwItemId == NULL_ID )
			return( -1 );
		pItemProp	= prj.GetItemProp( dwItemId );
	}
#endif	// __CLIENT

	if( pItemProp->dwItemKind3 != IK3_WAND )		// µé°íÀÖ´Â ¹«±â°¡ ¿Ïµå°¡ ¾Æ´Ï¸é ¿¡·¯.
		return( -1 );

#ifdef __CLIENT
	// ÇöÀç ÁöÁ¡°ú ¸ñÇ¥ÁöÁ¡±îÁö ¸·È÷´Â°Ô ÀÖÀ¸¸é ¸Þ½ÃÁö Ãâ·ÂÇÏ°í ¸®ÅÏ
	CWorld *pWorld = GetWorld();
	D3DXVECTOR3 vStart = GetPos();				vStart.y += 0.5f;
	D3DXVECTOR3 vEnd   = pTargetObj->GetPos();	vEnd.y += 0.5f;
#ifdef __SECURITY_FIXES
	if (!pWorld)
		return -1;
#endif // __SECURITY_FIXES
	if( pWorld->IntersectObjLine( NULL, vStart, vEnd, FALSE, FALSE ) )
	{
		g_WndMng.PutString( prj.GetText( TID_GAME_BLOCKTARGETING ), NULL, prj.GetTextColor( TID_GAME_BLOCKTARGETING ) );
		return -1;
	}
#endif  // CLIENT

	OBJID	idTarget = ((CCtrl*)pTargetObj)->GetId();

	int nError;
	if( ( nError = m_pActMover->SendActMsg( OBJMSG_ATK_MAGIC1, idTarget ) ) == 1 )	// ¿Ïµå°ø°Ý µ¿ÀÛ ½ÃÀÛ.
	{
		if( m_pActMover->IsFly() == FALSE )		
			SetAngle( GetDegree(pTargetObj->GetPos(), GetPos()) );		// ¸ñÇ¥ÂÊÀ¸·Î ¸öÀ» µ¹¸².
		SetActParam( OBJACT_MAGIC_ATTACK, idTarget, nMagicPower );		// ½ÇÇàÁß »ç¿ëÇÒ ÆÄ¶ó¸ÞÅÍ µî·Ï
		
#ifdef __CLIENT	
		if( nMagicPower >= 1 )	// ·¹º§ 2ÀÌ»óÀ» ¾²¸é ¾×¼ÇÆ÷ÀÎÆ® ÇÏ³ª ¿Ã¶ó°¨.
		{
			if (!g_Option.isClassicTheme() && !g_Option.isRedTheme() && !g_Option.isClassicBlueTheme())
			{
				if (g_WndMng.m_pWndTaskBar->m_nActionPoint < 100)
					g_WndMng.m_pWndTaskBar->m_nActionPoint++;
			}
		}
#endif
		
#ifdef __WORLDSERVER
		if (IsPlayer())
		{
//#ifndef __NEW_TASKBAR_V19
			//if(!g_Option.isClassicTheme() && !g_Option.isRedTheme() && !g_Option.isClassicBlueTheme())
			{
				if (nMagicPower >= 1 && ((CUser*)this)->m_playTaskBar.m_nActionPoint < 100)	// 2´Ü°èÃæÀüÀÌ»ó »ç¿ëÇÏ¸é ¾×¼ÇÆ÷ÀÎÆ® ¿Ã¶ó°¨.
					((CUser*)this)->m_playTaskBar.m_nActionPoint++;
			}
//#endif // __NEW_TASKBAR_V19
		}
		if (nMagicPower == 3)		// 4´Ü°èÂ¥¸®¸¦ ¾²¸é ¸¶³ª 5Æ÷ÀÎÆ® °¨¼Ò
			IncManaPoint(-GetReqMp(pItemProp->dwReqMp));
		g_UserMng.AddMagicAttack(this, OBJMSG_ATK_MAGIC1, idTarget, 0, 0, nMagicPower, idSfxHit);
#else	// __WORLDSERVER
#ifdef __CLIENT
		if (IsActiveMover()) {
			SetActParam(OBJACT_MAGIC_ATTACK, idTarget, nMagicPower);	// È¿°ú ½Äº°ÀÚ µî·Ï
			g_DPlay.SendMagicAttack(OBJMSG_ATK_MAGIC1, ((CCtrl*)pTargetObj)->GetId(), 0, 0, nMagicPower, m_idSfxHit);
		}
#endif	// __CLIENT
#endif	// __WORLDSERVER
	}
	return( nError );
}

/*--------------------------------------------------------------------------------------------------------


											Do Range Attack


----------------------------------------------------------------------------------------------------------*/
//
// ·¹ÀÎÁö¾îÅÃÀ» ÇÏ¶ó!
// dwItemID : ¹«±â¾ÆÀÌÅÛ ¾ÆÀÌµð
//
int	 CMover::DoAttackRange( CObj *pTargetObj, DWORD dwItemID, int idSfxHit )
{
	ItemProp* pItemProp = NULL;
	int nPower = 0;

	if( IsInvalidObj(pTargetObj) )
		return -1;
	
#ifdef __FIX_RANGER_ROLLER
	m_pActMover->SendActMsg(OBJMSG_STOP);
#endif

#ifdef __CLIENT
	if( IsActiveMover() )
	{
		// ÇöÀç ÁöÁ¡°ú ¸ñÇ¥ÁöÁ¡±îÁö ¸·È÷´Â°Ô ÀÖÀ¸¸é ¸Þ½ÃÁö Ãâ·ÂÇÏ°í ¸®ÅÏ
		CWorld *pWorld = GetWorld();
		D3DXVECTOR3 vStart = GetPos();				vStart.y += 0.5f;
		D3DXVECTOR3 vEnd   = pTargetObj->GetPos();	vEnd.y += 0.5f;

		if( pWorld->IntersectObjLine( NULL, vStart, vEnd, FALSE, FALSE ) )
		{
			g_WndMng.PutString( prj.GetText( TID_GAME_BLOCKTARGETING ), NULL, prj.GetTextColor( TID_GAME_BLOCKTARGETING ) );
			
			return -1;
		}
	}
#endif  // CLIENT
	

	if( IsPlayer() )
	{
		pItemProp = GetActiveHandItemProp();			
		nPower = dwItemID;
#ifdef __WANDATK
		dwItemID = 0;
#endif
	#ifdef __WORLDSERVER
		CItemElem* pItemElem = m_Inventory.GetEquip( PARTS_BULLET );	// È­»ìÀÌ ÀÖ´ÂÁö Ã¼Å©
		if( pItemElem == NULL || pItemElem->GetProp()->dwItemKind3 != IK3_ARROW )
			return -1;
	#endif // __WORLDSERVER
	}
	else
	{
		if( dwItemID == NULL_ID || dwItemID == 0 )	
			pItemProp = GetActiveHandItemProp();		// ÀÌ·±°æ¿ì´Â °Á ¼Õ¿¡ µç ¹«±â(È¤Àº ±âº»¾ÆÀÌÅÛ)
		else
			pItemProp = prj.GetItemProp( dwItemID );
	}
	
	if( pItemProp == NULL )
	{
		Error( "DoAttackRange : %s ActiveHandItemProp = NULL", m_szName );
		return -1;
	}

	if( pItemProp->dwWeaponType != WT_RANGE && pItemProp->dwWeaponType != WT_RANGE_BOW )		// µé°íÀÖ´Â ¹«±â°¡ RANGE°¡ ¾Æ´Ï¸é ¸®ÅÏ
	{
		return -1;
	}
	
	DWORD dwUseMotion = pItemProp->dwUseMotion;	
	if( dwUseMotion == NULL_ID )
	{
		if( IsPlayer() )
		{
			dwUseMotion = MTI_ATK_13 - MTI_STAND_13;//23;
		}
		else
		{
			Error( "DoAttackRange : %s [%d]'s dwUseMotion = NULL_ID", m_szName, pItemProp->dwID );
			dwUseMotion = MTI_ATK1;		// ÇÁ·ÎÆÛÆ¼¿¡ Àå°Å¸® °ø°Ý ¸ð¼ÇÀÌ ÁöÁ¤µÇÁö ¾Ê¾ÒÀ¸¸é ±âº» ¸ð¼ÇÀ¸·Î ÇÑ´Ù.
		}
	}

	OBJID	idTarget = ((CCtrl*)pTargetObj)->GetId();

	int nError;
	if( ( nError = m_pActMover->SendActMsg( OBJMSG_ATK_RANGE1, idTarget, (int)dwUseMotion ) ) == 1 )	// Àå°Å¸®°ø°Ý.
	{
		SetAngle( GetDegree(pTargetObj->GetPos(), GetPos()) );			// ¸ñÇ¥ÂÊÀ¸·Î ¸öÀ» µ¹¸².
		SetActParam( OBJACT_RANGE_ATTACK, idTarget, dwItemID, idSfxHit );	// È¿°ú ½Äº°ÀÚ µî·Ï
		
	#ifdef __WORLDSERVER
		g_UserMng.AddRangeAttack( this, OBJMSG_ATK_RANGE1, idTarget, dwItemID, 0, idSfxHit );
		ArrowDown( 1 );		// È­»ì 1°³ ¾ø¾Ú
	#else	// __WORLDSERVER
		if( IsActiveMover() )	// Å¬¶ó¿¡¼­ ÇÃ·¹ÀÌ¾î°¡ »ç¿ëÇÑ°Å¶ó¸é ¼­¹ö·Î Á¤º¸ º¸³¿.
			g_DPlay.SendRangeAttack( OBJMSG_ATK_RANGE1, ( (CCtrl*)pTargetObj )->GetId(), dwItemID, m_idSfxHit ); 
	#endif	// __WORLDSERVER
	}
	return nError;
}
#ifdef __ATTACK_TRACKING
//Track Attacks locally for client visualization
void CMover::TrackLocalConsecutiveHits(DWORD lastTarget, DWORD count, double time)
{
	m_dwLastPlayerAttacked = lastTarget;
	m_dwAttackCount = count;
	m_dbLastAttackTime = time;
}
#endif //__ATTACK_TRACKING
// ¸ó½ºÅÍ Æ¯¼ö°ø°Ý
int		CMover::DoAttackSP( CObj *pTargetObj, DWORD dwItemID )
{
	if( IsInvalidObj(pTargetObj) )
		return( -1 );
	
	ItemProp* pItemProp;
	if( dwItemID == NULL_ID || dwItemID == 0 )	
		pItemProp = GetActiveHandItemProp();	// ÀÌ·±°æ¿ì´Â °Á ¼Õ¿¡ µç ¹«±â(È¤Àº ±âº»¾ÆÀÌÅÛ)
	else
		pItemProp = prj.GetItemProp( dwItemID );	// Á÷Á¢ ¾ÆÀÌÅÛÀ» ÁöÁ¤ÇÑ °æ¿ì´Â ±×°É·Î °ø°ÝÇÔ(¸ó½ºÅÍ°¡ ÁÖ·Î »ç¿ëÇÔ)
	if( pItemProp == NULL )
	{
		Error( "DoAttackSP : %s ÀÇ ItemPropÀÌ NULL %d", m_szName, (int)dwItemID );
		return FALSE;
	}

	DWORD dwUseMotion = pItemProp->dwUseMotion;
	if( dwUseMotion == NULL_ID )
	{
		Error( "DoAttackSP : %sÀÇ °ø°Ý%dÀÇ dwUseMotionÀÌ ÁöÁ¤µÇÁö ¾Ê¾Ò´Ù", m_szName, pItemProp->dwID );
		dwUseMotion = MTI_ATK1;		// ÇÁ·ÎÆÛÆ¼¿¡ Àå°Å¸® °ø°Ý ¸ð¼ÇÀÌ ÁöÁ¤µÇÁö ¾Ê¾ÒÀ¸¸é ±âº» ¸ð¼ÇÀ¸·Î ÇÑ´Ù.
	}
	
	OBJID	idTarget = ((CCtrl*)pTargetObj)->GetId();
	
	int nError;
	if( ( nError = m_pActMover->SendActMsg( OBJMSG_SP_ATK1, idTarget, (int)dwItemID, (int)dwUseMotion ) ) == 1 )	// Àå°Å¸®°ø°Ý.
	{
		SetAngle( GetDegree(pTargetObj->GetPos(), GetPos()) );		// ¸ñÇ¥ÂÊÀ¸·Î ¸öÀ» µ¹¸².
		SetActParam( OBJACT_SP_ATTACK, idTarget, (int)dwItemID );	// È¿°ú ½Äº°ÀÚ µî·Ï
		
#ifdef __WORLDSERVER
		g_UserMng.AddAttackSP( this, OBJMSG_SP_ATK1, idTarget, dwItemID, 0 );
#else	// __WORLDSERVER
	
#if 0 //2009_12_18 ±âÈ¹¿¡¼­ Á¦°Å ¿äÃ» : ¹ßµ¿Å¸ÀÓ¿¡ Å¸°Ù¿¡ ´ëÇØ ÀÌÆåÆ® ÇÊ¿ä¾øÀ½ 
		DWORD dwSfxObj = pItemProp->dwSfxObj3;		// Æ¯¼ö°ø°Ý¿¡ ¹ßµ¿ÀÌÆåÆ®°¡ ÀÖ´Ù¸é 3¹ø»ç¿ë.
		if( dwSfxObj != NULL_ID )
			CreateSfx( D3DDEVICE, dwSfxObj, GetPos(), GetId(), D3DXVECTOR3(0,0,0), idTarget );
#endif 

	//gmpbigsun: ¹ßµ¿½Ã °ø°ÝÀÚ¿¡ ´ëÇÑ ¹ßµ¿ effect
	DWORD dwSfxObj = pItemProp->dwSfxObj;
	if( NULL_ID != dwSfxObj )
		CreateSfx( D3DDEVICE, dwSfxObj, GetPos() );

		
#endif	// __WORLDSERVER
	}

	return( nError );
}

int		CMover::DoAttackMelee( CMover *pTarget, OBJMSG dwMsg, DWORD dwItemID )
{
	SendActMsg( OBJMSG_STOP );		// Á¦ÀÚ¸® ¸ØÃã.

	if( IsInvalidObj(pTarget) )
		return 0;
	
	ItemProp* pItemProp;
	if( dwItemID == NULL_ID || dwItemID == 0 )	
		pItemProp = GetActiveHandItemProp();	// ÀÌ·±°æ¿ì´Â °Á ¼Õ¿¡ µç ¹«±â(È¤Àº ±âº»¾ÆÀÌÅÛ)
	else
		pItemProp = prj.GetItemProp( dwItemID );	// Á÷Á¢ ¾ÆÀÌÅÛÀ» ÁöÁ¤ÇÑ °æ¿ì´Â ±×°É·Î °ø°ÝÇÔ(¸ó½ºÅÍ°¡ ÁÖ·Î »ç¿ëÇÔ)
	if( pItemProp == NULL )
	{
		Error( "DoAttackMelee : %s ÀÇ ItemPropÀÌ NULL %d", GetName(), (int)dwItemID );
		return FALSE;
	}

	// ¸ð¼Ç ½ÃÀÛÇÏ°í.
	int nError	= SendActMsg( dwMsg, pTarget->GetId(), MAKELONG( 0, 0 ), MAKELONG( 0, 0 ) );
	if( nError > 0 )
	{
		SetActParam( OBJACT_MELEE_ATTACK, pTarget->GetId(), (int)dwItemID );	// OnAttackMelee¿¡¼­ ¾µ¼ö ÀÖµµ·Ï ÆÄ¶ó¸ÞÅÍ µî·Ï.

#ifdef __CLIENT
#ifdef __HACK_1023
		ItemProp* pHandItemProp		= GetActiveHandItemProp();
		FLOAT fVal	= pHandItemProp? pHandItemProp->fAttackSpeed: 0.0F;
		g_DPlay.SendMeleeAttack( dwMsg, pTarget->GetId(), MAKELONG( 0, 0 ), MAKELONG( 0, (WORD)nError ), fVal );
#else	// __HACK_1023
		g_DPlay.SendMeleeAttack( dwMsg, pTarget->GetId(), MAKELONG( 0, 0 ), MAKELONG( 0, (WORD)nError ) );
#endif	// __HACK_1023
		if( IsActiveMover() )
		{
			PlayCombatMusic();
#if __VER < 11 // __REMOVE_ENDURANCE
			CItemElem* pWeapon	= GetWeaponItem();
			if( pWeapon )
			{
				ItemProp* pItemProp		= pWeapon->GetProp();
				if( pItemProp )
					if( ( ( pWeapon->m_nHitPoint * 100 ) / pItemProp->dwEndurance ) == 0 )
						g_WndMng.PutString( prj.GetText( TID_GAME_WASTEENDURANCE ), NULL, prj.GetTextColor( TID_GAME_WASTEENDURANCE ) );
			}
#endif // __REMOVE_ENDURANCE
		}
#else	// __CLIENT
		g_UserMng.AddMeleeAttack( this, dwMsg, pTarget->GetId(), MAKELONG( 0, 0 ), MAKELONG( 0, (WORD)nError ) );
#endif	// __CLIENT
	}

	return TRUE;	
}	



// ÁÖº¯¿¡ ÀÖ´Â ¾ÆÀÌÅÛÁß ÇÏ³ª¸¦ Áý´Â´Ù.
void	CMover::DoPickupItemAround()
{
#ifdef __CLIENT
	if( m_pActMover->IsActAttack() )	return;		// °ø°ÝÁß »ç¿ë¾ÈµÊ.
	if( IsDie() )		return;						// Á×¾úÀ»¶© »ç¿ë¾ÈµÊ.
	
	int nRange	= 4;	// 4m
	float fDistMin = 99999.0f, fDistSq;
	CObj* pObj, *pMinObj = NULL;
	D3DXVECTOR3 vPos = GetPos();
	D3DXVECTOR3 vDist;
	FOR_LINKMAP( GetWorld(), vPos, pObj, nRange, CObj::linkDynamic, GetLayer() )
	{
		if( pObj->GetType() == OT_ITEM )
		{
			vDist = pObj->GetPos() - vPos;		// this -> ¾ÆÀÌÅÛ±îÁöÀÇ º¤ÅÍ
			fDistSq = D3DXVec3LengthSq( &vDist );
			if( fDistSq < 4.0f * 4.0f )		// ¾ÆÀÌÅÛ°úÀÇ °Å¸®°¡ x¹ÌÅÍ ÀÌ³»ÀÎ°ÍÀ» ´ë»óÀ¸·Î.
			{
				if( fDistSq < fDistMin )	// ±×Áß Á© °¡±î¿î³ðÀ¸·Î ¼±ÅÃ
				{
					fDistMin = fDistSq;
					pMinObj = pObj;
				}
			}
		}
	}
	END_LINKMAP

	// ¾ÆÀÌÅÛ ÁýÀ»°Ô ÀÖ´Ù.
	if( pMinObj )
	{
		CMD_SetUseItem( (CCtrl*)pMinObj );
	}
#endif // __CLIENT
}


// this¸¦ Å¸°ÙÀ¸·Î ÁÖº¯¿¡ µ¥¹ÌÁö¸¦ ÁØ´Ù.
// ------------------------------------------
// nDmgType : µ¥¹ÌÁö Å¸ÀÔ ex) AF_MAGICSKILL
// pAttacker : °ø°ÝÀÚ(½ÃÀüÀÚ) - ¾ÕÀ¸·Î CCtrl*·Î ¹Ù²ã¾ß ÇÑ´Ù
// nApplyType : Àû¿ë´ë»ó. ex) OBJTYPE_PLAYER | OBJTYPE_MONSTER
// nSkill : »ç¿ëÇÑ ½ºÅ³Á¾·ù
// fRange : Å¸°ÙÀ» Áß½ÉÀ¸·ÎÇÑ µ¥¹ÌÁö ¹üÀ§(¹ÌÅÍ)
// fTargetRatio : Å¸°Ù¿¡°Ô Àû¿ëµÇ´Â µ¥¹ÌÁö ºñÀ²
// fAroundRatio : ÁÖº¯¿¡ Àû¿ëµÇ´Â µ¥¹ÌÁö ºñÀ²
// (AF_MAGICSKILL, this, nSkill, 5.0f, 0.0, 1.0f )
void	CMover::SendDamageAround( int nDmgType, CMover *pAttacker, int nApplyType, int nAttackID, float fRange, float fTargetRatio, float fAroundRatio )
{
#ifdef __WORLDSERVER
	int nRange	= 4;	// 4m
	float fDistSq;
	CObj* pObj;
	CMover *pTarget;
	D3DXVECTOR3 vPos = GetPos();
	D3DXVECTOR3 vDist;

	if( fRange <= 4.0f )
		nRange = 4;
	else if( fRange <= 8.0f )
		nRange = 8;
	else if( fRange <= 16.0f )
		nRange = 16;
	else
		nRange = 32;
	
#ifdef __GAMEGUARD
	if (fRange <= 0 || nRange <= 0)
#else // __GAMEGUARD
	if (fRange <= 0)	// ¹üÀ§°¡ 0ÀÌ°Å³ª À½¼öÀÏ¼ö´Â ¾ø´Ù.
#endif // __GAMEGUARD
	{
		Error("CMover::SendDamageAround : D:%s A:%s %d %f", GetName(), pAttacker->GetName(), nAttackID, fRange);
	}

	ItemProp* pProp;
	if( nDmgType == AF_MAGICSKILL )
	{
		pProp = prj.GetSkillProp( nAttackID );		// UseSkill¿¡¼­ »ç¿ëÇÑ ½ºÅ³ÀÇ ÇÁ·ÎÆÛÆ¼ ²¨³¿
		if( pProp == NULL )
		{
			Error( "CMover::SendDamageAround : %s. ½ºÅ³(%d)ÀÇ ÇÁ·ÎÆÛÆ¼°¡ ¾÷´Ù.", m_szName, nAttackID );
			return;	// property not found
		}
	} else
	{
		pProp = prj.GetItemProp( nAttackID );		// ¾ÆÀÌÅÛ ÇÁ·ÎÆÛÆ¼²¨³¿
		if( pProp == NULL )
		{
			Error( "CMover::SendDamageAround : %s. ¾ÆÀÌÅÛ(%d)ÀÇ ÇÁ·ÎÆÛÆ¼°¡ ¾÷´Ù.", m_szName, nAttackID );
			return;	// property not found
		}
	}
	
	BOOL	bDamage = FALSE;
	BOOL	bTarget = FALSE;

	if( nApplyType & OBJTYPE_PLAYER )	// Àû¿ë´ë»óÀÌ ÇÃ·¹ÀÌ¾îÀÎ°¡ 
	{
		FOR_LINKMAP( GetWorld(), vPos, pObj, nRange, CObj::linkPlayer, GetLayer() )
		{
			if( pObj->GetType() == OT_MOVER )
			{
				bDamage = TRUE;

				if( bDamage )
				{
					vDist = pObj->GetPos() - vPos;		// this -> Å¸°Ù±îÁöÀÇ º¤ÅÍ
					fDistSq = D3DXVec3LengthSq( &vDist );
					if( fDistSq < fRange * fRange )		// Å¸°Ù°úÀÇ °Å¸®°¡ fRange¹ÌÅÍ ÀÌ³»ÀÎ°ÍÀ» ´ë»óÀ¸·Î.
					{
						if( pObj == this && fTargetRatio == 0.0f )	// Å¸°Ùµ¥¹ÌÁö ºñÀ²ÀÌ 0ÀÌ¸é ÀÚ±âÀÚ½Å(Å¸°Ù)Àº µ¥¹ÌÁö¸¦ ÁÖÁö¾ÊÀ½.
						{
						} else
						{
							if( pObj != pAttacker )		// ¾îÅÂÄ¿´Â °Ë»ö´ë»ó¿¡¼­ Á¦¿Ü.
							{
								pTarget = (CMover *)pObj;
								bTarget = ( pTarget == this );
								if( IsValidObj( (CObj*)pTarget ) && pTarget->IsLive() )
								{
									if( pProp->dwComboStyle == CT_FINISH )
										pTarget->m_pActMover->SendDamageForce( nDmgType, pAttacker->GetId(), (nAttackID << 16), bTarget );
									else
										pTarget->m_pActMover->SendDamage( nDmgType, pAttacker->GetId(), (nAttackID << 16), bTarget );
								}
							}
						}
					}
					
					bDamage = FALSE;	// ´ÙÀ½ ·çÇÁ¸¦ À§ÇØ¼­ ÃÊ±âÈ­.
				} // bDamage
			}
		}
		END_LINKMAP
	}

	// Àû¿ë´ë»óÀÌ ¸ó½ºÅÍÀÎ°¡.
	if( nApplyType & OBJTYPE_MONSTER )
	{
		FOR_LINKMAP( GetWorld(), vPos, pObj, nRange, CObj::linkDynamic, GetLayer() )
		{
			if( pObj->GetType() == OT_MOVER && ((CMover *)pObj)->IsPeaceful() == FALSE )
			{
				vDist = pObj->GetPos() - vPos;		// this -> Å¸°Ù±îÁöÀÇ º¤ÅÍ
				fDistSq = D3DXVec3LengthSq( &vDist );
				if( fDistSq < fRange * fRange )		// Å¸°Ù°úÀÇ °Å¸®°¡ fRange¹ÌÅÍ ÀÌ³»ÀÎ°ÍÀ» ´ë»óÀ¸·Î.
				{
					if( pObj == this && fTargetRatio == 0.0f )	// Å¸°Ùµ¥¹ÌÁö ºñÀ²ÀÌ 0ÀÌ¸é ÀÚ±âÀÚ½Å(Å¸°Ù)Àº µ¥¹ÌÁö¸¦ ÁÖÁö¾ÊÀ½.
					{
					} else
					{
						if( pObj != pAttacker )		// °ø°ÝÀÚ´Â °Ë»ç´ë»ó¿¡¼­ Á¦¿Ü.
						{
							pTarget = (CMover *)pObj;
							if( IsValidObj( (CObj*)pTarget ) && pTarget->IsLive() )
							{
								if( pProp->dwComboStyle == CT_FINISH )
									pTarget->m_pActMover->SendDamageForce( nDmgType, pAttacker->GetId(), (nAttackID << 16) );
								else
									pTarget->m_pActMover->SendDamage( nDmgType, pAttacker->GetId(), (nAttackID << 16) );
							}
						}
					}
				}
			}
		}
		END_LINKMAP
	}
		
#endif // WORLDSERVER		
} // SendDamageAround()
/*
BOOL	CMover::DoCollect( CMover *pTarget )
{
	SendActMsg( OBJMSG_STOP );
	BOOL bSuccess = SendActMsg( OBJMSG_COLLECT );
	ClearDest();
		
	return bSuccess;
}
*/


// 
// Æø, ³ôÀÌ, ±æÀÌ¸¦ ¼³Á¤ÇÏ¿© À°¸éÃ¼ ÇüÅÂÀÇ µ¥¹ÌÁö ¿µ¿ªÀ» »ý¼º.
// nDmgType : AF_???
// nApplyType : OBJTYPE_PLAYER , MONSTER
// nAttackID : ½ºÅ³ÀÌ³ª ¾ÆÀÌÅÛ ID
// fWidth, fHeight, fDepth : Æø, ³ôÀÌ, ±æÀÌ.
// this == Attacker
void	CMover::SendDamageLine( int nDmgType, int nApplyType, int nAttackID, 
								float fWidth, float fHeight, float fDepth )
{
#ifdef __WORLDSERVER
	int nRange	= 4;	// 4m

	CObj* pObj;
	CMover *pTarget;
	D3DXVECTOR3 vPos = GetPos();
	D3DXVECTOR3 vDist;

	// µ¥¹ÌÁö ¿µ¿ª Local AABB.
	D3DXVECTOR3 vMin1 = D3DXVECTOR3( -fWidth / 2.0f, -fHeight / 2.0f, -fDepth );
	D3DXVECTOR3 vMax1 = D3DXVECTOR3(  fWidth / 2.0f,  fHeight / 2.0f, 0 );

	D3DXMATRIX mInv;		// °ø°ÝÀÚÃø ¿ùµå¿ªÇà·Ä
	D3DXMATRIX m1, m2, m3;
	D3DXMatrixRotationY( &m1, D3DXToRadian( -GetAngle() ) );
	D3DXMatrixTranslation( &m2, GetPos().x, GetPos().y, GetPos().z );
	D3DXMatrixMultiply( &m3, &m1, &m2 );	// world = rot * trans
	
	D3DXMatrixInverse( &mInv, NULL, &m3 );		// °ø°ÝÀÚÀÇ ¿ªÇà·Ä ¸¸µë.

	// Å¸°ÙÀÇ ÁÂÇ¥¸¦ °ø°ÝÀÚÃø ±âÁØÀ¸·Î ¿ªº¯È¯ ÇÑ°Í.
	D3DXVECTOR3 vDestLocal;

	// ÀÏ¹ÝÀûÀ¸·Î fDepth°¡ °¡Àå ±æ±â¶§¹®¿¡ °Ë»ç ¿µ¿ªÀº fDepth·Î Çß´Ù. 
	if( fDepth <= 4.0f )
		nRange = 4;
	else if( fDepth <= 8.0f )
		nRange = 8;
	else if( fDepth <= 16.0f )
		nRange = 16;
	else
		nRange = 32;
	
	if( fDepth <= 0 )	// ¹üÀ§°¡ 0ÀÌ°Å³ª À½¼öÀÏ¼ö´Â ¾ø´Ù.
		Error( "CMover::SendDamageLine : D:%s A:%s %d %f", GetName(), nAttackID, fDepth );

	ItemProp* pProp;
	if( nDmgType == AF_MAGICSKILL )
	{
		pProp = prj.GetSkillProp( nAttackID );		// UseSkill¿¡¼­ »ç¿ëÇÑ ½ºÅ³ÀÇ ÇÁ·ÎÆÛÆ¼ ²¨³¿
		if( pProp == NULL )
		{
			Error( "CMover::SendDamageLine : %s. ½ºÅ³(%d)ÀÇ ÇÁ·ÎÆÛÆ¼°¡ ¾÷¤²´Ù.", m_szName, nAttackID );
			return;	// property not found
		}
	} else
	{
		pProp = prj.GetItemProp( nAttackID );		// ¾ÆÀÌÅÛ ÇÁ·ÎÆÛÆ¼²¨³¿
		if( pProp == NULL )
		{
			Error( "CMover::SendDamageLine : %s. ¾ÆÀÌÅÛ(%d)ÀÇ ÇÁ·ÎÆÛÆ¼°¡ ¾÷¤²´Ù.", m_szName, nAttackID );
			return;	// property not found
		}
	}
	
	BOOL	bDamage = FALSE;

	if( nApplyType & OBJTYPE_PLAYER )	// Àû¿ë´ë»óÀÌ ÇÃ·¹ÀÌ¾îÀÎ°¡ 
	{
		FOR_LINKMAP( GetWorld(), vPos, pObj, nRange, CObj::linkPlayer, GetLayer() )
		{
			if( pObj->GetType() == OT_MOVER )
			{
				bDamage = TRUE;	

				if( bDamage && pObj != this )		// this´Â °ø°Ý´ë»ó¿¡¼­ Á¦¿Ü.
				{
					pTarget = (CMover *)pObj;
					if( IsValidObj( pTarget ) && pTarget->IsLive() )
					{
						// Å¸°ÙÃø ÁÂÇ¥¸¦ ¿ªº¯È¯.
						D3DXVec3TransformCoord( &vDestLocal, &pTarget->GetPos(), &mInv );
						// Å¸°ÙÃø AABB
						D3DXVECTOR3 vMin2 = vDestLocal + pTarget->m_pModel->m_vMin;
						D3DXVECTOR3 vMax2 = vDestLocal + pTarget->m_pModel->m_vMax;
						if( ::IsTouchAABB( vMin1, vMax1, vMin2, vMax2 ) )		// AABBÃæµ¹°Ë»ç.
						{
						//	if( pProp->dwComboStyle == CT_FINISH )
						//		pTarget->m_pActMover->SendDamageForce( nDmgType, pAttacker->GetId(), (nAttackID << 16) );
						//	else
						//		pTarget->m_pActMover->SendDamage( nDmgType, pAttacker->GetId(), (nAttackID << 16) ); 					
						}
					}
				} // bDamage
			}
		}
		END_LINKMAP
	}

	// Àû¿ë´ë»óÀÌ ¸ó½ºÅÍÀÎ°¡.
	if( nApplyType & OBJTYPE_MONSTER )
	{
		FOR_LINKMAP( GetWorld(), vPos, pObj, nRange, CObj::linkDynamic, GetLayer() )
		{
			if( pObj->GetType() == OT_MOVER && ((CMover *)pObj)->IsPeaceful() == FALSE )
			{
				pTarget = (CMover *)pObj;
				if( IsValidObj( pTarget ) && pTarget->IsLive() )
				{
					// Å¸°ÙÃø ÁÂÇ¥¸¦ ¿ªº¯È¯.
					D3DXVec3TransformCoord( &vDestLocal, &pTarget->GetPos(), &mInv );
					// Å¸°ÙÃø AABB
					D3DXVECTOR3 vMin2 = vDestLocal + pTarget->m_pModel->m_vMin;
					D3DXVECTOR3 vMax2 = vDestLocal + pTarget->m_pModel->m_vMax;
					if( ::IsTouchAABB( vMin1, vMax1, vMin2, vMax2 ) )		// AABBÃæµ¹°Ë»ç.
					{
						if( pProp->dwComboStyle == CT_FINISH )
							pTarget->m_pActMover->SendDamageForce( nDmgType, GetId(), (nAttackID << 16) );
						else
							pTarget->m_pActMover->SendDamage( nDmgType, GetId(), (nAttackID << 16) ); 
					}
				}
			}
		}
		END_LINKMAP
	}
		
#endif // WORLDSERVER		
} // SendDamageLine()


#ifdef __WORLDSERVER
BOOL CMover::DoUseItemWarp( ItemProp* pItemProp, CItemElem* pItemElem )
{
	switch( pItemProp->dwID )
	{
		case II_GEN_WARP_COUPLERING:
		case II_GEN_WARP_WEDDING_BAND:
#if __VER >= 8 // __S_COUPLERING01
		case II_GEN_WARP_COUPLERING01:
#endif // __VER >= 8
			{
				if( IsFly() )
				{
					return FALSE;
				}
#ifdef __MOUNT
				if (GetMountId() > 0)
					return FALSE;
#endif // __MOUNT
//				if( pItemElem->IsFlag( CItemElem::expired ) )
//				{
//					( (CUser*)this )->AddDefinedText( TID_GAME_ITEM_EXPIRED );
//					return FALSE;
//				}
				u_long idCouple	= (u_long)( pItemElem->GetRandomOptItemId() );
				if( idCouple == m_idPlayer )
				{
					( (CUser*)this )->AddDefinedText( TID_GAME_COUPLERING_ERR01, "%s", GetName() );
					return FALSE;
				}

				if( idCouple > 0 )
				{
					// teleport
#if __VER >= 11 // __SYS_PLAYER_DATA
					const char* lpszPlayer	= CPlayerDataCenter::GetInstance()->GetPlayerString( idCouple );
#else	// __SYS_PLAYER_DATA
					LPCSTR lpszPlayer	= prj.GetPlayerString( idCouple );
#endif	// __SYS_PLAYER_DATA
					if( lpszPlayer )
					{
						CUser* pUser	= (CUser*)prj.GetUserByID( idCouple );
						if( IsValidObj( (CObj*)pUser ) )
						{
							if( pUser->IsFly() )
							{
								( (CUser*)this )->AddDefinedText( TID_GAME_COUPLERING_ERR03 );
								return FALSE;
							}
							if( pUser->GetWorld() && pUser->GetWorld()->GetID() == WI_WORLD_GUILDWAR )
								return FALSE;
							if( GetWorld() && GetWorld()->GetID() == WI_WORLD_GUILDWAR )
								return FALSE;
#if __VER >= 11	// __GUILD_COMBAT_1TO1
							if( GetWorld() && GetWorld()->GetID() >= WI_WORLD_GUILDWAR1TO1_0
								          && GetWorld()->GetID() <= WI_WORLD_GUILDWAR1TO1_L )
								return FALSE;
							if( pUser->GetWorld() && pUser->GetWorld()->GetID() >= WI_WORLD_GUILDWAR1TO1_0
												&& pUser->GetWorld()->GetID() <= WI_WORLD_GUILDWAR1TO1_L )
								return FALSE;
#endif // __GUILD_COMBAT_1TO1
#if __VER >= 13 // __RAINBOW_RACE
							if( CRainbowRaceMng::GetInstance()->IsEntry( ((CUser*)this)->m_idPlayer )
								|| CRainbowRaceMng::GetInstance()->IsEntry( idCouple ) )
							{
								((CUser*)this)->AddDefinedText( TID_GAME_RAINBOWRACE_NOTELEPORT );
								return FALSE;
							}
#endif // __RAINBOW_RACE

							if( GetWorld() == pUser->GetWorld() && !prj.IsGuildQuestRegion( pUser->GetPos() )
#if __VER >= 14 // __INSTANCE_DUNGEON
								&& GetLayer() == pUser->GetLayer()
#endif // __INSTANCE_DUNGEON
#ifdef __QUIZ
								&& GetWorld()->GetID() != WI_WORLD_QUIZ
								&& pUser->GetWorld()->GetID() != WI_WORLD_QUIZ
#endif // __QUIZ
								)
							{
#ifdef __FIX_TELEPORT
								if (pUser->GetWorld())
									this->REPLACE(g_uIdofMulti, pUser->GetWorld()->GetID(), pUser->GetPos(), REPLACE_NORMAL, pUser->GetLayer());
#else
								g_DPCoreClient.SendTeleportPlayer(m_idPlayer, idCouple);
#endif
							}
							else
							{
								( (CUser*)this )->AddDefinedText( TID_GAME_COUPLERING_ERR02, "%s", lpszPlayer );
							}
						}
						else
							( (CUser*)this )->AddDefinedText( TID_DIAG_0061, "%s", lpszPlayer );
					}
				}
				else
				{
					// carve
#if __VER >= 11 // __SYS_IDENTIFY
					UpdateItemEx( (BYTE)( pItemElem->m_dwObjId ), UI_RANDOMOPTITEMID, (__int64)m_idPlayer );
#else	// __SYS_IDENTIFY
					UpdateItem( (BYTE)( pItemElem->m_dwObjId ), UI_RANDOMOPTITEMID, m_idPlayer );
#endif	// __SYS_IDENTIFY
					if( II_GEN_WARP_COUPLERING == pItemProp->dwID )
						UpdateItem( (BYTE)( pItemElem->m_dwObjId ), UI_KEEPTIME, 21600 );	// 15 days
					( (CUser*)this )->AddDefinedText( TID_GAME_COUPLERING_CARVE, "%s", GetName() );
				}
				return TRUE;
			}
		default:
			break;
	}
	return FALSE;
}
#endif	// __WORLDSERVER

// nIndex skillÀÇ Àç»ç¿ë µô·¹ÀÌ¸¦ ¸®ÅÏÇÑ´Ù. 
// nIndex - skillÀÇ index, ( m_tmReUseDelay, m_aJobSkillÀÇ ÀÎµ¦½º´Â °°Àº ÀÇ¹Ì )
DWORD CMover::GetReuseDelay( int nIndex )
{
	ASSERT( nIndex >= 0 );	

	DWORD dwCur = ::timeGetTime();
	if( dwCur > m_tmReUseDelay[nIndex] )	// Á¾·á½Ã°¢ º¸´Ù ÇöÀç ½Ã°¢ÀÌ Å©¸é 
		return 0;								// µô·¹ÀÌ ¾ø´Ù.
	else									// ¾Æ´Ï¸é 
		return m_tmReUseDelay[nIndex] - dwCur;	// Á¾·á½Ã°¢ - ÇöÀç½Ã°¢ 
}

#if __VER >= 9	// __PET_0410
#ifndef __CLIENT
int CMover::DoUseItemFeedPocket( CItemElem* pPocket )
{
	int nResult = 0;

#ifdef __JEFF_11_1
	if( HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_PET_FEED_POCKET02 ) )
	{
		( (CUser*)this )->AddDefinedText( TID_GAME_DONOTUSE_PETPOCKET );
		return	4;
	}
#endif	// __JEFF_11_1
	// È°¼ºÈ­ °Ë»ç
	if( HasBuff( BUFF_ITEM, (WORD)( pPocket->m_dwItemId ) ) )
	{
		if( pPocket->m_dwKeepTime != 0 )
		{
			RemoveBuff( BUFF_ITEM, (WORD)( pPocket->m_dwItemId ) );
			nResult = 4;
		}
		else
			nResult = 2;
	}
	else
	{
		ItemProp* pProp	= pPocket->GetProp();
		if( pPocket->m_dwKeepTime == 0 )	// ¸¸·á ½Ã°£ÀÌ ¼³Á¤µÇ¾î ÀÖÁö ¾ÊÀ¸¹Ç·Î ÃÖÃÊ »ç¿ëÀÌ´Ù.
		{
			int nMax	= m_Inventory.GetMax();
			CItemElem* pItemElem;
			for( int i = 0 ; i < nMax; i++ )
			{
				pItemElem	= m_Inventory.GetAtId( i );
				if( IsUsableItem( pItemElem )
					&& pItemElem->m_dwItemId == pPocket->m_dwItemId
					&& pItemElem->m_dwKeepTime > 0
					&& !pItemElem->IsFlag( CItemElem::expired )
					)
				{
					// ±â°£ÀÌ ¸¸·áµÇÁö ¾ÊÀº µ¿ÀÏ ¾ÆÀÌÅÛÀÌ Á¸ÀçÇÏ¿© »ç¿ëÇÒ ¼ö ¾ø´Ù.
					( (CUser*)this )->AddDefinedText( TID_GAME_DONOTUSE_PETPOCKET, "" );
					nResult = 4;
					return nResult;
				}
			}
			ASSERT( pProp->dwAbilityMin < 259200 );
			UpdateItem( (BYTE)( pPocket->m_dwObjId ), UI_KEEPTIME, pProp->dwAbilityMin );	// 1440	// 1 days
		}
		DoApplySkill( (CCtrl*)this, pProp, NULL );
	}

	return nResult;
}
#endif	// __CLIENT
#endif	// __PET_0410

#ifdef __WORLDSERVER
void CMover::ActivateSystemPet( CItemElem* pItemElem )
{
#ifdef __SECURITY_FIXES
	if (!pItemElem)
		return;
#endif // __SECURITY_FIXES
#ifdef __QUIZ
	if( GetWorld() && GetWorld()->GetID() == WI_WORLD_QUIZ )
		return;
#endif // __QUIZ
	if( IsFly() )
	{
		static_cast<CUser*>( this )->AddDefinedText( TID_GAME_CANNOT_CALL_PET_ON_FLYING );
		return;	
	}
#ifdef __MOUNT
	if (GetMountId() > 0)
	{
		static_cast<CUser*>(this)->AddDefinedText(TID_GAME_CANNOT_CALL_PET_ON_FLYING);
		return;
	}
#endif // __MOUNT
	BOOL bFirst		= FALSE;
	if( pItemElem->m_pPet == NULL )
	{
		pItemElem->m_pPet	= new CPet;
		pItemElem->m_pPet->InitEgg();
		bFirst	= TRUE;
	}
	SetPetId( pItemElem->m_dwObjId );

//#if __VER >= 12 // __PET_0519	// CMover::ProcessPetAvail()·Î ÀÌµ¿
//	SetDestParamRandomOptExtension( pItemElem );	// ½Ã½ºÅÛ Æê È°¼ºÈ­ ½Ã °¢¼º È¿°ú Àû¿ë
//#endif	// __PET_0519
	g_dpDBClient.CalluspPetLog( m_idPlayer, pItemElem->GetSerialNumber(), 0, PETLOGTYPE_CALL, pItemElem->m_pPet );
	// pet, log
#ifdef __PET_1024
	g_UserMng.AddPetCall( this, pItemElem->m_dwObjId, pItemElem->m_pPet->GetIndex(), (BYTE)pItemElem->m_pPet->GetLevel(), pItemElem->m_pPet->GetName() );
#else	// __PET_1024
	g_UserMng.AddPetCall( this, pItemElem->m_dwObjId, pItemElem->m_pPet->GetIndex(), (BYTE)pItemElem->m_pPet->GetLevel() );
#endif	// __PET_1024
	
	if( bFirst )
		static_cast<CUser*>(this )->AddPet( pItemElem->m_pPet, PF_PET );
}

void CMover::InactivateSystemPet( CItemElem* pItemElem )
{
	if( GetPetId() == pItemElem->m_dwObjId )
		PetRelease();
	else
		static_cast<CUser*>(this )->AddDefinedText( TID_GAME_PET_NOWUSE );
}

void CMover::DoUseSystemPet( CItemElem* pItemElem )
{
	if( HasActivatedSystemPet() )
		InactivateSystemPet( pItemElem );
	else
		ActivateSystemPet( pItemElem );
}

void CMover::DoUseEatPet( CItemElem* pItemElem )
{
#ifdef __NEW_ITEM_VARUNA
	if( HasActivatedEatPet() )
	{
		CMover* pPet = prj.GetMover( GetEatPetId() );
		if( pPet && pPet->GetProp()->dwAI == AII_NONE )
			InactivateBarunaPet();
		else
			InactivateEatPet();
	}
#else // __NEW_ITEM_VARUNA
	if( HasActivatedEatPet() )
		InactivateEatPet();
#endif // __NEW_ITEM_VARUNA
	else
		ActivateEatPet( pItemElem );
}		

void CMover::ActivateEatPet( CItemElem* pItemElem )
{
#ifdef __GAMEGUARD
	if (!pItemElem)
		return;
#endif // __GAMEGUARD

	ItemProp* pProp	= pItemElem->GetProp();
	if( !pProp )
		return;

#ifdef __QUIZ
	if( GetWorld() && GetWorld()->GetID() == WI_WORLD_QUIZ )
		return;
#endif // __QUIZ

	if( IsFly() )
	{
		static_cast<CUser*>( this )->AddDefinedText( TID_GAME_CANNOT_CALL_PET_ON_FLYING );
		return;
	}
#ifdef __FIX_CRASH_PET
	if (GetTickCount() - static_cast<CUser*>(this)->m_tLastOpenPet > 1000)
		static_cast<CUser*>(this)->m_nNbrOpenPet = 0;

	if (static_cast<CUser*>(this)->m_nNbrOpenPet > 0)
		return;

	static_cast<CUser*>(this)->m_nNbrOpenPet++;
	static_cast<CUser*>(this)->m_tLastOpenPet = GetTickCount();
#endif //__FIX_CRASH_PET
#ifdef __MOUNT
	if (GetMountId() > 0)
	{
		static_cast<CUser*>(this)->AddDefinedText(TID_GAME_CANNOT_CALL_PET_ON_FLYING);
		return;
	}
#endif // __MOUNT
//		ASSERT( pItemProp->dwLinkKind != NULL_ID )
#ifdef __LOOKCHANGE
	DWORD dwPetId;
	if (pItemElem && pItemElem->IsChangedLook())
	{
		ItemProp* pProp2 = prj.GetItemProp(pItemElem->GetLook());
		dwPetId = pProp2->dwLinkKind;
	}
	else
		dwPetId = pProp->dwLinkKind;

	CMover *pEatPet = CreateMover(GetWorld(), dwPetId, GetPos(), GetLayer());
#else
#ifdef __LAYER_1015
	CMover *pEatPet	= CreateMover( GetWorld(), pProp->dwLinkKind, GetPos(), GetLayer() );
#else	// __LAYER_1015
	CMover *pEatPet	= CreateMover( GetWorld(), pProp->dwLinkKind, GetPos() );
#endif	// __LAYER_1015
#endif

	if( pEatPet )
	{
		CAIPet *pAIPet	= static_cast<CAIPet*>( pEatPet->m_pAIInterface );
		if( pAIPet )
		{
			pAIPet->SetOwner( GetId() );
			SetEatPetId( pEatPet->GetId() );
#if __VER >= 12 // __PET_0519
			pAIPet->SetItem( this, pItemElem );		// ¸ÔÆê È°¼ºÈ­ ½Ã °¢¼º È¿°ú Àû¿ë
#endif	// __PET_0519
#ifdef __EATPET_STATS
#if __VER >= 19
			for (int i = 0; i < 6; i++)
#else // __VER >= 19
#ifdef __PROP_0827
			for (int i = 0; i < 3; i++)
#else // __PROP_0827
			for (int i = 0; i < 2; i++)
#endif // __PROP_0827
#endif // __VER >= 19
			{
				if (pProp->dwDestParam[i] != NULL_ID)
					SetDestParam(pProp->dwDestParam[i], pProp->nAdjParamVal[i], pProp->dwChgParamVal[i]);
			}
#endif // __EATPET_STATS
#if __VER >= 15 // __PETVIS
			if( pItemElem->IsVisPet() )
			{
				if( pItemElem->GetPiercingSize() <= 0 )	// Ã¹ ¼ÒÈ¯½Ã ºñ½ºÆêÀÌ¸é ºñ½º ½½·Ô 2°³(±âº») ¶Õ¾îÁÜ
					UpdateItem( (BYTE)( pItemElem->m_dwObjId ), UI_PETVIS_SIZE, PETVIS_DEFAULT_VIS_SLOT_SZIE );

				SetVisPetItem( pItemElem->m_dwObjId );	// ÇØ´ç ¸ÔÆêÀÌ ºñ½ºÆêÀÌ¸é ºñ½ºÀÇ ´É·ÂÄ¡¸¦ Àû¿ëÇÏ°í ÀÌÆåÆ®¸¦ ÁöÁ¤ÇÑ´Ù.
				SetPetVisDST( pItemElem );
				pEatPet->m_dwMoverSfxId = pItemElem->GetVisPetSfxId();
				static_cast<CUser*>(this)->AddActivateVisPet( pItemElem->m_dwObjId, GetEatPetId() );
			}
#endif // __PETVIS
		}
	}
}

void CMover::InactivateEatPet( void )
{
	CMover* pEatPet		= prj.GetMover( GetEatPetId() );
	if( IsValidObj( pEatPet ) )
	{
#if __VER >= 12 // __PET_0519
		// ¸ÔÆê ¼ÒÈ¯ Á¾·á ½Ã °¢¼º È¿°ú Á¦°Å
		CAIPet *pAIPet	= static_cast<CAIPet*>( pEatPet->m_pAIInterface );
		if( pAIPet )
		{
#ifdef __EATPET_STATS
			CItemElem* pPetItem = m_Inventory.GetAtId(pAIPet->GetPetItemId());
			if (pPetItem)
			{
				ItemProp* pProp = pPetItem->GetProp();
				if (pProp)
				{
#if __VER >= 19
					for (int i = 0; i < 6; i++)
#else // __VER >= 19
#ifdef __PROP_0827
					for (int i = 0; i < 3; i++)
#else // __PROP_0827
					for (int i = 0; i < 2; i++)
#endif // __PROP_0827
#endif // __VER >= 19
					{
						if (pProp->dwDestParam[i] != NULL_ID)
							ResetDestParam(pProp->dwDestParam[i], pProp->nAdjParamVal[i]);
					}
				}
			}
#endif // __EATPET_STATS
#if __VER >= 15 // __PETVIS
			CItemElem* pItemElem = GetVisPetItem();
			if( pItemElem )
			{
				ResetPetVisDST( pItemElem );
				SetVisPetItem( NULL_ID );
				static_cast<CUser*>(this)->AddActivateVisPet( NULL_ID, NULL_ID );
			}
#endif // __PETVIS
			pAIPet->ResetItem();
		}
#endif	// __PET_0519

		pEatPet->Delete();
	}
	SetEatPetId( NULL_ID );
}

#if __VER >= 15 // __PETVIS
void CMover::SetPetVisDST( CItemElem* pItemElem )
{
	if( pItemElem && pItemElem->IsVisPet() )
	{
		AddBuff( BUFF_EQUIP, (WORD)( pItemElem->m_dwItemId ), 1, 999999999 );
		
		vector<BYTE> vecValidTable = GetValidVisTable( pItemElem );
		for( int i=0; i<pItemElem->GetPiercingSize(); i++ )
		{
			ItemProp* pItemProp = prj.GetItemProp( pItemElem->GetPiercingItem( i ) );
			if( vecValidTable[i] == SUCCSESS_NEEDVIS && pItemProp )
			{
				SetDestParam( 0, pItemProp );
				SetDestParam( 1, pItemProp );
				SetDestParam( 2, pItemProp );
			}
			else
			{
				if( IsPlayer() && pItemProp )
					static_cast<CUser*>( this )->AddDefinedText( TID_GAME_BUFFPET_NOTREQVIS, "\"%s\"", pItemProp->szName );
			}
		}
	}
}

void CMover::ResetPetVisDST( CItemElem* pItemElem )
{
	if( pItemElem && pItemElem->IsVisPet() )
	{
		m_buffs.RemoveBuff( BUFF_EQUIP, (WORD)( pItemElem->m_dwItemId ), FALSE );

		vector<BYTE> vecValidTable = GetValidVisTable( pItemElem );
		for( int i=0; i<pItemElem->GetPiercingSize(); i++ )
		{
			ItemProp* pItemProp = prj.GetItemProp( pItemElem->GetPiercingItem( i ) );
			if( vecValidTable[i] == SUCCSESS_NEEDVIS && pItemProp )
			{
				ResetDestParam( 0, pItemProp );
				ResetDestParam( 1, pItemProp );
				ResetDestParam( 2, pItemProp );
			}
		}
	}
}

void CMover::ProcessVisPet()
{
	if( HasActivatedVisPet() )
	{
		CItemElem* pItemElem = GetVisPetItem();
		if( pItemElem )
		{
			for( int i=0; i<pItemElem->GetPiercingSize(); i++ )
			{
				if( pItemElem->GetPiercingItem( i ) != 0 && time_null() >= pItemElem->GetVisKeepTime( i ) )
				{
					ItemProp* pItemProp = prj.GetItemProp( pItemElem->GetPiercingItem( i ) );
					if( pItemProp )
						static_cast<CUser*>( this )->AddDefinedText( TID_GAME_BUFFPET_TIMEOUTVIS, "\"%s\"", pItemProp->szName );
					CItemUpgrade::GetInstance()->RemovePetVisItem( static_cast<CUser*>( this ), i, TRUE );
				}
			}
		}		
	}
}
#endif // __PETVIS
#ifdef __NEW_ITEM_VARUNA
void CMover::DoUseBarunaPet( CItemElem* pItemElem )
{
	if( HasActivatedEatPet() )
	{
		CMover* pPet = prj.GetMover( GetEatPetId() );
		if( pPet && pPet->GetProp()->dwAI == AII_NONE )
		{
			InactivateBarunaPet();
			return;
		}
		else
		{
			InactivateEatPet();
			return;
		}
	}

	ItemProp* pProp	= pItemElem->GetProp();
	if( !pProp )
		return;

#ifdef __QUIZ
	if( GetWorld() && GetWorld()->GetID() == WI_WORLD_QUIZ )
		return;
#endif // __QUIZ

	if( IsFly() )
	{
		static_cast<CUser*>( this )->AddDefinedText( TID_GAME_CANNOT_CALL_PET_ON_FLYING );
		return;
	}

#ifdef __MOUNT
	if (GetMountId() > 0)
	{
		static_cast<CUser*>(this)->AddDefinedText(TID_GAME_CANNOT_CALL_PET_ON_FLYING);
		return;
	}
#endif // __MOUNT

	CMover *pBarunaPet	= CreateMover( GetWorld(), pProp->dwLinkKind, GetPos(), GetLayer() );

	if( pBarunaPet )
	{
		CString szCharacterKey;
		switch( pProp->dwLinkKind )
		{
		case MI_PET_SMELTPIYO:
			szCharacterKey = "Pet_Seltpiyo";
			break;
		case MI_PET_SMELTUDI:
			szCharacterKey = "Pet_Seltpudi";
			break;
		case MI_PET_SMELTCOBI:
			szCharacterKey = "Pet_Seltcobi";
			break;
		case MI_PET_SMELTPIERCE:
			szCharacterKey = "Pet_Seltpierce";
			break;
		default:
			szCharacterKey = "Pet_Seltpiyo";
			break;
		}

		lstrcpy( pBarunaPet->m_szCharacterKey, szCharacterKey );

		pBarunaPet->InitNPCProperty();
		pBarunaPet->InitCharacter( pBarunaPet->GetCharacter() );
		pBarunaPet->m_idBarunaPetOwner = GetId();
		dwBarunaPetItemId = pItemElem->m_dwObjId;
		SetEatPetId( pBarunaPet->GetId() );
		static_cast<CUser*>(this)->AddActivateBarunaPet( pItemElem->m_dwObjId, pBarunaPet->GetId(), TRUE );
	}
}
void CMover::InactivateBarunaPet( void )
{
	CMover* pBarunaPet		= prj.GetMover( GetEatPetId() );
	if( IsValidObj( pBarunaPet ) )
	{
		pBarunaPet->Delete();
	}
	SetEatPetId( NULL_ID );
	static_cast<CUser*>(this)->AddActivateBarunaPet( NULL_ID, NULL_ID, FALSE );
}

#endif // __NEW_ITEM_VARUNA
#endif	// __WORLDSERVER

#if __VER >= 15 // __PETVIS
vector<BYTE> CMover::GetValidVisTable( CItemElem* pItemElem )
{
	vector<BYTE> vecTemp;
	vecTemp.resize( pItemElem->GetPiercingSize(), UNDEFINED_NEEDVIS );

	for( DWORD i=0; i<vecTemp.size(); i++ )
		if( pItemElem->GetPiercingItem( i ) == 0 )
			vecTemp[i] = FAILED_BOTH_NEEDVIS;
	
	for( DWORD i=0; i<vecTemp.size(); i++ )
		if( vecTemp[i] == UNDEFINED_NEEDVIS )
			SetValidNeedVis( pItemElem, i, vecTemp );

	return vecTemp;
}

BOOL CMover::SetValidNeedVis( CItemElem* pItemElem, int nPos, vector<BYTE> & vecValid )
{
	if( vecValid[nPos] != UNDEFINED_NEEDVIS )
		return ( vecValid[nPos] == SUCCSESS_NEEDVIS );
	
	ItemProp* pPropVis = prj.GetItemProp( pItemElem->GetPiercingItem( nPos ) );
	if( !pPropVis )
	{
		vecValid[nPos] = FAILED_BOTH_NEEDVIS;
		return FALSE;
	}

	if( pPropVis->dwReferTarget1 == NULL_ID && pPropVis->dwReferTarget2 == NULL_ID )
	{
		vecValid[nPos] = SUCCSESS_NEEDVIS;
		return TRUE;
	}

	BOOL bResult1 = FALSE, bResult2 = FALSE;
	if( pPropVis->dwReferTarget1 == NULL_ID ) bResult1 = TRUE;
	if( pPropVis->dwReferTarget2 == NULL_ID ) bResult2 = TRUE;

	for( int i=0; i<pItemElem->GetPiercingSize(); i++ )
	{
		if( pPropVis->dwReferTarget1 == pItemElem->GetPiercingItem( i ) )
			bResult1 = SetValidNeedVis( pItemElem, i, vecValid );

		if( pPropVis->dwReferTarget2 == pItemElem->GetPiercingItem( i ) )
			bResult2 = SetValidNeedVis( pItemElem, i, vecValid );

		if( bResult1 && bResult2 )
		{
			vecValid[nPos] = SUCCSESS_NEEDVIS;
			return TRUE;
		}
	}

	if( !bResult1 && bResult2 )
		vecValid[nPos] = FAILED_1ST_NEEDVIS;
	else if( bResult1 && !bResult2 )
		vecValid[nPos] = FAILED_2ND_NEEDVIS;
	else
		vecValid[nPos] = FAILED_BOTH_NEEDVIS;
	return FALSE;
}

BYTE CMover::IsSatisfyNeedVis( CItemElem* pItemElemVisPet, ItemProp* pItemPropVis )
{
	if( pItemPropVis )
	{
		DWORD	dwNeeds[2] = { pItemPropVis->dwReferTarget1, pItemPropVis->dwReferTarget2 };
		if( dwNeeds[0] == NULL_ID && dwNeeds[1] == NULL_ID )
			return SUCCSESS_NEEDVIS;
		
		vector<BYTE> vecValidTable = GetValidVisTable( pItemElemVisPet );
		for( int i=0; i<pItemElemVisPet->GetPiercingSize(); i++ )	// ÇÊ¿ä ºñ½º°¡ ÃæÁ·µÇÁö ¾ÊÀº °æ¿ì´Â ´É·ÂÄ¡°¡ Àû¿ëµÇÁö ¾Ê¾ÒÀ¸¹Ç·Î ´É·ÂÄ¡¸¦ »©¸é ¾ÈµÈ´Ù.
		{
			DWORD dwVis = pItemElemVisPet->GetPiercingItem( i );
			if( dwNeeds[0] == dwVis && vecValidTable[i] == SUCCSESS_NEEDVIS && time_null() < pItemElemVisPet->GetVisKeepTime( i ) )	dwNeeds[0] = NULL_ID;
			if( dwNeeds[1] == dwVis && vecValidTable[i] == SUCCSESS_NEEDVIS && time_null() < pItemElemVisPet->GetVisKeepTime( i ) )	dwNeeds[1] = NULL_ID;
			if( dwNeeds[0] == NULL_ID && dwNeeds[1] == NULL_ID )
				return SUCCSESS_NEEDVIS;
		}
			
		if( dwNeeds[0] != NULL_ID && dwNeeds[1] == NULL_ID )
			return FAILED_1ST_NEEDVIS;
		else if( dwNeeds[0] == NULL_ID && dwNeeds[1] != NULL_ID )
			return FAILED_2ND_NEEDVIS;
	}

	return FAILED_BOTH_NEEDVIS;
}
#endif // __PETVIS

#if __VER >= 12 // __PET_0519
// Æê ¿µ¾çÁ¦ »ç¿ë
int CMover::DoUseItemPetTonic( CItemElem* pItemElem )
{
	// Æê ¿µ¾çÁ¦ µÎ Á¾·ù¸¦ ¼¯¾î¼­ »ç¿ëÇÒ ¼ö ¾ø´Ù
	if( ( pItemElem->m_dwItemId == II_SYS_SYS_SCR_PET_TONIC_A && HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_PET_TONIC_B ) )
		|| ( pItemElem->m_dwItemId == II_SYS_SYS_SCR_PET_TONIC_B && HasBuff( BUFF_ITEM, II_SYS_SYS_SCR_PET_TONIC_A ) )
	)
		return 2;

	// ½Ã°£ ¿À¹öÇÃ·Î¿ì ¸·±â
	DWORD dwCurr	= ::timeGetTime();
#ifdef __BUFF_1107
	IBuff* pBuff	= m_buffs.GetBuff( BUFF_ITEM, (WORD)( pItemElem->m_dwItemId ) );
	if( pBuff && static_cast<int>( pItemElem->GetProp()->dwSkillTime ) > static_cast<int>( pItemElem->GetProp()->dwSkillTime + ( pBuff->GetTotal() - ( dwCurr - pBuff->GetInst() ) ) ) )
		return 1;
#else	// __BUFF_1107
	LPSKILLINFLUENCE ptr	= m_SkillState.FindPtr( BUFF_ITEM, pItemElem->m_dwItemId );
	if( ptr && static_cast<int>( pItemElem->GetProp()->dwSkillTime ) > static_cast<int>( pItemElem->GetProp()->dwSkillTime + ( ptr->tmCount - ( dwCurr - ptr->tmTime ) ) ) )
		return 1;
#endif	// __BUFF_1107

	// È¿°ú Àû¿ë
	DoApplySkill( this, pItemElem->GetProp(), NULL );
	return 0;
}
#endif	// __PET_0519
```
